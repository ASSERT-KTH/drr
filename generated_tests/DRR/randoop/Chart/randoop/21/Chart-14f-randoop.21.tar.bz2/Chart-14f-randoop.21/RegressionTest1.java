import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        xYPlot0.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis5.getTickMarkPaint();
        xYPlot0.setDomainTickBandPaint(paint10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color15, stroke16);
        boolean boolean18 = axisLocation13.equals((java.lang.Object) valueMarker17);
        float float19 = valueMarker17.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = valueMarker17.getLabelAnchor();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean23 = layer21.equals((java.lang.Object) dateRange22);
        java.lang.String str24 = layer21.toString();
        xYPlot0.addDomainMarker((int) (short) 100, (org.jfree.chart.plot.Marker) valueMarker17, layer21);
        xYPlot0.configureDomainAxes();
        xYPlot0.configureDomainAxes();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Layer.FOREGROUND" + "'", str24.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot0.setInsets(rectangleInsets7);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot0.getDomainAxisEdge((int) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeMinimumSize((double) 11, false);
        numberAxis12.setAutoRangeStickyZero(true);
        double double18 = numberAxis12.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = numberAxis19.valueToJava2D((double) 10, rectangle2D21, rectangleEdge22);
        org.jfree.data.Range range24 = numberAxis19.getDefaultAutoRange();
        numberAxis12.setRange(range24, true, true);
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis12.setTickMarkPaint((java.awt.Paint) color28);
        categoryPlot0.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis12);
        org.jfree.chart.plot.Plot plot31 = categoryPlot0.getRootPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = plot31.getInsets();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(plot31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot0.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot0.setRenderer(categoryItemRenderer14, true);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = numberAxis18.valueToJava2D((double) 10, rectangle2D20, rectangleEdge21);
        org.jfree.data.Range range23 = numberAxis18.getDefaultAutoRange();
        numberAxis18.zoomRange((double) 0L, (double) 3);
        java.lang.String str27 = numberAxis18.getLabel();
        categoryPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis18, false);
        categoryPlot0.setRangeCrosshairValue((double) 4, false);
        org.jfree.chart.plot.Plot plot33 = categoryPlot0.getRootPlot();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(plot33);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        categoryPlot8.setDomainAxis((int) 'a', categoryAxis10);
        categoryPlot8.setBackgroundImageAlignment((int) (short) 10);
        float float14 = categoryPlot8.getBackgroundAlpha();
        org.jfree.chart.axis.AxisSpace axisSpace15 = categoryPlot8.getFixedRangeAxisSpace();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot8);
        java.awt.Paint paint17 = categoryPlot8.getOutlinePaint();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        try {
            categoryPlot8.setRenderer((-48897), categoryItemRenderer19, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
        org.junit.Assert.assertNull(axisSpace15);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryAxis1.equals(obj2);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis6);
        categoryPlot4.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        categoryPlot4.setDataset(0, categoryDataset10);
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot4.setNoDataMessagePaint(paint12);
        java.awt.Paint paint14 = categoryPlot4.getOutlinePaint();
        float float15 = categoryPlot4.getBackgroundAlpha();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot4);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis1.getCategoryMiddle(0, 128, rectangle2D19, rectangleEdge20);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        boolean boolean7 = xYPlot0.isDomainCrosshairVisible();
        boolean boolean8 = xYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = numberAxis9.valueToJava2D((double) 10, rectangle2D11, rectangleEdge12);
        org.jfree.data.Range range14 = numberAxis9.getDefaultAutoRange();
        numberAxis9.zoomRange((double) 0L, (double) 3);
        int int18 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis9);
        java.awt.Paint paint19 = xYPlot0.getRangeZeroBaselinePaint();
        java.awt.Paint paint20 = xYPlot0.getDomainZeroBaselinePaint();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        java.awt.Color color3 = java.awt.Color.getHSBColor(0.0f, (float) 11, (float) 10);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 12, 128.0d, 3.0d, 1.0E-8d);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        numberAxis6.setAutoRangeMinimumSize((double) 11, false);
        numberAxis6.setAutoRangeStickyZero(true);
        double double12 = numberAxis6.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = numberAxis13.valueToJava2D((double) 10, rectangle2D15, rectangleEdge16);
        org.jfree.data.Range range18 = numberAxis13.getDefaultAutoRange();
        numberAxis6.setRange(range18, true, true);
        boolean boolean22 = unitType0.equals((java.lang.Object) true);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color2 = java.awt.Color.getColor("PlotOrientation.HORIZONTAL", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker9.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = valueMarker9.getOutlineStroke();
        boolean boolean13 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.data.general.DatasetGroup datasetGroup14 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot15.setDomainAxis((int) 'a', categoryAxis17);
        categoryPlot15.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.data.general.DatasetGroup datasetGroup21 = categoryPlot15.getDatasetGroup();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot15);
        categoryPlot15.setBackgroundAlpha((float) (-393216));
        org.jfree.data.general.DatasetGroup datasetGroup25 = categoryPlot15.getDatasetGroup();
        java.awt.Paint paint26 = categoryPlot15.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(datasetGroup14);
        org.junit.Assert.assertNull(datasetGroup21);
        org.junit.Assert.assertNull(datasetGroup25);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundAlpha((float) 4);
        categoryPlot0.mapDatasetToDomainAxis(128, 4);
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot0.getRangeAxisLocation();
        org.junit.Assert.assertNotNull(axisLocation6);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        xYPlot0.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis5.getTickMarkPaint();
        xYPlot0.setDomainTickBandPaint(paint10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color15, stroke16);
        boolean boolean18 = axisLocation13.equals((java.lang.Object) valueMarker17);
        float float19 = valueMarker17.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = valueMarker17.getLabelAnchor();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean23 = layer21.equals((java.lang.Object) dateRange22);
        java.lang.String str24 = layer21.toString();
        xYPlot0.addDomainMarker((int) (short) 100, (org.jfree.chart.plot.Marker) valueMarker17, layer21);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        numberAxis26.setAutoRangeMinimumSize((double) 11, false);
        numberAxis26.setAutoRangeStickyZero(true);
        double double32 = numberAxis26.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        double double37 = numberAxis33.valueToJava2D((double) 10, rectangle2D35, rectangleEdge36);
        org.jfree.data.Range range38 = numberAxis33.getDefaultAutoRange();
        numberAxis26.setRange(range38, true, true);
        java.awt.Color color42 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis26.setTickMarkPaint((java.awt.Paint) color42);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = null;
        double double48 = numberAxis44.valueToJava2D((double) 10, rectangle2D46, rectangleEdge47);
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = null;
        double double53 = numberAxis49.valueToJava2D((double) 10, rectangle2D51, rectangleEdge52);
        org.jfree.data.Range range54 = numberAxis49.getDefaultAutoRange();
        numberAxis44.setRange(range54);
        boolean boolean56 = color42.equals((java.lang.Object) numberAxis44);
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color42);
        org.jfree.chart.plot.Plot plot58 = xYPlot0.getRootPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder59 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.ValueAxis valueAxis60 = xYPlot0.getRangeAxis();
        org.jfree.chart.plot.XYPlot xYPlot61 = new org.jfree.chart.plot.XYPlot();
        xYPlot61.mapDatasetToDomainAxis((int) (byte) 100, 1);
        org.jfree.data.general.Dataset dataset66 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent67 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 2, dataset66);
        xYPlot61.datasetChanged(datasetChangeEvent67);
        xYPlot0.datasetChanged(datasetChangeEvent67);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Layer.FOREGROUND" + "'", str24.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(plot58);
        org.junit.Assert.assertNotNull(seriesRenderingOrder59);
        org.junit.Assert.assertNull(valueAxis60);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        java.awt.Paint paint2 = xYPlot0.getRangeGridlinePaint();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation3 = null;
        try {
            boolean boolean4 = xYPlot0.removeAnnotation(xYAnnotation3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        boolean boolean5 = numberAxis0.getAutoRangeStickyZero();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        categoryPlot6.setDataset(categoryDataset7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        categoryPlot6.removeChangeListener(plotChangeListener9);
        numberAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        org.jfree.data.Range range12 = null;
        try {
            numberAxis0.setRange(range12, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean2 = layer0.equals((java.lang.Object) dateRange1);
        java.lang.String str3 = layer0.toString();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis6);
        categoryPlot4.setBackgroundImageAlignment((int) (short) 10);
        float float10 = categoryPlot4.getBackgroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot4.getRangeAxisLocation();
        boolean boolean12 = layer0.equals((java.lang.Object) categoryPlot4);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        categoryPlot13.setDomainAxis((int) 'a', categoryAxis15);
        categoryPlot13.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        categoryPlot13.setDataset(0, categoryDataset19);
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot13.setNoDataMessagePaint(paint21);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot13.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent25 = null;
        categoryPlot13.rendererChanged(rendererChangeEvent25);
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection29 = categoryPlot13.getRangeMarkers((int) (byte) -1, layer28);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj32 = null;
        boolean boolean33 = categoryAxis31.equals(obj32);
        categoryAxis31.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis31.clearCategoryLabelToolTips();
        categoryAxis31.setTickLabelsVisible(false);
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        categoryPlot41.setDomainAxis((int) 'a', categoryAxis43);
        categoryPlot41.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset47 = null;
        categoryPlot41.setDataset(0, categoryDataset47);
        java.awt.Paint paint49 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot41.setNoDataMessagePaint(paint49);
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = categoryPlot41.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent53 = null;
        categoryPlot41.rendererChanged(rendererChangeEvent53);
        org.jfree.chart.util.Layer layer56 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection57 = categoryPlot41.getRangeMarkers((int) (byte) -1, layer56);
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = null;
        org.jfree.chart.axis.AxisSpace axisSpace60 = null;
        org.jfree.chart.axis.AxisSpace axisSpace61 = categoryAxis31.reserveSpace(graphics2D40, (org.jfree.chart.plot.Plot) categoryPlot41, rectangle2D58, rectangleEdge59, axisSpace60);
        categoryPlot13.setFixedRangeAxisSpace(axisSpace61, false);
        categoryPlot4.setFixedDomainAxisSpace(axisSpace61, false);
        org.junit.Assert.assertNotNull(layer0);
        org.junit.Assert.assertNotNull(dateRange1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Layer.FOREGROUND" + "'", str3.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertNull(collection29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertNotNull(layer56);
        org.junit.Assert.assertNull(collection57);
        org.junit.Assert.assertNotNull(axisSpace61);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryAxis1.equals(obj2);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(false);
        boolean boolean11 = categoryAxis1.equals((java.lang.Object) 1.0d);
        int int12 = categoryAxis1.getCategoryLabelPositionOffset();
        double double13 = categoryAxis1.getCategoryMargin();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.2d + "'", double13 == 0.2d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis0.setRangeWithMargins(range10, true, true);
        java.text.NumberFormat numberFormat14 = numberAxis0.getNumberFormatOverride();
        java.lang.String str15 = numberAxis0.getLabelURL();
        numberAxis0.centerRange(0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        numberAxis18.setAutoRangeMinimumSize((double) 11, false);
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color23, stroke24);
        numberAxis18.setLabelPaint((java.awt.Paint) color23);
        numberAxis18.setPositiveArrowVisible(true);
        org.jfree.chart.plot.Plot plot29 = numberAxis18.getPlot();
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        double double34 = numberAxis30.valueToJava2D((double) 10, rectangle2D32, rectangleEdge33);
        org.jfree.data.Range range35 = numberAxis30.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = null;
        double double40 = numberAxis36.valueToJava2D((double) 10, rectangle2D38, rectangleEdge39);
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = numberAxis41.valueToJava2D((double) 10, rectangle2D43, rectangleEdge44);
        org.jfree.data.Range range46 = numberAxis41.getDefaultAutoRange();
        numberAxis36.setRange(range46);
        numberAxis30.setDefaultAutoRange(range46);
        java.awt.Shape shape49 = numberAxis30.getDownArrow();
        numberAxis18.setDownArrow(shape49);
        numberAxis0.setUpArrow(shape49);
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = new org.jfree.chart.util.RectangleInsets((double) (byte) 10, (double) 0.0f, (double) (byte) 1, (-1.0d));
        numberAxis0.setTickLabelInsets(rectangleInsets56);
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = null;
        double double62 = numberAxis58.valueToJava2D((double) 10, rectangle2D60, rectangleEdge61);
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj65 = null;
        boolean boolean66 = categoryAxis64.equals(obj65);
        categoryAxis64.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis64.clearCategoryLabelToolTips();
        categoryAxis64.setTickLabelsVisible(false);
        boolean boolean74 = categoryAxis64.equals((java.lang.Object) 1.0d);
        int int75 = categoryAxis64.getCategoryLabelPositionOffset();
        categoryAxis64.setLowerMargin((double) 10);
        org.jfree.chart.axis.NumberAxis numberAxis78 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D80 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge81 = null;
        double double82 = numberAxis78.valueToJava2D((double) 10, rectangle2D80, rectangleEdge81);
        org.jfree.data.Range range83 = numberAxis78.getDefaultAutoRange();
        java.awt.Font font84 = numberAxis78.getTickLabelFont();
        categoryAxis64.setTickLabelFont(font84);
        numberAxis58.setTickLabelFont(font84);
        numberAxis0.setTickLabelFont(font84);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNull(numberFormat14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(plot29);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 4 + "'", int75 == 4);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertNotNull(range83);
        org.junit.Assert.assertNotNull(font84);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis5.zoomRange((double) 0L, (double) 3);
        boolean boolean14 = numberAxis5.isNegativeArrowVisible();
        xYPlot0.setDomainAxis(255, (org.jfree.chart.axis.ValueAxis) numberAxis5, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        categoryPlot17.setDomainAxis((int) 'a', categoryAxis19);
        categoryPlot17.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        categoryPlot17.setDataset(0, categoryDataset23);
        java.awt.Paint paint25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot17.setNoDataMessagePaint(paint25);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot17.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent29 = null;
        categoryPlot17.rendererChanged(rendererChangeEvent29);
        org.jfree.chart.util.Layer layer32 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection33 = categoryPlot17.getRangeMarkers((int) (byte) -1, layer32);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj36 = null;
        boolean boolean37 = categoryAxis35.equals(obj36);
        categoryAxis35.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis35.clearCategoryLabelToolTips();
        categoryAxis35.setTickLabelsVisible(false);
        java.awt.Graphics2D graphics2D44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = null;
        categoryPlot45.setDomainAxis((int) 'a', categoryAxis47);
        categoryPlot45.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset51 = null;
        categoryPlot45.setDataset(0, categoryDataset51);
        java.awt.Paint paint53 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot45.setNoDataMessagePaint(paint53);
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = categoryPlot45.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent57 = null;
        categoryPlot45.rendererChanged(rendererChangeEvent57);
        org.jfree.chart.util.Layer layer60 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection61 = categoryPlot45.getRangeMarkers((int) (byte) -1, layer60);
        java.awt.geom.Rectangle2D rectangle2D62 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = null;
        org.jfree.chart.axis.AxisSpace axisSpace64 = null;
        org.jfree.chart.axis.AxisSpace axisSpace65 = categoryAxis35.reserveSpace(graphics2D44, (org.jfree.chart.plot.Plot) categoryPlot45, rectangle2D62, rectangleEdge63, axisSpace64);
        categoryPlot17.setFixedRangeAxisSpace(axisSpace65, false);
        xYPlot0.setFixedRangeAxisSpace(axisSpace65);
        org.jfree.chart.plot.XYPlot xYPlot69 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation71 = null;
        xYPlot69.setRangeAxisLocation((int) (short) 100, axisLocation71);
        org.jfree.chart.axis.NumberAxis numberAxis74 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D76 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge77 = null;
        double double78 = numberAxis74.valueToJava2D((double) 10, rectangle2D76, rectangleEdge77);
        org.jfree.data.Range range79 = numberAxis74.getDefaultAutoRange();
        numberAxis74.zoomRange((double) 0L, (double) 3);
        boolean boolean83 = numberAxis74.isNegativeArrowVisible();
        xYPlot69.setDomainAxis(255, (org.jfree.chart.axis.ValueAxis) numberAxis74, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder86 = xYPlot69.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation88 = xYPlot69.getRangeAxisLocation(0);
        java.awt.Stroke stroke89 = xYPlot69.getRangeCrosshairStroke();
        xYPlot0.setDomainCrosshairStroke(stroke89);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNotNull(layer32);
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(rectangleEdge56);
        org.junit.Assert.assertNotNull(layer60);
        org.junit.Assert.assertNull(collection61);
        org.junit.Assert.assertNotNull(axisSpace65);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertNotNull(range79);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder86);
        org.junit.Assert.assertNotNull(axisLocation88);
        org.junit.Assert.assertNotNull(stroke89);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        java.awt.Paint paint10 = categoryPlot0.getOutlinePaint();
        int int11 = categoryPlot0.getDomainAxisCount();
        java.lang.Class<?> wildcardClass12 = categoryPlot0.getClass();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        categoryPlot14.setDomainAxis((int) 'a', categoryAxis16);
        categoryPlot14.clearAnnotations();
        boolean boolean19 = categoryPlot14.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace20 = categoryPlot14.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot14.setInsets(rectangleInsets21);
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation23, plotOrientation24);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor26 = org.jfree.chart.axis.CategoryAnchor.END;
        boolean boolean27 = axisLocation23.equals((java.lang.Object) categoryAnchor26);
        categoryPlot14.setRangeAxisLocation(axisLocation23, false);
        categoryPlot0.setRangeAxisLocation((int) (short) 10, axisLocation23, false);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis();
        numberAxis33.setAutoRangeMinimumSize((double) 11, false);
        numberAxis33.setAutoRangeStickyZero(true);
        double double39 = numberAxis33.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = null;
        double double44 = numberAxis40.valueToJava2D((double) 10, rectangle2D42, rectangleEdge43);
        org.jfree.data.Range range45 = numberAxis40.getDefaultAutoRange();
        numberAxis33.setRange(range45, true, true);
        java.awt.Color color49 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis33.setTickMarkPaint((java.awt.Paint) color49);
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = null;
        double double55 = numberAxis51.valueToJava2D((double) 10, rectangle2D53, rectangleEdge54);
        org.jfree.chart.axis.NumberAxis numberAxis56 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = null;
        double double60 = numberAxis56.valueToJava2D((double) 10, rectangle2D58, rectangleEdge59);
        org.jfree.data.Range range61 = numberAxis56.getDefaultAutoRange();
        numberAxis51.setRange(range61);
        boolean boolean63 = color49.equals((java.lang.Object) numberAxis51);
        numberAxis51.setNegativeArrowVisible(true);
        categoryPlot0.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis51, false);
        numberAxis51.setAutoTickUnitSelection(false, true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 98 + "'", int11 == 98);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(axisSpace20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(plotOrientation24);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertNotNull(categoryAnchor26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(range61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundAlpha((float) 4);
        java.awt.Color color3 = java.awt.Color.RED;
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = null;
        org.jfree.chart.util.Layer layer6 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker5, layer6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        int int2 = xYPlot0.getSeriesCount();
        xYPlot0.setNoDataMessage("PlotOrientation.HORIZONTAL");
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = numberAxis11.valueToJava2D((double) 10, rectangle2D13, rectangleEdge14);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = numberAxis16.valueToJava2D((double) 10, rectangle2D18, rectangleEdge19);
        org.jfree.data.Range range21 = numberAxis16.getDefaultAutoRange();
        numberAxis11.setRange(range21);
        numberAxis5.setDefaultAutoRange(range21);
        org.jfree.chart.axis.TickUnitSource tickUnitSource24 = null;
        numberAxis5.setStandardTickUnits(tickUnitSource24);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        double double30 = numberAxis26.valueToJava2D((double) 10, rectangle2D28, rectangleEdge29);
        org.jfree.data.Range range31 = numberAxis26.getDefaultAutoRange();
        numberAxis5.setRangeWithMargins(range31);
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.JFreeChart jFreeChart34 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent35 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis33, jFreeChart34);
        org.jfree.data.time.DateRange dateRange36 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis33.setRange((org.jfree.data.Range) dateRange36);
        dateAxis33.setRange((double) 7, (double) 100);
        dateAxis33.setRangeAboutValue((double) 1, (double) 10);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray44 = new org.jfree.chart.axis.ValueAxis[] { numberAxis5, dateAxis33 };
        xYPlot0.setRangeAxes(valueAxisArray44);
        java.awt.Paint paint46 = xYPlot0.getRangeZeroBaselinePaint();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(dateRange36);
        org.junit.Assert.assertNotNull(valueAxisArray44);
        org.junit.Assert.assertNotNull(paint46);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.data.Range range5 = numberAxis0.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis6.valueToJava2D((double) 10, rectangle2D8, rectangleEdge9);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = numberAxis11.valueToJava2D((double) 10, rectangle2D13, rectangleEdge14);
        org.jfree.data.Range range16 = numberAxis11.getDefaultAutoRange();
        numberAxis6.setRange(range16);
        numberAxis0.setDefaultAutoRange(range16);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = null;
        numberAxis0.setStandardTickUnits(tickUnitSource19);
        org.jfree.data.RangeType rangeType21 = numberAxis0.getRangeType();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(rangeType21);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis0.setRange(range10);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis0.getTickUnit();
        double double13 = numberAxis0.getLabelAngle();
        double double14 = numberAxis0.getLowerBound();
        java.awt.Font font15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        numberAxis0.setLabelFont(font15);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        double double5 = rectangleInsets4.getTop();
        double double7 = rectangleInsets4.calculateLeftInset(62.0d);
        double double8 = rectangleInsets4.getLeft();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 52.0d + "'", double5 == 52.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 32.0d + "'", double7 == 32.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 32.0d + "'", double8 == 32.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color2, stroke3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker4.setOutlineStroke(stroke5);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker4.setLabelOffsetType(lengthAdjustmentType7);
        boolean boolean9 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker4);
        xYPlot0.setRangeCrosshairVisible(false);
        boolean boolean12 = xYPlot0.isDomainZoomable();
        java.awt.Stroke stroke13 = null;
        try {
            xYPlot0.setDomainGridlineStroke(stroke13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis0, jFreeChart1);
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange3);
        dateAxis0.setRange((double) 7, (double) 100);
        java.text.DateFormat dateFormat8 = dateAxis0.getDateFormatOverride();
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNull(dateFormat8);
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        long long3 = day2.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day2.next();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        long long3 = day2.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
//        categoryPlot5.setDomainAxis((int) 'a', categoryAxis7);
//        categoryPlot5.setBackgroundImageAlignment((int) (short) 10);
//        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot5.getDatasetGroup();
//        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
//        categoryPlot5.setNoDataMessagePaint(paint12);
//        boolean boolean14 = day2.equals((java.lang.Object) categoryPlot5);
//        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D17 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
//        double double19 = numberAxis15.valueToJava2D((double) 10, rectangle2D17, rectangleEdge18);
//        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D22 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
//        double double24 = numberAxis20.valueToJava2D((double) 10, rectangle2D22, rectangleEdge23);
//        org.jfree.data.Range range25 = numberAxis20.getDefaultAutoRange();
//        numberAxis15.setRange(range25);
//        int int27 = categoryPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis15);
//        numberAxis15.configure();
//        java.awt.Shape shape29 = numberAxis15.getRightArrow();
//        java.awt.Paint paint30 = numberAxis15.getAxisLinePaint();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNull(datasetGroup11);
//        org.junit.Assert.assertNotNull(paint12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
//        org.junit.Assert.assertNotNull(range25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//        org.junit.Assert.assertNotNull(shape29);
//        org.junit.Assert.assertNotNull(paint30);
//    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        java.awt.Color color1 = java.awt.Color.getColor("");
        org.junit.Assert.assertNull(color1);
    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test030");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        long long3 = day2.getFirstMillisecond();
//        int int4 = day2.getDayOfMonth();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeMinimumSize((double) 11, false);
        numberAxis0.setAutoRangeStickyZero(true);
        double double6 = numberAxis0.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = numberAxis7.valueToJava2D((double) 10, rectangle2D9, rectangleEdge10);
        org.jfree.data.Range range12 = numberAxis7.getDefaultAutoRange();
        numberAxis0.setRange(range12, true, true);
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis0.setTickMarkPaint((java.awt.Paint) color16);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot18.setDomainAxis((int) 'a', categoryAxis20);
        categoryPlot18.clearAnnotations();
        boolean boolean23 = categoryPlot18.isOutlineVisible();
        numberAxis0.setPlot((org.jfree.chart.plot.Plot) categoryPlot18);
        categoryPlot18.configureDomainAxes();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        xYPlot0.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis5.getTickMarkPaint();
        xYPlot0.setDomainTickBandPaint(paint10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color15, stroke16);
        boolean boolean18 = axisLocation13.equals((java.lang.Object) valueMarker17);
        float float19 = valueMarker17.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = valueMarker17.getLabelAnchor();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean23 = layer21.equals((java.lang.Object) dateRange22);
        java.lang.String str24 = layer21.toString();
        xYPlot0.addDomainMarker((int) (short) 100, (org.jfree.chart.plot.Marker) valueMarker17, layer21);
        org.jfree.chart.axis.ValueAxis valueAxis27 = xYPlot0.getDomainAxis(2019);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Layer.FOREGROUND" + "'", str24.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(valueAxis27);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        long long3 = day2.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate5);
//        java.util.Calendar calendar8 = null;
//        try {
//            day7.peg(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate5);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryAxis1.equals(obj2);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(false);
        boolean boolean11 = categoryAxis1.equals((java.lang.Object) 1.0d);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions12 = categoryAxis1.getCategoryLabelPositions();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions12);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color1, stroke2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = valueMarker3.getLabelAnchor();
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color6, stroke7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker8.setOutlineStroke(stroke9);
        java.awt.Stroke stroke11 = valueMarker8.getOutlineStroke();
        valueMarker3.setStroke(stroke11);
        java.awt.Stroke stroke13 = valueMarker3.getOutlineStroke();
        float float14 = valueMarker3.getAlpha();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis0, jFreeChart1);
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange3);
        dateAxis0.setRange((double) 7, (double) 100);
        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date9, timeZone10);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("AxisLocation.BOTTOM_OR_LEFT", timeZone10);
        java.util.Date date14 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("AxisLocation.BOTTOM_OR_LEFT", timeZone15);
        dateAxis12.setTimeZone(timeZone15);
        org.jfree.chart.axis.Timeline timeline19 = dateAxis12.getTimeline();
        dateAxis0.setTimeline(timeline19);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.JFreeChart jFreeChart22 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis21, jFreeChart22);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color26, stroke27);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker28.setOutlineStroke(stroke29);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType31 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker28.setLabelOffsetType(lengthAdjustmentType31);
        boolean boolean33 = xYPlot24.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker28);
        org.jfree.chart.LegendItemCollection legendItemCollection34 = xYPlot24.getFixedLegendItems();
        boolean boolean35 = dateAxis21.hasListener((java.util.EventListener) xYPlot24);
        dateAxis21.setUpperBound(1.0d);
        org.jfree.data.Range range38 = dateAxis21.getDefaultAutoRange();
        dateAxis0.setRange(range38);
        java.util.Date date40 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date40, timeZone41);
        java.util.Date date43 = day42.getEnd();
        java.util.Date date44 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date44, timeZone45);
        java.util.Date date47 = day46.getEnd();
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date47);
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date47);
        java.util.Date date51 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date51, timeZone52);
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis("AxisLocation.BOTTOM_OR_LEFT", timeZone52);
        java.util.Date date56 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date56, timeZone57);
        org.jfree.chart.axis.DateAxis dateAxis59 = new org.jfree.chart.axis.DateAxis("AxisLocation.BOTTOM_OR_LEFT", timeZone57);
        dateAxis54.setTimeZone(timeZone57);
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date47, timeZone57);
        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(date43, timeZone57);
        org.jfree.chart.plot.CategoryPlot categoryPlot63 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis65 = null;
        categoryPlot63.setDomainAxis((int) 'a', categoryAxis65);
        categoryPlot63.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset69 = null;
        categoryPlot63.setDataset(0, categoryDataset69);
        java.awt.Paint paint71 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot63.setNoDataMessagePaint(paint71);
        org.jfree.chart.util.RectangleEdge rectangleEdge74 = categoryPlot63.getDomainAxisEdge((int) (byte) 10);
        java.lang.Class<?> wildcardClass75 = rectangleEdge74.getClass();
        java.util.Date date76 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone77 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day(date76, timeZone77);
        java.util.Date date79 = day78.getEnd();
        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day(date79);
        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day(date79);
        java.util.Date date83 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone84 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day85 = new org.jfree.data.time.Day(date83, timeZone84);
        org.jfree.chart.axis.DateAxis dateAxis86 = new org.jfree.chart.axis.DateAxis("AxisLocation.BOTTOM_OR_LEFT", timeZone84);
        java.util.Date date88 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day90 = new org.jfree.data.time.Day(date88, timeZone89);
        org.jfree.chart.axis.DateAxis dateAxis91 = new org.jfree.chart.axis.DateAxis("AxisLocation.BOTTOM_OR_LEFT", timeZone89);
        dateAxis86.setTimeZone(timeZone89);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod93 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass75, date79, timeZone89);
        try {
            dateAxis0.setRange(date43, date79);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(timeline19);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(lengthAdjustmentType31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(legendItemCollection34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeZone52);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertNotNull(paint71);
        org.junit.Assert.assertNotNull(rectangleEdge74);
        org.junit.Assert.assertNotNull(wildcardClass75);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertNotNull(timeZone77);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertNotNull(date83);
        org.junit.Assert.assertNotNull(timeZone84);
        org.junit.Assert.assertNotNull(date88);
        org.junit.Assert.assertNotNull(timeZone89);
        org.junit.Assert.assertNull(regularTimePeriod93);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        categoryPlot0.setRenderer(6, categoryItemRenderer7, false);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace10);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double7 = rectangleInsets5.calculateRightInset(11.0d);
        categoryPlot0.setInsets(rectangleInsets5);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot11.setDomainAxis((int) 'a', categoryAxis13);
        categoryPlot11.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color18 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color18, stroke19);
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker20.setOutlineStroke(stroke21);
        java.awt.Stroke stroke23 = valueMarker20.getOutlineStroke();
        boolean boolean24 = categoryPlot11.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker20);
        org.jfree.chart.plot.PlotOrientation plotOrientation25 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot11.setOrientation(plotOrientation25);
        org.jfree.chart.plot.PlotOrientation plotOrientation27 = categoryPlot11.getOrientation();
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
        double double32 = numberAxis28.valueToJava2D((double) 10, rectangle2D30, rectangleEdge31);
        java.awt.Paint paint33 = numberAxis28.getTickMarkPaint();
        boolean boolean34 = plotOrientation27.equals((java.lang.Object) paint33);
        categoryPlot0.setOrientation(plotOrientation27);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(plotOrientation25);
        org.junit.Assert.assertNotNull(plotOrientation27);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        numberAxis2.setAutoRangeMinimumSize((double) 11, false);
        numberAxis2.setAutoRangeStickyZero(true);
        boolean boolean8 = numberAxis2.isTickLabelsVisible();
        numberAxis2.setAutoRange(false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis2, xYItemRenderer11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        int int17 = xYPlot16.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = xYPlot16.getRangeAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        categoryPlot19.setDomainAxis((int) 'a', categoryAxis21);
        categoryPlot19.clearAnnotations();
        boolean boolean24 = categoryPlot19.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace25 = categoryPlot19.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot19.setInsets(rectangleInsets26);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot19.getDomainAxisEdge((int) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis();
        numberAxis31.setAutoRangeMinimumSize((double) 11, false);
        numberAxis31.setAutoRangeStickyZero(true);
        double double37 = numberAxis31.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        double double42 = numberAxis38.valueToJava2D((double) 10, rectangle2D40, rectangleEdge41);
        org.jfree.data.Range range43 = numberAxis38.getDefaultAutoRange();
        numberAxis31.setRange(range43, true, true);
        java.awt.Color color47 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis31.setTickMarkPaint((java.awt.Paint) color47);
        categoryPlot19.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis31);
        categoryPlot19.clearRangeMarkers();
        java.awt.Color color52 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke53 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker54 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color52, stroke53);
        java.awt.Stroke stroke55 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker54.setOutlineStroke(stroke55);
        java.awt.Stroke stroke57 = valueMarker54.getStroke();
        categoryPlot19.setDomainGridlineStroke(stroke57);
        xYPlot16.setRangeGridlineStroke(stroke57);
        org.jfree.chart.axis.NumberAxis numberAxis61 = new org.jfree.chart.axis.NumberAxis();
        numberAxis61.setAutoRangeMinimumSize((double) 11, false);
        numberAxis61.setAutoRangeStickyZero(true);
        double double67 = numberAxis61.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis68 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = null;
        double double72 = numberAxis68.valueToJava2D((double) 10, rectangle2D70, rectangleEdge71);
        org.jfree.data.Range range73 = numberAxis68.getDefaultAutoRange();
        numberAxis61.setRange(range73, true, true);
        xYPlot16.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis61);
        org.jfree.chart.plot.CategoryPlot categoryPlot78 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis80 = null;
        categoryPlot78.setDomainAxis((int) 'a', categoryAxis80);
        categoryPlot78.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset84 = null;
        categoryPlot78.setDataset(0, categoryDataset84);
        float float86 = categoryPlot78.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets87 = categoryPlot78.getAxisOffset();
        java.awt.Color color88 = java.awt.Color.red;
        categoryPlot78.setRangeGridlinePaint((java.awt.Paint) color88);
        xYPlot16.setDomainCrosshairPaint((java.awt.Paint) color88);
        java.awt.geom.Point2D point2D91 = xYPlot16.getQuadrantOrigin();
        try {
            xYPlot12.zoomRangeAxes((double) 2019, 55.0d, plotRenderingInfo15, point2D91);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (2019.0) <= upper (55.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(axisSpace25);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(range73);
        org.junit.Assert.assertTrue("'" + float86 + "' != '" + 1.0f + "'", float86 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets87);
        org.junit.Assert.assertNotNull(color88);
        org.junit.Assert.assertNotNull(point2D91);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        int int2 = xYPlot0.getSeriesCount();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        int int4 = xYPlot0.getIndexOf(xYItemRenderer3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        xYPlot0.zoomDomainAxes(0.0d, 1.0d, plotRenderingInfo5, point2D6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot9.setDomainAxis((int) 'a', categoryAxis11);
        categoryPlot9.clearAnnotations();
        boolean boolean14 = categoryPlot9.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace15 = categoryPlot9.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot9.setInsets(rectangleInsets16);
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation18, plotOrientation19);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor21 = org.jfree.chart.axis.CategoryAnchor.END;
        boolean boolean22 = axisLocation18.equals((java.lang.Object) categoryAnchor21);
        categoryPlot9.setRangeAxisLocation(axisLocation18, false);
        xYPlot0.setRangeAxisLocation(12, axisLocation18, false);
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(axisSpace15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(plotOrientation19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(categoryAnchor21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = numberAxis1.valueToJava2D((double) 10, rectangle2D3, rectangleEdge4);
        java.awt.Paint paint6 = numberAxis1.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis7, xYItemRenderer8);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        double double16 = rectangleInsets14.calculateLeftInset((double) (-1));
        double double17 = rectangleInsets14.getBottom();
        double double19 = rectangleInsets14.extendHeight(3.0d);
        xYPlot9.setInsets(rectangleInsets14, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        int int23 = xYPlot9.getIndexOf(xYItemRenderer22);
        java.awt.Color color25 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Color color26 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT", color25);
        xYPlot9.setRangeCrosshairPaint((java.awt.Paint) color25);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 32.0d + "'", double16 == 32.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 55.0d + "'", double19 == 55.0d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        xYPlot0.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis5.getTickMarkPaint();
        xYPlot0.setDomainTickBandPaint(paint10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color15, stroke16);
        boolean boolean18 = axisLocation13.equals((java.lang.Object) valueMarker17);
        float float19 = valueMarker17.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = valueMarker17.getLabelAnchor();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean23 = layer21.equals((java.lang.Object) dateRange22);
        java.lang.String str24 = layer21.toString();
        xYPlot0.addDomainMarker((int) (short) 100, (org.jfree.chart.plot.Marker) valueMarker17, layer21);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        numberAxis26.setAutoRangeMinimumSize((double) 11, false);
        numberAxis26.setAutoRangeStickyZero(true);
        double double32 = numberAxis26.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        double double37 = numberAxis33.valueToJava2D((double) 10, rectangle2D35, rectangleEdge36);
        org.jfree.data.Range range38 = numberAxis33.getDefaultAutoRange();
        numberAxis26.setRange(range38, true, true);
        java.awt.Color color42 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis26.setTickMarkPaint((java.awt.Paint) color42);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = null;
        double double48 = numberAxis44.valueToJava2D((double) 10, rectangle2D46, rectangleEdge47);
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = null;
        double double53 = numberAxis49.valueToJava2D((double) 10, rectangle2D51, rectangleEdge52);
        org.jfree.data.Range range54 = numberAxis49.getDefaultAutoRange();
        numberAxis44.setRange(range54);
        boolean boolean56 = color42.equals((java.lang.Object) numberAxis44);
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color42);
        org.jfree.chart.plot.Plot plot58 = xYPlot0.getRootPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder59 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.ValueAxis valueAxis60 = xYPlot0.getRangeAxis();
        java.lang.Object obj61 = xYPlot0.clone();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Layer.FOREGROUND" + "'", str24.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(plot58);
        org.junit.Assert.assertNotNull(seriesRenderingOrder59);
        org.junit.Assert.assertNull(valueAxis60);
        org.junit.Assert.assertNotNull(obj61);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.jfree.chart.util.UnitType unitType1 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(unitType1, (double) 128, (double) 100.0f, (double) 6, (double) 10L);
        double double8 = rectangleInsets6.calculateLeftOutset((double) 1L);
        boolean boolean9 = rectangleAnchor0.equals((java.lang.Object) rectangleInsets6);
        double double11 = rectangleInsets6.calculateTopOutset((double) 13);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 128.0d + "'", double11 == 128.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        float float6 = categoryPlot0.getBackgroundAlpha();
        java.lang.String str7 = categoryPlot0.getPlotType();
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot0.getRangeAxis((int) (byte) -1);
        java.lang.String str10 = categoryPlot0.getPlotType();
        java.awt.Stroke stroke11 = categoryPlot0.getDomainGridlineStroke();
        java.awt.Color color12 = java.awt.Color.gray;
        int int13 = color12.getBlue();
        float[] floatArray14 = null;
        float[] floatArray15 = color12.getComponents(floatArray14);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color12);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Category Plot" + "'", str7.equals("Category Plot"));
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Category Plot" + "'", str10.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 128 + "'", int13 == 128);
        org.junit.Assert.assertNotNull(floatArray15);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color2, stroke3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker4.setOutlineStroke(stroke5);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker4.setLabelOffsetType(lengthAdjustmentType7);
        boolean boolean9 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker4);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = xYPlot0.getFixedLegendItems();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot11.setDomainAxis((int) 'a', categoryAxis13);
        categoryPlot11.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        categoryPlot11.setDataset(0, categoryDataset17);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot11.setNoDataMessagePaint(paint19);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot11.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        categoryPlot11.rendererChanged(rendererChangeEvent23);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection27 = categoryPlot11.getRangeMarkers((int) (byte) -1, layer26);
        java.util.Collection collection28 = xYPlot0.getRangeMarkers(layer26);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset30);
        xYPlot0.configureRangeAxes();
        xYPlot0.clearDomainMarkers();
        double double34 = xYPlot0.getDomainCrosshairValue();
        java.awt.Paint paint35 = xYPlot0.getRangeCrosshairPaint();
        org.jfree.chart.axis.AxisSpace axisSpace36 = xYPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNull(axisSpace36);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        xYPlot0.clearAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        int int6 = xYPlot5.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot5.zoomRangeAxes((double) 255, plotRenderingInfo8, point2D9, true);
        boolean boolean12 = xYPlot5.isDomainCrosshairVisible();
        boolean boolean13 = xYPlot5.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = numberAxis14.valueToJava2D((double) 10, rectangle2D16, rectangleEdge17);
        org.jfree.data.Range range19 = numberAxis14.getDefaultAutoRange();
        numberAxis14.zoomRange((double) 0L, (double) 3);
        int int23 = xYPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        java.awt.Paint paint24 = xYPlot5.getRangeZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation27 = null;
        xYPlot25.setRangeAxisLocation((int) (short) 100, axisLocation27);
        xYPlot25.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        double double34 = numberAxis30.valueToJava2D((double) 10, rectangle2D32, rectangleEdge33);
        java.awt.Paint paint35 = numberAxis30.getTickMarkPaint();
        xYPlot25.setDomainTickBandPaint(paint35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color40 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke41 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker42 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color40, stroke41);
        boolean boolean43 = axisLocation38.equals((java.lang.Object) valueMarker42);
        float float44 = valueMarker42.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = valueMarker42.getLabelAnchor();
        org.jfree.chart.util.Layer layer46 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange47 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean48 = layer46.equals((java.lang.Object) dateRange47);
        java.lang.String str49 = layer46.toString();
        xYPlot25.addDomainMarker((int) (short) 100, (org.jfree.chart.plot.Marker) valueMarker42, layer46);
        java.awt.Font font51 = valueMarker42.getLabelFont();
        xYPlot5.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker42);
        java.awt.Paint paint53 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        valueMarker42.setLabelPaint(paint53);
        xYPlot0.setDomainTickBandPaint(paint53);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 1.0f + "'", float44 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertNotNull(layer46);
        org.junit.Assert.assertNotNull(dateRange47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "Layer.FOREGROUND" + "'", str49.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(paint53);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        categoryPlot1.setDomainAxis((int) 'a', categoryAxis3);
        categoryPlot1.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        categoryPlot1.setDataset(0, categoryDataset7);
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot1.setNoDataMessagePaint(paint9);
        java.awt.Paint paint11 = categoryPlot1.getOutlinePaint();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = color12.createContext(colorModel13, rectangle14, rectangle2D15, affineTransform16, renderingHints17);
        java.awt.Paint[] paintArray19 = new java.awt.Paint[] { color0, paint11, color12 };
        java.awt.Paint[] paintArray20 = null;
        java.awt.Paint[] paintArray21 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray22 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray23 = null;
        java.awt.Shape[] shapeArray24 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier25 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray19, paintArray20, paintArray21, strokeArray22, strokeArray23, shapeArray24);
        java.lang.Object obj26 = defaultDrawingSupplier25.clone();
        java.awt.Stroke stroke27 = defaultDrawingSupplier25.getNextStroke();
        try {
            java.awt.Paint paint28 = defaultDrawingSupplier25.getNextFillPaint();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNotNull(paintArray19);
        org.junit.Assert.assertNotNull(paintArray21);
        org.junit.Assert.assertNotNull(strokeArray22);
        org.junit.Assert.assertNotNull(shapeArray24);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        categoryPlot1.setDomainAxis((int) 'a', categoryAxis3);
        categoryPlot1.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.data.general.DatasetGroup datasetGroup7 = categoryPlot1.getDatasetGroup();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot1.getRenderer();
        boolean boolean9 = rectangleInsets0.equals((java.lang.Object) categoryPlot1);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = null;
        org.jfree.chart.util.Layer layer11 = null;
        try {
            categoryPlot1.addDomainMarker(categoryMarker10, layer11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNull(datasetGroup7);
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.data.Range range5 = numberAxis0.getDefaultAutoRange();
        java.awt.Font font6 = numberAxis0.getTickLabelFont();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        numberAxis0.setTickMarkPaint((java.awt.Paint) color7);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot0.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot0.setRenderer(categoryItemRenderer14, true);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = numberAxis18.valueToJava2D((double) 10, rectangle2D20, rectangleEdge21);
        org.jfree.data.Range range23 = numberAxis18.getDefaultAutoRange();
        numberAxis18.zoomRange((double) 0L, (double) 3);
        java.lang.String str27 = numberAxis18.getLabel();
        categoryPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis18, false);
        categoryPlot0.setRangeCrosshairValue((double) 4, false);
        categoryPlot0.mapDatasetToRangeAxis(0, 13);
        categoryPlot0.clearDomainAxes();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNull(str27);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        xYPlot0.setRangeAxisLocation(4, axisLocation8);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = numberAxis11.valueToJava2D((double) 10, rectangle2D13, rectangleEdge14);
        boolean boolean16 = numberAxis11.getAutoRangeStickyZero();
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis11);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = xYPlot0.getAxisOffset();
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        try {
            xYPlot0.drawBackground(graphics2D19, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(rectangleInsets18);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        java.awt.Paint paint10 = categoryPlot0.getOutlinePaint();
        float float11 = categoryPlot0.getBackgroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation13 = null;
        categoryPlot0.setDomainAxisLocation(500, axisLocation13, false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker9.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = valueMarker9.getOutlineStroke();
        boolean boolean13 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        java.awt.Paint paint14 = categoryPlot0.getBackgroundPaint();
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        try {
            categoryPlot0.drawBackground(graphics2D15, rectangle2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj2 = objectList0.get((int) (short) 0);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker3.setOutlineStroke(stroke4);
        java.awt.Paint paint6 = valueMarker3.getOutlinePaint();
        java.lang.String str7 = valueMarker3.getLabel();
        valueMarker3.setAlpha(0.0f);
        valueMarker3.setValue((double) 1.0f);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        boolean boolean13 = valueMarker3.equals((java.lang.Object) rectangleInsets12);
        java.lang.Object obj14 = valueMarker3.clone();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        boolean boolean5 = numberAxis0.getAutoRangeStickyZero();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        categoryPlot6.setDataset(categoryDataset7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        categoryPlot6.removeChangeListener(plotChangeListener9);
        numberAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        java.awt.Font font12 = categoryPlot6.getNoDataMessageFont();
        java.awt.Paint paint13 = categoryPlot6.getNoDataMessagePaint();
        double double14 = categoryPlot6.getAnchorValue();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker9.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = valueMarker9.getOutlineStroke();
        boolean boolean13 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot0.setOrientation(plotOrientation14);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        categoryPlot16.setDomainAxis((int) 'a', categoryAxis18);
        categoryPlot16.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.data.general.DatasetGroup datasetGroup22 = categoryPlot16.getDatasetGroup();
        java.awt.Paint paint23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        categoryPlot16.setNoDataMessagePaint(paint23);
        categoryPlot0.setRangeGridlinePaint(paint23);
        int int26 = categoryPlot0.getWeight();
        org.jfree.chart.util.SortOrder sortOrder27 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setRowRenderingOrder(sortOrder27);
        double double29 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        categoryPlot0.setDomainAxis((int) (short) 100, categoryAxis31, true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNull(datasetGroup22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(sortOrder27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis0, jFreeChart1);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = chartChangeEvent2.getType();
        org.junit.Assert.assertNotNull(chartChangeEventType3);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        xYPlot0.setRangeAxisLocation(4, axisLocation8);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = xYPlot0.getSeriesRenderingOrder();
        java.util.List list11 = xYPlot0.getAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation13 = xYPlot0.getDomainAxisLocation(7);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertNotNull(list11);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberAxis0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color2, stroke3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker4.setOutlineStroke(stroke5);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker4.setLabelOffsetType(lengthAdjustmentType7);
        boolean boolean9 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker4);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = xYPlot0.getFixedLegendItems();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot11.setDomainAxis((int) 'a', categoryAxis13);
        categoryPlot11.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        categoryPlot11.setDataset(0, categoryDataset17);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot11.setNoDataMessagePaint(paint19);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot11.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        categoryPlot11.rendererChanged(rendererChangeEvent23);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection27 = categoryPlot11.getRangeMarkers((int) (byte) -1, layer26);
        java.util.Collection collection28 = xYPlot0.getRangeMarkers(layer26);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset30);
        xYPlot0.configureRangeAxes();
        xYPlot0.clearDomainMarkers();
        double double34 = xYPlot0.getDomainCrosshairValue();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        categoryPlot35.setDomainAxis((int) 'a', categoryAxis37);
        categoryPlot35.clearAnnotations();
        boolean boolean40 = categoryPlot35.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace41 = categoryPlot35.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot35.setInsets(rectangleInsets42);
        categoryPlot35.setWeight((int) (short) 1);
        double double46 = categoryPlot35.getRangeCrosshairValue();
        java.awt.Paint paint47 = categoryPlot35.getOutlinePaint();
        xYPlot0.setRangeGridlinePaint(paint47);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNull(axisSpace41);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(paint47);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double1 = rectangleInsets0.getRight();
        double double3 = rectangleInsets0.calculateLeftOutset((double) 128);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis((int) 'a', categoryAxis7);
        categoryPlot5.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color12, stroke13);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker14.setOutlineStroke(stroke15);
        java.awt.Stroke stroke17 = valueMarker14.getOutlineStroke();
        boolean boolean18 = categoryPlot5.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker14);
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean21 = layer19.equals((java.lang.Object) dateRange20);
        java.lang.String str22 = layer19.toString();
        xYPlot0.addDomainMarker((int) '#', (org.jfree.chart.plot.Marker) valueMarker14, layer19);
        org.jfree.chart.plot.IntervalMarker intervalMarker26 = new org.jfree.chart.plot.IntervalMarker(10.0d, (double) ' ');
        intervalMarker26.setEndValue((double) 6);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker26, layer29);
        xYPlot0.setOutlineVisible(false);
        java.util.List list33 = xYPlot0.getAnnotations();
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        java.util.List list35 = xYPlot34.getAnnotations();
        java.awt.Stroke stroke36 = xYPlot34.getDomainGridlineStroke();
        xYPlot0.setRangeGridlineStroke(stroke36);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(layer19);
        org.junit.Assert.assertNotNull(dateRange20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Layer.FOREGROUND" + "'", str22.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(list33);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2, timeZone3);
        java.util.Date date5 = day4.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date5);
        dateAxis1.setMinimumDate(date5);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(timeZone3);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        java.util.List list9 = numberAxis0.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge8);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        double double16 = rectangleInsets14.calculateLeftInset((double) (-1));
        numberAxis0.setTickLabelInsets(rectangleInsets14);
        double double19 = rectangleInsets14.trimWidth((double) 13);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 32.0d + "'", double16 == 32.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-30.0d) + "'", double19 == (-30.0d));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.junit.Assert.assertNotNull(range0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryAxis1.equals(obj2);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis1.setMaximumCategoryLabelLines(1);
        categoryAxis1.configure();
        float float10 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis5.zoomRange((double) 0L, (double) 3);
        boolean boolean14 = numberAxis5.isNegativeArrowVisible();
        xYPlot0.setDomainAxis(255, (org.jfree.chart.axis.ValueAxis) numberAxis5, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder17 = xYPlot0.getDatasetRenderingOrder();
        java.awt.Stroke stroke18 = xYPlot0.getRangeGridlineStroke();
        java.awt.Paint paint20 = null;
        try {
            xYPlot0.setQuadrantPaint(128, paint20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (128) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder17);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color2, stroke3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker4.setOutlineStroke(stroke5);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker4.setLabelOffsetType(lengthAdjustmentType7);
        boolean boolean9 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker4);
        xYPlot0.setRangeCrosshairVisible(false);
        boolean boolean12 = xYPlot0.isDomainZoomable();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        categoryPlot13.setDomainAxis((int) 'a', categoryAxis15);
        categoryPlot13.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        categoryPlot13.setDataset(0, categoryDataset19);
        float float21 = categoryPlot13.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = categoryPlot13.getAxisOffset();
        org.jfree.chart.LegendItemCollection legendItemCollection23 = categoryPlot13.getLegendItems();
        xYPlot0.setFixedLegendItems(legendItemCollection23);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 1.0f + "'", float21 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(legendItemCollection23);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        xYPlot0.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis6.valueToJava2D((double) 10, rectangle2D8, rectangleEdge9);
        org.jfree.data.Range range11 = numberAxis6.getDefaultAutoRange();
        java.awt.Font font12 = numberAxis6.getTickLabelFont();
        numberAxis6.setAutoRange(false);
        xYPlot0.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis6, false);
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color17);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder19 = xYPlot0.getSeriesRenderingOrder();
        xYPlot0.setDomainCrosshairValue(0.0d, true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(seriesRenderingOrder19);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        int int2 = xYPlot0.getSeriesCount();
        xYPlot0.setNoDataMessage("PlotOrientation.HORIZONTAL");
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = numberAxis11.valueToJava2D((double) 10, rectangle2D13, rectangleEdge14);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = numberAxis16.valueToJava2D((double) 10, rectangle2D18, rectangleEdge19);
        org.jfree.data.Range range21 = numberAxis16.getDefaultAutoRange();
        numberAxis11.setRange(range21);
        numberAxis5.setDefaultAutoRange(range21);
        org.jfree.chart.axis.TickUnitSource tickUnitSource24 = null;
        numberAxis5.setStandardTickUnits(tickUnitSource24);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        double double30 = numberAxis26.valueToJava2D((double) 10, rectangle2D28, rectangleEdge29);
        org.jfree.data.Range range31 = numberAxis26.getDefaultAutoRange();
        numberAxis5.setRangeWithMargins(range31);
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.JFreeChart jFreeChart34 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent35 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis33, jFreeChart34);
        org.jfree.data.time.DateRange dateRange36 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis33.setRange((org.jfree.data.Range) dateRange36);
        dateAxis33.setRange((double) 7, (double) 100);
        dateAxis33.setRangeAboutValue((double) 1, (double) 10);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray44 = new org.jfree.chart.axis.ValueAxis[] { numberAxis5, dateAxis33 };
        xYPlot0.setRangeAxes(valueAxisArray44);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent46 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot0);
        org.jfree.chart.JFreeChart jFreeChart47 = null;
        plotChangeEvent46.setChart(jFreeChart47);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertNotNull(dateRange36);
        org.junit.Assert.assertNotNull(valueAxisArray44);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryAxis1.equals(obj2);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(false);
        boolean boolean11 = categoryAxis1.equals((java.lang.Object) 1.0d);
        int int12 = categoryAxis1.getCategoryLabelPositionOffset();
        double double13 = categoryAxis1.getLowerMargin();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        float float6 = categoryPlot0.getBackgroundAlpha();
        java.lang.String str7 = categoryPlot0.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        double double14 = rectangleInsets12.calculateLeftInset((double) (-1));
        double double15 = rectangleInsets12.getBottom();
        org.jfree.data.general.Dataset dataset16 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) double15, dataset16);
        categoryPlot0.datasetChanged(datasetChangeEvent17);
        org.jfree.data.general.Dataset dataset19 = datasetChangeEvent17.getDataset();
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Category Plot" + "'", str7.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 32.0d + "'", double14 == 32.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNull(dataset19);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker9.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = valueMarker9.getOutlineStroke();
        boolean boolean13 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot0.setOrientation(plotOrientation14);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        categoryPlot16.setDomainAxis((int) 'a', categoryAxis18);
        categoryPlot16.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.data.general.DatasetGroup datasetGroup22 = categoryPlot16.getDatasetGroup();
        java.awt.Paint paint23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        categoryPlot16.setNoDataMessagePaint(paint23);
        categoryPlot0.setRangeGridlinePaint(paint23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        java.awt.geom.Point2D point2D28 = null;
        categoryPlot0.zoomRangeAxes((double) 10.0f, plotRenderingInfo27, point2D28, true);
        org.jfree.chart.axis.AxisLocation axisLocation32 = null;
        categoryPlot0.setDomainAxisLocation(1, axisLocation32);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNull(datasetGroup22);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker9.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = valueMarker9.getOutlineStroke();
        boolean boolean13 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        java.awt.Paint paint14 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace15, true);
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot0.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(axisLocation18);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        java.lang.String str1 = seriesRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str1.equals("SeriesRenderingOrder.REVERSE"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("CONTRACT");
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        categoryPlot1.setDomainAxis((int) 'a', categoryAxis3);
        categoryPlot1.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        categoryPlot1.setDataset(0, categoryDataset7);
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot1.setNoDataMessagePaint(paint9);
        java.awt.Paint paint11 = categoryPlot1.getOutlinePaint();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = color12.createContext(colorModel13, rectangle14, rectangle2D15, affineTransform16, renderingHints17);
        java.awt.Paint[] paintArray19 = new java.awt.Paint[] { color0, paint11, color12 };
        java.awt.Paint[] paintArray20 = null;
        java.awt.Paint[] paintArray21 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray22 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray23 = null;
        java.awt.Shape[] shapeArray24 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier25 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray19, paintArray20, paintArray21, strokeArray22, strokeArray23, shapeArray24);
        java.lang.Object obj26 = defaultDrawingSupplier25.clone();
        java.awt.Paint paint27 = defaultDrawingSupplier25.getNextOutlinePaint();
        try {
            java.awt.Paint paint28 = defaultDrawingSupplier25.getNextFillPaint();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNotNull(paintArray19);
        org.junit.Assert.assertNotNull(paintArray21);
        org.junit.Assert.assertNotNull(strokeArray22);
        org.junit.Assert.assertNotNull(shapeArray24);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double7 = rectangleInsets5.calculateRightInset(11.0d);
        categoryPlot0.setInsets(rectangleInsets5);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj11 = null;
        boolean boolean12 = categoryAxis10.equals(obj11);
        categoryAxis10.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis10.clearCategoryLabelToolTips();
        categoryAxis10.setTickLabelsVisible(false);
        categoryAxis10.setUpperMargin((double) 2);
        java.awt.Color color22 = java.awt.Color.gray;
        categoryAxis10.setTickLabelPaint((java.lang.Comparable) (-1.0f), (java.awt.Paint) color22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        boolean boolean25 = categoryAxis10.equals((java.lang.Object) color24);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color24);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        categoryPlot27.setDomainAxis((int) 'a', categoryAxis29);
        categoryPlot27.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        categoryPlot27.setDataset(0, categoryDataset33);
        java.awt.Paint paint35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot27.setNoDataMessagePaint(paint35);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent37 = null;
        categoryPlot27.rendererChanged(rendererChangeEvent37);
        org.jfree.chart.text.TextAnchor textAnchor39 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        boolean boolean40 = categoryPlot27.equals((java.lang.Object) textAnchor39);
        org.jfree.chart.axis.AxisLocation axisLocation42 = categoryPlot27.getDomainAxisLocation(255);
        categoryPlot0.setDomainAxisLocation(axisLocation42);
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj46 = null;
        boolean boolean47 = categoryAxis45.equals(obj46);
        categoryAxis45.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis45.clearCategoryLabelToolTips();
        categoryAxis45.setTickLabelsVisible(false);
        boolean boolean55 = categoryAxis45.equals((java.lang.Object) 1.0d);
        int int56 = categoryAxis45.getCategoryLabelPositionOffset();
        categoryAxis45.setUpperMargin((double) 98);
        int int59 = categoryPlot0.getDomainAxisIndex(categoryAxis45);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(textAnchor39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 4 + "'", int56 == 4);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
    }

//    @Test
//    public void test084() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test084");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        java.util.Date date3 = day2.getEnd();
//        long long4 = day2.getMiddleMillisecond();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560452399999L + "'", long4 == 1560452399999L);
//    }

//    @Test
//    public void test085() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test085");
//        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
//        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
//        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
//        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D7 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
//        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
//        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
//        numberAxis5.zoomRange((double) 0L, (double) 3);
//        boolean boolean14 = numberAxis5.isNegativeArrowVisible();
//        xYPlot0.setDomainAxis(255, (org.jfree.chart.axis.ValueAxis) numberAxis5, false);
//        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
//        numberAxis18.setAutoRangeMinimumSize((double) 11, false);
//        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_GREEN;
//        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color23, stroke24);
//        numberAxis18.setLabelPaint((java.awt.Paint) color23);
//        xYPlot0.setRangeAxis(7, (org.jfree.chart.axis.ValueAxis) numberAxis18, true);
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
//        xYPlot0.setRenderer(xYItemRenderer29);
//        java.awt.Paint paint31 = xYPlot0.getDomainTickBandPaint();
//        java.util.Date date32 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
//        long long35 = day34.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate36 = day34.getSerialDate();
//        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
//        categoryPlot37.setDomainAxis((int) 'a', categoryAxis39);
//        categoryPlot37.setBackgroundImageAlignment((int) (short) 10);
//        org.jfree.data.general.DatasetGroup datasetGroup43 = categoryPlot37.getDatasetGroup();
//        java.awt.Paint paint44 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
//        categoryPlot37.setNoDataMessagePaint(paint44);
//        boolean boolean46 = day34.equals((java.lang.Object) categoryPlot37);
//        java.awt.Stroke stroke47 = categoryPlot37.getOutlineStroke();
//        xYPlot0.setDomainGridlineStroke(stroke47);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
//        org.junit.Assert.assertNotNull(range10);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(color23);
//        org.junit.Assert.assertNotNull(stroke24);
//        org.junit.Assert.assertNull(paint31);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560409200000L + "'", long35 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNull(datasetGroup43);
//        org.junit.Assert.assertNotNull(paint44);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(stroke47);
//    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        float float8 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot0.getAxisOffset();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj12 = null;
        boolean boolean13 = categoryAxis11.equals(obj12);
        categoryAxis11.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis11.clearCategoryLabelToolTips();
        categoryPlot0.setDomainAxis(categoryAxis11);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        categoryPlot22.setRenderer(categoryItemRenderer23, false);
        int int26 = categoryPlot22.getWeight();
        int int27 = categoryPlot22.getDatasetCount();
        java.lang.String str28 = categoryPlot22.getPlotType();
        java.awt.Color color31 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color31, stroke32);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = valueMarker33.getLabelAnchor();
        java.awt.Color color36 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke37 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color36, stroke37);
        java.awt.Stroke stroke39 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker38.setOutlineStroke(stroke39);
        java.awt.Stroke stroke41 = valueMarker38.getOutlineStroke();
        valueMarker33.setStroke(stroke41);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor43 = org.jfree.chart.util.RectangleAnchor.TOP;
        valueMarker33.setLabelAnchor(rectangleAnchor43);
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = null;
        categoryPlot45.setDomainAxis((int) 'a', categoryAxis47);
        categoryPlot45.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset51 = null;
        categoryPlot45.setDataset(0, categoryDataset51);
        java.awt.Paint paint53 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot45.setNoDataMessagePaint(paint53);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent55 = null;
        categoryPlot45.rendererChanged(rendererChangeEvent55);
        org.jfree.chart.text.TextAnchor textAnchor57 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        boolean boolean58 = categoryPlot45.equals((java.lang.Object) textAnchor57);
        valueMarker33.setLabelTextAnchor(textAnchor57);
        org.jfree.chart.util.Layer layer60 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange61 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean62 = layer60.equals((java.lang.Object) dateRange61);
        java.lang.String str63 = layer60.toString();
        boolean boolean65 = categoryPlot22.removeDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker33, layer60, false);
        java.util.Collection collection66 = categoryPlot0.getRangeMarkers((int) (byte) 10, layer60);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "Category Plot" + "'", str28.equals("Category Plot"));
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(rectangleAnchor34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(rectangleAnchor43);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNotNull(textAnchor57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(layer60);
        org.junit.Assert.assertNotNull(dateRange61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "Layer.FOREGROUND" + "'", str63.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNull(collection66);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryAxis1.equals(obj2);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis1.setMaximumCategoryLabelLines(1);
        double double9 = categoryAxis1.getLowerMargin();
        categoryAxis1.setLowerMargin((double) (short) 100);
        double double12 = categoryAxis1.getLowerMargin();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeMinimumSize((double) 11, false);
        numberAxis0.setAutoRangeStickyZero(true);
        double double6 = numberAxis0.getLabelAngle();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        boolean boolean8 = numberAxis0.equals((java.lang.Object) color7);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        boolean boolean7 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        categoryPlot8.setDomainAxis((int) 'a', categoryAxis10);
        categoryPlot8.clearAnnotations();
        boolean boolean13 = categoryPlot8.isOutlineVisible();
        org.jfree.chart.util.SortOrder sortOrder14 = categoryPlot8.getColumnRenderingOrder();
        java.awt.Stroke stroke15 = categoryPlot8.getRangeGridlineStroke();
        xYPlot0.setRangeZeroBaselineStroke(stroke15);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        categoryPlot17.setDomainAxis((int) 'a', categoryAxis19);
        categoryPlot17.clearAnnotations();
        boolean boolean22 = categoryPlot17.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace23 = categoryPlot17.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot17.setInsets(rectangleInsets24);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot17.getDomainAxisEdge((int) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        numberAxis29.setAutoRangeMinimumSize((double) 11, false);
        numberAxis29.setAutoRangeStickyZero(true);
        double double35 = numberAxis29.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = null;
        double double40 = numberAxis36.valueToJava2D((double) 10, rectangle2D38, rectangleEdge39);
        org.jfree.data.Range range41 = numberAxis36.getDefaultAutoRange();
        numberAxis29.setRange(range41, true, true);
        java.awt.Color color45 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis29.setTickMarkPaint((java.awt.Paint) color45);
        categoryPlot17.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis29);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit48 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis29.setTickUnit(numberTickUnit48, true, false);
        org.jfree.data.Range range52 = xYPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis29);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(sortOrder14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(axisSpace23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(numberTickUnit48);
        org.junit.Assert.assertNull(range52);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot0.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        try {
            categoryPlot0.drawBackground(graphics2D14, rectangle2D15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
//        java.awt.Font font4 = null;
//        categoryAxis2.setTickLabelFont((java.lang.Comparable) (byte) -1, font4);
//        java.lang.String str6 = categoryAxis2.getLabelToolTip();
//        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D9 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
//        double double11 = numberAxis7.valueToJava2D((double) 10, rectangle2D9, rectangleEdge10);
//        java.awt.Graphics2D graphics2D12 = null;
//        org.jfree.chart.axis.AxisState axisState13 = null;
//        java.awt.geom.Rectangle2D rectangle2D14 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
//        java.util.List list16 = numberAxis7.refreshTicks(graphics2D12, axisState13, rectangle2D14, rectangleEdge15);
//        numberAxis7.setLabel("RectangleAnchor.TOP_LEFT");
//        numberAxis7.zoomRange((double) (-1L), (double) 1);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer22);
//        java.util.Date date24 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date24, timeZone25);
//        long long27 = day26.getFirstMillisecond();
//        org.jfree.chart.axis.AxisLocation axisLocation28 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
//        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_GREEN;
//        java.awt.Stroke stroke31 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color30, stroke31);
//        boolean boolean33 = axisLocation28.equals((java.lang.Object) valueMarker32);
//        float float34 = valueMarker32.getAlpha();
//        int int35 = day26.compareTo((java.lang.Object) valueMarker32);
//        boolean boolean36 = categoryPlot23.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker32);
//        org.junit.Assert.assertNull(str6);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
//        org.junit.Assert.assertNotNull(list16);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(timeZone25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560409200000L + "'", long27 == 1560409200000L);
//        org.junit.Assert.assertNotNull(axisLocation28);
//        org.junit.Assert.assertNotNull(color30);
//        org.junit.Assert.assertNotNull(stroke31);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 1.0f + "'", float34 == 1.0f);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        java.awt.Paint paint10 = categoryPlot0.getOutlinePaint();
        float float11 = categoryPlot0.getBackgroundAlpha();
        categoryPlot0.setDrawSharedDomainAxis(false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setRange((double) (byte) 10, 100.0d);
        org.jfree.chart.axis.Timeline timeline4 = null;
        dateAxis0.setTimeline(timeline4);
        org.jfree.chart.axis.Timeline timeline6 = null;
        dateAxis0.setTimeline(timeline6);
        java.util.Date date8 = dateAxis0.getMinimumDate();
        java.lang.Object obj9 = dateAxis0.clone();
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.data.Range range5 = numberAxis0.getDefaultAutoRange();
        numberAxis0.zoomRange((double) 0L, (double) 3);
        java.lang.String str9 = numberAxis0.getLabel();
        boolean boolean10 = numberAxis0.getAutoRangeStickyZero();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis0.getLabelInsets();
        double double13 = rectangleInsets11.trimWidth(0.05d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-5.95d) + "'", double13 == (-5.95d));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font4 = null;
        categoryAxis2.setTickLabelFont((java.lang.Comparable) (byte) -1, font4);
        java.lang.String str6 = categoryAxis2.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = numberAxis7.valueToJava2D((double) 10, rectangle2D9, rectangleEdge10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.AxisState axisState13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        java.util.List list16 = numberAxis7.refreshTicks(graphics2D12, axisState13, rectangle2D14, rectangleEdge15);
        numberAxis7.setLabel("RectangleAnchor.TOP_LEFT");
        numberAxis7.zoomRange((double) (-1L), (double) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer22);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = numberAxis24.valueToJava2D((double) 10, rectangle2D26, rectangleEdge27);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = null;
        double double33 = numberAxis29.valueToJava2D((double) 10, rectangle2D31, rectangleEdge32);
        org.jfree.data.Range range34 = numberAxis29.getDefaultAutoRange();
        numberAxis24.setRange(range34);
        numberAxis7.setRangeWithMargins(range34);
        numberAxis7.setVisible(false);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(range34);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis0.setRangeWithMargins(range10, true, true);
        java.text.NumberFormat numberFormat14 = numberAxis0.getNumberFormatOverride();
        java.lang.String str15 = numberAxis0.getLabelURL();
        numberAxis0.centerRange(0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        numberAxis18.setAutoRangeMinimumSize((double) 11, false);
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color23, stroke24);
        numberAxis18.setLabelPaint((java.awt.Paint) color23);
        numberAxis18.setPositiveArrowVisible(true);
        org.jfree.chart.plot.Plot plot29 = numberAxis18.getPlot();
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        double double34 = numberAxis30.valueToJava2D((double) 10, rectangle2D32, rectangleEdge33);
        org.jfree.data.Range range35 = numberAxis30.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = null;
        double double40 = numberAxis36.valueToJava2D((double) 10, rectangle2D38, rectangleEdge39);
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = numberAxis41.valueToJava2D((double) 10, rectangle2D43, rectangleEdge44);
        org.jfree.data.Range range46 = numberAxis41.getDefaultAutoRange();
        numberAxis36.setRange(range46);
        numberAxis30.setDefaultAutoRange(range46);
        java.awt.Shape shape49 = numberAxis30.getDownArrow();
        numberAxis18.setDownArrow(shape49);
        numberAxis0.setUpArrow(shape49);
        double double52 = numberAxis0.getLabelAngle();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNull(numberFormat14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(plot29);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        xYPlot0.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis5.getTickMarkPaint();
        xYPlot0.setDomainTickBandPaint(paint10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color15, stroke16);
        boolean boolean18 = axisLocation13.equals((java.lang.Object) valueMarker17);
        float float19 = valueMarker17.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = valueMarker17.getLabelAnchor();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean23 = layer21.equals((java.lang.Object) dateRange22);
        java.lang.String str24 = layer21.toString();
        xYPlot0.addDomainMarker((int) (short) 100, (org.jfree.chart.plot.Marker) valueMarker17, layer21);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        numberAxis26.setAutoRangeMinimumSize((double) 11, false);
        numberAxis26.setAutoRangeStickyZero(true);
        double double32 = numberAxis26.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        double double37 = numberAxis33.valueToJava2D((double) 10, rectangle2D35, rectangleEdge36);
        org.jfree.data.Range range38 = numberAxis33.getDefaultAutoRange();
        numberAxis26.setRange(range38, true, true);
        java.awt.Color color42 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis26.setTickMarkPaint((java.awt.Paint) color42);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = null;
        double double48 = numberAxis44.valueToJava2D((double) 10, rectangle2D46, rectangleEdge47);
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = null;
        double double53 = numberAxis49.valueToJava2D((double) 10, rectangle2D51, rectangleEdge52);
        org.jfree.data.Range range54 = numberAxis49.getDefaultAutoRange();
        numberAxis44.setRange(range54);
        boolean boolean56 = color42.equals((java.lang.Object) numberAxis44);
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color42);
        org.jfree.chart.plot.Plot plot58 = xYPlot0.getRootPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder59 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.data.xy.XYDataset xYDataset61 = xYPlot0.getDataset((int) (short) 0);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Layer.FOREGROUND" + "'", str24.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(plot58);
        org.junit.Assert.assertNotNull(seriesRenderingOrder59);
        org.junit.Assert.assertNull(xYDataset61);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        float float8 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot0.getAxisOffset();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj12 = null;
        boolean boolean13 = categoryAxis11.equals(obj12);
        categoryAxis11.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis11.clearCategoryLabelToolTips();
        categoryPlot0.setDomainAxis(categoryAxis11);
        java.awt.Font font20 = categoryAxis11.getTickLabelFont((java.lang.Comparable) ' ');
        java.awt.Paint paint21 = categoryAxis11.getTickLabelPaint();
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryAxis1.equals(obj2);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(false);
        categoryAxis1.setUpperMargin((double) 2);
        java.awt.Font font13 = null;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) (byte) -1, font13);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation18 = null;
        xYPlot16.setRangeAxisLocation((int) (short) 100, axisLocation18);
        xYPlot16.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = numberAxis21.valueToJava2D((double) 10, rectangle2D23, rectangleEdge24);
        java.awt.Paint paint26 = numberAxis21.getTickMarkPaint();
        xYPlot16.setDomainTickBandPaint(paint26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color31 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color31, stroke32);
        boolean boolean34 = axisLocation29.equals((java.lang.Object) valueMarker33);
        float float35 = valueMarker33.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor36 = valueMarker33.getLabelAnchor();
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange38 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean39 = layer37.equals((java.lang.Object) dateRange38);
        java.lang.String str40 = layer37.toString();
        xYPlot16.addDomainMarker((int) (short) 100, (org.jfree.chart.plot.Marker) valueMarker33, layer37);
        java.awt.Font font42 = valueMarker33.getLabelFont();
        categoryAxis1.setTickLabelFont((java.lang.Comparable) 9, font42);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 1.0f + "'", float35 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleAnchor36);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertNotNull(dateRange38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Layer.FOREGROUND" + "'", str40.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(font42);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        categoryPlot0.setRenderer(categoryItemRenderer1, false);
        int int4 = categoryPlot0.getWeight();
        int int5 = categoryPlot0.getDatasetCount();
        java.lang.String str6 = categoryPlot0.getPlotType();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent7);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        try {
            categoryPlot0.setDataset((-48897), categoryDataset10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        boolean boolean7 = xYPlot0.isDomainCrosshairVisible();
        boolean boolean8 = xYPlot0.isSubplot();
        int int9 = xYPlot0.getDatasetCount();
        org.jfree.chart.axis.AxisLocation axisLocation10 = null;
        try {
            xYPlot0.setDomainAxisLocation(axisLocation10, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        boolean boolean7 = xYPlot0.isDomainCrosshairVisible();
        boolean boolean8 = xYPlot0.isSubplot();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        int int10 = color9.getRGB();
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation12, plotOrientation13);
        xYPlot0.setOrientation(plotOrientation13);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-128) + "'", int10 == (-128));
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color2, stroke3);
        boolean boolean5 = axisLocation0.equals((java.lang.Object) valueMarker4);
        float float6 = valueMarker4.getAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        org.jfree.chart.util.UnitType unitType12 = rectangleInsets11.getUnitType();
        valueMarker4.setLabelOffset(rectangleInsets11);
        java.lang.String str14 = rectangleInsets11.toString();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(unitType12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "RectangleInsets[t=52.0,l=32.0,b=0.0,r=11.0]" + "'", str14.equals("RectangleInsets[t=52.0,l=32.0,b=0.0,r=11.0]"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeMinimumSize((double) 11, false);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color5, stroke6);
        numberAxis0.setLabelPaint((java.awt.Paint) color5);
        numberAxis0.setPositiveArrowVisible(true);
        java.lang.Object obj11 = numberAxis0.clone();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand12 = null;
        numberAxis0.setMarkerBand(markerAxisBand12);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        double double6 = rectangleInsets4.calculateLeftInset((double) (-1));
        org.jfree.chart.util.UnitType unitType7 = rectangleInsets4.getUnitType();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 32.0d + "'", double6 == 32.0d);
        org.junit.Assert.assertNotNull(unitType7);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        java.awt.Paint paint5 = numberAxis0.getTickMarkPaint();
        numberAxis0.resizeRange((double) 3);
        numberAxis0.setAutoRangeMinimumSize(10.0d, false);
        boolean boolean11 = numberAxis0.isInverted();
        boolean boolean12 = numberAxis0.isAutoRange();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setRange((double) (byte) 10, 100.0d);
        org.jfree.chart.axis.Timeline timeline4 = null;
        dateAxis0.setTimeline(timeline4);
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = dateAxis0.getTickUnit();
        org.junit.Assert.assertNotNull(dateTickUnit6);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        java.awt.Color color2 = java.awt.Color.getColor("AxisLocation.BOTTOM_OR_LEFT", 11);
        float[] floatArray9 = new float[] { 9, 0.0f, 12, (-393216), (byte) 0, 1 };
        float[] floatArray10 = color2.getColorComponents(floatArray9);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test110");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        long long3 = day2.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
//        categoryPlot5.setDomainAxis((int) 'a', categoryAxis7);
//        categoryPlot5.setBackgroundImageAlignment((int) (short) 10);
//        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot5.getDatasetGroup();
//        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
//        categoryPlot5.setNoDataMessagePaint(paint12);
//        boolean boolean14 = day2.equals((java.lang.Object) categoryPlot5);
//        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
//        java.awt.Font font19 = null;
//        categoryAxis17.setTickLabelFont((java.lang.Comparable) (byte) -1, font19);
//        java.lang.String str21 = categoryAxis17.getLabelToolTip();
//        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D24 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
//        double double26 = numberAxis22.valueToJava2D((double) 10, rectangle2D24, rectangleEdge25);
//        java.awt.Graphics2D graphics2D27 = null;
//        org.jfree.chart.axis.AxisState axisState28 = null;
//        java.awt.geom.Rectangle2D rectangle2D29 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
//        java.util.List list31 = numberAxis22.refreshTicks(graphics2D27, axisState28, rectangle2D29, rectangleEdge30);
//        numberAxis22.setLabel("RectangleAnchor.TOP_LEFT");
//        numberAxis22.zoomRange((double) (-1L), (double) 1);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis17, (org.jfree.chart.axis.ValueAxis) numberAxis22, categoryItemRenderer37);
//        int int39 = categoryPlot5.getDomainAxisIndex(categoryAxis17);
//        java.awt.Font font40 = categoryAxis17.getTickLabelFont();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNull(datasetGroup11);
//        org.junit.Assert.assertNotNull(paint12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNull(str21);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
//        org.junit.Assert.assertNotNull(list31);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
//        org.junit.Assert.assertNotNull(font40);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.data.general.DatasetGroup datasetGroup6 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = categoryPlot0.getRenderer();
        java.lang.String str8 = categoryPlot0.getPlotType();
        double double9 = categoryPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNull(categoryItemRenderer7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "Category Plot" + "'", str8.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        numberAxis0.setAutoRangeMinimumSize(52.0d, true);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = numberAxis8.valueToJava2D((double) 10, rectangle2D10, rectangleEdge11);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = numberAxis13.valueToJava2D((double) 10, rectangle2D15, rectangleEdge16);
        org.jfree.data.Range range18 = numberAxis13.getDefaultAutoRange();
        numberAxis8.setRange(range18);
        numberAxis8.setRangeAboutValue((double) (short) -1, 0.0d);
        numberAxis8.setTickLabelsVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = null;
        double double29 = numberAxis25.valueToJava2D((double) 10, rectangle2D27, rectangleEdge28);
        org.jfree.data.Range range30 = numberAxis25.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = null;
        double double35 = numberAxis31.valueToJava2D((double) 10, rectangle2D33, rectangleEdge34);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = null;
        double double40 = numberAxis36.valueToJava2D((double) 10, rectangle2D38, rectangleEdge39);
        org.jfree.data.Range range41 = numberAxis36.getDefaultAutoRange();
        numberAxis31.setRange(range41);
        numberAxis25.setDefaultAutoRange(range41);
        java.awt.Shape shape44 = numberAxis25.getDownArrow();
        numberAxis8.setRightArrow(shape44);
        numberAxis0.setDownArrow(shape44);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNotNull(shape44);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        java.util.List list9 = numberAxis0.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge8);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = numberAxis10.valueToJava2D((double) 10, rectangle2D12, rectangleEdge13);
        org.jfree.data.Range range15 = numberAxis10.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = numberAxis16.valueToJava2D((double) 10, rectangle2D18, rectangleEdge19);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = numberAxis21.valueToJava2D((double) 10, rectangle2D23, rectangleEdge24);
        org.jfree.data.Range range26 = numberAxis21.getDefaultAutoRange();
        numberAxis16.setRange(range26);
        numberAxis10.setDefaultAutoRange(range26);
        java.awt.Shape shape29 = numberAxis10.getDownArrow();
        boolean boolean30 = numberAxis10.isAutoRange();
        java.awt.Shape shape31 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        numberAxis10.setRightArrow(shape31);
        numberAxis0.setDownArrow(shape31);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(shape31);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryAxis1.equals(obj2);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(false);
        categoryAxis1.setUpperMargin((double) 2);
        java.awt.Color color13 = java.awt.Color.gray;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (-1.0f), (java.awt.Paint) color13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        boolean boolean16 = categoryAxis1.equals((java.lang.Object) color15);
        int int17 = color15.getBlue();
        java.awt.Color color18 = color15.brighter();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 255 + "'", int17 == 255);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setRange((double) (byte) 10, 100.0d);
        org.jfree.chart.axis.Timeline timeline4 = null;
        dateAxis0.setTimeline(timeline4);
        org.jfree.chart.axis.Timeline timeline6 = null;
        dateAxis0.setTimeline(timeline6);
        dateAxis0.configure();
        java.awt.Stroke stroke9 = dateAxis0.getTickMarkStroke();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition10 = null;
        try {
            dateAxis0.setTickMarkPosition(dateTickMarkPosition10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        double double6 = rectangleInsets4.calculateLeftInset((double) (-1));
        double double7 = rectangleInsets4.getTop();
        java.awt.Color color8 = java.awt.Color.lightGray;
        boolean boolean9 = rectangleInsets4.equals((java.lang.Object) color8);
        int int10 = color8.getAlpha();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 32.0d + "'", double6 == 32.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 52.0d + "'", double7 == 52.0d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 255 + "'", int10 == 255);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double7 = rectangleInsets5.calculateRightInset(11.0d);
        categoryPlot0.setInsets(rectangleInsets5);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot9.setDomainAxis((int) 'a', categoryAxis11);
        categoryPlot9.setBackgroundImageAlignment((int) (short) 10);
        float float15 = categoryPlot9.getBackgroundAlpha();
        categoryPlot9.clearRangeAxes();
        boolean boolean17 = rectangleInsets5.equals((java.lang.Object) categoryPlot9);
        categoryPlot9.setRangeCrosshairValue(0.0d);
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation23 = null;
        xYPlot21.setRangeAxisLocation((int) (short) 100, axisLocation23);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        double double30 = numberAxis26.valueToJava2D((double) 10, rectangle2D28, rectangleEdge29);
        org.jfree.data.Range range31 = numberAxis26.getDefaultAutoRange();
        numberAxis26.zoomRange((double) 0L, (double) 3);
        boolean boolean35 = numberAxis26.isNegativeArrowVisible();
        xYPlot21.setDomainAxis(255, (org.jfree.chart.axis.ValueAxis) numberAxis26, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder38 = xYPlot21.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation40 = xYPlot21.getRangeAxisLocation(0);
        categoryPlot9.setRangeAxisLocation(100, axisLocation40);
        java.awt.Stroke stroke42 = null;
        try {
            categoryPlot9.setRangeGridlineStroke(stroke42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder38);
        org.junit.Assert.assertNotNull(axisLocation40);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj3 = null;
        boolean boolean4 = categoryAxis2.equals(obj3);
        categoryAxis2.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis2.clearCategoryLabelToolTips();
        categoryAxis2.setTickLabelsVisible(false);
        boolean boolean12 = categoryAxis2.equals((java.lang.Object) 1.0d);
        int int13 = categoryAxis2.getCategoryLabelPositionOffset();
        categoryAxis2.setLowerMargin((double) 10);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = numberAxis16.valueToJava2D((double) 10, rectangle2D18, rectangleEdge19);
        org.jfree.data.Range range21 = numberAxis16.getDefaultAutoRange();
        java.awt.Font font22 = numberAxis16.getTickLabelFont();
        categoryAxis2.setTickLabelFont(font22);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = numberAxis24.valueToJava2D((double) 10, rectangle2D26, rectangleEdge27);
        org.jfree.data.Range range29 = numberAxis24.getDefaultAutoRange();
        java.awt.Font font30 = numberAxis24.getTickLabelFont();
        numberAxis24.setAutoRangeIncludesZero(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis24, categoryItemRenderer33);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNotNull(font30);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        java.util.List list9 = numberAxis0.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge8);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        double double16 = rectangleInsets14.calculateLeftInset((double) (-1));
        numberAxis0.setTickLabelInsets(rectangleInsets14);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = numberAxis0.getLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D20 = rectangleInsets18.createOutsetRectangle(rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 32.0d + "'", double16 == 32.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker9.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = valueMarker9.getOutlineStroke();
        boolean boolean13 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        java.awt.Paint paint14 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot0.setAxisOffset(rectangleInsets15);
        double double18 = rectangleInsets15.calculateBottomInset((double) 1560409200000L);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.0d + "'", double18 == 2.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        java.awt.Color color0 = java.awt.Color.cyan;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = categoryPlot0.getDrawingSupplier();
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.plot.Plot plot6 = categoryPlot0.getParent();
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(plot6);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        xYPlot0.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis5.getTickMarkPaint();
        xYPlot0.setDomainTickBandPaint(paint10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color15, stroke16);
        boolean boolean18 = axisLocation13.equals((java.lang.Object) valueMarker17);
        float float19 = valueMarker17.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = valueMarker17.getLabelAnchor();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean23 = layer21.equals((java.lang.Object) dateRange22);
        java.lang.String str24 = layer21.toString();
        xYPlot0.addDomainMarker((int) (short) 100, (org.jfree.chart.plot.Marker) valueMarker17, layer21);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        numberAxis26.setAutoRangeMinimumSize((double) 11, false);
        numberAxis26.setAutoRangeStickyZero(true);
        double double32 = numberAxis26.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        double double37 = numberAxis33.valueToJava2D((double) 10, rectangle2D35, rectangleEdge36);
        org.jfree.data.Range range38 = numberAxis33.getDefaultAutoRange();
        numberAxis26.setRange(range38, true, true);
        java.awt.Color color42 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis26.setTickMarkPaint((java.awt.Paint) color42);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = null;
        double double48 = numberAxis44.valueToJava2D((double) 10, rectangle2D46, rectangleEdge47);
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = null;
        double double53 = numberAxis49.valueToJava2D((double) 10, rectangle2D51, rectangleEdge52);
        org.jfree.data.Range range54 = numberAxis49.getDefaultAutoRange();
        numberAxis44.setRange(range54);
        boolean boolean56 = color42.equals((java.lang.Object) numberAxis44);
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color42);
        xYPlot0.clearDomainMarkers();
        java.awt.Graphics2D graphics2D59 = null;
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo61 = null;
        xYPlot0.drawAnnotations(graphics2D59, rectangle2D60, plotRenderingInfo61);
        org.jfree.chart.plot.XYPlot xYPlot63 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation65 = null;
        xYPlot63.setRangeAxisLocation((int) (short) 100, axisLocation65);
        org.jfree.chart.axis.NumberAxis numberAxis68 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = null;
        double double72 = numberAxis68.valueToJava2D((double) 10, rectangle2D70, rectangleEdge71);
        org.jfree.data.Range range73 = numberAxis68.getDefaultAutoRange();
        numberAxis68.zoomRange((double) 0L, (double) 3);
        boolean boolean77 = numberAxis68.isNegativeArrowVisible();
        xYPlot63.setDomainAxis(255, (org.jfree.chart.axis.ValueAxis) numberAxis68, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder80 = xYPlot63.getDatasetRenderingOrder();
        xYPlot0.setDatasetRenderingOrder(datasetRenderingOrder80);
        boolean boolean82 = xYPlot0.isDomainZeroBaselineVisible();
        int int83 = xYPlot0.getDatasetCount();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Layer.FOREGROUND" + "'", str24.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(range73);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder80);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 1 + "'", int83 == 1);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        java.awt.Paint paint10 = categoryPlot0.getOutlinePaint();
        java.util.List list11 = categoryPlot0.getCategories();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(list11);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        categoryPlot7.setDomainAxis((int) 'a', categoryAxis9);
        categoryPlot7.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        categoryPlot7.setDataset(0, categoryDataset13);
        java.awt.Paint paint15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot7.setNoDataMessagePaint(paint15);
        java.awt.Paint paint17 = categoryPlot7.getOutlinePaint();
        int int18 = categoryPlot7.getDomainAxisCount();
        java.lang.Class<?> wildcardClass19 = categoryPlot7.getClass();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        categoryPlot21.setDomainAxis((int) 'a', categoryAxis23);
        categoryPlot21.clearAnnotations();
        boolean boolean26 = categoryPlot21.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace27 = categoryPlot21.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot21.setInsets(rectangleInsets28);
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation31 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation30, plotOrientation31);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor33 = org.jfree.chart.axis.CategoryAnchor.END;
        boolean boolean34 = axisLocation30.equals((java.lang.Object) categoryAnchor33);
        categoryPlot21.setRangeAxisLocation(axisLocation30, false);
        categoryPlot7.setRangeAxisLocation((int) (short) 10, axisLocation30, false);
        xYPlot0.setRangeAxisLocation(axisLocation30, true);
        double double41 = xYPlot0.getDomainCrosshairValue();
        java.awt.Color color43 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke44 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker45 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color43, stroke44);
        xYPlot0.setDomainGridlineStroke(stroke44);
        xYPlot0.setRangeCrosshairValue((double) (short) -1, true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 98 + "'", int18 == 98);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(axisSpace27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(plotOrientation31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(categoryAnchor33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(stroke44);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        boolean boolean7 = xYPlot0.isDomainCrosshairVisible();
        boolean boolean8 = xYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = numberAxis9.valueToJava2D((double) 10, rectangle2D11, rectangleEdge12);
        org.jfree.data.Range range14 = numberAxis9.getDefaultAutoRange();
        numberAxis9.zoomRange((double) 0L, (double) 3);
        int int18 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis9);
        java.awt.Paint paint19 = xYPlot0.getRangeZeroBaselinePaint();
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation22 = null;
        xYPlot20.setRangeAxisLocation((int) (short) 100, axisLocation22);
        xYPlot20.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = null;
        double double29 = numberAxis25.valueToJava2D((double) 10, rectangle2D27, rectangleEdge28);
        java.awt.Paint paint30 = numberAxis25.getTickMarkPaint();
        xYPlot20.setDomainTickBandPaint(paint30);
        org.jfree.chart.axis.AxisLocation axisLocation33 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color35 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color35, stroke36);
        boolean boolean38 = axisLocation33.equals((java.lang.Object) valueMarker37);
        float float39 = valueMarker37.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = valueMarker37.getLabelAnchor();
        org.jfree.chart.util.Layer layer41 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange42 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean43 = layer41.equals((java.lang.Object) dateRange42);
        java.lang.String str44 = layer41.toString();
        xYPlot20.addDomainMarker((int) (short) 100, (org.jfree.chart.plot.Marker) valueMarker37, layer41);
        java.awt.Font font46 = valueMarker37.getLabelFont();
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) valueMarker37);
        org.jfree.chart.text.TextAnchor textAnchor48 = valueMarker37.getLabelTextAnchor();
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = null;
        double double53 = numberAxis49.valueToJava2D((double) 10, rectangle2D51, rectangleEdge52);
        org.jfree.data.Range range54 = numberAxis49.getDefaultAutoRange();
        numberAxis49.zoomRange((double) 0L, (double) 3);
        java.awt.Paint paint58 = numberAxis49.getTickLabelPaint();
        boolean boolean59 = textAnchor48.equals((java.lang.Object) numberAxis49);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 1.0f + "'", float39 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(layer41);
        org.junit.Assert.assertNotNull(dateRange42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Layer.FOREGROUND" + "'", str44.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(textAnchor48);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        xYPlot0.setRangeCrosshairValue(11.0d, false);
        boolean boolean5 = xYPlot0.isRangeZoomable();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        int int7 = xYPlot6.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot6.getRangeAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot9.setDomainAxis((int) 'a', categoryAxis11);
        categoryPlot9.clearAnnotations();
        boolean boolean14 = categoryPlot9.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace15 = categoryPlot9.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot9.setInsets(rectangleInsets16);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot9.getDomainAxisEdge((int) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        numberAxis21.setAutoRangeMinimumSize((double) 11, false);
        numberAxis21.setAutoRangeStickyZero(true);
        double double27 = numberAxis21.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
        double double32 = numberAxis28.valueToJava2D((double) 10, rectangle2D30, rectangleEdge31);
        org.jfree.data.Range range33 = numberAxis28.getDefaultAutoRange();
        numberAxis21.setRange(range33, true, true);
        java.awt.Color color37 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis21.setTickMarkPaint((java.awt.Paint) color37);
        categoryPlot9.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis21);
        categoryPlot9.clearRangeMarkers();
        java.awt.Color color42 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke43 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color42, stroke43);
        java.awt.Stroke stroke45 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker44.setOutlineStroke(stroke45);
        java.awt.Stroke stroke47 = valueMarker44.getStroke();
        categoryPlot9.setDomainGridlineStroke(stroke47);
        xYPlot6.setRangeGridlineStroke(stroke47);
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis();
        numberAxis51.setAutoRangeMinimumSize((double) 11, false);
        numberAxis51.setAutoRangeStickyZero(true);
        double double57 = numberAxis51.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = null;
        double double62 = numberAxis58.valueToJava2D((double) 10, rectangle2D60, rectangleEdge61);
        org.jfree.data.Range range63 = numberAxis58.getDefaultAutoRange();
        numberAxis51.setRange(range63, true, true);
        xYPlot6.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis51);
        org.jfree.chart.axis.AxisLocation axisLocation69 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot6.setDomainAxisLocation(5, axisLocation69, true);
        xYPlot0.setRangeAxisLocation(axisLocation69, true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(axisSpace15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(range63);
        org.junit.Assert.assertNotNull(axisLocation69);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeMinimumSize((double) 11, false);
        numberAxis0.setAutoRangeStickyZero(true);
        double double6 = numberAxis0.getLabelAngle();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        categoryPlot7.setDomainAxis((int) 'a', categoryAxis9);
        categoryPlot7.setBackgroundImageAlignment((int) (short) 10);
        numberAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot7.setRenderer(categoryItemRenderer14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot7.getDomainAxisLocation();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test130");
//        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
//        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
//        categoryPlot0.clearAnnotations();
//        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
//        categoryPlot0.setDataset(0, categoryDataset6);
//        float float8 = categoryPlot0.getForegroundAlpha();
//        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot0.getAxisOffset();
//        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
//        java.lang.Object obj12 = null;
//        boolean boolean13 = categoryAxis11.equals(obj12);
//        categoryAxis11.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
//        categoryAxis11.clearCategoryLabelToolTips();
//        categoryPlot0.setDomainAxis(categoryAxis11);
//        java.awt.Font font20 = categoryAxis11.getTickLabelFont((java.lang.Comparable) ' ');
//        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22, timeZone23);
//        long long25 = day24.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate26 = day24.getSerialDate();
//        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
//        java.awt.geom.Rectangle2D rectangle2D29 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
//        categoryPlot30.setDomainAxis((int) 'a', categoryAxis32);
//        categoryPlot30.clearAnnotations();
//        boolean boolean35 = categoryPlot30.isOutlineVisible();
//        org.jfree.chart.axis.AxisSpace axisSpace36 = categoryPlot30.getFixedDomainAxisSpace();
//        org.jfree.chart.util.RectangleInsets rectangleInsets37 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
//        categoryPlot30.setInsets(rectangleInsets37);
//        categoryPlot30.setWeight((int) (short) 1);
//        java.awt.Color color42 = org.jfree.chart.ChartColor.DARK_GREEN;
//        java.awt.Stroke stroke43 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color42, stroke43);
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = valueMarker44.getLabelAnchor();
//        boolean boolean46 = categoryPlot30.equals((java.lang.Object) rectangleAnchor45);
//        org.jfree.chart.util.RectangleEdge rectangleEdge47 = categoryPlot30.getRangeAxisEdge();
//        try {
//            double double48 = categoryAxis11.getCategorySeriesMiddle((java.lang.Comparable) 4, (java.lang.Comparable) serialDate26, categoryDataset27, 52.0d, rectangle2D29, rectangleEdge47);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
//        org.junit.Assert.assertNotNull(rectangleInsets9);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(font20);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(timeZone23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560409200000L + "'", long25 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate26);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
//        org.junit.Assert.assertNull(axisSpace36);
//        org.junit.Assert.assertNotNull(rectangleInsets37);
//        org.junit.Assert.assertNotNull(color42);
//        org.junit.Assert.assertNotNull(stroke43);
//        org.junit.Assert.assertNotNull(rectangleAnchor45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(rectangleEdge47);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        float float6 = categoryPlot0.getBackgroundAlpha();
        java.lang.String str7 = categoryPlot0.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        double double14 = rectangleInsets12.calculateLeftInset((double) (-1));
        double double15 = rectangleInsets12.getBottom();
        org.jfree.data.general.Dataset dataset16 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) double15, dataset16);
        categoryPlot0.datasetChanged(datasetChangeEvent17);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        categoryPlot0.setRenderer(categoryItemRenderer19, false);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        try {
            categoryPlot0.drawBackground(graphics2D22, rectangle2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Category Plot" + "'", str7.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 32.0d + "'", double14 == 32.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
        java.util.Date date3 = day2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        int int5 = day4.getYear();
        java.util.Calendar calendar6 = null;
        try {
            day4.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryAxis1.equals(obj2);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        java.lang.Comparable comparable7 = null;
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        try {
            categoryAxis1.setTickLabelPaint(comparable7, (java.awt.Paint) color8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        categoryPlot1.setDomainAxis((int) 'a', categoryAxis3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = categoryPlot1.getDrawingSupplier();
        categoryPlot0.setDrawingSupplier(drawingSupplier5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            categoryPlot0.drawBackground(graphics2D7, rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(drawingSupplier5);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        xYPlot0.zoomDomainAxes(0.0d, 1.0d, plotRenderingInfo5, point2D6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot9.setDomainAxis((int) 'a', categoryAxis11);
        categoryPlot9.clearAnnotations();
        boolean boolean14 = categoryPlot9.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace15 = categoryPlot9.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot9.setInsets(rectangleInsets16);
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation18, plotOrientation19);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor21 = org.jfree.chart.axis.CategoryAnchor.END;
        boolean boolean22 = axisLocation18.equals((java.lang.Object) categoryAnchor21);
        categoryPlot9.setRangeAxisLocation(axisLocation18, false);
        xYPlot0.setRangeAxisLocation(12, axisLocation18, false);
        xYPlot0.setRangeCrosshairValue((double) (byte) -1);
        boolean boolean29 = xYPlot0.isOutlineVisible();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(axisSpace15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(plotOrientation19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(categoryAnchor21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot0.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent12);
        org.jfree.chart.util.Layer layer15 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection16 = categoryPlot0.getRangeMarkers((int) (byte) -1, layer15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj19 = null;
        boolean boolean20 = categoryAxis18.equals(obj19);
        categoryAxis18.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis18.clearCategoryLabelToolTips();
        categoryAxis18.setTickLabelsVisible(false);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        categoryPlot28.setDomainAxis((int) 'a', categoryAxis30);
        categoryPlot28.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        categoryPlot28.setDataset(0, categoryDataset34);
        java.awt.Paint paint36 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot28.setNoDataMessagePaint(paint36);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = categoryPlot28.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent40 = null;
        categoryPlot28.rendererChanged(rendererChangeEvent40);
        org.jfree.chart.util.Layer layer43 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection44 = categoryPlot28.getRangeMarkers((int) (byte) -1, layer43);
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = null;
        org.jfree.chart.axis.AxisSpace axisSpace47 = null;
        org.jfree.chart.axis.AxisSpace axisSpace48 = categoryAxis18.reserveSpace(graphics2D27, (org.jfree.chart.plot.Plot) categoryPlot28, rectangle2D45, rectangleEdge46, axisSpace47);
        categoryPlot0.setFixedRangeAxisSpace(axisSpace48, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation51 = categoryPlot0.getOrientation();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent52 = null;
        categoryPlot0.notifyListeners(plotChangeEvent52);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(layer15);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNotNull(layer43);
        org.junit.Assert.assertNull(collection44);
        org.junit.Assert.assertNotNull(axisSpace48);
        org.junit.Assert.assertNotNull(plotOrientation51);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        categoryPlot1.setDomainAxis((int) 'a', categoryAxis3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = categoryPlot1.getDrawingSupplier();
        categoryPlot0.setDrawingSupplier(drawingSupplier5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        categoryPlot7.setDomainAxis((int) 'a', categoryAxis9);
        categoryPlot7.clearAnnotations();
        boolean boolean12 = categoryPlot7.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace13 = categoryPlot7.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot7.setInsets(rectangleInsets14);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot7.getDomainAxisEdge((int) (short) -1);
        boolean boolean18 = categoryPlot0.equals((java.lang.Object) (short) -1);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font22 = null;
        categoryAxis20.setTickLabelFont((java.lang.Comparable) (byte) -1, font22);
        java.lang.String str24 = categoryAxis20.getLabelToolTip();
        int int25 = categoryPlot0.getDomainAxisIndex(categoryAxis20);
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke30 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color29, stroke30);
        boolean boolean32 = axisLocation27.equals((java.lang.Object) valueMarker31);
        float float33 = valueMarker31.getAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        org.jfree.chart.util.UnitType unitType39 = rectangleInsets38.getUnitType();
        valueMarker31.setLabelOffset(rectangleInsets38);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        categoryPlot41.setDomainAxis((int) 'a', categoryAxis43);
        categoryPlot41.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset47 = null;
        categoryPlot41.setDataset(0, categoryDataset47);
        java.awt.Paint paint49 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot41.setNoDataMessagePaint(paint49);
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = categoryPlot41.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent53 = null;
        categoryPlot41.rendererChanged(rendererChangeEvent53);
        org.jfree.chart.util.Layer layer56 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection57 = categoryPlot41.getRangeMarkers((int) (byte) -1, layer56);
        boolean boolean59 = categoryPlot0.removeRangeMarker((int) (short) 0, (org.jfree.chart.plot.Marker) valueMarker31, layer56, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier60 = categoryPlot0.getDrawingSupplier();
        org.junit.Assert.assertNotNull(drawingSupplier5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(axisSpace13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 1.0f + "'", float33 == 1.0f);
        org.junit.Assert.assertNotNull(unitType39);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertNotNull(layer56);
        org.junit.Assert.assertNull(collection57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(drawingSupplier60);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        boolean boolean7 = xYPlot0.isDomainCrosshairVisible();
        boolean boolean8 = xYPlot0.isSubplot();
        int int9 = xYPlot0.getDatasetCount();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis11 = xYPlot0.getDomainAxisForDataset(98);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 98 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        xYPlot0.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis5.getTickMarkPaint();
        xYPlot0.setDomainTickBandPaint(paint10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color15, stroke16);
        boolean boolean18 = axisLocation13.equals((java.lang.Object) valueMarker17);
        float float19 = valueMarker17.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = valueMarker17.getLabelAnchor();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean23 = layer21.equals((java.lang.Object) dateRange22);
        java.lang.String str24 = layer21.toString();
        xYPlot0.addDomainMarker((int) (short) 100, (org.jfree.chart.plot.Marker) valueMarker17, layer21);
        xYPlot0.configureDomainAxes();
        java.awt.Font font27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot0.setNoDataMessageFont(font27);
        java.awt.Color color29 = java.awt.Color.PINK;
        xYPlot0.setDomainCrosshairPaint((java.awt.Paint) color29);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Layer.FOREGROUND" + "'", str24.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(color29);
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test142");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        long long3 = day2.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
//        categoryPlot5.setDomainAxis((int) 'a', categoryAxis7);
//        categoryPlot5.setBackgroundImageAlignment((int) (short) 10);
//        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot5.getDatasetGroup();
//        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
//        categoryPlot5.setNoDataMessagePaint(paint12);
//        boolean boolean14 = day2.equals((java.lang.Object) categoryPlot5);
//        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
//        java.awt.Font font19 = null;
//        categoryAxis17.setTickLabelFont((java.lang.Comparable) (byte) -1, font19);
//        java.lang.String str21 = categoryAxis17.getLabelToolTip();
//        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D24 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
//        double double26 = numberAxis22.valueToJava2D((double) 10, rectangle2D24, rectangleEdge25);
//        java.awt.Graphics2D graphics2D27 = null;
//        org.jfree.chart.axis.AxisState axisState28 = null;
//        java.awt.geom.Rectangle2D rectangle2D29 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
//        java.util.List list31 = numberAxis22.refreshTicks(graphics2D27, axisState28, rectangle2D29, rectangleEdge30);
//        numberAxis22.setLabel("RectangleAnchor.TOP_LEFT");
//        numberAxis22.zoomRange((double) (-1L), (double) 1);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis17, (org.jfree.chart.axis.ValueAxis) numberAxis22, categoryItemRenderer37);
//        int int39 = categoryPlot5.getDomainAxisIndex(categoryAxis17);
//        java.lang.Object obj40 = categoryPlot5.clone();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNull(datasetGroup11);
//        org.junit.Assert.assertNotNull(paint12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNull(str21);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
//        org.junit.Assert.assertNotNull(list31);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
//        org.junit.Assert.assertNotNull(obj40);
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        java.lang.Object obj3 = objectList1.get((int) '4');
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color5, stroke6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker7.setOutlineStroke(stroke8);
        java.awt.Stroke stroke10 = valueMarker7.getOutlineStroke();
        boolean boolean11 = objectList1.equals((java.lang.Object) stroke10);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        int int13 = xYPlot12.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        xYPlot12.zoomRangeAxes((double) 255, plotRenderingInfo15, point2D16, true);
        org.jfree.chart.axis.AxisLocation axisLocation20 = null;
        xYPlot12.setRangeAxisLocation(4, axisLocation20);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = numberAxis23.valueToJava2D((double) 10, rectangle2D25, rectangleEdge26);
        boolean boolean28 = numberAxis23.getAutoRangeStickyZero();
        xYPlot12.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis23);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = xYPlot12.getAxisOffset();
        boolean boolean31 = objectList1.equals((java.lang.Object) xYPlot12);
        xYPlot12.setRangeCrosshairValue((double) (short) 0);
        java.util.List list34 = xYPlot12.getAnnotations();
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(list34);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeMinimumSize((double) 11, false);
        numberAxis0.setAutoRangeStickyZero(true);
        double double6 = numberAxis0.getLabelAngle();
        org.jfree.chart.plot.Plot plot7 = numberAxis0.getPlot();
        numberAxis0.resizeRange((double) 7, (double) 10);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(plot7);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        java.awt.Paint paint5 = numberAxis0.getTickMarkPaint();
        numberAxis0.resizeRange((double) 3);
        boolean boolean8 = numberAxis0.getAutoRangeStickyZero();
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color10, stroke11);
        numberAxis0.setAxisLineStroke(stroke11);
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        numberAxis0.setLabelFont(font14);
        java.awt.Font font16 = numberAxis0.getTickLabelFont();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis0.setRange(range10);
        numberAxis0.setFixedDimension(0.2d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker3.setOutlineStroke(stroke4);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker3.setLabelOffsetType(lengthAdjustmentType6);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker3.setLabelAnchor(rectangleAnchor8);
        java.awt.Paint paint10 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        valueMarker3.setPaint(paint10);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) (byte) 100);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = categoryAxis1.getCategoryLabelPositions();
        org.junit.Assert.assertNotNull(categoryLabelPositions4);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis5.zoomRange((double) 0L, (double) 3);
        boolean boolean14 = numberAxis5.isNegativeArrowVisible();
        xYPlot0.setDomainAxis(255, (org.jfree.chart.axis.ValueAxis) numberAxis5, false);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        numberAxis18.setAutoRangeMinimumSize((double) 11, false);
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color23, stroke24);
        numberAxis18.setLabelPaint((java.awt.Paint) color23);
        xYPlot0.setRangeAxis(7, (org.jfree.chart.axis.ValueAxis) numberAxis18, true);
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener31 = null;
        xYPlot0.removeChangeListener(plotChangeListener31);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
//        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
//        categoryPlot0.clearAnnotations();
//        boolean boolean5 = categoryPlot0.isOutlineVisible();
//        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
//        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
//        categoryPlot0.setInsets(rectangleInsets7);
//        categoryPlot0.setWeight((int) (short) 1);
//        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone12 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11, timeZone12);
//        long long14 = day13.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate15 = day13.getSerialDate();
//        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
//        categoryPlot16.setDomainAxis((int) 'a', categoryAxis18);
//        categoryPlot16.setBackgroundImageAlignment((int) (short) 10);
//        org.jfree.data.general.DatasetGroup datasetGroup22 = categoryPlot16.getDatasetGroup();
//        java.awt.Paint paint23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
//        categoryPlot16.setNoDataMessagePaint(paint23);
//        boolean boolean25 = day13.equals((java.lang.Object) categoryPlot16);
//        java.awt.Stroke stroke26 = categoryPlot16.getOutlineStroke();
//        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
//        categoryPlot27.setDomainAxis((int) 'a', categoryAxis29);
//        categoryPlot27.setBackgroundImageAlignment((int) (short) 10);
//        org.jfree.data.general.DatasetGroup datasetGroup33 = categoryPlot27.getDatasetGroup();
//        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot27.getRangeAxisLocation();
//        categoryPlot16.setDomainAxisLocation(axisLocation34);
//        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("");
//        java.awt.Font font40 = null;
//        categoryAxis38.setTickLabelFont((java.lang.Comparable) (byte) -1, font40);
//        int int42 = categoryAxis38.getMaximumCategoryLabelLines();
//        categoryAxis38.setUpperMargin(32.0d);
//        int int45 = categoryAxis38.getMaximumCategoryLabelLines();
//        categoryAxis38.setLowerMargin((double) (short) 1);
//        categoryPlot16.setDomainAxis(0, categoryAxis38, true);
//        categoryPlot0.setDomainAxis(categoryAxis38);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNull(axisSpace6);
//        org.junit.Assert.assertNotNull(rectangleInsets7);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(timeZone12);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560409200000L + "'", long14 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate15);
//        org.junit.Assert.assertNull(datasetGroup22);
//        org.junit.Assert.assertNotNull(paint23);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(stroke26);
//        org.junit.Assert.assertNull(datasetGroup33);
//        org.junit.Assert.assertNotNull(axisLocation34);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        categoryPlot7.setDomainAxis((int) 'a', categoryAxis9);
        categoryPlot7.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        categoryPlot7.setDataset(0, categoryDataset13);
        java.awt.Paint paint15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot7.setNoDataMessagePaint(paint15);
        java.awt.Paint paint17 = categoryPlot7.getOutlinePaint();
        int int18 = categoryPlot7.getDomainAxisCount();
        java.lang.Class<?> wildcardClass19 = categoryPlot7.getClass();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        categoryPlot21.setDomainAxis((int) 'a', categoryAxis23);
        categoryPlot21.clearAnnotations();
        boolean boolean26 = categoryPlot21.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace27 = categoryPlot21.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot21.setInsets(rectangleInsets28);
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation31 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation30, plotOrientation31);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor33 = org.jfree.chart.axis.CategoryAnchor.END;
        boolean boolean34 = axisLocation30.equals((java.lang.Object) categoryAnchor33);
        categoryPlot21.setRangeAxisLocation(axisLocation30, false);
        categoryPlot7.setRangeAxisLocation((int) (short) 10, axisLocation30, false);
        xYPlot0.setRangeAxisLocation(axisLocation30, true);
        int int41 = xYPlot0.getRangeAxisCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 98 + "'", int18 == 98);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(axisSpace27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(plotOrientation31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(categoryAnchor33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryAxis1.equals(obj2);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(false);
        boolean boolean11 = categoryAxis1.equals((java.lang.Object) 1.0d);
        int int12 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setLowerMargin((double) 10);
        categoryAxis1.clearCategoryLabelToolTips();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        xYPlot0.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis5.getTickMarkPaint();
        xYPlot0.setDomainTickBandPaint(paint10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color15, stroke16);
        boolean boolean18 = axisLocation13.equals((java.lang.Object) valueMarker17);
        float float19 = valueMarker17.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = valueMarker17.getLabelAnchor();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean23 = layer21.equals((java.lang.Object) dateRange22);
        java.lang.String str24 = layer21.toString();
        xYPlot0.addDomainMarker((int) (short) 100, (org.jfree.chart.plot.Marker) valueMarker17, layer21);
        java.awt.Stroke stroke26 = xYPlot0.getDomainCrosshairStroke();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Layer.FOREGROUND" + "'", str24.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        boolean boolean7 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        int int12 = xYPlot11.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot11.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        int int17 = xYPlot16.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = xYPlot16.getRangeAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        categoryPlot19.setDomainAxis((int) 'a', categoryAxis21);
        categoryPlot19.clearAnnotations();
        boolean boolean24 = categoryPlot19.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace25 = categoryPlot19.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot19.setInsets(rectangleInsets26);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot19.getDomainAxisEdge((int) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis();
        numberAxis31.setAutoRangeMinimumSize((double) 11, false);
        numberAxis31.setAutoRangeStickyZero(true);
        double double37 = numberAxis31.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        double double42 = numberAxis38.valueToJava2D((double) 10, rectangle2D40, rectangleEdge41);
        org.jfree.data.Range range43 = numberAxis38.getDefaultAutoRange();
        numberAxis31.setRange(range43, true, true);
        java.awt.Color color47 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis31.setTickMarkPaint((java.awt.Paint) color47);
        categoryPlot19.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis31);
        categoryPlot19.clearRangeMarkers();
        java.awt.Color color52 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke53 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker54 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color52, stroke53);
        java.awt.Stroke stroke55 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker54.setOutlineStroke(stroke55);
        java.awt.Stroke stroke57 = valueMarker54.getStroke();
        categoryPlot19.setDomainGridlineStroke(stroke57);
        xYPlot16.setRangeGridlineStroke(stroke57);
        org.jfree.chart.axis.NumberAxis numberAxis61 = new org.jfree.chart.axis.NumberAxis();
        numberAxis61.setAutoRangeMinimumSize((double) 11, false);
        numberAxis61.setAutoRangeStickyZero(true);
        double double67 = numberAxis61.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis68 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = null;
        double double72 = numberAxis68.valueToJava2D((double) 10, rectangle2D70, rectangleEdge71);
        org.jfree.data.Range range73 = numberAxis68.getDefaultAutoRange();
        numberAxis61.setRange(range73, true, true);
        xYPlot16.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis61);
        org.jfree.chart.plot.CategoryPlot categoryPlot78 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis80 = null;
        categoryPlot78.setDomainAxis((int) 'a', categoryAxis80);
        categoryPlot78.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset84 = null;
        categoryPlot78.setDataset(0, categoryDataset84);
        float float86 = categoryPlot78.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets87 = categoryPlot78.getAxisOffset();
        java.awt.Color color88 = java.awt.Color.red;
        categoryPlot78.setRangeGridlinePaint((java.awt.Paint) color88);
        xYPlot16.setDomainCrosshairPaint((java.awt.Paint) color88);
        java.awt.geom.Point2D point2D91 = xYPlot16.getQuadrantOrigin();
        xYPlot11.zoomDomainAxes((double) 1560409200000L, plotRenderingInfo15, point2D91, true);
        xYPlot0.zoomDomainAxes(32.0d, (double) (byte) 1, plotRenderingInfo10, point2D91);
        java.awt.Graphics2D graphics2D95 = null;
        java.awt.geom.Rectangle2D rectangle2D96 = null;
        try {
            xYPlot0.drawBackground(graphics2D95, rectangle2D96);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(axisSpace25);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(range73);
        org.junit.Assert.assertTrue("'" + float86 + "' != '" + 1.0f + "'", float86 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets87);
        org.junit.Assert.assertNotNull(color88);
        org.junit.Assert.assertNotNull(point2D91);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        xYPlot0.setRangeAxisLocation(4, axisLocation8);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = numberAxis11.valueToJava2D((double) 10, rectangle2D13, rectangleEdge14);
        boolean boolean16 = numberAxis11.getAutoRangeStickyZero();
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis11);
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.LegendItemCollection legendItemCollection20 = xYPlot0.getLegendItems();
        org.jfree.data.xy.XYDataset xYDataset22 = xYPlot0.getDataset(98);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(legendItemCollection20);
        org.junit.Assert.assertNull(xYDataset22);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        java.lang.Object obj3 = objectList1.get((int) '4');
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color5, stroke6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker7.setOutlineStroke(stroke8);
        java.awt.Stroke stroke10 = valueMarker7.getOutlineStroke();
        boolean boolean11 = objectList1.equals((java.lang.Object) stroke10);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        int int13 = xYPlot12.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        xYPlot12.zoomRangeAxes((double) 255, plotRenderingInfo15, point2D16, true);
        org.jfree.chart.axis.AxisLocation axisLocation20 = null;
        xYPlot12.setRangeAxisLocation(4, axisLocation20);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = numberAxis23.valueToJava2D((double) 10, rectangle2D25, rectangleEdge26);
        boolean boolean28 = numberAxis23.getAutoRangeStickyZero();
        xYPlot12.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis23);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = xYPlot12.getAxisOffset();
        boolean boolean31 = objectList1.equals((java.lang.Object) xYPlot12);
        xYPlot12.setRangeCrosshairValue((double) (short) 0);
        xYPlot12.setOutlineVisible(true);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundAlpha((float) 4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        int int4 = categoryPlot0.getIndexOf(categoryItemRenderer3);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color6, stroke7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker8.setOutlineStroke(stroke9);
        java.awt.Stroke stroke11 = valueMarker8.getOutlineStroke();
        categoryPlot0.setOutlineStroke(stroke11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = categoryPlot0.getRenderer();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        categoryPlot0.setDataset(categoryDataset14);
        float float16 = categoryPlot0.getBackgroundAlpha();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(categoryItemRenderer13);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 4.0f + "'", float16 == 4.0f);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color6, stroke7);
        boolean boolean9 = axisLocation4.equals((java.lang.Object) valueMarker8);
        categoryPlot0.setDomainAxisLocation(axisLocation4);
        java.lang.String str11 = axisLocation4.toString();
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str11.equals("AxisLocation.BOTTOM_OR_LEFT"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean2 = layer0.equals((java.lang.Object) dateRange1);
        java.lang.String str3 = layer0.toString();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis6);
        categoryPlot4.setBackgroundImageAlignment((int) (short) 10);
        float float10 = categoryPlot4.getBackgroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot4.getRangeAxisLocation();
        boolean boolean12 = layer0.equals((java.lang.Object) categoryPlot4);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj15 = null;
        boolean boolean16 = categoryAxis14.equals(obj15);
        categoryAxis14.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis14.clearCategoryLabelToolTips();
        boolean boolean21 = categoryPlot4.equals((java.lang.Object) categoryAxis14);
        org.junit.Assert.assertNotNull(layer0);
        org.junit.Assert.assertNotNull(dateRange1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Layer.FOREGROUND" + "'", str3.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeMinimumSize((double) 11, false);
        numberAxis0.setAutoRangeIncludesZero(false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        xYPlot0.setRangeAxisLocation(4, axisLocation8);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = xYPlot0.getSeriesRenderingOrder();
        java.util.List list11 = xYPlot0.getAnnotations();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        xYPlot0.rendererChanged(rendererChangeEvent12);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker3.setOutlineStroke(stroke4);
        java.lang.String str6 = valueMarker3.getLabel();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        java.awt.Paint paint10 = categoryPlot0.getOutlinePaint();
        int int11 = categoryPlot0.getDomainAxisCount();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot0.setRenderer(categoryItemRenderer12, true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 98 + "'", int11 == 98);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        java.util.List list9 = numberAxis0.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge8);
        numberAxis0.setLabel("RectangleAnchor.TOP_LEFT");
        numberAxis0.zoomRange((double) (-1L), (double) 1);
        java.text.NumberFormat numberFormat15 = null;
        numberAxis0.setNumberFormatOverride(numberFormat15);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder2 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot7.setRenderer(categoryItemRenderer8, false);
        int int11 = categoryPlot7.getWeight();
        int int12 = categoryPlot7.getDatasetCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation18 = null;
        xYPlot16.setRangeAxisLocation((int) (short) 100, axisLocation18);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = numberAxis21.valueToJava2D((double) 10, rectangle2D23, rectangleEdge24);
        org.jfree.data.Range range26 = numberAxis21.getDefaultAutoRange();
        numberAxis21.zoomRange((double) 0L, (double) 3);
        boolean boolean30 = numberAxis21.isNegativeArrowVisible();
        xYPlot16.setDomainAxis(255, (org.jfree.chart.axis.ValueAxis) numberAxis21, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder33 = xYPlot16.getDatasetRenderingOrder();
        java.awt.geom.Point2D point2D34 = xYPlot16.getQuadrantOrigin();
        categoryPlot7.zoomRangeAxes((double) 5, (double) 0, plotRenderingInfo15, point2D34);
        xYPlot0.zoomDomainAxes(1.0d, 0.0d, plotRenderingInfo6, point2D34);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(seriesRenderingOrder2);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder33);
        org.junit.Assert.assertNotNull(point2D34);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.data.general.DatasetGroup datasetGroup6 = categoryPlot0.getDatasetGroup();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        categoryPlot0.setBackgroundImageAlignment(7);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color12, stroke13);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker14.setOutlineStroke(stroke15);
        categoryPlot0.setDomainGridlineStroke(stroke15);
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 4, 62.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.data.Range range5 = numberAxis0.getDefaultAutoRange();
        numberAxis0.setLabelAngle(2.0d);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.setRange((double) (byte) 10, 100.0d);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setRange((double) (byte) 10, 100.0d);
        org.jfree.chart.axis.Timeline timeline16 = null;
        dateAxis12.setTimeline(timeline16);
        org.jfree.chart.axis.Timeline timeline18 = null;
        dateAxis12.setTimeline(timeline18);
        org.jfree.chart.axis.DateTickUnit dateTickUnit20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date21 = dateAxis12.calculateHighestVisibleTickValue(dateTickUnit20);
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = dateAxis8.dateToJava2D(date21, rectangle2D22, rectangleEdge23);
        boolean boolean25 = numberAxis0.equals((java.lang.Object) double24);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(dateTickUnit20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis0.setRange(range10);
        numberAxis0.setRangeAboutValue((double) (short) -1, 0.0d);
        double double15 = numberAxis0.getLowerBound();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.0d) + "'", double15 == (-1.0d));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        categoryPlot0.setDataset(categoryDataset1);
        categoryPlot0.clearAnnotations();
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        java.lang.Object obj3 = objectList1.get((int) '4');
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color5, stroke6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker7.setOutlineStroke(stroke8);
        java.awt.Stroke stroke10 = valueMarker7.getOutlineStroke();
        boolean boolean11 = objectList1.equals((java.lang.Object) stroke10);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        int int13 = xYPlot12.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        xYPlot12.zoomRangeAxes((double) 255, plotRenderingInfo15, point2D16, true);
        org.jfree.chart.axis.AxisLocation axisLocation20 = null;
        xYPlot12.setRangeAxisLocation(4, axisLocation20);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = numberAxis23.valueToJava2D((double) 10, rectangle2D25, rectangleEdge26);
        boolean boolean28 = numberAxis23.getAutoRangeStickyZero();
        xYPlot12.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis23);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = xYPlot12.getAxisOffset();
        boolean boolean31 = objectList1.equals((java.lang.Object) xYPlot12);
        xYPlot12.setRangeCrosshairValue((double) (short) 0);
        org.jfree.data.general.Dataset dataset35 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent36 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 3.0d, dataset35);
        xYPlot12.datasetChanged(datasetChangeEvent36);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        float float6 = categoryPlot0.getBackgroundAlpha();
        org.jfree.chart.axis.AxisSpace axisSpace7 = categoryPlot0.getFixedRangeAxisSpace();
        java.awt.Paint paint8 = null;
        categoryPlot0.setOutlinePaint(paint8);
        java.awt.Font font10 = null;
        try {
            categoryPlot0.setNoDataMessageFont(font10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNull(axisSpace7);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        java.awt.Paint paint2 = xYPlot0.getRangeGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation(5);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis((int) 'a', categoryAxis7);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = categoryPlot5.getDrawingSupplier();
        boolean boolean10 = categoryPlot5.isDomainZoomable();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        double double17 = rectangleInsets15.calculateLeftInset((double) (-1));
        double double18 = rectangleInsets15.getTop();
        boolean boolean19 = categoryPlot5.equals((java.lang.Object) double18);
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        int int21 = xYPlot20.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = xYPlot20.getRangeAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        categoryPlot23.setDomainAxis((int) 'a', categoryAxis25);
        categoryPlot23.clearAnnotations();
        boolean boolean28 = categoryPlot23.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace29 = categoryPlot23.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot23.setInsets(rectangleInsets30);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = categoryPlot23.getDomainAxisEdge((int) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis();
        numberAxis35.setAutoRangeMinimumSize((double) 11, false);
        numberAxis35.setAutoRangeStickyZero(true);
        double double41 = numberAxis35.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = null;
        double double46 = numberAxis42.valueToJava2D((double) 10, rectangle2D44, rectangleEdge45);
        org.jfree.data.Range range47 = numberAxis42.getDefaultAutoRange();
        numberAxis35.setRange(range47, true, true);
        java.awt.Color color51 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis35.setTickMarkPaint((java.awt.Paint) color51);
        categoryPlot23.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis35);
        categoryPlot23.clearRangeMarkers();
        java.awt.Color color56 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke57 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker58 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color56, stroke57);
        java.awt.Stroke stroke59 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker58.setOutlineStroke(stroke59);
        java.awt.Stroke stroke61 = valueMarker58.getStroke();
        categoryPlot23.setDomainGridlineStroke(stroke61);
        xYPlot20.setRangeGridlineStroke(stroke61);
        categoryPlot5.setDomainGridlineStroke(stroke61);
        xYPlot0.setDomainGridlineStroke(stroke61);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(drawingSupplier9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 32.0d + "'", double17 == 32.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 52.0d + "'", double18 == 52.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(axisSpace29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(stroke61);
    }

//    @Test
//    public void test174() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test174");
//        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
//        org.jfree.chart.JFreeChart jFreeChart1 = null;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis0, jFreeChart1);
//        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
//        dateAxis0.setRange((org.jfree.data.Range) dateRange3);
//        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date5, timeZone6);
//        long long8 = day7.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate9 = day7.getSerialDate();
//        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
//        categoryPlot10.setDomainAxis((int) 'a', categoryAxis12);
//        categoryPlot10.setBackgroundImageAlignment((int) (short) 10);
//        org.jfree.data.general.DatasetGroup datasetGroup16 = categoryPlot10.getDatasetGroup();
//        java.awt.Paint paint17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
//        categoryPlot10.setNoDataMessagePaint(paint17);
//        boolean boolean19 = day7.equals((java.lang.Object) categoryPlot10);
//        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("");
//        java.awt.Font font24 = null;
//        categoryAxis22.setTickLabelFont((java.lang.Comparable) (byte) -1, font24);
//        java.lang.String str26 = categoryAxis22.getLabelToolTip();
//        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D29 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
//        double double31 = numberAxis27.valueToJava2D((double) 10, rectangle2D29, rectangleEdge30);
//        java.awt.Graphics2D graphics2D32 = null;
//        org.jfree.chart.axis.AxisState axisState33 = null;
//        java.awt.geom.Rectangle2D rectangle2D34 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge35 = null;
//        java.util.List list36 = numberAxis27.refreshTicks(graphics2D32, axisState33, rectangle2D34, rectangleEdge35);
//        numberAxis27.setLabel("RectangleAnchor.TOP_LEFT");
//        numberAxis27.zoomRange((double) (-1L), (double) 1);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis22, (org.jfree.chart.axis.ValueAxis) numberAxis27, categoryItemRenderer42);
//        int int44 = categoryPlot10.getDomainAxisIndex(categoryAxis22);
//        java.util.Date date45 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date45, timeZone46);
//        java.awt.Paint paint48 = categoryAxis22.getTickLabelPaint((java.lang.Comparable) date45);
//        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date45, timeZone49);
//        java.awt.geom.Rectangle2D rectangle2D51 = null;
//        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot();
//        int int53 = xYPlot52.getDomainAxisCount();
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo55 = null;
//        java.awt.geom.Point2D point2D56 = null;
//        xYPlot52.zoomRangeAxes((double) 255, plotRenderingInfo55, point2D56, true);
//        org.jfree.chart.plot.CategoryPlot categoryPlot59 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis61 = null;
//        categoryPlot59.setDomainAxis((int) 'a', categoryAxis61);
//        categoryPlot59.clearAnnotations();
//        org.jfree.data.category.CategoryDataset categoryDataset65 = null;
//        categoryPlot59.setDataset(0, categoryDataset65);
//        java.awt.Paint paint67 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
//        categoryPlot59.setNoDataMessagePaint(paint67);
//        java.awt.Paint paint69 = categoryPlot59.getOutlinePaint();
//        int int70 = categoryPlot59.getDomainAxisCount();
//        java.lang.Class<?> wildcardClass71 = categoryPlot59.getClass();
//        org.jfree.chart.plot.CategoryPlot categoryPlot73 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis75 = null;
//        categoryPlot73.setDomainAxis((int) 'a', categoryAxis75);
//        categoryPlot73.clearAnnotations();
//        boolean boolean78 = categoryPlot73.isOutlineVisible();
//        org.jfree.chart.axis.AxisSpace axisSpace79 = categoryPlot73.getFixedDomainAxisSpace();
//        org.jfree.chart.util.RectangleInsets rectangleInsets80 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
//        categoryPlot73.setInsets(rectangleInsets80);
//        org.jfree.chart.axis.AxisLocation axisLocation82 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
//        org.jfree.chart.plot.PlotOrientation plotOrientation83 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
//        org.jfree.chart.util.RectangleEdge rectangleEdge84 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation82, plotOrientation83);
//        org.jfree.chart.axis.CategoryAnchor categoryAnchor85 = org.jfree.chart.axis.CategoryAnchor.END;
//        boolean boolean86 = axisLocation82.equals((java.lang.Object) categoryAnchor85);
//        categoryPlot73.setRangeAxisLocation(axisLocation82, false);
//        categoryPlot59.setRangeAxisLocation((int) (short) 10, axisLocation82, false);
//        xYPlot52.setRangeAxisLocation(axisLocation82, true);
//        org.jfree.chart.util.RectangleEdge rectangleEdge93 = xYPlot52.getRangeAxisEdge();
//        try {
//            double double94 = dateAxis0.dateToJava2D(date45, rectangle2D51, rectangleEdge93);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(dateRange3);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560409200000L + "'", long8 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertNull(datasetGroup16);
//        org.junit.Assert.assertNotNull(paint17);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNull(str26);
//        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
//        org.junit.Assert.assertNotNull(list36);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1) + "'", int44 == (-1));
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertNotNull(timeZone46);
//        org.junit.Assert.assertNotNull(paint48);
//        org.junit.Assert.assertNotNull(timeZone49);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//        org.junit.Assert.assertNotNull(paint67);
//        org.junit.Assert.assertNotNull(paint69);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 98 + "'", int70 == 98);
//        org.junit.Assert.assertNotNull(wildcardClass71);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
//        org.junit.Assert.assertNull(axisSpace79);
//        org.junit.Assert.assertNotNull(rectangleInsets80);
//        org.junit.Assert.assertNotNull(axisLocation82);
//        org.junit.Assert.assertNotNull(plotOrientation83);
//        org.junit.Assert.assertNotNull(rectangleEdge84);
//        org.junit.Assert.assertNotNull(categoryAnchor85);
//        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
//        org.junit.Assert.assertNotNull(rectangleEdge93);
//    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        boolean boolean7 = categoryPlot0.isRangeZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot0.getRendererForDataset(categoryDataset8);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font14 = null;
        categoryAxis12.setTickLabelFont((java.lang.Comparable) (byte) -1, font14);
        java.lang.String str16 = categoryAxis12.getLabelToolTip();
        categoryPlot0.setDomainAxis(6, categoryAxis12, false);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        try {
            org.jfree.chart.axis.AxisState axisState25 = categoryAxis12.draw(graphics2D19, (double) (byte) 1, rectangle2D21, rectangle2D22, rectangleEdge23, plotRenderingInfo24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNull(str16);
    }

//    @Test
//    public void test176() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test176");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        long long3 = day2.getFirstMillisecond();
//        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
//        numberAxis4.setAutoRangeMinimumSize((double) 11, false);
//        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_GREEN;
//        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color9, stroke10);
//        numberAxis4.setLabelPaint((java.awt.Paint) color9);
//        numberAxis4.setPositiveArrowVisible(true);
//        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = numberAxis4.getTickUnit();
//        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D18 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
//        double double20 = numberAxis16.valueToJava2D((double) 10, rectangle2D18, rectangleEdge19);
//        org.jfree.data.Range range21 = numberAxis16.getDefaultAutoRange();
//        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D24 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
//        double double26 = numberAxis22.valueToJava2D((double) 10, rectangle2D24, rectangleEdge25);
//        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D29 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
//        double double31 = numberAxis27.valueToJava2D((double) 10, rectangle2D29, rectangleEdge30);
//        org.jfree.data.Range range32 = numberAxis27.getDefaultAutoRange();
//        numberAxis22.setRange(range32);
//        numberAxis16.setDefaultAutoRange(range32);
//        numberAxis16.setAutoRangeMinimumSize((double) 1, true);
//        org.jfree.data.Range range38 = numberAxis16.getDefaultAutoRange();
//        numberAxis4.setRangeWithMargins(range38, true, false);
//        boolean boolean42 = day2.equals((java.lang.Object) numberAxis4);
//        org.jfree.chart.JFreeChart jFreeChart43 = null;
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType44 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent45 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberAxis4, jFreeChart43, chartChangeEventType44);
//        org.jfree.chart.JFreeChart jFreeChart46 = chartChangeEvent45.getChart();
//        org.jfree.chart.JFreeChart jFreeChart47 = chartChangeEvent45.getChart();
//        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis();
//        org.jfree.chart.JFreeChart jFreeChart49 = null;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent50 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis48, jFreeChart49);
//        org.jfree.chart.JFreeChart jFreeChart51 = null;
//        chartChangeEvent50.setChart(jFreeChart51);
//        org.jfree.chart.JFreeChart jFreeChart53 = null;
//        chartChangeEvent50.setChart(jFreeChart53);
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType55 = chartChangeEvent50.getType();
//        chartChangeEvent45.setType(chartChangeEventType55);
//        java.lang.Object obj57 = chartChangeEvent45.getSource();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(color9);
//        org.junit.Assert.assertNotNull(stroke10);
//        org.junit.Assert.assertNotNull(numberTickUnit15);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
//        org.junit.Assert.assertNotNull(range21);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
//        org.junit.Assert.assertNotNull(range32);
//        org.junit.Assert.assertNotNull(range38);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(chartChangeEventType44);
//        org.junit.Assert.assertNull(jFreeChart46);
//        org.junit.Assert.assertNull(jFreeChart47);
//        org.junit.Assert.assertNotNull(chartChangeEventType55);
//        org.junit.Assert.assertNotNull(obj57);
//    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color1, stroke2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = valueMarker3.getLabelAnchor();
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color6, stroke7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker8.setOutlineStroke(stroke9);
        java.awt.Stroke stroke11 = valueMarker8.getOutlineStroke();
        valueMarker3.setStroke(stroke11);
        org.jfree.chart.text.TextAnchor textAnchor13 = valueMarker3.getLabelTextAnchor();
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color15, stroke16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker17.setOutlineStroke(stroke18);
        java.awt.Paint paint20 = valueMarker17.getOutlinePaint();
        java.lang.String str21 = valueMarker17.getLabel();
        valueMarker17.setAlpha(0.0f);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        valueMarker17.setStroke(stroke24);
        valueMarker3.setStroke(stroke24);
        java.lang.String str27 = valueMarker3.getLabel();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType28 = null;
        try {
            valueMarker3.setLabelOffsetType(lengthAdjustmentType28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'adj' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(str27);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryAxis1.equals(obj2);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(false);
        boolean boolean11 = categoryAxis1.equals((java.lang.Object) 1.0d);
        int int12 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setLowerMargin((double) 10);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = numberAxis15.valueToJava2D((double) 10, rectangle2D17, rectangleEdge18);
        org.jfree.data.Range range20 = numberAxis15.getDefaultAutoRange();
        java.awt.Font font21 = numberAxis15.getTickLabelFont();
        categoryAxis1.setTickLabelFont(font21);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        categoryPlot23.setDomainAxis((int) 'a', categoryAxis25);
        categoryPlot23.setBackgroundImageAlignment((int) (short) 10);
        float float29 = categoryPlot23.getBackgroundAlpha();
        org.jfree.chart.axis.AxisSpace axisSpace30 = categoryPlot23.getFixedRangeAxisSpace();
        java.awt.Paint paint31 = null;
        categoryPlot23.setOutlinePaint(paint31);
        boolean boolean33 = categoryAxis1.equals((java.lang.Object) paint31);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 1.0f + "'", float29 == 1.0f);
        org.junit.Assert.assertNull(axisSpace30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis0.setRange(range10);
        numberAxis0.resizeRange((double) 9, (double) 5);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        xYPlot0.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis6.valueToJava2D((double) 10, rectangle2D8, rectangleEdge9);
        org.jfree.data.Range range11 = numberAxis6.getDefaultAutoRange();
        java.awt.Font font12 = numberAxis6.getTickLabelFont();
        numberAxis6.setAutoRange(false);
        xYPlot0.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis6, false);
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color17);
        xYPlot0.clearDomainAxes();
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        categoryPlot0.setDataset(categoryDataset2);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis4.valueToJava2D((double) 10, rectangle2D6, rectangleEdge7);
        org.jfree.data.Range range9 = numberAxis4.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = numberAxis10.valueToJava2D((double) 10, rectangle2D12, rectangleEdge13);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = numberAxis15.valueToJava2D((double) 10, rectangle2D17, rectangleEdge18);
        org.jfree.data.Range range20 = numberAxis15.getDefaultAutoRange();
        numberAxis10.setRange(range20);
        numberAxis4.setDefaultAutoRange(range20);
        org.jfree.chart.axis.TickUnitSource tickUnitSource23 = null;
        numberAxis4.setStandardTickUnits(tickUnitSource23);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit25 = numberAxis4.getTickUnit();
        numberAxis4.setAxisLineVisible(true);
        org.jfree.data.Range range28 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis4);
        java.awt.Font font29 = categoryPlot0.getNoDataMessageFont();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(numberTickUnit25);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(font29);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = categoryPlot0.getDrawingSupplier();
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        double double12 = rectangleInsets10.calculateLeftInset((double) (-1));
        double double13 = rectangleInsets10.getTop();
        boolean boolean14 = categoryPlot0.equals((java.lang.Object) double13);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        int int16 = xYPlot15.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot15.getRangeAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot18.setDomainAxis((int) 'a', categoryAxis20);
        categoryPlot18.clearAnnotations();
        boolean boolean23 = categoryPlot18.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace24 = categoryPlot18.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot18.setInsets(rectangleInsets25);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot18.getDomainAxisEdge((int) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis();
        numberAxis30.setAutoRangeMinimumSize((double) 11, false);
        numberAxis30.setAutoRangeStickyZero(true);
        double double36 = numberAxis30.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = numberAxis37.valueToJava2D((double) 10, rectangle2D39, rectangleEdge40);
        org.jfree.data.Range range42 = numberAxis37.getDefaultAutoRange();
        numberAxis30.setRange(range42, true, true);
        java.awt.Color color46 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis30.setTickMarkPaint((java.awt.Paint) color46);
        categoryPlot18.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis30);
        categoryPlot18.clearRangeMarkers();
        java.awt.Color color51 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke52 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker53 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color51, stroke52);
        java.awt.Stroke stroke54 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker53.setOutlineStroke(stroke54);
        java.awt.Stroke stroke56 = valueMarker53.getStroke();
        categoryPlot18.setDomainGridlineStroke(stroke56);
        xYPlot15.setRangeGridlineStroke(stroke56);
        categoryPlot0.setDomainGridlineStroke(stroke56);
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = null;
        categoryPlot60.setDomainAxis((int) 'a', categoryAxis62);
        categoryPlot60.clearAnnotations();
        boolean boolean65 = categoryPlot60.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace66 = categoryPlot60.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot60.setInsets(rectangleInsets67);
        org.jfree.chart.axis.AxisLocation axisLocation69 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation70 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation69, plotOrientation70);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor72 = org.jfree.chart.axis.CategoryAnchor.END;
        boolean boolean73 = axisLocation69.equals((java.lang.Object) categoryAnchor72);
        categoryPlot60.setRangeAxisLocation(axisLocation69, false);
        org.jfree.chart.axis.AxisLocation axisLocation77 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot60.setRangeAxisLocation(98, axisLocation77, true);
        java.awt.Stroke stroke80 = categoryPlot60.getRangeCrosshairStroke();
        categoryPlot0.setRangeCrosshairStroke(stroke80);
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 32.0d + "'", double12 == 32.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 52.0d + "'", double13 == 52.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(axisSpace24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNull(axisSpace66);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertNotNull(axisLocation69);
        org.junit.Assert.assertNotNull(plotOrientation70);
        org.junit.Assert.assertNotNull(rectangleEdge71);
        org.junit.Assert.assertNotNull(categoryAnchor72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(axisLocation77);
        org.junit.Assert.assertNotNull(stroke80);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color2, stroke3);
        boolean boolean5 = axisLocation0.equals((java.lang.Object) valueMarker4);
        float float6 = valueMarker4.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = valueMarker4.getLabelAnchor();
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        int int9 = xYPlot8.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot8.zoomRangeAxes((double) 255, plotRenderingInfo11, point2D12, true);
        boolean boolean15 = xYPlot8.isDomainCrosshairVisible();
        boolean boolean16 = xYPlot8.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = numberAxis17.valueToJava2D((double) 10, rectangle2D19, rectangleEdge20);
        org.jfree.data.Range range22 = numberAxis17.getDefaultAutoRange();
        numberAxis17.zoomRange((double) 0L, (double) 3);
        int int26 = xYPlot8.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis17);
        java.awt.Paint paint27 = xYPlot8.getRangeZeroBaselinePaint();
        valueMarker4.setLabelPaint(paint27);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        float float6 = categoryPlot0.getBackgroundAlpha();
        categoryPlot0.setRangeCrosshairValue((double) 8, true);
        java.awt.Paint paint10 = categoryPlot0.getRangeGridlinePaint();
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot0.getRowRenderingOrder();
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(sortOrder11);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot0.setInsets(rectangleInsets7);
        double double10 = rectangleInsets7.calculateLeftOutset((double) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        boolean boolean7 = xYPlot0.isDomainCrosshairVisible();
        boolean boolean8 = xYPlot0.isSubplot();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        int int10 = color9.getRGB();
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color9);
        boolean boolean12 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Paint paint13 = xYPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-128) + "'", int10 == (-128));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        xYPlot0.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis5.getTickMarkPaint();
        xYPlot0.setDomainTickBandPaint(paint10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color15, stroke16);
        boolean boolean18 = axisLocation13.equals((java.lang.Object) valueMarker17);
        float float19 = valueMarker17.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = valueMarker17.getLabelAnchor();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean23 = layer21.equals((java.lang.Object) dateRange22);
        java.lang.String str24 = layer21.toString();
        xYPlot0.addDomainMarker((int) (short) 100, (org.jfree.chart.plot.Marker) valueMarker17, layer21);
        java.awt.Paint paint26 = xYPlot0.getRangeZeroBaselinePaint();
        java.awt.Stroke stroke27 = xYPlot0.getRangeGridlineStroke();
        xYPlot0.configureDomainAxes();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Layer.FOREGROUND" + "'", str24.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        float float8 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot0.getAxisOffset();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj12 = null;
        boolean boolean13 = categoryAxis11.equals(obj12);
        categoryAxis11.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis11.clearCategoryLabelToolTips();
        categoryPlot0.setDomainAxis(categoryAxis11);
        org.jfree.chart.axis.AxisLocation axisLocation20 = null;
        categoryPlot0.setRangeAxisLocation(255, axisLocation20);
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color25, stroke26);
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker27.setOutlineStroke(stroke28);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType30 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker27.setLabelOffsetType(lengthAdjustmentType30);
        boolean boolean32 = xYPlot23.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker27);
        org.jfree.chart.LegendItemCollection legendItemCollection33 = xYPlot23.getFixedLegendItems();
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        categoryPlot34.setDomainAxis((int) 'a', categoryAxis36);
        categoryPlot34.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset40 = null;
        categoryPlot34.setDataset(0, categoryDataset40);
        java.awt.Paint paint42 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot34.setNoDataMessagePaint(paint42);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = categoryPlot34.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent46 = null;
        categoryPlot34.rendererChanged(rendererChangeEvent46);
        org.jfree.chart.util.Layer layer49 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection50 = categoryPlot34.getRangeMarkers((int) (byte) -1, layer49);
        java.util.Collection collection51 = xYPlot23.getRangeMarkers(layer49);
        org.jfree.chart.axis.AxisLocation axisLocation52 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot23.setRangeAxisLocation(axisLocation52);
        org.jfree.chart.axis.AxisLocation axisLocation54 = axisLocation52.getOpposite();
        categoryPlot0.setRangeAxisLocation(64, axisLocation52, false);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(lengthAdjustmentType30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(legendItemCollection33);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertNotNull(layer49);
        org.junit.Assert.assertNull(collection50);
        org.junit.Assert.assertNull(collection51);
        org.junit.Assert.assertNotNull(axisLocation52);
        org.junit.Assert.assertNotNull(axisLocation54);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryAxis1.equals(obj2);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(false);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot11.setDomainAxis((int) 'a', categoryAxis13);
        categoryPlot11.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        categoryPlot11.setDataset(0, categoryDataset17);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot11.setNoDataMessagePaint(paint19);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot11.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        categoryPlot11.rendererChanged(rendererChangeEvent23);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection27 = categoryPlot11.getRangeMarkers((int) (byte) -1, layer26);
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        org.jfree.chart.axis.AxisSpace axisSpace30 = null;
        org.jfree.chart.axis.AxisSpace axisSpace31 = categoryAxis1.reserveSpace(graphics2D10, (org.jfree.chart.plot.Plot) categoryPlot11, rectangle2D28, rectangleEdge29, axisSpace30);
        org.jfree.chart.plot.Plot plot32 = categoryAxis1.getPlot();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertNotNull(axisSpace31);
        org.junit.Assert.assertNull(plot32);
    }

//    @Test
//    public void test190() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test190");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        long long3 = day2.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
//        categoryPlot5.setDomainAxis((int) 'a', categoryAxis7);
//        categoryPlot5.setBackgroundImageAlignment((int) (short) 10);
//        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot5.getDatasetGroup();
//        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
//        categoryPlot5.setNoDataMessagePaint(paint12);
//        boolean boolean14 = day2.equals((java.lang.Object) categoryPlot5);
//        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
//        java.awt.Font font19 = null;
//        categoryAxis17.setTickLabelFont((java.lang.Comparable) (byte) -1, font19);
//        java.lang.String str21 = categoryAxis17.getLabelToolTip();
//        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D24 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
//        double double26 = numberAxis22.valueToJava2D((double) 10, rectangle2D24, rectangleEdge25);
//        java.awt.Graphics2D graphics2D27 = null;
//        org.jfree.chart.axis.AxisState axisState28 = null;
//        java.awt.geom.Rectangle2D rectangle2D29 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
//        java.util.List list31 = numberAxis22.refreshTicks(graphics2D27, axisState28, rectangle2D29, rectangleEdge30);
//        numberAxis22.setLabel("RectangleAnchor.TOP_LEFT");
//        numberAxis22.zoomRange((double) (-1L), (double) 1);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis17, (org.jfree.chart.axis.ValueAxis) numberAxis22, categoryItemRenderer37);
//        int int39 = categoryPlot5.getDomainAxisIndex(categoryAxis17);
//        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
//        categoryPlot40.setDomainAxis((int) 'a', categoryAxis42);
//        categoryPlot40.clearAnnotations();
//        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
//        categoryPlot40.setDataset(0, categoryDataset46);
//        java.awt.Paint paint48 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
//        categoryPlot40.setNoDataMessagePaint(paint48);
//        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent50 = null;
//        categoryPlot40.rendererChanged(rendererChangeEvent50);
//        org.jfree.chart.axis.CategoryAxis categoryAxis54 = new org.jfree.chart.axis.CategoryAxis("");
//        categoryAxis54.setTickMarksVisible(false);
//        categoryAxis54.setLabel("");
//        categoryPlot40.setDomainAxis((int) (byte) 100, categoryAxis54, false);
//        categoryPlot5.setDomainAxis(categoryAxis54);
//        org.jfree.chart.util.RectangleInsets rectangleInsets62 = categoryPlot5.getInsets();
//        org.jfree.chart.axis.AxisLocation axisLocation64 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
//        categoryPlot5.setRangeAxisLocation(128, axisLocation64);
//        boolean boolean66 = categoryPlot5.isRangeCrosshairLockedOnData();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNull(datasetGroup11);
//        org.junit.Assert.assertNotNull(paint12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNull(str21);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
//        org.junit.Assert.assertNotNull(list31);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
//        org.junit.Assert.assertNotNull(paint48);
//        org.junit.Assert.assertNotNull(rectangleInsets62);
//        org.junit.Assert.assertNotNull(axisLocation64);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
//    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        int int2 = xYPlot0.getSeriesCount();
        org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot0.getDomainAxisForDataset((int) (byte) 0);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation6, plotOrientation7);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = org.jfree.chart.axis.CategoryAnchor.END;
        boolean boolean10 = axisLocation6.equals((java.lang.Object) categoryAnchor9);
        try {
            xYPlot0.setDomainAxisLocation((int) (short) -1, axisLocation6, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        xYPlot0.setRangeAxisLocation(4, axisLocation8);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = numberAxis11.valueToJava2D((double) 10, rectangle2D13, rectangleEdge14);
        boolean boolean16 = numberAxis11.getAutoRangeStickyZero();
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis11);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = xYPlot0.getAxisOffset();
        double double19 = rectangleInsets18.getTop();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        int int2 = xYPlot0.getSeriesCount();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = xYPlot0.getRenderer((int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(xYItemRenderer4);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        float float8 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot0.getAxisOffset();
        java.awt.Color color10 = java.awt.Color.red;
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color10);
        java.lang.String str12 = categoryPlot0.getPlotType();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        categoryPlot13.setDomainAxis((int) 'a', categoryAxis15);
        categoryPlot13.clearAnnotations();
        boolean boolean18 = categoryPlot13.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace19 = categoryPlot13.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot13.setInsets(rectangleInsets20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot13.getDomainAxisEdge((int) (short) -1);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder24 = categoryPlot13.getDatasetRenderingOrder();
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder24);
        java.util.List list26 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation28 = categoryPlot0.getDomainAxisLocation(0);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Category Plot" + "'", str12.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(axisSpace19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(datasetRenderingOrder24);
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertNotNull(axisLocation28);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        xYPlot0.setRangeAxisLocation(4, axisLocation8);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = numberAxis11.valueToJava2D((double) 10, rectangle2D13, rectangleEdge14);
        boolean boolean16 = numberAxis11.getAutoRangeStickyZero();
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis11);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        categoryPlot20.setDomainAxis((int) 'a', categoryAxis22);
        categoryPlot20.clearAnnotations();
        boolean boolean25 = categoryPlot20.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace26 = categoryPlot20.getFixedDomainAxisSpace();
        boolean boolean27 = categoryPlot20.isRangeZoomable();
        categoryPlot20.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation30 = categoryPlot20.getDomainAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation31 = categoryPlot20.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation19, plotOrientation31);
        xYPlot0.setRangeAxisLocation(12, axisLocation19, true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNull(axisSpace26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(plotOrientation31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        java.awt.Paint paint2 = xYPlot0.getRangeGridlinePaint();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        xYPlot0.setDataset((int) ' ', xYDataset4);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis6.valueToJava2D((double) 10, rectangle2D8, rectangleEdge9);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = numberAxis11.valueToJava2D((double) 10, rectangle2D13, rectangleEdge14);
        org.jfree.data.Range range16 = numberAxis11.getDefaultAutoRange();
        numberAxis6.setRange(range16);
        numberAxis6.setRangeAboutValue((double) (short) -1, 0.0d);
        numberAxis6.setTickLabelsVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = numberAxis23.valueToJava2D((double) 10, rectangle2D25, rectangleEdge26);
        org.jfree.data.Range range28 = numberAxis23.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = null;
        double double33 = numberAxis29.valueToJava2D((double) 10, rectangle2D31, rectangleEdge32);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = null;
        double double38 = numberAxis34.valueToJava2D((double) 10, rectangle2D36, rectangleEdge37);
        org.jfree.data.Range range39 = numberAxis34.getDefaultAutoRange();
        numberAxis29.setRange(range39);
        numberAxis23.setDefaultAutoRange(range39);
        java.awt.Shape shape42 = numberAxis23.getDownArrow();
        numberAxis6.setRightArrow(shape42);
        boolean boolean44 = numberAxis6.isAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis();
        numberAxis45.setAutoRangeMinimumSize((double) 11, false);
        numberAxis45.setAutoRangeStickyZero(true);
        double double51 = numberAxis45.getLabelAngle();
        org.jfree.chart.plot.Plot plot52 = numberAxis45.getPlot();
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        double double57 = numberAxis53.valueToJava2D((double) 10, rectangle2D55, rectangleEdge56);
        org.jfree.data.Range range58 = numberAxis53.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D61 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = null;
        double double63 = numberAxis59.valueToJava2D((double) 10, rectangle2D61, rectangleEdge62);
        org.jfree.chart.axis.NumberAxis numberAxis64 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge67 = null;
        double double68 = numberAxis64.valueToJava2D((double) 10, rectangle2D66, rectangleEdge67);
        org.jfree.data.Range range69 = numberAxis64.getDefaultAutoRange();
        numberAxis59.setRange(range69);
        numberAxis53.setDefaultAutoRange(range69);
        org.jfree.chart.axis.NumberAxis numberAxis72 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = null;
        double double76 = numberAxis72.valueToJava2D((double) 10, rectangle2D74, rectangleEdge75);
        org.jfree.data.Range range77 = numberAxis72.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis78 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D80 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge81 = null;
        double double82 = numberAxis78.valueToJava2D((double) 10, rectangle2D80, rectangleEdge81);
        org.jfree.chart.axis.NumberAxis numberAxis83 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D85 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge86 = null;
        double double87 = numberAxis83.valueToJava2D((double) 10, rectangle2D85, rectangleEdge86);
        org.jfree.data.Range range88 = numberAxis83.getDefaultAutoRange();
        numberAxis78.setRange(range88);
        numberAxis72.setDefaultAutoRange(range88);
        numberAxis72.setAutoRangeMinimumSize((double) 1, true);
        org.jfree.data.Range range94 = numberAxis72.getDefaultAutoRange();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray95 = new org.jfree.chart.axis.ValueAxis[] { numberAxis6, numberAxis45, numberAxis53, numberAxis72 };
        xYPlot0.setRangeAxes(valueAxisArray95);
        xYPlot0.setDomainCrosshairLockedOnData(true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNull(plot52);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(range58);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(range69);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(range77);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertNotNull(range88);
        org.junit.Assert.assertNotNull(range94);
        org.junit.Assert.assertNotNull(valueAxisArray95);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        categoryPlot1.setDomainAxis((int) 'a', categoryAxis3);
        categoryPlot1.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        categoryPlot1.setDataset(0, categoryDataset7);
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot1.setNoDataMessagePaint(paint9);
        java.awt.Paint paint11 = categoryPlot1.getOutlinePaint();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = color12.createContext(colorModel13, rectangle14, rectangle2D15, affineTransform16, renderingHints17);
        java.awt.Paint[] paintArray19 = new java.awt.Paint[] { color0, paint11, color12 };
        java.awt.Paint[] paintArray20 = null;
        java.awt.Paint[] paintArray21 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray22 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray23 = null;
        java.awt.Shape[] shapeArray24 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier25 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray19, paintArray20, paintArray21, strokeArray22, strokeArray23, shapeArray24);
        java.lang.Object obj26 = defaultDrawingSupplier25.clone();
        java.awt.Paint paint27 = defaultDrawingSupplier25.getNextOutlinePaint();
        java.awt.Paint paint28 = defaultDrawingSupplier25.getNextOutlinePaint();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNotNull(paintArray19);
        org.junit.Assert.assertNotNull(paintArray21);
        org.junit.Assert.assertNotNull(strokeArray22);
        org.junit.Assert.assertNotNull(shapeArray24);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker9.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = valueMarker9.getOutlineStroke();
        boolean boolean13 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        java.awt.Paint paint14 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot0.setAxisOffset(rectangleInsets15);
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets15.createInsetRectangle(rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.data.general.DatasetGroup datasetGroup6 = categoryPlot0.getDatasetGroup();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        int int12 = xYPlot11.getDomainAxisCount();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        xYPlot11.rendererChanged(rendererChangeEvent13);
        java.awt.geom.Point2D point2D15 = xYPlot11.getQuadrantOrigin();
        categoryPlot0.zoomRangeAxes((double) 0.0f, plotRenderingInfo10, point2D15);
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(point2D15);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        boolean boolean7 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        categoryPlot8.setDomainAxis((int) 'a', categoryAxis10);
        categoryPlot8.clearAnnotations();
        boolean boolean13 = categoryPlot8.isOutlineVisible();
        org.jfree.chart.util.SortOrder sortOrder14 = categoryPlot8.getColumnRenderingOrder();
        java.awt.Stroke stroke15 = categoryPlot8.getRangeGridlineStroke();
        xYPlot0.setRangeZeroBaselineStroke(stroke15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color17);
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean21 = layer19.equals((java.lang.Object) dateRange20);
        java.util.Collection collection22 = xYPlot0.getRangeMarkers(layer19);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation23 = null;
        try {
            boolean boolean25 = xYPlot0.removeAnnotation(xYAnnotation23, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(sortOrder14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(layer19);
        org.junit.Assert.assertNotNull(dateRange20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(collection22);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis0, jFreeChart1);
        dateAxis0.zoomRange((double) (byte) -1, 0.05d);
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6, timeZone7);
        dateAxis0.setMinimumDate(date6);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis10, jFreeChart11);
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis10.setRange((org.jfree.data.Range) dateRange13);
        dateAxis10.setRange((double) 7, (double) 100);
        java.util.Date date19 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date19, timeZone20);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("AxisLocation.BOTTOM_OR_LEFT", timeZone20);
        java.util.Date date24 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date24, timeZone25);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis("AxisLocation.BOTTOM_OR_LEFT", timeZone25);
        dateAxis22.setTimeZone(timeZone25);
        org.jfree.chart.axis.Timeline timeline29 = dateAxis22.getTimeline();
        dateAxis10.setTimeline(timeline29);
        dateAxis0.setTimeline(timeline29);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(dateRange13);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertNotNull(timeline29);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Color color2 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT", color1);
        org.jfree.data.general.Dataset dataset3 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) color1, dataset3);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        float float6 = categoryPlot0.getBackgroundAlpha();
        org.jfree.chart.axis.AxisSpace axisSpace7 = categoryPlot0.getFixedRangeAxisSpace();
        java.awt.Paint paint8 = null;
        categoryPlot0.setOutlinePaint(paint8);
        org.jfree.chart.util.SortOrder sortOrder10 = org.jfree.chart.util.SortOrder.DESCENDING;
        categoryPlot0.setRowRenderingOrder(sortOrder10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation17 = null;
        xYPlot15.setRangeAxisLocation((int) (short) 100, axisLocation17);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = numberAxis20.valueToJava2D((double) 10, rectangle2D22, rectangleEdge23);
        org.jfree.data.Range range25 = numberAxis20.getDefaultAutoRange();
        numberAxis20.zoomRange((double) 0L, (double) 3);
        boolean boolean29 = numberAxis20.isNegativeArrowVisible();
        xYPlot15.setDomainAxis(255, (org.jfree.chart.axis.ValueAxis) numberAxis20, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder32 = xYPlot15.getDatasetRenderingOrder();
        java.awt.geom.Point2D point2D33 = xYPlot15.getQuadrantOrigin();
        categoryPlot0.zoomRangeAxes((double) 100, (double) 9, plotRenderingInfo14, point2D33);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNull(axisSpace7);
        org.junit.Assert.assertNotNull(sortOrder10);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder32);
        org.junit.Assert.assertNotNull(point2D33);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker9.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = valueMarker9.getOutlineStroke();
        boolean boolean13 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent14 = null;
        categoryPlot0.axisChanged(axisChangeEvent14);
        categoryPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = categoryPlot0.getDomainAxisForDataset(12);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation20 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation20, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryAxis19);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color2, stroke3);
        boolean boolean5 = axisLocation0.equals((java.lang.Object) valueMarker4);
        float float6 = valueMarker4.getAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        org.jfree.chart.util.UnitType unitType12 = rectangleInsets11.getUnitType();
        valueMarker4.setLabelOffset(rectangleInsets11);
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color15, stroke16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker17.setOutlineStroke(stroke18);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType20 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker17.setLabelOffsetType(lengthAdjustmentType20);
        valueMarker4.setLabelOffsetType(lengthAdjustmentType20);
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_RED;
        int int24 = color23.getRed();
        valueMarker4.setOutlinePaint((java.awt.Paint) color23);
        valueMarker4.setValue(55.0d);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(unitType12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(lengthAdjustmentType20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 255 + "'", int24 == 255);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis((int) 'a', categoryAxis7);
        categoryPlot5.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color12, stroke13);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker14.setOutlineStroke(stroke15);
        java.awt.Stroke stroke17 = valueMarker14.getOutlineStroke();
        boolean boolean18 = categoryPlot5.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker14);
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean21 = layer19.equals((java.lang.Object) dateRange20);
        java.lang.String str22 = layer19.toString();
        xYPlot0.addDomainMarker((int) '#', (org.jfree.chart.plot.Marker) valueMarker14, layer19);
        org.jfree.chart.plot.IntervalMarker intervalMarker26 = new org.jfree.chart.plot.IntervalMarker(10.0d, (double) ' ');
        intervalMarker26.setEndValue((double) 6);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker26, layer29);
        java.awt.Paint paint31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        xYPlot0.setRangeTickBandPaint(paint31);
        boolean boolean33 = xYPlot0.isSubplot();
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(layer19);
        org.junit.Assert.assertNotNull(dateRange20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Layer.FOREGROUND" + "'", str22.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis0, jFreeChart1);
        dateAxis0.zoomRange((double) (byte) -1, 0.05d);
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6, timeZone7);
        dateAxis0.setMinimumDate(date6);
        java.text.DateFormat dateFormat10 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("TextAnchor.CENTER");
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.JFreeChart jFreeChart14 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis13, jFreeChart14);
        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = dateAxis13.getTickUnit();
        java.util.Date date17 = dateAxis12.calculateLowestVisibleTickValue(dateTickUnit16);
        java.util.Date date18 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit16);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(dateFormat10);
        org.junit.Assert.assertNotNull(dateTickUnit16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date18);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        boolean boolean7 = xYPlot0.isDomainCrosshairVisible();
        boolean boolean8 = xYPlot0.isSubplot();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        int int10 = color9.getRGB();
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color9);
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation15 = null;
        xYPlot13.setRangeAxisLocation((int) (short) 100, axisLocation15);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = numberAxis18.valueToJava2D((double) 10, rectangle2D20, rectangleEdge21);
        org.jfree.data.Range range23 = numberAxis18.getDefaultAutoRange();
        numberAxis18.zoomRange((double) 0L, (double) 3);
        boolean boolean27 = numberAxis18.isNegativeArrowVisible();
        xYPlot13.setDomainAxis(255, (org.jfree.chart.axis.ValueAxis) numberAxis18, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder30 = xYPlot13.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation32 = xYPlot13.getRangeAxisLocation(0);
        xYPlot0.setDomainAxisLocation(12, axisLocation32, false);
        xYPlot0.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder37 = xYPlot0.getDatasetRenderingOrder();
        xYPlot0.clearRangeAxes();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-128) + "'", int10 == (-128));
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder30);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(datasetRenderingOrder37);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(9, 64, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font4 = null;
        categoryAxis2.setTickLabelFont((java.lang.Comparable) (byte) -1, font4);
        java.lang.String str6 = categoryAxis2.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = numberAxis7.valueToJava2D((double) 10, rectangle2D9, rectangleEdge10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.AxisState axisState13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        java.util.List list16 = numberAxis7.refreshTicks(graphics2D12, axisState13, rectangle2D14, rectangleEdge15);
        numberAxis7.setLabel("RectangleAnchor.TOP_LEFT");
        numberAxis7.zoomRange((double) (-1L), (double) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer22);
        numberAxis7.setRangeAboutValue((double) 10, (double) 2);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(list16);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("AxisLocation.BOTTOM_OR_LEFT", timeZone2);
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6, timeZone7);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("AxisLocation.BOTTOM_OR_LEFT", timeZone7);
        dateAxis4.setTimeZone(timeZone7);
        org.jfree.chart.axis.Timeline timeline11 = dateAxis4.getTimeline();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = null;
        try {
            dateAxis4.setTickMarkPosition(dateTickMarkPosition12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(timeline11);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.mapDatasetToDomainAxis((int) (byte) 100, 1);
        int int4 = xYPlot0.getWeight();
        xYPlot0.setBackgroundImageAlpha((float) (short) 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test213");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        long long3 = day2.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        long long5 = day2.getLastMillisecond();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker9.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = valueMarker9.getOutlineStroke();
        boolean boolean13 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        java.awt.Paint paint14 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot0.setAxisOffset(rectangleInsets15);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot0.removeChangeListener(plotChangeListener17);
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot0.setOrientation(plotOrientation19);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(plotOrientation19);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot0.setInsets(rectangleInsets7);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D10 = rectangleInsets7.createOutsetRectangle(rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot3.setDomainAxis((int) 'a', categoryAxis5);
        categoryPlot3.clearAnnotations();
        boolean boolean8 = categoryPlot3.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace9 = categoryPlot3.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot3.setInsets(rectangleInsets10);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot3.getDomainAxisEdge((int) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        numberAxis15.setAutoRangeMinimumSize((double) 11, false);
        numberAxis15.setAutoRangeStickyZero(true);
        double double21 = numberAxis15.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
        double double26 = numberAxis22.valueToJava2D((double) 10, rectangle2D24, rectangleEdge25);
        org.jfree.data.Range range27 = numberAxis22.getDefaultAutoRange();
        numberAxis15.setRange(range27, true, true);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis15.setTickMarkPaint((java.awt.Paint) color31);
        categoryPlot3.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis15);
        categoryPlot3.clearRangeMarkers();
        java.awt.Color color36 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke37 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color36, stroke37);
        java.awt.Stroke stroke39 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker38.setOutlineStroke(stroke39);
        java.awt.Stroke stroke41 = valueMarker38.getStroke();
        categoryPlot3.setDomainGridlineStroke(stroke41);
        xYPlot0.setRangeGridlineStroke(stroke41);
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis();
        numberAxis45.setAutoRangeMinimumSize((double) 11, false);
        numberAxis45.setAutoRangeStickyZero(true);
        double double51 = numberAxis45.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = null;
        double double56 = numberAxis52.valueToJava2D((double) 10, rectangle2D54, rectangleEdge55);
        org.jfree.data.Range range57 = numberAxis52.getDefaultAutoRange();
        numberAxis45.setRange(range57, true, true);
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis45);
        org.jfree.chart.axis.AxisLocation axisLocation63 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot0.setDomainAxisLocation(5, axisLocation63, true);
        org.jfree.chart.axis.ValueAxis valueAxis67 = null;
        try {
            xYPlot0.setDomainAxis((-393216), valueAxis67);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertNotNull(axisLocation63);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeMinimumSize((double) 11, false);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color5, stroke6);
        numberAxis0.setLabelPaint((java.awt.Paint) color5);
        java.awt.Color color9 = java.awt.Color.yellow;
        numberAxis0.setAxisLinePaint((java.awt.Paint) color9);
        numberAxis0.setUpperBound(10.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        boolean boolean7 = categoryPlot0.isRangeZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot0.getRendererForDataset(categoryDataset8);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        categoryPlot10.setDomainAxis((int) 'a', categoryAxis12);
        categoryPlot10.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color17, stroke18);
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker19.setOutlineStroke(stroke20);
        java.awt.Stroke stroke22 = valueMarker19.getOutlineStroke();
        boolean boolean23 = categoryPlot10.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker19);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent24 = null;
        categoryPlot10.axisChanged(axisChangeEvent24);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj28 = null;
        boolean boolean29 = categoryAxis27.equals(obj28);
        categoryAxis27.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis27.clearCategoryLabelToolTips();
        categoryAxis27.setTickLabelsVisible(false);
        categoryPlot10.setDomainAxis(categoryAxis27);
        categoryPlot0.setDomainAxis(categoryAxis27);
        int int38 = categoryAxis27.getMaximumCategoryLabelLines();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        xYPlot0.setRangeAxisLocation(4, axisLocation8);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = numberAxis11.valueToJava2D((double) 10, rectangle2D13, rectangleEdge14);
        boolean boolean16 = numberAxis11.getAutoRangeStickyZero();
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis11);
        xYPlot0.setRangeZeroBaselineVisible(false);
        xYPlot0.clearDomainMarkers();
        org.jfree.chart.plot.PlotOrientation plotOrientation21 = xYPlot0.getOrientation();
        boolean boolean22 = xYPlot0.isDomainCrosshairLockedOnData();
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        java.util.List list24 = xYPlot23.getAnnotations();
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot23.setDomainZeroBaselineStroke(stroke25);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        xYPlot23.rendererChanged(rendererChangeEvent27);
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot();
        java.util.List list30 = xYPlot29.getAnnotations();
        java.awt.Stroke stroke31 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot29.setDomainZeroBaselineStroke(stroke31);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent33 = null;
        xYPlot29.rendererChanged(rendererChangeEvent33);
        org.jfree.chart.axis.AxisLocation axisLocation36 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        categoryPlot37.setDomainAxis((int) 'a', categoryAxis39);
        categoryPlot37.clearAnnotations();
        boolean boolean42 = categoryPlot37.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace43 = categoryPlot37.getFixedDomainAxisSpace();
        boolean boolean44 = categoryPlot37.isRangeZoomable();
        categoryPlot37.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation47 = categoryPlot37.getDomainAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation48 = categoryPlot37.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation36, plotOrientation48);
        xYPlot29.setDomainAxisLocation(10, axisLocation36);
        xYPlot23.setDomainAxisLocation(axisLocation36);
        xYPlot0.setRangeAxisLocation(axisLocation36, true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(plotOrientation21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNull(axisSpace43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(axisLocation47);
        org.junit.Assert.assertNotNull(plotOrientation48);
        org.junit.Assert.assertNotNull(rectangleEdge49);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        xYPlot0.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis6.valueToJava2D((double) 10, rectangle2D8, rectangleEdge9);
        org.jfree.data.Range range11 = numberAxis6.getDefaultAutoRange();
        java.awt.Font font12 = numberAxis6.getTickLabelFont();
        numberAxis6.setAutoRange(false);
        xYPlot0.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis6, false);
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color17);
        xYPlot0.setRangeCrosshairVisible(true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color17);
    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test221");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        long long3 = day2.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
//        categoryPlot5.setDomainAxis((int) 'a', categoryAxis7);
//        categoryPlot5.setBackgroundImageAlignment((int) (short) 10);
//        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot5.getDatasetGroup();
//        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
//        categoryPlot5.setNoDataMessagePaint(paint12);
//        boolean boolean14 = day2.equals((java.lang.Object) categoryPlot5);
//        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
//        java.awt.Font font19 = null;
//        categoryAxis17.setTickLabelFont((java.lang.Comparable) (byte) -1, font19);
//        java.lang.String str21 = categoryAxis17.getLabelToolTip();
//        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D24 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
//        double double26 = numberAxis22.valueToJava2D((double) 10, rectangle2D24, rectangleEdge25);
//        java.awt.Graphics2D graphics2D27 = null;
//        org.jfree.chart.axis.AxisState axisState28 = null;
//        java.awt.geom.Rectangle2D rectangle2D29 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
//        java.util.List list31 = numberAxis22.refreshTicks(graphics2D27, axisState28, rectangle2D29, rectangleEdge30);
//        numberAxis22.setLabel("RectangleAnchor.TOP_LEFT");
//        numberAxis22.zoomRange((double) (-1L), (double) 1);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis17, (org.jfree.chart.axis.ValueAxis) numberAxis22, categoryItemRenderer37);
//        int int39 = categoryPlot5.getDomainAxisIndex(categoryAxis17);
//        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
//        categoryPlot40.setDomainAxis((int) 'a', categoryAxis42);
//        categoryPlot40.clearAnnotations();
//        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
//        categoryPlot40.setDataset(0, categoryDataset46);
//        java.awt.Paint paint48 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
//        categoryPlot40.setNoDataMessagePaint(paint48);
//        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent50 = null;
//        categoryPlot40.rendererChanged(rendererChangeEvent50);
//        org.jfree.chart.axis.CategoryAxis categoryAxis54 = new org.jfree.chart.axis.CategoryAxis("");
//        categoryAxis54.setTickMarksVisible(false);
//        categoryAxis54.setLabel("");
//        categoryPlot40.setDomainAxis((int) (byte) 100, categoryAxis54, false);
//        categoryPlot5.setDomainAxis(categoryAxis54);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer62 = null;
//        categoryPlot5.setRenderer(categoryItemRenderer62, true);
//        org.jfree.chart.plot.CategoryPlot categoryPlot65 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis67 = null;
//        categoryPlot65.setDomainAxis((int) 'a', categoryAxis67);
//        categoryPlot65.clearAnnotations();
//        boolean boolean70 = categoryPlot65.isOutlineVisible();
//        org.jfree.chart.axis.AxisSpace axisSpace71 = categoryPlot65.getFixedDomainAxisSpace();
//        org.jfree.chart.util.RectangleInsets rectangleInsets72 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
//        categoryPlot65.setInsets(rectangleInsets72);
//        categoryPlot65.setWeight((int) (short) 1);
//        java.awt.Paint paint76 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
//        boolean boolean77 = categoryPlot65.equals((java.lang.Object) paint76);
//        categoryPlot5.setRangeCrosshairPaint(paint76);
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNull(datasetGroup11);
//        org.junit.Assert.assertNotNull(paint12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNull(str21);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
//        org.junit.Assert.assertNotNull(list31);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
//        org.junit.Assert.assertNotNull(paint48);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
//        org.junit.Assert.assertNull(axisSpace71);
//        org.junit.Assert.assertNotNull(rectangleInsets72);
//        org.junit.Assert.assertNotNull(paint76);
//        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis5.zoomRange((double) 0L, (double) 3);
        boolean boolean14 = numberAxis5.isNegativeArrowVisible();
        xYPlot0.setDomainAxis(255, (org.jfree.chart.axis.ValueAxis) numberAxis5, false);
        org.jfree.chart.plot.Plot plot17 = numberAxis5.getPlot();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        numberAxis18.setAutoRangeMinimumSize((double) 11, false);
        numberAxis18.setAutoRangeStickyZero(true);
        double double24 = numberAxis18.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = null;
        double double29 = numberAxis25.valueToJava2D((double) 10, rectangle2D27, rectangleEdge28);
        org.jfree.data.Range range30 = numberAxis25.getDefaultAutoRange();
        numberAxis18.setRange(range30, true, true);
        numberAxis5.setDefaultAutoRange(range30);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(plot17);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(range30);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent5);
        boolean boolean7 = categoryPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYPlot0.rendererChanged(rendererChangeEvent2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = xYPlot0.getDomainAxisEdge();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        int int7 = xYPlot6.getDomainAxisCount();
        xYPlot6.setRangeCrosshairValue(11.0d, false);
        boolean boolean11 = xYPlot6.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation12 = xYPlot6.getRangeAxisLocation();
        xYPlot0.setRangeAxisLocation(1, axisLocation12);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(axisLocation12);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        java.awt.Color color0 = java.awt.Color.pink;
        java.awt.Color color1 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeMinimumSize((double) 11, false);
        numberAxis0.setAutoRangeStickyZero(true);
        double double6 = numberAxis0.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = numberAxis7.valueToJava2D((double) 10, rectangle2D9, rectangleEdge10);
        org.jfree.data.Range range12 = numberAxis7.getDefaultAutoRange();
        numberAxis0.setRange(range12, true, true);
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis0.setTickMarkPaint((java.awt.Paint) color16);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        double double24 = rectangleInsets22.calculateLeftInset((double) (-1));
        numberAxis0.setLabelInsets(rectangleInsets22);
        java.awt.Stroke stroke26 = numberAxis0.getTickMarkStroke();
        org.jfree.chart.plot.Plot plot27 = numberAxis0.getPlot();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 32.0d + "'", double24 == 32.0d);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(plot27);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeMinimumSize((double) 11, false);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color5, stroke6);
        numberAxis0.setLabelPaint((java.awt.Paint) color5);
        numberAxis0.setPositiveArrowVisible(true);
        org.jfree.chart.plot.Plot plot11 = numberAxis0.getPlot();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = numberAxis12.valueToJava2D((double) 10, rectangle2D14, rectangleEdge15);
        org.jfree.data.Range range17 = numberAxis12.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = numberAxis18.valueToJava2D((double) 10, rectangle2D20, rectangleEdge21);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = numberAxis23.valueToJava2D((double) 10, rectangle2D25, rectangleEdge26);
        org.jfree.data.Range range28 = numberAxis23.getDefaultAutoRange();
        numberAxis18.setRange(range28);
        numberAxis12.setDefaultAutoRange(range28);
        java.awt.Shape shape31 = numberAxis12.getDownArrow();
        numberAxis0.setDownArrow(shape31);
        boolean boolean33 = numberAxis0.getAutoRangeStickyZero();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.data.Range range5 = numberAxis0.getDefaultAutoRange();
        numberAxis0.zoomRange((double) 0L, (double) 3);
        java.lang.String str9 = numberAxis0.getLabel();
        boolean boolean10 = numberAxis0.getAutoRangeStickyZero();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis0.getLabelInsets();
        double double12 = rectangleInsets11.getLeft();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D16 = rectangleInsets11.createInsetRectangle(rectangle2D13, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.0d + "'", double12 == 3.0d);
    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test229");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        long long3 = day2.getFirstMillisecond();
//        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
//        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_GREEN;
//        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color6, stroke7);
//        boolean boolean9 = axisLocation4.equals((java.lang.Object) valueMarker8);
//        float float10 = valueMarker8.getAlpha();
//        int int11 = day2.compareTo((java.lang.Object) valueMarker8);
//        int int12 = day2.getYear();
//        int int13 = day2.getYear();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(axisLocation4);
//        org.junit.Assert.assertNotNull(color6);
//        org.junit.Assert.assertNotNull(stroke7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot0.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent12);
        org.jfree.chart.util.Layer layer15 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection16 = categoryPlot0.getRangeMarkers((int) (byte) -1, layer15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj19 = null;
        boolean boolean20 = categoryAxis18.equals(obj19);
        categoryAxis18.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis18.clearCategoryLabelToolTips();
        categoryAxis18.setTickLabelsVisible(false);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        categoryPlot28.setDomainAxis((int) 'a', categoryAxis30);
        categoryPlot28.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        categoryPlot28.setDataset(0, categoryDataset34);
        java.awt.Paint paint36 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot28.setNoDataMessagePaint(paint36);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = categoryPlot28.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent40 = null;
        categoryPlot28.rendererChanged(rendererChangeEvent40);
        org.jfree.chart.util.Layer layer43 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection44 = categoryPlot28.getRangeMarkers((int) (byte) -1, layer43);
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = null;
        org.jfree.chart.axis.AxisSpace axisSpace47 = null;
        org.jfree.chart.axis.AxisSpace axisSpace48 = categoryAxis18.reserveSpace(graphics2D27, (org.jfree.chart.plot.Plot) categoryPlot28, rectangle2D45, rectangleEdge46, axisSpace47);
        categoryPlot0.setFixedRangeAxisSpace(axisSpace48, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = null;
        categoryPlot51.setDomainAxis((int) 'a', categoryAxis53);
        categoryPlot51.clearAnnotations();
        boolean boolean56 = categoryPlot51.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace57 = categoryPlot51.getFixedDomainAxisSpace();
        boolean boolean58 = categoryPlot51.isRangeZoomable();
        categoryPlot51.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation61 = categoryPlot51.getDomainAxisLocation();
        categoryPlot0.setRangeAxisLocation(axisLocation61);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(layer15);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNotNull(layer43);
        org.junit.Assert.assertNull(collection44);
        org.junit.Assert.assertNotNull(axisSpace48);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNull(axisSpace57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(axisLocation61);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis0, jFreeChart1);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color5, stroke6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker7.setOutlineStroke(stroke8);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType10 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker7.setLabelOffsetType(lengthAdjustmentType10);
        boolean boolean12 = xYPlot3.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker7);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = xYPlot3.getFixedLegendItems();
        boolean boolean14 = dateAxis0.hasListener((java.util.EventListener) xYPlot3);
        dateAxis0.setUpperBound(1.0d);
        dateAxis0.configure();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(lengthAdjustmentType10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(legendItemCollection13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = categoryPlot0.getDrawingSupplier();
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        double double12 = rectangleInsets10.calculateLeftInset((double) (-1));
        double double13 = rectangleInsets10.getTop();
        boolean boolean14 = categoryPlot0.equals((java.lang.Object) double13);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = categoryPlot0.getDomainAxis();
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 32.0d + "'", double12 == 32.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 52.0d + "'", double13 == 52.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(categoryAxis15);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis0.setRange(range10);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis0.getTickUnit();
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        numberAxis0.setTickLabelFont(font13);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.mapDatasetToDomainAxis((int) (byte) 100, 1);
        int int4 = xYPlot0.getDatasetCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

//    @Test
//    public void test235() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test235");
//        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
//        long long4 = day3.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
//        categoryPlot6.setDomainAxis((int) 'a', categoryAxis8);
//        categoryPlot6.setBackgroundImageAlignment((int) (short) 10);
//        org.jfree.data.general.DatasetGroup datasetGroup12 = categoryPlot6.getDatasetGroup();
//        java.awt.Paint paint13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
//        categoryPlot6.setNoDataMessagePaint(paint13);
//        boolean boolean15 = day3.equals((java.lang.Object) categoryPlot6);
//        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("");
//        java.awt.Font font20 = null;
//        categoryAxis18.setTickLabelFont((java.lang.Comparable) (byte) -1, font20);
//        categoryPlot6.setDomainAxis(10, categoryAxis18);
//        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
//        dateAxis23.setRange((double) (byte) 10, 100.0d);
//        org.jfree.chart.axis.Timeline timeline27 = null;
//        dateAxis23.setTimeline(timeline27);
//        org.jfree.chart.axis.Timeline timeline29 = null;
//        dateAxis23.setTimeline(timeline29);
//        dateAxis23.configure();
//        java.awt.Stroke stroke32 = dateAxis23.getTickMarkStroke();
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis23, categoryItemRenderer33);
//        java.util.Date date35 = dateAxis23.getMaximumDate();
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNull(datasetGroup12);
//        org.junit.Assert.assertNotNull(paint13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(stroke32);
//        org.junit.Assert.assertNotNull(date35);
//    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot0.setInsets(rectangleInsets7);
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation9, plotOrientation10);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor12 = org.jfree.chart.axis.CategoryAnchor.END;
        boolean boolean13 = axisLocation9.equals((java.lang.Object) categoryAnchor12);
        categoryPlot0.setRangeAxisLocation(axisLocation9, false);
        boolean boolean16 = categoryPlot0.isOutlineVisible();
        categoryPlot0.setForegroundAlpha((float) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(categoryAnchor12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = numberAxis1.valueToJava2D((double) 10, rectangle2D3, rectangleEdge4);
        java.awt.Paint paint6 = numberAxis1.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis7, xYItemRenderer8);
        xYPlot9.setRangeZeroBaselineVisible(false);
        xYPlot9.clearRangeMarkers(8);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint6);
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test238");
//        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
//        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
//        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
//        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone4 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3, timeZone4);
//        java.awt.Color color6 = java.awt.Color.gray;
//        int int7 = color6.getBlue();
//        float[] floatArray8 = null;
//        float[] floatArray9 = color6.getComponents(floatArray8);
//        boolean boolean10 = day5.equals((java.lang.Object) floatArray8);
//        int int11 = day5.getDayOfMonth();
//        long long12 = day5.getSerialIndex();
//        boolean boolean13 = plotOrientation1.equals((java.lang.Object) day5);
//        java.lang.String str14 = day5.toString();
//        org.junit.Assert.assertNotNull(axisLocation0);
//        org.junit.Assert.assertNotNull(plotOrientation1);
//        org.junit.Assert.assertNotNull(rectangleEdge2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(timeZone4);
//        org.junit.Assert.assertNotNull(color6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 128 + "'", int7 == 128);
//        org.junit.Assert.assertNotNull(floatArray9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 13 + "'", int11 == 13);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43629L + "'", long12 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "13-June-2019" + "'", str14.equals("13-June-2019"));
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker3.setOutlineStroke(stroke4);
        valueMarker3.setAlpha((float) (short) 0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        float float8 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot0.getAxisOffset();
        java.awt.Color color10 = java.awt.Color.red;
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color10);
        java.lang.String str12 = categoryPlot0.getPlotType();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        categoryPlot13.setDomainAxis((int) 'a', categoryAxis15);
        categoryPlot13.clearAnnotations();
        boolean boolean18 = categoryPlot13.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace19 = categoryPlot13.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot13.setInsets(rectangleInsets20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot13.getDomainAxisEdge((int) (short) -1);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder24 = categoryPlot13.getDatasetRenderingOrder();
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder24);
        categoryPlot0.setRangeCrosshairValue((double) 12, false);
        categoryPlot0.configureRangeAxes();
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Category Plot" + "'", str12.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(axisSpace19);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(datasetRenderingOrder24);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        float float6 = categoryPlot0.getBackgroundAlpha();
        java.awt.Paint paint7 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        categoryPlot0.removeChangeListener(plotChangeListener8);
        java.awt.Paint paint10 = null;
        try {
            categoryPlot0.setDomainGridlinePaint(paint10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.data.general.DatasetGroup datasetGroup6 = categoryPlot0.getDatasetGroup();
        java.awt.Paint paint7 = categoryPlot0.getBackgroundPaint();
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryAxis1.equals(obj2);
        categoryAxis1.setLabelToolTip("Layer.FOREGROUND");
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot6.setDomainAxis((int) 'a', categoryAxis8);
        categoryPlot6.setBackgroundImageAlignment((int) (short) 10);
        float float12 = categoryPlot6.getBackgroundAlpha();
        java.lang.String str13 = categoryPlot6.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        double double20 = rectangleInsets18.calculateLeftInset((double) (-1));
        double double21 = rectangleInsets18.getBottom();
        org.jfree.data.general.Dataset dataset22 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent23 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) double21, dataset22);
        categoryPlot6.datasetChanged(datasetChangeEvent23);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = null;
        double double29 = numberAxis25.valueToJava2D((double) 10, rectangle2D27, rectangleEdge28);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.axis.AxisState axisState31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        java.util.List list34 = numberAxis25.refreshTicks(graphics2D30, axisState31, rectangle2D32, rectangleEdge33);
        numberAxis25.setLabel("RectangleAnchor.TOP_LEFT");
        numberAxis25.zoomRange((double) (-1L), (double) 1);
        categoryPlot6.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis25);
        categoryAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Category Plot" + "'", str13.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 32.0d + "'", double20 == 32.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(list34);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        java.util.List list9 = numberAxis0.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge8);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        double double16 = rectangleInsets14.calculateLeftInset((double) (-1));
        numberAxis0.setTickLabelInsets(rectangleInsets14);
        numberAxis0.setAutoRangeMinimumSize((double) 100L);
        numberAxis0.setAutoRangeIncludesZero(true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 32.0d + "'", double16 == 32.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker9.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = valueMarker9.getOutlineStroke();
        boolean boolean13 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot15.setDomainAxis((int) 'a', categoryAxis17);
        categoryPlot15.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color22, stroke23);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker24.setOutlineStroke(stroke25);
        java.awt.Stroke stroke27 = valueMarker24.getOutlineStroke();
        boolean boolean28 = categoryPlot15.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker24);
        org.jfree.chart.text.TextAnchor textAnchor29 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        valueMarker24.setLabelTextAnchor(textAnchor29);
        java.lang.String str31 = valueMarker24.getLabel();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        categoryPlot32.setDomainAxis((int) 'a', categoryAxis34);
        categoryPlot32.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        categoryPlot32.setDataset(0, categoryDataset38);
        java.awt.Paint paint40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot32.setNoDataMessagePaint(paint40);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot32.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent44 = null;
        categoryPlot32.rendererChanged(rendererChangeEvent44);
        org.jfree.chart.util.Layer layer47 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection48 = categoryPlot32.getRangeMarkers((int) (byte) -1, layer47);
        boolean boolean49 = categoryPlot0.removeRangeMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) valueMarker24, layer47);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(textAnchor29);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertNotNull(layer47);
        org.junit.Assert.assertNull(collection48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker9.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = valueMarker9.getOutlineStroke();
        boolean boolean13 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.data.general.DatasetGroup datasetGroup14 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot15.setDomainAxis((int) 'a', categoryAxis17);
        categoryPlot15.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.data.general.DatasetGroup datasetGroup21 = categoryPlot15.getDatasetGroup();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot15);
        categoryPlot15.setBackgroundAlpha((float) (-393216));
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent25 = null;
        categoryPlot15.rendererChanged(rendererChangeEvent25);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        categoryPlot27.setDomainAxis((int) 'a', categoryAxis29);
        categoryPlot27.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        categoryPlot27.setDataset(0, categoryDataset33);
        java.awt.Paint paint35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot27.setNoDataMessagePaint(paint35);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = categoryPlot27.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent39 = null;
        categoryPlot27.rendererChanged(rendererChangeEvent39);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray42 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer41 };
        categoryPlot27.setRenderers(categoryItemRendererArray42);
        categoryPlot15.setRenderers(categoryItemRendererArray42);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(datasetGroup14);
        org.junit.Assert.assertNull(datasetGroup21);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertNotNull(categoryItemRendererArray42);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeMinimumSize((double) 11, false);
        numberAxis0.setAutoRangeStickyZero(true);
        double double6 = numberAxis0.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = numberAxis7.valueToJava2D((double) 10, rectangle2D9, rectangleEdge10);
        org.jfree.data.Range range12 = numberAxis7.getDefaultAutoRange();
        numberAxis0.setRange(range12, true, true);
        java.awt.Shape shape16 = null;
        try {
            numberAxis0.setLeftArrow(shape16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(range12);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker9.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = valueMarker9.getOutlineStroke();
        boolean boolean13 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.data.general.DatasetGroup datasetGroup14 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot15.setDomainAxis((int) 'a', categoryAxis17);
        categoryPlot15.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.data.general.DatasetGroup datasetGroup21 = categoryPlot15.getDatasetGroup();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot15);
        categoryPlot15.setBackgroundAlpha((float) (-393216));
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent25 = null;
        categoryPlot15.rendererChanged(rendererChangeEvent25);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        categoryPlot15.rendererChanged(rendererChangeEvent27);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(datasetGroup14);
        org.junit.Assert.assertNull(datasetGroup21);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        numberAxis0.setVerticalTickLabels(false);
        java.awt.Paint paint7 = numberAxis0.getTickMarkPaint();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot0.setInsets(rectangleInsets7);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot0.getDomainAxisEdge((int) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeMinimumSize((double) 11, false);
        numberAxis12.setAutoRangeStickyZero(true);
        double double18 = numberAxis12.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = numberAxis19.valueToJava2D((double) 10, rectangle2D21, rectangleEdge22);
        org.jfree.data.Range range24 = numberAxis19.getDefaultAutoRange();
        numberAxis12.setRange(range24, true, true);
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis12.setTickMarkPaint((java.awt.Paint) color28);
        categoryPlot0.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis12);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit31 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis12.setTickUnit(numberTickUnit31, true, false);
        numberAxis12.setLabelAngle(3.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(numberTickUnit31);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.data.Range range5 = numberAxis0.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis6.valueToJava2D((double) 10, rectangle2D8, rectangleEdge9);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = numberAxis11.valueToJava2D((double) 10, rectangle2D13, rectangleEdge14);
        org.jfree.data.Range range16 = numberAxis11.getDefaultAutoRange();
        numberAxis6.setRange(range16);
        numberAxis0.setDefaultAutoRange(range16);
        numberAxis0.setAutoRangeMinimumSize((double) 1, true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand22 = numberAxis0.getMarkerBand();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNull(markerAxisBand22);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryAxis1.equals(obj2);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis1.setMaximumCategoryLabelLines(1);
        categoryAxis1.configure();
        categoryAxis1.setCategoryMargin((double) (-393216));
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (byte) 100, paint13);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color2, stroke3);
        boolean boolean5 = axisLocation0.equals((java.lang.Object) valueMarker4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        valueMarker4.setPaint((java.awt.Paint) color6);
        int int8 = color6.getAlpha();
        java.lang.String str9 = color6.toString();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 255 + "'", int8 == 255);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "java.awt.Color[r=128,g=0,b=128]" + "'", str9.equals("java.awt.Color[r=128,g=0,b=128]"));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        boolean boolean7 = categoryPlot0.isRangeZoomable();
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        categoryPlot10.setDomainAxis((int) 'a', categoryAxis12);
        categoryPlot10.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.data.general.DatasetGroup datasetGroup16 = categoryPlot10.getDatasetGroup();
        java.awt.Paint paint17 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        categoryPlot10.setNoDataMessagePaint(paint17);
        categoryPlot0.setRangeGridlinePaint(paint17);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(datasetGroup16);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        boolean boolean5 = numberAxis0.getAutoRangeStickyZero();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        categoryPlot6.setDataset(categoryDataset7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        categoryPlot6.removeChangeListener(plotChangeListener9);
        numberAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        java.awt.Font font12 = categoryPlot6.getNoDataMessageFont();
        java.awt.Paint paint13 = categoryPlot6.getNoDataMessagePaint();
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color16, stroke17);
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker18.setOutlineStroke(stroke19);
        java.awt.Paint paint21 = valueMarker18.getOutlinePaint();
        java.lang.String str22 = valueMarker18.getLabel();
        valueMarker18.setAlpha(0.0f);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        valueMarker18.setStroke(stroke25);
        valueMarker18.setLabel("PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean30 = categoryPlot6.removeRangeMarker((-1), (org.jfree.chart.plot.Marker) valueMarker18, layer29);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType31 = valueMarker18.getLabelOffsetType();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType31);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis0.setRange(range10);
        numberAxis0.setRangeAboutValue((double) (short) -1, 0.0d);
        org.jfree.chart.plot.Plot plot15 = numberAxis0.getPlot();
        java.lang.String str16 = numberAxis0.getLabelToolTip();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNull(plot15);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryAxis1.equals(obj2);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(false);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot11.setDomainAxis((int) 'a', categoryAxis13);
        categoryPlot11.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        categoryPlot11.setDataset(0, categoryDataset17);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot11.setNoDataMessagePaint(paint19);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot11.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        categoryPlot11.rendererChanged(rendererChangeEvent23);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection27 = categoryPlot11.getRangeMarkers((int) (byte) -1, layer26);
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        org.jfree.chart.axis.AxisSpace axisSpace30 = null;
        org.jfree.chart.axis.AxisSpace axisSpace31 = categoryAxis1.reserveSpace(graphics2D10, (org.jfree.chart.plot.Plot) categoryPlot11, rectangle2D28, rectangleEdge29, axisSpace30);
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = null;
        double double36 = numberAxis32.valueToJava2D((double) 10, rectangle2D34, rectangleEdge35);
        java.awt.Paint paint37 = numberAxis32.getTickMarkPaint();
        numberAxis32.resizeRange((double) 3);
        numberAxis32.setAutoRangeMinimumSize(10.0d, false);
        boolean boolean43 = numberAxis32.isInverted();
        boolean boolean44 = numberAxis32.isAutoRange();
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.JFreeChart jFreeChart46 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent47 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis45, jFreeChart46);
        org.jfree.data.time.DateRange dateRange48 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis45.setRange((org.jfree.data.Range) dateRange48);
        dateAxis45.setRange((double) 7, (double) 100);
        java.util.Date date54 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day56 = new org.jfree.data.time.Day(date54, timeZone55);
        org.jfree.chart.axis.DateAxis dateAxis57 = new org.jfree.chart.axis.DateAxis("AxisLocation.BOTTOM_OR_LEFT", timeZone55);
        java.util.Date date59 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone60 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date59, timeZone60);
        org.jfree.chart.axis.DateAxis dateAxis62 = new org.jfree.chart.axis.DateAxis("AxisLocation.BOTTOM_OR_LEFT", timeZone60);
        dateAxis57.setTimeZone(timeZone60);
        org.jfree.chart.axis.Timeline timeline64 = dateAxis57.getTimeline();
        dateAxis45.setTimeline(timeline64);
        org.jfree.chart.axis.DateAxis dateAxis66 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.JFreeChart jFreeChart67 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent68 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis66, jFreeChart67);
        org.jfree.chart.plot.XYPlot xYPlot69 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color71 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke72 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker73 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color71, stroke72);
        java.awt.Stroke stroke74 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker73.setOutlineStroke(stroke74);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType76 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker73.setLabelOffsetType(lengthAdjustmentType76);
        boolean boolean78 = xYPlot69.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker73);
        org.jfree.chart.LegendItemCollection legendItemCollection79 = xYPlot69.getFixedLegendItems();
        boolean boolean80 = dateAxis66.hasListener((java.util.EventListener) xYPlot69);
        dateAxis66.setUpperBound(1.0d);
        org.jfree.data.Range range83 = dateAxis66.getDefaultAutoRange();
        dateAxis45.setRange(range83);
        org.jfree.chart.axis.NumberAxis numberAxis85 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D87 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge88 = null;
        double double89 = numberAxis85.valueToJava2D((double) 10, rectangle2D87, rectangleEdge88);
        org.jfree.data.Range range90 = numberAxis85.getDefaultAutoRange();
        numberAxis85.zoomRange((double) 0L, (double) 3);
        java.lang.String str94 = numberAxis85.getLabel();
        boolean boolean95 = numberAxis85.getAutoRangeStickyZero();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray96 = new org.jfree.chart.axis.ValueAxis[] { numberAxis32, dateAxis45, numberAxis85 };
        categoryPlot11.setRangeAxes(valueAxisArray96);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertNotNull(axisSpace31);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(dateRange48);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(timeZone60);
        org.junit.Assert.assertNotNull(timeline64);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertNotNull(stroke72);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(lengthAdjustmentType76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNull(legendItemCollection79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertNotNull(range83);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
        org.junit.Assert.assertNotNull(range90);
        org.junit.Assert.assertNull(str94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + true + "'", boolean95 == true);
        org.junit.Assert.assertNotNull(valueAxisArray96);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (byte) 0, 8, 0);
    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test261");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        long long3 = day2.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
//        categoryPlot5.setDomainAxis((int) 'a', categoryAxis7);
//        categoryPlot5.setBackgroundImageAlignment((int) (short) 10);
//        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot5.getDatasetGroup();
//        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
//        categoryPlot5.setNoDataMessagePaint(paint12);
//        boolean boolean14 = day2.equals((java.lang.Object) categoryPlot5);
//        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D17 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
//        double double19 = numberAxis15.valueToJava2D((double) 10, rectangle2D17, rectangleEdge18);
//        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D22 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
//        double double24 = numberAxis20.valueToJava2D((double) 10, rectangle2D22, rectangleEdge23);
//        org.jfree.data.Range range25 = numberAxis20.getDefaultAutoRange();
//        numberAxis15.setRange(range25);
//        int int27 = categoryPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis15);
//        org.jfree.chart.event.AxisChangeListener axisChangeListener28 = null;
//        numberAxis15.removeChangeListener(axisChangeListener28);
//        org.jfree.data.Range range30 = numberAxis15.getRange();
//        java.awt.Paint paint31 = numberAxis15.getTickMarkPaint();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNull(datasetGroup11);
//        org.junit.Assert.assertNotNull(paint12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
//        org.junit.Assert.assertNotNull(range25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//        org.junit.Assert.assertNotNull(range30);
//        org.junit.Assert.assertNotNull(paint31);
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        double double5 = rectangleInsets4.getTop();
        double double7 = rectangleInsets4.calculateLeftInset(62.0d);
        double double9 = rectangleInsets4.extendHeight((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 52.0d + "'", double5 == 52.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 32.0d + "'", double7 == 32.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 152.0d + "'", double9 == 152.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeMinimumSize((double) 11, false);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color5, stroke6);
        numberAxis0.setLabelPaint((java.awt.Paint) color5);
        java.awt.Color color9 = java.awt.Color.yellow;
        numberAxis0.setAxisLinePaint((java.awt.Paint) color9);
        numberAxis0.setLabelToolTip("java.awt.Color[r=128,g=0,b=128]");
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        xYPlot0.setRangeAxisLocation(4, axisLocation8);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = numberAxis11.valueToJava2D((double) 10, rectangle2D13, rectangleEdge14);
        boolean boolean16 = numberAxis11.getAutoRangeStickyZero();
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis11);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = xYPlot0.getAxisOffset();
        double double20 = rectangleInsets18.calculateLeftOutset((double) (short) 100);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D24 = rectangleInsets18.createInsetRectangle(rectangle2D21, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.0d + "'", double20 == 4.0d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot3.setDomainAxis((int) 'a', categoryAxis5);
        categoryPlot3.clearAnnotations();
        boolean boolean8 = categoryPlot3.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace9 = categoryPlot3.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot3.setInsets(rectangleInsets10);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot3.getDomainAxisEdge((int) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        numberAxis15.setAutoRangeMinimumSize((double) 11, false);
        numberAxis15.setAutoRangeStickyZero(true);
        double double21 = numberAxis15.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
        double double26 = numberAxis22.valueToJava2D((double) 10, rectangle2D24, rectangleEdge25);
        org.jfree.data.Range range27 = numberAxis22.getDefaultAutoRange();
        numberAxis15.setRange(range27, true, true);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis15.setTickMarkPaint((java.awt.Paint) color31);
        categoryPlot3.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis15);
        categoryPlot3.clearRangeMarkers();
        java.awt.Color color36 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke37 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color36, stroke37);
        java.awt.Stroke stroke39 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker38.setOutlineStroke(stroke39);
        java.awt.Stroke stroke41 = valueMarker38.getStroke();
        categoryPlot3.setDomainGridlineStroke(stroke41);
        xYPlot0.setRangeGridlineStroke(stroke41);
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis();
        numberAxis45.setAutoRangeMinimumSize((double) 11, false);
        numberAxis45.setAutoRangeStickyZero(true);
        double double51 = numberAxis45.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = null;
        double double56 = numberAxis52.valueToJava2D((double) 10, rectangle2D54, rectangleEdge55);
        org.jfree.data.Range range57 = numberAxis52.getDefaultAutoRange();
        numberAxis45.setRange(range57, true, true);
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis45);
        org.jfree.chart.axis.AxisLocation axisLocation63 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        xYPlot0.setDomainAxisLocation(5, axisLocation63, true);
        java.awt.Paint paint66 = xYPlot0.getDomainZeroBaselinePaint();
        xYPlot0.setDomainCrosshairLockedOnData(true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertNotNull(axisLocation63);
        org.junit.Assert.assertNotNull(paint66);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(10.0d, (double) ' ');
        double double3 = intervalMarker2.getStartValue();
        intervalMarker2.setEndValue((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(10.0d, (double) ' ');
        double double3 = intervalMarker2.getEndValue();
        intervalMarker2.setEndValue((double) 4);
        double double6 = intervalMarker2.getStartValue();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
    }

//    @Test
//    public void test268() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test268");
//        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D2 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
//        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
//        org.jfree.data.Range range5 = numberAxis0.getDefaultAutoRange();
//        java.awt.Font font6 = numberAxis0.getTickLabelFont();
//        java.util.Date date7 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone8 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date7, timeZone8);
//        long long10 = day9.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate11 = day9.getSerialDate();
//        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
//        categoryPlot12.setDomainAxis((int) 'a', categoryAxis14);
//        categoryPlot12.setBackgroundImageAlignment((int) (short) 10);
//        org.jfree.data.general.DatasetGroup datasetGroup18 = categoryPlot12.getDatasetGroup();
//        java.awt.Paint paint19 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
//        categoryPlot12.setNoDataMessagePaint(paint19);
//        boolean boolean21 = day9.equals((java.lang.Object) categoryPlot12);
//        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D24 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
//        double double26 = numberAxis22.valueToJava2D((double) 10, rectangle2D24, rectangleEdge25);
//        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D29 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
//        double double31 = numberAxis27.valueToJava2D((double) 10, rectangle2D29, rectangleEdge30);
//        org.jfree.data.Range range32 = numberAxis27.getDefaultAutoRange();
//        numberAxis22.setRange(range32);
//        int int34 = categoryPlot12.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis22);
//        org.jfree.chart.event.AxisChangeListener axisChangeListener35 = null;
//        numberAxis22.removeChangeListener(axisChangeListener35);
//        org.jfree.data.Range range37 = numberAxis22.getRange();
//        numberAxis0.setRangeWithMargins(range37);
//        boolean boolean39 = numberAxis0.isAutoTickUnitSelection();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
//        org.junit.Assert.assertNotNull(range5);
//        org.junit.Assert.assertNotNull(font6);
//        org.junit.Assert.assertNotNull(date7);
//        org.junit.Assert.assertNotNull(timeZone8);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1560409200000L + "'", long10 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate11);
//        org.junit.Assert.assertNull(datasetGroup18);
//        org.junit.Assert.assertNotNull(paint19);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
//        org.junit.Assert.assertNotNull(range32);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertNotNull(range37);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeMinimumSize((double) 11, false);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color5, stroke6);
        numberAxis0.setLabelPaint((java.awt.Paint) color5);
        numberAxis0.setPositiveArrowVisible(true);
        org.jfree.chart.plot.Plot plot11 = numberAxis0.getPlot();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.Plot plot13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot15.setDomainAxis((int) 'a', categoryAxis17);
        categoryPlot15.clearAnnotations();
        boolean boolean20 = categoryPlot15.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace21 = categoryPlot15.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot15.setInsets(rectangleInsets22);
        categoryPlot15.setWeight((int) (short) 1);
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color27, stroke28);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = valueMarker29.getLabelAnchor();
        boolean boolean31 = categoryPlot15.equals((java.lang.Object) rectangleAnchor30);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = categoryPlot15.getRangeAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        categoryPlot33.setDomainAxis((int) 'a', categoryAxis35);
        categoryPlot33.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        categoryPlot33.setDataset(0, categoryDataset39);
        java.awt.Paint paint41 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot33.setNoDataMessagePaint(paint41);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = categoryPlot33.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent45 = null;
        categoryPlot33.rendererChanged(rendererChangeEvent45);
        org.jfree.chart.util.Layer layer48 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection49 = categoryPlot33.getRangeMarkers((int) (byte) -1, layer48);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj52 = null;
        boolean boolean53 = categoryAxis51.equals(obj52);
        categoryAxis51.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis51.clearCategoryLabelToolTips();
        categoryAxis51.setTickLabelsVisible(false);
        java.awt.Graphics2D graphics2D60 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot61 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis63 = null;
        categoryPlot61.setDomainAxis((int) 'a', categoryAxis63);
        categoryPlot61.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset67 = null;
        categoryPlot61.setDataset(0, categoryDataset67);
        java.awt.Paint paint69 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot61.setNoDataMessagePaint(paint69);
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = categoryPlot61.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent73 = null;
        categoryPlot61.rendererChanged(rendererChangeEvent73);
        org.jfree.chart.util.Layer layer76 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection77 = categoryPlot61.getRangeMarkers((int) (byte) -1, layer76);
        java.awt.geom.Rectangle2D rectangle2D78 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge79 = null;
        org.jfree.chart.axis.AxisSpace axisSpace80 = null;
        org.jfree.chart.axis.AxisSpace axisSpace81 = categoryAxis51.reserveSpace(graphics2D60, (org.jfree.chart.plot.Plot) categoryPlot61, rectangle2D78, rectangleEdge79, axisSpace80);
        categoryPlot33.setFixedRangeAxisSpace(axisSpace81, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation84 = categoryPlot33.getOrientation();
        categoryPlot33.setRangeCrosshairValue((double) 10L);
        org.jfree.chart.axis.AxisSpace axisSpace87 = categoryPlot33.getFixedRangeAxisSpace();
        try {
            org.jfree.chart.axis.AxisSpace axisSpace88 = numberAxis0.reserveSpace(graphics2D12, plot13, rectangle2D14, rectangleEdge32, axisSpace87);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(plot11);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNull(axisSpace21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertNotNull(layer48);
        org.junit.Assert.assertNull(collection49);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertNotNull(rectangleEdge72);
        org.junit.Assert.assertNotNull(layer76);
        org.junit.Assert.assertNull(collection77);
        org.junit.Assert.assertNotNull(axisSpace81);
        org.junit.Assert.assertNotNull(plotOrientation84);
        org.junit.Assert.assertNotNull(axisSpace87);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        float float6 = categoryPlot0.getBackgroundAlpha();
        java.lang.String str7 = categoryPlot0.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        double double14 = rectangleInsets12.calculateLeftInset((double) (-1));
        double double15 = rectangleInsets12.getBottom();
        org.jfree.data.general.Dataset dataset16 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) double15, dataset16);
        categoryPlot0.datasetChanged(datasetChangeEvent17);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        categoryPlot0.setRenderer(categoryItemRenderer19, false);
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot0.getRangeAxis();
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = categoryPlot0.getOrientation();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        categoryPlot24.setDomainAxis((int) 'a', categoryAxis26);
        categoryPlot24.clearAnnotations();
        boolean boolean29 = categoryPlot24.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace30 = categoryPlot24.getFixedDomainAxisSpace();
        boolean boolean31 = categoryPlot24.isRangeZoomable();
        categoryPlot24.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot24.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        categoryPlot24.setDataset(categoryDataset35);
        boolean boolean37 = plotOrientation23.equals((java.lang.Object) categoryPlot24);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Category Plot" + "'", str7.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 32.0d + "'", double14 == 32.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNull(valueAxis22);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNull(axisSpace30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot0.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot0.setRenderer(categoryItemRenderer14, true);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = numberAxis18.valueToJava2D((double) 10, rectangle2D20, rectangleEdge21);
        org.jfree.data.Range range23 = numberAxis18.getDefaultAutoRange();
        numberAxis18.zoomRange((double) 0L, (double) 3);
        java.lang.String str27 = numberAxis18.getLabel();
        categoryPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis18, false);
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font34 = null;
        categoryAxis32.setTickLabelFont((java.lang.Comparable) (byte) -1, font34);
        java.lang.String str36 = categoryAxis32.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = numberAxis37.valueToJava2D((double) 10, rectangle2D39, rectangleEdge40);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.axis.AxisState axisState43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = null;
        java.util.List list46 = numberAxis37.refreshTicks(graphics2D42, axisState43, rectangle2D44, rectangleEdge45);
        numberAxis37.setLabel("RectangleAnchor.TOP_LEFT");
        numberAxis37.zoomRange((double) (-1L), (double) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis32, (org.jfree.chart.axis.ValueAxis) numberAxis37, categoryItemRenderer52);
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = null;
        double double58 = numberAxis54.valueToJava2D((double) 10, rectangle2D56, rectangleEdge57);
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D61 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = null;
        double double63 = numberAxis59.valueToJava2D((double) 10, rectangle2D61, rectangleEdge62);
        org.jfree.data.Range range64 = numberAxis59.getDefaultAutoRange();
        numberAxis54.setRange(range64);
        numberAxis37.setRangeWithMargins(range64);
        numberAxis18.setRangeWithMargins(range64, false, false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNull(str36);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(list46);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(range64);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis((int) 'a', categoryAxis7);
        categoryPlot5.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color12, stroke13);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker14.setOutlineStroke(stroke15);
        java.awt.Stroke stroke17 = valueMarker14.getOutlineStroke();
        boolean boolean18 = categoryPlot5.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker14);
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean21 = layer19.equals((java.lang.Object) dateRange20);
        java.lang.String str22 = layer19.toString();
        xYPlot0.addDomainMarker((int) '#', (org.jfree.chart.plot.Marker) valueMarker14, layer19);
        org.jfree.chart.plot.IntervalMarker intervalMarker26 = new org.jfree.chart.plot.IntervalMarker(10.0d, (double) ' ');
        intervalMarker26.setEndValue((double) 6);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker26, layer29);
        org.jfree.data.xy.XYDataset xYDataset31 = xYPlot0.getDataset();
        int int32 = xYPlot0.getRangeAxisCount();
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        double double37 = numberAxis33.valueToJava2D((double) 10, rectangle2D35, rectangleEdge36);
        org.jfree.data.Range range38 = numberAxis33.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = null;
        double double43 = numberAxis39.valueToJava2D((double) 10, rectangle2D41, rectangleEdge42);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = null;
        double double48 = numberAxis44.valueToJava2D((double) 10, rectangle2D46, rectangleEdge47);
        org.jfree.data.Range range49 = numberAxis44.getDefaultAutoRange();
        numberAxis39.setRange(range49);
        numberAxis33.setDefaultAutoRange(range49);
        java.awt.Shape shape52 = numberAxis33.getDownArrow();
        boolean boolean53 = numberAxis33.isAutoRange();
        int int54 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis33);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(layer19);
        org.junit.Assert.assertNotNull(dateRange20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Layer.FOREGROUND" + "'", str22.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(xYDataset31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(range49);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color2, stroke3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker4.setOutlineStroke(stroke5);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker4.setLabelOffsetType(lengthAdjustmentType7);
        boolean boolean9 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker4);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = xYPlot0.getFixedLegendItems();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot11.setDomainAxis((int) 'a', categoryAxis13);
        categoryPlot11.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        categoryPlot11.setDataset(0, categoryDataset17);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot11.setNoDataMessagePaint(paint19);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot11.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        categoryPlot11.rendererChanged(rendererChangeEvent23);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection27 = categoryPlot11.getRangeMarkers((int) (byte) -1, layer26);
        java.util.Collection collection28 = xYPlot0.getRangeMarkers(layer26);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset30);
        xYPlot0.configureRangeAxes();
        xYPlot0.clearDomainMarkers();
        double double34 = xYPlot0.getDomainCrosshairValue();
        java.awt.Paint paint35 = xYPlot0.getRangeCrosshairPaint();
        boolean boolean36 = xYPlot0.isDomainZoomable();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setRange((double) (byte) 10, 100.0d);
        java.text.DateFormat dateFormat4 = dateAxis0.getDateFormatOverride();
        double double5 = dateAxis0.getFixedAutoRange();
        java.util.Date date6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis7, jFreeChart8);
        java.util.Date date10 = dateAxis7.getMinimumDate();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.TickUnitSource tickUnitSource12 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date10, timeZone11);
        try {
            dateAxis0.setRange(date6, date10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(dateFormat4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNotNull(tickUnitSource12);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        java.awt.Paint paint2 = xYPlot0.getRangeGridlinePaint();
        java.awt.Stroke stroke3 = xYPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test276");
//        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
//        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
//        long long4 = day3.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
//        categoryPlot6.setDomainAxis((int) 'a', categoryAxis8);
//        categoryPlot6.setBackgroundImageAlignment((int) (short) 10);
//        org.jfree.data.general.DatasetGroup datasetGroup12 = categoryPlot6.getDatasetGroup();
//        java.awt.Paint paint13 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
//        categoryPlot6.setNoDataMessagePaint(paint13);
//        boolean boolean15 = day3.equals((java.lang.Object) categoryPlot6);
//        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("");
//        java.awt.Font font20 = null;
//        categoryAxis18.setTickLabelFont((java.lang.Comparable) (byte) -1, font20);
//        categoryPlot6.setDomainAxis(10, categoryAxis18);
//        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
//        dateAxis23.setRange((double) (byte) 10, 100.0d);
//        org.jfree.chart.axis.Timeline timeline27 = null;
//        dateAxis23.setTimeline(timeline27);
//        org.jfree.chart.axis.Timeline timeline29 = null;
//        dateAxis23.setTimeline(timeline29);
//        dateAxis23.configure();
//        java.awt.Stroke stroke32 = dateAxis23.getTickMarkStroke();
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis23, categoryItemRenderer33);
//        java.util.Date date35 = dateAxis23.getMinimumDate();
//        dateAxis23.setAutoRange(false);
//        org.junit.Assert.assertNotNull(date1);
//        org.junit.Assert.assertNotNull(timeZone2);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560409200000L + "'", long4 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNull(datasetGroup12);
//        org.junit.Assert.assertNotNull(paint13);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNotNull(stroke32);
//        org.junit.Assert.assertNotNull(date35);
//    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) 1, (double) 11, (double) 0L);
        java.lang.String str5 = rectangleInsets4.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleInsets[t=10.0,l=1.0,b=11.0,r=0.0]" + "'", str5.equals("RectangleInsets[t=10.0,l=1.0,b=11.0,r=0.0]"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("");
        org.jfree.chart.plot.XYPlot xYPlot2 = new org.jfree.chart.plot.XYPlot();
        int int3 = xYPlot2.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        xYPlot2.zoomRangeAxes((double) 255, plotRenderingInfo5, point2D6, true);
        boolean boolean9 = xYPlot2.isDomainCrosshairVisible();
        boolean boolean10 = xYPlot2.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = numberAxis11.valueToJava2D((double) 10, rectangle2D13, rectangleEdge14);
        org.jfree.data.Range range16 = numberAxis11.getDefaultAutoRange();
        numberAxis11.zoomRange((double) 0L, (double) 3);
        int int20 = xYPlot2.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis11);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.JFreeChart jFreeChart22 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis21, jFreeChart22);
        org.jfree.data.time.DateRange dateRange24 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis21.setRange((org.jfree.data.Range) dateRange24);
        numberAxis11.setRange((org.jfree.data.Range) dateRange24, true, false);
        dateAxis1.setRange((org.jfree.data.Range) dateRange24);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(dateRange24);
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test279");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        long long3 = day2.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
//        categoryPlot5.setDomainAxis((int) 'a', categoryAxis7);
//        categoryPlot5.setBackgroundImageAlignment((int) (short) 10);
//        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot5.getDatasetGroup();
//        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
//        categoryPlot5.setNoDataMessagePaint(paint12);
//        boolean boolean14 = day2.equals((java.lang.Object) categoryPlot5);
//        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
//        java.awt.Font font19 = null;
//        categoryAxis17.setTickLabelFont((java.lang.Comparable) (byte) -1, font19);
//        java.lang.String str21 = categoryAxis17.getLabelToolTip();
//        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D24 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
//        double double26 = numberAxis22.valueToJava2D((double) 10, rectangle2D24, rectangleEdge25);
//        java.awt.Graphics2D graphics2D27 = null;
//        org.jfree.chart.axis.AxisState axisState28 = null;
//        java.awt.geom.Rectangle2D rectangle2D29 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
//        java.util.List list31 = numberAxis22.refreshTicks(graphics2D27, axisState28, rectangle2D29, rectangleEdge30);
//        numberAxis22.setLabel("RectangleAnchor.TOP_LEFT");
//        numberAxis22.zoomRange((double) (-1L), (double) 1);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis17, (org.jfree.chart.axis.ValueAxis) numberAxis22, categoryItemRenderer37);
//        int int39 = categoryPlot5.getDomainAxisIndex(categoryAxis17);
//        java.util.Date date40 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date40, timeZone41);
//        java.awt.Paint paint43 = categoryAxis17.getTickLabelPaint((java.lang.Comparable) date40);
//        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions44 = categoryAxis17.getCategoryLabelPositions();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNull(datasetGroup11);
//        org.junit.Assert.assertNotNull(paint12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNull(str21);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
//        org.junit.Assert.assertNotNull(list31);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(timeZone41);
//        org.junit.Assert.assertNotNull(paint43);
//        org.junit.Assert.assertNotNull(categoryLabelPositions44);
//    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryAxis1.equals(obj2);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(false);
        categoryAxis1.setUpperMargin((double) 2);
        categoryAxis1.setCategoryMargin((double) 'a');
        int int14 = categoryAxis1.getCategoryLabelPositionOffset();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test281");
//        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
//        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
//        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
//        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
//        double double7 = rectangleInsets5.calculateRightInset(11.0d);
//        categoryPlot0.setInsets(rectangleInsets5);
//        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
//        categoryPlot9.setDomainAxis((int) 'a', categoryAxis11);
//        categoryPlot9.setBackgroundImageAlignment((int) (short) 10);
//        float float15 = categoryPlot9.getBackgroundAlpha();
//        categoryPlot9.clearRangeAxes();
//        boolean boolean17 = rectangleInsets5.equals((java.lang.Object) categoryPlot9);
//        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
//        int int19 = xYPlot18.getDomainAxisCount();
//        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent20 = null;
//        xYPlot18.rendererChanged(rendererChangeEvent20);
//        org.jfree.chart.util.RectangleEdge rectangleEdge22 = xYPlot18.getDomainAxisEdge();
//        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
//        categoryPlot23.setDomainAxis((int) 'a', categoryAxis25);
//        categoryPlot23.clearAnnotations();
//        boolean boolean28 = categoryPlot23.isOutlineVisible();
//        categoryPlot23.setRangeCrosshairValue((double) 1L);
//        java.util.Date date32 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone33 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32, timeZone33);
//        long long35 = day34.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate36 = day34.getSerialDate();
//        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
//        categoryPlot37.setDomainAxis((int) 'a', categoryAxis39);
//        categoryPlot37.setBackgroundImageAlignment((int) (short) 10);
//        org.jfree.data.general.DatasetGroup datasetGroup43 = categoryPlot37.getDatasetGroup();
//        java.awt.Paint paint44 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
//        categoryPlot37.setNoDataMessagePaint(paint44);
//        boolean boolean46 = day34.equals((java.lang.Object) categoryPlot37);
//        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D49 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge50 = null;
//        double double51 = numberAxis47.valueToJava2D((double) 10, rectangle2D49, rectangleEdge50);
//        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D54 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge55 = null;
//        double double56 = numberAxis52.valueToJava2D((double) 10, rectangle2D54, rectangleEdge55);
//        org.jfree.data.Range range57 = numberAxis52.getDefaultAutoRange();
//        numberAxis47.setRange(range57);
//        int int59 = categoryPlot37.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis47);
//        numberAxis47.configure();
//        categoryPlot23.setRangeAxis((int) (short) 0, (org.jfree.chart.axis.ValueAxis) numberAxis47);
//        org.jfree.chart.axis.ValueAxis[] valueAxisArray62 = new org.jfree.chart.axis.ValueAxis[] { numberAxis47 };
//        xYPlot18.setRangeAxes(valueAxisArray62);
//        categoryPlot9.setRangeAxes(valueAxisArray62);
//        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray65 = new org.jfree.chart.axis.CategoryAxis[] {};
//        categoryPlot9.setDomainAxes(categoryAxisArray65);
//        org.junit.Assert.assertNotNull(stroke4);
//        org.junit.Assert.assertNotNull(rectangleInsets5);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
//        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(rectangleEdge22);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
//        org.junit.Assert.assertNotNull(date32);
//        org.junit.Assert.assertNotNull(timeZone33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1560409200000L + "'", long35 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate36);
//        org.junit.Assert.assertNull(datasetGroup43);
//        org.junit.Assert.assertNotNull(paint44);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
//        org.junit.Assert.assertNotNull(range57);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
//        org.junit.Assert.assertNotNull(valueAxisArray62);
//        org.junit.Assert.assertNotNull(categoryAxisArray65);
//    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        categoryPlot0.setDataset(categoryDataset1);
        categoryPlot0.mapDatasetToRangeAxis((int) (byte) 100, (int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation6, plotOrientation7);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = org.jfree.chart.axis.CategoryAnchor.END;
        boolean boolean10 = axisLocation6.equals((java.lang.Object) categoryAnchor9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot11.setDomainAxis((int) 'a', categoryAxis13);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = categoryPlot11.getDrawingSupplier();
        boolean boolean16 = categoryPlot11.isDomainZoomable();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot11.getRenderer();
        boolean boolean18 = categoryAnchor9.equals((java.lang.Object) categoryPlot11);
        categoryPlot0.setDomainGridlinePosition(categoryAnchor9);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(categoryItemRenderer17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryAxis1.equals(obj2);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(false);
        categoryAxis1.setUpperMargin((double) 2);
        java.awt.Color color13 = java.awt.Color.gray;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (-1.0f), (java.awt.Paint) color13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        boolean boolean16 = categoryAxis1.equals((java.lang.Object) color15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryAxis1.getTickLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation22 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation21, plotOrientation22);
        org.jfree.data.general.Dataset dataset24 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent25 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleEdge23, dataset24);
        try {
            double double26 = categoryAxis1.getCategoryStart(255, 10, rectangle2D20, rectangleEdge23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(plotOrientation22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker9.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = valueMarker9.getOutlineStroke();
        boolean boolean13 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot0.setOrientation(plotOrientation14);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        categoryPlot16.setDomainAxis((int) 'a', categoryAxis18);
        categoryPlot16.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.data.general.DatasetGroup datasetGroup22 = categoryPlot16.getDatasetGroup();
        java.awt.Paint paint23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        categoryPlot16.setNoDataMessagePaint(paint23);
        categoryPlot0.setRangeGridlinePaint(paint23);
        boolean boolean26 = categoryPlot0.isRangeZoomable();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNull(datasetGroup22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.valueToJava2D((double) 10, rectangle2D4, rectangleEdge5);
        org.jfree.data.Range range7 = numberAxis2.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = numberAxis8.valueToJava2D((double) 10, rectangle2D10, rectangleEdge11);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = numberAxis13.valueToJava2D((double) 10, rectangle2D15, rectangleEdge16);
        org.jfree.data.Range range18 = numberAxis13.getDefaultAutoRange();
        numberAxis8.setRange(range18);
        numberAxis2.setDefaultAutoRange(range18);
        boolean boolean21 = objectList1.equals((java.lang.Object) numberAxis2);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeMinimumSize((double) 11, false);
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color27, stroke28);
        numberAxis22.setLabelPaint((java.awt.Paint) color27);
        numberAxis22.setPositiveArrowVisible(true);
        int int33 = objectList1.indexOf((java.lang.Object) numberAxis22);
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot();
        int int36 = xYPlot35.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        xYPlot35.zoomRangeAxes((double) 255, plotRenderingInfo38, point2D39, true);
        org.jfree.chart.axis.AxisLocation axisLocation43 = null;
        xYPlot35.setRangeAxisLocation(4, axisLocation43);
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = null;
        double double50 = numberAxis46.valueToJava2D((double) 10, rectangle2D48, rectangleEdge49);
        boolean boolean51 = numberAxis46.getAutoRangeStickyZero();
        xYPlot35.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis46);
        xYPlot35.setRangeZeroBaselineVisible(false);
        org.jfree.chart.LegendItemCollection legendItemCollection55 = xYPlot35.getLegendItems();
        try {
            objectList1.set(100, (java.lang.Object) legendItemCollection55);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(legendItemCollection55);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        boolean boolean7 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        int int12 = xYPlot11.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot11.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        int int17 = xYPlot16.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = xYPlot16.getRangeAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        categoryPlot19.setDomainAxis((int) 'a', categoryAxis21);
        categoryPlot19.clearAnnotations();
        boolean boolean24 = categoryPlot19.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace25 = categoryPlot19.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot19.setInsets(rectangleInsets26);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot19.getDomainAxisEdge((int) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis();
        numberAxis31.setAutoRangeMinimumSize((double) 11, false);
        numberAxis31.setAutoRangeStickyZero(true);
        double double37 = numberAxis31.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        double double42 = numberAxis38.valueToJava2D((double) 10, rectangle2D40, rectangleEdge41);
        org.jfree.data.Range range43 = numberAxis38.getDefaultAutoRange();
        numberAxis31.setRange(range43, true, true);
        java.awt.Color color47 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis31.setTickMarkPaint((java.awt.Paint) color47);
        categoryPlot19.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis31);
        categoryPlot19.clearRangeMarkers();
        java.awt.Color color52 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke53 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker54 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color52, stroke53);
        java.awt.Stroke stroke55 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker54.setOutlineStroke(stroke55);
        java.awt.Stroke stroke57 = valueMarker54.getStroke();
        categoryPlot19.setDomainGridlineStroke(stroke57);
        xYPlot16.setRangeGridlineStroke(stroke57);
        org.jfree.chart.axis.NumberAxis numberAxis61 = new org.jfree.chart.axis.NumberAxis();
        numberAxis61.setAutoRangeMinimumSize((double) 11, false);
        numberAxis61.setAutoRangeStickyZero(true);
        double double67 = numberAxis61.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis68 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = null;
        double double72 = numberAxis68.valueToJava2D((double) 10, rectangle2D70, rectangleEdge71);
        org.jfree.data.Range range73 = numberAxis68.getDefaultAutoRange();
        numberAxis61.setRange(range73, true, true);
        xYPlot16.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis61);
        org.jfree.chart.plot.CategoryPlot categoryPlot78 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis80 = null;
        categoryPlot78.setDomainAxis((int) 'a', categoryAxis80);
        categoryPlot78.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset84 = null;
        categoryPlot78.setDataset(0, categoryDataset84);
        float float86 = categoryPlot78.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets87 = categoryPlot78.getAxisOffset();
        java.awt.Color color88 = java.awt.Color.red;
        categoryPlot78.setRangeGridlinePaint((java.awt.Paint) color88);
        xYPlot16.setDomainCrosshairPaint((java.awt.Paint) color88);
        java.awt.geom.Point2D point2D91 = xYPlot16.getQuadrantOrigin();
        xYPlot11.zoomDomainAxes((double) 1560409200000L, plotRenderingInfo15, point2D91, true);
        xYPlot0.zoomDomainAxes(32.0d, (double) (byte) 1, plotRenderingInfo10, point2D91);
        double double95 = xYPlot0.getRangeCrosshairValue();
        xYPlot0.setRangeGridlinesVisible(false);
        java.awt.Image image98 = null;
        xYPlot0.setBackgroundImage(image98);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(axisSpace25);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(range73);
        org.junit.Assert.assertTrue("'" + float86 + "' != '" + 1.0f + "'", float86 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets87);
        org.junit.Assert.assertNotNull(color88);
        org.junit.Assert.assertNotNull(point2D91);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 0.0d + "'", double95 == 0.0d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.mapDatasetToDomainAxis((int) (byte) 100, 1);
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 2, dataset5);
        xYPlot0.datasetChanged(datasetChangeEvent6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        int int9 = xYPlot8.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        xYPlot8.zoomRangeAxes((double) 255, plotRenderingInfo11, point2D12, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot15.setDomainAxis((int) 'a', categoryAxis17);
        categoryPlot15.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot15.setDataset(0, categoryDataset21);
        java.awt.Paint paint23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot15.setNoDataMessagePaint(paint23);
        java.awt.Paint paint25 = categoryPlot15.getOutlinePaint();
        int int26 = categoryPlot15.getDomainAxisCount();
        java.lang.Class<?> wildcardClass27 = categoryPlot15.getClass();
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        categoryPlot29.setDomainAxis((int) 'a', categoryAxis31);
        categoryPlot29.clearAnnotations();
        boolean boolean34 = categoryPlot29.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace35 = categoryPlot29.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot29.setInsets(rectangleInsets36);
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation39 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation38, plotOrientation39);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor41 = org.jfree.chart.axis.CategoryAnchor.END;
        boolean boolean42 = axisLocation38.equals((java.lang.Object) categoryAnchor41);
        categoryPlot29.setRangeAxisLocation(axisLocation38, false);
        categoryPlot15.setRangeAxisLocation((int) (short) 10, axisLocation38, false);
        xYPlot8.setRangeAxisLocation(axisLocation38, true);
        xYPlot0.setRangeAxisLocation(axisLocation38);
        java.awt.geom.Point2D point2D50 = xYPlot0.getQuadrantOrigin();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 98 + "'", int26 == 98);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNull(axisSpace35);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(plotOrientation39);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertNotNull(categoryAnchor41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(point2D50);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.data.Range range5 = numberAxis0.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis6.valueToJava2D((double) 10, rectangle2D8, rectangleEdge9);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = numberAxis11.valueToJava2D((double) 10, rectangle2D13, rectangleEdge14);
        org.jfree.data.Range range16 = numberAxis11.getDefaultAutoRange();
        numberAxis6.setRange(range16);
        numberAxis0.setDefaultAutoRange(range16);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = null;
        numberAxis0.setStandardTickUnits(tickUnitSource19);
        numberAxis0.resizeRange((double) 0.0f);
        numberAxis0.setUpperBound(100.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(range16);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setRange((double) (byte) 10, 100.0d);
        org.jfree.chart.axis.Timeline timeline4 = null;
        dateAxis0.setTimeline(timeline4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        int int7 = xYPlot6.getDomainAxisCount();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder8 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        xYPlot6.setSeriesRenderingOrder(seriesRenderingOrder8);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        xYPlot10.setRangeAxisLocation((int) (short) 100, axisLocation12);
        xYPlot10.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = numberAxis15.valueToJava2D((double) 10, rectangle2D17, rectangleEdge18);
        java.awt.Paint paint20 = numberAxis15.getTickMarkPaint();
        xYPlot10.setDomainTickBandPaint(paint20);
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color25, stroke26);
        boolean boolean28 = axisLocation23.equals((java.lang.Object) valueMarker27);
        float float29 = valueMarker27.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = valueMarker27.getLabelAnchor();
        org.jfree.chart.util.Layer layer31 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange32 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean33 = layer31.equals((java.lang.Object) dateRange32);
        java.lang.String str34 = layer31.toString();
        xYPlot10.addDomainMarker((int) (short) 100, (org.jfree.chart.plot.Marker) valueMarker27, layer31);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis();
        numberAxis36.setAutoRangeMinimumSize((double) 11, false);
        numberAxis36.setAutoRangeStickyZero(true);
        double double42 = numberAxis36.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = null;
        double double47 = numberAxis43.valueToJava2D((double) 10, rectangle2D45, rectangleEdge46);
        org.jfree.data.Range range48 = numberAxis43.getDefaultAutoRange();
        numberAxis36.setRange(range48, true, true);
        java.awt.Color color52 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis36.setTickMarkPaint((java.awt.Paint) color52);
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = null;
        double double58 = numberAxis54.valueToJava2D((double) 10, rectangle2D56, rectangleEdge57);
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D61 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = null;
        double double63 = numberAxis59.valueToJava2D((double) 10, rectangle2D61, rectangleEdge62);
        org.jfree.data.Range range64 = numberAxis59.getDefaultAutoRange();
        numberAxis54.setRange(range64);
        boolean boolean66 = color52.equals((java.lang.Object) numberAxis54);
        xYPlot10.setRangeGridlinePaint((java.awt.Paint) color52);
        xYPlot10.clearDomainMarkers();
        java.awt.Graphics2D graphics2D69 = null;
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo71 = null;
        xYPlot10.drawAnnotations(graphics2D69, rectangle2D70, plotRenderingInfo71);
        org.jfree.chart.plot.XYPlot xYPlot73 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation75 = null;
        xYPlot73.setRangeAxisLocation((int) (short) 100, axisLocation75);
        org.jfree.chart.axis.NumberAxis numberAxis78 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D80 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge81 = null;
        double double82 = numberAxis78.valueToJava2D((double) 10, rectangle2D80, rectangleEdge81);
        org.jfree.data.Range range83 = numberAxis78.getDefaultAutoRange();
        numberAxis78.zoomRange((double) 0L, (double) 3);
        boolean boolean87 = numberAxis78.isNegativeArrowVisible();
        xYPlot73.setDomainAxis(255, (org.jfree.chart.axis.ValueAxis) numberAxis78, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder90 = xYPlot73.getDatasetRenderingOrder();
        xYPlot10.setDatasetRenderingOrder(datasetRenderingOrder90);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer92 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray93 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer92 };
        xYPlot10.setRenderers(xYItemRendererArray93);
        xYPlot6.setRenderers(xYItemRendererArray93);
        dateAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(seriesRenderingOrder8);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 1.0f + "'", float29 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNotNull(layer31);
        org.junit.Assert.assertNotNull(dateRange32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Layer.FOREGROUND" + "'", str34.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(range64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertNotNull(range83);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder90);
        org.junit.Assert.assertNotNull(xYItemRendererArray93);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double7 = rectangleInsets5.calculateRightInset(11.0d);
        categoryPlot0.setInsets(rectangleInsets5);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot9.setDomainAxis((int) 'a', categoryAxis11);
        categoryPlot9.setBackgroundImageAlignment((int) (short) 10);
        float float15 = categoryPlot9.getBackgroundAlpha();
        categoryPlot9.clearRangeAxes();
        boolean boolean17 = rectangleInsets5.equals((java.lang.Object) categoryPlot9);
        categoryPlot9.setRangeCrosshairValue(0.0d);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = categoryPlot9.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test291");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        long long3 = day2.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        int int5 = day2.getMonth();
//        long long6 = day2.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day2.previous();
//        java.util.Calendar calendar8 = null;
//        try {
//            long long9 = day2.getMiddleMillisecond(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        categoryPlot0.setDataset(categoryDataset1);
        categoryPlot0.setBackgroundImageAlignment(0);
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot0.getDomainAxisLocation((-393216));
        org.junit.Assert.assertNotNull(axisLocation6);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        xYPlot0.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis5.getTickMarkPaint();
        xYPlot0.setDomainTickBandPaint(paint10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color15, stroke16);
        boolean boolean18 = axisLocation13.equals((java.lang.Object) valueMarker17);
        float float19 = valueMarker17.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = valueMarker17.getLabelAnchor();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean23 = layer21.equals((java.lang.Object) dateRange22);
        java.lang.String str24 = layer21.toString();
        xYPlot0.addDomainMarker((int) (short) 100, (org.jfree.chart.plot.Marker) valueMarker17, layer21);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        numberAxis26.setAutoRangeMinimumSize((double) 11, false);
        numberAxis26.setAutoRangeStickyZero(true);
        double double32 = numberAxis26.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        double double37 = numberAxis33.valueToJava2D((double) 10, rectangle2D35, rectangleEdge36);
        org.jfree.data.Range range38 = numberAxis33.getDefaultAutoRange();
        numberAxis26.setRange(range38, true, true);
        java.awt.Color color42 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis26.setTickMarkPaint((java.awt.Paint) color42);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = null;
        double double48 = numberAxis44.valueToJava2D((double) 10, rectangle2D46, rectangleEdge47);
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = null;
        double double53 = numberAxis49.valueToJava2D((double) 10, rectangle2D51, rectangleEdge52);
        org.jfree.data.Range range54 = numberAxis49.getDefaultAutoRange();
        numberAxis44.setRange(range54);
        boolean boolean56 = color42.equals((java.lang.Object) numberAxis44);
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color42);
        xYPlot0.clearDomainMarkers();
        java.awt.Graphics2D graphics2D59 = null;
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo61 = null;
        xYPlot0.drawAnnotations(graphics2D59, rectangle2D60, plotRenderingInfo61);
        org.jfree.chart.plot.CategoryPlot categoryPlot64 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis66 = null;
        categoryPlot64.setDomainAxis((int) 'a', categoryAxis66);
        categoryPlot64.setBackgroundImageAlignment((int) (short) 10);
        float float70 = categoryPlot64.getBackgroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation71 = categoryPlot64.getRangeAxisLocation();
        xYPlot0.setDomainAxisLocation((int) (short) 1, axisLocation71, false);
        int int74 = xYPlot0.getWeight();
        org.jfree.chart.plot.CategoryPlot categoryPlot75 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint76 = categoryPlot75.getDomainGridlinePaint();
        java.awt.Stroke stroke77 = categoryPlot75.getDomainGridlineStroke();
        xYPlot0.setDomainZeroBaselineStroke(stroke77);
        java.awt.Graphics2D graphics2D79 = null;
        java.awt.geom.Rectangle2D rectangle2D80 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo82 = null;
        org.jfree.chart.plot.CrosshairState crosshairState83 = null;
        boolean boolean84 = xYPlot0.render(graphics2D79, rectangle2D80, 0, plotRenderingInfo82, crosshairState83);
        xYPlot0.setRangeGridlinesVisible(true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Layer.FOREGROUND" + "'", str24.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + float70 + "' != '" + 1.0f + "'", float70 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation71);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertNotNull(stroke77);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test294");
//        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
//        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
//        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
//        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
//        double double7 = rectangleInsets5.calculateRightInset(11.0d);
//        categoryPlot0.setInsets(rectangleInsets5);
//        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
//        categoryPlot9.setDomainAxis((int) 'a', categoryAxis11);
//        categoryPlot9.setBackgroundImageAlignment((int) (short) 10);
//        float float15 = categoryPlot9.getBackgroundAlpha();
//        categoryPlot9.clearRangeAxes();
//        boolean boolean17 = rectangleInsets5.equals((java.lang.Object) categoryPlot9);
//        categoryPlot9.setRangeCrosshairValue(0.0d);
//        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
//        org.jfree.chart.plot.PlotOrientation plotOrientation21 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
//        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation20, plotOrientation21);
//        java.util.Date date23 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone24 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date23, timeZone24);
//        java.awt.Color color26 = java.awt.Color.gray;
//        int int27 = color26.getBlue();
//        float[] floatArray28 = null;
//        float[] floatArray29 = color26.getComponents(floatArray28);
//        boolean boolean30 = day25.equals((java.lang.Object) floatArray28);
//        int int31 = day25.getDayOfMonth();
//        long long32 = day25.getSerialIndex();
//        boolean boolean33 = plotOrientation21.equals((java.lang.Object) day25);
//        categoryPlot9.setOrientation(plotOrientation21);
//        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot();
//        int int36 = xYPlot35.getDomainAxisCount();
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
//        java.awt.geom.Point2D point2D39 = null;
//        xYPlot35.zoomRangeAxes((double) 255, plotRenderingInfo38, point2D39, true);
//        org.jfree.chart.axis.AxisLocation axisLocation43 = null;
//        xYPlot35.setRangeAxisLocation(4, axisLocation43);
//        org.jfree.chart.axis.AxisLocation axisLocation45 = xYPlot35.getDomainAxisLocation();
//        org.jfree.chart.util.RectangleInsets rectangleInsets50 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
//        double double51 = rectangleInsets50.getTop();
//        double double53 = rectangleInsets50.calculateLeftInset(62.0d);
//        org.jfree.chart.text.TextAnchor textAnchor54 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
//        java.awt.Paint paint55 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
//        boolean boolean56 = textAnchor54.equals((java.lang.Object) paint55);
//        boolean boolean57 = rectangleInsets50.equals((java.lang.Object) paint55);
//        xYPlot35.setRangeTickBandPaint(paint55);
//        categoryPlot9.setNoDataMessagePaint(paint55);
//        org.junit.Assert.assertNotNull(stroke4);
//        org.junit.Assert.assertNotNull(rectangleInsets5);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
//        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertNotNull(axisLocation20);
//        org.junit.Assert.assertNotNull(plotOrientation21);
//        org.junit.Assert.assertNotNull(rectangleEdge22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(timeZone24);
//        org.junit.Assert.assertNotNull(color26);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 128 + "'", int27 == 128);
//        org.junit.Assert.assertNotNull(floatArray29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 13 + "'", int31 == 13);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 43629L + "'", long32 == 43629L);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertNotNull(axisLocation45);
//        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 52.0d + "'", double51 == 52.0d);
//        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 32.0d + "'", double53 == 32.0d);
//        org.junit.Assert.assertNotNull(textAnchor54);
//        org.junit.Assert.assertNotNull(paint55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        float float6 = categoryPlot0.getBackgroundAlpha();
        java.lang.String str7 = categoryPlot0.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        double double14 = rectangleInsets12.calculateLeftInset((double) (-1));
        double double15 = rectangleInsets12.getBottom();
        org.jfree.data.general.Dataset dataset16 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) double15, dataset16);
        categoryPlot0.datasetChanged(datasetChangeEvent17);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = numberAxis19.valueToJava2D((double) 10, rectangle2D21, rectangleEdge22);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.axis.AxisState axisState25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        java.util.List list28 = numberAxis19.refreshTicks(graphics2D24, axisState25, rectangle2D26, rectangleEdge27);
        numberAxis19.setLabel("RectangleAnchor.TOP_LEFT");
        numberAxis19.zoomRange((double) (-1L), (double) 1);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis19);
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        categoryPlot35.setDomainAxis((int) 'a', categoryAxis37);
        categoryPlot35.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color42 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke43 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color42, stroke43);
        java.awt.Stroke stroke45 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker44.setOutlineStroke(stroke45);
        java.awt.Stroke stroke47 = valueMarker44.getOutlineStroke();
        boolean boolean48 = categoryPlot35.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker44);
        org.jfree.chart.plot.PlotOrientation plotOrientation49 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot35.setOrientation(plotOrientation49);
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = null;
        categoryPlot51.setDomainAxis((int) 'a', categoryAxis53);
        categoryPlot51.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.data.general.DatasetGroup datasetGroup57 = categoryPlot51.getDatasetGroup();
        java.awt.Paint paint58 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        categoryPlot51.setNoDataMessagePaint(paint58);
        categoryPlot35.setRangeGridlinePaint(paint58);
        int int61 = categoryPlot35.getWeight();
        java.awt.Paint paint62 = categoryPlot35.getDomainGridlinePaint();
        categoryPlot0.setDomainGridlinePaint(paint62);
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = categoryPlot0.getDomainAxis();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Category Plot" + "'", str7.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 32.0d + "'", double14 == 32.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(list28);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(plotOrientation49);
        org.junit.Assert.assertNull(datasetGroup57);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNull(categoryAxis64);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double7 = rectangleInsets5.calculateRightInset(11.0d);
        categoryPlot0.setInsets(rectangleInsets5);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot9.setDomainAxis((int) 'a', categoryAxis11);
        categoryPlot9.setBackgroundImageAlignment((int) (short) 10);
        float float15 = categoryPlot9.getBackgroundAlpha();
        categoryPlot9.clearRangeAxes();
        boolean boolean17 = rectangleInsets5.equals((java.lang.Object) categoryPlot9);
        categoryPlot9.setRangeCrosshairValue(0.0d);
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation23 = null;
        xYPlot21.setRangeAxisLocation((int) (short) 100, axisLocation23);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        double double30 = numberAxis26.valueToJava2D((double) 10, rectangle2D28, rectangleEdge29);
        org.jfree.data.Range range31 = numberAxis26.getDefaultAutoRange();
        numberAxis26.zoomRange((double) 0L, (double) 3);
        boolean boolean35 = numberAxis26.isNegativeArrowVisible();
        xYPlot21.setDomainAxis(255, (org.jfree.chart.axis.ValueAxis) numberAxis26, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder38 = xYPlot21.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation40 = xYPlot21.getRangeAxisLocation(0);
        categoryPlot9.setRangeAxisLocation(100, axisLocation40);
        java.awt.Stroke stroke42 = categoryPlot9.getOutlineStroke();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder38);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertNotNull(stroke42);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker9.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = valueMarker9.getOutlineStroke();
        boolean boolean13 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.data.general.DatasetGroup datasetGroup14 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot15.setDomainAxis((int) 'a', categoryAxis17);
        categoryPlot15.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.data.general.DatasetGroup datasetGroup21 = categoryPlot15.getDatasetGroup();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot15);
        categoryPlot15.setBackgroundAlpha((float) (-393216));
        org.jfree.data.general.DatasetGroup datasetGroup25 = categoryPlot15.getDatasetGroup();
        boolean boolean26 = categoryPlot15.isDomainGridlinesVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection27 = categoryPlot15.getFixedLegendItems();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(datasetGroup14);
        org.junit.Assert.assertNull(datasetGroup21);
        org.junit.Assert.assertNull(datasetGroup25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(legendItemCollection27);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color2, stroke3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker4.setOutlineStroke(stroke5);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker4.setLabelOffsetType(lengthAdjustmentType7);
        boolean boolean9 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker4);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = xYPlot0.getFixedLegendItems();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot11.setDomainAxis((int) 'a', categoryAxis13);
        categoryPlot11.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        categoryPlot11.setDataset(0, categoryDataset17);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot11.setNoDataMessagePaint(paint19);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot11.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        categoryPlot11.rendererChanged(rendererChangeEvent23);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection27 = categoryPlot11.getRangeMarkers((int) (byte) -1, layer26);
        java.util.Collection collection28 = xYPlot0.getRangeMarkers(layer26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        xYPlot0.setRangeAxisLocation(axisLocation29);
        java.awt.Image image31 = null;
        xYPlot0.setBackgroundImage(image31);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertNotNull(axisLocation29);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        java.awt.Color color0 = java.awt.Color.gray;
        int int1 = color0.getBlue();
        java.awt.color.ColorSpace colorSpace2 = null;
        float[] floatArray7 = new float[] { 255, 3, 100.0f, 13 };
        try {
            float[] floatArray8 = color0.getComponents(colorSpace2, floatArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
        org.junit.Assert.assertNotNull(floatArray7);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeMinimumSize((double) 11, false);
        try {
            numberAxis0.setRange((double) 100.0f, (double) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (2.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        float float6 = categoryPlot0.getBackgroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot0.getRangeAxisLocation();
        java.awt.Stroke stroke8 = categoryPlot0.getRangeCrosshairStroke();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getDomainAxisEdge();
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        boolean boolean7 = categoryPlot0.isRangeZoomable();
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        categoryPlot0.setDataset(categoryDataset11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        categoryPlot13.setDomainAxis((int) 'a', categoryAxis15);
        categoryPlot13.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        categoryPlot13.setDataset(0, categoryDataset19);
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot13.setNoDataMessagePaint(paint21);
        java.awt.Paint paint23 = categoryPlot13.getOutlinePaint();
        org.jfree.chart.util.SortOrder sortOrder24 = categoryPlot13.getColumnRenderingOrder();
        java.lang.String str25 = sortOrder24.toString();
        categoryPlot0.setRowRenderingOrder(sortOrder24);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        categoryPlot0.setRenderer(2019, categoryItemRenderer28, false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(sortOrder24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "SortOrder.ASCENDING" + "'", str25.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        boolean boolean7 = xYPlot0.isDomainCrosshairVisible();
        boolean boolean8 = xYPlot0.isSubplot();
        int int9 = xYPlot0.getDatasetCount();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        xYPlot0.setDomainAxis(valueAxis10);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = xYPlot0.getFixedLegendItems();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(legendItemCollection12);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
        org.jfree.data.general.Dataset dataset3 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) rectangleEdge2, dataset3);
        org.jfree.data.general.Dataset dataset5 = datasetChangeEvent4.getDataset();
        java.lang.String str6 = datasetChangeEvent4.toString();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNull(dataset5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.DatasetChangeEvent[source=RectangleEdge.BOTTOM]" + "'", str6.equals("org.jfree.data.general.DatasetChangeEvent[source=RectangleEdge.BOTTOM]"));
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test307");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        long long3 = day2.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
//        categoryPlot5.setDomainAxis((int) 'a', categoryAxis7);
//        categoryPlot5.setBackgroundImageAlignment((int) (short) 10);
//        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot5.getDatasetGroup();
//        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
//        categoryPlot5.setNoDataMessagePaint(paint12);
//        boolean boolean14 = day2.equals((java.lang.Object) categoryPlot5);
//        java.awt.Stroke stroke15 = categoryPlot5.getOutlineStroke();
//        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
//        categoryPlot16.setDomainAxis((int) 'a', categoryAxis18);
//        categoryPlot16.setBackgroundImageAlignment((int) (short) 10);
//        org.jfree.data.general.DatasetGroup datasetGroup22 = categoryPlot16.getDatasetGroup();
//        org.jfree.chart.axis.AxisLocation axisLocation23 = categoryPlot16.getRangeAxisLocation();
//        categoryPlot5.setDomainAxisLocation(axisLocation23);
//        org.jfree.data.category.CategoryDataset categoryDataset26 = categoryPlot5.getDataset((-393216));
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNull(datasetGroup11);
//        org.junit.Assert.assertNotNull(paint12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(stroke15);
//        org.junit.Assert.assertNull(datasetGroup22);
//        org.junit.Assert.assertNotNull(axisLocation23);
//        org.junit.Assert.assertNull(categoryDataset26);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        xYPlot0.setRangeAxisLocation(4, axisLocation8);
        java.lang.String str10 = xYPlot0.getPlotType();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "XY Plot" + "'", str10.equals("XY Plot"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Color color1 = color0.brighter();
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis((int) 'a', categoryAxis7);
        categoryPlot5.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color12, stroke13);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker14.setOutlineStroke(stroke15);
        java.awt.Stroke stroke17 = valueMarker14.getOutlineStroke();
        boolean boolean18 = categoryPlot5.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker14);
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean21 = layer19.equals((java.lang.Object) dateRange20);
        java.lang.String str22 = layer19.toString();
        xYPlot0.addDomainMarker((int) '#', (org.jfree.chart.plot.Marker) valueMarker14, layer19);
        org.jfree.chart.plot.IntervalMarker intervalMarker26 = new org.jfree.chart.plot.IntervalMarker(10.0d, (double) ' ');
        intervalMarker26.setEndValue((double) 6);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker26, layer29);
        intervalMarker26.setEndValue(32.0d);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(layer19);
        org.junit.Assert.assertNotNull(dateRange20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Layer.FOREGROUND" + "'", str22.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent10);
        boolean boolean12 = categoryPlot0.isRangeGridlinesVisible();
        double double13 = categoryPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        java.lang.Object obj3 = objectList1.get((int) '4');
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color5, stroke6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker7.setOutlineStroke(stroke8);
        java.awt.Stroke stroke10 = valueMarker7.getOutlineStroke();
        boolean boolean11 = objectList1.equals((java.lang.Object) stroke10);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        int int13 = xYPlot12.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        xYPlot12.zoomRangeAxes((double) 255, plotRenderingInfo15, point2D16, true);
        org.jfree.chart.axis.AxisLocation axisLocation20 = null;
        xYPlot12.setRangeAxisLocation(4, axisLocation20);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = numberAxis23.valueToJava2D((double) 10, rectangle2D25, rectangleEdge26);
        boolean boolean28 = numberAxis23.getAutoRangeStickyZero();
        xYPlot12.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis23);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = xYPlot12.getAxisOffset();
        boolean boolean31 = objectList1.equals((java.lang.Object) xYPlot12);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        categoryPlot33.setDomainAxis((int) 'a', categoryAxis35);
        categoryPlot33.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color40 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke41 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker42 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color40, stroke41);
        java.awt.Stroke stroke43 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker42.setOutlineStroke(stroke43);
        java.awt.Stroke stroke45 = valueMarker42.getOutlineStroke();
        boolean boolean46 = categoryPlot33.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker42);
        valueMarker42.setLabel("RectangleAnchor.TOP_LEFT");
        org.jfree.chart.util.Layer layer49 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange50 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean51 = layer49.equals((java.lang.Object) dateRange50);
        java.lang.String str52 = layer49.toString();
        xYPlot12.addDomainMarker((int) '#', (org.jfree.chart.plot.Marker) valueMarker42, layer49, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = null;
        categoryPlot55.setDomainAxis((int) 'a', categoryAxis57);
        categoryPlot55.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.data.general.DatasetGroup datasetGroup61 = categoryPlot55.getDatasetGroup();
        java.awt.Paint paint62 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        categoryPlot55.setNoDataMessagePaint(paint62);
        java.util.List list64 = categoryPlot55.getAnnotations();
        boolean boolean65 = layer49.equals((java.lang.Object) list64);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(layer49);
        org.junit.Assert.assertNotNull(dateRange50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Layer.FOREGROUND" + "'", str52.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(datasetGroup61);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNotNull(list64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test313");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        long long3 = day2.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
//        categoryPlot5.setDomainAxis((int) 'a', categoryAxis7);
//        categoryPlot5.setBackgroundImageAlignment((int) (short) 10);
//        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot5.getDatasetGroup();
//        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
//        categoryPlot5.setNoDataMessagePaint(paint12);
//        boolean boolean14 = day2.equals((java.lang.Object) categoryPlot5);
//        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D17 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
//        double double19 = numberAxis15.valueToJava2D((double) 10, rectangle2D17, rectangleEdge18);
//        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D22 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
//        double double24 = numberAxis20.valueToJava2D((double) 10, rectangle2D22, rectangleEdge23);
//        org.jfree.data.Range range25 = numberAxis20.getDefaultAutoRange();
//        numberAxis15.setRange(range25);
//        int int27 = categoryPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis15);
//        org.jfree.chart.event.AxisChangeListener axisChangeListener28 = null;
//        numberAxis15.removeChangeListener(axisChangeListener28);
//        org.jfree.data.Range range30 = numberAxis15.getRange();
//        numberAxis15.setAxisLineVisible(false);
//        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
//        org.jfree.chart.JFreeChart jFreeChart34 = null;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent35 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis33, jFreeChart34);
//        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
//        java.awt.Color color38 = org.jfree.chart.ChartColor.DARK_GREEN;
//        java.awt.Stroke stroke39 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color38, stroke39);
//        java.awt.Stroke stroke41 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
//        valueMarker40.setOutlineStroke(stroke41);
//        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType43 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
//        valueMarker40.setLabelOffsetType(lengthAdjustmentType43);
//        boolean boolean45 = xYPlot36.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker40);
//        org.jfree.chart.LegendItemCollection legendItemCollection46 = xYPlot36.getFixedLegendItems();
//        boolean boolean47 = dateAxis33.hasListener((java.util.EventListener) xYPlot36);
//        dateAxis33.setUpperBound(1.0d);
//        org.jfree.data.Range range50 = dateAxis33.getDefaultAutoRange();
//        numberAxis15.setRangeWithMargins(range50);
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNull(datasetGroup11);
//        org.junit.Assert.assertNotNull(paint12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
//        org.junit.Assert.assertNotNull(range25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//        org.junit.Assert.assertNotNull(range30);
//        org.junit.Assert.assertNotNull(color38);
//        org.junit.Assert.assertNotNull(stroke39);
//        org.junit.Assert.assertNotNull(stroke41);
//        org.junit.Assert.assertNotNull(lengthAdjustmentType43);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertNull(legendItemCollection46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertNotNull(range50);
//    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        xYPlot0.zoomDomainAxes(0.0d, 1.0d, plotRenderingInfo5, point2D6);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot9.setDomainAxis((int) 'a', categoryAxis11);
        categoryPlot9.clearAnnotations();
        boolean boolean14 = categoryPlot9.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace15 = categoryPlot9.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot9.setInsets(rectangleInsets16);
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation18, plotOrientation19);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor21 = org.jfree.chart.axis.CategoryAnchor.END;
        boolean boolean22 = axisLocation18.equals((java.lang.Object) categoryAnchor21);
        categoryPlot9.setRangeAxisLocation(axisLocation18, false);
        xYPlot0.setRangeAxisLocation(12, axisLocation18, false);
        org.jfree.chart.LegendItemCollection legendItemCollection27 = xYPlot0.getLegendItems();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(axisSpace15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(plotOrientation19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(categoryAnchor21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(legendItemCollection27);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis0.setRange(range10);
        numberAxis0.setRangeAboutValue((double) (short) -1, 0.0d);
        numberAxis0.setTickLabelsVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = numberAxis17.valueToJava2D((double) 10, rectangle2D19, rectangleEdge20);
        org.jfree.data.Range range22 = numberAxis17.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = numberAxis23.valueToJava2D((double) 10, rectangle2D25, rectangleEdge26);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
        double double32 = numberAxis28.valueToJava2D((double) 10, rectangle2D30, rectangleEdge31);
        org.jfree.data.Range range33 = numberAxis28.getDefaultAutoRange();
        numberAxis23.setRange(range33);
        numberAxis17.setDefaultAutoRange(range33);
        java.awt.Shape shape36 = numberAxis17.getDownArrow();
        numberAxis0.setRightArrow(shape36);
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis();
        numberAxis38.setAutoRangeMinimumSize((double) 11, false);
        numberAxis38.setAutoRangeStickyZero(true);
        double double44 = numberAxis38.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis();
        numberAxis45.setAutoRangeMinimumSize((double) 11, false);
        java.awt.Color color50 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke51 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker52 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color50, stroke51);
        numberAxis45.setLabelPaint((java.awt.Paint) color50);
        numberAxis45.setPositiveArrowVisible(true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit56 = numberAxis45.getTickUnit();
        numberAxis38.setTickUnit(numberTickUnit56, true, false);
        numberAxis0.setTickUnit(numberTickUnit56, true, true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(numberTickUnit56);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis5.zoomRange((double) 0L, (double) 3);
        boolean boolean14 = numberAxis5.isNegativeArrowVisible();
        xYPlot0.setDomainAxis(255, (org.jfree.chart.axis.ValueAxis) numberAxis5, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder17 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.data.xy.XYDataset xYDataset18 = xYPlot0.getDataset();
        java.awt.Paint paint19 = xYPlot0.getDomainTickBandPaint();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis21 = xYPlot0.getDomainAxisForDataset(13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 13 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder17);
        org.junit.Assert.assertNull(xYDataset18);
        org.junit.Assert.assertNull(paint19);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = numberAxis1.valueToJava2D((double) 10, rectangle2D3, rectangleEdge4);
        java.awt.Paint paint6 = numberAxis1.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis7, xYItemRenderer8);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        double double16 = rectangleInsets14.calculateLeftInset((double) (-1));
        double double17 = rectangleInsets14.getBottom();
        double double19 = rectangleInsets14.extendHeight(3.0d);
        xYPlot9.setInsets(rectangleInsets14, false);
        java.awt.Stroke stroke22 = xYPlot9.getRangeGridlineStroke();
        java.awt.Paint paint23 = xYPlot9.getDomainCrosshairPaint();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 32.0d + "'", double16 == 32.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 55.0d + "'", double19 == 55.0d);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeMinimumSize((double) 11, false);
        numberAxis0.setAutoRangeStickyZero(true);
        double double6 = numberAxis0.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = numberAxis7.valueToJava2D((double) 10, rectangle2D9, rectangleEdge10);
        org.jfree.data.Range range12 = numberAxis7.getDefaultAutoRange();
        numberAxis0.setRange(range12, true, true);
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis0.setTickMarkPaint((java.awt.Paint) color16);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        double double24 = rectangleInsets22.calculateLeftInset((double) (-1));
        numberAxis0.setLabelInsets(rectangleInsets22);
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        try {
            rectangleInsets22.trim(rectangle2D26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 32.0d + "'", double24 == 32.0d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot0.setInsets(rectangleInsets7);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot0.getDomainAxisEdge((int) (short) -1);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = categoryPlot0.getDatasetRenderingOrder();
        java.util.List list12 = categoryPlot0.getCategories();
        org.jfree.chart.axis.AxisSpace axisSpace13 = categoryPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNull(list12);
        org.junit.Assert.assertNull(axisSpace13);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double7 = rectangleInsets5.calculateRightInset(11.0d);
        categoryPlot0.setInsets(rectangleInsets5);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj11 = null;
        boolean boolean12 = categoryAxis10.equals(obj11);
        categoryAxis10.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis10.clearCategoryLabelToolTips();
        categoryAxis10.setTickLabelsVisible(false);
        categoryAxis10.setUpperMargin((double) 2);
        java.awt.Color color22 = java.awt.Color.gray;
        categoryAxis10.setTickLabelPaint((java.lang.Comparable) (-1.0f), (java.awt.Paint) color22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        boolean boolean25 = categoryAxis10.equals((java.lang.Object) color24);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color24);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        categoryPlot27.setDomainAxis((int) 'a', categoryAxis29);
        categoryPlot27.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        categoryPlot27.setDataset(0, categoryDataset33);
        java.awt.Paint paint35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot27.setNoDataMessagePaint(paint35);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent37 = null;
        categoryPlot27.rendererChanged(rendererChangeEvent37);
        org.jfree.chart.text.TextAnchor textAnchor39 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        boolean boolean40 = categoryPlot27.equals((java.lang.Object) textAnchor39);
        org.jfree.chart.axis.AxisLocation axisLocation42 = categoryPlot27.getDomainAxisLocation(255);
        categoryPlot0.setDomainAxisLocation(axisLocation42);
        org.jfree.chart.axis.AxisLocation axisLocation44 = axisLocation42.getOpposite();
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation47 = null;
        xYPlot45.setRangeAxisLocation((int) (short) 100, axisLocation47);
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = null;
        categoryPlot50.setDomainAxis((int) 'a', categoryAxis52);
        categoryPlot50.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color57 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke58 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker59 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color57, stroke58);
        java.awt.Stroke stroke60 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker59.setOutlineStroke(stroke60);
        java.awt.Stroke stroke62 = valueMarker59.getOutlineStroke();
        boolean boolean63 = categoryPlot50.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker59);
        org.jfree.chart.util.Layer layer64 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange65 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean66 = layer64.equals((java.lang.Object) dateRange65);
        java.lang.String str67 = layer64.toString();
        xYPlot45.addDomainMarker((int) '#', (org.jfree.chart.plot.Marker) valueMarker59, layer64);
        org.jfree.chart.plot.IntervalMarker intervalMarker71 = new org.jfree.chart.plot.IntervalMarker(10.0d, (double) ' ');
        intervalMarker71.setEndValue((double) 6);
        org.jfree.chart.util.Layer layer74 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean75 = xYPlot45.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker71, layer74);
        double double76 = intervalMarker71.getEndValue();
        boolean boolean77 = axisLocation42.equals((java.lang.Object) intervalMarker71);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(textAnchor39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(layer64);
        org.junit.Assert.assertNotNull(dateRange65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "Layer.FOREGROUND" + "'", str67.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(layer74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 6.0d + "'", double76 == 6.0d);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        categoryPlot0.setDataset(categoryDataset2);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = numberAxis4.valueToJava2D((double) 10, rectangle2D6, rectangleEdge7);
        org.jfree.data.Range range9 = numberAxis4.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = numberAxis10.valueToJava2D((double) 10, rectangle2D12, rectangleEdge13);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = numberAxis15.valueToJava2D((double) 10, rectangle2D17, rectangleEdge18);
        org.jfree.data.Range range20 = numberAxis15.getDefaultAutoRange();
        numberAxis10.setRange(range20);
        numberAxis4.setDefaultAutoRange(range20);
        org.jfree.chart.axis.TickUnitSource tickUnitSource23 = null;
        numberAxis4.setStandardTickUnits(tickUnitSource23);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit25 = numberAxis4.getTickUnit();
        numberAxis4.setAxisLineVisible(true);
        org.jfree.data.Range range28 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis4);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj31 = null;
        boolean boolean32 = categoryAxis30.equals(obj31);
        categoryAxis30.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis30.setMaximumCategoryLabelLines(1);
        categoryPlot0.setDomainAxis(categoryAxis30);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(numberTickUnit25);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker9.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = valueMarker9.getOutlineStroke();
        boolean boolean13 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        java.awt.Paint paint14 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot0.setAxisOffset(rectangleInsets15);
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot0.removeChangeListener(plotChangeListener17);
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color22, stroke23);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker24.setOutlineStroke(stroke25);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType27 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker24.setLabelOffsetType(lengthAdjustmentType27);
        boolean boolean29 = xYPlot20.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker24);
        valueMarker24.setLabel("PlotOrientation.HORIZONTAL");
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = null;
        double double36 = numberAxis32.valueToJava2D((double) 10, rectangle2D34, rectangleEdge35);
        boolean boolean37 = numberAxis32.getAutoRangeStickyZero();
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        categoryPlot38.setDataset(categoryDataset39);
        org.jfree.chart.event.PlotChangeListener plotChangeListener41 = null;
        categoryPlot38.removeChangeListener(plotChangeListener41);
        numberAxis32.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot38);
        java.awt.Font font44 = categoryPlot38.getNoDataMessageFont();
        java.awt.Paint paint45 = categoryPlot38.getNoDataMessagePaint();
        java.awt.Color color48 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke49 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker50 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color48, stroke49);
        java.awt.Stroke stroke51 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker50.setOutlineStroke(stroke51);
        java.awt.Paint paint53 = valueMarker50.getOutlinePaint();
        java.lang.String str54 = valueMarker50.getLabel();
        valueMarker50.setAlpha(0.0f);
        java.awt.Stroke stroke57 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        valueMarker50.setStroke(stroke57);
        valueMarker50.setLabel("PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer61 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean62 = categoryPlot38.removeRangeMarker((-1), (org.jfree.chart.plot.Marker) valueMarker50, layer61);
        categoryPlot0.addRangeMarker((-1), (org.jfree.chart.plot.Marker) valueMarker24, layer61);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(lengthAdjustmentType27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(layer61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        xYPlot0.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis5.getTickMarkPaint();
        xYPlot0.setDomainTickBandPaint(paint10);
        boolean boolean12 = xYPlot0.isRangeCrosshairLockedOnData();
        java.lang.String str13 = xYPlot0.getPlotType();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "XY Plot" + "'", str13.equals("XY Plot"));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker9.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = valueMarker9.getOutlineStroke();
        boolean boolean13 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot0.setOrientation(plotOrientation14);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        categoryPlot16.setDomainAxis((int) 'a', categoryAxis18);
        categoryPlot16.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.data.general.DatasetGroup datasetGroup22 = categoryPlot16.getDatasetGroup();
        java.awt.Paint paint23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        categoryPlot16.setNoDataMessagePaint(paint23);
        categoryPlot0.setRangeGridlinePaint(paint23);
        boolean boolean26 = categoryPlot0.isOutlineVisible();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNull(datasetGroup22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker9.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = valueMarker9.getOutlineStroke();
        boolean boolean13 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot0.setOrientation(plotOrientation14);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        categoryPlot16.setDomainAxis((int) 'a', categoryAxis18);
        categoryPlot16.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.data.general.DatasetGroup datasetGroup22 = categoryPlot16.getDatasetGroup();
        java.awt.Paint paint23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        categoryPlot16.setNoDataMessagePaint(paint23);
        categoryPlot0.setRangeGridlinePaint(paint23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        java.awt.geom.Point2D point2D28 = null;
        categoryPlot0.zoomRangeAxes((double) 10.0f, plotRenderingInfo27, point2D28, true);
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.axis.ValueAxis valueAxis33 = categoryPlot0.getRangeAxisForDataset((int) ' ');
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNull(datasetGroup22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(valueAxis33);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        float float6 = categoryPlot0.getBackgroundAlpha();
        categoryPlot0.setRangeCrosshairValue((double) 8, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot11.setDomainAxis((int) 'a', categoryAxis13);
        categoryPlot11.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        categoryPlot11.setDataset(0, categoryDataset17);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot11.setNoDataMessagePaint(paint19);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot11.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        categoryPlot11.rendererChanged(rendererChangeEvent23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray26 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer25 };
        categoryPlot11.setRenderers(categoryItemRendererArray26);
        categoryPlot0.setRenderers(categoryItemRendererArray26);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setRangeCrosshairStroke(stroke29);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(categoryItemRendererArray26);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker9.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = valueMarker9.getOutlineStroke();
        boolean boolean13 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot0.setOrientation(plotOrientation14);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        categoryPlot16.setDomainAxis((int) 'a', categoryAxis18);
        categoryPlot16.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.data.general.DatasetGroup datasetGroup22 = categoryPlot16.getDatasetGroup();
        java.awt.Paint paint23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        categoryPlot16.setNoDataMessagePaint(paint23);
        categoryPlot0.setRangeGridlinePaint(paint23);
        int int26 = categoryPlot0.getWeight();
        java.awt.Paint paint27 = categoryPlot0.getDomainGridlinePaint();
        categoryPlot0.clearDomainAxes();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNull(datasetGroup22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder2 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj6 = null;
        boolean boolean7 = categoryAxis5.equals(obj6);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = categoryAxis5.getCategoryMiddle((-1), 8, rectangle2D10, rectangleEdge11);
        java.awt.Stroke stroke13 = categoryAxis5.getAxisLineStroke();
        xYPlot0.setDomainGridlineStroke(stroke13);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(seriesRenderingOrder2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(stroke13);
    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test329");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        java.util.Date date3 = day2.getEnd();
//        long long4 = day2.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day2.next();
//        java.util.Date date6 = regularTimePeriod5.getEnd();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43629L + "'", long4 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//        org.junit.Assert.assertNotNull(date6);
//    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis0.setRangeWithMargins(range10, true, true);
        java.text.NumberFormat numberFormat14 = numberAxis0.getNumberFormatOverride();
        java.lang.String str15 = numberAxis0.getLabelURL();
        numberAxis0.setVisible(true);
        boolean boolean18 = numberAxis0.isVerticalTickLabels();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNull(numberFormat14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setRange((double) (byte) 10, 100.0d);
        org.jfree.chart.axis.Timeline timeline4 = null;
        dateAxis0.setTimeline(timeline4);
        java.lang.String str6 = dateAxis0.getLabelToolTip();
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        float float6 = categoryPlot0.getBackgroundAlpha();
        categoryPlot0.setRangeCrosshairValue((double) 8, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent11 = null;
        categoryPlot0.markerChanged(markerChangeEvent11);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        xYPlot0.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis5.getTickMarkPaint();
        xYPlot0.setDomainTickBandPaint(paint10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color15, stroke16);
        boolean boolean18 = axisLocation13.equals((java.lang.Object) valueMarker17);
        float float19 = valueMarker17.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = valueMarker17.getLabelAnchor();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean23 = layer21.equals((java.lang.Object) dateRange22);
        java.lang.String str24 = layer21.toString();
        xYPlot0.addDomainMarker((int) (short) 100, (org.jfree.chart.plot.Marker) valueMarker17, layer21);
        xYPlot0.configureDomainAxes();
        java.awt.Font font27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        xYPlot0.setNoDataMessageFont(font27);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent29 = null;
        xYPlot0.markerChanged(markerChangeEvent29);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Layer.FOREGROUND" + "'", str24.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(font27);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setRange((double) (byte) 10, 100.0d);
        java.text.DateFormat dateFormat4 = dateAxis0.getDateFormatOverride();
        boolean boolean5 = dateAxis0.isAutoRange();
        java.text.DateFormat dateFormat6 = dateAxis0.getDateFormatOverride();
        org.junit.Assert.assertNull(dateFormat4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(dateFormat6);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        categoryPlot0.clearRangeAxes();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            categoryPlot0.drawBackground(graphics2D11, rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        xYPlot0.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis6.valueToJava2D((double) 10, rectangle2D8, rectangleEdge9);
        org.jfree.data.Range range11 = numberAxis6.getDefaultAutoRange();
        java.awt.Font font12 = numberAxis6.getTickLabelFont();
        numberAxis6.setAutoRange(false);
        xYPlot0.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis6, false);
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        xYPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color17);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder19 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Stroke stroke20 = xYPlot0.getDomainGridlineStroke();
        java.awt.Stroke stroke21 = xYPlot0.getDomainCrosshairStroke();
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        categoryPlot24.setDomainAxis((int) 'a', categoryAxis26);
        categoryPlot24.clearAnnotations();
        boolean boolean29 = categoryPlot24.isOutlineVisible();
        categoryPlot24.setRangeCrosshairValue((double) 1L);
        java.util.List list32 = categoryPlot24.getAnnotations();
        xYPlot0.drawRangeTickBands(graphics2D22, rectangle2D23, list32);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(seriesRenderingOrder19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(list32);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.05d, (double) (-1));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        java.util.List list9 = numberAxis0.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge8);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        double double16 = rectangleInsets14.calculateLeftInset((double) (-1));
        numberAxis0.setTickLabelInsets(rectangleInsets14);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = numberAxis0.getLabelInsets();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand19 = numberAxis0.getMarkerBand();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 32.0d + "'", double16 == 32.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNull(markerAxisBand19);
    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test339");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        long long3 = day2.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
//        categoryPlot5.setDomainAxis((int) 'a', categoryAxis7);
//        categoryPlot5.setBackgroundImageAlignment((int) (short) 10);
//        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot5.getDatasetGroup();
//        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
//        categoryPlot5.setNoDataMessagePaint(paint12);
//        boolean boolean14 = day2.equals((java.lang.Object) categoryPlot5);
//        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
//        java.awt.Font font19 = null;
//        categoryAxis17.setTickLabelFont((java.lang.Comparable) (byte) -1, font19);
//        categoryPlot5.setDomainAxis(10, categoryAxis17);
//        java.lang.String str22 = categoryPlot5.getPlotType();
//        categoryPlot5.setBackgroundAlpha((float) 7);
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNull(datasetGroup11);
//        org.junit.Assert.assertNotNull(paint12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Category Plot" + "'", str22.equals("Category Plot"));
//    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test340");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        long long3 = day2.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
//        categoryPlot5.setDomainAxis((int) 'a', categoryAxis7);
//        categoryPlot5.setBackgroundImageAlignment((int) (short) 10);
//        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot5.getDatasetGroup();
//        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
//        categoryPlot5.setNoDataMessagePaint(paint12);
//        boolean boolean14 = day2.equals((java.lang.Object) categoryPlot5);
//        java.awt.Stroke stroke15 = categoryPlot5.getOutlineStroke();
//        float float16 = categoryPlot5.getForegroundAlpha();
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
//        java.awt.geom.Point2D point2D19 = null;
//        categoryPlot5.zoomDomainAxes((double) 10L, plotRenderingInfo18, point2D19, true);
//        org.jfree.chart.axis.AxisLocation axisLocation23 = categoryPlot5.getRangeAxisLocation(1);
//        org.jfree.chart.plot.Marker marker24 = null;
//        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
//        try {
//            categoryPlot5.addRangeMarker(marker24, layer25);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNull(datasetGroup11);
//        org.junit.Assert.assertNotNull(paint12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(stroke15);
//        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 1.0f + "'", float16 == 1.0f);
//        org.junit.Assert.assertNotNull(axisLocation23);
//        org.junit.Assert.assertNotNull(layer25);
//    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        java.awt.Color color0 = java.awt.Color.lightGray;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundAlpha((float) 4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        int int4 = categoryPlot0.getIndexOf(categoryItemRenderer3);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color6, stroke7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker8.setOutlineStroke(stroke9);
        java.awt.Stroke stroke11 = valueMarker8.getOutlineStroke();
        categoryPlot0.setOutlineStroke(stroke11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = categoryPlot0.getRenderer();
        java.util.List list14 = categoryPlot0.getAnnotations();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(categoryItemRenderer13);
        org.junit.Assert.assertNotNull(list14);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis0.setRange(range10);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis0.getTickUnit();
        double double13 = numberAxis0.getLabelAngle();
        double double14 = numberAxis0.getLowerBound();
        double double15 = numberAxis0.getUpperBound();
        double double16 = numberAxis0.getUpperBound();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        float float8 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot0.getAxisOffset();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj12 = null;
        boolean boolean13 = categoryAxis11.equals(obj12);
        categoryAxis11.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis11.clearCategoryLabelToolTips();
        categoryPlot0.setDomainAxis(categoryAxis11);
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot0.getRangeAxisForDataset((-1));
        try {
            categoryPlot0.zoom((double) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(valueAxis20);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        float float8 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot0.getAxisOffset();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj12 = null;
        boolean boolean13 = categoryAxis11.equals(obj12);
        categoryAxis11.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis11.clearCategoryLabelToolTips();
        categoryPlot0.setDomainAxis(categoryAxis11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot0.getRenderer(2019);
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation23 = null;
        xYPlot21.setRangeAxisLocation((int) (short) 100, axisLocation23);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        double double30 = numberAxis26.valueToJava2D((double) 10, rectangle2D28, rectangleEdge29);
        org.jfree.data.Range range31 = numberAxis26.getDefaultAutoRange();
        numberAxis26.zoomRange((double) 0L, (double) 3);
        boolean boolean35 = numberAxis26.isNegativeArrowVisible();
        xYPlot21.setDomainAxis(255, (org.jfree.chart.axis.ValueAxis) numberAxis26, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        categoryPlot38.setDomainAxis((int) 'a', categoryAxis40);
        categoryPlot38.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset44 = null;
        categoryPlot38.setDataset(0, categoryDataset44);
        java.awt.Paint paint46 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot38.setNoDataMessagePaint(paint46);
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = categoryPlot38.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent50 = null;
        categoryPlot38.rendererChanged(rendererChangeEvent50);
        org.jfree.chart.util.Layer layer53 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection54 = categoryPlot38.getRangeMarkers((int) (byte) -1, layer53);
        org.jfree.chart.axis.CategoryAxis categoryAxis56 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj57 = null;
        boolean boolean58 = categoryAxis56.equals(obj57);
        categoryAxis56.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis56.clearCategoryLabelToolTips();
        categoryAxis56.setTickLabelsVisible(false);
        java.awt.Graphics2D graphics2D65 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot66 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis68 = null;
        categoryPlot66.setDomainAxis((int) 'a', categoryAxis68);
        categoryPlot66.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset72 = null;
        categoryPlot66.setDataset(0, categoryDataset72);
        java.awt.Paint paint74 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot66.setNoDataMessagePaint(paint74);
        org.jfree.chart.util.RectangleEdge rectangleEdge77 = categoryPlot66.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent78 = null;
        categoryPlot66.rendererChanged(rendererChangeEvent78);
        org.jfree.chart.util.Layer layer81 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection82 = categoryPlot66.getRangeMarkers((int) (byte) -1, layer81);
        java.awt.geom.Rectangle2D rectangle2D83 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge84 = null;
        org.jfree.chart.axis.AxisSpace axisSpace85 = null;
        org.jfree.chart.axis.AxisSpace axisSpace86 = categoryAxis56.reserveSpace(graphics2D65, (org.jfree.chart.plot.Plot) categoryPlot66, rectangle2D83, rectangleEdge84, axisSpace85);
        categoryPlot38.setFixedRangeAxisSpace(axisSpace86, false);
        xYPlot21.setFixedRangeAxisSpace(axisSpace86);
        categoryPlot0.setFixedRangeAxisSpace(axisSpace86);
        boolean boolean91 = categoryPlot0.isSubplot();
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(rectangleEdge49);
        org.junit.Assert.assertNotNull(layer53);
        org.junit.Assert.assertNull(collection54);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertNotNull(rectangleEdge77);
        org.junit.Assert.assertNotNull(layer81);
        org.junit.Assert.assertNull(collection82);
        org.junit.Assert.assertNotNull(axisSpace86);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.data.Range range5 = numberAxis0.getDefaultAutoRange();
        numberAxis0.zoomRange((double) 0L, (double) 3);
        java.lang.String str9 = numberAxis0.getLabel();
        boolean boolean10 = numberAxis0.getAutoRangeStickyZero();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis0.getLabelInsets();
        double double12 = rectangleInsets11.getLeft();
        double double14 = rectangleInsets11.calculateRightOutset((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.0d + "'", double12 == 3.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.0d + "'", double14 == 3.0d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        xYPlot1.setRangeAxisLocation((int) (short) 100, axisLocation3);
        xYPlot1.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis6.valueToJava2D((double) 10, rectangle2D8, rectangleEdge9);
        java.awt.Paint paint11 = numberAxis6.getTickMarkPaint();
        xYPlot1.setDomainTickBandPaint(paint11);
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color16, stroke17);
        boolean boolean19 = axisLocation14.equals((java.lang.Object) valueMarker18);
        float float20 = valueMarker18.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = valueMarker18.getLabelAnchor();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange23 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean24 = layer22.equals((java.lang.Object) dateRange23);
        java.lang.String str25 = layer22.toString();
        xYPlot1.addDomainMarker((int) (short) 100, (org.jfree.chart.plot.Marker) valueMarker18, layer22);
        int int27 = xYPlot1.getWeight();
        java.awt.Paint paint28 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        xYPlot1.setRangeTickBandPaint(paint28);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        categoryPlot30.setDomainAxis((int) 'a', categoryAxis32);
        categoryPlot30.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.data.general.DatasetGroup datasetGroup36 = categoryPlot30.getDatasetGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        categoryPlot37.setDomainAxis((int) 'a', categoryAxis39);
        categoryPlot37.clearAnnotations();
        boolean boolean42 = categoryPlot37.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace43 = categoryPlot37.getFixedDomainAxisSpace();
        boolean boolean44 = categoryPlot37.isRangeZoomable();
        categoryPlot37.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation47 = categoryPlot37.getDomainAxisLocation();
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color50 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke51 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker52 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color50, stroke51);
        java.awt.Stroke stroke53 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker52.setOutlineStroke(stroke53);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType55 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker52.setLabelOffsetType(lengthAdjustmentType55);
        boolean boolean57 = xYPlot48.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker52);
        valueMarker52.setLabel("PlotOrientation.HORIZONTAL");
        java.awt.Stroke stroke60 = valueMarker52.getOutlineStroke();
        categoryPlot37.setOutlineStroke(stroke60);
        categoryPlot30.setDomainGridlineStroke(stroke60);
        org.jfree.chart.plot.ValueMarker valueMarker63 = new org.jfree.chart.plot.ValueMarker(0.0d, paint28, stroke60);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNotNull(dateRange23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(datasetGroup36);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNull(axisSpace43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(axisLocation47);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(lengthAdjustmentType55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(stroke60);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        float float6 = categoryPlot0.getBackgroundAlpha();
        java.lang.String str7 = categoryPlot0.getPlotType();
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot0.getRangeAxis((int) (byte) -1);
        java.lang.String str10 = categoryPlot0.getPlotType();
        java.awt.Stroke stroke11 = categoryPlot0.getDomainGridlineStroke();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        xYPlot12.setRangeAxisLocation((int) (short) 100, axisLocation14);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = numberAxis17.valueToJava2D((double) 10, rectangle2D19, rectangleEdge20);
        org.jfree.data.Range range22 = numberAxis17.getDefaultAutoRange();
        numberAxis17.zoomRange((double) 0L, (double) 3);
        boolean boolean26 = numberAxis17.isNegativeArrowVisible();
        xYPlot12.setDomainAxis(255, (org.jfree.chart.axis.ValueAxis) numberAxis17, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = xYPlot12.getDatasetRenderingOrder();
        java.lang.String str30 = datasetRenderingOrder29.toString();
        java.lang.String str31 = datasetRenderingOrder29.toString();
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = null;
        xYPlot32.setRangeAxisLocation((int) (short) 100, axisLocation34);
        xYPlot32.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        double double42 = numberAxis38.valueToJava2D((double) 10, rectangle2D40, rectangleEdge41);
        org.jfree.data.Range range43 = numberAxis38.getDefaultAutoRange();
        java.awt.Font font44 = numberAxis38.getTickLabelFont();
        numberAxis38.setAutoRange(false);
        xYPlot32.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis38, false);
        boolean boolean49 = datasetRenderingOrder29.equals((java.lang.Object) xYPlot32);
        java.awt.Color color50 = java.awt.Color.PINK;
        boolean boolean51 = datasetRenderingOrder29.equals((java.lang.Object) color50);
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder29);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Category Plot" + "'", str7.equals("Category Plot"));
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Category Plot" + "'", str10.equals("Category Plot"));
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str30.equals("DatasetRenderingOrder.REVERSE"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str31.equals("DatasetRenderingOrder.REVERSE"));
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        boolean boolean7 = xYPlot0.isDomainCrosshairVisible();
        boolean boolean8 = xYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = numberAxis9.valueToJava2D((double) 10, rectangle2D11, rectangleEdge12);
        org.jfree.data.Range range14 = numberAxis9.getDefaultAutoRange();
        numberAxis9.zoomRange((double) 0L, (double) 3);
        int int18 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis9);
        java.awt.Paint paint19 = xYPlot0.getRangeCrosshairPaint();
        boolean boolean20 = xYPlot0.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = xYPlot0.getRangeAxisEdge((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(rectangleEdge22);
    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test350");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        long long3 = day2.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
//        categoryPlot5.setDomainAxis((int) 'a', categoryAxis7);
//        categoryPlot5.setBackgroundImageAlignment((int) (short) 10);
//        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot5.getDatasetGroup();
//        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
//        categoryPlot5.setNoDataMessagePaint(paint12);
//        boolean boolean14 = day2.equals((java.lang.Object) categoryPlot5);
//        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
//        java.awt.Font font19 = null;
//        categoryAxis17.setTickLabelFont((java.lang.Comparable) (byte) -1, font19);
//        java.lang.String str21 = categoryAxis17.getLabelToolTip();
//        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D24 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
//        double double26 = numberAxis22.valueToJava2D((double) 10, rectangle2D24, rectangleEdge25);
//        java.awt.Graphics2D graphics2D27 = null;
//        org.jfree.chart.axis.AxisState axisState28 = null;
//        java.awt.geom.Rectangle2D rectangle2D29 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
//        java.util.List list31 = numberAxis22.refreshTicks(graphics2D27, axisState28, rectangle2D29, rectangleEdge30);
//        numberAxis22.setLabel("RectangleAnchor.TOP_LEFT");
//        numberAxis22.zoomRange((double) (-1L), (double) 1);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis17, (org.jfree.chart.axis.ValueAxis) numberAxis22, categoryItemRenderer37);
//        int int39 = categoryPlot5.getDomainAxisIndex(categoryAxis17);
//        java.util.Date date40 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date40, timeZone41);
//        java.awt.Paint paint43 = categoryAxis17.getTickLabelPaint((java.lang.Comparable) date40);
//        double double44 = categoryAxis17.getCategoryMargin();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNull(datasetGroup11);
//        org.junit.Assert.assertNotNull(paint12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNull(str21);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
//        org.junit.Assert.assertNotNull(list31);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(timeZone41);
//        org.junit.Assert.assertNotNull(paint43);
//        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.2d + "'", double44 == 0.2d);
//    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        java.awt.Paint paint2 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color4, stroke5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = valueMarker6.getLabelAnchor();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color9, stroke10);
        java.awt.Stroke stroke12 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker11.setOutlineStroke(stroke12);
        java.awt.Stroke stroke14 = valueMarker11.getOutlineStroke();
        valueMarker6.setStroke(stroke14);
        java.awt.Stroke stroke16 = valueMarker6.getOutlineStroke();
        java.awt.Color color17 = java.awt.Color.GREEN;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot18.setDomainAxis((int) 'a', categoryAxis20);
        categoryPlot18.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        categoryPlot18.setDataset(0, categoryDataset24);
        java.awt.Paint paint26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot18.setNoDataMessagePaint(paint26);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot18.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
        categoryPlot18.rendererChanged(rendererChangeEvent30);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        categoryPlot18.setRenderer(categoryItemRenderer32, true);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = null;
        double double40 = numberAxis36.valueToJava2D((double) 10, rectangle2D38, rectangleEdge39);
        org.jfree.data.Range range41 = numberAxis36.getDefaultAutoRange();
        numberAxis36.zoomRange((double) 0L, (double) 3);
        java.lang.String str45 = numberAxis36.getLabel();
        categoryPlot18.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis36, false);
        java.awt.Stroke stroke48 = numberAxis36.getTickMarkStroke();
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker50 = new org.jfree.chart.plot.IntervalMarker(1.0d, (double) 7, paint2, stroke16, (java.awt.Paint) color17, stroke48, (float) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertNotNull(stroke48);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryAxis1.equals(obj2);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setVisible(false);
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) (-1L));
        categoryAxis1.setMaximumCategoryLabelLines(9);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryAxis1.getTickLabelInsets();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(10.0d, (double) ' ');
        double double3 = intervalMarker2.getEndValue();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent4 = null;
        intervalMarker2.notifyListeners(markerChangeEvent4);
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        xYPlot6.setRangeAxisLocation((int) (short) 100, axisLocation8);
        xYPlot6.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = numberAxis11.valueToJava2D((double) 10, rectangle2D13, rectangleEdge14);
        java.awt.Paint paint16 = numberAxis11.getTickMarkPaint();
        xYPlot6.setDomainTickBandPaint(paint16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color21 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color21, stroke22);
        boolean boolean24 = axisLocation19.equals((java.lang.Object) valueMarker23);
        float float25 = valueMarker23.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = valueMarker23.getLabelAnchor();
        org.jfree.chart.util.Layer layer27 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange28 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean29 = layer27.equals((java.lang.Object) dateRange28);
        java.lang.String str30 = layer27.toString();
        xYPlot6.addDomainMarker((int) (short) 100, (org.jfree.chart.plot.Marker) valueMarker23, layer27);
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis();
        numberAxis32.setAutoRangeMinimumSize((double) 11, false);
        numberAxis32.setAutoRangeStickyZero(true);
        double double38 = numberAxis32.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = null;
        double double43 = numberAxis39.valueToJava2D((double) 10, rectangle2D41, rectangleEdge42);
        org.jfree.data.Range range44 = numberAxis39.getDefaultAutoRange();
        numberAxis32.setRange(range44, true, true);
        java.awt.Color color48 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis32.setTickMarkPaint((java.awt.Paint) color48);
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = null;
        double double54 = numberAxis50.valueToJava2D((double) 10, rectangle2D52, rectangleEdge53);
        org.jfree.chart.axis.NumberAxis numberAxis55 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = null;
        double double59 = numberAxis55.valueToJava2D((double) 10, rectangle2D57, rectangleEdge58);
        org.jfree.data.Range range60 = numberAxis55.getDefaultAutoRange();
        numberAxis50.setRange(range60);
        boolean boolean62 = color48.equals((java.lang.Object) numberAxis50);
        xYPlot6.setRangeGridlinePaint((java.awt.Paint) color48);
        xYPlot6.clearDomainMarkers();
        java.awt.Graphics2D graphics2D65 = null;
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo67 = null;
        xYPlot6.drawAnnotations(graphics2D65, rectangle2D66, plotRenderingInfo67);
        org.jfree.chart.plot.XYPlot xYPlot69 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation71 = null;
        xYPlot69.setRangeAxisLocation((int) (short) 100, axisLocation71);
        org.jfree.chart.axis.NumberAxis numberAxis74 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D76 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge77 = null;
        double double78 = numberAxis74.valueToJava2D((double) 10, rectangle2D76, rectangleEdge77);
        org.jfree.data.Range range79 = numberAxis74.getDefaultAutoRange();
        numberAxis74.zoomRange((double) 0L, (double) 3);
        boolean boolean83 = numberAxis74.isNegativeArrowVisible();
        xYPlot69.setDomainAxis(255, (org.jfree.chart.axis.ValueAxis) numberAxis74, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder86 = xYPlot69.getDatasetRenderingOrder();
        xYPlot6.setDatasetRenderingOrder(datasetRenderingOrder86);
        boolean boolean88 = xYPlot6.isDomainZeroBaselineVisible();
        intervalMarker2.addChangeListener((org.jfree.chart.event.MarkerChangeListener) xYPlot6);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 1.0f + "'", float25 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(layer27);
        org.junit.Assert.assertNotNull(dateRange28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "Layer.FOREGROUND" + "'", str30.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(range60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertNotNull(range79);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder86);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setRange((double) (byte) 10, 100.0d);
        org.jfree.chart.axis.Timeline timeline4 = null;
        dateAxis0.setTimeline(timeline4);
        org.jfree.chart.axis.Timeline timeline6 = null;
        dateAxis0.setTimeline(timeline6);
        dateAxis0.configure();
        java.awt.Stroke stroke9 = dateAxis0.getTickMarkStroke();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition10 = dateAxis0.getTickMarkPosition();
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(dateTickMarkPosition10);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        int int6 = xYPlot5.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = xYPlot5.getRangeAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        categoryPlot8.setDomainAxis((int) 'a', categoryAxis10);
        categoryPlot8.clearAnnotations();
        boolean boolean13 = categoryPlot8.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace14 = categoryPlot8.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot8.setInsets(rectangleInsets15);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot8.getDomainAxisEdge((int) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        numberAxis20.setAutoRangeMinimumSize((double) 11, false);
        numberAxis20.setAutoRangeStickyZero(true);
        double double26 = numberAxis20.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
        double double31 = numberAxis27.valueToJava2D((double) 10, rectangle2D29, rectangleEdge30);
        org.jfree.data.Range range32 = numberAxis27.getDefaultAutoRange();
        numberAxis20.setRange(range32, true, true);
        java.awt.Color color36 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis20.setTickMarkPaint((java.awt.Paint) color36);
        categoryPlot8.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis20);
        categoryPlot8.clearRangeMarkers();
        java.awt.Color color41 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke42 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color41, stroke42);
        java.awt.Stroke stroke44 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker43.setOutlineStroke(stroke44);
        java.awt.Stroke stroke46 = valueMarker43.getStroke();
        categoryPlot8.setDomainGridlineStroke(stroke46);
        xYPlot5.setRangeGridlineStroke(stroke46);
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis();
        numberAxis50.setAutoRangeMinimumSize((double) 11, false);
        numberAxis50.setAutoRangeStickyZero(true);
        double double56 = numberAxis50.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis57 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = null;
        double double61 = numberAxis57.valueToJava2D((double) 10, rectangle2D59, rectangleEdge60);
        org.jfree.data.Range range62 = numberAxis57.getDefaultAutoRange();
        numberAxis50.setRange(range62, true, true);
        xYPlot5.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis50);
        org.jfree.chart.plot.CategoryPlot categoryPlot67 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis69 = null;
        categoryPlot67.setDomainAxis((int) 'a', categoryAxis69);
        categoryPlot67.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset73 = null;
        categoryPlot67.setDataset(0, categoryDataset73);
        float float75 = categoryPlot67.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets76 = categoryPlot67.getAxisOffset();
        java.awt.Color color77 = java.awt.Color.red;
        categoryPlot67.setRangeGridlinePaint((java.awt.Paint) color77);
        xYPlot5.setDomainCrosshairPaint((java.awt.Paint) color77);
        java.awt.geom.Point2D point2D80 = xYPlot5.getQuadrantOrigin();
        xYPlot0.zoomDomainAxes((double) 1560409200000L, plotRenderingInfo4, point2D80, true);
        org.jfree.chart.axis.AxisLocation axisLocation84 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color86 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke87 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker88 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color86, stroke87);
        boolean boolean89 = axisLocation84.equals((java.lang.Object) valueMarker88);
        float float90 = valueMarker88.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor91 = valueMarker88.getLabelAnchor();
        org.jfree.chart.util.Layer layer92 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange93 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean94 = layer92.equals((java.lang.Object) dateRange93);
        xYPlot0.addRangeMarker(12, (org.jfree.chart.plot.Marker) valueMarker88, layer92, true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(axisSpace14);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(range62);
        org.junit.Assert.assertTrue("'" + float75 + "' != '" + 1.0f + "'", float75 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets76);
        org.junit.Assert.assertNotNull(color77);
        org.junit.Assert.assertNotNull(point2D80);
        org.junit.Assert.assertNotNull(axisLocation84);
        org.junit.Assert.assertNotNull(color86);
        org.junit.Assert.assertNotNull(stroke87);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + float90 + "' != '" + 1.0f + "'", float90 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleAnchor91);
        org.junit.Assert.assertNotNull(layer92);
        org.junit.Assert.assertNotNull(dateRange93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.data.Range range5 = numberAxis0.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis6.valueToJava2D((double) 10, rectangle2D8, rectangleEdge9);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = numberAxis11.valueToJava2D((double) 10, rectangle2D13, rectangleEdge14);
        org.jfree.data.Range range16 = numberAxis11.getDefaultAutoRange();
        numberAxis6.setRange(range16);
        numberAxis0.setDefaultAutoRange(range16);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = null;
        numberAxis0.setStandardTickUnits(tickUnitSource19);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = numberAxis21.valueToJava2D((double) 10, rectangle2D23, rectangleEdge24);
        org.jfree.data.Range range26 = numberAxis21.getDefaultAutoRange();
        numberAxis0.setRangeWithMargins(range26);
        java.awt.Shape shape28 = numberAxis0.getLeftArrow();
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot();
        int int34 = xYPlot33.getDomainAxisCount();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent35 = null;
        xYPlot33.rendererChanged(rendererChangeEvent35);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = xYPlot33.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        try {
            org.jfree.chart.axis.AxisState axisState40 = numberAxis0.draw(graphics2D29, (double) (-1), rectangle2D31, rectangle2D32, rectangleEdge38, plotRenderingInfo39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge38);
    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test357");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        long long3 = day2.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
//        categoryPlot5.setDomainAxis((int) 'a', categoryAxis7);
//        categoryPlot5.setBackgroundImageAlignment((int) (short) 10);
//        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot5.getDatasetGroup();
//        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
//        categoryPlot5.setNoDataMessagePaint(paint12);
//        boolean boolean14 = day2.equals((java.lang.Object) categoryPlot5);
//        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
//        java.awt.Font font19 = null;
//        categoryAxis17.setTickLabelFont((java.lang.Comparable) (byte) -1, font19);
//        java.lang.String str21 = categoryAxis17.getLabelToolTip();
//        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D24 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
//        double double26 = numberAxis22.valueToJava2D((double) 10, rectangle2D24, rectangleEdge25);
//        java.awt.Graphics2D graphics2D27 = null;
//        org.jfree.chart.axis.AxisState axisState28 = null;
//        java.awt.geom.Rectangle2D rectangle2D29 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
//        java.util.List list31 = numberAxis22.refreshTicks(graphics2D27, axisState28, rectangle2D29, rectangleEdge30);
//        numberAxis22.setLabel("RectangleAnchor.TOP_LEFT");
//        numberAxis22.zoomRange((double) (-1L), (double) 1);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis17, (org.jfree.chart.axis.ValueAxis) numberAxis22, categoryItemRenderer37);
//        int int39 = categoryPlot5.getDomainAxisIndex(categoryAxis17);
//        java.util.Date date40 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date40, timeZone41);
//        java.awt.Paint paint43 = categoryAxis17.getTickLabelPaint((java.lang.Comparable) date40);
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date40, timeZone44);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = day45.next();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNull(datasetGroup11);
//        org.junit.Assert.assertNotNull(paint12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNull(str21);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
//        org.junit.Assert.assertNotNull(list31);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(timeZone41);
//        org.junit.Assert.assertNotNull(paint43);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.data.Range range5 = numberAxis0.getDefaultAutoRange();
        java.awt.Font font6 = numberAxis0.getTickLabelFont();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        int int10 = xYPlot9.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        xYPlot9.zoomRangeAxes((double) 255, plotRenderingInfo12, point2D13, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        categoryPlot16.setDomainAxis((int) 'a', categoryAxis18);
        categoryPlot16.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        categoryPlot16.setDataset(0, categoryDataset22);
        java.awt.Paint paint24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot16.setNoDataMessagePaint(paint24);
        java.awt.Paint paint26 = categoryPlot16.getOutlinePaint();
        int int27 = categoryPlot16.getDomainAxisCount();
        java.lang.Class<?> wildcardClass28 = categoryPlot16.getClass();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        categoryPlot30.setDomainAxis((int) 'a', categoryAxis32);
        categoryPlot30.clearAnnotations();
        boolean boolean35 = categoryPlot30.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace36 = categoryPlot30.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot30.setInsets(rectangleInsets37);
        org.jfree.chart.axis.AxisLocation axisLocation39 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation40 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation39, plotOrientation40);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor42 = org.jfree.chart.axis.CategoryAnchor.END;
        boolean boolean43 = axisLocation39.equals((java.lang.Object) categoryAnchor42);
        categoryPlot30.setRangeAxisLocation(axisLocation39, false);
        categoryPlot16.setRangeAxisLocation((int) (short) 10, axisLocation39, false);
        xYPlot9.setRangeAxisLocation(axisLocation39, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = xYPlot9.getRangeAxisEdge();
        try {
            double double51 = numberAxis0.valueToJava2D((double) 2.0f, rectangle2D8, rectangleEdge50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 98 + "'", int27 == 98);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNull(axisSpace36);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(plotOrientation40);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertNotNull(categoryAnchor42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(rectangleEdge50);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker9.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = valueMarker9.getOutlineStroke();
        boolean boolean13 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent14 = null;
        categoryPlot0.axisChanged(axisChangeEvent14);
        categoryPlot0.setDomainGridlinesVisible(false);
        categoryPlot0.setAnchorValue((double) ' ', false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        java.awt.Paint paint10 = categoryPlot0.getOutlinePaint();
        int int11 = categoryPlot0.getDomainAxisCount();
        java.lang.Class<?> wildcardClass12 = categoryPlot0.getClass();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        categoryPlot14.setDomainAxis((int) 'a', categoryAxis16);
        categoryPlot14.clearAnnotations();
        boolean boolean19 = categoryPlot14.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace20 = categoryPlot14.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot14.setInsets(rectangleInsets21);
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation23, plotOrientation24);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor26 = org.jfree.chart.axis.CategoryAnchor.END;
        boolean boolean27 = axisLocation23.equals((java.lang.Object) categoryAnchor26);
        categoryPlot14.setRangeAxisLocation(axisLocation23, false);
        categoryPlot0.setRangeAxisLocation((int) (short) 10, axisLocation23, false);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis();
        numberAxis33.setAutoRangeMinimumSize((double) 11, false);
        numberAxis33.setAutoRangeStickyZero(true);
        double double39 = numberAxis33.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = null;
        double double44 = numberAxis40.valueToJava2D((double) 10, rectangle2D42, rectangleEdge43);
        org.jfree.data.Range range45 = numberAxis40.getDefaultAutoRange();
        numberAxis33.setRange(range45, true, true);
        java.awt.Color color49 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis33.setTickMarkPaint((java.awt.Paint) color49);
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = null;
        double double55 = numberAxis51.valueToJava2D((double) 10, rectangle2D53, rectangleEdge54);
        org.jfree.chart.axis.NumberAxis numberAxis56 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = null;
        double double60 = numberAxis56.valueToJava2D((double) 10, rectangle2D58, rectangleEdge59);
        org.jfree.data.Range range61 = numberAxis56.getDefaultAutoRange();
        numberAxis51.setRange(range61);
        boolean boolean63 = color49.equals((java.lang.Object) numberAxis51);
        numberAxis51.setNegativeArrowVisible(true);
        categoryPlot0.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis51, false);
        numberAxis51.setVerticalTickLabels(false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 98 + "'", int11 == 98);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(axisSpace20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(plotOrientation24);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertNotNull(categoryAnchor26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(range61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder6 = categoryPlot0.getDatasetRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font11 = null;
        categoryAxis9.setTickLabelFont((java.lang.Comparable) (byte) -1, font11);
        java.lang.String str13 = categoryAxis9.getLabelToolTip();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis9, valueAxis14, categoryItemRenderer15);
        boolean boolean17 = datasetRenderingOrder6.equals((java.lang.Object) categoryPlot16);
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = null;
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange21 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean22 = layer20.equals((java.lang.Object) dateRange21);
        try {
            categoryPlot16.addDomainMarker((int) (short) -1, categoryMarker19, layer20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(datasetRenderingOrder6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertNotNull(dateRange21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        xYPlot0.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis5.getTickMarkPaint();
        xYPlot0.setDomainTickBandPaint(paint10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color15, stroke16);
        boolean boolean18 = axisLocation13.equals((java.lang.Object) valueMarker17);
        float float19 = valueMarker17.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = valueMarker17.getLabelAnchor();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean23 = layer21.equals((java.lang.Object) dateRange22);
        java.lang.String str24 = layer21.toString();
        xYPlot0.addDomainMarker((int) (short) 100, (org.jfree.chart.plot.Marker) valueMarker17, layer21);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        numberAxis26.setAutoRangeMinimumSize((double) 11, false);
        numberAxis26.setAutoRangeStickyZero(true);
        double double32 = numberAxis26.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        double double37 = numberAxis33.valueToJava2D((double) 10, rectangle2D35, rectangleEdge36);
        org.jfree.data.Range range38 = numberAxis33.getDefaultAutoRange();
        numberAxis26.setRange(range38, true, true);
        java.awt.Color color42 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis26.setTickMarkPaint((java.awt.Paint) color42);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = null;
        double double48 = numberAxis44.valueToJava2D((double) 10, rectangle2D46, rectangleEdge47);
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = null;
        double double53 = numberAxis49.valueToJava2D((double) 10, rectangle2D51, rectangleEdge52);
        org.jfree.data.Range range54 = numberAxis49.getDefaultAutoRange();
        numberAxis44.setRange(range54);
        boolean boolean56 = color42.equals((java.lang.Object) numberAxis44);
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color42);
        xYPlot0.clearDomainMarkers();
        java.awt.Graphics2D graphics2D59 = null;
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo61 = null;
        xYPlot0.drawAnnotations(graphics2D59, rectangle2D60, plotRenderingInfo61);
        org.jfree.chart.plot.CategoryPlot categoryPlot64 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis66 = null;
        categoryPlot64.setDomainAxis((int) 'a', categoryAxis66);
        categoryPlot64.setBackgroundImageAlignment((int) (short) 10);
        float float70 = categoryPlot64.getBackgroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation71 = categoryPlot64.getRangeAxisLocation();
        xYPlot0.setDomainAxisLocation((int) (short) 1, axisLocation71, false);
        int int74 = xYPlot0.getWeight();
        org.jfree.chart.axis.ValueAxis valueAxis75 = xYPlot0.getRangeAxis();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Layer.FOREGROUND" + "'", str24.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + float70 + "' != '" + 1.0f + "'", float70 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation71);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
        org.junit.Assert.assertNull(valueAxis75);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightInset(11.0d);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            rectangleInsets0.trim(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        xYPlot0.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis5.getTickMarkPaint();
        xYPlot0.setDomainTickBandPaint(paint10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color15, stroke16);
        boolean boolean18 = axisLocation13.equals((java.lang.Object) valueMarker17);
        float float19 = valueMarker17.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = valueMarker17.getLabelAnchor();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean23 = layer21.equals((java.lang.Object) dateRange22);
        java.lang.String str24 = layer21.toString();
        xYPlot0.addDomainMarker((int) (short) 100, (org.jfree.chart.plot.Marker) valueMarker17, layer21);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        numberAxis26.setAutoRangeMinimumSize((double) 11, false);
        numberAxis26.setAutoRangeStickyZero(true);
        double double32 = numberAxis26.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        double double37 = numberAxis33.valueToJava2D((double) 10, rectangle2D35, rectangleEdge36);
        org.jfree.data.Range range38 = numberAxis33.getDefaultAutoRange();
        numberAxis26.setRange(range38, true, true);
        java.awt.Color color42 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis26.setTickMarkPaint((java.awt.Paint) color42);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = null;
        double double48 = numberAxis44.valueToJava2D((double) 10, rectangle2D46, rectangleEdge47);
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = null;
        double double53 = numberAxis49.valueToJava2D((double) 10, rectangle2D51, rectangleEdge52);
        org.jfree.data.Range range54 = numberAxis49.getDefaultAutoRange();
        numberAxis44.setRange(range54);
        boolean boolean56 = color42.equals((java.lang.Object) numberAxis44);
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color42);
        xYPlot0.clearDomainMarkers();
        java.awt.Graphics2D graphics2D59 = null;
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo61 = null;
        xYPlot0.drawAnnotations(graphics2D59, rectangle2D60, plotRenderingInfo61);
        org.jfree.chart.plot.XYPlot xYPlot63 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation65 = null;
        xYPlot63.setRangeAxisLocation((int) (short) 100, axisLocation65);
        org.jfree.chart.axis.NumberAxis numberAxis68 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = null;
        double double72 = numberAxis68.valueToJava2D((double) 10, rectangle2D70, rectangleEdge71);
        org.jfree.data.Range range73 = numberAxis68.getDefaultAutoRange();
        numberAxis68.zoomRange((double) 0L, (double) 3);
        boolean boolean77 = numberAxis68.isNegativeArrowVisible();
        xYPlot63.setDomainAxis(255, (org.jfree.chart.axis.ValueAxis) numberAxis68, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder80 = xYPlot63.getDatasetRenderingOrder();
        xYPlot0.setDatasetRenderingOrder(datasetRenderingOrder80);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer82 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray83 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer82 };
        xYPlot0.setRenderers(xYItemRendererArray83);
        java.awt.Paint paint85 = xYPlot0.getRangeCrosshairPaint();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Layer.FOREGROUND" + "'", str24.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(range73);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder80);
        org.junit.Assert.assertNotNull(xYItemRendererArray83);
        org.junit.Assert.assertNotNull(paint85);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        categoryPlot0.clearRangeMarkers(1);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color2, stroke3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker4.setOutlineStroke(stroke5);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker4.setLabelOffsetType(lengthAdjustmentType7);
        boolean boolean9 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker4);
        xYPlot0.setRangeCrosshairVisible(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        xYPlot0.addChangeListener(plotChangeListener12);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = numberAxis15.valueToJava2D((double) 10, rectangle2D17, rectangleEdge18);
        java.awt.Paint paint20 = numberAxis15.getTickMarkPaint();
        numberAxis15.resizeRange((double) 3);
        numberAxis15.setLabelToolTip("");
        int int25 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis15);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        float float8 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot0.getAxisOffset();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj12 = null;
        boolean boolean13 = categoryAxis11.equals(obj12);
        categoryAxis11.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis11.clearCategoryLabelToolTips();
        categoryPlot0.setDomainAxis(categoryAxis11);
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot0.getRangeAxisForDataset((-1));
        org.jfree.chart.axis.AxisLocation axisLocation21 = categoryPlot0.getRangeAxisLocation();
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertNotNull(axisLocation21);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeMinimumSize((double) 11, false);
        numberAxis0.setAutoRangeStickyZero(true);
        boolean boolean6 = numberAxis0.isTickLabelsVisible();
        numberAxis0.setAutoRange(false);
        numberAxis0.setAutoRange(true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = null;
        categoryPlot0.axisChanged(axisChangeEvent11);
        org.junit.Assert.assertNotNull(paint8);
    }

//    @Test
//    public void test370() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test370");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        long long3 = day2.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
//        categoryPlot5.setDomainAxis((int) 'a', categoryAxis7);
//        categoryPlot5.setBackgroundImageAlignment((int) (short) 10);
//        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot5.getDatasetGroup();
//        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
//        categoryPlot5.setNoDataMessagePaint(paint12);
//        boolean boolean14 = day2.equals((java.lang.Object) categoryPlot5);
//        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
//        java.awt.Font font19 = null;
//        categoryAxis17.setTickLabelFont((java.lang.Comparable) (byte) -1, font19);
//        categoryPlot5.setDomainAxis(10, categoryAxis17);
//        java.lang.String str22 = categoryPlot5.getPlotType();
//        boolean boolean23 = categoryPlot5.isDomainGridlinesVisible();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNull(datasetGroup11);
//        org.junit.Assert.assertNotNull(paint12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Category Plot" + "'", str22.equals("Category Plot"));
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis5.zoomRange((double) 0L, (double) 3);
        boolean boolean14 = numberAxis5.isNegativeArrowVisible();
        xYPlot0.setDomainAxis(255, (org.jfree.chart.axis.ValueAxis) numberAxis5, false);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        numberAxis18.setAutoRangeMinimumSize((double) 11, false);
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color23, stroke24);
        numberAxis18.setLabelPaint((java.awt.Paint) color23);
        xYPlot0.setRangeAxis(7, (org.jfree.chart.axis.ValueAxis) numberAxis18, true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        xYPlot0.setRenderer(xYItemRenderer29);
        java.awt.Paint paint31 = xYPlot0.getDomainTickBandPaint();
        org.jfree.chart.axis.ValueAxis valueAxis32 = xYPlot0.getDomainAxis();
        java.awt.Stroke stroke33 = xYPlot0.getDomainZeroBaselineStroke();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertNull(valueAxis32);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker9.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = valueMarker9.getOutlineStroke();
        boolean boolean13 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.data.general.DatasetGroup datasetGroup14 = categoryPlot0.getDatasetGroup();
        categoryPlot0.setRangeCrosshairValue((double) (byte) 1);
        java.awt.Image image17 = null;
        categoryPlot0.setBackgroundImage(image17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = categoryPlot0.getFixedLegendItems();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(datasetGroup14);
        org.junit.Assert.assertNull(legendItemCollection19);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("java.awt.Color[r=128,g=0,b=128]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setRange((double) (byte) 10, 100.0d);
        java.text.DateFormat dateFormat4 = dateAxis0.getDateFormatOverride();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        int int8 = xYPlot7.getDomainAxisCount();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = null;
        xYPlot7.rendererChanged(rendererChangeEvent9);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = xYPlot7.getDomainAxisEdge(0);
        try {
            double double13 = dateAxis0.java2DToValue((double) 500, rectangle2D6, rectangleEdge12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(dateFormat4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.data.general.DatasetGroup datasetGroup6 = categoryPlot0.getDatasetGroup();
        java.awt.Paint paint7 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint7);
        boolean boolean9 = categoryPlot0.isDomainGridlinesVisible();
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        float float6 = categoryPlot0.getBackgroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot0.getRangeAxisForDataset((-393216));
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot0.getDomainAxisForDataset((-393216));
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        int int14 = xYPlot13.getDomainAxisCount();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder15 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        xYPlot13.setSeriesRenderingOrder(seriesRenderingOrder15);
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color19, stroke20);
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker21.setOutlineStroke(stroke22);
        org.jfree.chart.text.TextAnchor textAnchor24 = valueMarker21.getLabelTextAnchor();
        org.jfree.chart.util.Layer layer25 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean27 = xYPlot13.removeRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker21, layer25, true);
        java.util.Collection collection28 = categoryPlot0.getRangeMarkers(255, layer25);
        try {
            categoryPlot0.zoom((double) (-128));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNull(categoryAxis11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(seriesRenderingOrder15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(layer25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(collection28);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeMinimumSize((double) 11, false);
        numberAxis0.setAutoRangeStickyZero(true);
        double double6 = numberAxis0.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = numberAxis7.valueToJava2D((double) 10, rectangle2D9, rectangleEdge10);
        org.jfree.data.Range range12 = numberAxis7.getDefaultAutoRange();
        numberAxis0.setRange(range12, true, true);
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis0.setTickMarkPaint((java.awt.Paint) color16);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot18.setDomainAxis((int) 'a', categoryAxis20);
        categoryPlot18.clearAnnotations();
        boolean boolean23 = categoryPlot18.isOutlineVisible();
        numberAxis0.setPlot((org.jfree.chart.plot.Plot) categoryPlot18);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = null;
        double double29 = numberAxis25.valueToJava2D((double) 10, rectangle2D27, rectangleEdge28);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        double double34 = numberAxis30.valueToJava2D((double) 10, rectangle2D32, rectangleEdge33);
        org.jfree.data.Range range35 = numberAxis30.getDefaultAutoRange();
        numberAxis25.setRange(range35);
        numberAxis25.setRangeAboutValue((double) (short) -1, 0.0d);
        numberAxis25.setTickLabelsVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = null;
        double double46 = numberAxis42.valueToJava2D((double) 10, rectangle2D44, rectangleEdge45);
        org.jfree.data.Range range47 = numberAxis42.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = null;
        double double52 = numberAxis48.valueToJava2D((double) 10, rectangle2D50, rectangleEdge51);
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = null;
        double double57 = numberAxis53.valueToJava2D((double) 10, rectangle2D55, rectangleEdge56);
        org.jfree.data.Range range58 = numberAxis53.getDefaultAutoRange();
        numberAxis48.setRange(range58);
        numberAxis42.setDefaultAutoRange(range58);
        java.awt.Shape shape61 = numberAxis42.getDownArrow();
        numberAxis25.setRightArrow(shape61);
        numberAxis0.setUpArrow(shape61);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(range58);
        org.junit.Assert.assertNotNull(shape61);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        categoryPlot0.setRangeCrosshairVisible(false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryAxis1.equals(obj2);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(false);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot11.setDomainAxis((int) 'a', categoryAxis13);
        categoryPlot11.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        categoryPlot11.setDataset(0, categoryDataset17);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot11.setNoDataMessagePaint(paint19);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot11.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        categoryPlot11.rendererChanged(rendererChangeEvent23);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection27 = categoryPlot11.getRangeMarkers((int) (byte) -1, layer26);
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        org.jfree.chart.axis.AxisSpace axisSpace30 = null;
        org.jfree.chart.axis.AxisSpace axisSpace31 = categoryAxis1.reserveSpace(graphics2D10, (org.jfree.chart.plot.Plot) categoryPlot11, rectangle2D28, rectangleEdge29, axisSpace30);
        categoryPlot11.setDomainGridlinesVisible(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertNotNull(axisSpace31);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        boolean boolean5 = numberAxis0.getAutoRangeStickyZero();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        categoryPlot6.setDataset(categoryDataset7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        categoryPlot6.removeChangeListener(plotChangeListener9);
        numberAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = null;
        try {
            categoryPlot6.setAxisOffset(rectangleInsets12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'offset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

//    @Test
//    public void test381() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test381");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        long long3 = day2.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
//        categoryPlot5.setDomainAxis((int) 'a', categoryAxis7);
//        categoryPlot5.setBackgroundImageAlignment((int) (short) 10);
//        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot5.getDatasetGroup();
//        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
//        categoryPlot5.setNoDataMessagePaint(paint12);
//        boolean boolean14 = day2.equals((java.lang.Object) categoryPlot5);
//        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
//        java.awt.Font font19 = null;
//        categoryAxis17.setTickLabelFont((java.lang.Comparable) (byte) -1, font19);
//        java.lang.String str21 = categoryAxis17.getLabelToolTip();
//        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D24 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
//        double double26 = numberAxis22.valueToJava2D((double) 10, rectangle2D24, rectangleEdge25);
//        java.awt.Graphics2D graphics2D27 = null;
//        org.jfree.chart.axis.AxisState axisState28 = null;
//        java.awt.geom.Rectangle2D rectangle2D29 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
//        java.util.List list31 = numberAxis22.refreshTicks(graphics2D27, axisState28, rectangle2D29, rectangleEdge30);
//        numberAxis22.setLabel("RectangleAnchor.TOP_LEFT");
//        numberAxis22.zoomRange((double) (-1L), (double) 1);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis17, (org.jfree.chart.axis.ValueAxis) numberAxis22, categoryItemRenderer37);
//        int int39 = categoryPlot5.getDomainAxisIndex(categoryAxis17);
//        java.util.Date date40 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date40, timeZone41);
//        java.awt.Paint paint43 = categoryAxis17.getTickLabelPaint((java.lang.Comparable) date40);
//        java.util.TimeZone timeZone44 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date40, timeZone44);
//        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis();
//        org.jfree.chart.JFreeChart jFreeChart47 = null;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent48 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis46, jFreeChart47);
//        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot();
//        java.awt.Color color51 = org.jfree.chart.ChartColor.DARK_GREEN;
//        java.awt.Stroke stroke52 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker53 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color51, stroke52);
//        java.awt.Stroke stroke54 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
//        valueMarker53.setOutlineStroke(stroke54);
//        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType56 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
//        valueMarker53.setLabelOffsetType(lengthAdjustmentType56);
//        boolean boolean58 = xYPlot49.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker53);
//        org.jfree.chart.LegendItemCollection legendItemCollection59 = xYPlot49.getFixedLegendItems();
//        boolean boolean60 = dateAxis46.hasListener((java.util.EventListener) xYPlot49);
//        dateAxis46.setUpperBound(1.0d);
//        java.util.Date date64 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date64, timeZone65);
//        org.jfree.chart.axis.DateAxis dateAxis67 = new org.jfree.chart.axis.DateAxis("AxisLocation.BOTTOM_OR_LEFT", timeZone65);
//        dateAxis46.setTimeZone(timeZone65);
//        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(date40, timeZone65);
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNull(datasetGroup11);
//        org.junit.Assert.assertNotNull(paint12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNull(str21);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
//        org.junit.Assert.assertNotNull(list31);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(timeZone41);
//        org.junit.Assert.assertNotNull(paint43);
//        org.junit.Assert.assertNotNull(timeZone44);
//        org.junit.Assert.assertNotNull(color51);
//        org.junit.Assert.assertNotNull(stroke52);
//        org.junit.Assert.assertNotNull(stroke54);
//        org.junit.Assert.assertNotNull(lengthAdjustmentType56);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNull(legendItemCollection59);
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(timeZone65);
//    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis0, jFreeChart1);
        dateAxis0.zoomRange((double) (byte) -1, 0.05d);
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6, timeZone7);
        dateAxis0.setMinimumDate(date6);
        boolean boolean11 = dateAxis0.isHiddenValue(0L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        try {
            java.awt.Color color1 = java.awt.Color.decode("AxisLocation.BOTTOM_OR_LEFT");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"AxisLocation.BOTTOM_OR_LEFT\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker9.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = valueMarker9.getOutlineStroke();
        boolean boolean13 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.data.general.DatasetGroup datasetGroup14 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot15.setDomainAxis((int) 'a', categoryAxis17);
        categoryPlot15.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.data.general.DatasetGroup datasetGroup21 = categoryPlot15.getDatasetGroup();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot15);
        categoryPlot15.setBackgroundAlpha((float) (-393216));
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent25 = null;
        categoryPlot15.rendererChanged(rendererChangeEvent25);
        categoryPlot15.mapDatasetToDomainAxis((int) ' ', (int) (short) 0);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(datasetGroup14);
        org.junit.Assert.assertNull(datasetGroup21);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        double double6 = rectangleInsets4.calculateLeftInset((double) (-1));
        double double7 = rectangleInsets4.getBottom();
        double double9 = rectangleInsets4.calculateLeftOutset((double) 5);
        org.jfree.chart.util.UnitType unitType10 = rectangleInsets4.getUnitType();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 32.0d + "'", double6 == 32.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 32.0d + "'", double9 == 32.0d);
        org.junit.Assert.assertNotNull(unitType10);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color2, stroke3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker4.setOutlineStroke(stroke5);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker4.setLabelOffsetType(lengthAdjustmentType7);
        boolean boolean9 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker4);
        xYPlot0.setRangeCrosshairVisible(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        xYPlot0.addChangeListener(plotChangeListener12);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = xYPlot0.getRangeAxisEdge();
        xYPlot0.configureDomainAxes();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = numberAxis17.valueToJava2D((double) 10, rectangle2D19, rectangleEdge20);
        org.jfree.data.Range range22 = numberAxis17.getDefaultAutoRange();
        numberAxis17.zoomRange((double) 0L, (double) 3);
        boolean boolean26 = numberAxis17.isNegativeArrowVisible();
        double double27 = numberAxis17.getUpperMargin();
        xYPlot0.setRangeAxis(9, (org.jfree.chart.axis.ValueAxis) numberAxis17);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.05d + "'", double27 == 0.05d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryAxis1.equals(obj2);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        double double7 = categoryAxis1.getUpperMargin();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = numberAxis1.valueToJava2D((double) 10, rectangle2D3, rectangleEdge4);
        java.awt.Paint paint6 = numberAxis1.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis7, xYItemRenderer8);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        double double16 = rectangleInsets14.calculateLeftInset((double) (-1));
        double double17 = rectangleInsets14.getBottom();
        double double19 = rectangleInsets14.extendHeight(3.0d);
        xYPlot9.setInsets(rectangleInsets14, false);
        java.awt.Stroke stroke22 = xYPlot9.getRangeGridlineStroke();
        xYPlot9.configureRangeAxes();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 32.0d + "'", double16 == 32.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 55.0d + "'", double19 == 55.0d);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeMinimumSize((double) 11, false);
        numberAxis0.setAutoRangeStickyZero(true);
        double double6 = numberAxis0.getFixedDimension();
        numberAxis0.setLowerBound((double) (byte) 0);
        numberAxis0.zoomRange((double) 1L, (double) 5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

//    @Test
//    public void test391() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test391");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        long long3 = day2.getFirstMillisecond();
//        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
//        numberAxis4.setAutoRangeMinimumSize((double) 11, false);
//        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_GREEN;
//        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color9, stroke10);
//        numberAxis4.setLabelPaint((java.awt.Paint) color9);
//        numberAxis4.setPositiveArrowVisible(true);
//        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = numberAxis4.getTickUnit();
//        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D18 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
//        double double20 = numberAxis16.valueToJava2D((double) 10, rectangle2D18, rectangleEdge19);
//        org.jfree.data.Range range21 = numberAxis16.getDefaultAutoRange();
//        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D24 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
//        double double26 = numberAxis22.valueToJava2D((double) 10, rectangle2D24, rectangleEdge25);
//        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D29 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
//        double double31 = numberAxis27.valueToJava2D((double) 10, rectangle2D29, rectangleEdge30);
//        org.jfree.data.Range range32 = numberAxis27.getDefaultAutoRange();
//        numberAxis22.setRange(range32);
//        numberAxis16.setDefaultAutoRange(range32);
//        numberAxis16.setAutoRangeMinimumSize((double) 1, true);
//        org.jfree.data.Range range38 = numberAxis16.getDefaultAutoRange();
//        numberAxis4.setRangeWithMargins(range38, true, false);
//        boolean boolean42 = day2.equals((java.lang.Object) numberAxis4);
//        org.jfree.chart.JFreeChart jFreeChart43 = null;
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType44 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent45 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberAxis4, jFreeChart43, chartChangeEventType44);
//        java.lang.String str46 = numberAxis4.getLabelURL();
//        numberAxis4.setRangeAboutValue(152.0d, 128.0d);
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(color9);
//        org.junit.Assert.assertNotNull(stroke10);
//        org.junit.Assert.assertNotNull(numberTickUnit15);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
//        org.junit.Assert.assertNotNull(range21);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
//        org.junit.Assert.assertNotNull(range32);
//        org.junit.Assert.assertNotNull(range38);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertNotNull(chartChangeEventType44);
//        org.junit.Assert.assertNull(str46);
//    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot0.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent12);
        org.jfree.chart.util.Layer layer15 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection16 = categoryPlot0.getRangeMarkers((int) (byte) -1, layer15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj19 = null;
        boolean boolean20 = categoryAxis18.equals(obj19);
        categoryAxis18.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis18.clearCategoryLabelToolTips();
        categoryAxis18.setTickLabelsVisible(false);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        categoryPlot28.setDomainAxis((int) 'a', categoryAxis30);
        categoryPlot28.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        categoryPlot28.setDataset(0, categoryDataset34);
        java.awt.Paint paint36 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot28.setNoDataMessagePaint(paint36);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = categoryPlot28.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent40 = null;
        categoryPlot28.rendererChanged(rendererChangeEvent40);
        org.jfree.chart.util.Layer layer43 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection44 = categoryPlot28.getRangeMarkers((int) (byte) -1, layer43);
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = null;
        org.jfree.chart.axis.AxisSpace axisSpace47 = null;
        org.jfree.chart.axis.AxisSpace axisSpace48 = categoryAxis18.reserveSpace(graphics2D27, (org.jfree.chart.plot.Plot) categoryPlot28, rectangle2D45, rectangleEdge46, axisSpace47);
        categoryPlot0.setFixedRangeAxisSpace(axisSpace48, false);
        org.jfree.chart.plot.PlotOrientation plotOrientation51 = categoryPlot0.getOrientation();
        categoryPlot0.setRangeCrosshairValue((double) 10L);
        org.jfree.chart.axis.AxisSpace axisSpace54 = categoryPlot0.getFixedRangeAxisSpace();
        categoryPlot0.configureDomainAxes();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(layer15);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNotNull(layer43);
        org.junit.Assert.assertNull(collection44);
        org.junit.Assert.assertNotNull(axisSpace48);
        org.junit.Assert.assertNotNull(plotOrientation51);
        org.junit.Assert.assertNotNull(axisSpace54);
    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test393");
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
//        java.awt.Font font3 = null;
//        categoryAxis1.setTickLabelFont((java.lang.Comparable) (byte) -1, font3);
//        int int5 = categoryAxis1.getMaximumCategoryLabelLines();
//        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6, timeZone7);
//        java.util.Date date9 = day8.getEnd();
//        long long10 = day8.getSerialIndex();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day8.next();
//        java.awt.Font font12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
//        categoryAxis1.setTickLabelFont((java.lang.Comparable) regularTimePeriod11, font12);
//        java.util.Date date14 = regularTimePeriod11.getStart();
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43629L + "'", long10 == 43629L);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(font12);
//        org.junit.Assert.assertNotNull(date14);
//    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeMinimumSize((double) 11, false);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color5, stroke6);
        numberAxis0.setLabelPaint((java.awt.Paint) color5);
        java.awt.Color color9 = java.awt.Color.yellow;
        numberAxis0.setAxisLinePaint((java.awt.Paint) color9);
        numberAxis0.setLowerBound((double) (-1.0f));
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        int int3 = java.awt.Color.HSBtoRGB(0.0f, (float) 8, (float) 500);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-4691) + "'", int3 == (-4691));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker9.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = valueMarker9.getOutlineStroke();
        boolean boolean13 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.data.general.DatasetGroup datasetGroup14 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot15.setDomainAxis((int) 'a', categoryAxis17);
        categoryPlot15.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.data.general.DatasetGroup datasetGroup21 = categoryPlot15.getDatasetGroup();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot15);
        categoryPlot15.setBackgroundAlpha((float) (-393216));
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent25 = null;
        categoryPlot15.rendererChanged(rendererChangeEvent25);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor27 = categoryPlot15.getDomainGridlinePosition();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(datasetGroup14);
        org.junit.Assert.assertNull(datasetGroup21);
        org.junit.Assert.assertNotNull(categoryAnchor27);
    }
}

