import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray3 = new float[] { 100L };
        try {
            float[] floatArray4 = color0.getColorComponents(colorSpace1, floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        float[] floatArray5 = new float[] { (byte) 1, (short) 100 };
        try {
            float[] floatArray6 = java.awt.Color.RGBtoHSB((int) (byte) 1, (int) (byte) 1, (int) (short) -1, floatArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray5);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createInsetRectangle(rectangle2D1, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        java.util.TimeZone timeZone3 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        try {
            objectList1.set((int) (byte) -1, (java.lang.Object) timeZone3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timeZone3);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            categoryPlot0.drawOutline(graphics2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets4.getUnitType();
        double double7 = rectangleInsets4.calculateLeftInset((double) (byte) 100);
        org.junit.Assert.assertNotNull(unitType5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 32.0d + "'", double7 == 32.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis0.setRangeWithMargins(range10, true, true);
        java.awt.Font font14 = null;
        try {
            numberAxis0.setTickLabelFont(font14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((-1), (int) (short) 1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        try {
            java.awt.Color color1 = java.awt.Color.decode("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis0.setRange(range10);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis0.getTickUnit();
        java.awt.Font font13 = null;
        try {
            numberAxis0.setTickLabelFont(font13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(numberTickUnit12);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font3 = null;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) (byte) -1, font3);
        int int5 = categoryAxis1.getMaximumCategoryLabelLines();
        categoryAxis1.setUpperMargin(32.0d);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot9.setDomainAxis((int) 'a', categoryAxis11);
        categoryPlot9.clearAnnotations();
        boolean boolean14 = categoryPlot9.isOutlineVisible();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        categoryPlot16.setDomainAxis((int) 'a', categoryAxis18);
        categoryPlot16.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        categoryPlot16.setDataset(0, categoryDataset22);
        java.awt.Paint paint24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot16.setNoDataMessagePaint(paint24);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot16.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace28 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace29 = categoryAxis1.reserveSpace(graphics2D8, (org.jfree.chart.plot.Plot) categoryPlot9, rectangle2D15, rectangleEdge27, axisSpace28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis0.setRange(range10);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis0.getTickUnit();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.AxisState axisState14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        categoryPlot16.setDomainAxis((int) 'a', categoryAxis18);
        categoryPlot16.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        categoryPlot16.setDataset(0, categoryDataset22);
        java.awt.Paint paint24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot16.setNoDataMessagePaint(paint24);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot16.getDomainAxisEdge((int) (byte) 10);
        java.lang.Class<?> wildcardClass28 = rectangleEdge27.getClass();
        try {
            java.util.List list29 = numberAxis0.refreshTicks(graphics2D13, axisState14, rectangle2D15, rectangleEdge27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(wildcardClass28);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets4.getUnitType();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D9 = rectangleInsets4.createInsetRectangle(rectangle2D6, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(unitType5);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color6, stroke7);
        boolean boolean9 = axisLocation4.equals((java.lang.Object) valueMarker8);
        categoryPlot0.setDomainAxisLocation(axisLocation4);
        java.awt.Font font11 = null;
        try {
            categoryPlot0.setNoDataMessageFont(font11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeMinimumSize((double) 11, false);
        numberAxis0.setAutoRangeStickyZero(true);
        double double6 = numberAxis0.getLabelAngle();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis0.valueToJava2D((double) 1.0f, rectangle2D8, rectangleEdge9);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray2 = new float[] { 128 };
        try {
            float[] floatArray3 = color0.getColorComponents(floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        categoryPlot0.setDataset(categoryDataset1);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryDataset1, jFreeChart3, chartChangeEventType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot0.setInsets(rectangleInsets7);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            rectangleInsets7.trim(rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot0.setInsets(rectangleInsets7);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = null;
        org.jfree.chart.util.Layer layer11 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange12 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean13 = layer11.equals((java.lang.Object) dateRange12);
        try {
            categoryPlot0.addDomainMarker((int) (byte) 1, categoryMarker10, layer11, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(layer11);
        org.junit.Assert.assertNotNull(dateRange12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot0.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        try {
            categoryPlot0.drawOutline(graphics2D14, rectangle2D15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.util.SortOrder sortOrder6 = categoryPlot0.getColumnRenderingOrder();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation7 = null;
        try {
            boolean boolean9 = categoryPlot0.removeAnnotation(categoryAnnotation7, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(sortOrder6);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeMinimumSize((double) 11, false);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color5, stroke6);
        numberAxis0.setLabelPaint((java.awt.Paint) color5);
        try {
            numberAxis0.setRangeWithMargins((double) '#', (double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (35.0) <= upper (10.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent10);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = null;
        org.jfree.chart.util.Layer layer14 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange15 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean16 = layer14.equals((java.lang.Object) dateRange15);
        try {
            categoryPlot0.addDomainMarker(0, categoryMarker13, layer14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(layer14);
        org.junit.Assert.assertNotNull(dateRange15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.awt.Color color2 = java.awt.Color.getColor("PlotOrientation.HORIZONTAL", 11);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis0.setRange(range10);
        numberAxis0.setRangeAboutValue((double) (short) -1, 0.0d);
        numberAxis0.setTickLabelsVisible(false);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        categoryPlot20.setDomainAxis((int) 'a', categoryAxis22);
        categoryPlot20.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        categoryPlot20.setDataset(0, categoryDataset26);
        java.awt.Paint paint28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot20.setNoDataMessagePaint(paint28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot20.getDomainAxisEdge((int) (byte) 10);
        java.lang.Class<?> wildcardClass32 = rectangleEdge31.getClass();
        try {
            java.util.List list33 = numberAxis0.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(wildcardClass32);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        double double6 = rectangleInsets4.calculateLeftInset((double) (-1));
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets4.createInsetRectangle(rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 32.0d + "'", double6 == 32.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.awt.Color color1 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) 'a', 0, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color2, stroke3);
        boolean boolean5 = axisLocation0.equals((java.lang.Object) valueMarker4);
        float float6 = valueMarker4.getAlpha();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        categoryPlot7.setDomainAxis((int) 'a', categoryAxis9);
        categoryPlot7.setBackgroundImageAlignment((int) (short) 10);
        boolean boolean13 = valueMarker4.equals((java.lang.Object) (short) 10);
        java.awt.Font font14 = null;
        try {
            valueMarker4.setLabelFont(font14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        try {
            boolean boolean9 = categoryPlot0.removeAnnotation(categoryAnnotation8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray8 = new float[] { 10, ' ', (short) 10, '#', (-1.0f), 100.0f };
        try {
            float[] floatArray9 = color0.getComponents(colorSpace1, floatArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray6 = null;
        try {
            categoryPlot0.setRangeAxes(valueAxisArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.valueToJava2D((double) 10, rectangle2D4, rectangleEdge5);
        org.jfree.data.Range range7 = numberAxis2.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = numberAxis8.valueToJava2D((double) 10, rectangle2D10, rectangleEdge11);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = numberAxis13.valueToJava2D((double) 10, rectangle2D15, rectangleEdge16);
        org.jfree.data.Range range18 = numberAxis13.getDefaultAutoRange();
        numberAxis8.setRange(range18);
        numberAxis2.setDefaultAutoRange(range18);
        boolean boolean21 = objectList1.equals((java.lang.Object) numberAxis2);
        java.lang.Object obj23 = objectList1.get(11);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(obj23);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.data.general.DatasetGroup datasetGroup6 = categoryPlot0.getDatasetGroup();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        java.awt.Stroke stroke9 = null;
        try {
            categoryPlot0.setRangeCrosshairStroke(stroke9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(datasetGroup6);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) 1, (double) 11, (double) 0L);
        double double6 = rectangleInsets4.calculateBottomInset(0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 11.0d + "'", double6 == 11.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.data.Range range5 = numberAxis0.getDefaultAutoRange();
        numberAxis0.zoomRange((double) 0L, (double) 3);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.AxisState axisState10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        categoryPlot12.setDomainAxis((int) 'a', categoryAxis14);
        categoryPlot12.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        categoryPlot12.setDataset(0, categoryDataset18);
        java.awt.Paint paint20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot12.setNoDataMessagePaint(paint20);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot12.getDomainAxisEdge((int) (byte) 10);
        try {
            java.util.List list24 = numberAxis0.refreshTicks(graphics2D9, axisState10, rectangle2D11, rectangleEdge23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test075");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        long long3 = day2.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
//        categoryPlot5.setDomainAxis((int) 'a', categoryAxis7);
//        categoryPlot5.setBackgroundImageAlignment((int) (short) 10);
//        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot5.getDatasetGroup();
//        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
//        categoryPlot5.setNoDataMessagePaint(paint12);
//        boolean boolean14 = day2.equals((java.lang.Object) categoryPlot5);
//        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation15 = null;
//        try {
//            categoryPlot5.addAnnotation(categoryAnnotation15, true);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNull(datasetGroup11);
//        org.junit.Assert.assertNotNull(paint12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryAxis1.equals(obj2);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = null;
        try {
            categoryAxis1.setCategoryLabelPositions(categoryLabelPositions7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = org.jfree.chart.util.Layer.FOREGROUND;
        try {
            boolean boolean7 = categoryPlot0.removeRangeMarker(marker5, layer6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(layer6);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        float float8 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot0.getAxisOffset();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color12, stroke13);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker14.setOutlineStroke(stroke15);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType17 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker14.setLabelOffsetType(lengthAdjustmentType17);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType19 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        try {
            java.awt.geom.Rectangle2D rectangle2D20 = rectangleInsets9.createAdjustedRectangle(rectangle2D10, lengthAdjustmentType17, lengthAdjustmentType19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(lengthAdjustmentType17);
        org.junit.Assert.assertNotNull(lengthAdjustmentType19);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        double double6 = rectangleInsets4.calculateLeftInset((double) (-1));
        double double7 = rectangleInsets4.getTop();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D11 = rectangleInsets4.createOutsetRectangle(rectangle2D8, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 32.0d + "'", double6 == 32.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 52.0d + "'", double7 == 52.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.data.general.DatasetGroup datasetGroup6 = categoryPlot0.getDatasetGroup();
        categoryPlot0.setBackgroundImageAlpha(0.0f);
        categoryPlot0.setBackgroundImageAlignment(7);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            categoryPlot0.drawOutline(graphics2D11, rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(datasetGroup6);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot0.setInsets(rectangleInsets7);
        try {
            categoryPlot0.zoom((double) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font3 = null;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) (byte) -1, font3);
        int int5 = categoryAxis1.getMaximumCategoryLabelLines();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot9.setDomainAxis((int) 'a', categoryAxis11);
        categoryPlot9.clearAnnotations();
        boolean boolean14 = categoryPlot9.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace15 = categoryPlot9.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot9.setInsets(rectangleInsets16);
        categoryPlot9.setWeight((int) (short) 1);
        java.awt.Color color21 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color21, stroke22);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = valueMarker23.getLabelAnchor();
        boolean boolean25 = categoryPlot9.equals((java.lang.Object) rectangleAnchor24);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot9.getRangeAxisEdge();
        try {
            double double27 = categoryAxis1.getCategoryEnd((int) (byte) 100, 3, rectangle2D8, rectangleEdge26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(axisSpace15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RectangleAnchor.TOP_LEFT");
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot0.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation12 = null;
        try {
            boolean boolean14 = categoryPlot0.removeAnnotation(categoryAnnotation12, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        float float8 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot0.getAxisOffset();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj12 = null;
        boolean boolean13 = categoryAxis11.equals(obj12);
        categoryAxis11.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis11.clearCategoryLabelToolTips();
        categoryPlot0.setDomainAxis(categoryAxis11);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation19 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryAxis1.equals(obj2);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(false);
        boolean boolean11 = categoryAxis1.equals((java.lang.Object) 1.0d);
        int int12 = categoryAxis1.getCategoryLabelPositionOffset();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        categoryPlot16.setDomainAxis((int) 'a', categoryAxis18);
        categoryPlot16.clearAnnotations();
        boolean boolean21 = categoryPlot16.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace22 = categoryPlot16.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot16.setInsets(rectangleInsets23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot16.getDomainAxisEdge((int) (short) -1);
        try {
            double double27 = categoryAxis1.getCategoryEnd((int) (short) 100, (int) '#', rectangle2D15, rectangleEdge26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNull(axisSpace22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot0.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent12);
        java.awt.Stroke stroke14 = null;
        try {
            categoryPlot0.setRangeGridlineStroke(stroke14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = org.jfree.chart.axis.CategoryAnchor.END;
        boolean boolean4 = axisLocation0.equals((java.lang.Object) categoryAnchor3);
        java.awt.Paint[] paintArray5 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        boolean boolean6 = categoryAnchor3.equals((java.lang.Object) paintArray5);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot0.getDomainAxisEdge((int) (byte) 10);
        categoryPlot0.setAnchorValue((double) 100.0f);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        float float8 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot0.getAxisOffset();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj12 = null;
        boolean boolean13 = categoryAxis11.equals(obj12);
        categoryAxis11.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis11.clearCategoryLabelToolTips();
        categoryPlot0.setDomainAxis(categoryAxis11);
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = null;
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean23 = layer21.equals((java.lang.Object) dateRange22);
        java.lang.String str24 = layer21.toString();
        try {
            categoryPlot0.addDomainMarker((int) '#', categoryMarker20, layer21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Layer.FOREGROUND" + "'", str24.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        java.util.List list9 = numberAxis0.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge8);
        numberAxis0.setLowerBound((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        boolean boolean2 = sortOrder0.equals((java.lang.Object) 100);
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color1, stroke2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = valueMarker3.getLabelAnchor();
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color6, stroke7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker8.setOutlineStroke(stroke9);
        java.awt.Stroke stroke11 = valueMarker8.getOutlineStroke();
        valueMarker3.setStroke(stroke11);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        categoryPlot13.setDomainAxis((int) 'a', categoryAxis15);
        categoryPlot13.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color20, stroke21);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker22.setOutlineStroke(stroke23);
        java.awt.Stroke stroke25 = valueMarker22.getOutlineStroke();
        boolean boolean26 = categoryPlot13.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker22);
        org.jfree.chart.text.TextAnchor textAnchor27 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        valueMarker22.setLabelTextAnchor(textAnchor27);
        valueMarker3.setLabelTextAnchor(textAnchor27);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(textAnchor27);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis0.setRange(range10);
        numberAxis0.setRangeAboutValue((double) (short) -1, 0.0d);
        numberAxis0.setFixedDimension((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        java.awt.Paint paint10 = categoryPlot0.getOutlinePaint();
        int int11 = categoryPlot0.getDomainAxisCount();
        java.lang.Class<?> wildcardClass12 = categoryPlot0.getClass();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        categoryPlot14.setDomainAxis((int) 'a', categoryAxis16);
        categoryPlot14.clearAnnotations();
        boolean boolean19 = categoryPlot14.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace20 = categoryPlot14.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot14.setInsets(rectangleInsets21);
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation23, plotOrientation24);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor26 = org.jfree.chart.axis.CategoryAnchor.END;
        boolean boolean27 = axisLocation23.equals((java.lang.Object) categoryAnchor26);
        categoryPlot14.setRangeAxisLocation(axisLocation23, false);
        categoryPlot0.setRangeAxisLocation((int) (short) 10, axisLocation23, false);
        java.lang.String str32 = axisLocation23.toString();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 98 + "'", int11 == 98);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(axisSpace20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(plotOrientation24);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertNotNull(categoryAnchor26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str32.equals("AxisLocation.BOTTOM_OR_LEFT"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        categoryPlot0.setDataset(categoryDataset1);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder3 = null;
        try {
            categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker3.setOutlineStroke(stroke4);
        org.jfree.chart.text.TextAnchor textAnchor6 = valueMarker3.getLabelTextAnchor();
        java.lang.String str7 = textAnchor6.toString();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TextAnchor.CENTER" + "'", str7.equals("TextAnchor.CENTER"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.data.Range range5 = numberAxis0.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis6.valueToJava2D((double) 10, rectangle2D8, rectangleEdge9);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = numberAxis11.valueToJava2D((double) 10, rectangle2D13, rectangleEdge14);
        org.jfree.data.Range range16 = numberAxis11.getDefaultAutoRange();
        numberAxis6.setRange(range16);
        numberAxis0.setDefaultAutoRange(range16);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = null;
        numberAxis0.setStandardTickUnits(tickUnitSource19);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit21 = numberAxis0.getTickUnit();
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        categoryPlot23.setDomainAxis((int) 'a', categoryAxis25);
        categoryPlot23.clearAnnotations();
        boolean boolean28 = categoryPlot23.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace29 = categoryPlot23.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot23.setInsets(rectangleInsets30);
        categoryPlot23.setWeight((int) (short) 1);
        double double34 = categoryPlot23.getRangeCrosshairValue();
        java.awt.Paint paint35 = categoryPlot23.getOutlinePaint();
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        categoryPlot37.setDomainAxis((int) 'a', categoryAxis39);
        categoryPlot37.clearAnnotations();
        boolean boolean42 = categoryPlot37.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace43 = categoryPlot37.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot37.setInsets(rectangleInsets44);
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = categoryPlot37.getDomainAxisEdge((int) (short) -1);
        org.jfree.chart.axis.AxisSpace axisSpace48 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace49 = numberAxis0.reserveSpace(graphics2D22, (org.jfree.chart.plot.Plot) categoryPlot23, rectangle2D36, rectangleEdge47, axisSpace48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(numberTickUnit21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(axisSpace29);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNull(axisSpace43);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(rectangleEdge47);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryAxis1.equals(obj2);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(false);
        boolean boolean11 = categoryAxis1.equals((java.lang.Object) 1.0d);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        categoryPlot16.setDomainAxis((int) 'a', categoryAxis18);
        categoryPlot16.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        categoryPlot16.setDataset(0, categoryDataset22);
        java.awt.Paint paint24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot16.setNoDataMessagePaint(paint24);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot16.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        try {
            org.jfree.chart.axis.AxisState axisState29 = categoryAxis1.draw(graphics2D12, (double) 0L, rectangle2D14, rectangle2D15, rectangleEdge27, plotRenderingInfo28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.awt.Color color0 = java.awt.Color.gray;
        int int1 = color0.getBlue();
        float[] floatArray2 = null;
        float[] floatArray3 = color0.getComponents(floatArray2);
        java.awt.color.ColorSpace colorSpace4 = null;
        float[] floatArray11 = new float[] { 10L, (short) 0, 100, 2, 98, 128 };
        try {
            float[] floatArray12 = color0.getColorComponents(colorSpace4, floatArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.awt.Color color2 = java.awt.Color.getColor("", 128);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj5 = null;
        boolean boolean6 = categoryAxis4.equals(obj5);
        categoryAxis4.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis4.clearCategoryLabelToolTips();
        categoryAxis4.setTickLabelsVisible(false);
        categoryAxis4.setUpperMargin((double) 2);
        java.awt.Font font16 = null;
        categoryAxis4.setTickLabelFont((java.lang.Comparable) (byte) -1, font16);
        try {
            objectList1.set((int) 'a', (java.lang.Object) font16);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color2, stroke3);
        boolean boolean5 = axisLocation0.equals((java.lang.Object) valueMarker4);
        float float6 = valueMarker4.getAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        org.jfree.chart.util.UnitType unitType12 = rectangleInsets11.getUnitType();
        valueMarker4.setLabelOffset(rectangleInsets11);
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color15, stroke16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker17.setOutlineStroke(stroke18);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType20 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker17.setLabelOffsetType(lengthAdjustmentType20);
        valueMarker4.setLabelOffsetType(lengthAdjustmentType20);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        categoryPlot23.setDomainAxis((int) 'a', categoryAxis25);
        categoryPlot23.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.data.general.DatasetGroup datasetGroup29 = categoryPlot23.getDatasetGroup();
        categoryPlot23.setBackgroundImageAlpha(0.0f);
        categoryPlot23.setBackgroundImageAlignment(7);
        boolean boolean34 = lengthAdjustmentType20.equals((java.lang.Object) categoryPlot23);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(unitType12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(lengthAdjustmentType20);
        org.junit.Assert.assertNull(datasetGroup29);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis0.setRange(range10);
        numberAxis0.setRangeAboutValue((double) (short) -1, 0.0d);
        numberAxis0.setTickLabelsVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = numberAxis17.valueToJava2D((double) 10, rectangle2D19, rectangleEdge20);
        org.jfree.data.Range range22 = numberAxis17.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = numberAxis23.valueToJava2D((double) 10, rectangle2D25, rectangleEdge26);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
        double double32 = numberAxis28.valueToJava2D((double) 10, rectangle2D30, rectangleEdge31);
        org.jfree.data.Range range33 = numberAxis28.getDefaultAutoRange();
        numberAxis23.setRange(range33);
        numberAxis17.setDefaultAutoRange(range33);
        java.awt.Shape shape36 = numberAxis17.getDownArrow();
        numberAxis0.setRightArrow(shape36);
        boolean boolean38 = numberAxis0.getAutoRangeStickyZero();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot0.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot0.setRenderer(categoryItemRenderer14, true);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = numberAxis18.valueToJava2D((double) 10, rectangle2D20, rectangleEdge21);
        org.jfree.data.Range range23 = numberAxis18.getDefaultAutoRange();
        numberAxis18.zoomRange((double) 0L, (double) 3);
        java.lang.String str27 = numberAxis18.getLabel();
        categoryPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis18, false);
        double double30 = numberAxis18.getFixedDimension();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        float float6 = categoryPlot0.getBackgroundAlpha();
        categoryPlot0.setRangeCrosshairValue((double) 8, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        categoryPlot10.setDomainAxis((int) 'a', categoryAxis12);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier14 = categoryPlot10.getDrawingSupplier();
        categoryPlot0.setDrawingSupplier(drawingSupplier14);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(drawingSupplier14);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.awt.Color color1 = java.awt.Color.getColor("hi!");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 128, (double) 100.0f, (double) 6, (double) 10L);
        double double7 = rectangleInsets5.calculateLeftOutset((double) 1L);
        double double9 = rectangleInsets5.calculateTopInset(0.05d);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 128.0d + "'", double9 == 128.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryAxis1.equals(obj2);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(false);
        boolean boolean11 = categoryAxis1.equals((java.lang.Object) 1.0d);
        java.lang.Comparable comparable12 = null;
        try {
            java.awt.Font font13 = categoryAxis1.getTickLabelFont(comparable12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        float float6 = categoryPlot0.getBackgroundAlpha();
        try {
            categoryPlot0.mapDatasetToRangeAxis((-1), 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot0.setInsets(rectangleInsets7);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot0.getDomainAxisEdge((int) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeMinimumSize((double) 11, false);
        numberAxis12.setAutoRangeStickyZero(true);
        double double18 = numberAxis12.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = numberAxis19.valueToJava2D((double) 10, rectangle2D21, rectangleEdge22);
        org.jfree.data.Range range24 = numberAxis19.getDefaultAutoRange();
        numberAxis12.setRange(range24, true, true);
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis12.setTickMarkPaint((java.awt.Paint) color28);
        categoryPlot0.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis12);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        try {
            org.jfree.chart.axis.AxisState axisState37 = numberAxis12.draw(graphics2D31, (double) (-1L), rectangle2D33, rectangle2D34, rectangleEdge35, plotRenderingInfo36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(color28);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot0.setInsets(rectangleInsets7);
        categoryPlot0.setWeight((int) (short) 1);
        java.lang.Object obj11 = categoryPlot0.clone();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            xYPlot0.drawBackground(graphics2D2, rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        double double6 = rectangleInsets4.calculateLeftInset((double) (-1));
        double double7 = rectangleInsets4.getTop();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            rectangleInsets4.trim(rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 32.0d + "'", double6 == 32.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 52.0d + "'", double7 == 52.0d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.awt.Font font0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double7 = rectangleInsets5.calculateRightInset(11.0d);
        categoryPlot0.setInsets(rectangleInsets5);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.data.Range range5 = numberAxis0.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis6.valueToJava2D((double) 10, rectangle2D8, rectangleEdge9);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = numberAxis11.valueToJava2D((double) 10, rectangle2D13, rectangleEdge14);
        org.jfree.data.Range range16 = numberAxis11.getDefaultAutoRange();
        numberAxis6.setRange(range16);
        numberAxis0.setDefaultAutoRange(range16);
        numberAxis0.setAutoRangeMinimumSize((double) 1, true);
        org.jfree.data.Range range22 = numberAxis0.getDefaultAutoRange();
        double double23 = numberAxis0.getLowerBound();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        boolean boolean7 = categoryPlot0.isRangeZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot0.getRendererForDataset(categoryDataset8);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font14 = null;
        categoryAxis12.setTickLabelFont((java.lang.Comparable) (byte) -1, font14);
        java.lang.String str16 = categoryAxis12.getLabelToolTip();
        categoryPlot0.setDomainAxis(6, categoryAxis12, false);
        java.awt.Paint paint20 = categoryAxis12.getTickLabelPaint((java.lang.Comparable) 7);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker9.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = valueMarker9.getOutlineStroke();
        boolean boolean13 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot0.setOrientation(plotOrientation14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        categoryPlot17.setDomainAxis((int) 'a', categoryAxis19);
        categoryPlot17.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        categoryPlot17.setDataset(0, categoryDataset23);
        java.awt.Paint paint25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot17.setNoDataMessagePaint(paint25);
        java.awt.Paint paint27 = categoryPlot17.getOutlinePaint();
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.awt.image.ColorModel colorModel29 = null;
        java.awt.Rectangle rectangle30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        java.awt.geom.AffineTransform affineTransform32 = null;
        java.awt.RenderingHints renderingHints33 = null;
        java.awt.PaintContext paintContext34 = color28.createContext(colorModel29, rectangle30, rectangle2D31, affineTransform32, renderingHints33);
        java.awt.Paint[] paintArray35 = new java.awt.Paint[] { color16, paint27, color28 };
        java.awt.Paint[] paintArray36 = null;
        java.awt.Paint[] paintArray37 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray38 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray39 = null;
        java.awt.Shape[] shapeArray40 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier41 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray35, paintArray36, paintArray37, strokeArray38, strokeArray39, shapeArray40);
        boolean boolean42 = plotOrientation14.equals((java.lang.Object) paintArray35);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(paintContext34);
        org.junit.Assert.assertNotNull(paintArray35);
        org.junit.Assert.assertNotNull(paintArray37);
        org.junit.Assert.assertNotNull(strokeArray38);
        org.junit.Assert.assertNotNull(shapeArray40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeMinimumSize((double) 11, false);
        numberAxis0.setAutoRangeStickyZero(true);
        double double6 = numberAxis0.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = numberAxis7.valueToJava2D((double) 10, rectangle2D9, rectangleEdge10);
        org.jfree.data.Range range12 = numberAxis7.getDefaultAutoRange();
        numberAxis0.setRange(range12, true, true);
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis0.setTickMarkPaint((java.awt.Paint) color16);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = numberAxis18.valueToJava2D((double) 10, rectangle2D20, rectangleEdge21);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = numberAxis23.valueToJava2D((double) 10, rectangle2D25, rectangleEdge26);
        org.jfree.data.Range range28 = numberAxis23.getDefaultAutoRange();
        numberAxis18.setRange(range28);
        boolean boolean30 = color16.equals((java.lang.Object) numberAxis18);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.axis.AxisState axisState32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        int int35 = xYPlot34.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = xYPlot34.getRangeAxisEdge();
        try {
            java.util.List list37 = numberAxis18.refreshTicks(graphics2D31, axisState32, rectangle2D33, rectangleEdge36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge36);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 128, (double) 100.0f, (double) 6, (double) 10L);
        java.lang.String str6 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UnitType.ABSOLUTE" + "'", str6.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        java.util.List list9 = numberAxis0.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge8);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        double double16 = rectangleInsets14.calculateLeftInset((double) (-1));
        numberAxis0.setTickLabelInsets(rectangleInsets14);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = numberAxis0.getLabelInsets();
        java.text.NumberFormat numberFormat19 = null;
        numberAxis0.setNumberFormatOverride(numberFormat19);
        numberAxis0.setAutoRangeStickyZero(false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 32.0d + "'", double16 == 32.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot0.setInsets(rectangleInsets7);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot0.getDomainAxisEdge((int) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeMinimumSize((double) 11, false);
        numberAxis12.setAutoRangeStickyZero(true);
        double double18 = numberAxis12.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = numberAxis19.valueToJava2D((double) 10, rectangle2D21, rectangleEdge22);
        org.jfree.data.Range range24 = numberAxis19.getDefaultAutoRange();
        numberAxis12.setRange(range24, true, true);
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis12.setTickMarkPaint((java.awt.Paint) color28);
        categoryPlot0.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis12);
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation32 = null;
        try {
            boolean boolean33 = categoryPlot0.removeAnnotation(categoryAnnotation32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(color28);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.util.SortOrder sortOrder6 = categoryPlot0.getColumnRenderingOrder();
        categoryPlot0.setBackgroundImageAlignment(7);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(sortOrder6);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color1, stroke2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = valueMarker3.getLabelAnchor();
        java.lang.String str5 = valueMarker3.getLabel();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot0.setInsets(rectangleInsets7);
        categoryPlot0.setWeight((int) (short) 1);
        double double11 = categoryPlot0.getRangeCrosshairValue();
        java.awt.Paint paint12 = categoryPlot0.getOutlinePaint();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.Point2D point2D15 = null;
        org.jfree.chart.plot.PlotState plotState16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        try {
            categoryPlot0.draw(graphics2D13, rectangle2D14, point2D15, plotState16, plotRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
        java.util.Date date3 = day2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj8 = null;
        boolean boolean9 = categoryAxis7.equals(obj8);
        categoryAxis7.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis7.clearCategoryLabelToolTips();
        categoryAxis7.setTickLabelsVisible(false);
        categoryAxis7.setUpperMargin((double) 2);
        java.awt.Color color19 = java.awt.Color.gray;
        categoryAxis7.setTickLabelPaint((java.lang.Comparable) (-1.0f), (java.awt.Paint) color19);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        categoryPlot21.setDomainAxis((int) 'a', categoryAxis23);
        categoryPlot21.clearAnnotations();
        boolean boolean26 = categoryPlot21.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace27 = categoryPlot21.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot21.setInsets(rectangleInsets28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot21.getDomainAxisEdge((int) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis();
        numberAxis33.setAutoRangeMinimumSize((double) 11, false);
        numberAxis33.setAutoRangeStickyZero(true);
        double double39 = numberAxis33.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = null;
        double double44 = numberAxis40.valueToJava2D((double) 10, rectangle2D42, rectangleEdge43);
        org.jfree.data.Range range45 = numberAxis40.getDefaultAutoRange();
        numberAxis33.setRange(range45, true, true);
        java.awt.Color color49 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis33.setTickMarkPaint((java.awt.Paint) color49);
        categoryPlot21.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis33);
        categoryPlot21.clearRangeMarkers();
        java.awt.Color color54 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke55 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker56 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color54, stroke55);
        java.awt.Stroke stroke57 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker56.setOutlineStroke(stroke57);
        java.awt.Stroke stroke59 = valueMarker56.getStroke();
        categoryPlot21.setDomainGridlineStroke(stroke59);
        java.awt.Paint paint61 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = null;
        categoryPlot62.setDomainAxis((int) 'a', categoryAxis64);
        java.awt.Stroke stroke66 = categoryPlot62.getRangeCrosshairStroke();
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker68 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day5, (java.awt.Paint) color19, stroke59, paint61, stroke66, (float) 13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(axisSpace27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(stroke66);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        categoryPlot7.setDomainAxis((int) 'a', categoryAxis9);
        categoryPlot7.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        categoryPlot7.setDataset(0, categoryDataset13);
        java.awt.Paint paint15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot7.setNoDataMessagePaint(paint15);
        java.awt.Paint paint17 = categoryPlot7.getOutlinePaint();
        int int18 = categoryPlot7.getDomainAxisCount();
        java.lang.Class<?> wildcardClass19 = categoryPlot7.getClass();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        categoryPlot21.setDomainAxis((int) 'a', categoryAxis23);
        categoryPlot21.clearAnnotations();
        boolean boolean26 = categoryPlot21.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace27 = categoryPlot21.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot21.setInsets(rectangleInsets28);
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation31 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation30, plotOrientation31);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor33 = org.jfree.chart.axis.CategoryAnchor.END;
        boolean boolean34 = axisLocation30.equals((java.lang.Object) categoryAnchor33);
        categoryPlot21.setRangeAxisLocation(axisLocation30, false);
        categoryPlot7.setRangeAxisLocation((int) (short) 10, axisLocation30, false);
        xYPlot0.setRangeAxisLocation(axisLocation30, true);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis42 = xYPlot0.getRangeAxisForDataset((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 10 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 98 + "'", int18 == 98);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(axisSpace27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(plotOrientation31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(categoryAnchor33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker3.setOutlineStroke(stroke4);
        float float6 = valueMarker3.getAlpha();
        org.jfree.chart.text.TextAnchor textAnchor7 = null;
        try {
            valueMarker3.setLabelTextAnchor(textAnchor7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.data.general.DatasetGroup datasetGroup6 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot0.getDomainAxis(0);
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNull(categoryAxis8);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = null;
        try {
            categoryAxis1.setCategoryLabelPositions(categoryLabelPositions2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        int int3 = java.awt.Color.HSBtoRGB((float) 3, 1.0f, (float) 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-393216) + "'", int3 == (-393216));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setAutoRangeMinimumSize((double) 11, false);
        numberAxis5.setAutoRangeStickyZero(true);
        double double11 = numberAxis5.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = numberAxis12.valueToJava2D((double) 10, rectangle2D14, rectangleEdge15);
        org.jfree.data.Range range17 = numberAxis12.getDefaultAutoRange();
        numberAxis5.setRange(range17, true, true);
        numberAxis0.setRangeWithMargins(range17, false, false);
        numberAxis0.setLowerBound((double) 'a');
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(range17);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
        java.util.Date date3 = day2.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
        java.util.Calendar calendar6 = null;
        try {
            day5.peg(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
        java.util.Date date3 = day2.getEnd();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day2.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(timeZone1);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setAutoRangeMinimumSize((double) 11, false);
        numberAxis5.setAutoRangeStickyZero(true);
        double double11 = numberAxis5.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = numberAxis12.valueToJava2D((double) 10, rectangle2D14, rectangleEdge15);
        org.jfree.data.Range range17 = numberAxis12.getDefaultAutoRange();
        numberAxis5.setRange(range17, true, true);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis5.setTickMarkPaint((java.awt.Paint) color21);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = numberAxis23.valueToJava2D((double) 10, rectangle2D25, rectangleEdge26);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
        double double32 = numberAxis28.valueToJava2D((double) 10, rectangle2D30, rectangleEdge31);
        org.jfree.data.Range range33 = numberAxis28.getDefaultAutoRange();
        numberAxis23.setRange(range33);
        boolean boolean35 = color21.equals((java.lang.Object) numberAxis23);
        numberAxis0.setAxisLinePaint((java.awt.Paint) color21);
        int int37 = color21.getTransparency();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color1, stroke2);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = valueMarker3.getLabelAnchor();
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color6, stroke7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker8.setOutlineStroke(stroke9);
        java.awt.Stroke stroke11 = valueMarker8.getOutlineStroke();
        valueMarker3.setStroke(stroke11);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = org.jfree.chart.util.RectangleAnchor.TOP;
        valueMarker3.setLabelAnchor(rectangleAnchor13);
        java.lang.String str15 = valueMarker3.getLabel();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.axis.AxisLocation axisLocation3 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation3, plotOrientation4);
        try {
            double double6 = dateAxis0.valueToJava2D((double) (byte) 0, rectangle2D2, rectangleEdge5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(plotOrientation4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot0.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent12);
        org.jfree.chart.util.Layer layer15 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection16 = categoryPlot0.getRangeMarkers((int) (byte) -1, layer15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj19 = null;
        boolean boolean20 = categoryAxis18.equals(obj19);
        categoryAxis18.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis18.clearCategoryLabelToolTips();
        categoryAxis18.setTickLabelsVisible(false);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        categoryPlot28.setDomainAxis((int) 'a', categoryAxis30);
        categoryPlot28.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        categoryPlot28.setDataset(0, categoryDataset34);
        java.awt.Paint paint36 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot28.setNoDataMessagePaint(paint36);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = categoryPlot28.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent40 = null;
        categoryPlot28.rendererChanged(rendererChangeEvent40);
        org.jfree.chart.util.Layer layer43 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection44 = categoryPlot28.getRangeMarkers((int) (byte) -1, layer43);
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = null;
        org.jfree.chart.axis.AxisSpace axisSpace47 = null;
        org.jfree.chart.axis.AxisSpace axisSpace48 = categoryAxis18.reserveSpace(graphics2D27, (org.jfree.chart.plot.Plot) categoryPlot28, rectangle2D45, rectangleEdge46, axisSpace47);
        categoryPlot0.setFixedRangeAxisSpace(axisSpace48, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
        try {
            categoryPlot0.handleClick((int) (short) 100, (int) (short) -1, plotRenderingInfo53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(layer15);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNotNull(layer43);
        org.junit.Assert.assertNull(collection44);
        org.junit.Assert.assertNotNull(axisSpace48);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker9.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = valueMarker9.getOutlineStroke();
        boolean boolean13 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        try {
            valueMarker9.setAlpha((float) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (short) 1, 1.0E-8d, (double) 10.0f, (double) (byte) 1);
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeMinimumSize((double) 11, false);
        numberAxis0.setAutoRangeStickyZero(true);
        double double6 = numberAxis0.getLabelAngle();
        org.jfree.chart.plot.Plot plot7 = numberAxis0.getPlot();
        numberAxis0.setLabelAngle((double) (-1));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(plot7);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font3 = null;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) (byte) -1, font3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot6.setDomainAxis((int) 'a', categoryAxis8);
        categoryPlot6.clearAnnotations();
        boolean boolean11 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.util.SortOrder sortOrder12 = categoryPlot6.getColumnRenderingOrder();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        categoryPlot14.setDomainAxis((int) 'a', categoryAxis16);
        categoryPlot14.clearAnnotations();
        boolean boolean19 = categoryPlot14.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace20 = categoryPlot14.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot14.setInsets(rectangleInsets21);
        categoryPlot14.setWeight((int) (short) 1);
        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color26, stroke27);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = valueMarker28.getLabelAnchor();
        boolean boolean30 = categoryPlot14.equals((java.lang.Object) rectangleAnchor29);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot14.getRangeAxisEdge();
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj34 = null;
        boolean boolean35 = categoryAxis33.equals(obj34);
        categoryAxis33.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis33.clearCategoryLabelToolTips();
        categoryAxis33.setTickLabelsVisible(false);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = null;
        categoryPlot43.setDomainAxis((int) 'a', categoryAxis45);
        categoryPlot43.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset49 = null;
        categoryPlot43.setDataset(0, categoryDataset49);
        java.awt.Paint paint51 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot43.setNoDataMessagePaint(paint51);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = categoryPlot43.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent55 = null;
        categoryPlot43.rendererChanged(rendererChangeEvent55);
        org.jfree.chart.util.Layer layer58 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection59 = categoryPlot43.getRangeMarkers((int) (byte) -1, layer58);
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = null;
        org.jfree.chart.axis.AxisSpace axisSpace62 = null;
        org.jfree.chart.axis.AxisSpace axisSpace63 = categoryAxis33.reserveSpace(graphics2D42, (org.jfree.chart.plot.Plot) categoryPlot43, rectangle2D60, rectangleEdge61, axisSpace62);
        try {
            org.jfree.chart.axis.AxisSpace axisSpace64 = categoryAxis1.reserveSpace(graphics2D5, (org.jfree.chart.plot.Plot) categoryPlot6, rectangle2D13, rectangleEdge31, axisSpace63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(sortOrder12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(axisSpace20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(rectangleAnchor29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertNotNull(layer58);
        org.junit.Assert.assertNull(collection59);
        org.junit.Assert.assertNotNull(axisSpace63);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis0.setRange(range10);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis0.getTickUnit();
        double double13 = numberAxis0.getLabelAngle();
        boolean boolean14 = numberAxis0.isTickLabelsVisible();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        java.util.Date date4 = day3.getEnd();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6, timeZone7);
        java.util.Date date9 = day8.getEnd();
        try {
            dateAxis0.setRange(date4, date9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeMinimumSize((double) 11, false);
        numberAxis0.setAutoRangeStickyZero(true);
        double double6 = numberAxis0.getLabelAngle();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        categoryPlot7.setDomainAxis((int) 'a', categoryAxis9);
        categoryPlot7.setBackgroundImageAlignment((int) (short) 10);
        numberAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        org.jfree.data.RangeType rangeType14 = null;
        try {
            numberAxis0.setRangeType(rangeType14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        categoryPlot1.setDomainAxis((int) 'a', categoryAxis3);
        categoryPlot1.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.data.general.DatasetGroup datasetGroup7 = categoryPlot1.getDatasetGroup();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot1.getRenderer();
        boolean boolean9 = rectangleInsets0.equals((java.lang.Object) categoryPlot1);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets0.createOutsetRectangle(rectangle2D10, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNull(datasetGroup7);
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) ' ', 255, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker9.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = valueMarker9.getOutlineStroke();
        boolean boolean13 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot0.setOrientation(plotOrientation14);
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = categoryPlot0.getOrientation();
        java.lang.String str17 = plotOrientation16.toString();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str17.equals("PlotOrientation.HORIZONTAL"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeMinimumSize((double) 11, false);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color5, stroke6);
        numberAxis0.setLabelPaint((java.awt.Paint) color5);
        numberAxis0.setPositiveArrowVisible(true);
        java.lang.Object obj11 = numberAxis0.clone();
        double double12 = numberAxis0.getUpperMargin();
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        xYPlot0.setRangeAxisLocation(4, axisLocation8);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation10 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation10, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        float float8 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot0.getAxisOffset();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj12 = null;
        boolean boolean13 = categoryAxis11.equals(obj12);
        categoryAxis11.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis11.clearCategoryLabelToolTips();
        categoryPlot0.setDomainAxis(categoryAxis11);
        java.awt.Stroke stroke19 = categoryPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        float float6 = categoryPlot0.getBackgroundAlpha();
        java.lang.String str7 = categoryPlot0.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        double double14 = rectangleInsets12.calculateLeftInset((double) (-1));
        double double15 = rectangleInsets12.getBottom();
        org.jfree.data.general.Dataset dataset16 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) double15, dataset16);
        categoryPlot0.datasetChanged(datasetChangeEvent17);
        int int19 = categoryPlot0.getDomainAxisCount();
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Category Plot" + "'", str7.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 32.0d + "'", double14 == 32.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 98 + "'", int19 == 98);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = categoryPlot0.getDrawingSupplier();
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        double double12 = rectangleInsets10.calculateLeftInset((double) (-1));
        double double13 = rectangleInsets10.getTop();
        boolean boolean14 = categoryPlot0.equals((java.lang.Object) double13);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        categoryPlot0.setDataset((int) (short) 1, categoryDataset16);
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 32.0d + "'", double12 == 32.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 52.0d + "'", double13 == 52.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryAxis1.equals(obj2);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(false);
        categoryAxis1.setUpperMargin((double) 2);
        java.awt.Color color13 = java.awt.Color.gray;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (-1.0f), (java.awt.Paint) color13);
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot();
        int int19 = xYPlot18.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = xYPlot18.getRangeAxisEdge();
        try {
            double double21 = categoryAxis1.getCategoryMiddle(3, 128, rectangle2D17, rectangleEdge20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test177");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        long long3 = day2.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
//        categoryPlot5.setDomainAxis((int) 'a', categoryAxis7);
//        categoryPlot5.setBackgroundImageAlignment((int) (short) 10);
//        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot5.getDatasetGroup();
//        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
//        categoryPlot5.setNoDataMessagePaint(paint12);
//        boolean boolean14 = day2.equals((java.lang.Object) categoryPlot5);
//        java.awt.Stroke stroke15 = categoryPlot5.getOutlineStroke();
//        org.jfree.chart.util.ObjectList objectList17 = new org.jfree.chart.util.ObjectList(0);
//        int int19 = objectList17.indexOf((java.lang.Object) 100);
//        boolean boolean20 = categoryPlot5.equals((java.lang.Object) 100);
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNull(datasetGroup11);
//        org.junit.Assert.assertNotNull(paint12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(stroke15);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeMinimumSize((double) 11, false);
        java.awt.Paint paint4 = numberAxis0.getLabelPaint();
        java.awt.Paint paint5 = numberAxis0.getTickMarkPaint();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        xYPlot0.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis5.getTickMarkPaint();
        xYPlot0.setDomainTickBandPaint(paint10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color15, stroke16);
        boolean boolean18 = axisLocation13.equals((java.lang.Object) valueMarker17);
        float float19 = valueMarker17.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = valueMarker17.getLabelAnchor();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean23 = layer21.equals((java.lang.Object) dateRange22);
        java.lang.String str24 = layer21.toString();
        xYPlot0.addDomainMarker((int) (short) 100, (org.jfree.chart.plot.Marker) valueMarker17, layer21);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis27 = xYPlot0.getRangeAxisForDataset(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 4 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Layer.FOREGROUND" + "'", str24.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        float float6 = categoryPlot0.getBackgroundAlpha();
        org.jfree.chart.axis.AxisSpace axisSpace7 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        try {
            categoryPlot0.setDomainAxisLocation((-1), axisLocation9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNull(axisSpace7);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot0.setInsets(rectangleInsets7);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot0.getDomainAxisEdge((int) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeMinimumSize((double) 11, false);
        numberAxis12.setAutoRangeStickyZero(true);
        double double18 = numberAxis12.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = numberAxis19.valueToJava2D((double) 10, rectangle2D21, rectangleEdge22);
        org.jfree.data.Range range24 = numberAxis19.getDefaultAutoRange();
        numberAxis12.setRange(range24, true, true);
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis12.setTickMarkPaint((java.awt.Paint) color28);
        categoryPlot0.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis12);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation31 = null;
        try {
            boolean boolean32 = categoryPlot0.removeAnnotation(categoryAnnotation31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(color28);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        java.awt.geom.Point2D point2D14 = null;
        org.jfree.chart.plot.PlotState plotState15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        try {
            categoryPlot0.draw(graphics2D12, rectangle2D13, point2D14, plotState15, plotRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str1.equals("ChartChangeEventType.NEW_DATASET"));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.awt.Color color2 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT", (int) (byte) 0);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        java.lang.Object obj3 = objectList1.get((int) '4');
        objectList1.clear();
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        float float6 = categoryPlot0.getBackgroundAlpha();
        java.lang.String str7 = categoryPlot0.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        double double14 = rectangleInsets12.calculateLeftInset((double) (-1));
        double double15 = rectangleInsets12.getBottom();
        org.jfree.data.general.Dataset dataset16 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) double15, dataset16);
        categoryPlot0.datasetChanged(datasetChangeEvent17);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        categoryPlot0.setRenderer(categoryItemRenderer19, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj25 = null;
        boolean boolean26 = categoryAxis24.equals(obj25);
        try {
            categoryPlot0.setDomainAxis((-393216), categoryAxis24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Category Plot" + "'", str7.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 32.0d + "'", double14 == 32.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeMinimumSize((double) 11, false);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color5, stroke6);
        numberAxis0.setLabelPaint((java.awt.Paint) color5);
        numberAxis0.setPositiveArrowVisible(true);
        numberAxis0.setLabelAngle((double) 8);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation1 = axisLocation0.getOpposite();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(axisLocation1);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test191");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        long long3 = day2.getFirstMillisecond();
//        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
//        numberAxis4.setAutoRangeMinimumSize((double) 11, false);
//        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_GREEN;
//        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color9, stroke10);
//        numberAxis4.setLabelPaint((java.awt.Paint) color9);
//        numberAxis4.setPositiveArrowVisible(true);
//        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = numberAxis4.getTickUnit();
//        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D18 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
//        double double20 = numberAxis16.valueToJava2D((double) 10, rectangle2D18, rectangleEdge19);
//        org.jfree.data.Range range21 = numberAxis16.getDefaultAutoRange();
//        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D24 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
//        double double26 = numberAxis22.valueToJava2D((double) 10, rectangle2D24, rectangleEdge25);
//        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D29 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
//        double double31 = numberAxis27.valueToJava2D((double) 10, rectangle2D29, rectangleEdge30);
//        org.jfree.data.Range range32 = numberAxis27.getDefaultAutoRange();
//        numberAxis22.setRange(range32);
//        numberAxis16.setDefaultAutoRange(range32);
//        numberAxis16.setAutoRangeMinimumSize((double) 1, true);
//        org.jfree.data.Range range38 = numberAxis16.getDefaultAutoRange();
//        numberAxis4.setRangeWithMargins(range38, true, false);
//        boolean boolean42 = day2.equals((java.lang.Object) numberAxis4);
//        java.lang.String str43 = day2.toString();
//        java.util.Calendar calendar44 = null;
//        try {
//            long long45 = day2.getMiddleMillisecond(calendar44);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(color9);
//        org.junit.Assert.assertNotNull(stroke10);
//        org.junit.Assert.assertNotNull(numberTickUnit15);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
//        org.junit.Assert.assertNotNull(range21);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
//        org.junit.Assert.assertNotNull(range32);
//        org.junit.Assert.assertNotNull(range38);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "13-June-2019" + "'", str43.equals("13-June-2019"));
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font3 = null;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) (byte) -1, font3);
        int int5 = categoryAxis1.getMaximumCategoryLabelLines();
        categoryAxis1.setCategoryLabelPositionOffset((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        float float6 = categoryPlot0.getBackgroundAlpha();
        java.lang.String str7 = categoryPlot0.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        double double14 = rectangleInsets12.calculateLeftInset((double) (-1));
        double double15 = rectangleInsets12.getBottom();
        org.jfree.data.general.Dataset dataset16 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) double15, dataset16);
        categoryPlot0.datasetChanged(datasetChangeEvent17);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        categoryPlot0.setRenderer(categoryItemRenderer19, false);
        java.awt.Paint paint22 = categoryPlot0.getNoDataMessagePaint();
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Category Plot" + "'", str7.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 32.0d + "'", double14 == 32.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        categoryPlot0.setDataset(categoryDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        categoryPlot0.removeChangeListener(plotChangeListener3);
        int int5 = categoryPlot0.getDomainAxisCount();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.data.Range range5 = numberAxis0.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis6.valueToJava2D((double) 10, rectangle2D8, rectangleEdge9);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = numberAxis11.valueToJava2D((double) 10, rectangle2D13, rectangleEdge14);
        org.jfree.data.Range range16 = numberAxis11.getDefaultAutoRange();
        numberAxis6.setRange(range16);
        numberAxis0.setDefaultAutoRange(range16);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = null;
        numberAxis0.setStandardTickUnits(tickUnitSource19);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = numberAxis21.valueToJava2D((double) 10, rectangle2D23, rectangleEdge24);
        org.jfree.data.Range range26 = numberAxis21.getDefaultAutoRange();
        numberAxis0.setRangeWithMargins(range26);
        org.jfree.data.RangeType rangeType28 = null;
        try {
            numberAxis0.setRangeType(rangeType28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(range26);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryAxis1.equals(obj2);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(false);
        categoryAxis1.setUpperMargin((double) 2);
        java.awt.Font font13 = null;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) (byte) -1, font13);
        categoryAxis1.setCategoryMargin((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryAxis1.equals(obj2);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(false);
        categoryAxis1.setUpperMargin((double) 2);
        java.awt.Font font13 = null;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) (byte) -1, font13);
        java.lang.Comparable comparable15 = null;
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.Color color18 = java.awt.Color.getColor("hi!", color17);
        try {
            categoryAxis1.setTickLabelPaint(comparable15, (java.awt.Paint) color18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        java.util.List list9 = numberAxis0.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge8);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        double double16 = rectangleInsets14.calculateLeftInset((double) (-1));
        numberAxis0.setTickLabelInsets(rectangleInsets14);
        double double19 = rectangleInsets14.extendHeight((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 32.0d + "'", double16 == 32.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 62.0d + "'", double19 == 62.0d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryAxis1.equals(obj2);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(false);
        boolean boolean11 = categoryAxis1.equals((java.lang.Object) 1.0d);
        int int12 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setLowerMargin((double) 10);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = numberAxis15.valueToJava2D((double) 10, rectangle2D17, rectangleEdge18);
        org.jfree.data.Range range20 = numberAxis15.getDefaultAutoRange();
        java.awt.Font font21 = numberAxis15.getTickLabelFont();
        categoryAxis1.setTickLabelFont(font21);
        categoryAxis1.setCategoryLabelPositionOffset(7);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(font21);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        xYPlot0.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis5.getTickMarkPaint();
        xYPlot0.setDomainTickBandPaint(paint10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color15, stroke16);
        boolean boolean18 = axisLocation13.equals((java.lang.Object) valueMarker17);
        float float19 = valueMarker17.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = valueMarker17.getLabelAnchor();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean23 = layer21.equals((java.lang.Object) dateRange22);
        java.lang.String str24 = layer21.toString();
        xYPlot0.addDomainMarker((int) (short) 100, (org.jfree.chart.plot.Marker) valueMarker17, layer21);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        numberAxis26.setAutoRangeMinimumSize((double) 11, false);
        numberAxis26.setAutoRangeStickyZero(true);
        double double32 = numberAxis26.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        double double37 = numberAxis33.valueToJava2D((double) 10, rectangle2D35, rectangleEdge36);
        org.jfree.data.Range range38 = numberAxis33.getDefaultAutoRange();
        numberAxis26.setRange(range38, true, true);
        java.awt.Color color42 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis26.setTickMarkPaint((java.awt.Paint) color42);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = null;
        double double48 = numberAxis44.valueToJava2D((double) 10, rectangle2D46, rectangleEdge47);
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = null;
        double double53 = numberAxis49.valueToJava2D((double) 10, rectangle2D51, rectangleEdge52);
        org.jfree.data.Range range54 = numberAxis49.getDefaultAutoRange();
        numberAxis44.setRange(range54);
        boolean boolean56 = color42.equals((java.lang.Object) numberAxis44);
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color42);
        org.jfree.chart.plot.IntervalMarker intervalMarker61 = new org.jfree.chart.plot.IntervalMarker(10.0d, (double) ' ');
        double double62 = intervalMarker61.getEndValue();
        intervalMarker61.setEndValue((double) 4);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer65 = intervalMarker61.getGradientPaintTransformer();
        org.jfree.chart.util.Layer layer66 = null;
        try {
            xYPlot0.addDomainMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) intervalMarker61, layer66);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Layer.FOREGROUND" + "'", str24.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 32.0d + "'", double62 == 32.0d);
        org.junit.Assert.assertNull(gradientPaintTransformer65);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font3 = null;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) (byte) -1, font3);
        int int5 = categoryAxis1.getMaximumCategoryLabelLines();
        categoryAxis1.setUpperMargin(32.0d);
        int int8 = categoryAxis1.getMaximumCategoryLabelLines();
        categoryAxis1.setLowerMargin((double) (short) 1);
        categoryAxis1.setLabelToolTip("13-June-2019");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        try {
            java.awt.Color color1 = java.awt.Color.decode("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeMinimumSize((double) 11, false);
        numberAxis0.setAutoRangeStickyZero(true);
        double double6 = numberAxis0.getLabelAngle();
        boolean boolean7 = numberAxis0.getAutoRangeIncludesZero();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        int int3 = objectList1.indexOf((java.lang.Object) 100);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        numberAxis5.setAutoRangeMinimumSize((double) 11, false);
        numberAxis5.setAutoRangeStickyZero(true);
        double double11 = numberAxis5.getFixedDimension();
        try {
            objectList1.set(7, (java.lang.Object) double11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 7");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot3.setDomainAxis((int) 'a', categoryAxis5);
        categoryPlot3.clearAnnotations();
        boolean boolean8 = categoryPlot3.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace9 = categoryPlot3.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot3.setInsets(rectangleInsets10);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot3.getDomainAxisEdge((int) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        numberAxis15.setAutoRangeMinimumSize((double) 11, false);
        numberAxis15.setAutoRangeStickyZero(true);
        double double21 = numberAxis15.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
        double double26 = numberAxis22.valueToJava2D((double) 10, rectangle2D24, rectangleEdge25);
        org.jfree.data.Range range27 = numberAxis22.getDefaultAutoRange();
        numberAxis15.setRange(range27, true, true);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis15.setTickMarkPaint((java.awt.Paint) color31);
        categoryPlot3.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis15);
        categoryPlot3.clearRangeMarkers();
        java.awt.Color color36 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke37 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color36, stroke37);
        java.awt.Stroke stroke39 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker38.setOutlineStroke(stroke39);
        java.awt.Stroke stroke41 = valueMarker38.getStroke();
        categoryPlot3.setDomainGridlineStroke(stroke41);
        xYPlot0.setRangeGridlineStroke(stroke41);
        java.awt.geom.Point2D point2D44 = null;
        try {
            xYPlot0.setQuadrantOrigin(point2D44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets4.getUnitType();
        double double7 = rectangleInsets4.calculateRightInset((double) 10);
        org.junit.Assert.assertNotNull(unitType5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 11.0d + "'", double7 == 11.0d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis0.setRange(range10);
        numberAxis0.setRangeAboutValue((double) (short) -1, 0.0d);
        numberAxis0.configure();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        xYPlot0.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis5.getTickMarkPaint();
        xYPlot0.setDomainTickBandPaint(paint10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color15, stroke16);
        boolean boolean18 = axisLocation13.equals((java.lang.Object) valueMarker17);
        float float19 = valueMarker17.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = valueMarker17.getLabelAnchor();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean23 = layer21.equals((java.lang.Object) dateRange22);
        java.lang.String str24 = layer21.toString();
        xYPlot0.addDomainMarker((int) (short) 100, (org.jfree.chart.plot.Marker) valueMarker17, layer21);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        numberAxis26.setAutoRangeMinimumSize((double) 11, false);
        numberAxis26.setAutoRangeStickyZero(true);
        double double32 = numberAxis26.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        double double37 = numberAxis33.valueToJava2D((double) 10, rectangle2D35, rectangleEdge36);
        org.jfree.data.Range range38 = numberAxis33.getDefaultAutoRange();
        numberAxis26.setRange(range38, true, true);
        java.awt.Color color42 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis26.setTickMarkPaint((java.awt.Paint) color42);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = null;
        double double48 = numberAxis44.valueToJava2D((double) 10, rectangle2D46, rectangleEdge47);
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = null;
        double double53 = numberAxis49.valueToJava2D((double) 10, rectangle2D51, rectangleEdge52);
        org.jfree.data.Range range54 = numberAxis49.getDefaultAutoRange();
        numberAxis44.setRange(range54);
        boolean boolean56 = color42.equals((java.lang.Object) numberAxis44);
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color42);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation58 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation58, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Layer.FOREGROUND" + "'", str24.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        categoryPlot8.setDomainAxis((int) 'a', categoryAxis10);
        categoryPlot8.setBackgroundImageAlignment((int) (short) 10);
        float float14 = categoryPlot8.getBackgroundAlpha();
        org.jfree.chart.axis.AxisSpace axisSpace15 = categoryPlot8.getFixedRangeAxisSpace();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot8);
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color21 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color21, stroke22);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker23.setOutlineStroke(stroke24);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType26 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker23.setLabelOffsetType(lengthAdjustmentType26);
        boolean boolean28 = xYPlot19.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker23);
        org.jfree.chart.LegendItemCollection legendItemCollection29 = xYPlot19.getFixedLegendItems();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        categoryPlot30.setDomainAxis((int) 'a', categoryAxis32);
        categoryPlot30.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        categoryPlot30.setDataset(0, categoryDataset36);
        java.awt.Paint paint38 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot30.setNoDataMessagePaint(paint38);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = categoryPlot30.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent42 = null;
        categoryPlot30.rendererChanged(rendererChangeEvent42);
        org.jfree.chart.util.Layer layer45 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection46 = categoryPlot30.getRangeMarkers((int) (byte) -1, layer45);
        java.util.Collection collection47 = xYPlot19.getRangeMarkers(layer45);
        try {
            categoryPlot0.addDomainMarker((int) (short) 100, categoryMarker18, layer45, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 1.0f + "'", float14 == 1.0f);
        org.junit.Assert.assertNull(axisSpace15);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(lengthAdjustmentType26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(legendItemCollection29);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertNotNull(layer45);
        org.junit.Assert.assertNull(collection46);
        org.junit.Assert.assertNull(collection47);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        java.awt.Paint paint10 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot0.getColumnRenderingOrder();
        categoryPlot0.setWeight((int) (short) -1);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(sortOrder11);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.data.general.DatasetGroup datasetGroup6 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = categoryPlot0.getRenderer();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            categoryPlot0.drawBackground(graphics2D8, rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNull(categoryItemRenderer7);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker9.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = valueMarker9.getOutlineStroke();
        boolean boolean13 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot0.setOrientation(plotOrientation14);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        categoryPlot16.setDomainAxis((int) 'a', categoryAxis18);
        categoryPlot16.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.data.general.DatasetGroup datasetGroup22 = categoryPlot16.getDatasetGroup();
        java.awt.Paint paint23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        categoryPlot16.setNoDataMessagePaint(paint23);
        categoryPlot0.setRangeGridlinePaint(paint23);
        org.jfree.data.general.DatasetGroup datasetGroup26 = categoryPlot0.getDatasetGroup();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNull(datasetGroup22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(datasetGroup26);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeMinimumSize((double) 11, false);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color5, stroke6);
        numberAxis0.setLabelPaint((java.awt.Paint) color5);
        numberAxis0.setPositiveArrowVisible(true);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        categoryPlot12.setDomainAxis((int) 'a', categoryAxis14);
        categoryPlot12.setBackgroundImageAlignment((int) (short) 10);
        float float18 = categoryPlot12.getBackgroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation19 = categoryPlot12.getRangeAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot12.getRangeAxisForDataset((-393216));
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation23, plotOrientation24);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj28 = null;
        boolean boolean29 = categoryAxis27.equals(obj28);
        categoryAxis27.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis27.clearCategoryLabelToolTips();
        categoryAxis27.setTickLabelsVisible(false);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        categoryPlot37.setDomainAxis((int) 'a', categoryAxis39);
        categoryPlot37.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset43 = null;
        categoryPlot37.setDataset(0, categoryDataset43);
        java.awt.Paint paint45 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot37.setNoDataMessagePaint(paint45);
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = categoryPlot37.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent49 = null;
        categoryPlot37.rendererChanged(rendererChangeEvent49);
        org.jfree.chart.util.Layer layer52 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection53 = categoryPlot37.getRangeMarkers((int) (byte) -1, layer52);
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = null;
        org.jfree.chart.axis.AxisSpace axisSpace56 = null;
        org.jfree.chart.axis.AxisSpace axisSpace57 = categoryAxis27.reserveSpace(graphics2D36, (org.jfree.chart.plot.Plot) categoryPlot37, rectangle2D54, rectangleEdge55, axisSpace56);
        try {
            org.jfree.chart.axis.AxisSpace axisSpace58 = numberAxis0.reserveSpace(graphics2D11, (org.jfree.chart.plot.Plot) categoryPlot12, rectangle2D22, rectangleEdge25, axisSpace56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 1.0f + "'", float18 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNull(valueAxis21);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(plotOrientation24);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertNotNull(layer52);
        org.junit.Assert.assertNull(collection53);
        org.junit.Assert.assertNotNull(axisSpace57);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        xYPlot0.zoomRangeAxes((double) (byte) 1, plotRenderingInfo8, point2D9, false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis((int) 'a', categoryAxis7);
        categoryPlot5.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color12, stroke13);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker14.setOutlineStroke(stroke15);
        java.awt.Stroke stroke17 = valueMarker14.getOutlineStroke();
        boolean boolean18 = categoryPlot5.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker14);
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean21 = layer19.equals((java.lang.Object) dateRange20);
        java.lang.String str22 = layer19.toString();
        xYPlot0.addDomainMarker((int) '#', (org.jfree.chart.plot.Marker) valueMarker14, layer19);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        categoryPlot25.setDomainAxis((int) 'a', categoryAxis27);
        categoryPlot25.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        categoryPlot25.setDataset(0, categoryDataset31);
        java.awt.Paint paint33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot25.setNoDataMessagePaint(paint33);
        java.awt.Paint paint35 = categoryPlot25.getOutlinePaint();
        int int36 = categoryPlot25.getDomainAxisCount();
        java.lang.Class<?> wildcardClass37 = categoryPlot25.getClass();
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
        categoryPlot39.setDomainAxis((int) 'a', categoryAxis41);
        categoryPlot39.clearAnnotations();
        boolean boolean44 = categoryPlot39.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace45 = categoryPlot39.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot39.setInsets(rectangleInsets46);
        org.jfree.chart.axis.AxisLocation axisLocation48 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation49 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation48, plotOrientation49);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor51 = org.jfree.chart.axis.CategoryAnchor.END;
        boolean boolean52 = axisLocation48.equals((java.lang.Object) categoryAnchor51);
        categoryPlot39.setRangeAxisLocation(axisLocation48, false);
        categoryPlot25.setRangeAxisLocation((int) (short) 10, axisLocation48, false);
        xYPlot0.setDomainAxisLocation(1, axisLocation48, false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(layer19);
        org.junit.Assert.assertNotNull(dateRange20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Layer.FOREGROUND" + "'", str22.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 98 + "'", int36 == 98);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNull(axisSpace45);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertNotNull(plotOrientation49);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertNotNull(categoryAnchor51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color2, stroke3);
        boolean boolean5 = axisLocation0.equals((java.lang.Object) valueMarker4);
        float float6 = valueMarker4.getAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        org.jfree.chart.util.UnitType unitType12 = rectangleInsets11.getUnitType();
        valueMarker4.setLabelOffset(rectangleInsets11);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D15 = rectangleInsets11.createInsetRectangle(rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(unitType12);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.jfree.chart.util.UnitType unitType1 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets(unitType1, (double) 128, (double) 100.0f, (double) 6, (double) 10L);
        double double8 = rectangleInsets6.calculateLeftOutset((double) 1L);
        boolean boolean9 = rectangleAnchor0.equals((java.lang.Object) rectangleInsets6);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = numberAxis10.valueToJava2D((double) 10, rectangle2D12, rectangleEdge13);
        org.jfree.data.Range range15 = numberAxis10.getDefaultAutoRange();
        numberAxis10.zoomRange((double) 0L, (double) 3);
        boolean boolean19 = rectangleAnchor0.equals((java.lang.Object) 3);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(unitType1);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test221");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        long long3 = day2.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
//        categoryPlot5.setDomainAxis((int) 'a', categoryAxis7);
//        categoryPlot5.setBackgroundImageAlignment((int) (short) 10);
//        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot5.getDatasetGroup();
//        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
//        categoryPlot5.setNoDataMessagePaint(paint12);
//        boolean boolean14 = day2.equals((java.lang.Object) categoryPlot5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day2.previous();
//        java.util.Calendar calendar16 = null;
//        try {
//            day2.peg(calendar16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNull(datasetGroup11);
//        org.junit.Assert.assertNotNull(paint12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setRange((double) (byte) 10, 100.0d);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot6.setDomainAxis((int) 'a', categoryAxis8);
        categoryPlot6.clearAnnotations();
        boolean boolean11 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace12 = categoryPlot6.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot6.setInsets(rectangleInsets13);
        categoryPlot6.setWeight((int) (short) 1);
        java.awt.Color color18 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color18, stroke19);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = valueMarker20.getLabelAnchor();
        boolean boolean22 = categoryPlot6.equals((java.lang.Object) rectangleAnchor21);
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot6.getRangeAxisEdge();
        try {
            double double24 = dateAxis0.valueToJava2D(0.0d, rectangle2D5, rectangleEdge23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(axisSpace12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker9.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = valueMarker9.getOutlineStroke();
        boolean boolean13 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.data.general.DatasetGroup datasetGroup14 = categoryPlot0.getDatasetGroup();
        java.awt.Paint paint15 = null;
        categoryPlot0.setBackgroundPaint(paint15);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(datasetGroup14);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        float float6 = categoryPlot0.getBackgroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot0.getRangeAxisForDataset((-393216));
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation10 = null;
        try {
            boolean boolean11 = categoryPlot0.removeAnnotation(categoryAnnotation10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNull(valueAxis9);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker5 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color3, stroke4);
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker5.setOutlineStroke(stroke6);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType8 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker5.setLabelOffsetType(lengthAdjustmentType8);
        boolean boolean10 = xYPlot1.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker5);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation13 = null;
        xYPlot11.setRangeAxisLocation((int) (short) 100, axisLocation13);
        xYPlot11.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = numberAxis16.valueToJava2D((double) 10, rectangle2D18, rectangleEdge19);
        java.awt.Paint paint21 = numberAxis16.getTickMarkPaint();
        xYPlot11.setDomainTickBandPaint(paint21);
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color26, stroke27);
        boolean boolean29 = axisLocation24.equals((java.lang.Object) valueMarker28);
        float float30 = valueMarker28.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = valueMarker28.getLabelAnchor();
        org.jfree.chart.util.Layer layer32 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange33 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean34 = layer32.equals((java.lang.Object) dateRange33);
        java.lang.String str35 = layer32.toString();
        xYPlot11.addDomainMarker((int) (short) 100, (org.jfree.chart.plot.Marker) valueMarker28, layer32);
        java.awt.Color color37 = java.awt.Color.GREEN;
        valueMarker28.setOutlinePaint((java.awt.Paint) color37);
        xYPlot1.setRangeGridlinePaint((java.awt.Paint) color37);
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot();
        java.util.List list41 = xYPlot40.getAnnotations();
        java.awt.Stroke stroke42 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot40.setDomainZeroBaselineStroke(stroke42);
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        categoryPlot44.setDomainAxis((int) 'a', categoryAxis46);
        categoryPlot44.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset50 = null;
        categoryPlot44.setDataset(0, categoryDataset50);
        float float52 = categoryPlot44.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = categoryPlot44.getAxisOffset();
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj56 = null;
        boolean boolean57 = categoryAxis55.equals(obj56);
        categoryAxis55.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis55.clearCategoryLabelToolTips();
        categoryPlot44.setDomainAxis(categoryAxis55);
        org.jfree.chart.axis.AxisLocation axisLocation64 = null;
        categoryPlot44.setRangeAxisLocation(255, axisLocation64);
        java.awt.Color color66 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        float[] floatArray73 = new float[] { 255, (short) 100, 100.0f, 1L, (short) 0, 'a' };
        float[] floatArray74 = color66.getRGBColorComponents(floatArray73);
        categoryPlot44.setBackgroundPaint((java.awt.Paint) color66);
        java.awt.Paint paint76 = categoryPlot44.getRangeCrosshairPaint();
        java.awt.Color color78 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke79 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker80 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color78, stroke79);
        java.awt.Stroke stroke81 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker80.setOutlineStroke(stroke81);
        java.awt.Stroke stroke83 = valueMarker80.getOutlineStroke();
        try {
            org.jfree.chart.plot.ValueMarker valueMarker85 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color37, stroke42, paint76, stroke83, (float) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(lengthAdjustmentType8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 1.0f + "'", float30 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleAnchor31);
        org.junit.Assert.assertNotNull(layer32);
        org.junit.Assert.assertNotNull(dateRange33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "Layer.FOREGROUND" + "'", str35.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(list41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + float52 + "' != '" + 1.0f + "'", float52 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets53);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNotNull(floatArray73);
        org.junit.Assert.assertNotNull(floatArray74);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertNotNull(color78);
        org.junit.Assert.assertNotNull(stroke79);
        org.junit.Assert.assertNotNull(stroke81);
        org.junit.Assert.assertNotNull(stroke83);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        java.lang.Object obj0 = null;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent(obj0, jFreeChart1, chartChangeEventType2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chartChangeEventType2);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis0.setRangeWithMargins(range10, true, true);
        java.text.NumberFormat numberFormat14 = numberAxis0.getNumberFormatOverride();
        java.text.NumberFormat numberFormat15 = numberAxis0.getNumberFormatOverride();
        java.awt.Font font16 = numberAxis0.getTickLabelFont();
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        categoryPlot19.setDomainAxis((int) 'a', categoryAxis21);
        categoryPlot19.clearAnnotations();
        boolean boolean24 = categoryPlot19.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace25 = categoryPlot19.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot19.setInsets(rectangleInsets26);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot19.getDomainAxisEdge((int) (short) -1);
        try {
            double double30 = numberAxis0.lengthToJava2D((double) '4', rectangle2D18, rectangleEdge29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNull(numberFormat14);
        org.junit.Assert.assertNull(numberFormat15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(axisSpace25);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(rectangleEdge29);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryAxis1.equals(obj2);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis1.setCategoryMargin((double) (-393216));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundAlpha((float) 4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        categoryPlot0.setRenderer(categoryItemRenderer3, false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        float float8 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot0.getAxisOffset();
        boolean boolean11 = categoryPlot0.equals((java.lang.Object) 4.0d);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

//    @Test
//    public void test234() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test234");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        java.awt.Color color3 = java.awt.Color.gray;
//        int int4 = color3.getBlue();
//        float[] floatArray5 = null;
//        float[] floatArray6 = color3.getComponents(floatArray5);
//        boolean boolean7 = day2.equals((java.lang.Object) floatArray5);
//        int int8 = day2.getDayOfMonth();
//        java.lang.String str9 = day2.toString();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertNotNull(color3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 128 + "'", int4 == 128);
//        org.junit.Assert.assertNotNull(floatArray6);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 13 + "'", int8 == 13);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "13-June-2019" + "'", str9.equals("13-June-2019"));
//    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryAxis1.equals(obj2);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(false);
        boolean boolean11 = categoryAxis1.equals((java.lang.Object) 1.0d);
        int int12 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setLowerMargin((double) 10);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = numberAxis15.valueToJava2D((double) 10, rectangle2D17, rectangleEdge18);
        org.jfree.data.Range range20 = numberAxis15.getDefaultAutoRange();
        java.awt.Font font21 = numberAxis15.getTickLabelFont();
        categoryAxis1.setTickLabelFont(font21);
        categoryAxis1.setFixedDimension((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(font21);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot0.setInsets(rectangleInsets7);
        categoryPlot0.setWeight((int) (short) 1);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color12, stroke13);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = valueMarker14.getLabelAnchor();
        boolean boolean16 = categoryPlot0.equals((java.lang.Object) rectangleAnchor15);
        categoryPlot0.setDrawSharedDomainAxis(false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker3.setOutlineStroke(stroke4);
        java.awt.Paint paint6 = valueMarker3.getOutlinePaint();
        java.lang.String str7 = valueMarker3.getLabel();
        valueMarker3.setAlpha(0.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        valueMarker3.notifyListeners(markerChangeEvent10);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot0.setInsets(rectangleInsets7);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot0.getDomainAxisEdge((int) (short) -1);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = categoryPlot0.getDatasetRenderingOrder();
        org.jfree.chart.util.SortOrder sortOrder12 = categoryPlot0.getColumnRenderingOrder();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertNotNull(sortOrder12);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        int int1 = color0.getAlpha();
        float[] floatArray6 = new float[] { '4', (byte) -1, 8, 0L };
        float[] floatArray7 = color0.getColorComponents(floatArray6);
        int int8 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent10);
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        boolean boolean13 = categoryPlot0.equals((java.lang.Object) textAnchor12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot0.getDomainAxisLocation(255);
        categoryPlot0.clearRangeMarkers();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot0.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent12);
        org.jfree.chart.util.Layer layer15 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection16 = categoryPlot0.getRangeMarkers((int) (byte) -1, layer15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj19 = null;
        boolean boolean20 = categoryAxis18.equals(obj19);
        categoryAxis18.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis18.clearCategoryLabelToolTips();
        categoryAxis18.setTickLabelsVisible(false);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        categoryPlot28.setDomainAxis((int) 'a', categoryAxis30);
        categoryPlot28.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        categoryPlot28.setDataset(0, categoryDataset34);
        java.awt.Paint paint36 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot28.setNoDataMessagePaint(paint36);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = categoryPlot28.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent40 = null;
        categoryPlot28.rendererChanged(rendererChangeEvent40);
        org.jfree.chart.util.Layer layer43 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection44 = categoryPlot28.getRangeMarkers((int) (byte) -1, layer43);
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = null;
        org.jfree.chart.axis.AxisSpace axisSpace47 = null;
        org.jfree.chart.axis.AxisSpace axisSpace48 = categoryAxis18.reserveSpace(graphics2D27, (org.jfree.chart.plot.Plot) categoryPlot28, rectangle2D45, rectangleEdge46, axisSpace47);
        categoryPlot0.setFixedRangeAxisSpace(axisSpace48, false);
        org.jfree.chart.LegendItemCollection legendItemCollection51 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection51);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(layer15);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNotNull(layer43);
        org.junit.Assert.assertNull(collection44);
        org.junit.Assert.assertNotNull(axisSpace48);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent10);
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        boolean boolean13 = categoryPlot0.equals((java.lang.Object) textAnchor12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot0.getDomainAxisLocation(255);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        categoryPlot0.setRenderer(11, categoryItemRenderer17, false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color2, stroke3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker4.setOutlineStroke(stroke5);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker4.setLabelOffsetType(lengthAdjustmentType7);
        boolean boolean9 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker4);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        xYPlot10.setRangeAxisLocation((int) (short) 100, axisLocation12);
        xYPlot10.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = numberAxis15.valueToJava2D((double) 10, rectangle2D17, rectangleEdge18);
        java.awt.Paint paint20 = numberAxis15.getTickMarkPaint();
        xYPlot10.setDomainTickBandPaint(paint20);
        org.jfree.chart.axis.AxisLocation axisLocation23 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color25, stroke26);
        boolean boolean28 = axisLocation23.equals((java.lang.Object) valueMarker27);
        float float29 = valueMarker27.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = valueMarker27.getLabelAnchor();
        org.jfree.chart.util.Layer layer31 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange32 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean33 = layer31.equals((java.lang.Object) dateRange32);
        java.lang.String str34 = layer31.toString();
        xYPlot10.addDomainMarker((int) (short) 100, (org.jfree.chart.plot.Marker) valueMarker27, layer31);
        java.awt.Color color36 = java.awt.Color.GREEN;
        valueMarker27.setOutlinePaint((java.awt.Paint) color36);
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color36);
        java.awt.Graphics2D graphics2D39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        try {
            xYPlot0.drawBackground(graphics2D39, rectangle2D40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 1.0f + "'", float29 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNotNull(layer31);
        org.junit.Assert.assertNotNull(dateRange32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Layer.FOREGROUND" + "'", str34.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(color36);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        xYPlot0.setRangeAxisLocation(4, axisLocation8);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis11 = xYPlot0.getRangeAxisForDataset(98);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 98 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        categoryPlot1.setDomainAxis((int) 'a', categoryAxis3);
        categoryPlot1.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        categoryPlot1.setDataset(0, categoryDataset7);
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot1.setNoDataMessagePaint(paint9);
        java.awt.Paint paint11 = categoryPlot1.getOutlinePaint();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = color12.createContext(colorModel13, rectangle14, rectangle2D15, affineTransform16, renderingHints17);
        java.awt.Paint[] paintArray19 = new java.awt.Paint[] { color0, paint11, color12 };
        java.awt.Paint[] paintArray20 = null;
        java.awt.Paint[] paintArray21 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray22 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray23 = null;
        java.awt.Shape[] shapeArray24 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier25 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray19, paintArray20, paintArray21, strokeArray22, strokeArray23, shapeArray24);
        try {
            java.awt.Paint paint26 = defaultDrawingSupplier25.getNextFillPaint();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNotNull(paintArray19);
        org.junit.Assert.assertNotNull(paintArray21);
        org.junit.Assert.assertNotNull(strokeArray22);
        org.junit.Assert.assertNotNull(shapeArray24);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.util.List list1 = xYPlot0.getAnnotations();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainZeroBaselineStroke(stroke2);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray4 = null;
        try {
            xYPlot0.setRangeAxes(valueAxisArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker9.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = valueMarker9.getOutlineStroke();
        boolean boolean13 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        try {
            valueMarker9.setAlpha((float) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot0.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot0.setRenderer(categoryItemRenderer14, true);
        java.awt.Color color17 = java.awt.Color.black;
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        float[] floatArray25 = new float[] { 255, (short) 100, 100.0f, 1L, (short) 0, 'a' };
        float[] floatArray26 = color18.getRGBColorComponents(floatArray25);
        float[] floatArray27 = color17.getColorComponents(floatArray25);
        categoryPlot0.setRangeCrosshairPaint((java.awt.Paint) color17);
        boolean boolean30 = color17.equals((java.lang.Object) (byte) 0);
        int int31 = color17.getRed();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis5.zoomRange((double) 0L, (double) 3);
        boolean boolean14 = numberAxis5.isNegativeArrowVisible();
        xYPlot0.setDomainAxis(255, (org.jfree.chart.axis.ValueAxis) numberAxis5, false);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        numberAxis18.setAutoRangeMinimumSize((double) 11, false);
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color23, stroke24);
        numberAxis18.setLabelPaint((java.awt.Paint) color23);
        xYPlot0.setRangeAxis(7, (org.jfree.chart.axis.ValueAxis) numberAxis18, true);
        org.jfree.chart.axis.AxisLocation axisLocation30 = null;
        try {
            xYPlot0.setDomainAxisLocation((-1), axisLocation30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        boolean boolean5 = numberAxis0.getAutoRangeStickyZero();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        categoryPlot6.setDataset(categoryDataset7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        categoryPlot6.removeChangeListener(plotChangeListener9);
        numberAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis0.setTickMarkPaint((java.awt.Paint) color12);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        numberAxis0.setVerticalTickLabels(false);
        double double7 = numberAxis0.getFixedDimension();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.data.Range range5 = numberAxis0.getDefaultAutoRange();
        numberAxis0.zoomRange((double) 0L, (double) 3);
        java.lang.String str9 = numberAxis0.getLabel();
        numberAxis0.setLowerBound((double) 1L);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot0.setInsets(rectangleInsets7);
        categoryPlot0.setWeight((int) (short) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        int int12 = categoryPlot0.getIndexOf(categoryItemRenderer11);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker9.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = valueMarker9.getOutlineStroke();
        boolean boolean13 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.data.general.DatasetGroup datasetGroup14 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot15.setDomainAxis((int) 'a', categoryAxis17);
        categoryPlot15.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.data.general.DatasetGroup datasetGroup21 = categoryPlot15.getDatasetGroup();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot15);
        categoryPlot15.setBackgroundAlpha((float) (-393216));
        categoryPlot15.setRangeCrosshairValue((double) (byte) 0, false);
        java.util.List list28 = categoryPlot15.getAnnotations();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(datasetGroup14);
        org.junit.Assert.assertNull(datasetGroup21);
        org.junit.Assert.assertNotNull(list28);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis5.zoomRange((double) 0L, (double) 3);
        boolean boolean14 = numberAxis5.isNegativeArrowVisible();
        xYPlot0.setDomainAxis(255, (org.jfree.chart.axis.ValueAxis) numberAxis5, false);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = numberAxis17.valueToJava2D((double) 10, rectangle2D19, rectangleEdge20);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
        double double26 = numberAxis22.valueToJava2D((double) 10, rectangle2D24, rectangleEdge25);
        org.jfree.data.Range range27 = numberAxis22.getDefaultAutoRange();
        numberAxis17.setRange(range27);
        numberAxis17.setRangeAboutValue((double) (short) -1, 0.0d);
        numberAxis17.setTickLabelsVisible(false);
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        int int35 = color34.getRGB();
        numberAxis17.setAxisLinePaint((java.awt.Paint) color34);
        int int37 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis17);
        org.jfree.chart.plot.Marker marker39 = null;
        org.jfree.chart.util.Layer layer40 = org.jfree.chart.util.Layer.BACKGROUND;
        try {
            boolean boolean41 = xYPlot0.removeRangeMarker(5, marker39, layer40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-128) + "'", int35 == (-128));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(layer40);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis0, jFreeChart1);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color5, stroke6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker7.setOutlineStroke(stroke8);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType10 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker7.setLabelOffsetType(lengthAdjustmentType10);
        boolean boolean12 = xYPlot3.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker7);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = xYPlot3.getFixedLegendItems();
        boolean boolean14 = dateAxis0.hasListener((java.util.EventListener) xYPlot3);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.AxisState axisState16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot18.setDomainAxis((int) 'a', categoryAxis20);
        categoryPlot18.clearAnnotations();
        boolean boolean23 = categoryPlot18.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace24 = categoryPlot18.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot18.setInsets(rectangleInsets25);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot18.getDomainAxisEdge((int) (short) -1);
        try {
            java.util.List list29 = dateAxis0.refreshTicks(graphics2D15, axisState16, rectangle2D17, rectangleEdge28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(lengthAdjustmentType10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(legendItemCollection13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(axisSpace24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis0, jFreeChart1);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color5, stroke6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker7.setOutlineStroke(stroke8);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType10 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker7.setLabelOffsetType(lengthAdjustmentType10);
        boolean boolean12 = xYPlot3.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker7);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = xYPlot3.getFixedLegendItems();
        boolean boolean14 = dateAxis0.hasListener((java.util.EventListener) xYPlot3);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        int int16 = color15.getAlpha();
        float[] floatArray21 = new float[] { '4', (byte) -1, 8, 0L };
        float[] floatArray22 = color15.getColorComponents(floatArray21);
        int int23 = color15.getGreen();
        xYPlot3.setDomainCrosshairPaint((java.awt.Paint) color15);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(lengthAdjustmentType10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(legendItemCollection13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 255 + "'", int16 == 255);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 128 + "'", int23 == 128);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.util.Size2D size2D0 = null;
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color4, stroke5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = valueMarker6.getLabelAnchor();
        java.lang.String str8 = rectangleAnchor7.toString();
        try {
            java.awt.geom.Rectangle2D rectangle2D9 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 1, (double) (byte) -1, rectangleAnchor7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleAnchor.TOP_LEFT" + "'", str8.equals("RectangleAnchor.TOP_LEFT"));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        boolean boolean7 = categoryPlot0.isRangeZoomable();
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getDomainAxisLocation();
        categoryPlot0.setAnchorValue((-1.0d), false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(axisLocation10);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        float float6 = categoryPlot0.getBackgroundAlpha();
        java.awt.Paint paint7 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        categoryPlot0.setRangeCrosshairPaint(paint7);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(paint7);
    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test264");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        long long3 = day2.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
//        categoryPlot5.setDomainAxis((int) 'a', categoryAxis7);
//        categoryPlot5.setBackgroundImageAlignment((int) (short) 10);
//        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot5.getDatasetGroup();
//        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
//        categoryPlot5.setNoDataMessagePaint(paint12);
//        boolean boolean14 = day2.equals((java.lang.Object) categoryPlot5);
//        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
//        java.awt.Font font19 = null;
//        categoryAxis17.setTickLabelFont((java.lang.Comparable) (byte) -1, font19);
//        java.lang.String str21 = categoryAxis17.getLabelToolTip();
//        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D24 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
//        double double26 = numberAxis22.valueToJava2D((double) 10, rectangle2D24, rectangleEdge25);
//        java.awt.Graphics2D graphics2D27 = null;
//        org.jfree.chart.axis.AxisState axisState28 = null;
//        java.awt.geom.Rectangle2D rectangle2D29 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
//        java.util.List list31 = numberAxis22.refreshTicks(graphics2D27, axisState28, rectangle2D29, rectangleEdge30);
//        numberAxis22.setLabel("RectangleAnchor.TOP_LEFT");
//        numberAxis22.zoomRange((double) (-1L), (double) 1);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis17, (org.jfree.chart.axis.ValueAxis) numberAxis22, categoryItemRenderer37);
//        int int39 = categoryPlot5.getDomainAxisIndex(categoryAxis17);
//        org.jfree.chart.axis.AxisLocation axisLocation40 = categoryPlot5.getRangeAxisLocation();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNull(datasetGroup11);
//        org.junit.Assert.assertNotNull(paint12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNull(str21);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
//        org.junit.Assert.assertNotNull(list31);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
//        org.junit.Assert.assertNotNull(axisLocation40);
//    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeMinimumSize((double) 11, false);
        numberAxis0.setAutoRangeStickyZero(true);
        double double6 = numberAxis0.getLabelAngle();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) 1, (double) 11, (double) 0L);
        numberAxis0.setTickLabelInsets(rectangleInsets11);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand13 = numberAxis0.getMarkerBand();
        numberAxis0.setTickMarkInsideLength((float) 43629L);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(markerAxisBand13);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis0, jFreeChart1);
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color5, stroke6);
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker7.setOutlineStroke(stroke8);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType10 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker7.setLabelOffsetType(lengthAdjustmentType10);
        boolean boolean12 = xYPlot3.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker7);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = xYPlot3.getFixedLegendItems();
        boolean boolean14 = dateAxis0.hasListener((java.util.EventListener) xYPlot3);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        categoryPlot19.setDomainAxis((int) 'a', categoryAxis21);
        categoryPlot19.clearAnnotations();
        boolean boolean24 = categoryPlot19.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace25 = categoryPlot19.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot19.setInsets(rectangleInsets26);
        categoryPlot19.setWeight((int) (short) 1);
        java.awt.Color color31 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke32 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color31, stroke32);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = valueMarker33.getLabelAnchor();
        boolean boolean35 = categoryPlot19.equals((java.lang.Object) rectangleAnchor34);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot19.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        try {
            org.jfree.chart.axis.AxisState axisState38 = dateAxis0.draw(graphics2D15, 0.0d, rectangle2D17, rectangle2D18, rectangleEdge36, plotRenderingInfo37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(lengthAdjustmentType10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(legendItemCollection13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(axisSpace25);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(rectangleAnchor34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(rectangleEdge36);
    }

//    @Test
//    public void test267() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test267");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        long long3 = day2.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate5);
//        java.util.Calendar calendar7 = null;
//        try {
//            day6.peg(calendar7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate5);
//    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        int int3 = objectList1.indexOf((java.lang.Object) 100);
        java.lang.Object obj4 = objectList1.clone();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        int int7 = color6.getAlpha();
        float[] floatArray12 = new float[] { '4', (byte) -1, 8, 0L };
        float[] floatArray13 = color6.getColorComponents(floatArray12);
        int int14 = color6.getGreen();
        try {
            objectList1.set(2, (java.lang.Object) int14);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 255 + "'", int7 == 255);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 128 + "'", int14 == 128);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("SortOrder.ASCENDING");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        float float6 = categoryPlot0.getBackgroundAlpha();
        categoryPlot0.setRangeCrosshairValue((double) 8, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = null;
        try {
            categoryPlot0.setOrientation(plotOrientation11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        try {
            java.awt.Color color1 = java.awt.Color.decode("RectangleAnchor.TOP_LEFT");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"RectangleAnchor.TOP_LEFT\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = numberAxis1.valueToJava2D((double) 10, rectangle2D3, rectangleEdge4);
        java.awt.Paint paint6 = numberAxis1.getTickMarkPaint();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, valueAxis7, xYItemRenderer8);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation10 = null;
        try {
            xYPlot9.addAnnotation(xYAnnotation10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        try {
            java.awt.Color color1 = java.awt.Color.decode("TextAnchor.CENTER");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"TextAnchor.CENTER\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker9.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = valueMarker9.getOutlineStroke();
        boolean boolean13 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        java.awt.Paint paint14 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace15, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot18.setDomainAxis((int) 'a', categoryAxis20);
        categoryPlot18.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        categoryPlot18.setDataset(0, categoryDataset24);
        java.awt.Paint paint26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot18.setNoDataMessagePaint(paint26);
        java.awt.Paint paint28 = categoryPlot18.getOutlinePaint();
        org.jfree.chart.util.SortOrder sortOrder29 = categoryPlot18.getColumnRenderingOrder();
        java.lang.String str30 = sortOrder29.toString();
        categoryPlot0.setRowRenderingOrder(sortOrder29);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(sortOrder29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "SortOrder.ASCENDING" + "'", str30.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker3.setOutlineStroke(stroke4);
        org.jfree.chart.text.TextAnchor textAnchor6 = valueMarker3.getLabelTextAnchor();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = numberAxis7.valueToJava2D((double) 10, rectangle2D9, rectangleEdge10);
        org.jfree.data.Range range12 = numberAxis7.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = numberAxis13.valueToJava2D((double) 10, rectangle2D15, rectangleEdge16);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = numberAxis18.valueToJava2D((double) 10, rectangle2D20, rectangleEdge21);
        org.jfree.data.Range range23 = numberAxis18.getDefaultAutoRange();
        numberAxis13.setRange(range23);
        numberAxis7.setDefaultAutoRange(range23);
        java.awt.Shape shape26 = numberAxis7.getDownArrow();
        numberAxis7.setInverted(false);
        boolean boolean29 = textAnchor6.equals((java.lang.Object) numberAxis7);
        boolean boolean30 = numberAxis7.getAutoRangeStickyZero();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.mapDatasetToDomainAxis((int) (byte) 100, 1);
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 2, dataset5);
        xYPlot0.datasetChanged(datasetChangeEvent6);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation8 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeMinimumSize((double) 11, false);
        numberAxis0.setAutoRangeStickyZero(true);
        double double6 = numberAxis0.getLabelAngle();
        org.jfree.chart.plot.Plot plot7 = numberAxis0.getPlot();
        numberAxis0.setVerticalTickLabels(true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(plot7);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        xYPlot0.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis5.getTickMarkPaint();
        xYPlot0.setDomainTickBandPaint(paint10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color15, stroke16);
        boolean boolean18 = axisLocation13.equals((java.lang.Object) valueMarker17);
        float float19 = valueMarker17.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = valueMarker17.getLabelAnchor();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean23 = layer21.equals((java.lang.Object) dateRange22);
        java.lang.String str24 = layer21.toString();
        xYPlot0.addDomainMarker((int) (short) 100, (org.jfree.chart.plot.Marker) valueMarker17, layer21);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        numberAxis26.setAutoRangeMinimumSize((double) 11, false);
        numberAxis26.setAutoRangeStickyZero(true);
        double double32 = numberAxis26.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        double double37 = numberAxis33.valueToJava2D((double) 10, rectangle2D35, rectangleEdge36);
        org.jfree.data.Range range38 = numberAxis33.getDefaultAutoRange();
        numberAxis26.setRange(range38, true, true);
        java.awt.Color color42 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis26.setTickMarkPaint((java.awt.Paint) color42);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = null;
        double double48 = numberAxis44.valueToJava2D((double) 10, rectangle2D46, rectangleEdge47);
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = null;
        double double53 = numberAxis49.valueToJava2D((double) 10, rectangle2D51, rectangleEdge52);
        org.jfree.data.Range range54 = numberAxis49.getDefaultAutoRange();
        numberAxis44.setRange(range54);
        boolean boolean56 = color42.equals((java.lang.Object) numberAxis44);
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color42);
        org.jfree.chart.plot.Plot plot58 = xYPlot0.getRootPlot();
        java.awt.Color color59 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = null;
        categoryPlot60.setDomainAxis((int) 'a', categoryAxis62);
        categoryPlot60.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset66 = null;
        categoryPlot60.setDataset(0, categoryDataset66);
        java.awt.Paint paint68 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot60.setNoDataMessagePaint(paint68);
        java.awt.Paint paint70 = categoryPlot60.getOutlinePaint();
        java.awt.Color color71 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.awt.image.ColorModel colorModel72 = null;
        java.awt.Rectangle rectangle73 = null;
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        java.awt.geom.AffineTransform affineTransform75 = null;
        java.awt.RenderingHints renderingHints76 = null;
        java.awt.PaintContext paintContext77 = color71.createContext(colorModel72, rectangle73, rectangle2D74, affineTransform75, renderingHints76);
        java.awt.Paint[] paintArray78 = new java.awt.Paint[] { color59, paint70, color71 };
        java.awt.Paint[] paintArray79 = null;
        java.awt.Paint[] paintArray80 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray81 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray82 = null;
        java.awt.Shape[] shapeArray83 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier84 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray78, paintArray79, paintArray80, strokeArray81, strokeArray82, shapeArray83);
        java.awt.Paint paint85 = defaultDrawingSupplier84.getNextOutlinePaint();
        java.awt.Paint paint86 = defaultDrawingSupplier84.getNextPaint();
        plot58.setBackgroundPaint(paint86);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Layer.FOREGROUND" + "'", str24.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(plot58);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(paint70);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertNotNull(paintContext77);
        org.junit.Assert.assertNotNull(paintArray78);
        org.junit.Assert.assertNotNull(paintArray80);
        org.junit.Assert.assertNotNull(strokeArray81);
        org.junit.Assert.assertNotNull(shapeArray83);
        org.junit.Assert.assertNotNull(paint85);
        org.junit.Assert.assertNotNull(paint86);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis5.zoomRange((double) 0L, (double) 3);
        boolean boolean14 = numberAxis5.isNegativeArrowVisible();
        xYPlot0.setDomainAxis(255, (org.jfree.chart.axis.ValueAxis) numberAxis5, false);
        xYPlot0.clearRangeMarkers();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker3.setOutlineStroke(stroke4);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot6.setDomainAxis((int) 'a', categoryAxis8);
        categoryPlot6.clearAnnotations();
        boolean boolean11 = categoryPlot6.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace12 = categoryPlot6.getFixedDomainAxisSpace();
        boolean boolean13 = categoryPlot6.isRangeZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot6.getRendererForDataset(categoryDataset14);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font20 = null;
        categoryAxis18.setTickLabelFont((java.lang.Comparable) (byte) -1, font20);
        java.lang.String str22 = categoryAxis18.getLabelToolTip();
        categoryPlot6.setDomainAxis(6, categoryAxis18, false);
        valueMarker3.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot6);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(axisSpace12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNull(str22);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        java.util.List list9 = numberAxis0.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge8);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        double double16 = rectangleInsets14.calculateLeftInset((double) (-1));
        numberAxis0.setTickLabelInsets(rectangleInsets14);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand18 = null;
        numberAxis0.setMarkerBand(markerAxisBand18);
        numberAxis0.setAutoRangeIncludesZero(true);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 32.0d + "'", double16 == 32.0d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot0.setInsets(rectangleInsets7);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot0.getDomainAxisEdge((int) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeMinimumSize((double) 11, false);
        numberAxis12.setAutoRangeStickyZero(true);
        double double18 = numberAxis12.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = numberAxis19.valueToJava2D((double) 10, rectangle2D21, rectangleEdge22);
        org.jfree.data.Range range24 = numberAxis19.getDefaultAutoRange();
        numberAxis12.setRange(range24, true, true);
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis12.setTickMarkPaint((java.awt.Paint) color28);
        categoryPlot0.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis12);
        org.jfree.chart.plot.Plot plot31 = categoryPlot0.getRootPlot();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent32 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent32);
        boolean boolean34 = categoryPlot0.isRangeZoomable();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(plot31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font4 = null;
        categoryAxis2.setTickLabelFont((java.lang.Comparable) (byte) -1, font4);
        java.lang.String str6 = categoryAxis2.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = numberAxis7.valueToJava2D((double) 10, rectangle2D9, rectangleEdge10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.AxisState axisState13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        java.util.List list16 = numberAxis7.refreshTicks(graphics2D12, axisState13, rectangle2D14, rectangleEdge15);
        numberAxis7.setLabel("RectangleAnchor.TOP_LEFT");
        numberAxis7.zoomRange((double) (-1L), (double) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer22);
        try {
            numberAxis7.setRange((double) '4', (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (52.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(list16);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        categoryPlot1.setDomainAxis((int) 'a', categoryAxis3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = categoryPlot1.getDrawingSupplier();
        categoryPlot0.setDrawingSupplier(drawingSupplier5);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent7);
        org.junit.Assert.assertNotNull(drawingSupplier5);
    }

//    @Test
//    public void test286() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test286");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        long long3 = day2.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
//        categoryPlot5.setDomainAxis((int) 'a', categoryAxis7);
//        categoryPlot5.setBackgroundImageAlignment((int) (short) 10);
//        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot5.getDatasetGroup();
//        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
//        categoryPlot5.setNoDataMessagePaint(paint12);
//        boolean boolean14 = day2.equals((java.lang.Object) categoryPlot5);
//        java.awt.Stroke stroke15 = categoryPlot5.getOutlineStroke();
//        float float16 = categoryPlot5.getForegroundAlpha();
//        org.jfree.chart.plot.CategoryMarker categoryMarker17 = null;
//        try {
//            categoryPlot5.addDomainMarker(categoryMarker17);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNull(datasetGroup11);
//        org.junit.Assert.assertNotNull(paint12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(stroke15);
//        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 1.0f + "'", float16 == 1.0f);
//    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        boolean boolean7 = categoryPlot0.isRangeZoomable();
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = categoryPlot0.getOrientation();
        java.awt.Stroke stroke12 = categoryPlot0.getRangeCrosshairStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        categoryPlot0.setRenderer(categoryItemRenderer13, false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double7 = rectangleInsets5.calculateRightInset(11.0d);
        categoryPlot0.setInsets(rectangleInsets5);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot9.setDomainAxis((int) 'a', categoryAxis11);
        categoryPlot9.setBackgroundImageAlignment((int) (short) 10);
        float float15 = categoryPlot9.getBackgroundAlpha();
        categoryPlot9.clearRangeAxes();
        boolean boolean17 = rectangleInsets5.equals((java.lang.Object) categoryPlot9);
        boolean boolean18 = categoryPlot9.isRangeZoomable();
        int int19 = categoryPlot9.getRangeAxisCount();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setTickMarksVisible(false);
        categoryAxis1.setLabel("");
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        categoryPlot7.setDomainAxis((int) 'a', categoryAxis9);
        categoryPlot7.clearAnnotations();
        boolean boolean12 = categoryPlot7.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace13 = categoryPlot7.getFixedDomainAxisSpace();
        boolean boolean14 = categoryPlot7.isRangeZoomable();
        categoryPlot7.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot7.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        categoryPlot7.setDataset(categoryDataset18);
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace23 = categoryAxis1.reserveSpace(graphics2D6, (org.jfree.chart.plot.Plot) categoryPlot7, rectangle2D20, rectangleEdge21, axisSpace22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(axisSpace13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(axisLocation17);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeMinimumSize((double) 11, false);
        numberAxis0.setAutoRangeStickyZero(true);
        double double6 = numberAxis0.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = numberAxis7.valueToJava2D((double) 10, rectangle2D9, rectangleEdge10);
        org.jfree.data.Range range12 = numberAxis7.getDefaultAutoRange();
        numberAxis0.setRange(range12, true, true);
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis0.setTickMarkPaint((java.awt.Paint) color16);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        double double24 = rectangleInsets22.calculateLeftInset((double) (-1));
        numberAxis0.setLabelInsets(rectangleInsets22);
        numberAxis0.setVerticalTickLabels(false);
        try {
            numberAxis0.zoomRange(0.0d, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (0.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 32.0d + "'", double24 == 32.0d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        xYPlot0.clearDomainMarkers();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        xYPlot10.setRangeAxisLocation((int) (short) 100, axisLocation12);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = numberAxis15.valueToJava2D((double) 10, rectangle2D17, rectangleEdge18);
        org.jfree.data.Range range20 = numberAxis15.getDefaultAutoRange();
        numberAxis15.zoomRange((double) 0L, (double) 3);
        boolean boolean24 = numberAxis15.isNegativeArrowVisible();
        xYPlot10.setDomainAxis(255, (org.jfree.chart.axis.ValueAxis) numberAxis15, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder27 = xYPlot10.getDatasetRenderingOrder();
        java.awt.geom.Point2D point2D28 = xYPlot10.getQuadrantOrigin();
        org.jfree.chart.plot.PlotState plotState29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        try {
            xYPlot0.draw(graphics2D8, rectangle2D9, point2D28, plotState29, plotRenderingInfo30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder27);
        org.junit.Assert.assertNotNull(point2D28);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.awt.Color color1 = java.awt.Color.getColor("PlotOrientation.HORIZONTAL");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        boolean boolean2 = color0.equals((java.lang.Object) "Category Plot");
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.util.List list1 = xYPlot0.getAnnotations();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainZeroBaselineStroke(stroke2);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = null;
        xYPlot0.rendererChanged(rendererChangeEvent4);
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot0.getRangeAxis();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(valueAxis6);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot0.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot0.getRenderer();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNull(categoryItemRenderer14);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundAlpha((float) 4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        int int4 = categoryPlot0.getIndexOf(categoryItemRenderer3);
        int int5 = categoryPlot0.getWeight();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        double double5 = numberAxis1.valueToJava2D((double) 10, rectangle2D3, rectangleEdge4);
        org.jfree.data.Range range6 = numberAxis1.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = numberAxis7.valueToJava2D((double) 10, rectangle2D9, rectangleEdge10);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = numberAxis12.valueToJava2D((double) 10, rectangle2D14, rectangleEdge15);
        org.jfree.data.Range range17 = numberAxis12.getDefaultAutoRange();
        numberAxis7.setRange(range17);
        numberAxis1.setDefaultAutoRange(range17);
        java.awt.Shape shape20 = numberAxis1.getDownArrow();
        java.awt.Color color21 = java.awt.Color.orange;
        numberAxis1.setAxisLinePaint((java.awt.Paint) color21);
        org.jfree.chart.plot.IntervalMarker intervalMarker25 = new org.jfree.chart.plot.IntervalMarker(10.0d, (double) ' ');
        java.awt.Stroke stroke26 = intervalMarker25.getStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        categoryPlot27.setDomainAxis((int) 'a', categoryAxis29);
        categoryPlot27.setBackgroundImageAlignment((int) (short) 10);
        float float33 = categoryPlot27.getBackgroundAlpha();
        java.awt.Paint paint34 = categoryPlot27.getNoDataMessagePaint();
        org.jfree.chart.plot.IntervalMarker intervalMarker37 = new org.jfree.chart.plot.IntervalMarker(10.0d, (double) ' ');
        java.awt.Stroke stroke38 = intervalMarker37.getStroke();
        try {
            org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker((double) 98, (java.awt.Paint) color21, stroke26, paint34, stroke38, (float) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 1.0f + "'", float33 == 1.0f);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(stroke38);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        boolean boolean7 = xYPlot0.isDomainCrosshairVisible();
        boolean boolean8 = xYPlot0.isSubplot();
        java.awt.Stroke stroke9 = xYPlot0.getDomainCrosshairStroke();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        boolean boolean7 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot0.getRangeAxis(5);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(valueAxis9);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis0.setRangeWithMargins(range10, true, true);
        java.text.NumberFormat numberFormat14 = numberAxis0.getNumberFormatOverride();
        java.lang.String str15 = numberAxis0.getLabelURL();
        numberAxis0.centerRange(0.0d);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        numberAxis18.setAutoRangeMinimumSize((double) 11, false);
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color23, stroke24);
        numberAxis18.setLabelPaint((java.awt.Paint) color23);
        numberAxis18.setPositiveArrowVisible(true);
        org.jfree.chart.plot.Plot plot29 = numberAxis18.getPlot();
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        double double34 = numberAxis30.valueToJava2D((double) 10, rectangle2D32, rectangleEdge33);
        org.jfree.data.Range range35 = numberAxis30.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = null;
        double double40 = numberAxis36.valueToJava2D((double) 10, rectangle2D38, rectangleEdge39);
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = numberAxis41.valueToJava2D((double) 10, rectangle2D43, rectangleEdge44);
        org.jfree.data.Range range46 = numberAxis41.getDefaultAutoRange();
        numberAxis36.setRange(range46);
        numberAxis30.setDefaultAutoRange(range46);
        java.awt.Shape shape49 = numberAxis30.getDownArrow();
        numberAxis18.setDownArrow(shape49);
        numberAxis0.setUpArrow(shape49);
        java.awt.Paint paint52 = numberAxis0.getTickLabelPaint();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNull(numberFormat14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(plot29);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNotNull(paint52);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color2, stroke3);
        boolean boolean5 = axisLocation0.equals((java.lang.Object) valueMarker4);
        valueMarker4.setLabel("TextAnchor.CENTER");
        boolean boolean9 = valueMarker4.equals((java.lang.Object) 0.0d);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

//    @Test
//    public void test304() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test304");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        long long3 = day2.getFirstMillisecond();
//        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
//        numberAxis4.setAutoRangeMinimumSize((double) 11, false);
//        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_GREEN;
//        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color9, stroke10);
//        numberAxis4.setLabelPaint((java.awt.Paint) color9);
//        numberAxis4.setPositiveArrowVisible(true);
//        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = numberAxis4.getTickUnit();
//        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D18 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
//        double double20 = numberAxis16.valueToJava2D((double) 10, rectangle2D18, rectangleEdge19);
//        org.jfree.data.Range range21 = numberAxis16.getDefaultAutoRange();
//        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D24 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
//        double double26 = numberAxis22.valueToJava2D((double) 10, rectangle2D24, rectangleEdge25);
//        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D29 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
//        double double31 = numberAxis27.valueToJava2D((double) 10, rectangle2D29, rectangleEdge30);
//        org.jfree.data.Range range32 = numberAxis27.getDefaultAutoRange();
//        numberAxis22.setRange(range32);
//        numberAxis16.setDefaultAutoRange(range32);
//        numberAxis16.setAutoRangeMinimumSize((double) 1, true);
//        org.jfree.data.Range range38 = numberAxis16.getDefaultAutoRange();
//        numberAxis4.setRangeWithMargins(range38, true, false);
//        boolean boolean42 = day2.equals((java.lang.Object) numberAxis4);
//        long long43 = day2.getFirstMillisecond();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(color9);
//        org.junit.Assert.assertNotNull(stroke10);
//        org.junit.Assert.assertNotNull(numberTickUnit15);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
//        org.junit.Assert.assertNotNull(range21);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
//        org.junit.Assert.assertNotNull(range32);
//        org.junit.Assert.assertNotNull(range38);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1560409200000L + "'", long43 == 1560409200000L);
//    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.data.Range range5 = numberAxis0.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis6.valueToJava2D((double) 10, rectangle2D8, rectangleEdge9);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = numberAxis11.valueToJava2D((double) 10, rectangle2D13, rectangleEdge14);
        org.jfree.data.Range range16 = numberAxis11.getDefaultAutoRange();
        numberAxis6.setRange(range16);
        numberAxis0.setDefaultAutoRange(range16);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = null;
        numberAxis0.setStandardTickUnits(tickUnitSource19);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = numberAxis21.valueToJava2D((double) 10, rectangle2D23, rectangleEdge24);
        org.jfree.data.Range range26 = numberAxis21.getDefaultAutoRange();
        numberAxis0.setRangeWithMargins(range26);
        java.awt.Paint paint28 = numberAxis0.getTickMarkPaint();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        boolean boolean5 = numberAxis0.getAutoRangeStickyZero();
        java.lang.Object obj6 = numberAxis0.clone();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightInset(11.0d);
        java.lang.String str3 = rectangleInsets0.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str3.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker9.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = valueMarker9.getOutlineStroke();
        boolean boolean13 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot0.setOrientation(plotOrientation14);
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = categoryPlot0.getOrientation();
        categoryPlot0.mapDatasetToRangeAxis(3, 100);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(plotOrientation16);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, (double) 1, (double) 11, (double) 0L);
        double double6 = rectangleInsets4.calculateRightInset((double) 1560409200000L);
        double double7 = rectangleInsets4.getLeft();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryAxis1.equals(obj2);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(false);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot11.setDomainAxis((int) 'a', categoryAxis13);
        categoryPlot11.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        categoryPlot11.setDataset(0, categoryDataset17);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot11.setNoDataMessagePaint(paint19);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot11.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        categoryPlot11.rendererChanged(rendererChangeEvent23);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection27 = categoryPlot11.getRangeMarkers((int) (byte) -1, layer26);
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        org.jfree.chart.axis.AxisSpace axisSpace30 = null;
        org.jfree.chart.axis.AxisSpace axisSpace31 = categoryAxis1.reserveSpace(graphics2D10, (org.jfree.chart.plot.Plot) categoryPlot11, rectangle2D28, rectangleEdge29, axisSpace30);
        java.awt.Color color34 = java.awt.Color.getColor("Category Plot", 0);
        categoryPlot11.setBackgroundPaint((java.awt.Paint) color34);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertNotNull(axisSpace31);
        org.junit.Assert.assertNotNull(color34);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeMinimumSize((double) 11, false);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color5, stroke6);
        numberAxis0.setLabelPaint((java.awt.Paint) color5);
        java.awt.Color color9 = java.awt.Color.yellow;
        numberAxis0.setAxisLinePaint((java.awt.Paint) color9);
        numberAxis0.setLabelAngle(100.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis5.zoomRange((double) 0L, (double) 3);
        boolean boolean14 = numberAxis5.isNegativeArrowVisible();
        xYPlot0.setDomainAxis(255, (org.jfree.chart.axis.ValueAxis) numberAxis5, false);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis18 = xYPlot0.getDomainAxisForDataset((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 97 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

//    @Test
//    public void test315() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test315");
//        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
//        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
//        categoryPlot0.clearAnnotations();
//        boolean boolean5 = categoryPlot0.isOutlineVisible();
//        categoryPlot0.setRangeCrosshairValue((double) 1L);
//        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date9, timeZone10);
//        long long12 = day11.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate13 = day11.getSerialDate();
//        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
//        categoryPlot14.setDomainAxis((int) 'a', categoryAxis16);
//        categoryPlot14.setBackgroundImageAlignment((int) (short) 10);
//        org.jfree.data.general.DatasetGroup datasetGroup20 = categoryPlot14.getDatasetGroup();
//        java.awt.Paint paint21 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
//        categoryPlot14.setNoDataMessagePaint(paint21);
//        boolean boolean23 = day11.equals((java.lang.Object) categoryPlot14);
//        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D26 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
//        double double28 = numberAxis24.valueToJava2D((double) 10, rectangle2D26, rectangleEdge27);
//        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D31 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge32 = null;
//        double double33 = numberAxis29.valueToJava2D((double) 10, rectangle2D31, rectangleEdge32);
//        org.jfree.data.Range range34 = numberAxis29.getDefaultAutoRange();
//        numberAxis24.setRange(range34);
//        int int36 = categoryPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis24);
//        numberAxis24.configure();
//        categoryPlot0.setRangeAxis((int) (short) 0, (org.jfree.chart.axis.ValueAxis) numberAxis24);
//        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
//        categoryPlot39.setDomainAxis((int) 'a', categoryAxis41);
//        categoryPlot39.clearAnnotations();
//        org.jfree.data.category.CategoryDataset categoryDataset45 = null;
//        categoryPlot39.setDataset(0, categoryDataset45);
//        java.awt.Paint paint47 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
//        categoryPlot39.setNoDataMessagePaint(paint47);
//        org.jfree.chart.util.RectangleEdge rectangleEdge50 = categoryPlot39.getDomainAxisEdge((int) (byte) 10);
//        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent51 = null;
//        categoryPlot39.rendererChanged(rendererChangeEvent51);
//        org.jfree.chart.util.Layer layer54 = org.jfree.chart.util.Layer.FOREGROUND;
//        java.util.Collection collection55 = categoryPlot39.getRangeMarkers((int) (byte) -1, layer54);
//        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis("");
//        java.lang.Object obj58 = null;
//        boolean boolean59 = categoryAxis57.equals(obj58);
//        categoryAxis57.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
//        categoryAxis57.clearCategoryLabelToolTips();
//        categoryAxis57.setTickLabelsVisible(false);
//        java.awt.Graphics2D graphics2D66 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot67 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis69 = null;
//        categoryPlot67.setDomainAxis((int) 'a', categoryAxis69);
//        categoryPlot67.clearAnnotations();
//        org.jfree.data.category.CategoryDataset categoryDataset73 = null;
//        categoryPlot67.setDataset(0, categoryDataset73);
//        java.awt.Paint paint75 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
//        categoryPlot67.setNoDataMessagePaint(paint75);
//        org.jfree.chart.util.RectangleEdge rectangleEdge78 = categoryPlot67.getDomainAxisEdge((int) (byte) 10);
//        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent79 = null;
//        categoryPlot67.rendererChanged(rendererChangeEvent79);
//        org.jfree.chart.util.Layer layer82 = org.jfree.chart.util.Layer.FOREGROUND;
//        java.util.Collection collection83 = categoryPlot67.getRangeMarkers((int) (byte) -1, layer82);
//        java.awt.geom.Rectangle2D rectangle2D84 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge85 = null;
//        org.jfree.chart.axis.AxisSpace axisSpace86 = null;
//        org.jfree.chart.axis.AxisSpace axisSpace87 = categoryAxis57.reserveSpace(graphics2D66, (org.jfree.chart.plot.Plot) categoryPlot67, rectangle2D84, rectangleEdge85, axisSpace86);
//        categoryPlot39.setFixedRangeAxisSpace(axisSpace87, false);
//        categoryPlot0.setFixedRangeAxisSpace(axisSpace87, false);
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(timeZone10);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560409200000L + "'", long12 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate13);
//        org.junit.Assert.assertNull(datasetGroup20);
//        org.junit.Assert.assertNotNull(paint21);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
//        org.junit.Assert.assertNotNull(range34);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
//        org.junit.Assert.assertNotNull(paint47);
//        org.junit.Assert.assertNotNull(rectangleEdge50);
//        org.junit.Assert.assertNotNull(layer54);
//        org.junit.Assert.assertNull(collection55);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertNotNull(paint75);
//        org.junit.Assert.assertNotNull(rectangleEdge78);
//        org.junit.Assert.assertNotNull(layer82);
//        org.junit.Assert.assertNull(collection83);
//        org.junit.Assert.assertNotNull(axisSpace87);
//    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font3 = null;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) (byte) -1, font3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        int int9 = xYPlot8.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot8.getRangeAxisEdge();
        try {
            java.util.List list11 = categoryAxis1.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        categoryPlot1.setDomainAxis((int) 'a', categoryAxis3);
        categoryPlot1.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        categoryPlot1.setDataset(0, categoryDataset7);
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot1.setNoDataMessagePaint(paint9);
        java.awt.Paint paint11 = categoryPlot1.getOutlinePaint();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = color12.createContext(colorModel13, rectangle14, rectangle2D15, affineTransform16, renderingHints17);
        java.awt.Paint[] paintArray19 = new java.awt.Paint[] { color0, paint11, color12 };
        java.awt.Paint[] paintArray20 = null;
        java.awt.Paint[] paintArray21 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray22 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray23 = null;
        java.awt.Shape[] shapeArray24 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier25 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray19, paintArray20, paintArray21, strokeArray22, strokeArray23, shapeArray24);
        java.awt.Paint paint26 = defaultDrawingSupplier25.getNextOutlinePaint();
        java.awt.Stroke stroke27 = defaultDrawingSupplier25.getNextStroke();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNotNull(paintArray19);
        org.junit.Assert.assertNotNull(paintArray21);
        org.junit.Assert.assertNotNull(strokeArray22);
        org.junit.Assert.assertNotNull(shapeArray24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis0.setRangeWithMargins(range10, true, true);
        java.text.NumberFormat numberFormat14 = numberAxis0.getNumberFormatOverride();
        java.lang.String str15 = numberAxis0.getLabelURL();
        numberAxis0.centerRange(0.0d);
        numberAxis0.setLabel("AxisLocation.BOTTOM_OR_LEFT");
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNull(numberFormat14);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font4 = null;
        categoryAxis2.setTickLabelFont((java.lang.Comparable) (byte) -1, font4);
        java.lang.String str6 = categoryAxis2.getLabelToolTip();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = numberAxis7.valueToJava2D((double) 10, rectangle2D9, rectangleEdge10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.AxisState axisState13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        java.util.List list16 = numberAxis7.refreshTicks(graphics2D12, axisState13, rectangle2D14, rectangleEdge15);
        numberAxis7.setLabel("RectangleAnchor.TOP_LEFT");
        numberAxis7.zoomRange((double) (-1L), (double) 1);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis7, categoryItemRenderer22);
        categoryAxis2.setMaximumCategoryLabelWidthRatio((float) 5);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(list16);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis0.setRange(range10);
        numberAxis0.setRangeAboutValue((double) (short) -1, 0.0d);
        numberAxis0.setTickLabelsVisible(false);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        int int18 = color17.getRGB();
        numberAxis0.setAxisLinePaint((java.awt.Paint) color17);
        org.jfree.data.Range range20 = numberAxis0.getRange();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-128) + "'", int18 == (-128));
        org.junit.Assert.assertNotNull(range20);
    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test321");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        long long3 = day2.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
//        categoryPlot5.setDomainAxis((int) 'a', categoryAxis7);
//        categoryPlot5.setBackgroundImageAlignment((int) (short) 10);
//        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot5.getDatasetGroup();
//        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
//        categoryPlot5.setNoDataMessagePaint(paint12);
//        boolean boolean14 = day2.equals((java.lang.Object) categoryPlot5);
//        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D17 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
//        double double19 = numberAxis15.valueToJava2D((double) 10, rectangle2D17, rectangleEdge18);
//        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D22 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
//        double double24 = numberAxis20.valueToJava2D((double) 10, rectangle2D22, rectangleEdge23);
//        org.jfree.data.Range range25 = numberAxis20.getDefaultAutoRange();
//        numberAxis15.setRange(range25);
//        int int27 = categoryPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis15);
//        try {
//            categoryPlot5.zoom((double) 10.0f);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNull(datasetGroup11);
//        org.junit.Assert.assertNotNull(paint12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
//        org.junit.Assert.assertNotNull(range25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        categoryPlot7.setDomainAxis((int) 'a', categoryAxis9);
        categoryPlot7.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        categoryPlot7.setDataset(0, categoryDataset13);
        java.awt.Paint paint15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot7.setNoDataMessagePaint(paint15);
        java.awt.Paint paint17 = categoryPlot7.getOutlinePaint();
        int int18 = categoryPlot7.getDomainAxisCount();
        java.lang.Class<?> wildcardClass19 = categoryPlot7.getClass();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        categoryPlot21.setDomainAxis((int) 'a', categoryAxis23);
        categoryPlot21.clearAnnotations();
        boolean boolean26 = categoryPlot21.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace27 = categoryPlot21.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot21.setInsets(rectangleInsets28);
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation31 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation30, plotOrientation31);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor33 = org.jfree.chart.axis.CategoryAnchor.END;
        boolean boolean34 = axisLocation30.equals((java.lang.Object) categoryAnchor33);
        categoryPlot21.setRangeAxisLocation(axisLocation30, false);
        categoryPlot7.setRangeAxisLocation((int) (short) 10, axisLocation30, false);
        xYPlot0.setRangeAxisLocation(axisLocation30, true);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation41 = null;
        try {
            boolean boolean42 = xYPlot0.removeAnnotation(xYAnnotation41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 98 + "'", int18 == 98);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(axisSpace27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(plotOrientation31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(categoryAnchor33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker3.setOutlineStroke(stroke4);
        org.jfree.chart.text.TextAnchor textAnchor6 = valueMarker3.getLabelTextAnchor();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = numberAxis7.valueToJava2D((double) 10, rectangle2D9, rectangleEdge10);
        org.jfree.data.Range range12 = numberAxis7.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = numberAxis13.valueToJava2D((double) 10, rectangle2D15, rectangleEdge16);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = numberAxis18.valueToJava2D((double) 10, rectangle2D20, rectangleEdge21);
        org.jfree.data.Range range23 = numberAxis18.getDefaultAutoRange();
        numberAxis13.setRange(range23);
        numberAxis7.setDefaultAutoRange(range23);
        java.awt.Shape shape26 = numberAxis7.getDownArrow();
        numberAxis7.setInverted(false);
        boolean boolean29 = textAnchor6.equals((java.lang.Object) numberAxis7);
        boolean boolean30 = numberAxis7.isPositiveArrowVisible();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Color color1 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent10);
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        boolean boolean13 = categoryPlot0.equals((java.lang.Object) textAnchor12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot0.getDomainAxisLocation(255);
        java.awt.Stroke stroke16 = categoryPlot0.getDomainGridlineStroke();
        double double17 = categoryPlot0.getAnchorValue();
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot0.setInsets(rectangleInsets7);
        categoryPlot0.setWeight((int) (short) 1);
        double double11 = categoryPlot0.getRangeCrosshairValue();
        boolean boolean12 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = categoryPlot0.getDatasetRenderingOrder();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test327");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        long long3 = day2.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
//        categoryPlot5.setDomainAxis((int) 'a', categoryAxis7);
//        categoryPlot5.setBackgroundImageAlignment((int) (short) 10);
//        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot5.getDatasetGroup();
//        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
//        categoryPlot5.setNoDataMessagePaint(paint12);
//        boolean boolean14 = day2.equals((java.lang.Object) categoryPlot5);
//        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D17 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
//        double double19 = numberAxis15.valueToJava2D((double) 10, rectangle2D17, rectangleEdge18);
//        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D22 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
//        double double24 = numberAxis20.valueToJava2D((double) 10, rectangle2D22, rectangleEdge23);
//        org.jfree.data.Range range25 = numberAxis20.getDefaultAutoRange();
//        numberAxis15.setRange(range25);
//        int int27 = categoryPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis15);
//        numberAxis15.configure();
//        numberAxis15.centerRange((double) (byte) 100);
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNull(datasetGroup11);
//        org.junit.Assert.assertNotNull(paint12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
//        org.junit.Assert.assertNotNull(range25);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
//    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(10.0d, (double) ' ');
        double double3 = intervalMarker2.getStartValue();
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color5, stroke6);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = valueMarker7.getLabelAnchor();
        intervalMarker2.setLabelAnchor(rectangleAnchor8);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.0d + "'", double3 == 10.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = null;
        try {
            xYPlot0.setRangeCrosshairPaint(paint1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-48897) + "'", int1 == (-48897));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.data.Range range5 = numberAxis0.getDefaultAutoRange();
        numberAxis0.zoomRange((double) 0L, (double) 3);
        java.lang.String str9 = numberAxis0.getLabel();
        boolean boolean10 = numberAxis0.getAutoRangeStickyZero();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = numberAxis0.getLabelInsets();
        boolean boolean12 = numberAxis0.getAutoRangeStickyZero();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color2, stroke3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker4.setOutlineStroke(stroke5);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker4.setLabelOffsetType(lengthAdjustmentType7);
        boolean boolean9 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker4);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = xYPlot0.getFixedLegendItems();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot11.setDomainAxis((int) 'a', categoryAxis13);
        categoryPlot11.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        categoryPlot11.setDataset(0, categoryDataset17);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot11.setNoDataMessagePaint(paint19);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot11.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        categoryPlot11.rendererChanged(rendererChangeEvent23);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection27 = categoryPlot11.getRangeMarkers((int) (byte) -1, layer26);
        java.util.Collection collection28 = xYPlot0.getRangeMarkers(layer26);
        org.jfree.chart.axis.ValueAxis valueAxis30 = xYPlot0.getDomainAxisForDataset(0);
        java.util.List list31 = xYPlot0.getAnnotations();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent32 = null;
        xYPlot0.rendererChanged(rendererChangeEvent32);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertNull(valueAxis30);
        org.junit.Assert.assertNotNull(list31);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis0.setRange(range10);
        numberAxis0.setRangeAboutValue((double) (short) -1, 0.0d);
        numberAxis0.setTickLabelsVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = numberAxis17.valueToJava2D((double) 10, rectangle2D19, rectangleEdge20);
        org.jfree.data.Range range22 = numberAxis17.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = numberAxis23.valueToJava2D((double) 10, rectangle2D25, rectangleEdge26);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
        double double32 = numberAxis28.valueToJava2D((double) 10, rectangle2D30, rectangleEdge31);
        org.jfree.data.Range range33 = numberAxis28.getDefaultAutoRange();
        numberAxis23.setRange(range33);
        numberAxis17.setDefaultAutoRange(range33);
        java.awt.Shape shape36 = numberAxis17.getDownArrow();
        numberAxis0.setRightArrow(shape36);
        boolean boolean38 = numberAxis0.isAutoRange();
        java.awt.Paint paint39 = numberAxis0.getTickLabelPaint();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(paint39);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.data.Range range5 = numberAxis0.getDefaultAutoRange();
        numberAxis0.zoomRange((double) 0L, (double) 3);
        java.lang.String str9 = numberAxis0.getLabel();
        boolean boolean10 = numberAxis0.getAutoRangeStickyZero();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = numberAxis11.valueToJava2D((double) 10, rectangle2D13, rectangleEdge14);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = numberAxis16.valueToJava2D((double) 10, rectangle2D18, rectangleEdge19);
        org.jfree.data.Range range21 = numberAxis16.getDefaultAutoRange();
        numberAxis11.setRange(range21);
        numberAxis11.setRangeAboutValue((double) (short) -1, 0.0d);
        numberAxis11.setTickLabelsVisible(false);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
        double double32 = numberAxis28.valueToJava2D((double) 10, rectangle2D30, rectangleEdge31);
        org.jfree.data.Range range33 = numberAxis28.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = null;
        double double38 = numberAxis34.valueToJava2D((double) 10, rectangle2D36, rectangleEdge37);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = null;
        double double43 = numberAxis39.valueToJava2D((double) 10, rectangle2D41, rectangleEdge42);
        org.jfree.data.Range range44 = numberAxis39.getDefaultAutoRange();
        numberAxis34.setRange(range44);
        numberAxis28.setDefaultAutoRange(range44);
        java.awt.Shape shape47 = numberAxis28.getDownArrow();
        numberAxis11.setRightArrow(shape47);
        boolean boolean49 = numberAxis11.isAutoRange();
        org.jfree.data.Range range50 = numberAxis11.getRange();
        numberAxis0.setRangeWithMargins(range50, true, false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(range50);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color1, stroke2);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker3.setOutlineStroke(stroke4);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker3.setLabelOffsetType(lengthAdjustmentType6);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = org.jfree.chart.util.RectangleAnchor.CENTER;
        valueMarker3.setLabelAnchor(rectangleAnchor8);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        categoryPlot10.setDomainAxis((int) 'a', categoryAxis12);
        categoryPlot10.clearAnnotations();
        boolean boolean15 = categoryPlot10.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace16 = categoryPlot10.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot10.setInsets(rectangleInsets17);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation20 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation19, plotOrientation20);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor22 = org.jfree.chart.axis.CategoryAnchor.END;
        boolean boolean23 = axisLocation19.equals((java.lang.Object) categoryAnchor22);
        categoryPlot10.setRangeAxisLocation(axisLocation19, false);
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot10.setRangeAxisLocation(98, axisLocation27, true);
        boolean boolean30 = rectangleAnchor8.equals((java.lang.Object) 98);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(axisSpace16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(plotOrientation20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(categoryAnchor22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

//    @Test
//    public void test339() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test339");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        long long3 = day2.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day2.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis((int) 'a', categoryAxis7);
        categoryPlot5.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color12, stroke13);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker14.setOutlineStroke(stroke15);
        java.awt.Stroke stroke17 = valueMarker14.getOutlineStroke();
        boolean boolean18 = categoryPlot5.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker14);
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean21 = layer19.equals((java.lang.Object) dateRange20);
        java.lang.String str22 = layer19.toString();
        xYPlot0.addDomainMarker((int) '#', (org.jfree.chart.plot.Marker) valueMarker14, layer19);
        org.jfree.chart.plot.IntervalMarker intervalMarker26 = new org.jfree.chart.plot.IntervalMarker(10.0d, (double) ' ');
        intervalMarker26.setEndValue((double) 6);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker26, layer29);
        org.jfree.data.xy.XYDataset xYDataset31 = xYPlot0.getDataset();
        java.awt.Paint paint32 = xYPlot0.getRangeTickBandPaint();
        boolean boolean33 = xYPlot0.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(layer19);
        org.junit.Assert.assertNotNull(dateRange20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Layer.FOREGROUND" + "'", str22.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(xYDataset31);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        float float8 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot0.getAxisOffset();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj12 = null;
        boolean boolean13 = categoryAxis11.equals(obj12);
        categoryAxis11.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis11.clearCategoryLabelToolTips();
        categoryPlot0.setDomainAxis(categoryAxis11);
        org.jfree.chart.axis.AxisLocation axisLocation20 = null;
        categoryPlot0.setRangeAxisLocation(255, axisLocation20);
        categoryPlot0.setDomainGridlinesVisible(true);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        boolean boolean5 = numberAxis0.isAutoRange();
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        xYPlot6.setRangeAxisLocation((int) (short) 100, axisLocation8);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = numberAxis11.valueToJava2D((double) 10, rectangle2D13, rectangleEdge14);
        org.jfree.data.Range range16 = numberAxis11.getDefaultAutoRange();
        numberAxis11.zoomRange((double) 0L, (double) 3);
        boolean boolean20 = numberAxis11.isNegativeArrowVisible();
        xYPlot6.setDomainAxis(255, (org.jfree.chart.axis.ValueAxis) numberAxis11, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder23 = xYPlot6.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation25 = xYPlot6.getRangeAxisLocation(0);
        java.awt.Stroke stroke26 = xYPlot6.getRangeCrosshairStroke();
        numberAxis0.setAxisLineStroke(stroke26);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder23);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        categoryPlot7.setDomainAxis((int) 'a', categoryAxis9);
        categoryPlot7.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        categoryPlot7.setDataset(0, categoryDataset13);
        java.awt.Paint paint15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot7.setNoDataMessagePaint(paint15);
        java.awt.Paint paint17 = categoryPlot7.getOutlinePaint();
        int int18 = categoryPlot7.getDomainAxisCount();
        java.lang.Class<?> wildcardClass19 = categoryPlot7.getClass();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        categoryPlot21.setDomainAxis((int) 'a', categoryAxis23);
        categoryPlot21.clearAnnotations();
        boolean boolean26 = categoryPlot21.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace27 = categoryPlot21.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot21.setInsets(rectangleInsets28);
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation31 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation30, plotOrientation31);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor33 = org.jfree.chart.axis.CategoryAnchor.END;
        boolean boolean34 = axisLocation30.equals((java.lang.Object) categoryAnchor33);
        categoryPlot21.setRangeAxisLocation(axisLocation30, false);
        categoryPlot7.setRangeAxisLocation((int) (short) 10, axisLocation30, false);
        xYPlot0.setRangeAxisLocation(axisLocation30, true);
        double double41 = xYPlot0.getDomainCrosshairValue();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation42 = null;
        try {
            boolean boolean44 = xYPlot0.removeAnnotation(xYAnnotation42, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 98 + "'", int18 == 98);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(axisSpace27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(plotOrientation31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(categoryAnchor33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.String str3 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 1.0d);
        org.jfree.chart.plot.Plot plot4 = categoryAxis1.getPlot();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(plot4);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis0.setRange(range10);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis0.getTickUnit();
        double double13 = numberAxis0.getLabelAngle();
        numberAxis0.setAutoTickUnitSelection(false, false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker9.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = valueMarker9.getOutlineStroke();
        boolean boolean13 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        valueMarker9.setLabel("RectangleAnchor.TOP_LEFT");
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = valueMarker9.getLabelOffset();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleInsets16);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker9.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = valueMarker9.getOutlineStroke();
        boolean boolean13 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent14 = null;
        categoryPlot0.axisChanged(axisChangeEvent14);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj18 = null;
        boolean boolean19 = categoryAxis17.equals(obj18);
        categoryAxis17.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis17.clearCategoryLabelToolTips();
        categoryAxis17.setTickLabelsVisible(false);
        categoryPlot0.setDomainAxis(categoryAxis17);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        try {
            categoryPlot0.drawBackground(graphics2D27, rectangle2D28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        xYPlot0.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis5.getTickMarkPaint();
        xYPlot0.setDomainTickBandPaint(paint10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color15, stroke16);
        boolean boolean18 = axisLocation13.equals((java.lang.Object) valueMarker17);
        float float19 = valueMarker17.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = valueMarker17.getLabelAnchor();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean23 = layer21.equals((java.lang.Object) dateRange22);
        java.lang.String str24 = layer21.toString();
        xYPlot0.addDomainMarker((int) (short) 100, (org.jfree.chart.plot.Marker) valueMarker17, layer21);
        java.awt.Font font26 = valueMarker17.getLabelFont();
        java.awt.Paint paint27 = valueMarker17.getLabelPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        categoryPlot28.setDomainAxis((int) 'a', categoryAxis30);
        categoryPlot28.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        categoryPlot28.setDataset(0, categoryDataset34);
        java.awt.Paint paint36 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot28.setNoDataMessagePaint(paint36);
        java.awt.Paint paint38 = categoryPlot28.getOutlinePaint();
        int int39 = categoryPlot28.getDomainAxisCount();
        java.lang.Class<?> wildcardClass40 = categoryPlot28.getClass();
        java.lang.Class class41 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass40);
        try {
            java.util.EventListener[] eventListenerArray42 = valueMarker17.getListeners(class41);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [Lorg.jfree.data.time.Millisecond; cannot be cast to [Ljava.util.EventListener;");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Layer.FOREGROUND" + "'", str24.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 98 + "'", int39 == 98);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertNotNull(class41);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        int int1 = color0.getAlpha();
        java.awt.Color color2 = java.awt.Color.GREEN;
        int int3 = color2.getAlpha();
        boolean boolean4 = color0.equals((java.lang.Object) int3);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        categoryPlot0.setDataset(categoryDataset1);
        categoryPlot0.setBackgroundImageAlignment(0);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = null;
        categoryPlot0.setFixedLegendItems(legendItemCollection5);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setRange((double) (byte) 10, 100.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = null;
        dateAxis0.setTickUnit(dateTickUnit4);
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = null;
        dateAxis0.setTickUnit(dateTickUnit6, false, false);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation12, plotOrientation13);
        try {
            double double15 = dateAxis0.java2DToValue((double) 1560409200000L, rectangle2D11, rectangleEdge14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("UnitType.ABSOLUTE");
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        java.util.List list9 = numberAxis0.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge8);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        double double16 = rectangleInsets14.calculateLeftInset((double) (-1));
        numberAxis0.setTickLabelInsets(rectangleInsets14);
        numberAxis0.setLabelURL("PlotOrientation.HORIZONTAL");
        double double20 = numberAxis0.getAutoRangeMinimumSize();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 32.0d + "'", double16 == 32.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0E-8d + "'", double20 == 1.0E-8d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker9.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = valueMarker9.getOutlineStroke();
        boolean boolean13 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        valueMarker9.setLabelTextAnchor(textAnchor14);
        java.lang.String str16 = textAnchor14.toString();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "TextAnchor.BOTTOM_RIGHT" + "'", str16.equals("TextAnchor.BOTTOM_RIGHT"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        categoryPlot1.setDomainAxis((int) 'a', categoryAxis3);
        categoryPlot1.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.data.general.DatasetGroup datasetGroup7 = categoryPlot1.getDatasetGroup();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot1.getRenderer();
        boolean boolean9 = rectangleInsets0.equals((java.lang.Object) categoryPlot1);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        categoryPlot10.setDomainAxis((int) 'a', categoryAxis12);
        categoryPlot10.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder16 = categoryPlot10.getDatasetRenderingOrder();
        boolean boolean17 = rectangleInsets0.equals((java.lang.Object) categoryPlot10);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNull(datasetGroup7);
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot3.setDomainAxis((int) 'a', categoryAxis5);
        categoryPlot3.clearAnnotations();
        boolean boolean8 = categoryPlot3.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace9 = categoryPlot3.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot3.setInsets(rectangleInsets10);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot3.getDomainAxisEdge((int) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        numberAxis15.setAutoRangeMinimumSize((double) 11, false);
        numberAxis15.setAutoRangeStickyZero(true);
        double double21 = numberAxis15.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
        double double26 = numberAxis22.valueToJava2D((double) 10, rectangle2D24, rectangleEdge25);
        org.jfree.data.Range range27 = numberAxis22.getDefaultAutoRange();
        numberAxis15.setRange(range27, true, true);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis15.setTickMarkPaint((java.awt.Paint) color31);
        categoryPlot3.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis15);
        categoryPlot3.clearRangeMarkers();
        java.awt.Color color36 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke37 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color36, stroke37);
        java.awt.Stroke stroke39 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker38.setOutlineStroke(stroke39);
        java.awt.Stroke stroke41 = valueMarker38.getStroke();
        categoryPlot3.setDomainGridlineStroke(stroke41);
        xYPlot0.setRangeGridlineStroke(stroke41);
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis();
        numberAxis45.setAutoRangeMinimumSize((double) 11, false);
        numberAxis45.setAutoRangeStickyZero(true);
        double double51 = numberAxis45.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = null;
        double double56 = numberAxis52.valueToJava2D((double) 10, rectangle2D54, rectangleEdge55);
        org.jfree.data.Range range57 = numberAxis52.getDefaultAutoRange();
        numberAxis45.setRange(range57, true, true);
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis45);
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = null;
        categoryPlot62.setDomainAxis((int) 'a', categoryAxis64);
        categoryPlot62.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset68 = null;
        categoryPlot62.setDataset(0, categoryDataset68);
        float float70 = categoryPlot62.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets71 = categoryPlot62.getAxisOffset();
        java.awt.Color color72 = java.awt.Color.red;
        categoryPlot62.setRangeGridlinePaint((java.awt.Paint) color72);
        xYPlot0.setDomainCrosshairPaint((java.awt.Paint) color72);
        org.jfree.data.xy.XYDataset xYDataset75 = null;
        int int76 = xYPlot0.indexOf(xYDataset75);
        java.awt.Paint paint77 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot0.setRangeCrosshairPaint(paint77);
        try {
            xYPlot0.setBackgroundImageAlpha((float) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertTrue("'" + float70 + "' != '" + 1.0f + "'", float70 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets71);
        org.junit.Assert.assertNotNull(color72);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertNotNull(paint77);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot3.setDomainAxis((int) 'a', categoryAxis5);
        categoryPlot3.clearAnnotations();
        boolean boolean8 = categoryPlot3.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace9 = categoryPlot3.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot3.setInsets(rectangleInsets10);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot3.getDomainAxisEdge((int) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        numberAxis15.setAutoRangeMinimumSize((double) 11, false);
        numberAxis15.setAutoRangeStickyZero(true);
        double double21 = numberAxis15.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
        double double26 = numberAxis22.valueToJava2D((double) 10, rectangle2D24, rectangleEdge25);
        org.jfree.data.Range range27 = numberAxis22.getDefaultAutoRange();
        numberAxis15.setRange(range27, true, true);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis15.setTickMarkPaint((java.awt.Paint) color31);
        categoryPlot3.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis15);
        categoryPlot3.clearRangeMarkers();
        java.awt.Color color36 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke37 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color36, stroke37);
        java.awt.Stroke stroke39 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker38.setOutlineStroke(stroke39);
        java.awt.Stroke stroke41 = valueMarker38.getStroke();
        categoryPlot3.setDomainGridlineStroke(stroke41);
        xYPlot0.setRangeGridlineStroke(stroke41);
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis();
        numberAxis45.setAutoRangeMinimumSize((double) 11, false);
        numberAxis45.setAutoRangeStickyZero(true);
        double double51 = numberAxis45.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = null;
        double double56 = numberAxis52.valueToJava2D((double) 10, rectangle2D54, rectangleEdge55);
        org.jfree.data.Range range57 = numberAxis52.getDefaultAutoRange();
        numberAxis45.setRange(range57, true, true);
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis45);
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = null;
        categoryPlot62.setDomainAxis((int) 'a', categoryAxis64);
        categoryPlot62.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset68 = null;
        categoryPlot62.setDataset(0, categoryDataset68);
        float float70 = categoryPlot62.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets71 = categoryPlot62.getAxisOffset();
        java.awt.Color color72 = java.awt.Color.red;
        categoryPlot62.setRangeGridlinePaint((java.awt.Paint) color72);
        xYPlot0.setDomainCrosshairPaint((java.awt.Paint) color72);
        int int75 = color72.getTransparency();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertTrue("'" + float70 + "' != '" + 1.0f + "'", float70 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets71);
        org.junit.Assert.assertNotNull(color72);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.util.SortOrder sortOrder6 = categoryPlot0.getColumnRenderingOrder();
        double double7 = categoryPlot0.getAnchorValue();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(sortOrder6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis5.zoomRange((double) 0L, (double) 3);
        boolean boolean14 = numberAxis5.isNegativeArrowVisible();
        xYPlot0.setDomainAxis(255, (org.jfree.chart.axis.ValueAxis) numberAxis5, false);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = numberAxis17.valueToJava2D((double) 10, rectangle2D19, rectangleEdge20);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
        double double26 = numberAxis22.valueToJava2D((double) 10, rectangle2D24, rectangleEdge25);
        org.jfree.data.Range range27 = numberAxis22.getDefaultAutoRange();
        numberAxis17.setRange(range27);
        numberAxis17.setRangeAboutValue((double) (short) -1, 0.0d);
        numberAxis17.setTickLabelsVisible(false);
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        int int35 = color34.getRGB();
        numberAxis17.setAxisLinePaint((java.awt.Paint) color34);
        int int37 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis17);
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        categoryPlot40.setDomainAxis((int) 'a', categoryAxis42);
        categoryPlot40.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        categoryPlot40.setDataset(0, categoryDataset46);
        java.awt.Paint paint48 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot40.setNoDataMessagePaint(paint48);
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = categoryPlot40.getDomainAxisEdge((int) (byte) 10);
        try {
            double double52 = numberAxis17.valueToJava2D((double) 100L, rectangle2D39, rectangleEdge51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-128) + "'", int35 == (-128));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(rectangleEdge51);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(10.0d, (double) ' ');
        double double3 = intervalMarker2.getEndValue();
        intervalMarker2.setEndValue((double) 4);
        java.lang.Object obj6 = intervalMarker2.clone();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.0d + "'", double3 == 32.0d);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        categoryPlot0.setRenderer(categoryItemRenderer1, false);
        int int4 = categoryPlot0.getWeight();
        int int5 = categoryPlot0.getDatasetCount();
        java.lang.String str6 = categoryPlot0.getPlotType();
        double double7 = categoryPlot0.getAnchorValue();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Category Plot" + "'", str6.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis0, jFreeChart1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        categoryPlot7.setDomainAxis((int) 'a', categoryAxis9);
        categoryPlot7.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        categoryPlot7.setDataset(0, categoryDataset13);
        java.awt.Paint paint15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot7.setNoDataMessagePaint(paint15);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot7.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        try {
            org.jfree.chart.axis.AxisState axisState20 = dateAxis0.draw(graphics2D3, (double) (byte) 10, rectangle2D5, rectangle2D6, rectangleEdge18, plotRenderingInfo19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        xYPlot0.zoomDomainAxes(0.0d, 1.0d, plotRenderingInfo5, point2D6);
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = null;
        xYPlot8.setRangeAxisLocation((int) (short) 100, axisLocation10);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = numberAxis13.valueToJava2D((double) 10, rectangle2D15, rectangleEdge16);
        org.jfree.data.Range range18 = numberAxis13.getDefaultAutoRange();
        numberAxis13.zoomRange((double) 0L, (double) 3);
        boolean boolean22 = numberAxis13.isNegativeArrowVisible();
        xYPlot8.setDomainAxis(255, (org.jfree.chart.axis.ValueAxis) numberAxis13, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        categoryPlot25.setDomainAxis((int) 'a', categoryAxis27);
        categoryPlot25.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        categoryPlot25.setDataset(0, categoryDataset31);
        java.awt.Paint paint33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot25.setNoDataMessagePaint(paint33);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot25.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent37 = null;
        categoryPlot25.rendererChanged(rendererChangeEvent37);
        org.jfree.chart.util.Layer layer40 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection41 = categoryPlot25.getRangeMarkers((int) (byte) -1, layer40);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj44 = null;
        boolean boolean45 = categoryAxis43.equals(obj44);
        categoryAxis43.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis43.clearCategoryLabelToolTips();
        categoryAxis43.setTickLabelsVisible(false);
        java.awt.Graphics2D graphics2D52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = null;
        categoryPlot53.setDomainAxis((int) 'a', categoryAxis55);
        categoryPlot53.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset59 = null;
        categoryPlot53.setDataset(0, categoryDataset59);
        java.awt.Paint paint61 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot53.setNoDataMessagePaint(paint61);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = categoryPlot53.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent65 = null;
        categoryPlot53.rendererChanged(rendererChangeEvent65);
        org.jfree.chart.util.Layer layer68 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection69 = categoryPlot53.getRangeMarkers((int) (byte) -1, layer68);
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = null;
        org.jfree.chart.axis.AxisSpace axisSpace72 = null;
        org.jfree.chart.axis.AxisSpace axisSpace73 = categoryAxis43.reserveSpace(graphics2D52, (org.jfree.chart.plot.Plot) categoryPlot53, rectangle2D70, rectangleEdge71, axisSpace72);
        categoryPlot25.setFixedRangeAxisSpace(axisSpace73, false);
        xYPlot8.setFixedRangeAxisSpace(axisSpace73);
        xYPlot0.setFixedDomainAxisSpace(axisSpace73, false);
        xYPlot0.setRangeCrosshairValue(52.0d, true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(layer40);
        org.junit.Assert.assertNull(collection41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertNotNull(layer68);
        org.junit.Assert.assertNull(collection69);
        org.junit.Assert.assertNotNull(axisSpace73);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getDomainGridlinePaint();
        java.awt.Paint paint2 = categoryPlot0.getRangeGridlinePaint();
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getRowRenderingOrder();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(sortOrder3);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        double double6 = rectangleInsets5.getTop();
        boolean boolean7 = color0.equals((java.lang.Object) rectangleInsets5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 52.0d + "'", double6 == 52.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color2, stroke3);
        boolean boolean5 = axisLocation0.equals((java.lang.Object) valueMarker4);
        float float6 = valueMarker4.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = valueMarker4.getLabelAnchor();
        valueMarker4.setAlpha((float) 0);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        xYPlot0.setRangeCrosshairValue(11.0d, false);
        boolean boolean5 = xYPlot0.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj8 = null;
        boolean boolean9 = categoryAxis7.equals(obj8);
        categoryAxis7.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis7.clearCategoryLabelToolTips();
        categoryAxis7.setTickLabelsVisible(false);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        categoryPlot17.setDomainAxis((int) 'a', categoryAxis19);
        categoryPlot17.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        categoryPlot17.setDataset(0, categoryDataset23);
        java.awt.Paint paint25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot17.setNoDataMessagePaint(paint25);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot17.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent29 = null;
        categoryPlot17.rendererChanged(rendererChangeEvent29);
        org.jfree.chart.util.Layer layer32 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection33 = categoryPlot17.getRangeMarkers((int) (byte) -1, layer32);
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = null;
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        org.jfree.chart.axis.AxisSpace axisSpace37 = categoryAxis7.reserveSpace(graphics2D16, (org.jfree.chart.plot.Plot) categoryPlot17, rectangle2D34, rectangleEdge35, axisSpace36);
        xYPlot0.setFixedRangeAxisSpace(axisSpace36, true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNotNull(layer32);
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertNotNull(axisSpace37);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.data.Range range5 = numberAxis0.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis6.valueToJava2D((double) 10, rectangle2D8, rectangleEdge9);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = numberAxis11.valueToJava2D((double) 10, rectangle2D13, rectangleEdge14);
        org.jfree.data.Range range16 = numberAxis11.getDefaultAutoRange();
        numberAxis6.setRange(range16);
        numberAxis0.setDefaultAutoRange(range16);
        java.awt.Shape shape19 = numberAxis0.getDownArrow();
        java.awt.Color color20 = java.awt.Color.orange;
        numberAxis0.setAxisLinePaint((java.awt.Paint) color20);
        java.lang.String str22 = color20.toString();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "java.awt.Color[r=255,g=200,b=0]" + "'", str22.equals("java.awt.Color[r=255,g=200,b=0]"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setRange((double) (byte) 10, 100.0d);
        try {
            dateAxis0.setRange((double) 2, (double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.plot.IntervalMarker intervalMarker4 = new org.jfree.chart.plot.IntervalMarker(10.0d, (double) ' ');
        java.awt.Stroke stroke5 = intervalMarker4.getStroke();
        java.awt.Color color6 = java.awt.Color.GREEN;
        int int7 = color6.getRed();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        categoryPlot8.setDomainAxis((int) 'a', categoryAxis10);
        categoryPlot8.clearAnnotations();
        boolean boolean13 = categoryPlot8.isOutlineVisible();
        org.jfree.chart.util.SortOrder sortOrder14 = categoryPlot8.getColumnRenderingOrder();
        java.awt.Stroke stroke15 = categoryPlot8.getRangeGridlineStroke();
        try {
            org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) 43629L, (java.awt.Paint) color1, stroke5, (java.awt.Paint) color6, stroke15, (float) 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(sortOrder14);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        float float6 = categoryPlot0.getBackgroundAlpha();
        java.lang.String str7 = categoryPlot0.getPlotType();
        org.jfree.chart.axis.ValueAxis valueAxis9 = categoryPlot0.getRangeAxis((int) (byte) -1);
        java.lang.String str10 = categoryPlot0.getNoDataMessage();
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Category Plot" + "'", str7.equals("Category Plot"));
        org.junit.Assert.assertNull(valueAxis9);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color2, stroke3);
        boolean boolean5 = axisLocation0.equals((java.lang.Object) valueMarker4);
        float float6 = valueMarker4.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = valueMarker4.getLabelAnchor();
        java.lang.Object obj8 = valueMarker4.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot9.setDomainAxis((int) 'a', categoryAxis11);
        categoryPlot9.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        categoryPlot9.setDataset(0, categoryDataset15);
        java.awt.Paint paint17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot9.setNoDataMessagePaint(paint17);
        java.awt.Paint paint19 = categoryPlot9.getOutlinePaint();
        int int20 = categoryPlot9.getDomainAxisCount();
        java.lang.Class<?> wildcardClass21 = categoryPlot9.getClass();
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass21);
        try {
            java.util.EventListener[] eventListenerArray23 = valueMarker4.getListeners(class22);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [Lorg.jfree.data.time.Millisecond; cannot be cast to [Ljava.util.EventListener;");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 98 + "'", int20 == 98);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(class22);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker9.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = valueMarker9.getOutlineStroke();
        boolean boolean13 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        valueMarker9.setLabelTextAnchor(textAnchor14);
        java.lang.String str16 = valueMarker9.getLabel();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        categoryPlot17.setDomainAxis((int) 'a', categoryAxis19);
        categoryPlot17.setBackgroundImageAlignment((int) (short) 10);
        float float23 = categoryPlot17.getBackgroundAlpha();
        categoryPlot17.setRangeCrosshairValue((double) 8, true);
        java.awt.Paint paint27 = categoryPlot17.getRangeGridlinePaint();
        boolean boolean28 = valueMarker9.equals((java.lang.Object) paint27);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis0.setRange(range10);
        numberAxis0.setRangeAboutValue((double) (short) -1, 0.0d);
        numberAxis0.setTickLabelsVisible(false);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        int int18 = color17.getRGB();
        numberAxis0.setAxisLinePaint((java.awt.Paint) color17);
        try {
            numberAxis0.setRange(0.0d, (double) (-48897));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (0.0) <= upper (-48897.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-128) + "'", int18 == (-128));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        java.util.List list9 = numberAxis0.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge8);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        double double16 = rectangleInsets14.calculateLeftInset((double) (-1));
        numberAxis0.setTickLabelInsets(rectangleInsets14);
        java.lang.String str18 = numberAxis0.getLabelToolTip();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 32.0d + "'", double16 == 32.0d);
        org.junit.Assert.assertNull(str18);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis0, jFreeChart1);
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange3);
        dateAxis0.setRange((double) 7, (double) 100);
        dateAxis0.setRangeAboutValue((double) 1, (double) 10);
        java.awt.Stroke stroke11 = null;
        try {
            dateAxis0.setAxisLineStroke(stroke11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateRange3);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color2, stroke3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker4.setOutlineStroke(stroke5);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker4.setLabelOffsetType(lengthAdjustmentType7);
        boolean boolean9 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker4);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color12, stroke13);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker14.setOutlineStroke(stroke15);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType17 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker14.setLabelOffsetType(lengthAdjustmentType17);
        boolean boolean19 = xYPlot10.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker14);
        valueMarker14.setLabel("PlotOrientation.HORIZONTAL");
        boolean boolean22 = xYPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker14);
        org.jfree.chart.plot.Marker marker23 = null;
        org.jfree.chart.util.Layer layer24 = null;
        try {
            boolean boolean25 = xYPlot0.removeRangeMarker(marker23, layer24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(lengthAdjustmentType17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date1, timeZone2);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis("AxisLocation.BOTTOM_OR_LEFT", timeZone2);
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day(date6, timeZone7);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("AxisLocation.BOTTOM_OR_LEFT", timeZone7);
        dateAxis4.setTimeZone(timeZone7);
        try {
            dateAxis4.setRange((double) ' ', (double) (-128));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        long long3 = day2.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
//        categoryPlot5.setDomainAxis((int) 'a', categoryAxis7);
//        categoryPlot5.setBackgroundImageAlignment((int) (short) 10);
//        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot5.getDatasetGroup();
//        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
//        categoryPlot5.setNoDataMessagePaint(paint12);
//        boolean boolean14 = day2.equals((java.lang.Object) categoryPlot5);
//        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
//        java.awt.Font font19 = null;
//        categoryAxis17.setTickLabelFont((java.lang.Comparable) (byte) -1, font19);
//        categoryPlot5.setDomainAxis(10, categoryAxis17);
//        java.lang.String str22 = categoryPlot5.getPlotType();
//        try {
//            categoryPlot5.setBackgroundImageAlpha((float) 500);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNull(datasetGroup11);
//        org.junit.Assert.assertNotNull(paint12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Category Plot" + "'", str22.equals("Category Plot"));
//    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryAxis1.equals(obj2);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis1.setMaximumCategoryLabelLines(1);
        double double9 = categoryAxis1.getLowerMargin();
        double double10 = categoryAxis1.getCategoryMargin();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.2d + "'", double10 == 0.2d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setBackgroundAlpha((float) 4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        int int4 = categoryPlot0.getIndexOf(categoryItemRenderer3);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color6, stroke7);
        java.awt.Stroke stroke9 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker8.setOutlineStroke(stroke9);
        java.awt.Stroke stroke11 = valueMarker8.getOutlineStroke();
        categoryPlot0.setOutlineStroke(stroke11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = categoryPlot0.getRenderer();
        int int14 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.AxisLocation axisLocation16 = null;
        categoryPlot0.setDomainAxisLocation(13, axisLocation16, true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(categoryItemRenderer13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.valueToJava2D((double) 10, rectangle2D4, rectangleEdge5);
        org.jfree.data.Range range7 = numberAxis2.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = numberAxis8.valueToJava2D((double) 10, rectangle2D10, rectangleEdge11);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = numberAxis13.valueToJava2D((double) 10, rectangle2D15, rectangleEdge16);
        org.jfree.data.Range range18 = numberAxis13.getDefaultAutoRange();
        numberAxis8.setRange(range18);
        numberAxis2.setDefaultAutoRange(range18);
        boolean boolean21 = objectList1.equals((java.lang.Object) numberAxis2);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        numberAxis22.setAutoRangeMinimumSize((double) 11, false);
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color27, stroke28);
        numberAxis22.setLabelPaint((java.awt.Paint) color27);
        numberAxis22.setPositiveArrowVisible(true);
        int int33 = objectList1.indexOf((java.lang.Object) numberAxis22);
        int int34 = objectList1.size();
        java.lang.Object obj36 = null;
        try {
            objectList1.set(6, obj36);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 6");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        double double6 = rectangleInsets4.calculateLeftInset((double) (-1));
        double double7 = rectangleInsets4.getBottom();
        double double8 = rectangleInsets4.getLeft();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 32.0d + "'", double6 == 32.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 32.0d + "'", double8 == 32.0d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryAxis1.equals(obj2);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(false);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot11.setDomainAxis((int) 'a', categoryAxis13);
        categoryPlot11.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        categoryPlot11.setDataset(0, categoryDataset17);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot11.setNoDataMessagePaint(paint19);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot11.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        categoryPlot11.rendererChanged(rendererChangeEvent23);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection27 = categoryPlot11.getRangeMarkers((int) (byte) -1, layer26);
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        org.jfree.chart.axis.AxisSpace axisSpace30 = null;
        org.jfree.chart.axis.AxisSpace axisSpace31 = categoryAxis1.reserveSpace(graphics2D10, (org.jfree.chart.plot.Plot) categoryPlot11, rectangle2D28, rectangleEdge29, axisSpace30);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        categoryPlot33.setDomainAxis((int) 'a', categoryAxis35);
        categoryPlot33.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.data.general.DatasetGroup datasetGroup39 = categoryPlot33.getDatasetGroup();
        org.jfree.chart.axis.AxisLocation axisLocation40 = categoryPlot33.getRangeAxisLocation();
        categoryPlot11.setRangeAxisLocation(3, axisLocation40);
        java.awt.Graphics2D graphics2D42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        try {
            categoryPlot11.drawBackground(graphics2D42, rectangle2D43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertNotNull(axisSpace31);
        org.junit.Assert.assertNull(datasetGroup39);
        org.junit.Assert.assertNotNull(axisLocation40);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font3 = null;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) (byte) -1, font3);
        int int5 = categoryAxis1.getMaximumCategoryLabelLines();
        categoryAxis1.setUpperMargin(32.0d);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        int int12 = xYPlot11.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot11.getRangeAxisEdge();
        try {
            double double14 = categoryAxis1.getCategoryMiddle((int) 'a', (int) (short) 1, rectangle2D10, rectangleEdge13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        boolean boolean7 = xYPlot0.isDomainCrosshairVisible();
        boolean boolean8 = xYPlot0.isSubplot();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        int int10 = color9.getRGB();
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color9);
        boolean boolean12 = xYPlot0.isRangeZeroBaselineVisible();
        java.awt.Paint paint13 = xYPlot0.getDomainCrosshairPaint();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-128) + "'", int10 == (-128));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        boolean boolean5 = numberAxis0.getAutoRangeStickyZero();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        categoryPlot6.setDataset(categoryDataset7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        categoryPlot6.removeChangeListener(plotChangeListener9);
        numberAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        java.awt.Font font12 = categoryPlot6.getNoDataMessageFont();
        java.awt.Paint paint13 = categoryPlot6.getRangeCrosshairPaint();
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color15, stroke16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker17.setOutlineStroke(stroke18);
        java.awt.Paint paint20 = valueMarker17.getOutlinePaint();
        java.lang.String str21 = valueMarker17.getLabel();
        valueMarker17.setAlpha(0.0f);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        valueMarker17.setStroke(stroke24);
        categoryPlot6.setRangeCrosshairStroke(stroke24);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis((int) 'a', categoryAxis7);
        categoryPlot5.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color12, stroke13);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker14.setOutlineStroke(stroke15);
        java.awt.Stroke stroke17 = valueMarker14.getOutlineStroke();
        boolean boolean18 = categoryPlot5.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker14);
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean21 = layer19.equals((java.lang.Object) dateRange20);
        java.lang.String str22 = layer19.toString();
        xYPlot0.addDomainMarker((int) '#', (org.jfree.chart.plot.Marker) valueMarker14, layer19);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        java.util.List list25 = xYPlot24.getAnnotations();
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot24.setDomainZeroBaselineStroke(stroke26);
        xYPlot0.setDomainCrosshairStroke(stroke26);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = xYPlot0.getRenderer(2019);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(layer19);
        org.junit.Assert.assertNotNull(dateRange20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Layer.FOREGROUND" + "'", str22.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(list25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(xYItemRenderer30);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color2, stroke3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker4.setOutlineStroke(stroke5);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker4.setLabelOffsetType(lengthAdjustmentType7);
        boolean boolean9 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker4);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = xYPlot0.getFixedLegendItems();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot11.setDomainAxis((int) 'a', categoryAxis13);
        categoryPlot11.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        categoryPlot11.setDataset(0, categoryDataset17);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot11.setNoDataMessagePaint(paint19);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot11.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        categoryPlot11.rendererChanged(rendererChangeEvent23);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection27 = categoryPlot11.getRangeMarkers((int) (byte) -1, layer26);
        java.util.Collection collection28 = xYPlot0.getRangeMarkers(layer26);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset30);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke32);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation34 = null;
        try {
            boolean boolean35 = xYPlot0.removeAnnotation(xYAnnotation34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.AxisState axisState2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis6);
        categoryPlot4.clearAnnotations();
        boolean boolean9 = categoryPlot4.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot4.setInsets(rectangleInsets11);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot4.getDomainAxisEdge((int) (short) -1);
        try {
            java.util.List list15 = dateAxis0.refreshTicks(graphics2D1, axisState2, rectangle2D3, rectangleEdge14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker9.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = valueMarker9.getOutlineStroke();
        boolean boolean13 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        categoryPlot0.setOrientation(plotOrientation14);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        categoryPlot16.setDomainAxis((int) 'a', categoryAxis18);
        categoryPlot16.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.data.general.DatasetGroup datasetGroup22 = categoryPlot16.getDatasetGroup();
        java.awt.Paint paint23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        categoryPlot16.setNoDataMessagePaint(paint23);
        categoryPlot0.setRangeGridlinePaint(paint23);
        int int26 = categoryPlot0.getWeight();
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        categoryPlot0.drawBackgroundImage(graphics2D27, rectangle2D28);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNull(datasetGroup22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (short) 10, 0, 5);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        boolean boolean7 = xYPlot0.isDomainCrosshairVisible();
        boolean boolean8 = xYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = numberAxis9.valueToJava2D((double) 10, rectangle2D11, rectangleEdge12);
        org.jfree.data.Range range14 = numberAxis9.getDefaultAutoRange();
        numberAxis9.zoomRange((double) 0L, (double) 3);
        int int18 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis9);
        java.awt.Paint paint19 = xYPlot0.getRangeZeroBaselinePaint();
        xYPlot0.clearDomainMarkers(9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 64 + "'", int1 == 64);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setRange((double) (byte) 10, 100.0d);
        org.jfree.chart.axis.Timeline timeline4 = null;
        dateAxis0.setTimeline(timeline4);
        org.jfree.chart.axis.Timeline timeline6 = null;
        dateAxis0.setTimeline(timeline6);
        dateAxis0.configure();
        java.text.DateFormat dateFormat9 = null;
        dateAxis0.setDateFormatOverride(dateFormat9);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

//    @Test
//    public void test404() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test404");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        long long3 = day2.getFirstMillisecond();
//        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis();
//        numberAxis4.setAutoRangeMinimumSize((double) 11, false);
//        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_GREEN;
//        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color9, stroke10);
//        numberAxis4.setLabelPaint((java.awt.Paint) color9);
//        numberAxis4.setPositiveArrowVisible(true);
//        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = numberAxis4.getTickUnit();
//        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D18 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
//        double double20 = numberAxis16.valueToJava2D((double) 10, rectangle2D18, rectangleEdge19);
//        org.jfree.data.Range range21 = numberAxis16.getDefaultAutoRange();
//        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D24 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
//        double double26 = numberAxis22.valueToJava2D((double) 10, rectangle2D24, rectangleEdge25);
//        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
//        java.awt.geom.Rectangle2D rectangle2D29 = null;
//        org.jfree.chart.util.RectangleEdge rectangleEdge30 = null;
//        double double31 = numberAxis27.valueToJava2D((double) 10, rectangle2D29, rectangleEdge30);
//        org.jfree.data.Range range32 = numberAxis27.getDefaultAutoRange();
//        numberAxis22.setRange(range32);
//        numberAxis16.setDefaultAutoRange(range32);
//        numberAxis16.setAutoRangeMinimumSize((double) 1, true);
//        org.jfree.data.Range range38 = numberAxis16.getDefaultAutoRange();
//        numberAxis4.setRangeWithMargins(range38, true, false);
//        boolean boolean42 = day2.equals((java.lang.Object) numberAxis4);
//        java.lang.String str43 = day2.toString();
//        long long44 = day2.getMiddleMillisecond();
//        java.util.Calendar calendar45 = null;
//        try {
//            long long46 = day2.getMiddleMillisecond(calendar45);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(color9);
//        org.junit.Assert.assertNotNull(stroke10);
//        org.junit.Assert.assertNotNull(numberTickUnit15);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
//        org.junit.Assert.assertNotNull(range21);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
//        org.junit.Assert.assertNotNull(range32);
//        org.junit.Assert.assertNotNull(range38);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "13-June-2019" + "'", str43.equals("13-June-2019"));
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560452399999L + "'", long44 == 1560452399999L);
//    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color2, stroke3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker4.setOutlineStroke(stroke5);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker4.setLabelOffsetType(lengthAdjustmentType7);
        boolean boolean9 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker4);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = xYPlot0.getFixedLegendItems();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot11.setDomainAxis((int) 'a', categoryAxis13);
        categoryPlot11.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        categoryPlot11.setDataset(0, categoryDataset17);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot11.setNoDataMessagePaint(paint19);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot11.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        categoryPlot11.rendererChanged(rendererChangeEvent23);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection27 = categoryPlot11.getRangeMarkers((int) (byte) -1, layer26);
        java.util.Collection collection28 = xYPlot0.getRangeMarkers(layer26);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis30 = xYPlot0.getDomainAxisForDataset(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 6 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertNull(collection28);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        xYPlot0.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis6.valueToJava2D((double) 10, rectangle2D8, rectangleEdge9);
        org.jfree.data.Range range11 = numberAxis6.getDefaultAutoRange();
        java.awt.Font font12 = numberAxis6.getTickLabelFont();
        numberAxis6.setAutoRange(false);
        xYPlot0.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis6, false);
        numberAxis6.configure();
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        categoryPlot1.setDomainAxis((int) 'a', categoryAxis3);
        categoryPlot1.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.data.general.DatasetGroup datasetGroup7 = categoryPlot1.getDatasetGroup();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot1.getRenderer();
        boolean boolean9 = rectangleInsets0.equals((java.lang.Object) categoryPlot1);
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        try {
            categoryPlot1.setDomainAxisLocation(0, axisLocation11, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNull(datasetGroup7);
        org.junit.Assert.assertNull(categoryItemRenderer8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot3.setDomainAxis((int) 'a', categoryAxis5);
        categoryPlot3.clearAnnotations();
        boolean boolean8 = categoryPlot3.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace9 = categoryPlot3.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot3.setInsets(rectangleInsets10);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot3.getDomainAxisEdge((int) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        numberAxis15.setAutoRangeMinimumSize((double) 11, false);
        numberAxis15.setAutoRangeStickyZero(true);
        double double21 = numberAxis15.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
        double double26 = numberAxis22.valueToJava2D((double) 10, rectangle2D24, rectangleEdge25);
        org.jfree.data.Range range27 = numberAxis22.getDefaultAutoRange();
        numberAxis15.setRange(range27, true, true);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis15.setTickMarkPaint((java.awt.Paint) color31);
        categoryPlot3.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis15);
        categoryPlot3.clearRangeMarkers();
        java.awt.Color color36 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke37 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color36, stroke37);
        java.awt.Stroke stroke39 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker38.setOutlineStroke(stroke39);
        java.awt.Stroke stroke41 = valueMarker38.getStroke();
        categoryPlot3.setDomainGridlineStroke(stroke41);
        xYPlot0.setRangeGridlineStroke(stroke41);
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis();
        numberAxis45.setAutoRangeMinimumSize((double) 11, false);
        numberAxis45.setAutoRangeStickyZero(true);
        double double51 = numberAxis45.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = null;
        double double56 = numberAxis52.valueToJava2D((double) 10, rectangle2D54, rectangleEdge55);
        org.jfree.data.Range range57 = numberAxis52.getDefaultAutoRange();
        numberAxis45.setRange(range57, true, true);
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis45);
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = null;
        categoryPlot62.setDomainAxis((int) 'a', categoryAxis64);
        categoryPlot62.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset68 = null;
        categoryPlot62.setDataset(0, categoryDataset68);
        float float70 = categoryPlot62.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets71 = categoryPlot62.getAxisOffset();
        java.awt.Color color72 = java.awt.Color.red;
        categoryPlot62.setRangeGridlinePaint((java.awt.Paint) color72);
        xYPlot0.setDomainCrosshairPaint((java.awt.Paint) color72);
        org.jfree.data.xy.XYDataset xYDataset75 = null;
        int int76 = xYPlot0.indexOf(xYDataset75);
        java.awt.Paint paint77 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        xYPlot0.setRangeCrosshairPaint(paint77);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation79 = null;
        try {
            xYPlot0.addAnnotation(xYAnnotation79, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertTrue("'" + float70 + "' != '" + 1.0f + "'", float70 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets71);
        org.junit.Assert.assertNotNull(color72);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertNotNull(paint77);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis((int) 'a', categoryAxis7);
        categoryPlot5.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color12, stroke13);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker14.setOutlineStroke(stroke15);
        java.awt.Stroke stroke17 = valueMarker14.getOutlineStroke();
        boolean boolean18 = categoryPlot5.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker14);
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean21 = layer19.equals((java.lang.Object) dateRange20);
        java.lang.String str22 = layer19.toString();
        xYPlot0.addDomainMarker((int) '#', (org.jfree.chart.plot.Marker) valueMarker14, layer19);
        org.jfree.chart.plot.IntervalMarker intervalMarker26 = new org.jfree.chart.plot.IntervalMarker(10.0d, (double) ' ');
        intervalMarker26.setEndValue((double) 6);
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean30 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker26, layer29);
        boolean boolean32 = layer29.equals((java.lang.Object) 100);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(layer19);
        org.junit.Assert.assertNotNull(dateRange20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Layer.FOREGROUND" + "'", str22.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        categoryPlot1.setDomainAxis((int) 'a', categoryAxis3);
        categoryPlot1.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        categoryPlot1.setDataset(0, categoryDataset7);
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot1.setNoDataMessagePaint(paint9);
        java.awt.Paint paint11 = categoryPlot1.getOutlinePaint();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = color12.createContext(colorModel13, rectangle14, rectangle2D15, affineTransform16, renderingHints17);
        java.awt.Paint[] paintArray19 = new java.awt.Paint[] { color0, paint11, color12 };
        java.awt.Paint[] paintArray20 = null;
        java.awt.Paint[] paintArray21 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray22 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray23 = null;
        java.awt.Shape[] shapeArray24 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier25 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray19, paintArray20, paintArray21, strokeArray22, strokeArray23, shapeArray24);
        java.awt.Shape shape26 = defaultDrawingSupplier25.getNextShape();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNotNull(paintArray19);
        org.junit.Assert.assertNotNull(paintArray21);
        org.junit.Assert.assertNotNull(strokeArray22);
        org.junit.Assert.assertNotNull(shapeArray24);
        org.junit.Assert.assertNotNull(shape26);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot3.setDomainAxis((int) 'a', categoryAxis5);
        categoryPlot3.clearAnnotations();
        boolean boolean8 = categoryPlot3.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace9 = categoryPlot3.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot3.setInsets(rectangleInsets10);
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot3.getDomainAxisEdge((int) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        numberAxis15.setAutoRangeMinimumSize((double) 11, false);
        numberAxis15.setAutoRangeStickyZero(true);
        double double21 = numberAxis15.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
        double double26 = numberAxis22.valueToJava2D((double) 10, rectangle2D24, rectangleEdge25);
        org.jfree.data.Range range27 = numberAxis22.getDefaultAutoRange();
        numberAxis15.setRange(range27, true, true);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis15.setTickMarkPaint((java.awt.Paint) color31);
        categoryPlot3.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis15);
        categoryPlot3.clearRangeMarkers();
        java.awt.Color color36 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke37 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color36, stroke37);
        java.awt.Stroke stroke39 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker38.setOutlineStroke(stroke39);
        java.awt.Stroke stroke41 = valueMarker38.getStroke();
        categoryPlot3.setDomainGridlineStroke(stroke41);
        xYPlot0.setRangeGridlineStroke(stroke41);
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis();
        numberAxis45.setAutoRangeMinimumSize((double) 11, false);
        numberAxis45.setAutoRangeStickyZero(true);
        double double51 = numberAxis45.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = null;
        double double56 = numberAxis52.valueToJava2D((double) 10, rectangle2D54, rectangleEdge55);
        org.jfree.data.Range range57 = numberAxis52.getDefaultAutoRange();
        numberAxis45.setRange(range57, true, true);
        xYPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis45);
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = null;
        categoryPlot62.setDomainAxis((int) 'a', categoryAxis64);
        categoryPlot62.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset68 = null;
        categoryPlot62.setDataset(0, categoryDataset68);
        float float70 = categoryPlot62.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets71 = categoryPlot62.getAxisOffset();
        java.awt.Color color72 = java.awt.Color.red;
        categoryPlot62.setRangeGridlinePaint((java.awt.Paint) color72);
        xYPlot0.setDomainCrosshairPaint((java.awt.Paint) color72);
        java.awt.geom.Point2D point2D75 = xYPlot0.getQuadrantOrigin();
        xYPlot0.clearDomainAxes();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertTrue("'" + float70 + "' != '" + 1.0f + "'", float70 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets71);
        org.junit.Assert.assertNotNull(color72);
        org.junit.Assert.assertNotNull(point2D75);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        float float8 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot0.getAxisOffset();
        java.awt.Color color10 = java.awt.Color.red;
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color10);
        java.lang.String str12 = categoryPlot0.getPlotType();
        categoryPlot0.clearRangeAxes();
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Category Plot" + "'", str12.equals("Category Plot"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font3 = null;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) (byte) -1, font3);
        int int5 = categoryAxis1.getMaximumCategoryLabelLines();
        categoryAxis1.setUpperMargin(32.0d);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        int int10 = xYPlot9.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        xYPlot9.zoomRangeAxes((double) 255, plotRenderingInfo12, point2D13, true);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        categoryPlot17.setDomainAxis((int) 'a', categoryAxis19);
        categoryPlot17.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        categoryPlot17.setDataset(0, categoryDataset23);
        java.awt.Paint paint25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot17.setNoDataMessagePaint(paint25);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot17.getDomainAxisEdge((int) (byte) 10);
        java.lang.Class<?> wildcardClass29 = rectangleEdge28.getClass();
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj32 = null;
        boolean boolean33 = categoryAxis31.equals(obj32);
        categoryAxis31.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis31.clearCategoryLabelToolTips();
        categoryAxis31.setTickLabelsVisible(false);
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        categoryPlot41.setDomainAxis((int) 'a', categoryAxis43);
        categoryPlot41.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset47 = null;
        categoryPlot41.setDataset(0, categoryDataset47);
        java.awt.Paint paint49 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot41.setNoDataMessagePaint(paint49);
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = categoryPlot41.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent53 = null;
        categoryPlot41.rendererChanged(rendererChangeEvent53);
        org.jfree.chart.util.Layer layer56 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection57 = categoryPlot41.getRangeMarkers((int) (byte) -1, layer56);
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = null;
        org.jfree.chart.axis.AxisSpace axisSpace60 = null;
        org.jfree.chart.axis.AxisSpace axisSpace61 = categoryAxis31.reserveSpace(graphics2D40, (org.jfree.chart.plot.Plot) categoryPlot41, rectangle2D58, rectangleEdge59, axisSpace60);
        try {
            org.jfree.chart.axis.AxisSpace axisSpace62 = categoryAxis1.reserveSpace(graphics2D8, (org.jfree.chart.plot.Plot) xYPlot9, rectangle2D16, rectangleEdge28, axisSpace60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNotNull(wildcardClass29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertNotNull(layer56);
        org.junit.Assert.assertNull(collection57);
        org.junit.Assert.assertNotNull(axisSpace61);
    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test417");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        long long3 = day2.getFirstMillisecond();
//        org.jfree.chart.axis.AxisLocation axisLocation4 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
//        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_GREEN;
//        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
//        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color6, stroke7);
//        boolean boolean9 = axisLocation4.equals((java.lang.Object) valueMarker8);
//        float float10 = valueMarker8.getAlpha();
//        int int11 = day2.compareTo((java.lang.Object) valueMarker8);
//        int int12 = day2.getYear();
//        int int13 = day2.getMonth();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(axisLocation4);
//        org.junit.Assert.assertNotNull(color6);
//        org.junit.Assert.assertNotNull(stroke7);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis0.setRangeWithMargins(range10, true, true);
        java.text.NumberFormat numberFormat14 = numberAxis0.getNumberFormatOverride();
        java.lang.String str15 = numberAxis0.getLabelURL();
        numberAxis0.centerRange(0.0d);
        java.awt.Paint paint18 = numberAxis0.getTickLabelPaint();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNull(numberFormat14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot0.getDomainAxisEdge((int) (byte) 10);
        categoryPlot0.setRangeCrosshairVisible(false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        int int4 = categoryPlot0.getDatasetCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color2, stroke3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker4.setOutlineStroke(stroke5);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker4.setLabelOffsetType(lengthAdjustmentType7);
        boolean boolean9 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker4);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = xYPlot0.getFixedLegendItems();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot11.setDomainAxis((int) 'a', categoryAxis13);
        categoryPlot11.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        categoryPlot11.setDataset(0, categoryDataset17);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot11.setNoDataMessagePaint(paint19);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot11.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        categoryPlot11.rendererChanged(rendererChangeEvent23);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection27 = categoryPlot11.getRangeMarkers((int) (byte) -1, layer26);
        java.util.Collection collection28 = xYPlot0.getRangeMarkers(layer26);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset30);
        xYPlot0.configureRangeAxes();
        xYPlot0.clearDomainMarkers();
        xYPlot0.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertNull(collection28);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        float float6 = categoryPlot0.getBackgroundAlpha();
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot();
        int int10 = xYPlot9.getDomainAxisCount();
        xYPlot9.setRangeCrosshairValue(11.0d, false);
        boolean boolean14 = xYPlot9.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot9.getRangeAxisLocation();
        categoryPlot0.setRangeAxisLocation(axisLocation15);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNull(axisSpace8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryAxis1.equals(obj2);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setVisible(false);
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) (-1L));
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.AxisState axisState13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot15.setDomainAxis((int) 'a', categoryAxis17);
        categoryPlot15.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color22, stroke23);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker24.setOutlineStroke(stroke25);
        java.awt.Stroke stroke27 = valueMarker24.getOutlineStroke();
        boolean boolean28 = categoryPlot15.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker24);
        org.jfree.data.general.DatasetGroup datasetGroup29 = categoryPlot15.getDatasetGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        categoryPlot30.setDomainAxis((int) 'a', categoryAxis32);
        categoryPlot30.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.data.general.DatasetGroup datasetGroup36 = categoryPlot30.getDatasetGroup();
        categoryPlot15.setParent((org.jfree.chart.plot.Plot) categoryPlot30);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = categoryPlot15.getDomainAxisEdge();
        try {
            java.util.List list39 = categoryAxis1.refreshTicks(graphics2D12, axisState13, rectangle2D14, rectangleEdge38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(datasetGroup29);
        org.junit.Assert.assertNull(datasetGroup36);
        org.junit.Assert.assertNotNull(rectangleEdge38);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color7, stroke8);
        java.awt.Stroke stroke10 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker9.setOutlineStroke(stroke10);
        java.awt.Stroke stroke12 = valueMarker9.getOutlineStroke();
        boolean boolean13 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker9);
        org.jfree.data.general.DatasetGroup datasetGroup14 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot15.setDomainAxis((int) 'a', categoryAxis17);
        categoryPlot15.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.data.general.DatasetGroup datasetGroup21 = categoryPlot15.getDatasetGroup();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot15);
        categoryPlot15.setBackgroundAlpha((float) (-393216));
        categoryPlot15.setRangeCrosshairValue((double) (byte) 0, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot15.getRenderer(500);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(datasetGroup14);
        org.junit.Assert.assertNull(datasetGroup21);
        org.junit.Assert.assertNull(categoryItemRenderer29);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        java.awt.Color color0 = java.awt.Color.gray;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray3 = new float[] { 10L };
        try {
            float[] floatArray4 = color0.getColorComponents(colorSpace1, floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        float float6 = categoryPlot0.getBackgroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.AxisLocation axisLocation8 = axisLocation7.getOpposite();
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(axisLocation8);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        boolean boolean7 = categoryPlot0.isRangeZoomable();
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = categoryPlot0.getOrientation();
        java.awt.Stroke stroke12 = categoryPlot0.getRangeCrosshairStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        categoryPlot0.setRenderer(categoryItemRenderer13);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot0.getRendererForDataset(categoryDataset15);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(categoryItemRenderer16);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.Object obj1 = null;
        boolean boolean2 = lengthAdjustmentType0.equals(obj1);
        java.lang.String str3 = lengthAdjustmentType0.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "CONTRACT" + "'", str3.equals("CONTRACT"));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        boolean boolean7 = xYPlot0.isDomainCrosshairVisible();
        boolean boolean8 = xYPlot0.isDomainZeroBaselineVisible();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = numberAxis9.valueToJava2D((double) 10, rectangle2D11, rectangleEdge12);
        org.jfree.data.Range range14 = numberAxis9.getDefaultAutoRange();
        numberAxis9.zoomRange((double) 0L, (double) 3);
        int int18 = xYPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis9);
        java.awt.Paint paint19 = xYPlot0.getRangeCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation20 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        categoryPlot21.setDomainAxis((int) 'a', categoryAxis23);
        categoryPlot21.clearAnnotations();
        boolean boolean26 = categoryPlot21.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace27 = categoryPlot21.getFixedDomainAxisSpace();
        boolean boolean28 = categoryPlot21.isRangeZoomable();
        categoryPlot21.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation31 = categoryPlot21.getDomainAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation32 = categoryPlot21.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation20, plotOrientation32);
        xYPlot0.setDomainAxisLocation(axisLocation20);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNull(axisSpace27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(plotOrientation32);
        org.junit.Assert.assertNotNull(rectangleEdge33);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier4 = categoryPlot0.getDrawingSupplier();
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = categoryPlot0.getRenderer();
        org.jfree.data.general.Dataset dataset7 = null;
        try {
            org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) categoryItemRenderer6, dataset7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(drawingSupplier4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryItemRenderer6);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setRange((double) (byte) 10, 100.0d);
        java.text.DateFormat dateFormat4 = dateAxis0.getDateFormatOverride();
        boolean boolean5 = dateAxis0.isAutoRange();
        dateAxis0.setLabelURL("java.awt.Color[r=255,g=200,b=0]");
        org.junit.Assert.assertNull(dateFormat4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        java.awt.Paint paint2 = xYPlot0.getRangeGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation(5);
        int int5 = xYPlot0.getDomainAxisCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        boolean boolean7 = categoryPlot0.isRangeZoomable();
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot0.getFixedDomainAxisSpace();
        java.awt.Stroke stroke11 = categoryPlot0.getRangeCrosshairStroke();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryAxis1.equals(obj2);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(false);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot();
        int int15 = xYPlot14.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot14.getRangeAxisEdge();
        try {
            double double17 = categoryAxis1.getCategoryMiddle(12, 0, rectangle2D13, rectangleEdge16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot5.setDomainAxis((int) 'a', categoryAxis7);
        categoryPlot5.setBackgroundImageAlignment((int) (short) 10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color12, stroke13);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker14.setOutlineStroke(stroke15);
        java.awt.Stroke stroke17 = valueMarker14.getOutlineStroke();
        boolean boolean18 = categoryPlot5.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker14);
        org.jfree.chart.util.Layer layer19 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange20 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean21 = layer19.equals((java.lang.Object) dateRange20);
        java.lang.String str22 = layer19.toString();
        xYPlot0.addDomainMarker((int) '#', (org.jfree.chart.plot.Marker) valueMarker14, layer19);
        org.jfree.chart.axis.ValueAxis valueAxis24 = xYPlot0.getDomainAxis();
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(layer19);
        org.junit.Assert.assertNotNull(dateRange20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Layer.FOREGROUND" + "'", str22.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(valueAxis24);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryAxis1.equals(obj2);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setTickLabelsVisible(false);
        boolean boolean11 = categoryAxis1.equals((java.lang.Object) 1.0d);
        int int12 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setLowerMargin((double) 10);
        categoryAxis1.setCategoryLabelPositionOffset((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.util.List list1 = xYPlot0.getAnnotations();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot0.setDomainZeroBaselineStroke(stroke2);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = null;
        xYPlot0.rendererChanged(rendererChangeEvent4);
        xYPlot0.setDomainZeroBaselineVisible(true);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        boolean boolean7 = xYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot();
        int int12 = xYPlot11.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = xYPlot11.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        int int17 = xYPlot16.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = xYPlot16.getRangeAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        categoryPlot19.setDomainAxis((int) 'a', categoryAxis21);
        categoryPlot19.clearAnnotations();
        boolean boolean24 = categoryPlot19.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace25 = categoryPlot19.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot19.setInsets(rectangleInsets26);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot19.getDomainAxisEdge((int) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis();
        numberAxis31.setAutoRangeMinimumSize((double) 11, false);
        numberAxis31.setAutoRangeStickyZero(true);
        double double37 = numberAxis31.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        double double42 = numberAxis38.valueToJava2D((double) 10, rectangle2D40, rectangleEdge41);
        org.jfree.data.Range range43 = numberAxis38.getDefaultAutoRange();
        numberAxis31.setRange(range43, true, true);
        java.awt.Color color47 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis31.setTickMarkPaint((java.awt.Paint) color47);
        categoryPlot19.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis31);
        categoryPlot19.clearRangeMarkers();
        java.awt.Color color52 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke53 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker54 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color52, stroke53);
        java.awt.Stroke stroke55 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker54.setOutlineStroke(stroke55);
        java.awt.Stroke stroke57 = valueMarker54.getStroke();
        categoryPlot19.setDomainGridlineStroke(stroke57);
        xYPlot16.setRangeGridlineStroke(stroke57);
        org.jfree.chart.axis.NumberAxis numberAxis61 = new org.jfree.chart.axis.NumberAxis();
        numberAxis61.setAutoRangeMinimumSize((double) 11, false);
        numberAxis61.setAutoRangeStickyZero(true);
        double double67 = numberAxis61.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis68 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge71 = null;
        double double72 = numberAxis68.valueToJava2D((double) 10, rectangle2D70, rectangleEdge71);
        org.jfree.data.Range range73 = numberAxis68.getDefaultAutoRange();
        numberAxis61.setRange(range73, true, true);
        xYPlot16.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis61);
        org.jfree.chart.plot.CategoryPlot categoryPlot78 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis80 = null;
        categoryPlot78.setDomainAxis((int) 'a', categoryAxis80);
        categoryPlot78.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset84 = null;
        categoryPlot78.setDataset(0, categoryDataset84);
        float float86 = categoryPlot78.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets87 = categoryPlot78.getAxisOffset();
        java.awt.Color color88 = java.awt.Color.red;
        categoryPlot78.setRangeGridlinePaint((java.awt.Paint) color88);
        xYPlot16.setDomainCrosshairPaint((java.awt.Paint) color88);
        java.awt.geom.Point2D point2D91 = xYPlot16.getQuadrantOrigin();
        xYPlot11.zoomDomainAxes((double) 1560409200000L, plotRenderingInfo15, point2D91, true);
        xYPlot0.zoomDomainAxes(32.0d, (double) (byte) 1, plotRenderingInfo10, point2D91);
        double double95 = xYPlot0.getRangeCrosshairValue();
        xYPlot0.setDomainCrosshairLockedOnData(true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(axisSpace25);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(range73);
        org.junit.Assert.assertTrue("'" + float86 + "' != '" + 1.0f + "'", float86 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets87);
        org.junit.Assert.assertNotNull(color88);
        org.junit.Assert.assertNotNull(point2D91);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 0.0d + "'", double95 == 0.0d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomDomainAxes((double) 4, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        int int13 = xYPlot12.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = xYPlot12.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot();
        int int18 = xYPlot17.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = xYPlot17.getRangeAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        categoryPlot20.setDomainAxis((int) 'a', categoryAxis22);
        categoryPlot20.clearAnnotations();
        boolean boolean25 = categoryPlot20.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace26 = categoryPlot20.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot20.setInsets(rectangleInsets27);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot20.getDomainAxisEdge((int) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis();
        numberAxis32.setAutoRangeMinimumSize((double) 11, false);
        numberAxis32.setAutoRangeStickyZero(true);
        double double38 = numberAxis32.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = null;
        double double43 = numberAxis39.valueToJava2D((double) 10, rectangle2D41, rectangleEdge42);
        org.jfree.data.Range range44 = numberAxis39.getDefaultAutoRange();
        numberAxis32.setRange(range44, true, true);
        java.awt.Color color48 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis32.setTickMarkPaint((java.awt.Paint) color48);
        categoryPlot20.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis32);
        categoryPlot20.clearRangeMarkers();
        java.awt.Color color53 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke54 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker55 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color53, stroke54);
        java.awt.Stroke stroke56 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker55.setOutlineStroke(stroke56);
        java.awt.Stroke stroke58 = valueMarker55.getStroke();
        categoryPlot20.setDomainGridlineStroke(stroke58);
        xYPlot17.setRangeGridlineStroke(stroke58);
        org.jfree.chart.axis.NumberAxis numberAxis62 = new org.jfree.chart.axis.NumberAxis();
        numberAxis62.setAutoRangeMinimumSize((double) 11, false);
        numberAxis62.setAutoRangeStickyZero(true);
        double double68 = numberAxis62.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis69 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D71 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = null;
        double double73 = numberAxis69.valueToJava2D((double) 10, rectangle2D71, rectangleEdge72);
        org.jfree.data.Range range74 = numberAxis69.getDefaultAutoRange();
        numberAxis62.setRange(range74, true, true);
        xYPlot17.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis62);
        org.jfree.chart.plot.CategoryPlot categoryPlot79 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis81 = null;
        categoryPlot79.setDomainAxis((int) 'a', categoryAxis81);
        categoryPlot79.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset85 = null;
        categoryPlot79.setDataset(0, categoryDataset85);
        float float87 = categoryPlot79.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets88 = categoryPlot79.getAxisOffset();
        java.awt.Color color89 = java.awt.Color.red;
        categoryPlot79.setRangeGridlinePaint((java.awt.Paint) color89);
        xYPlot17.setDomainCrosshairPaint((java.awt.Paint) color89);
        java.awt.geom.Point2D point2D92 = xYPlot17.getQuadrantOrigin();
        xYPlot12.zoomDomainAxes((double) 1560409200000L, plotRenderingInfo16, point2D92, true);
        categoryPlot0.zoomDomainAxes((double) (-48897), plotRenderingInfo11, point2D92);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNull(axisSpace26);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(range74);
        org.junit.Assert.assertTrue("'" + float87 + "' != '" + 1.0f + "'", float87 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets88);
        org.junit.Assert.assertNotNull(color89);
        org.junit.Assert.assertNotNull(point2D92);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        java.awt.Paint paint2 = null;
        org.jfree.chart.plot.XYPlot xYPlot3 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        xYPlot3.setRangeAxisLocation((int) (short) 100, axisLocation5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = numberAxis8.valueToJava2D((double) 10, rectangle2D10, rectangleEdge11);
        org.jfree.data.Range range13 = numberAxis8.getDefaultAutoRange();
        numberAxis8.zoomRange((double) 0L, (double) 3);
        boolean boolean17 = numberAxis8.isNegativeArrowVisible();
        xYPlot3.setDomainAxis(255, (org.jfree.chart.axis.ValueAxis) numberAxis8, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = xYPlot3.getDatasetRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation22 = xYPlot3.getRangeAxisLocation(0);
        java.awt.Stroke stroke23 = xYPlot3.getRangeCrosshairStroke();
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation26 = null;
        xYPlot24.setRangeAxisLocation((int) (short) 100, axisLocation26);
        xYPlot24.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = null;
        double double33 = numberAxis29.valueToJava2D((double) 10, rectangle2D31, rectangleEdge32);
        java.awt.Paint paint34 = numberAxis29.getTickMarkPaint();
        xYPlot24.setDomainTickBandPaint(paint34);
        java.awt.Stroke stroke36 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker38 = new org.jfree.chart.plot.IntervalMarker((double) 9, 0.0d, paint2, stroke23, paint34, stroke36, (float) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightInset(11.0d);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType4 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color7, stroke8);
        boolean boolean10 = axisLocation5.equals((java.lang.Object) valueMarker9);
        float float11 = valueMarker9.getAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        org.jfree.chart.util.UnitType unitType17 = rectangleInsets16.getUnitType();
        valueMarker9.setLabelOffset(rectangleInsets16);
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color20, stroke21);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker22.setOutlineStroke(stroke23);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType25 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker22.setLabelOffsetType(lengthAdjustmentType25);
        valueMarker9.setLabelOffsetType(lengthAdjustmentType25);
        try {
            java.awt.geom.Rectangle2D rectangle2D28 = rectangleInsets0.createAdjustedRectangle(rectangle2D3, lengthAdjustmentType4, lengthAdjustmentType25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertNotNull(lengthAdjustmentType4);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
        org.junit.Assert.assertNotNull(unitType17);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(lengthAdjustmentType25);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        xYPlot0.setRangeAxisLocation(4, axisLocation8);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = xYPlot0.getSeriesRenderingOrder();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) 0L, 10.0f, 0.0f);
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color14);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color2, stroke3);
        java.awt.Stroke stroke5 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker4.setOutlineStroke(stroke5);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker4.setLabelOffsetType(lengthAdjustmentType7);
        boolean boolean9 = xYPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker4);
        org.jfree.chart.LegendItemCollection legendItemCollection10 = xYPlot0.getFixedLegendItems();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot11.setDomainAxis((int) 'a', categoryAxis13);
        categoryPlot11.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        categoryPlot11.setDataset(0, categoryDataset17);
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot11.setNoDataMessagePaint(paint19);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot11.getDomainAxisEdge((int) (byte) 10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        categoryPlot11.rendererChanged(rendererChangeEvent23);
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection27 = categoryPlot11.getRangeMarkers((int) (byte) -1, layer26);
        java.util.Collection collection28 = xYPlot0.getRangeMarkers(layer26);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        xYPlot0.setDataset((int) (byte) 10, xYDataset30);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setDomainGridlineStroke(stroke32);
        java.awt.Paint paint34 = xYPlot0.getDomainTickBandPaint();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(lengthAdjustmentType7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNull(paint34);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot0.setInsets(rectangleInsets7);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot0.getDomainAxisEdge((int) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeMinimumSize((double) 11, false);
        numberAxis12.setAutoRangeStickyZero(true);
        double double18 = numberAxis12.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = numberAxis19.valueToJava2D((double) 10, rectangle2D21, rectangleEdge22);
        org.jfree.data.Range range24 = numberAxis19.getDefaultAutoRange();
        numberAxis12.setRange(range24, true, true);
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis12.setTickMarkPaint((java.awt.Paint) color28);
        categoryPlot0.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis12);
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.Plot plot32 = categoryPlot0.getRootPlot();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(plot32);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        org.jfree.data.Range range10 = numberAxis5.getDefaultAutoRange();
        numberAxis0.setRange(range10);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = numberAxis0.getTickUnit();
        double double13 = numberAxis0.getLabelAngle();
        java.lang.String str14 = numberAxis0.getLabel();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        xYPlot0.setRangeAxisLocation(4, axisLocation8);
        java.awt.Paint paint10 = xYPlot0.getRangeZeroBaselinePaint();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot0.getRendererForDataset(xYDataset11);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(xYItemRenderer12);
    }

//    @Test
//    public void test447() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test447");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        long long3 = day2.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate5 = day2.getSerialDate();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day2.getLastMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNotNull(serialDate5);
//    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.data.Range range5 = numberAxis0.getDefaultAutoRange();
        numberAxis0.zoomRange((double) 0L, (double) 3);
        java.lang.String str9 = numberAxis0.getLabel();
        numberAxis0.setAutoRangeMinimumSize((double) 11, false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.data.Range range5 = numberAxis0.getDefaultAutoRange();
        numberAxis0.setLabelAngle(2.0d);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj10 = null;
        boolean boolean11 = categoryAxis9.equals(obj10);
        categoryAxis9.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis9.setMaximumCategoryLabelLines(1);
        double double17 = categoryAxis9.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryAxis9.getTickLabelInsets();
        numberAxis0.setTickLabelInsets(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        boolean boolean7 = categoryPlot0.isRangeZoomable();
        categoryPlot0.setDrawSharedDomainAxis(false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.data.Range range5 = numberAxis0.getDefaultAutoRange();
        numberAxis0.zoomRange((double) 0L, (double) 3);
        boolean boolean9 = numberAxis0.isNegativeArrowVisible();
        numberAxis0.setAutoRangeStickyZero(false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYPlot0.rendererChanged(rendererChangeEvent2);
        java.awt.Paint paint4 = null;
        try {
            xYPlot0.setDomainCrosshairPaint(paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge();
        xYPlot0.zoom((double) 0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        boolean boolean7 = categoryPlot0.isRangeZoomable();
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getDomainAxisLocation();
        int int11 = categoryPlot0.getWeight();
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        xYPlot12.setRangeAxisLocation((int) (short) 100, axisLocation14);
        xYPlot12.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = numberAxis17.valueToJava2D((double) 10, rectangle2D19, rectangleEdge20);
        java.awt.Paint paint22 = numberAxis17.getTickMarkPaint();
        xYPlot12.setDomainTickBandPaint(paint22);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color27, stroke28);
        boolean boolean30 = axisLocation25.equals((java.lang.Object) valueMarker29);
        float float31 = valueMarker29.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = valueMarker29.getLabelAnchor();
        org.jfree.chart.util.Layer layer33 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange34 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean35 = layer33.equals((java.lang.Object) dateRange34);
        java.lang.String str36 = layer33.toString();
        xYPlot12.addDomainMarker((int) (short) 100, (org.jfree.chart.plot.Marker) valueMarker29, layer33);
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis();
        numberAxis38.setAutoRangeMinimumSize((double) 11, false);
        numberAxis38.setAutoRangeStickyZero(true);
        double double44 = numberAxis38.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = null;
        double double49 = numberAxis45.valueToJava2D((double) 10, rectangle2D47, rectangleEdge48);
        org.jfree.data.Range range50 = numberAxis45.getDefaultAutoRange();
        numberAxis38.setRange(range50, true, true);
        java.awt.Color color54 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis38.setTickMarkPaint((java.awt.Paint) color54);
        org.jfree.chart.axis.NumberAxis numberAxis56 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = null;
        double double60 = numberAxis56.valueToJava2D((double) 10, rectangle2D58, rectangleEdge59);
        org.jfree.chart.axis.NumberAxis numberAxis61 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D63 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = null;
        double double65 = numberAxis61.valueToJava2D((double) 10, rectangle2D63, rectangleEdge64);
        org.jfree.data.Range range66 = numberAxis61.getDefaultAutoRange();
        numberAxis56.setRange(range66);
        boolean boolean68 = color54.equals((java.lang.Object) numberAxis56);
        xYPlot12.setRangeGridlinePaint((java.awt.Paint) color54);
        xYPlot12.clearDomainMarkers();
        java.awt.Graphics2D graphics2D71 = null;
        java.awt.geom.Rectangle2D rectangle2D72 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo73 = null;
        xYPlot12.drawAnnotations(graphics2D71, rectangle2D72, plotRenderingInfo73);
        org.jfree.chart.plot.CategoryPlot categoryPlot76 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis78 = null;
        categoryPlot76.setDomainAxis((int) 'a', categoryAxis78);
        categoryPlot76.setBackgroundImageAlignment((int) (short) 10);
        float float82 = categoryPlot76.getBackgroundAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation83 = categoryPlot76.getRangeAxisLocation();
        xYPlot12.setDomainAxisLocation((int) (short) 1, axisLocation83, false);
        int int86 = xYPlot12.getWeight();
        org.jfree.chart.plot.CategoryPlot categoryPlot87 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint88 = categoryPlot87.getDomainGridlinePaint();
        java.awt.Stroke stroke89 = categoryPlot87.getDomainGridlineStroke();
        xYPlot12.setDomainZeroBaselineStroke(stroke89);
        categoryPlot0.setRangeGridlineStroke(stroke89);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 1.0f + "'", float31 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleAnchor32);
        org.junit.Assert.assertNotNull(layer33);
        org.junit.Assert.assertNotNull(dateRange34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Layer.FOREGROUND" + "'", str36.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(range50);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(range66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + float82 + "' != '" + 1.0f + "'", float82 == 1.0f);
        org.junit.Assert.assertNotNull(axisLocation83);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 1 + "'", int86 == 1);
        org.junit.Assert.assertNotNull(paint88);
        org.junit.Assert.assertNotNull(stroke89);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        float float8 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot0.getAxisOffset();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj12 = null;
        boolean boolean13 = categoryAxis11.equals(obj12);
        categoryAxis11.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis11.clearCategoryLabelToolTips();
        categoryPlot0.setDomainAxis(categoryAxis11);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation21 = null;
        try {
            categoryPlot0.setDomainAxisLocation(axisLocation21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 1.0f + "'", float8 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.data.Range range5 = numberAxis0.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis6.valueToJava2D((double) 10, rectangle2D8, rectangleEdge9);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = numberAxis11.valueToJava2D((double) 10, rectangle2D13, rectangleEdge14);
        org.jfree.data.Range range16 = numberAxis11.getDefaultAutoRange();
        numberAxis6.setRange(range16);
        numberAxis0.setDefaultAutoRange(range16);
        java.awt.Shape shape19 = numberAxis0.getDownArrow();
        boolean boolean20 = numberAxis0.isVisible();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        boolean boolean5 = numberAxis0.getAutoRangeStickyZero();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        categoryPlot6.setDataset(categoryDataset7);
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        categoryPlot6.removeChangeListener(plotChangeListener9);
        numberAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        java.awt.Font font12 = categoryPlot6.getNoDataMessageFont();
        java.awt.Paint paint13 = categoryPlot6.getNoDataMessagePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = categoryPlot6.getDomainAxisForDataset(255);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryAxis15);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj2 = null;
        boolean boolean3 = categoryAxis1.equals(obj2);
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setVisible(false);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color15, stroke16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker17.setOutlineStroke(stroke18);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType20 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker17.setLabelOffsetType(lengthAdjustmentType20);
        boolean boolean22 = xYPlot13.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker17);
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot();
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke26 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color25, stroke26);
        java.awt.Stroke stroke28 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker27.setOutlineStroke(stroke28);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType30 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker27.setLabelOffsetType(lengthAdjustmentType30);
        boolean boolean32 = xYPlot23.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker27);
        valueMarker27.setLabel("PlotOrientation.HORIZONTAL");
        boolean boolean35 = xYPlot13.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker27);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = xYPlot13.getDomainAxisEdge((int) (short) 100);
        try {
            double double38 = categoryAxis1.getCategoryEnd((int) (byte) 0, 0, rectangle2D12, rectangleEdge37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(lengthAdjustmentType20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(lengthAdjustmentType30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(rectangleEdge37);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis2.valueToJava2D((double) 10, rectangle2D4, rectangleEdge5);
        org.jfree.data.Range range7 = numberAxis2.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = numberAxis8.valueToJava2D((double) 10, rectangle2D10, rectangleEdge11);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = numberAxis13.valueToJava2D((double) 10, rectangle2D15, rectangleEdge16);
        org.jfree.data.Range range18 = numberAxis13.getDefaultAutoRange();
        numberAxis8.setRange(range18);
        numberAxis2.setDefaultAutoRange(range18);
        boolean boolean21 = objectList1.equals((java.lang.Object) numberAxis2);
        boolean boolean22 = numberAxis2.isAutoTickUnitSelection();
        boolean boolean23 = numberAxis2.isAxisLineVisible();
        double double24 = numberAxis2.getUpperMargin();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        int int2 = xYPlot0.getSeriesCount();
        org.jfree.chart.axis.ValueAxis valueAxis4 = xYPlot0.getDomainAxisForDataset((int) (byte) 0);
        java.awt.Paint paint5 = xYPlot0.getDomainCrosshairPaint();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNull(valueAxis4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis0, jFreeChart1);
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange3);
        dateAxis0.setRange((double) 7, (double) 100);
        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date9, timeZone10);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("AxisLocation.BOTTOM_OR_LEFT", timeZone10);
        java.util.Date date14 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("AxisLocation.BOTTOM_OR_LEFT", timeZone15);
        dateAxis12.setTimeZone(timeZone15);
        org.jfree.chart.axis.Timeline timeline19 = dateAxis12.getTimeline();
        dateAxis0.setTimeline(timeline19);
        try {
            dateAxis0.setRange(32.0d, (double) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(timeline19);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
        boolean boolean7 = xYPlot0.isDomainCrosshairVisible();
        boolean boolean8 = xYPlot0.isSubplot();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        int int10 = color9.getRGB();
        xYPlot0.setDomainGridlinePaint((java.awt.Paint) color9);
        boolean boolean12 = xYPlot0.isRangeZeroBaselineVisible();
        xYPlot0.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-128) + "'", int10 == (-128));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test464");
//        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
//        int int1 = xYPlot0.getDomainAxisCount();
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
//        java.awt.geom.Point2D point2D4 = null;
//        xYPlot0.zoomRangeAxes((double) 255, plotRenderingInfo3, point2D4, true);
//        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
//        categoryPlot7.setDomainAxis((int) 'a', categoryAxis9);
//        categoryPlot7.clearAnnotations();
//        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
//        categoryPlot7.setDataset(0, categoryDataset13);
//        java.awt.Paint paint15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
//        categoryPlot7.setNoDataMessagePaint(paint15);
//        java.awt.Paint paint17 = categoryPlot7.getOutlinePaint();
//        int int18 = categoryPlot7.getDomainAxisCount();
//        java.lang.Class<?> wildcardClass19 = categoryPlot7.getClass();
//        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
//        categoryPlot21.setDomainAxis((int) 'a', categoryAxis23);
//        categoryPlot21.clearAnnotations();
//        boolean boolean26 = categoryPlot21.isOutlineVisible();
//        org.jfree.chart.axis.AxisSpace axisSpace27 = categoryPlot21.getFixedDomainAxisSpace();
//        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
//        categoryPlot21.setInsets(rectangleInsets28);
//        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
//        org.jfree.chart.plot.PlotOrientation plotOrientation31 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
//        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation30, plotOrientation31);
//        org.jfree.chart.axis.CategoryAnchor categoryAnchor33 = org.jfree.chart.axis.CategoryAnchor.END;
//        boolean boolean34 = axisLocation30.equals((java.lang.Object) categoryAnchor33);
//        categoryPlot21.setRangeAxisLocation(axisLocation30, false);
//        categoryPlot7.setRangeAxisLocation((int) (short) 10, axisLocation30, false);
//        xYPlot0.setRangeAxisLocation(axisLocation30, true);
//        java.util.Date date41 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone42 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date41, timeZone42);
//        long long44 = day43.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate45 = day43.getSerialDate();
//        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis48 = null;
//        categoryPlot46.setDomainAxis((int) 'a', categoryAxis48);
//        categoryPlot46.setBackgroundImageAlignment((int) (short) 10);
//        org.jfree.data.general.DatasetGroup datasetGroup52 = categoryPlot46.getDatasetGroup();
//        java.awt.Paint paint53 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
//        categoryPlot46.setNoDataMessagePaint(paint53);
//        boolean boolean55 = day43.equals((java.lang.Object) categoryPlot46);
//        java.awt.Stroke stroke56 = categoryPlot46.getOutlineStroke();
//        boolean boolean57 = categoryPlot46.isDomainZoomable();
//        boolean boolean58 = xYPlot0.equals((java.lang.Object) categoryPlot46);
//        org.jfree.chart.plot.PlotOrientation plotOrientation59 = categoryPlot46.getOrientation();
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
//        org.junit.Assert.assertNotNull(paint15);
//        org.junit.Assert.assertNotNull(paint17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 98 + "'", int18 == 98);
//        org.junit.Assert.assertNotNull(wildcardClass19);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
//        org.junit.Assert.assertNull(axisSpace27);
//        org.junit.Assert.assertNotNull(rectangleInsets28);
//        org.junit.Assert.assertNotNull(axisLocation30);
//        org.junit.Assert.assertNotNull(plotOrientation31);
//        org.junit.Assert.assertNotNull(rectangleEdge32);
//        org.junit.Assert.assertNotNull(categoryAnchor33);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNotNull(date41);
//        org.junit.Assert.assertNotNull(timeZone42);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560409200000L + "'", long44 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertNull(datasetGroup52);
//        org.junit.Assert.assertNotNull(paint53);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertNotNull(stroke56);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
//        org.junit.Assert.assertNotNull(plotOrientation59);
//    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        categoryPlot1.setDomainAxis((int) 'a', categoryAxis3);
        categoryPlot1.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        categoryPlot1.setDataset(0, categoryDataset7);
        java.awt.Paint paint9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot1.setNoDataMessagePaint(paint9);
        java.awt.Paint paint11 = categoryPlot1.getOutlinePaint();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        java.awt.geom.AffineTransform affineTransform16 = null;
        java.awt.RenderingHints renderingHints17 = null;
        java.awt.PaintContext paintContext18 = color12.createContext(colorModel13, rectangle14, rectangle2D15, affineTransform16, renderingHints17);
        java.awt.Paint[] paintArray19 = new java.awt.Paint[] { color0, paint11, color12 };
        java.awt.Paint[] paintArray20 = null;
        java.awt.Paint[] paintArray21 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Stroke[] strokeArray22 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray23 = null;
        java.awt.Shape[] shapeArray24 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier25 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray19, paintArray20, paintArray21, strokeArray22, strokeArray23, shapeArray24);
        java.lang.Object obj26 = defaultDrawingSupplier25.clone();
        try {
            java.awt.Paint paint27 = defaultDrawingSupplier25.getNextFillPaint();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintContext18);
        org.junit.Assert.assertNotNull(paintArray19);
        org.junit.Assert.assertNotNull(paintArray21);
        org.junit.Assert.assertNotNull(strokeArray22);
        org.junit.Assert.assertNotNull(shapeArray24);
        org.junit.Assert.assertNotNull(obj26);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        java.lang.Object obj8 = null;
        boolean boolean9 = categoryAxis7.equals(obj8);
        categoryAxis7.addCategoryLabelToolTip((java.lang.Comparable) "", "RectangleAnchor.TOP_LEFT");
        categoryAxis7.setMaximumCategoryLabelLines(1);
        double double15 = categoryAxis7.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryAxis7.getTickLabelInsets();
        categoryPlot0.setDomainAxis((int) (short) 10, categoryAxis7, true);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.data.Range range20 = categoryPlot0.getDataRange(valueAxis19);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNull(range20);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        xYPlot0.setRangeZeroBaselineVisible(false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot0.setInsets(rectangleInsets7);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot0.getDomainAxisEdge((int) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeMinimumSize((double) 11, false);
        numberAxis12.setAutoRangeStickyZero(true);
        double double18 = numberAxis12.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = numberAxis19.valueToJava2D((double) 10, rectangle2D21, rectangleEdge22);
        org.jfree.data.Range range24 = numberAxis19.getDefaultAutoRange();
        numberAxis12.setRange(range24, true, true);
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis12.setTickMarkPaint((java.awt.Paint) color28);
        categoryPlot0.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis12);
        categoryPlot0.clearRangeMarkers();
        java.awt.Color color33 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke34 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color33, stroke34);
        java.awt.Stroke stroke36 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker35.setOutlineStroke(stroke36);
        java.awt.Stroke stroke38 = valueMarker35.getStroke();
        categoryPlot0.setDomainGridlineStroke(stroke38);
        categoryPlot0.setAnchorValue(100.0d, true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(stroke38);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.data.Range range5 = numberAxis0.getDefaultAutoRange();
        java.awt.Font font6 = numberAxis0.getTickLabelFont();
        numberAxis0.setAutoRangeIncludesZero(true);
        numberAxis0.setLabelToolTip("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        java.awt.Paint paint2 = xYPlot0.getRangeGridlinePaint();
        boolean boolean3 = xYPlot0.isDomainCrosshairLockedOnData();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        xYPlot0.zoomRangeAxes((double) 43629L, (double) 10L, plotRenderingInfo6, point2D7);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        java.awt.Paint paint2 = xYPlot0.getRangeGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getDomainAxisLocation(5);
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = xYPlot0.getDomainAxis();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(valueAxis7);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        categoryPlot0.setDataset(categoryDataset1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        categoryPlot0.removeChangeListener(plotChangeListener3);
        categoryPlot0.clearRangeAxes();
    }

//    @Test
//    public void test475() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test475");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone1 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
//        long long3 = day2.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
//        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
//        categoryPlot5.setDomainAxis((int) 'a', categoryAxis7);
//        categoryPlot5.setBackgroundImageAlignment((int) (short) 10);
//        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot5.getDatasetGroup();
//        java.awt.Paint paint12 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
//        categoryPlot5.setNoDataMessagePaint(paint12);
//        boolean boolean14 = day2.equals((java.lang.Object) categoryPlot5);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day2.previous();
//        int int16 = day2.getYear();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(timeZone1);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertNull(datasetGroup11);
//        org.junit.Assert.assertNotNull(paint12);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 2019 + "'", int16 == 2019);
//    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder2 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        xYPlot0.setSeriesRenderingOrder(seriesRenderingOrder2);
        int int4 = xYPlot0.getWeight();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(seriesRenderingOrder2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot0.setInsets(rectangleInsets7);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot0.getDomainAxisEdge((int) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        numberAxis12.setAutoRangeMinimumSize((double) 11, false);
        numberAxis12.setAutoRangeStickyZero(true);
        double double18 = numberAxis12.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = numberAxis19.valueToJava2D((double) 10, rectangle2D21, rectangleEdge22);
        org.jfree.data.Range range24 = numberAxis19.getDefaultAutoRange();
        numberAxis12.setRange(range24, true, true);
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis12.setTickMarkPaint((java.awt.Paint) color28);
        categoryPlot0.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis12);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = null;
        double double35 = numberAxis31.valueToJava2D((double) 10, rectangle2D33, rectangleEdge34);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = null;
        double double40 = numberAxis36.valueToJava2D((double) 10, rectangle2D38, rectangleEdge39);
        org.jfree.data.Range range41 = numberAxis36.getDefaultAutoRange();
        numberAxis31.setRangeWithMargins(range41, true, true);
        java.text.NumberFormat numberFormat45 = numberAxis31.getNumberFormatOverride();
        java.text.NumberFormat numberFormat46 = numberAxis31.getNumberFormatOverride();
        java.awt.Font font47 = numberAxis31.getTickLabelFont();
        java.util.TimeZone timeZone48 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.chart.axis.TickUnitSource tickUnitSource49 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone48);
        numberAxis31.setStandardTickUnits(tickUnitSource49);
        numberAxis12.setStandardTickUnits(tickUnitSource49);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertNull(numberFormat45);
        org.junit.Assert.assertNull(numberFormat46);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNotNull(timeZone48);
        org.junit.Assert.assertNotNull(tickUnitSource49);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        java.util.List list9 = numberAxis0.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge8);
        numberAxis0.setRangeAboutValue((double) (short) -1, (double) (byte) 1);
        float float13 = numberAxis0.getTickMarkOutsideLength();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 2.0f + "'", float13 == 2.0f);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        int int1 = xYPlot0.getDomainAxisCount();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        xYPlot0.rendererChanged(rendererChangeEvent2);
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = xYPlot0.getDomainAxisEdge();
        java.util.List list5 = xYPlot0.getAnnotations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        float float6 = categoryPlot0.getBackgroundAlpha();
        java.lang.String str7 = categoryPlot0.getPlotType();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        double double14 = rectangleInsets12.calculateLeftInset((double) (-1));
        double double15 = rectangleInsets12.getBottom();
        org.jfree.data.general.Dataset dataset16 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent17 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) double15, dataset16);
        categoryPlot0.datasetChanged(datasetChangeEvent17);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot();
        int int23 = xYPlot22.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = xYPlot22.getRangeAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        categoryPlot25.setDomainAxis((int) 'a', categoryAxis27);
        categoryPlot25.clearAnnotations();
        boolean boolean30 = categoryPlot25.isOutlineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace31 = categoryPlot25.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot25.setInsets(rectangleInsets32);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot25.getDomainAxisEdge((int) (short) -1);
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        numberAxis37.setAutoRangeMinimumSize((double) 11, false);
        numberAxis37.setAutoRangeStickyZero(true);
        double double43 = numberAxis37.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = null;
        double double48 = numberAxis44.valueToJava2D((double) 10, rectangle2D46, rectangleEdge47);
        org.jfree.data.Range range49 = numberAxis44.getDefaultAutoRange();
        numberAxis37.setRange(range49, true, true);
        java.awt.Color color53 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis37.setTickMarkPaint((java.awt.Paint) color53);
        categoryPlot25.setRangeAxis(11, (org.jfree.chart.axis.ValueAxis) numberAxis37);
        categoryPlot25.clearRangeMarkers();
        java.awt.Color color58 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke59 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker60 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color58, stroke59);
        java.awt.Stroke stroke61 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker60.setOutlineStroke(stroke61);
        java.awt.Stroke stroke63 = valueMarker60.getStroke();
        categoryPlot25.setDomainGridlineStroke(stroke63);
        xYPlot22.setRangeGridlineStroke(stroke63);
        org.jfree.chart.axis.NumberAxis numberAxis67 = new org.jfree.chart.axis.NumberAxis();
        numberAxis67.setAutoRangeMinimumSize((double) 11, false);
        numberAxis67.setAutoRangeStickyZero(true);
        double double73 = numberAxis67.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis74 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D76 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge77 = null;
        double double78 = numberAxis74.valueToJava2D((double) 10, rectangle2D76, rectangleEdge77);
        org.jfree.data.Range range79 = numberAxis74.getDefaultAutoRange();
        numberAxis67.setRange(range79, true, true);
        xYPlot22.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis67);
        org.jfree.chart.plot.CategoryPlot categoryPlot84 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis86 = null;
        categoryPlot84.setDomainAxis((int) 'a', categoryAxis86);
        categoryPlot84.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset90 = null;
        categoryPlot84.setDataset(0, categoryDataset90);
        float float92 = categoryPlot84.getForegroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets93 = categoryPlot84.getAxisOffset();
        java.awt.Color color94 = java.awt.Color.red;
        categoryPlot84.setRangeGridlinePaint((java.awt.Paint) color94);
        xYPlot22.setDomainCrosshairPaint((java.awt.Paint) color94);
        java.awt.geom.Point2D point2D97 = xYPlot22.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes((double) 0L, 52.0d, plotRenderingInfo21, point2D97);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Category Plot" + "'", str7.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 32.0d + "'", double14 == 32.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(axisSpace31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(range49);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertNotNull(range79);
        org.junit.Assert.assertTrue("'" + float92 + "' != '" + 1.0f + "'", float92 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets93);
        org.junit.Assert.assertNotNull(color94);
        org.junit.Assert.assertNotNull(point2D97);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        float float6 = categoryPlot0.getBackgroundAlpha();
        java.lang.String str7 = categoryPlot0.getPlotType();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        try {
            categoryPlot0.setRenderer((int) (byte) -1, categoryItemRenderer9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "Category Plot" + "'", str7.equals("Category Plot"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        numberAxis0.setAutoRangeMinimumSize(52.0d, true);
        java.awt.Shape shape8 = numberAxis0.getRightArrow();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeMinimumSize((double) 11, false);
        numberAxis0.setAutoRangeStickyZero(true);
        double double6 = numberAxis0.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = numberAxis7.valueToJava2D((double) 10, rectangle2D9, rectangleEdge10);
        org.jfree.data.Range range12 = numberAxis7.getDefaultAutoRange();
        numberAxis0.setRange(range12, true, true);
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis0.setTickMarkPaint((java.awt.Paint) color16);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = numberAxis18.valueToJava2D((double) 10, rectangle2D20, rectangleEdge21);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = numberAxis23.valueToJava2D((double) 10, rectangle2D25, rectangleEdge26);
        org.jfree.data.Range range28 = numberAxis23.getDefaultAutoRange();
        numberAxis18.setRange(range28);
        boolean boolean30 = color16.equals((java.lang.Object) numberAxis18);
        boolean boolean31 = numberAxis18.isInverted();
        numberAxis18.setUpperBound((double) 0L);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(0, categoryDataset6);
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        java.awt.Paint paint10 = categoryPlot0.getOutlinePaint();
        int int11 = categoryPlot0.getDomainAxisCount();
        java.lang.Class<?> wildcardClass12 = categoryPlot0.getClass();
        java.lang.Class class13 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        java.lang.Class class14 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass12);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 98 + "'", int11 == 98);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(class13);
        org.junit.Assert.assertNotNull(class14);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        float[] floatArray7 = new float[] { 255, (short) 100, 100.0f, 1L, (short) 0, 'a' };
        float[] floatArray8 = color0.getRGBColorComponents(floatArray7);
        java.awt.Color color9 = color0.brighter();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.mapDatasetToDomainAxis((int) (byte) 100, 1);
        int int4 = xYPlot0.getWeight();
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot0.setRangeAxisLocation(7, axisLocation6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.mapDatasetToDomainAxis((int) (byte) 100, 1);
        org.jfree.data.general.Dataset dataset5 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent6 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) 2, dataset5);
        xYPlot0.datasetChanged(datasetChangeEvent6);
        java.lang.Object obj8 = datasetChangeEvent6.getSource();
        org.junit.Assert.assertTrue("'" + obj8 + "' != '" + 2 + "'", obj8.equals(2));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setRange((double) (byte) 10, 100.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = null;
        dateAxis0.setTickUnit(dateTickUnit4);
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = null;
        dateAxis0.setTickUnit(dateTickUnit6, false, false);
        boolean boolean10 = dateAxis0.isVerticalTickLabels();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("hi!", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        xYPlot1.setRangeAxisLocation((int) (short) 100, axisLocation3);
        xYPlot1.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis6.valueToJava2D((double) 10, rectangle2D8, rectangleEdge9);
        java.awt.Paint paint11 = numberAxis6.getTickMarkPaint();
        xYPlot1.setDomainTickBandPaint(paint11);
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color16, stroke17);
        boolean boolean19 = axisLocation14.equals((java.lang.Object) valueMarker18);
        float float20 = valueMarker18.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = valueMarker18.getLabelAnchor();
        org.jfree.chart.util.Layer layer22 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange23 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean24 = layer22.equals((java.lang.Object) dateRange23);
        java.lang.String str25 = layer22.toString();
        xYPlot1.addDomainMarker((int) (short) 100, (org.jfree.chart.plot.Marker) valueMarker18, layer22);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        numberAxis27.setAutoRangeMinimumSize((double) 11, false);
        numberAxis27.setAutoRangeStickyZero(true);
        double double33 = numberAxis27.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = null;
        double double38 = numberAxis34.valueToJava2D((double) 10, rectangle2D36, rectangleEdge37);
        org.jfree.data.Range range39 = numberAxis34.getDefaultAutoRange();
        numberAxis27.setRange(range39, true, true);
        java.awt.Color color43 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis27.setTickMarkPaint((java.awt.Paint) color43);
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = null;
        double double49 = numberAxis45.valueToJava2D((double) 10, rectangle2D47, rectangleEdge48);
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = null;
        double double54 = numberAxis50.valueToJava2D((double) 10, rectangle2D52, rectangleEdge53);
        org.jfree.data.Range range55 = numberAxis50.getDefaultAutoRange();
        numberAxis45.setRange(range55);
        boolean boolean57 = color43.equals((java.lang.Object) numberAxis45);
        xYPlot1.setRangeGridlinePaint((java.awt.Paint) color43);
        xYPlot1.clearDomainMarkers();
        java.awt.Graphics2D graphics2D60 = null;
        java.awt.geom.Rectangle2D rectangle2D61 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo62 = null;
        xYPlot1.drawAnnotations(graphics2D60, rectangle2D61, plotRenderingInfo62);
        org.jfree.chart.plot.XYPlot xYPlot64 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation66 = null;
        xYPlot64.setRangeAxisLocation((int) (short) 100, axisLocation66);
        org.jfree.chart.axis.NumberAxis numberAxis69 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D71 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = null;
        double double73 = numberAxis69.valueToJava2D((double) 10, rectangle2D71, rectangleEdge72);
        org.jfree.data.Range range74 = numberAxis69.getDefaultAutoRange();
        numberAxis69.zoomRange((double) 0L, (double) 3);
        boolean boolean78 = numberAxis69.isNegativeArrowVisible();
        xYPlot64.setDomainAxis(255, (org.jfree.chart.axis.ValueAxis) numberAxis69, false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder81 = xYPlot64.getDatasetRenderingOrder();
        xYPlot1.setDatasetRenderingOrder(datasetRenderingOrder81);
        boolean boolean83 = lengthAdjustmentType0.equals((java.lang.Object) xYPlot1);
        java.lang.String str84 = lengthAdjustmentType0.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
        org.junit.Assert.assertNotNull(layer22);
        org.junit.Assert.assertNotNull(dateRange23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "Layer.FOREGROUND" + "'", str25.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(range55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(range74);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder81);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "CONTRACT" + "'", str84.equals("CONTRACT"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        xYPlot0.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis5.getTickMarkPaint();
        xYPlot0.setDomainTickBandPaint(paint10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color15, stroke16);
        boolean boolean18 = axisLocation13.equals((java.lang.Object) valueMarker17);
        float float19 = valueMarker17.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = valueMarker17.getLabelAnchor();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean23 = layer21.equals((java.lang.Object) dateRange22);
        java.lang.String str24 = layer21.toString();
        xYPlot0.addDomainMarker((int) (short) 100, (org.jfree.chart.plot.Marker) valueMarker17, layer21);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        numberAxis26.setAutoRangeMinimumSize((double) 11, false);
        numberAxis26.setAutoRangeStickyZero(true);
        double double32 = numberAxis26.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        double double37 = numberAxis33.valueToJava2D((double) 10, rectangle2D35, rectangleEdge36);
        org.jfree.data.Range range38 = numberAxis33.getDefaultAutoRange();
        numberAxis26.setRange(range38, true, true);
        java.awt.Color color42 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        numberAxis26.setTickMarkPaint((java.awt.Paint) color42);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = null;
        double double48 = numberAxis44.valueToJava2D((double) 10, rectangle2D46, rectangleEdge47);
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = null;
        double double53 = numberAxis49.valueToJava2D((double) 10, rectangle2D51, rectangleEdge52);
        org.jfree.data.Range range54 = numberAxis49.getDefaultAutoRange();
        numberAxis44.setRange(range54);
        boolean boolean56 = color42.equals((java.lang.Object) numberAxis44);
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color42);
        org.jfree.chart.plot.Plot plot58 = xYPlot0.getRootPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder59 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.axis.ValueAxis valueAxis60 = xYPlot0.getRangeAxis();
        org.jfree.chart.axis.DateAxis dateAxis61 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.JFreeChart jFreeChart62 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent63 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis61, jFreeChart62);
        dateAxis61.zoomRange((double) (byte) -1, 0.05d);
        java.util.Date date67 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone68 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day69 = new org.jfree.data.time.Day(date67, timeZone68);
        dateAxis61.setMinimumDate(date67);
        xYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis61);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Layer.FOREGROUND" + "'", str24.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(plot58);
        org.junit.Assert.assertNotNull(seriesRenderingOrder59);
        org.junit.Assert.assertNull(valueAxis60);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertNotNull(timeZone68);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color2, stroke3);
        boolean boolean5 = axisLocation0.equals((java.lang.Object) valueMarker4);
        float float6 = valueMarker4.getAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets((double) '4', (double) ' ', (double) (short) 0, (double) 11);
        org.jfree.chart.util.UnitType unitType12 = rectangleInsets11.getUnitType();
        valueMarker4.setLabelOffset(rectangleInsets11);
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color15, stroke16);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        valueMarker17.setOutlineStroke(stroke18);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType20 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        valueMarker17.setLabelOffsetType(lengthAdjustmentType20);
        valueMarker4.setLabelOffsetType(lengthAdjustmentType20);
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_RED;
        int int24 = color23.getRed();
        valueMarker4.setOutlinePaint((java.awt.Paint) color23);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        valueMarker4.setLabelAnchor(rectangleAnchor26);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 1.0f + "'", float6 == 1.0f);
        org.junit.Assert.assertNotNull(unitType12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(lengthAdjustmentType20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 255 + "'", int24 == 255);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis((int) 'a', categoryAxis2);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        org.jfree.data.general.DatasetGroup datasetGroup6 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = categoryPlot0.getRenderer();
        java.util.List list8 = categoryPlot0.getCategories();
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNull(categoryItemRenderer7);
        org.junit.Assert.assertNull(list8);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = numberAxis0.valueToJava2D((double) 10, rectangle2D2, rectangleEdge3);
        org.jfree.data.Range range5 = numberAxis0.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = numberAxis6.valueToJava2D((double) 10, rectangle2D8, rectangleEdge9);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = numberAxis11.valueToJava2D((double) 10, rectangle2D13, rectangleEdge14);
        org.jfree.data.Range range16 = numberAxis11.getDefaultAutoRange();
        numberAxis6.setRange(range16);
        numberAxis0.setDefaultAutoRange(range16);
        java.awt.Shape shape19 = numberAxis0.getDownArrow();
        boolean boolean20 = numberAxis0.isInverted();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis0, jFreeChart1);
        org.jfree.data.time.DateRange dateRange3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRange((org.jfree.data.Range) dateRange3);
        dateAxis0.setRange((double) 7, (double) 100);
        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone10 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date9, timeZone10);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis("AxisLocation.BOTTOM_OR_LEFT", timeZone10);
        java.util.Date date14 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14, timeZone15);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("AxisLocation.BOTTOM_OR_LEFT", timeZone15);
        dateAxis12.setTimeZone(timeZone15);
        org.jfree.chart.axis.Timeline timeline19 = dateAxis12.getTimeline();
        dateAxis0.setTimeline(timeline19);
        org.jfree.data.Range range21 = null;
        try {
            dateAxis0.setRange(range21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateRange3);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone10);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNotNull(timeline19);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoRangeMinimumSize((double) 11, false);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color5, stroke6);
        numberAxis0.setLabelPaint((java.awt.Paint) color5);
        numberAxis0.setPositiveArrowVisible(true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = numberAxis0.getTickUnit();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = numberAxis12.valueToJava2D((double) 10, rectangle2D14, rectangleEdge15);
        org.jfree.data.Range range17 = numberAxis12.getDefaultAutoRange();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = numberAxis18.valueToJava2D((double) 10, rectangle2D20, rectangleEdge21);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = numberAxis23.valueToJava2D((double) 10, rectangle2D25, rectangleEdge26);
        org.jfree.data.Range range28 = numberAxis23.getDefaultAutoRange();
        numberAxis18.setRange(range28);
        numberAxis12.setDefaultAutoRange(range28);
        numberAxis12.setAutoRangeMinimumSize((double) 1, true);
        org.jfree.data.Range range34 = numberAxis12.getDefaultAutoRange();
        numberAxis0.setRangeWithMargins(range34, true, false);
        numberAxis0.setAutoTickUnitSelection(true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(numberTickUnit11);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(range34);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        xYPlot0.setRangeAxisLocation((int) (short) 100, axisLocation2);
        xYPlot0.clearAnnotations();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = numberAxis5.valueToJava2D((double) 10, rectangle2D7, rectangleEdge8);
        java.awt.Paint paint10 = numberAxis5.getTickMarkPaint();
        xYPlot0.setDomainTickBandPaint(paint10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Stroke stroke16 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker17 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, (java.awt.Paint) color15, stroke16);
        boolean boolean18 = axisLocation13.equals((java.lang.Object) valueMarker17);
        float float19 = valueMarker17.getAlpha();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = valueMarker17.getLabelAnchor();
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.data.time.DateRange dateRange22 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        boolean boolean23 = layer21.equals((java.lang.Object) dateRange22);
        java.lang.String str24 = layer21.toString();
        xYPlot0.addDomainMarker((int) (short) 100, (org.jfree.chart.plot.Marker) valueMarker17, layer21);
        java.awt.Paint paint26 = xYPlot0.getRangeZeroBaselinePaint();
        java.awt.Paint paint27 = xYPlot0.getBackgroundPaint();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertNotNull(dateRange22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Layer.FOREGROUND" + "'", str24.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint27);
    }
}

