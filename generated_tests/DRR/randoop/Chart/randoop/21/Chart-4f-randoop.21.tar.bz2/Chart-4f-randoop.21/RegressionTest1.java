import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean4 = xYLineAndShapeRenderer3.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer3.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke8 = xYLineAndShapeRenderer3.getBaseOutlineStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYLineAndShapeRenderer3.getBasePositiveItemLabelPosition();
        java.awt.Shape shape10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity17 = new org.jfree.chart.entity.PieSectionEntity(shape10, pieDataset11, 1, (int) (short) -1, (java.lang.Comparable) 3, "hi!", "index.html");
        xYLineAndShapeRenderer3.setBaseShape(shape10, true);
        int int20 = combinedRangeXYPlot0.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer3);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("EXPAND");
        combinedRangeXYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis22);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor25 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean27 = textBlockAnchor25.equals((java.lang.Object) chartRenderingInfo26);
        java.awt.geom.Rectangle2D rectangle2D28 = chartRenderingInfo26.getChartArea();
        org.jfree.chart.entity.EntityCollection entityCollection29 = chartRenderingInfo26.getEntityCollection();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor30 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean32 = textBlockAnchor30.equals((java.lang.Object) chartRenderingInfo31);
        java.awt.geom.Rectangle2D rectangle2D33 = chartRenderingInfo31.getChartArea();
        chartRenderingInfo26.setChartArea(rectangle2D33);
        try {
            combinedRangeXYPlot0.drawBackground(graphics2D24, rectangle2D33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(textBlockAnchor25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertNotNull(entityCollection29);
        org.junit.Assert.assertNotNull(textBlockAnchor30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangle2D33);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor2 = timeSeriesCollection1.getXPosition();
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.junit.Assert.assertNotNull(timePeriodAnchor2);
        org.junit.Assert.assertNull(number3);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        java.awt.Paint paint0 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_ALTERNATE_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder(paint0);
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        piePlot1.setLabelLinkPaint(paint2);
        double double4 = piePlot1.getLabelLinkMargin();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean6 = xYLineAndShapeRenderer5.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint8 = xYLineAndShapeRenderer5.lookupLegendTextPaint((int) (short) 100);
        boolean boolean9 = xYLineAndShapeRenderer5.getBaseLinesVisible();
        java.awt.Stroke stroke13 = xYLineAndShapeRenderer5.getItemOutlineStroke(6, (-4145152), true);
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.color.ColorSpace colorSpace17 = color16.getColorSpace();
        boolean boolean19 = color16.equals((java.lang.Object) 'a');
        java.awt.Color color20 = java.awt.Color.getColor("ERROR : Relative To String", color16);
        xYLineAndShapeRenderer5.setSeriesItemLabelPaint(7, (java.awt.Paint) color20, true);
        piePlot1.setLabelShadowPaint((java.awt.Paint) color20);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.025d + "'", double4 == 0.025d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(colorSpace17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesStroke(false);
        barRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray8 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray8);
        org.jfree.data.Range range10 = barRenderer5.findRangeBounds(categoryDataset9);
        org.jfree.data.Range range11 = barRenderer0.findRangeBounds(categoryDataset9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection17, valueAxis18, polarItemRenderer19);
        polarPlot20.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = polarPlot20.getOrientation();
        combinedRangeXYPlot15.setOrientation(plotOrientation23);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer25 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean26 = xYLineAndShapeRenderer25.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer25.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke30 = xYLineAndShapeRenderer25.getBaseOutlineStroke();
        java.awt.Stroke stroke32 = xYLineAndShapeRenderer25.lookupSeriesStroke(4);
        combinedRangeXYPlot15.setDomainCrosshairStroke(stroke32);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        numberAxis34.setFixedAutoRange((double) 9);
        combinedRangeXYPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis34);
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis34.setLeftArrow(shape39);
        java.text.NumberFormat numberFormat41 = java.text.NumberFormat.getNumberInstance();
        boolean boolean42 = numberFormat41.isParseIntegerOnly();
        numberAxis34.setNumberFormatOverride(numberFormat41);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis34, categoryItemRenderer44);
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        categoryPlot45.setRangeAxis((int) (byte) 100, valueAxis47);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent49 = null;
        categoryPlot45.markerChanged(markerChangeEvent49);
        categoryPlot45.setRangeZeroBaselineVisible(false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(numberFormat41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke5 = xYLineAndShapeRenderer0.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath8 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean11 = textBlockAnchor9.equals((java.lang.Object) chartRenderingInfo10);
        java.awt.geom.Rectangle2D rectangle2D12 = chartRenderingInfo10.getChartArea();
        org.jfree.chart.RenderingSource renderingSource13 = null;
        combinedRangeXYPlot7.select(generalPath8, rectangle2D12, renderingSource13);
        org.jfree.chart.plot.XYPlot xYPlot15 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset16 = new org.jfree.data.xy.DefaultXYDataset();
        int int18 = defaultXYDataset16.indexOf((java.lang.Comparable) 0.5f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState20 = xYLineAndShapeRenderer0.initialise(graphics2D6, rectangle2D12, xYPlot15, (org.jfree.data.xy.XYDataset) defaultXYDataset16, plotRenderingInfo19);
        org.jfree.chart.JFreeChart jFreeChart21 = null;
        try {
            org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity23 = new org.jfree.chart.entity.JFreeChartEntity((java.awt.Shape) rectangle2D12, jFreeChart21, "EXPAND");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'chart' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState20);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) waferMapPlot0);
        boolean boolean2 = legendTitle1.visible;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_GREEN;
        legendTitle1.setItemPaint((java.awt.Paint) color3);
        java.lang.Object obj5 = legendTitle1.clone();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.data.Range range8 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((double) (-1), range8);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType10 = rectangleConstraint9.getWidthConstraintType();
        org.jfree.data.Range range11 = rectangleConstraint9.getWidthRange();
        org.jfree.data.Range range13 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint(0.2d, range13);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = rectangleConstraint9.toRangeWidth(range13);
        try {
            org.jfree.chart.util.Size2D size2D16 = legendTitle1.arrange(graphics2D6, rectangleConstraint9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(lengthConstraintType10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(rectangleConstraint15);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (-1), range1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toUnconstrainedHeight();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint4.toRangeWidth((org.jfree.data.Range) dateRange5);
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(rectangleConstraint6);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.data.Range range2 = combinedRangeXYPlot0.getDataRange(valueAxis1);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot3.setDomainZeroBaselineVisible(false);
        org.jfree.chart.plot.Marker marker7 = null;
        org.jfree.chart.util.Layer layer8 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean10 = combinedRangeXYPlot3.removeDomainMarker((int) (short) 0, marker7, layer8, false);
        java.util.Collection collection11 = combinedRangeXYPlot0.getRangeMarkers(layer8);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(layer8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(collection11);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, (double) (short) 10);
        boolean boolean6 = columnArrangement4.equals((java.lang.Object) "index.html");
        columnArrangement4.clear();
        org.jfree.chart.block.Block block8 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot10 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) waferMapPlot10);
        java.awt.Font font12 = legendTitle11.getItemFont();
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("DateTickUnitType.SECOND", font12);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Font font16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer14.setLegendTextFont((int) '#', font16);
        textTitle13.setFont(font16);
        java.awt.Paint paint19 = textTitle13.getBackgroundPaint();
        java.awt.Font font20 = textTitle13.getFont();
        textTitle13.setVisible(false);
        columnArrangement4.add(block8, (java.lang.Object) false);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNotNull(font20);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Color color1 = java.awt.Color.yellow;
        combinedRangeXYPlot0.setDomainZeroBaselinePaint((java.awt.Paint) color1);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        int int2 = piePlot1.getPieIndex();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        piePlot1.notifyListeners(plotChangeEvent3);
        java.awt.Shape shape5 = piePlot1.getLegendItemShape();
        java.awt.Image image6 = null;
        piePlot1.setBackgroundImage(image6);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setStartAngle(1.0d);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor4 = piePlot1.getLabelDistributor();
        piePlot1.setStartAngle((double) 1);
        boolean boolean7 = piePlot1.getAutoPopulateSectionPaint();
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        double double3 = timeSeriesCollection1.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean7 = xYLineAndShapeRenderer6.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer6.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke11 = xYLineAndShapeRenderer6.getBaseOutlineStroke();
        java.awt.Stroke stroke13 = xYLineAndShapeRenderer6.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, valueAxis5, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer6);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = xYPlot14.getInsets();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYPlot14.setNoDataMessagePaint((java.awt.Paint) color16);
        org.jfree.chart.axis.LogAxis logAxis18 = new org.jfree.chart.axis.LogAxis();
        boolean boolean19 = logAxis18.isTickMarksVisible();
        java.awt.Paint paint20 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder(paint20);
        java.awt.Paint paint22 = blockBorder21.getPaint();
        logAxis18.setTickMarkPaint(paint22);
        int int24 = xYPlot14.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis18);
        xYPlot14.clearRangeMarkers();
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        xYPlot14.setFixedDomainAxisSpace(axisSpace26, false);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setStartAngle(1.0d);
        java.awt.Image image4 = null;
        piePlot1.setBackgroundImage(image4);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        piePlot7.setStartAngle(1.0d);
        java.awt.Image image10 = null;
        piePlot7.setBackgroundImage(image10);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator12 = piePlot7.getLegendLabelGenerator();
        piePlot1.setLabelGenerator(pieSectionLabelGenerator12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor15 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean17 = textBlockAnchor15.equals((java.lang.Object) chartRenderingInfo16);
        java.awt.geom.Rectangle2D rectangle2D18 = chartRenderingInfo16.getChartArea();
        org.jfree.chart.entity.EntityCollection entityCollection19 = chartRenderingInfo16.getEntityCollection();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor20 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean22 = textBlockAnchor20.equals((java.lang.Object) chartRenderingInfo21);
        java.awt.geom.Rectangle2D rectangle2D23 = chartRenderingInfo21.getChartArea();
        chartRenderingInfo16.setChartArea(rectangle2D23);
        java.awt.geom.Point2D point2D25 = null;
        org.jfree.chart.plot.PlotState plotState26 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor27 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean29 = textBlockAnchor27.equals((java.lang.Object) chartRenderingInfo28);
        java.awt.geom.Rectangle2D rectangle2D30 = chartRenderingInfo28.getChartArea();
        org.jfree.chart.entity.EntityCollection entityCollection31 = chartRenderingInfo28.getEntityCollection();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor32 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo33 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean34 = textBlockAnchor32.equals((java.lang.Object) chartRenderingInfo33);
        java.awt.geom.Rectangle2D rectangle2D35 = chartRenderingInfo33.getChartArea();
        chartRenderingInfo28.setChartArea(rectangle2D35);
        java.util.TimeZone timeZone37 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection38 = new org.jfree.data.time.TimeSeriesCollection(timeZone37);
        double double40 = timeSeriesCollection38.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer43 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean44 = xYLineAndShapeRenderer43.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer43.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke48 = xYLineAndShapeRenderer43.getBaseOutlineStroke();
        java.awt.Stroke stroke50 = xYLineAndShapeRenderer43.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot51 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection38, valueAxis41, valueAxis42, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer43);
        org.jfree.chart.block.LineBorder lineBorder53 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint54 = lineBorder53.getPaint();
        xYLineAndShapeRenderer43.setSeriesItemLabelPaint((int) (short) 0, paint54, false);
        boolean boolean57 = chartRenderingInfo28.equals((java.lang.Object) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = chartRenderingInfo28.getPlotInfo();
        try {
            piePlot1.draw(graphics2D14, rectangle2D23, point2D25, plotState26, plotRenderingInfo58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator12);
        org.junit.Assert.assertNotNull(textBlockAnchor15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(entityCollection19);
        org.junit.Assert.assertNotNull(textBlockAnchor20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(textBlockAnchor27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangle2D30);
        org.junit.Assert.assertNotNull(entityCollection31);
        org.junit.Assert.assertNotNull(textBlockAnchor32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(rectangle2D35);
        org.junit.Assert.assertEquals((double) double40, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo58);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        boolean boolean5 = polarPlot4.isRadiusGridlinesVisible();
        org.jfree.chart.axis.TickUnit tickUnit6 = polarPlot4.getAngleTickUnit();
        int int7 = polarPlot4.getSeriesCount();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(tickUnit6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        polarPlot5.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = polarPlot5.getOrientation();
        combinedRangeXYPlot0.setOrientation(plotOrientation8);
        combinedRangeXYPlot0.setRangeCrosshairValue(0.0d);
        boolean boolean12 = combinedRangeXYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisSpace axisSpace13 = new org.jfree.chart.axis.AxisSpace();
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace13);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) 1.0d);
        combinedRangeXYPlot0.rendererChanged(rendererChangeEvent16);
        java.util.List list19 = null;
        try {
            combinedRangeXYPlot0.mapDatasetToDomainAxes((int) (byte) 100, list19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        int int0 = org.jfree.chart.renderer.xy.XYStepAreaRenderer.AREA_AND_SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        try {
            dateAxis0.zoomRange((double) (short) 10, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (10.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        java.util.Locale locale0 = null;
        org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale0);
        org.junit.Assert.assertNotNull(tickUnitSource1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke5 = xYLineAndShapeRenderer0.getBaseOutlineStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYLineAndShapeRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        xYLineAndShapeRenderer0.setBaseShape(shape7, true);
        org.jfree.chart.LegendItem legendItem12 = xYLineAndShapeRenderer0.getLegendItem(0, 9);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNull(legendItem12);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        piePlot1.setLabelLinkPaint(paint2);
        double double4 = piePlot1.getLabelLinkMargin();
        java.awt.Paint paint5 = null;
        try {
            piePlot1.setBaseSectionPaint(paint5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.025d + "'", double4 == 0.025d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 7, (int) (short) 100, (int) (short) 1);
        segmentedTimeline3.setAdjustForDaylightSaving(false);
        segmentedTimeline3.addException((long) (byte) 100);
        boolean boolean8 = segmentedTimeline3.getAdjustForDaylightSaving();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 0L, 0.025d);
        size2D2.setHeight((double) (short) 100);
        org.jfree.chart.axis.NumberAxis numberAxis5 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot10 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) waferMapPlot10);
        java.awt.Font font12 = legendTitle11.getItemFont();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand13 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis5, (-6.0d), (double) (byte) 100, (double) (-1L), 4.0d, font12);
        boolean boolean14 = size2D2.equals((java.lang.Object) markerAxisBand13);
        double double15 = size2D2.getWidth();
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        double double3 = timeSeriesCollection1.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean7 = xYLineAndShapeRenderer6.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer6.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke11 = xYLineAndShapeRenderer6.getBaseOutlineStroke();
        java.awt.Stroke stroke13 = xYLineAndShapeRenderer6.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, valueAxis5, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer6);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = xYPlot14.getInsets();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYPlot14.setNoDataMessagePaint((java.awt.Paint) color16);
        org.jfree.chart.axis.LogAxis logAxis18 = new org.jfree.chart.axis.LogAxis();
        boolean boolean19 = logAxis18.isTickMarksVisible();
        java.awt.Paint paint20 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder(paint20);
        java.awt.Paint paint22 = blockBorder21.getPaint();
        logAxis18.setTickMarkPaint(paint22);
        int int24 = xYPlot14.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis18);
        java.text.NumberFormat numberFormat26 = java.text.NumberFormat.getNumberInstance();
        boolean boolean27 = numberFormat26.isParseIntegerOnly();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit28 = new org.jfree.chart.axis.NumberTickUnit((double) 1, numberFormat26);
        logAxis18.setTickUnit(numberTickUnit28, false, false);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(numberFormat26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.setDomainZeroBaselineVisible(false);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean7 = combinedRangeXYPlot0.removeDomainMarker((int) (short) 0, marker4, layer5, false);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation9 = axisLocation8.getOpposite();
        combinedRangeXYPlot0.setDomainAxisLocation(axisLocation9, false);
        int int12 = combinedRangeXYPlot0.getRangeAxisCount();
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        int int2 = piePlot1.getPieIndex();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent3 = null;
        piePlot1.axisChanged(axisChangeEvent3);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator5 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getXOffset();
        java.awt.Stroke stroke5 = barRenderer3D0.getItemOutlineStroke((-4145152), (int) '#', true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.0d + "'", double1 == 12.0d);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.setDomainZeroBaselineVisible(false);
        combinedRangeXYPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection(timeZone7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection8, valueAxis9, polarItemRenderer10);
        polarPlot11.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = polarPlot11.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation6, plotOrientation14);
        try {
            combinedRangeXYPlot0.setDomainAxisLocation((int) (byte) -1, axisLocation6, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        int int2 = piePlot1.getPieIndex();
        double double3 = piePlot1.getMaximumLabelWidth();
        piePlot1.setMaximumLabelWidth((double) (byte) 0);
        piePlot1.setInteriorGap(0.0d);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_YELLOW;
        piePlot1.setLabelPaint((java.awt.Paint) color8);
        piePlot1.setIgnoreNullValues(false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.14d + "'", double3 == 0.14d);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Shape shape3 = numberAxis3D2.getDownArrow();
        xYStepRenderer0.setSeriesShape((int) (byte) 100, shape3, false);
        java.awt.Stroke stroke6 = null;
        try {
            xYStepRenderer0.setBaseOutlineStroke(stroke6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator1 = xYBarRenderer0.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset2 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range3 = xYBarRenderer0.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset2);
        double double4 = xYBarRenderer0.getShadowXOffset();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator5 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer0.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator5, true);
        java.lang.String str8 = standardXYToolTipGenerator5.getFormatString();
        org.junit.Assert.assertNull(xYItemLabelGenerator1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "{0}: ({1}, {2})" + "'", str8.equals("{0}: ({1}, {2})"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getShadowsVisible();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator2, false);
        java.awt.Paint paint6 = barRenderer0.lookupSeriesFillPaint((-4145152));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 1, (int) (short) -1, (java.lang.Comparable) 3, "hi!", "index.html");
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray13 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray13);
        org.jfree.data.Range range15 = barRenderer10.findRangeBounds(categoryDataset14);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity18 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "hi!", "hi!", categoryDataset14, (java.lang.Comparable) 64, (java.lang.Comparable) (short) 0);
        java.lang.String str19 = categoryItemEntity18.toString();
        java.lang.Comparable comparable20 = categoryItemEntity18.getRowKey();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(categoryDataset14);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + 64 + "'", comparable20.equals(64));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        double double3 = timeSeriesCollection1.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean7 = xYLineAndShapeRenderer6.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer6.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke11 = xYLineAndShapeRenderer6.getBaseOutlineStroke();
        java.awt.Stroke stroke13 = xYLineAndShapeRenderer6.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, valueAxis5, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer6);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = xYPlot14.getInsets();
        double double16 = xYPlot14.getRangeCrosshairValue();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation17 = null;
        try {
            xYPlot14.addAnnotation(xYAnnotation17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.plot.RingPlot ringPlot0 = new org.jfree.chart.plot.RingPlot();
        java.awt.Paint paint1 = null;
        try {
            ringPlot0.setSeparatorPaint(paint1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.SHAPES_AND_LINES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        polarPlot5.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = polarPlot5.getOrientation();
        combinedRangeXYPlot0.setOrientation(plotOrientation8);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean11 = xYLineAndShapeRenderer10.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer10.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke15 = xYLineAndShapeRenderer10.getBaseOutlineStroke();
        java.awt.Stroke stroke17 = xYLineAndShapeRenderer10.lookupSeriesStroke(4);
        combinedRangeXYPlot0.setDomainCrosshairStroke(stroke17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = combinedRangeXYPlot0.getLegendItems();
        java.awt.Shape shape24 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.general.PieDataset pieDataset25 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity31 = new org.jfree.chart.entity.PieSectionEntity(shape24, pieDataset25, 1, (int) (short) -1, (java.lang.Comparable) 3, "hi!", "index.html");
        org.jfree.data.general.PieDataset pieDataset32 = null;
        org.jfree.chart.plot.PiePlot piePlot33 = new org.jfree.chart.plot.PiePlot(pieDataset32);
        piePlot33.setStartAngle(1.0d);
        java.awt.Shape shape41 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color42 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem43 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape41, (java.awt.Paint) color42);
        piePlot33.setLabelLinkPaint((java.awt.Paint) color42);
        org.jfree.chart.LegendItem legendItem45 = new org.jfree.chart.LegendItem("", "TimePeriodAnchor.START", "TimePeriodAnchor.START", "DateTickUnitType.SECOND", shape24, (java.awt.Paint) color42);
        legendItemCollection19.add(legendItem45);
        try {
            org.jfree.chart.LegendItem legendItem48 = legendItemCollection19.get(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(legendItemCollection19);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(color42);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        double double3 = timeSeriesCollection1.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean7 = xYLineAndShapeRenderer6.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer6.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke11 = xYLineAndShapeRenderer6.getBaseOutlineStroke();
        java.awt.Stroke stroke13 = xYLineAndShapeRenderer6.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, valueAxis5, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer6);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot14.getRangeAxisEdge(3);
        boolean boolean17 = xYPlot14.isDomainZeroBaselineVisible();
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        java.lang.String str0 = org.jfree.chart.urls.StandardXYURLGenerator.DEFAULT_ITEM_PARAMETER;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "item" + "'", str0.equals("item"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setFixedAutoRange((double) 9);
        java.awt.Font font4 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("hi!", font4);
        java.text.NumberFormat numberFormat7 = java.text.NumberFormat.getNumberInstance();
        boolean boolean8 = numberFormat7.isParseIntegerOnly();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = new org.jfree.chart.axis.NumberTickUnit((double) 1, numberFormat7);
        boolean boolean10 = textLine5.equals((java.lang.Object) numberTickUnit9);
        numberAxis0.setTickUnit(numberTickUnit9, false, true);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(numberFormat7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke5 = xYLineAndShapeRenderer0.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath8 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean11 = textBlockAnchor9.equals((java.lang.Object) chartRenderingInfo10);
        java.awt.geom.Rectangle2D rectangle2D12 = chartRenderingInfo10.getChartArea();
        org.jfree.chart.RenderingSource renderingSource13 = null;
        combinedRangeXYPlot7.select(generalPath8, rectangle2D12, renderingSource13);
        org.jfree.chart.plot.XYPlot xYPlot15 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset16 = new org.jfree.data.xy.DefaultXYDataset();
        int int18 = defaultXYDataset16.indexOf((java.lang.Comparable) 0.5f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState20 = xYLineAndShapeRenderer0.initialise(graphics2D6, rectangle2D12, xYPlot15, (org.jfree.data.xy.XYDataset) defaultXYDataset16, plotRenderingInfo19);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType21 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit23 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType21, (int) (short) 100);
        org.jfree.data.time.DateRange dateRange24 = new org.jfree.data.time.DateRange();
        java.util.Date date25 = dateRange24.getUpperDate();
        java.util.Date date26 = dateTickUnit23.rollDate(date25);
        defaultXYDataset16.removeSeries((java.lang.Comparable) dateTickUnit23);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState20);
        org.junit.Assert.assertNotNull(dateTickUnitType21);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date26);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        xYLineAndShapeRenderer0.setAutoPopulateSeriesPaint(true);
        xYLineAndShapeRenderer0.setSeriesCreateEntities((int) (short) 100, (java.lang.Boolean) false, false);
        java.awt.Shape shape12 = xYLineAndShapeRenderer0.getSeriesShape((int) (byte) 1);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset13 = new org.jfree.data.xy.DefaultXYDataset();
        int int15 = defaultXYDataset13.indexOf((java.lang.Comparable) 0.5f);
        boolean boolean16 = xYLineAndShapeRenderer0.hasListener((java.util.EventListener) defaultXYDataset13);
        try {
            double double19 = defaultXYDataset13.getYValue((int) 'a', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(shape12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean2 = textBlockAnchor0.equals((java.lang.Object) chartRenderingInfo1);
        java.awt.geom.Rectangle2D rectangle2D3 = chartRenderingInfo1.getChartArea();
        org.jfree.chart.entity.EntityCollection entityCollection4 = chartRenderingInfo1.getEntityCollection();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean7 = textBlockAnchor5.equals((java.lang.Object) chartRenderingInfo6);
        java.awt.geom.Rectangle2D rectangle2D8 = chartRenderingInfo6.getChartArea();
        chartRenderingInfo1.setChartArea(rectangle2D8);
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        double double13 = timeSeriesCollection11.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean17 = xYLineAndShapeRenderer16.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer16.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke21 = xYLineAndShapeRenderer16.getBaseOutlineStroke();
        java.awt.Stroke stroke23 = xYLineAndShapeRenderer16.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection11, valueAxis14, valueAxis15, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer16);
        org.jfree.chart.block.LineBorder lineBorder26 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint27 = lineBorder26.getPaint();
        xYLineAndShapeRenderer16.setSeriesItemLabelPaint((int) (short) 0, paint27, false);
        boolean boolean30 = chartRenderingInfo1.equals((java.lang.Object) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = chartRenderingInfo1.getPlotInfo();
        java.lang.Object obj32 = chartRenderingInfo1.clone();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(entityCollection4);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo31);
        org.junit.Assert.assertNotNull(obj32);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.previous();
        long long2 = month0.getFirstMillisecond();
        int int3 = month0.getMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1559372400000L + "'", long2 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesStroke(false);
        barRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray8 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray8);
        org.jfree.data.Range range10 = barRenderer5.findRangeBounds(categoryDataset9);
        org.jfree.data.Range range11 = barRenderer0.findRangeBounds(categoryDataset9);
        java.lang.Object obj12 = barRenderer0.clone();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        polarPlot4.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = polarPlot4.getOrientation();
        polarPlot4.setAngleGridlinesVisible(true);
        boolean boolean10 = polarPlot4.isAngleGridlinesVisible();
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        xYLineAndShapeRenderer0.setAutoPopulateSeriesPaint(true);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeZone9);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection10, valueAxis11, polarItemRenderer12);
        polarPlot13.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = polarPlot13.getOrientation();
        combinedRangeXYPlot8.setOrientation(plotOrientation16);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer18 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean19 = xYLineAndShapeRenderer18.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer18.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke23 = xYLineAndShapeRenderer18.getBaseOutlineStroke();
        java.awt.Stroke stroke25 = xYLineAndShapeRenderer18.lookupSeriesStroke(4);
        combinedRangeXYPlot8.setDomainCrosshairStroke(stroke25);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        numberAxis27.setFixedAutoRange((double) 9);
        combinedRangeXYPlot8.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis27);
        org.jfree.chart.axis.LogAxis logAxis31 = new org.jfree.chart.axis.LogAxis();
        logAxis31.setSmallestValue((double) 7);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer34 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean35 = xYLineAndShapeRenderer34.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer34.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke39 = xYLineAndShapeRenderer34.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot41 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath42 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor43 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean45 = textBlockAnchor43.equals((java.lang.Object) chartRenderingInfo44);
        java.awt.geom.Rectangle2D rectangle2D46 = chartRenderingInfo44.getChartArea();
        org.jfree.chart.RenderingSource renderingSource47 = null;
        combinedRangeXYPlot41.select(generalPath42, rectangle2D46, renderingSource47);
        org.jfree.chart.plot.XYPlot xYPlot49 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset50 = new org.jfree.data.xy.DefaultXYDataset();
        int int52 = defaultXYDataset50.indexOf((java.lang.Comparable) 0.5f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState54 = xYLineAndShapeRenderer34.initialise(graphics2D40, rectangle2D46, xYPlot49, (org.jfree.data.xy.XYDataset) defaultXYDataset50, plotRenderingInfo53);
        try {
            xYLineAndShapeRenderer0.drawDomainGridLine(graphics2D7, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot8, (org.jfree.chart.axis.ValueAxis) logAxis31, rectangle2D46, 0.2d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(textBlockAnchor43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState54);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        java.lang.Comparable comparable6 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) timeSeriesCollection2, comparable6);
        org.jfree.data.general.Dataset dataset8 = legendItemBlockContainer7.getDataset();
        org.junit.Assert.assertNotNull(dataset8);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setStartAngle(1.0d);
        java.awt.Image image4 = null;
        piePlot1.setBackgroundImage(image4);
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        piePlot7.setStartAngle(1.0d);
        java.awt.Image image10 = null;
        piePlot7.setBackgroundImage(image10);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator12 = piePlot7.getLegendLabelGenerator();
        piePlot1.setLabelGenerator(pieSectionLabelGenerator12);
        java.awt.Color color14 = java.awt.Color.YELLOW;
        piePlot1.setLabelLinkPaint((java.awt.Paint) color14);
        double double16 = piePlot1.getShadowYOffset();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.setDomainZeroBaselineVisible(false);
        combinedRangeXYPlot0.setDomainGridlinesVisible(false);
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean9 = textBlockAnchor7.equals((java.lang.Object) chartRenderingInfo8);
        java.awt.geom.Rectangle2D rectangle2D10 = chartRenderingInfo8.getChartArea();
        try {
            combinedRangeXYPlot0.drawBackground(graphics2D6, rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangle2D10);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        double double1 = blockParams0.getTranslateX();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        java.text.DateFormat dateFormat1 = null;
        java.text.DateFormat dateFormat2 = null;
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator3 = new org.jfree.chart.labels.StandardXYToolTipGenerator("Pie Plot", dateFormat1, dateFormat2);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean4 = textBlockAnchor2.equals((java.lang.Object) chartRenderingInfo3);
        java.awt.geom.Rectangle2D rectangle2D5 = chartRenderingInfo3.getChartArea();
        org.jfree.chart.RenderingSource renderingSource6 = null;
        combinedRangeXYPlot0.select(generalPath1, rectangle2D5, renderingSource6);
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.clone((java.awt.Shape) generalPath1);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNull(shape8);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        java.lang.Comparable comparable6 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) timeSeriesCollection2, comparable6);
        java.lang.Object obj8 = legendItemBlockContainer7.clone();
        org.jfree.data.general.Dataset dataset9 = legendItemBlockContainer7.getDataset();
        java.lang.Comparable comparable10 = legendItemBlockContainer7.getSeriesKey();
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(dataset9);
        org.junit.Assert.assertNull(comparable10);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        int int2 = piePlot1.getPieIndex();
        double double3 = piePlot1.getMaximumLabelWidth();
        piePlot1.setMaximumLabelWidth((double) (byte) 0);
        piePlot1.setInteriorGap(0.0d);
        java.lang.Object obj8 = piePlot1.clone();
        java.lang.Comparable comparable9 = null;
        try {
            piePlot1.setExplodePercent(comparable9, 12.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.14d + "'", double3 == 0.14d);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesStroke(false);
        barRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray8 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray8);
        org.jfree.data.Range range10 = barRenderer5.findRangeBounds(categoryDataset9);
        org.jfree.data.Range range11 = barRenderer0.findRangeBounds(categoryDataset9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection17, valueAxis18, polarItemRenderer19);
        polarPlot20.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = polarPlot20.getOrientation();
        combinedRangeXYPlot15.setOrientation(plotOrientation23);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer25 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean26 = xYLineAndShapeRenderer25.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer25.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke30 = xYLineAndShapeRenderer25.getBaseOutlineStroke();
        java.awt.Stroke stroke32 = xYLineAndShapeRenderer25.lookupSeriesStroke(4);
        combinedRangeXYPlot15.setDomainCrosshairStroke(stroke32);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        numberAxis34.setFixedAutoRange((double) 9);
        combinedRangeXYPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis34);
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis34.setLeftArrow(shape39);
        java.text.NumberFormat numberFormat41 = java.text.NumberFormat.getNumberInstance();
        boolean boolean42 = numberFormat41.isParseIntegerOnly();
        numberAxis34.setNumberFormatOverride(numberFormat41);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis34, categoryItemRenderer44);
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        categoryPlot45.setRangeAxis((int) (byte) 100, valueAxis47);
        java.lang.Comparable comparable49 = categoryPlot45.getDomainCrosshairRowKey();
        categoryPlot45.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.IntervalMarker intervalMarker54 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 1.0f);
        java.awt.Paint paint55 = intervalMarker54.getOutlinePaint();
        java.awt.Stroke stroke56 = intervalMarker54.getOutlineStroke();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer57 = null;
        intervalMarker54.setGradientPaintTransformer(gradientPaintTransformer57);
        float float59 = intervalMarker54.getAlpha();
        categoryPlot45.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker54);
        intervalMarker54.setEndValue((double) 0);
        java.awt.Stroke stroke63 = intervalMarker54.getStroke();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(numberFormat41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(comparable49);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertTrue("'" + float59 + "' != '" + 0.8f + "'", float59 == 0.8f);
        org.junit.Assert.assertNotNull(stroke63);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        polarPlot5.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = polarPlot5.getOrientation();
        combinedRangeXYPlot0.setOrientation(plotOrientation8);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean11 = xYLineAndShapeRenderer10.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer10.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke15 = xYLineAndShapeRenderer10.getBaseOutlineStroke();
        java.awt.Stroke stroke17 = xYLineAndShapeRenderer10.lookupSeriesStroke(4);
        combinedRangeXYPlot0.setDomainCrosshairStroke(stroke17);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        numberAxis19.setFixedAutoRange((double) 9);
        combinedRangeXYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis19);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder23 = combinedRangeXYPlot0.getDatasetRenderingOrder();
        combinedRangeXYPlot0.configureDomainAxes();
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(datasetRenderingOrder23);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("EXPAND");
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        java.util.Date date3 = dateAxis1.getMaximumDate();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = new org.jfree.chart.axis.SegmentedTimeline((long) 7, (int) (short) 100, (int) (short) 1);
        segmentedTimeline8.setAdjustForDaylightSaving(false);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange();
        java.util.Date date12 = dateRange11.getUpperDate();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType13 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType13, (int) (short) 100);
        org.jfree.data.time.DateRange dateRange16 = new org.jfree.data.time.DateRange();
        java.util.Date date17 = dateRange16.getUpperDate();
        java.util.Date date18 = dateTickUnit15.rollDate(date17);
        boolean boolean19 = segmentedTimeline8.containsDomainRange(date12, date17);
        dateAxis4.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline8);
        dateAxis1.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline8);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(dateTickUnitType13);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("TimePeriodAnchor.START", graphics2D1, (float) (-4145152), (float) (-1L), (double) '4', (float) ' ', (float) 64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = blockResult0.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        java.awt.Paint paint6 = polarPlot5.getAngleLabelPaint();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean8 = xYLineAndShapeRenderer7.getAutoPopulateSeriesOutlinePaint();
        java.awt.Font font9 = xYLineAndShapeRenderer7.getBaseItemLabelFont();
        polarPlot5.setAngleLabelFont(font9);
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("TimePeriodAnchor.START", font9);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.Range range14 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((double) (-1), range14);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType16 = rectangleConstraint15.getWidthConstraintType();
        org.jfree.data.Range range17 = rectangleConstraint15.getWidthRange();
        try {
            org.jfree.chart.util.Size2D size2D18 = labelBlock11.arrange(graphics2D12, rectangleConstraint15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(lengthConstraintType16);
        org.junit.Assert.assertNull(range17);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getXOffset();
        org.jfree.chart.event.RendererChangeListener rendererChangeListener2 = null;
        try {
            barRenderer3D0.removeChangeListener(rendererChangeListener2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.0d + "'", double1 == 12.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        categoryAxis0.setLabelPaint((java.awt.Paint) color1);
        double double3 = categoryAxis0.getLowerMargin();
        double double4 = categoryAxis0.getLowerMargin();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        int int2 = piePlot1.getPieIndex();
        boolean boolean3 = piePlot1.isSubplot();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis();
        boolean boolean2 = logAxis1.isTickMarksVisible();
        java.awt.Paint paint3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder(paint3);
        java.awt.Paint paint5 = blockBorder4.getPaint();
        logAxis1.setTickMarkPaint(paint5);
        java.text.NumberFormat numberFormat7 = java.text.NumberFormat.getIntegerInstance();
        logAxis1.setNumberFormatOverride(numberFormat7);
        logAxis0.setNumberFormatOverride(numberFormat7);
        logAxis0.setBase(4.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(numberFormat7);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("EXPAND");
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = org.jfree.chart.axis.DateTickMarkPosition.END;
        dateAxis1.setTickMarkPosition(dateTickMarkPosition3);
        boolean boolean5 = dateAxis1.isPositiveArrowVisible();
        org.jfree.chart.axis.Timeline timeline6 = dateAxis1.getTimeline();
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(timeline6);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer1.setAutoPopulateSeriesStroke(false);
        barRenderer1.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray9);
        org.jfree.data.Range range11 = barRenderer6.findRangeBounds(categoryDataset10);
        org.jfree.data.Range range12 = barRenderer1.findRangeBounds(categoryDataset10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis13.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection18 = new org.jfree.data.time.TimeSeriesCollection(timeZone17);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer20 = null;
        org.jfree.chart.plot.PolarPlot polarPlot21 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection18, valueAxis19, polarItemRenderer20);
        polarPlot21.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = polarPlot21.getOrientation();
        combinedRangeXYPlot16.setOrientation(plotOrientation24);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer26 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean27 = xYLineAndShapeRenderer26.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer26.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke31 = xYLineAndShapeRenderer26.getBaseOutlineStroke();
        java.awt.Stroke stroke33 = xYLineAndShapeRenderer26.lookupSeriesStroke(4);
        combinedRangeXYPlot16.setDomainCrosshairStroke(stroke33);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis();
        numberAxis35.setFixedAutoRange((double) 9);
        combinedRangeXYPlot16.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis35);
        java.awt.Shape shape40 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis35.setLeftArrow(shape40);
        java.text.NumberFormat numberFormat42 = java.text.NumberFormat.getNumberInstance();
        boolean boolean43 = numberFormat42.isParseIntegerOnly();
        numberAxis35.setNumberFormatOverride(numberFormat42);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis35, categoryItemRenderer45);
        categoryPlot46.clearDomainMarkers();
        boolean boolean48 = categoryPlot46.isRangePannable();
        java.awt.Paint paint49 = categoryPlot46.getRangeMinorGridlinePaint();
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart("ERROR : Relative To String", (org.jfree.chart.plot.Plot) categoryPlot46);
        java.awt.Paint paint51 = jFreeChart50.getBackgroundPaint();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor55 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo56 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean57 = textBlockAnchor55.equals((java.lang.Object) chartRenderingInfo56);
        java.awt.geom.Rectangle2D rectangle2D58 = chartRenderingInfo56.getChartArea();
        org.jfree.chart.entity.EntityCollection entityCollection59 = chartRenderingInfo56.getEntityCollection();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor60 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo61 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean62 = textBlockAnchor60.equals((java.lang.Object) chartRenderingInfo61);
        java.awt.geom.Rectangle2D rectangle2D63 = chartRenderingInfo61.getChartArea();
        chartRenderingInfo56.setChartArea(rectangle2D63);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo65 = chartRenderingInfo56.getPlotInfo();
        org.jfree.chart.RenderingSource renderingSource66 = null;
        chartRenderingInfo56.setRenderingSource(renderingSource66);
        try {
            java.awt.image.BufferedImage bufferedImage68 = jFreeChart50.createBufferedImage((int) (byte) 1, 100, 500, chartRenderingInfo56);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 500");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(plotOrientation24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(numberFormat42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(textBlockAnchor55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(rectangle2D58);
        org.junit.Assert.assertNotNull(entityCollection59);
        org.junit.Assert.assertNotNull(textBlockAnchor60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertNotNull(plotRenderingInfo65);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesStroke(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = barRenderer0.getSeriesURLGenerator((int) ' ');
        org.junit.Assert.assertNull(categoryURLGenerator4);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(true);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke5 = xYLineAndShapeRenderer0.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath8 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean11 = textBlockAnchor9.equals((java.lang.Object) chartRenderingInfo10);
        java.awt.geom.Rectangle2D rectangle2D12 = chartRenderingInfo10.getChartArea();
        org.jfree.chart.RenderingSource renderingSource13 = null;
        combinedRangeXYPlot7.select(generalPath8, rectangle2D12, renderingSource13);
        org.jfree.chart.plot.XYPlot xYPlot15 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset16 = new org.jfree.data.xy.DefaultXYDataset();
        int int18 = defaultXYDataset16.indexOf((java.lang.Comparable) 0.5f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState20 = xYLineAndShapeRenderer0.initialise(graphics2D6, rectangle2D12, xYPlot15, (org.jfree.data.xy.XYDataset) defaultXYDataset16, plotRenderingInfo19);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Shape shape22 = numberAxis3D21.getDownArrow();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer23 = null;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) defaultXYDataset16, (org.jfree.chart.axis.ValueAxis) numberAxis3D21, polarItemRenderer23);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean26 = numberAxis25.isVisible();
        numberAxis25.setAutoRangeStickyZero(false);
        org.jfree.data.Range range29 = numberAxis25.getDefaultAutoRange();
        numberAxis3D21.setDefaultAutoRange(range29);
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection32 = new org.jfree.data.time.TimeSeriesCollection(timeZone31);
        double double34 = timeSeriesCollection32.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer37 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean38 = xYLineAndShapeRenderer37.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer37.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke42 = xYLineAndShapeRenderer37.getBaseOutlineStroke();
        java.awt.Stroke stroke44 = xYLineAndShapeRenderer37.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection32, valueAxis35, valueAxis36, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer37);
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = xYPlot45.getRangeAxisEdge(3);
        numberAxis3D21.setPlot((org.jfree.chart.plot.Plot) xYPlot45);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState20);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(rectangleEdge47);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = xYBarRenderer1.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset3 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range4 = xYBarRenderer1.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset3);
        double double5 = xYBarRenderer1.getShadowXOffset();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator6 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer1.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator6, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator11 = xYBarRenderer10.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset12 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range13 = xYBarRenderer10.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset12);
        double double14 = xYBarRenderer10.getShadowXOffset();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator15 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer10.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator15, true);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator18 = new org.jfree.chart.urls.StandardXYURLGenerator();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer19 = new org.jfree.chart.renderer.xy.XYAreaRenderer(8, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator15, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator18);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer20 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator6, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator18);
        boolean boolean21 = xYStepAreaRenderer20.isOutline();
        org.junit.Assert.assertNull(xYItemLabelGenerator2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator6);
        org.junit.Assert.assertNull(xYItemLabelGenerator11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        java.lang.Comparable comparable6 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) timeSeriesCollection2, comparable6);
        java.lang.Object obj8 = legendItemBlockContainer7.clone();
        org.jfree.data.general.Dataset dataset9 = legendItemBlockContainer7.getDataset();
        legendItemBlockContainer7.clear();
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(dataset9);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.awt.Paint paint0 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_ALTERNATE_PAINT;
        java.awt.Stroke stroke1 = null;
        org.jfree.data.general.PieDataset pieDataset2 = null;
        org.jfree.chart.plot.PiePlot piePlot3 = new org.jfree.chart.plot.PiePlot(pieDataset2);
        piePlot3.setStartAngle(1.0d);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 1.0f);
        java.awt.Paint paint9 = intervalMarker8.getOutlinePaint();
        java.awt.Stroke stroke10 = intervalMarker8.getOutlineStroke();
        piePlot3.setLabelOutlineStroke(stroke10);
        piePlot3.setLabelLinksVisible(false);
        java.awt.Paint paint14 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        piePlot3.setNoDataMessagePaint(paint14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = piePlot3.getSimpleLabelOffset();
        try {
            org.jfree.chart.block.LineBorder lineBorder17 = new org.jfree.chart.block.LineBorder(paint0, stroke1, rectangleInsets16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint0);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true);
        xYSeries2.fireSeriesChanged();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries2);
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection4);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator1 = xYBarRenderer0.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset2 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range3 = xYBarRenderer0.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset2);
        double double4 = xYBarRenderer0.getShadowXOffset();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean6 = xYLineAndShapeRenderer5.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer5.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke10 = xYLineAndShapeRenderer5.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath13 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean16 = textBlockAnchor14.equals((java.lang.Object) chartRenderingInfo15);
        java.awt.geom.Rectangle2D rectangle2D17 = chartRenderingInfo15.getChartArea();
        org.jfree.chart.RenderingSource renderingSource18 = null;
        combinedRangeXYPlot12.select(generalPath13, rectangle2D17, renderingSource18);
        org.jfree.chart.plot.XYPlot xYPlot20 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset21 = new org.jfree.data.xy.DefaultXYDataset();
        int int23 = defaultXYDataset21.indexOf((java.lang.Comparable) 0.5f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState25 = xYLineAndShapeRenderer5.initialise(graphics2D11, rectangle2D17, xYPlot20, (org.jfree.data.xy.XYDataset) defaultXYDataset21, plotRenderingInfo24);
        org.jfree.data.Range range26 = xYBarRenderer0.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset21);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer27 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean28 = xYLineAndShapeRenderer27.getDrawOutlines();
        java.awt.Shape shape29 = xYLineAndShapeRenderer27.getBaseShape();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor30 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.jfree.chart.text.TextAnchor textAnchor31 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor30, textAnchor31);
        xYLineAndShapeRenderer27.setBaseNegativeItemLabelPosition(itemLabelPosition32);
        xYBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition32);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer36 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean37 = xYLineAndShapeRenderer36.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer36.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Paint paint41 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYLineAndShapeRenderer36.setBasePaint(paint41, false);
        xYBarRenderer0.setSeriesOutlinePaint(3, paint41);
        org.junit.Assert.assertNull(xYItemLabelGenerator1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(textBlockAnchor14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState25);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(itemLabelAnchor30);
        org.junit.Assert.assertNotNull(textAnchor31);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        java.awt.Shape shape4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity11 = new org.jfree.chart.entity.PieSectionEntity(shape4, pieDataset5, 1, (int) (short) -1, (java.lang.Comparable) 3, "hi!", "index.html");
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        piePlot13.setStartAngle(1.0d);
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape21, (java.awt.Paint) color22);
        piePlot13.setLabelLinkPaint((java.awt.Paint) color22);
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("", "TimePeriodAnchor.START", "TimePeriodAnchor.START", "DateTickUnitType.SECOND", shape4, (java.awt.Paint) color22);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        legendItem25.setOutlineStroke(stroke26);
        java.lang.String str28 = legendItem25.getURLText();
        java.awt.Shape shape29 = legendItem25.getLine();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "DateTickUnitType.SECOND" + "'", str28.equals("DateTickUnitType.SECOND"));
        org.junit.Assert.assertNotNull(shape29);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Font font2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer0.setLegendTextFont((int) '#', font2);
        boolean boolean4 = xYLineAndShapeRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean6 = xYLineAndShapeRenderer5.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer5.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke10 = xYLineAndShapeRenderer5.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath13 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean16 = textBlockAnchor14.equals((java.lang.Object) chartRenderingInfo15);
        java.awt.geom.Rectangle2D rectangle2D17 = chartRenderingInfo15.getChartArea();
        org.jfree.chart.RenderingSource renderingSource18 = null;
        combinedRangeXYPlot12.select(generalPath13, rectangle2D17, renderingSource18);
        org.jfree.chart.plot.XYPlot xYPlot20 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset21 = new org.jfree.data.xy.DefaultXYDataset();
        int int23 = defaultXYDataset21.indexOf((java.lang.Comparable) 0.5f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState25 = xYLineAndShapeRenderer5.initialise(graphics2D11, rectangle2D17, xYPlot20, (org.jfree.data.xy.XYDataset) defaultXYDataset21, plotRenderingInfo24);
        org.jfree.data.Range range26 = xYLineAndShapeRenderer0.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset21);
        boolean boolean29 = xYLineAndShapeRenderer0.getItemShapeVisible(0, 3);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(textBlockAnchor14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState25);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        boolean boolean6 = textAnchor4.equals((java.lang.Object) (byte) 0);
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("AxisLocation.BOTTOM_OR_LEFT", graphics2D1, 10.0f, (float) ' ', textAnchor4, (double) 24234L, 100.0f, (float) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) (short) 100);
        java.lang.String str3 = dateTickUnit2.toString();
        int int4 = dateTickUnit2.getCalendarField();
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "DateTickUnit[DateTickUnitType.YEAR, 100]" + "'", str3.equals("DateTickUnit[DateTickUnitType.YEAR, 100]"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        int int1 = barRenderer0.getRowCount();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        barRenderer0.setSeriesPaint(3, (java.awt.Paint) color3);
        barRenderer0.setShadowVisible(false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.lang.String[] strArray1 = new java.lang.String[] {};
        org.jfree.chart.axis.SymbolAxis symbolAxis2 = new org.jfree.chart.axis.SymbolAxis("AxisLocation.BOTTOM_OR_LEFT", strArray1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = new org.jfree.chart.axis.AxisState();
        axisState4.cursorLeft((double) 100);
        axisState4.cursorDown(3.0d);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean10 = xYLineAndShapeRenderer9.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer9.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        xYLineAndShapeRenderer9.setAutoPopulateSeriesPaint(true);
        xYLineAndShapeRenderer9.setSeriesLinesVisible((int) (byte) 100, (java.lang.Boolean) false);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state21 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo20);
        java.awt.geom.GeneralPath generalPath22 = null;
        state21.seriesPath = generalPath22;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer24 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean25 = xYLineAndShapeRenderer24.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer24.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke29 = xYLineAndShapeRenderer24.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot31 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath32 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor33 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo34 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean35 = textBlockAnchor33.equals((java.lang.Object) chartRenderingInfo34);
        java.awt.geom.Rectangle2D rectangle2D36 = chartRenderingInfo34.getChartArea();
        org.jfree.chart.RenderingSource renderingSource37 = null;
        combinedRangeXYPlot31.select(generalPath32, rectangle2D36, renderingSource37);
        org.jfree.chart.plot.XYPlot xYPlot39 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset40 = new org.jfree.data.xy.DefaultXYDataset();
        int int42 = defaultXYDataset40.indexOf((java.lang.Comparable) 0.5f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState44 = xYLineAndShapeRenderer24.initialise(graphics2D30, rectangle2D36, xYPlot39, (org.jfree.data.xy.XYDataset) defaultXYDataset40, plotRenderingInfo43);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot45 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone46 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection47 = new org.jfree.data.time.TimeSeriesCollection(timeZone46);
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer49 = null;
        org.jfree.chart.plot.PolarPlot polarPlot50 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection47, valueAxis48, polarItemRenderer49);
        polarPlot50.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation53 = polarPlot50.getOrientation();
        combinedRangeXYPlot45.setOrientation(plotOrientation53);
        combinedRangeXYPlot45.setRangeCrosshairValue(0.0d);
        boolean boolean57 = combinedRangeXYPlot45.isDomainCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis58 = null;
        org.jfree.chart.axis.ValueAxis valueAxis59 = null;
        java.util.TimeZone timeZone60 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection61 = new org.jfree.data.time.TimeSeriesCollection(timeZone60);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor62 = timeSeriesCollection61.getXPosition();
        xYLineAndShapeRenderer9.drawItem(graphics2D19, (org.jfree.chart.renderer.xy.XYItemRendererState) state21, rectangle2D36, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot45, valueAxis58, valueAxis59, (org.jfree.data.xy.XYDataset) timeSeriesCollection61, (-1), 15, false, (-4145152));
        org.jfree.chart.axis.AxisLocation axisLocation68 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.util.TimeZone timeZone69 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection70 = new org.jfree.data.time.TimeSeriesCollection(timeZone69);
        org.jfree.chart.axis.ValueAxis valueAxis71 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer72 = null;
        org.jfree.chart.plot.PolarPlot polarPlot73 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection70, valueAxis71, polarItemRenderer72);
        polarPlot73.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation76 = polarPlot73.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge77 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation68, plotOrientation76);
        try {
            java.util.List list78 = symbolAxis2.refreshTicks(graphics2D3, axisState4, rectangle2D36, rectangleEdge77);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(textBlockAnchor33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState44);
        org.junit.Assert.assertNotNull(plotOrientation53);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(timePeriodAnchor62);
        org.junit.Assert.assertNotNull(axisLocation68);
        org.junit.Assert.assertNotNull(plotOrientation76);
        org.junit.Assert.assertNotNull(rectangleEdge77);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean2 = textBlockAnchor0.equals((java.lang.Object) chartRenderingInfo1);
        java.awt.geom.Rectangle2D rectangle2D3 = chartRenderingInfo1.getChartArea();
        org.jfree.chart.entity.EntityCollection entityCollection4 = chartRenderingInfo1.getEntityCollection();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean7 = textBlockAnchor5.equals((java.lang.Object) chartRenderingInfo6);
        java.awt.geom.Rectangle2D rectangle2D8 = chartRenderingInfo6.getChartArea();
        chartRenderingInfo1.setChartArea(rectangle2D8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = chartRenderingInfo1.getPlotInfo();
        chartRenderingInfo1.clear();
        chartRenderingInfo1.clear();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(entityCollection4);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(plotRenderingInfo10);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true);
        xYSeries2.fireSeriesChanged();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries2);
        boolean boolean5 = xYSeriesCollection4.isAutoWidth();
        xYSeriesCollection4.setIntervalWidth((double) 3);
        java.lang.Comparable comparable8 = null;
        try {
            org.jfree.data.xy.XYSeries xYSeries9 = xYSeriesCollection4.getSeries(comparable8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (-1), range1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toUnconstrainedHeight();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = rectangleConstraint4.getHeightConstraintType();
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertNotNull(rectangleConstraint4);
        org.junit.Assert.assertNotNull(lengthConstraintType5);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) (short) 100);
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange();
        java.util.Date date4 = dateRange3.getUpperDate();
        java.util.Date date5 = dateTickUnit2.rollDate(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline10 = new org.jfree.chart.axis.SegmentedTimeline((long) 7, (int) (short) 100, (int) (short) 1);
        segmentedTimeline10.setStartTime((long) 10);
        org.jfree.data.time.DateRange dateRange13 = new org.jfree.data.time.DateRange();
        java.util.Date date14 = dateRange13.getUpperDate();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment15 = segmentedTimeline10.getSegment(date14);
        try {
            org.jfree.data.time.DateRange dateRange16 = new org.jfree.data.time.DateRange(date5, date14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (3.155760000001E12) <= upper (1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(segment15);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        double double1 = xYStepRenderer0.getStepPoint();
        xYStepRenderer0.setItemLabelAnchorOffset((double) 10.0f);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape9, (java.awt.Paint) color10);
        java.awt.Font font12 = legendItem11.getLabelFont();
        org.jfree.data.general.Dataset dataset13 = null;
        legendItem11.setDataset(dataset13);
        legendItem11.setDescription("DateTickUnitType.SECOND");
        java.awt.Paint paint17 = legendItem11.getFillPaint();
        xYStepRenderer0.setBasePaint(paint17, true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(font12);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape5, (java.awt.Paint) color6);
        org.jfree.chart.plot.WaferMapPlot waferMapPlot8 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) waferMapPlot8);
        java.lang.Object obj10 = legendTitle9.clone();
        double double11 = legendTitle9.getHeight();
        boolean boolean12 = legendTitle9.visible;
        org.jfree.chart.entity.TitleEntity titleEntity15 = new org.jfree.chart.entity.TitleEntity(shape5, (org.jfree.chart.title.Title) legendTitle9, "rect", "DateTickUnitType.SECOND");
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.color.ColorSpace colorSpace17 = color16.getColorSpace();
        boolean boolean19 = color16.equals((java.lang.Object) 'a');
        legendTitle9.setItemPaint((java.awt.Paint) color16);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(colorSpace17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesStroke(false);
        barRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray8 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray8);
        org.jfree.data.Range range10 = barRenderer5.findRangeBounds(categoryDataset9);
        org.jfree.data.Range range11 = barRenderer0.findRangeBounds(categoryDataset9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection17, valueAxis18, polarItemRenderer19);
        polarPlot20.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = polarPlot20.getOrientation();
        combinedRangeXYPlot15.setOrientation(plotOrientation23);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer25 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean26 = xYLineAndShapeRenderer25.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer25.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke30 = xYLineAndShapeRenderer25.getBaseOutlineStroke();
        java.awt.Stroke stroke32 = xYLineAndShapeRenderer25.lookupSeriesStroke(4);
        combinedRangeXYPlot15.setDomainCrosshairStroke(stroke32);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        numberAxis34.setFixedAutoRange((double) 9);
        combinedRangeXYPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis34);
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis34.setLeftArrow(shape39);
        java.text.NumberFormat numberFormat41 = java.text.NumberFormat.getNumberInstance();
        boolean boolean42 = numberFormat41.isParseIntegerOnly();
        numberAxis34.setNumberFormatOverride(numberFormat41);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis34, categoryItemRenderer44);
        categoryPlot45.clearDomainMarkers();
        categoryPlot45.clearRangeAxes();
        java.lang.String str48 = categoryPlot45.getPlotType();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(numberFormat41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "Category Plot" + "'", str48.equals("Category Plot"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setStartAngle(1.0d);
        piePlot1.setSectionOutlinesVisible(false);
        boolean boolean6 = piePlot1.getSimpleLabels();
        double double7 = piePlot1.getLabelLinkMargin();
        piePlot1.setCircular(true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.025d + "'", double7 == 0.025d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = null;
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 10, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem9 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape7, (java.awt.Paint) color8);
        int int10 = color8.getGreen();
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("hi!", font1, (java.awt.Paint) color8);
        org.jfree.chart.text.TextFragment textFragment12 = textLine11.getLastTextFragment();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor15 = itemLabelPosition14.getTextAnchor();
        try {
            float float16 = textFragment12.calculateBaselineOffset(graphics2D13, textAnchor15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 64 + "'", int10 == 64);
        org.junit.Assert.assertNotNull(textFragment12);
        org.junit.Assert.assertNotNull(textAnchor15);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        polarPlot5.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = polarPlot5.getOrientation();
        combinedRangeXYPlot0.setOrientation(plotOrientation8);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean11 = xYLineAndShapeRenderer10.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer10.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke15 = xYLineAndShapeRenderer10.getBaseOutlineStroke();
        java.awt.Stroke stroke17 = xYLineAndShapeRenderer10.lookupSeriesStroke(4);
        combinedRangeXYPlot0.setDomainCrosshairStroke(stroke17);
        java.awt.geom.GeneralPath generalPath19 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer20 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean21 = xYLineAndShapeRenderer20.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer20.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke25 = xYLineAndShapeRenderer20.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot27 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath28 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor29 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo30 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean31 = textBlockAnchor29.equals((java.lang.Object) chartRenderingInfo30);
        java.awt.geom.Rectangle2D rectangle2D32 = chartRenderingInfo30.getChartArea();
        org.jfree.chart.RenderingSource renderingSource33 = null;
        combinedRangeXYPlot27.select(generalPath28, rectangle2D32, renderingSource33);
        org.jfree.chart.plot.XYPlot xYPlot35 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset36 = new org.jfree.data.xy.DefaultXYDataset();
        int int38 = defaultXYDataset36.indexOf((java.lang.Comparable) 0.5f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState40 = xYLineAndShapeRenderer20.initialise(graphics2D26, rectangle2D32, xYPlot35, (org.jfree.data.xy.XYDataset) defaultXYDataset36, plotRenderingInfo39);
        org.jfree.chart.RenderingSource renderingSource41 = null;
        combinedRangeXYPlot0.select(generalPath19, rectangle2D32, renderingSource41);
        org.jfree.chart.axis.ValueAxis valueAxis44 = combinedRangeXYPlot0.getRangeAxis((int) (short) 10);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(textBlockAnchor29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState40);
        org.junit.Assert.assertNull(valueAxis44);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 1, (int) (short) -1, (java.lang.Comparable) 3, "hi!", "index.html");
        java.lang.Object obj8 = null;
        boolean boolean9 = pieSectionEntity7.equals(obj8);
        java.lang.String str10 = pieSectionEntity7.getShapeType();
        java.lang.String str11 = pieSectionEntity7.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "rect" + "'", str10.equals("rect"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PieSection: 1, -1(3)" + "'", str11.equals("PieSection: 1, -1(3)"));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean4 = textBlockAnchor2.equals((java.lang.Object) chartRenderingInfo3);
        java.awt.geom.Rectangle2D rectangle2D5 = chartRenderingInfo3.getChartArea();
        org.jfree.chart.RenderingSource renderingSource6 = null;
        combinedRangeXYPlot0.select(generalPath1, rectangle2D5, renderingSource6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_GREEN;
        combinedRangeXYPlot0.setDomainMinorGridlinePaint((java.awt.Paint) color8);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        double double3 = timeSeriesCollection1.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean7 = xYLineAndShapeRenderer6.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer6.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke11 = xYLineAndShapeRenderer6.getBaseOutlineStroke();
        java.awt.Stroke stroke13 = xYLineAndShapeRenderer6.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, valueAxis5, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer6);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = xYPlot14.getInsets();
        xYPlot14.setNotify(true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot19 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot19.setDomainZeroBaselineVisible(false);
        org.jfree.chart.plot.Marker marker23 = null;
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean26 = combinedRangeXYPlot19.removeDomainMarker((int) (short) 0, marker23, layer24, false);
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation28 = axisLocation27.getOpposite();
        combinedRangeXYPlot19.setDomainAxisLocation(axisLocation28, false);
        xYPlot14.setRangeAxisLocation(0, axisLocation28, true);
        java.lang.String str33 = axisLocation28.toString();
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str33.equals("AxisLocation.BOTTOM_OR_LEFT"));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) waferMapPlot0);
        boolean boolean2 = legendTitle1.visible;
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_GREEN;
        legendTitle1.setItemPaint((java.awt.Paint) color3);
        java.awt.Font font5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        legendTitle1.setItemFont(font5);
        java.awt.Font font7 = legendTitle1.getItemFont();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) (short) 10, categoryItemLabelGenerator2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator((-4145152), (int) (byte) 1, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = null;
        try {
            barRenderer0.setSeriesItemLabelGenerator((-9999), categoryItemLabelGenerator9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryURLGenerator7);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ChartChangeEventType.GENERAL");
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        java.awt.Font font0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray3 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray3);
        org.jfree.data.Range range5 = barRenderer0.findRangeBounds(categoryDataset4);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = null;
        barRenderer0.setSeriesURLGenerator(255, categoryURLGenerator7, false);
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter13 = new org.jfree.chart.renderer.category.GradientBarPainter(0.14d, (-1.0d), (double) 100);
        barRenderer0.setBarPainter((org.jfree.chart.renderer.category.BarPainter) gradientBarPainter13);
        int int15 = barRenderer0.getColumnCount();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(categoryDataset4);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer3.setAutoPopulateSeriesStroke(false);
        barRenderer3.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray11 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray11);
        org.jfree.data.Range range13 = barRenderer8.findRangeBounds(categoryDataset12);
        org.jfree.data.Range range14 = barRenderer3.findRangeBounds(categoryDataset12);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis15.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection20 = new org.jfree.data.time.TimeSeriesCollection(timeZone19);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer22 = null;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection20, valueAxis21, polarItemRenderer22);
        polarPlot23.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation26 = polarPlot23.getOrientation();
        combinedRangeXYPlot18.setOrientation(plotOrientation26);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer28 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean29 = xYLineAndShapeRenderer28.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer28.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke33 = xYLineAndShapeRenderer28.getBaseOutlineStroke();
        java.awt.Stroke stroke35 = xYLineAndShapeRenderer28.lookupSeriesStroke(4);
        combinedRangeXYPlot18.setDomainCrosshairStroke(stroke35);
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        numberAxis37.setFixedAutoRange((double) 9);
        combinedRangeXYPlot18.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis37);
        java.awt.Shape shape42 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis37.setLeftArrow(shape42);
        java.text.NumberFormat numberFormat44 = java.text.NumberFormat.getNumberInstance();
        boolean boolean45 = numberFormat44.isParseIntegerOnly();
        numberAxis37.setNumberFormatOverride(numberFormat44);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis37, categoryItemRenderer47);
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        categoryPlot48.setRangeAxis((int) (byte) 100, valueAxis50);
        java.awt.Stroke stroke52 = categoryPlot48.getRangeCrosshairStroke();
        xYLineAndShapeRenderer0.setSeriesOutlineStroke(64, stroke52);
        xYLineAndShapeRenderer0.setAutoPopulateSeriesOutlineStroke(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(plotOrientation26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(numberFormat44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(stroke52);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true);
        xYSeries2.fireSeriesChanged();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries2);
        try {
            java.lang.Number number7 = xYSeriesCollection4.getStartX(2, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        polarPlot4.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = polarPlot4.getOrientation();
        java.lang.String str8 = plotOrientation7.toString();
        org.junit.Assert.assertNotNull(plotOrientation7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str8.equals("PlotOrientation.HORIZONTAL"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
        java.lang.String str3 = month1.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = null;
        try {
            org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("Combined Range XYPlot", (org.jfree.data.time.RegularTimePeriod) month1, regularTimePeriod5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.setDomainCrosshairValue((double) 9, true);
        org.jfree.chart.axis.ValueAxis valueAxis4 = combinedRangeXYPlot0.getRangeAxis();
        combinedRangeXYPlot0.setGap((double) 2);
        org.junit.Assert.assertNotNull(valueAxis4);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesStroke(false);
        barRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray8 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray8);
        org.jfree.data.Range range10 = barRenderer5.findRangeBounds(categoryDataset9);
        org.jfree.data.Range range11 = barRenderer0.findRangeBounds(categoryDataset9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection17, valueAxis18, polarItemRenderer19);
        polarPlot20.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = polarPlot20.getOrientation();
        combinedRangeXYPlot15.setOrientation(plotOrientation23);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer25 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean26 = xYLineAndShapeRenderer25.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer25.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke30 = xYLineAndShapeRenderer25.getBaseOutlineStroke();
        java.awt.Stroke stroke32 = xYLineAndShapeRenderer25.lookupSeriesStroke(4);
        combinedRangeXYPlot15.setDomainCrosshairStroke(stroke32);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        numberAxis34.setFixedAutoRange((double) 9);
        combinedRangeXYPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis34);
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis34.setLeftArrow(shape39);
        java.text.NumberFormat numberFormat41 = java.text.NumberFormat.getNumberInstance();
        boolean boolean42 = numberFormat41.isParseIntegerOnly();
        numberAxis34.setNumberFormatOverride(numberFormat41);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis34, categoryItemRenderer44);
        java.awt.Paint paint46 = categoryPlot45.getDomainGridlinePaint();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot48 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot48.clearDomainMarkers((int) (short) 10);
        java.util.List list51 = combinedRangeXYPlot48.getAnnotations();
        try {
            categoryPlot45.mapDatasetToRangeAxes((int) ' ', list51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(numberFormat41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(list51);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray3 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray3);
        org.jfree.data.Range range5 = barRenderer0.findRangeBounds(categoryDataset4);
        barRenderer0.setShadowVisible(false);
        boolean boolean8 = barRenderer0.isDrawBarOutline();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(categoryDataset4);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        double double1 = axisState0.getCursor();
        axisState0.cursorRight((double) (-2208960000000L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = xYBarRenderer1.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset3 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range4 = xYBarRenderer1.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset3);
        double double5 = xYBarRenderer1.getShadowXOffset();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator6 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer1.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator6, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator11 = xYBarRenderer10.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset12 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range13 = xYBarRenderer10.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset12);
        double double14 = xYBarRenderer10.getShadowXOffset();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator15 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer10.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator15, true);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator18 = new org.jfree.chart.urls.StandardXYURLGenerator();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer19 = new org.jfree.chart.renderer.xy.XYAreaRenderer(8, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator15, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator18);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer20 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator6, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator18);
        java.lang.Object obj21 = xYStepAreaRenderer20.clone();
        org.jfree.data.general.PieDataset pieDataset23 = null;
        org.jfree.chart.plot.PiePlot piePlot24 = new org.jfree.chart.plot.PiePlot(pieDataset23);
        piePlot24.setStartAngle(1.0d);
        org.jfree.chart.plot.IntervalMarker intervalMarker29 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 1.0f);
        java.awt.Paint paint30 = intervalMarker29.getOutlinePaint();
        java.awt.Stroke stroke31 = intervalMarker29.getOutlineStroke();
        piePlot24.setLabelOutlineStroke(stroke31);
        piePlot24.setLabelLinksVisible(false);
        java.awt.Paint paint35 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        piePlot24.setNoDataMessagePaint(paint35);
        xYStepAreaRenderer20.setSeriesFillPaint(3, paint35, false);
        org.junit.Assert.assertNull(xYItemLabelGenerator2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator6);
        org.junit.Assert.assertNull(xYItemLabelGenerator11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator15);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getShadowsVisible();
        double double2 = barRenderer0.getItemMargin();
        java.awt.Stroke stroke4 = barRenderer0.getSeriesOutlineStroke((-9999));
        boolean boolean5 = barRenderer0.getIncludeBaseInRange();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        piePlot1.setLabelLinkPaint(paint2);
        boolean boolean4 = piePlot1.getSectionOutlinesVisible();
        boolean boolean5 = piePlot1.getAutoPopulateSectionPaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem9 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape7, (java.awt.Paint) color8);
        int int10 = color8.getGreen();
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("hi!", font1, (java.awt.Paint) color8);
        org.jfree.chart.text.TextFragment textFragment12 = textLine11.getLastTextFragment();
        org.jfree.chart.text.TextFragment textFragment13 = null;
        textLine11.removeFragment(textFragment13);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 64 + "'", int10 == 64);
        org.junit.Assert.assertNotNull(textFragment12);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getShadowsVisible();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator2, false);
        java.awt.Paint paint8 = barRenderer0.getItemFillPaint((-1), 255, false);
        barRenderer0.setDrawBarOutline(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getShadowsVisible();
        org.jfree.chart.renderer.category.BarPainter barPainter2 = barRenderer0.getBarPainter();
        barRenderer0.setMinimumBarLength((double) 0.0f);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(barPainter2);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) waferMapPlot1);
        java.awt.Font font3 = legendTitle2.getItemFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("DateTickUnitType.SECOND", font3);
        java.awt.Graphics2D graphics2D5 = null;
        try {
            org.jfree.chart.util.Size2D size2D6 = textTitle4.arrange(graphics2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true);
        xYSeries2.fireSeriesChanged();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries2);
        boolean boolean5 = xYSeries2.isEmpty();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        int int8 = piePlot7.getPieIndex();
        boolean boolean10 = piePlot7.equals((java.lang.Object) "");
        float float11 = piePlot7.getBackgroundImageAlpha();
        java.awt.Shape shape16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity23 = new org.jfree.chart.entity.PieSectionEntity(shape16, pieDataset17, 1, (int) (short) -1, (java.lang.Comparable) 3, "hi!", "index.html");
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot(pieDataset24);
        piePlot25.setStartAngle(1.0d);
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape33, (java.awt.Paint) color34);
        piePlot25.setLabelLinkPaint((java.awt.Paint) color34);
        org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("", "TimePeriodAnchor.START", "TimePeriodAnchor.START", "DateTickUnitType.SECOND", shape16, (java.awt.Paint) color34);
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        legendItem37.setFillPaint((java.awt.Paint) color38);
        piePlot7.setLabelBackgroundPaint((java.awt.Paint) color38);
        boolean boolean41 = xYSeries2.equals((java.lang.Object) color38);
        java.beans.PropertyChangeListener propertyChangeListener42 = null;
        xYSeries2.addPropertyChangeListener(propertyChangeListener42);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState2 = timeSeriesCollection1.getSelectionState();
        java.util.List list3 = timeSeriesCollection1.getSeries();
        int int5 = timeSeriesCollection1.indexOf((java.lang.Comparable) 1.0f);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, false);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(range7);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 1.0f);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.lang.String str4 = lengthAdjustmentType3.toString();
        intervalMarker2.setLabelOffsetType(lengthAdjustmentType3);
        try {
            intervalMarker2.setAlpha((float) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(lengthAdjustmentType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "EXPAND" + "'", str4.equals("EXPAND"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = xYBarRenderer1.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset3 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range4 = xYBarRenderer1.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset3);
        double double5 = xYBarRenderer1.getShadowXOffset();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator6 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer1.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator6, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator11 = xYBarRenderer10.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset12 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range13 = xYBarRenderer10.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset12);
        double double14 = xYBarRenderer10.getShadowXOffset();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator15 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer10.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator15, true);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator18 = new org.jfree.chart.urls.StandardXYURLGenerator();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer19 = new org.jfree.chart.renderer.xy.XYAreaRenderer(8, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator15, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator18);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer20 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator6, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator18);
        int int21 = xYStepAreaRenderer20.getDefaultEntityRadius();
        boolean boolean22 = xYStepAreaRenderer20.getShapesVisible();
        org.junit.Assert.assertNull(xYItemLabelGenerator2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator6);
        org.junit.Assert.assertNull(xYItemLabelGenerator11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator15);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape2 = null;
        xYLineAndShapeRenderer0.setBaseLegendShape(shape2);
        xYLineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, false);
        java.awt.Stroke stroke9 = xYLineAndShapeRenderer0.getSeriesStroke((int) '4');
        boolean boolean11 = xYLineAndShapeRenderer0.isSeriesVisibleInLegend(9999);
        java.awt.Stroke stroke12 = null;
        try {
            xYLineAndShapeRenderer0.setBaseStroke(stroke12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.junit.Assert.assertNotNull(numberTickUnit0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getNumberInstance();
        boolean boolean3 = numberFormat2.isParseIntegerOnly();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = new org.jfree.chart.axis.NumberTickUnit((double) 1, numberFormat2);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = new org.jfree.chart.axis.NumberTickUnit(0.08d, numberFormat2);
        numberFormat2.setMaximumIntegerDigits(2);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesStroke(false);
        barRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray8 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray8);
        org.jfree.data.Range range10 = barRenderer5.findRangeBounds(categoryDataset9);
        org.jfree.data.Range range11 = barRenderer0.findRangeBounds(categoryDataset9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection17, valueAxis18, polarItemRenderer19);
        polarPlot20.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = polarPlot20.getOrientation();
        combinedRangeXYPlot15.setOrientation(plotOrientation23);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer25 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean26 = xYLineAndShapeRenderer25.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer25.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke30 = xYLineAndShapeRenderer25.getBaseOutlineStroke();
        java.awt.Stroke stroke32 = xYLineAndShapeRenderer25.lookupSeriesStroke(4);
        combinedRangeXYPlot15.setDomainCrosshairStroke(stroke32);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        numberAxis34.setFixedAutoRange((double) 9);
        combinedRangeXYPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis34);
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis34.setLeftArrow(shape39);
        java.text.NumberFormat numberFormat41 = java.text.NumberFormat.getNumberInstance();
        boolean boolean42 = numberFormat41.isParseIntegerOnly();
        numberAxis34.setNumberFormatOverride(numberFormat41);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis34, categoryItemRenderer44);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D46.setLabel("org.jfree.chart.event.RendererChangeEvent[source=1.0]");
        org.jfree.data.Range range49 = categoryPlot45.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D46);
        java.lang.String str50 = categoryPlot45.getPlotType();
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = categoryPlot45.getRangeAxisEdge((int) (byte) 100);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(numberFormat41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Category Plot" + "'", str50.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleEdge52);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 1.0f);
        java.awt.Paint paint3 = intervalMarker2.getOutlinePaint();
        java.awt.Stroke stroke4 = intervalMarker2.getOutlineStroke();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer5 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer5);
        float float7 = intervalMarker2.getAlpha();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer8 = intervalMarker2.getGradientPaintTransformer();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.8f + "'", float7 == 0.8f);
        org.junit.Assert.assertNull(gradientPaintTransformer8);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        java.awt.Paint paint0 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        polarPlot5.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = polarPlot5.getOrientation();
        combinedRangeXYPlot0.setOrientation(plotOrientation8);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean11 = xYLineAndShapeRenderer10.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer10.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke15 = xYLineAndShapeRenderer10.getBaseOutlineStroke();
        java.awt.Stroke stroke17 = xYLineAndShapeRenderer10.lookupSeriesStroke(4);
        combinedRangeXYPlot0.setDomainCrosshairStroke(stroke17);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        numberAxis19.setFixedAutoRange((double) 9);
        combinedRangeXYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis19);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder23 = combinedRangeXYPlot0.getDatasetRenderingOrder();
        java.awt.Paint paint24 = combinedRangeXYPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(datasetRenderingOrder23);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.setDomainCrosshairValue((double) 9, true);
        java.lang.Object obj4 = combinedRangeXYPlot0.clone();
        java.lang.String str5 = combinedRangeXYPlot0.getPlotType();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis7 = combinedRangeXYPlot0.getDomainAxisForDataset(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 1 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Combined Range XYPlot" + "'", str5.equals("Combined Range XYPlot"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesStroke(false);
        barRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray8 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray8);
        org.jfree.data.Range range10 = barRenderer5.findRangeBounds(categoryDataset9);
        org.jfree.data.Range range11 = barRenderer0.findRangeBounds(categoryDataset9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection17, valueAxis18, polarItemRenderer19);
        polarPlot20.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = polarPlot20.getOrientation();
        combinedRangeXYPlot15.setOrientation(plotOrientation23);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer25 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean26 = xYLineAndShapeRenderer25.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer25.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke30 = xYLineAndShapeRenderer25.getBaseOutlineStroke();
        java.awt.Stroke stroke32 = xYLineAndShapeRenderer25.lookupSeriesStroke(4);
        combinedRangeXYPlot15.setDomainCrosshairStroke(stroke32);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        numberAxis34.setFixedAutoRange((double) 9);
        combinedRangeXYPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis34);
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis34.setLeftArrow(shape39);
        java.text.NumberFormat numberFormat41 = java.text.NumberFormat.getNumberInstance();
        boolean boolean42 = numberFormat41.isParseIntegerOnly();
        numberAxis34.setNumberFormatOverride(numberFormat41);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis34, categoryItemRenderer44);
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        categoryPlot45.setRangeAxis((int) (byte) 100, valueAxis47);
        java.lang.Comparable comparable49 = categoryPlot45.getDomainCrosshairRowKey();
        categoryPlot45.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.IntervalMarker intervalMarker54 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 1.0f);
        java.awt.Paint paint55 = intervalMarker54.getOutlinePaint();
        java.awt.Stroke stroke56 = intervalMarker54.getOutlineStroke();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer57 = null;
        intervalMarker54.setGradientPaintTransformer(gradientPaintTransformer57);
        float float59 = intervalMarker54.getAlpha();
        categoryPlot45.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker54);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray61 = null;
        try {
            categoryPlot45.setDomainAxes(categoryAxisArray61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(numberFormat41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(comparable49);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertTrue("'" + float59 + "' != '" + 0.8f + "'", float59 == 0.8f);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        int int3 = piePlot2.getPieIndex();
        double double4 = piePlot2.getMaximumLabelWidth();
        piePlot2.setMaximumLabelWidth((double) (byte) 0);
        boolean boolean7 = xYStepRenderer0.equals((java.lang.Object) piePlot2);
        java.lang.Object obj8 = piePlot2.clone();
        double double9 = piePlot2.getLabelGap();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.14d + "'", double4 == 0.14d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.025d + "'", double9 == 0.025d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Shape shape1 = numberAxis3D0.getDownArrow();
        numberAxis3D0.configure();
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) waferMapPlot1);
        java.awt.Font font3 = legendTitle2.getItemFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("DateTickUnitType.SECOND", font3);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer5.setLegendTextFont((int) '#', font7);
        textTitle4.setFont(font7);
        java.awt.Paint paint10 = textTitle4.getBackgroundPaint();
        java.awt.geom.Rectangle2D rectangle2D11 = textTitle4.getBounds();
        textTitle4.setExpandToFitSpace(false);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(rectangle2D11);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("{0}: ({1}, {2})");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name {0}: ({1}, {2}), locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYLineAndShapeRenderer0.getNegativeItemLabelPosition(1, (int) (short) 10, true);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        xYLineAndShapeRenderer0.setSeriesShape(10, shape11);
        java.awt.Paint paint16 = xYLineAndShapeRenderer0.getItemOutlinePaint(2, (int) 'a', false);
        xYLineAndShapeRenderer0.setSeriesItemLabelsVisible(7, true);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator21 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYLineAndShapeRenderer0.setSeriesToolTipGenerator(2958465, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator21, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator24 = xYLineAndShapeRenderer0.getLegendItemURLGenerator();
        java.awt.Paint paint26 = xYLineAndShapeRenderer0.getSeriesPaint((int) '4');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator21);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator24);
        org.junit.Assert.assertNull(paint26);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        java.awt.Paint paint6 = polarPlot5.getAngleLabelPaint();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean8 = xYLineAndShapeRenderer7.getAutoPopulateSeriesOutlinePaint();
        java.awt.Font font9 = xYLineAndShapeRenderer7.getBaseItemLabelFont();
        polarPlot5.setAngleLabelFont(font9);
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("TimePeriodAnchor.START", font9);
        double double12 = labelBlock11.getWidth();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        java.text.NumberFormat numberFormat3 = java.text.NumberFormat.getNumberInstance();
        boolean boolean4 = numberFormat3.isParseIntegerOnly();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = new org.jfree.chart.axis.NumberTickUnit((double) 1, numberFormat3);
        int int6 = numberFormat3.getMaximumFractionDigits();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = new org.jfree.chart.axis.NumberTickUnit((double) 9, numberFormat3, (int) 'a');
        java.text.NumberFormat numberFormat9 = java.text.NumberFormat.getNumberInstance();
        boolean boolean10 = numberFormat9.isParseIntegerOnly();
        int int11 = numberFormat9.getMinimumIntegerDigits();
        numberFormat9.setMinimumFractionDigits(100);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator14 = new org.jfree.chart.labels.StandardPieToolTipGenerator("12/31/69 4:00 PM", numberFormat3, numberFormat9);
        java.lang.String str15 = standardPieToolTipGenerator14.getLabelFormat();
        org.junit.Assert.assertNotNull(numberFormat3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertNotNull(numberFormat9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "12/31/69 4:00 PM" + "'", str15.equals("12/31/69 4:00 PM"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        int int3 = java.awt.Color.HSBtoRGB(0.5f, (float) 1, 0.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getShadowsVisible();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator2, false);
        java.awt.Paint paint5 = barRenderer0.getBaseFillPaint();
        barRenderer0.setAutoPopulateSeriesFillPaint(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range2 = xYBarRenderer0.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.lang.Object obj3 = timeSeriesCollection1.clone();
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, true);
        try {
            org.jfree.data.time.TimeSeries timeSeries7 = timeSeriesCollection1.getSeries(64);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (64).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        java.awt.Color color0 = java.awt.Color.WHITE;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.color.ColorSpace colorSpace4 = color3.getColorSpace();
        boolean boolean6 = color3.equals((java.lang.Object) 'a');
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.color.ColorSpace colorSpace8 = color7.getColorSpace();
        float[] floatArray12 = new float[] { (short) 100, 3, 0L };
        float[] floatArray13 = color3.getColorComponents(colorSpace8, floatArray12);
        try {
            float[] floatArray14 = color0.getComponents(colorSpace2, floatArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(colorSpace4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(colorSpace8);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        double double3 = timeSeriesCollection1.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean7 = xYLineAndShapeRenderer6.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer6.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke11 = xYLineAndShapeRenderer6.getBaseOutlineStroke();
        java.awt.Stroke stroke13 = xYLineAndShapeRenderer6.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, valueAxis5, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer6);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = xYPlot14.getInsets();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYPlot14.setNoDataMessagePaint((java.awt.Paint) color16);
        org.jfree.chart.axis.LogAxis logAxis18 = new org.jfree.chart.axis.LogAxis();
        boolean boolean19 = logAxis18.isTickMarksVisible();
        java.awt.Paint paint20 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder(paint20);
        java.awt.Paint paint22 = blockBorder21.getPaint();
        logAxis18.setTickMarkPaint(paint22);
        int int24 = xYPlot14.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis18);
        java.text.NumberFormat numberFormat25 = logAxis18.getNumberFormatOverride();
        logAxis18.setFixedAutoRange((double) 12);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNull(numberFormat25);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.isVisible();
        numberAxis0.setAutoRangeStickyZero(false);
        org.jfree.data.Range range4 = numberAxis0.getDefaultAutoRange();
        float float5 = numberAxis0.getMinorTickMarkInsideLength();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        try {
            logAxis0.setBase((double) (-4145152));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'base' > 1.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        int int2 = piePlot1.getPieIndex();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        piePlot1.notifyListeners(plotChangeEvent3);
        java.awt.Shape shape5 = piePlot1.getLegendItemShape();
        java.awt.Paint paint6 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder(paint6);
        java.awt.Paint paint8 = blockBorder7.getPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic9 = new org.jfree.chart.title.LegendGraphic(shape5, paint8);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean11 = xYLineAndShapeRenderer10.getDrawOutlines();
        java.awt.Shape shape12 = xYLineAndShapeRenderer10.getBaseShape();
        legendGraphic9.setLine(shape12);
        boolean boolean14 = legendGraphic9.isShapeVisible();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState2 = timeSeriesCollection1.getSelectionState();
        java.util.List list3 = timeSeriesCollection1.getSeries();
        int int5 = timeSeriesCollection1.indexOf((java.lang.Comparable) 1.0f);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate7 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection1, true);
        java.lang.Object obj8 = intervalXYDelegate7.clone();
        try {
            double double11 = intervalXYDelegate7.getEndXValue(500, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 500, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(xYDatasetSelectionState2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        java.lang.String[] strArray1 = new java.lang.String[] {};
        org.jfree.chart.axis.SymbolAxis symbolAxis2 = new org.jfree.chart.axis.SymbolAxis("AxisLocation.BOTTOM_OR_LEFT", strArray1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        symbolAxis2.setGridBandAlternatePaint((java.awt.Paint) color3);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        int int2 = piePlot1.getPieIndex();
        double double3 = piePlot1.getMaximumLabelWidth();
        piePlot1.setMaximumLabelWidth((double) (byte) 0);
        piePlot1.setInteriorGap(0.0d);
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle8 = piePlot1.getLabelLinkStyle();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.14d + "'", double3 == 0.14d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle8);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((double) 2);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray3 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray3);
        org.jfree.data.Range range5 = barRenderer0.findRangeBounds(categoryDataset4);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = null;
        barRenderer0.setSeriesURLGenerator(255, categoryURLGenerator7, false);
        java.lang.Boolean boolean11 = barRenderer0.getSeriesVisibleInLegend((int) (byte) 100);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(categoryDataset4);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNull(boolean11);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator1 = xYBarRenderer0.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset2 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range3 = xYBarRenderer0.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset2);
        double double4 = xYBarRenderer0.getShadowXOffset();
        xYBarRenderer0.setShadowYOffset(0.0d);
        org.junit.Assert.assertNull(xYItemLabelGenerator1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) waferMapPlot3);
        java.lang.Object obj5 = legendTitle4.clone();
        org.jfree.chart.entity.TitleEntity titleEntity8 = new org.jfree.chart.entity.TitleEntity(shape2, (org.jfree.chart.title.Title) legendTitle4, "hi!", "");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle4.setLegendItemGraphicLocation(rectangleAnchor9);
        boolean boolean11 = rectangleEdge0.equals((java.lang.Object) legendTitle4);
        org.jfree.chart.block.BlockFrame blockFrame12 = legendTitle4.getFrame();
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(blockFrame12);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setStartAngle(1.0d);
        piePlot1.setSectionOutlinesVisible(false);
        java.awt.Paint paint6 = piePlot1.getBaseSectionOutlinePaint();
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYLineAndShapeRenderer0.getNegativeItemLabelPosition(1, (int) (short) 10, true);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        xYLineAndShapeRenderer0.setSeriesShape(10, shape11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        categoryAxis13.setLabelPaint((java.awt.Paint) color14);
        org.jfree.chart.entity.AxisEntity axisEntity17 = new org.jfree.chart.entity.AxisEntity(shape11, (org.jfree.chart.axis.Axis) categoryAxis13, "TimePeriodAnchor.START");
        categoryAxis13.setCategoryLabelPositionOffset((int) '#');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.setDomainCrosshairValue((double) 9, true);
        java.lang.Object obj4 = combinedRangeXYPlot0.clone();
        java.awt.Paint paint5 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 100.0d, (java.lang.Number) Double.NaN);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean4 = xYLineAndShapeRenderer3.getDrawOutlines();
        java.awt.Shape shape5 = xYLineAndShapeRenderer3.getBaseShape();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor6 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor6, textAnchor7);
        xYLineAndShapeRenderer3.setBaseNegativeItemLabelPosition(itemLabelPosition8);
        boolean boolean10 = xYDataItem2.equals((java.lang.Object) xYLineAndShapeRenderer3);
        boolean boolean11 = xYDataItem2.isSelected();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(itemLabelAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 1, (int) (short) -1, (java.lang.Comparable) 3, "hi!", "index.html");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.setDomainZeroBaselineVisible(false);
        combinedRangeXYPlot8.setDomainGridlinesVisible(false);
        org.jfree.chart.entity.PlotEntity plotEntity15 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) combinedRangeXYPlot8, "EXPAND", "");
        org.jfree.chart.plot.Plot plot16 = plotEntity15.getPlot();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(plot16);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator1 = xYBarRenderer0.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset2 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range3 = xYBarRenderer0.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset2);
        double double4 = xYBarRenderer0.getShadowXOffset();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean6 = xYLineAndShapeRenderer5.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer5.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke10 = xYLineAndShapeRenderer5.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath13 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean16 = textBlockAnchor14.equals((java.lang.Object) chartRenderingInfo15);
        java.awt.geom.Rectangle2D rectangle2D17 = chartRenderingInfo15.getChartArea();
        org.jfree.chart.RenderingSource renderingSource18 = null;
        combinedRangeXYPlot12.select(generalPath13, rectangle2D17, renderingSource18);
        org.jfree.chart.plot.XYPlot xYPlot20 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset21 = new org.jfree.data.xy.DefaultXYDataset();
        int int23 = defaultXYDataset21.indexOf((java.lang.Comparable) 0.5f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState25 = xYLineAndShapeRenderer5.initialise(graphics2D11, rectangle2D17, xYPlot20, (org.jfree.data.xy.XYDataset) defaultXYDataset21, plotRenderingInfo24);
        org.jfree.data.Range range26 = xYBarRenderer0.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset21);
        java.lang.Object obj27 = null;
        boolean boolean28 = defaultXYDataset21.equals(obj27);
        org.junit.Assert.assertNull(xYItemLabelGenerator1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(textBlockAnchor14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState25);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) waferMapPlot2);
        java.awt.Font font4 = legendTitle3.getItemFont();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("DateTickUnitType.SECOND", font4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Font font8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer6.setLegendTextFont((int) '#', font8);
        textTitle5.setFont(font8);
        java.awt.Paint paint11 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("TimePeriodAnchor.START", font8, paint11);
        java.lang.Object obj13 = null;
        boolean boolean14 = textBlock12.equals(obj13);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textBlock12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean3 = xYLineAndShapeRenderer2.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer5.setAutoPopulateSeriesStroke(false);
        barRenderer5.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray13 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray13);
        org.jfree.data.Range range15 = barRenderer10.findRangeBounds(categoryDataset14);
        org.jfree.data.Range range16 = barRenderer5.findRangeBounds(categoryDataset14);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis17.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection22 = new org.jfree.data.time.TimeSeriesCollection(timeZone21);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer24 = null;
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection22, valueAxis23, polarItemRenderer24);
        polarPlot25.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation28 = polarPlot25.getOrientation();
        combinedRangeXYPlot20.setOrientation(plotOrientation28);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer30 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean31 = xYLineAndShapeRenderer30.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer30.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke35 = xYLineAndShapeRenderer30.getBaseOutlineStroke();
        java.awt.Stroke stroke37 = xYLineAndShapeRenderer30.lookupSeriesStroke(4);
        combinedRangeXYPlot20.setDomainCrosshairStroke(stroke37);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis();
        numberAxis39.setFixedAutoRange((double) 9);
        combinedRangeXYPlot20.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis39);
        java.awt.Shape shape44 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis39.setLeftArrow(shape44);
        java.text.NumberFormat numberFormat46 = java.text.NumberFormat.getNumberInstance();
        boolean boolean47 = numberFormat46.isParseIntegerOnly();
        numberAxis39.setNumberFormatOverride(numberFormat46);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis17, (org.jfree.chart.axis.ValueAxis) numberAxis39, categoryItemRenderer49);
        org.jfree.chart.axis.ValueAxis valueAxis52 = null;
        categoryPlot50.setRangeAxis((int) (byte) 100, valueAxis52);
        java.awt.Stroke stroke54 = categoryPlot50.getRangeCrosshairStroke();
        xYLineAndShapeRenderer2.setSeriesOutlineStroke(64, stroke54);
        periodAxis1.setMinorTickMarkStroke(stroke54);
        periodAxis1.setMinorTickMarkInsideLength((float) (-1L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(categoryDataset14);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(plotOrientation28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(numberFormat46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(stroke54);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        double double3 = timeSeriesCollection1.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean7 = xYLineAndShapeRenderer6.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer6.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke11 = xYLineAndShapeRenderer6.getBaseOutlineStroke();
        java.awt.Stroke stroke13 = xYLineAndShapeRenderer6.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, valueAxis5, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer6);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = xYPlot14.getInsets();
        double double17 = rectangleInsets15.calculateBottomOutset((double) (short) 0);
        double double19 = rectangleInsets15.calculateRightOutset((double) 0.8f);
        double double21 = rectangleInsets15.calculateLeftOutset((double) 4);
        double double23 = rectangleInsets15.extendHeight((double) (-1L));
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.0d + "'", double17 == 4.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 8.0d + "'", double19 == 8.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 8.0d + "'", double21 == 8.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 7.0d + "'", double23 == 7.0d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 0L, (java.lang.Number) 100.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesStroke(false);
        barRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = barRenderer0.getToolTipGenerator(2147483647, (int) (short) 1, false);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        java.lang.Comparable comparable6 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) timeSeriesCollection2, comparable6);
        java.lang.Object obj8 = legendItemBlockContainer7.clone();
        java.lang.String str9 = legendItemBlockContainer7.getURLText();
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer1.setAutoPopulateSeriesStroke(false);
        barRenderer1.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray9);
        org.jfree.data.Range range11 = barRenderer6.findRangeBounds(categoryDataset10);
        org.jfree.data.Range range12 = barRenderer1.findRangeBounds(categoryDataset10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis13.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection18 = new org.jfree.data.time.TimeSeriesCollection(timeZone17);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer20 = null;
        org.jfree.chart.plot.PolarPlot polarPlot21 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection18, valueAxis19, polarItemRenderer20);
        polarPlot21.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = polarPlot21.getOrientation();
        combinedRangeXYPlot16.setOrientation(plotOrientation24);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer26 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean27 = xYLineAndShapeRenderer26.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer26.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke31 = xYLineAndShapeRenderer26.getBaseOutlineStroke();
        java.awt.Stroke stroke33 = xYLineAndShapeRenderer26.lookupSeriesStroke(4);
        combinedRangeXYPlot16.setDomainCrosshairStroke(stroke33);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis();
        numberAxis35.setFixedAutoRange((double) 9);
        combinedRangeXYPlot16.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis35);
        java.awt.Shape shape40 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis35.setLeftArrow(shape40);
        java.text.NumberFormat numberFormat42 = java.text.NumberFormat.getNumberInstance();
        boolean boolean43 = numberFormat42.isParseIntegerOnly();
        numberAxis35.setNumberFormatOverride(numberFormat42);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis35, categoryItemRenderer45);
        categoryPlot46.clearDomainMarkers();
        boolean boolean48 = categoryPlot46.isRangePannable();
        java.awt.Paint paint49 = categoryPlot46.getRangeMinorGridlinePaint();
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart("ERROR : Relative To String", (org.jfree.chart.plot.Plot) categoryPlot46);
        java.awt.Paint paint51 = jFreeChart50.getBackgroundPaint();
        org.jfree.chart.plot.Plot plot52 = jFreeChart50.getPlot();
        java.awt.Graphics2D graphics2D53 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot54 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot54.setDomainZeroBaselineVisible(false);
        combinedRangeXYPlot54.setDomainGridlinesVisible(false);
        org.jfree.data.xy.XYDataset xYDataset59 = combinedRangeXYPlot54.getDataset();
        java.awt.geom.GeneralPath generalPath60 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer61 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean62 = xYLineAndShapeRenderer61.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer61.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke66 = xYLineAndShapeRenderer61.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D67 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot68 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath69 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor70 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo71 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean72 = textBlockAnchor70.equals((java.lang.Object) chartRenderingInfo71);
        java.awt.geom.Rectangle2D rectangle2D73 = chartRenderingInfo71.getChartArea();
        org.jfree.chart.RenderingSource renderingSource74 = null;
        combinedRangeXYPlot68.select(generalPath69, rectangle2D73, renderingSource74);
        org.jfree.chart.plot.XYPlot xYPlot76 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset77 = new org.jfree.data.xy.DefaultXYDataset();
        int int79 = defaultXYDataset77.indexOf((java.lang.Comparable) 0.5f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo80 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState81 = xYLineAndShapeRenderer61.initialise(graphics2D67, rectangle2D73, xYPlot76, (org.jfree.data.xy.XYDataset) defaultXYDataset77, plotRenderingInfo80);
        org.jfree.chart.RenderingSource renderingSource82 = null;
        combinedRangeXYPlot54.select(generalPath60, rectangle2D73, renderingSource82);
        try {
            jFreeChart50.draw(graphics2D53, rectangle2D73);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(plotOrientation24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(numberFormat42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(plot52);
        org.junit.Assert.assertNull(xYDataset59);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNotNull(textBlockAnchor70);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(rectangle2D73);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-1) + "'", int79 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState81);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        java.lang.Comparable comparable6 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) timeSeriesCollection2, comparable6);
        legendItemBlockContainer7.setURLText("TextBlockAnchor.BOTTOM_LEFT");
        java.awt.Graphics2D graphics2D10 = null;
        try {
            org.jfree.chart.util.Size2D size2D11 = legendItemBlockContainer7.arrange(graphics2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true);
        xYSeries2.fireSeriesChanged();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries2);
        double[][] doubleArray5 = xYSeries2.toArray();
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarksVisible(false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        java.awt.Image image3 = null;
        org.jfree.chart.ui.ProjectInfo projectInfo7 = new org.jfree.chart.ui.ProjectInfo("RectangleEdge.TOP", "June 2019", "index.html", image3, "DateTickUnitType.SECOND", "", "DateTickUnit[DateTickUnitType.YEAR, 100]");
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((-4145152));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("TextBlockAnchor.BOTTOM_LEFT");
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesStroke(false);
        barRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray8 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray8);
        org.jfree.data.Range range10 = barRenderer5.findRangeBounds(categoryDataset9);
        org.jfree.data.Range range11 = barRenderer0.findRangeBounds(categoryDataset9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection17, valueAxis18, polarItemRenderer19);
        polarPlot20.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = polarPlot20.getOrientation();
        combinedRangeXYPlot15.setOrientation(plotOrientation23);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer25 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean26 = xYLineAndShapeRenderer25.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer25.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke30 = xYLineAndShapeRenderer25.getBaseOutlineStroke();
        java.awt.Stroke stroke32 = xYLineAndShapeRenderer25.lookupSeriesStroke(4);
        combinedRangeXYPlot15.setDomainCrosshairStroke(stroke32);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        numberAxis34.setFixedAutoRange((double) 9);
        combinedRangeXYPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis34);
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis34.setLeftArrow(shape39);
        java.text.NumberFormat numberFormat41 = java.text.NumberFormat.getNumberInstance();
        boolean boolean42 = numberFormat41.isParseIntegerOnly();
        numberAxis34.setNumberFormatOverride(numberFormat41);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis34, categoryItemRenderer44);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D46.setLabel("org.jfree.chart.event.RendererChangeEvent[source=1.0]");
        org.jfree.data.Range range49 = categoryPlot45.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D46);
        org.jfree.chart.axis.ValueAxis valueAxis50 = categoryPlot45.getRangeAxis();
        valueAxis50.setLowerBound((double) 9999);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(numberFormat41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertNotNull(valueAxis50);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean4 = textBlockAnchor2.equals((java.lang.Object) chartRenderingInfo3);
        java.awt.geom.Rectangle2D rectangle2D5 = chartRenderingInfo3.getChartArea();
        org.jfree.chart.RenderingSource renderingSource6 = null;
        combinedRangeXYPlot0.select(generalPath1, rectangle2D5, renderingSource6);
        java.awt.Paint paint8 = combinedRangeXYPlot0.getDomainCrosshairPaint();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeZone9);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer12 = null;
        org.jfree.chart.plot.PolarPlot polarPlot13 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection10, valueAxis11, polarItemRenderer12);
        polarPlot13.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = polarPlot13.getOrientation();
        combinedRangeXYPlot0.setOrientation(plotOrientation16);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(plotOrientation16);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.String str1 = verticalAlignment0.toString();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str1.equals("VerticalAlignment.BOTTOM"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesStroke(false);
        barRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray8 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray8);
        org.jfree.data.Range range10 = barRenderer5.findRangeBounds(categoryDataset9);
        org.jfree.data.Range range11 = barRenderer0.findRangeBounds(categoryDataset9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection17, valueAxis18, polarItemRenderer19);
        polarPlot20.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = polarPlot20.getOrientation();
        combinedRangeXYPlot15.setOrientation(plotOrientation23);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer25 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean26 = xYLineAndShapeRenderer25.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer25.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke30 = xYLineAndShapeRenderer25.getBaseOutlineStroke();
        java.awt.Stroke stroke32 = xYLineAndShapeRenderer25.lookupSeriesStroke(4);
        combinedRangeXYPlot15.setDomainCrosshairStroke(stroke32);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        numberAxis34.setFixedAutoRange((double) 9);
        combinedRangeXYPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis34);
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis34.setLeftArrow(shape39);
        java.text.NumberFormat numberFormat41 = java.text.NumberFormat.getNumberInstance();
        boolean boolean42 = numberFormat41.isParseIntegerOnly();
        numberAxis34.setNumberFormatOverride(numberFormat41);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis34, categoryItemRenderer44);
        categoryPlot45.clearDomainMarkers();
        int int47 = categoryPlot45.getCrosshairDatasetIndex();
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str49 = categoryAxis48.getLabelURL();
        categoryAxis48.setUpperMargin(Double.NaN);
        int int52 = categoryPlot45.getDomainAxisIndex(categoryAxis48);
        categoryPlot45.setCrosshairDatasetIndex(0, true);
        java.awt.Shape shape61 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color62 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem63 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape61, (java.awt.Paint) color62);
        categoryPlot45.setDomainCrosshairPaint((java.awt.Paint) color62);
        categoryPlot45.setCrosshairDatasetIndex(64);
        org.jfree.chart.axis.AxisLocation axisLocation68 = categoryPlot45.getRangeAxisLocation((int) '4');
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(numberFormat41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(shape61);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(axisLocation68);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true);
        xYSeries2.fireSeriesChanged();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries2);
        boolean boolean5 = xYSeries2.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        xYSeries2.removePropertyChangeListener(propertyChangeListener6);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = xYBarRenderer1.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset3 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range4 = xYBarRenderer1.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset3);
        double double5 = xYBarRenderer1.getShadowXOffset();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator6 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer1.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator6, true);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator9 = new org.jfree.chart.urls.StandardXYURLGenerator();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer10 = new org.jfree.chart.renderer.xy.XYAreaRenderer(8, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator6, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state13 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo12);
        java.awt.geom.GeneralPath generalPath14 = null;
        state13.seriesPath = generalPath14;
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState16 = state13.getCrosshairState();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor17 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean19 = textBlockAnchor17.equals((java.lang.Object) chartRenderingInfo18);
        java.awt.geom.Rectangle2D rectangle2D20 = chartRenderingInfo18.getChartArea();
        org.jfree.chart.entity.EntityCollection entityCollection21 = chartRenderingInfo18.getEntityCollection();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor22 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean24 = textBlockAnchor22.equals((java.lang.Object) chartRenderingInfo23);
        java.awt.geom.Rectangle2D rectangle2D25 = chartRenderingInfo23.getChartArea();
        chartRenderingInfo18.setChartArea(rectangle2D25);
        org.jfree.chart.plot.XYPlot xYPlot27 = null;
        org.jfree.chart.axis.LogAxis logAxis28 = new org.jfree.chart.axis.LogAxis();
        boolean boolean29 = logAxis28.isTickMarksVisible();
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        java.util.TimeZone timeZone31 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection32 = new org.jfree.data.time.TimeSeriesCollection(timeZone31);
        double double34 = timeSeriesCollection32.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer37 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean38 = xYLineAndShapeRenderer37.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer37.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke42 = xYLineAndShapeRenderer37.getBaseOutlineStroke();
        java.awt.Stroke stroke44 = xYLineAndShapeRenderer37.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection32, valueAxis35, valueAxis36, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer37);
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = xYPlot45.getInsets();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer47 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean48 = xYLineAndShapeRenderer47.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer47.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke52 = xYLineAndShapeRenderer47.getBaseOutlineStroke();
        java.awt.Stroke stroke54 = xYLineAndShapeRenderer47.lookupSeriesStroke(4);
        xYPlot45.setDomainGridlineStroke(stroke54);
        boolean boolean56 = xYPlot45.isRangeCrosshairVisible();
        boolean boolean57 = xYPlot45.isDomainGridlinesVisible();
        org.jfree.chart.block.CenterArrangement centerArrangement58 = new org.jfree.chart.block.CenterArrangement();
        java.util.TimeZone timeZone59 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection60 = new org.jfree.data.time.TimeSeriesCollection(timeZone59);
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer62 = null;
        org.jfree.chart.plot.PolarPlot polarPlot63 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection60, valueAxis61, polarItemRenderer62);
        java.lang.Comparable comparable64 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer65 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement58, (org.jfree.data.general.Dataset) timeSeriesCollection60, comparable64);
        xYPlot45.setDataset((org.jfree.data.xy.XYDataset) timeSeriesCollection60);
        try {
            xYAreaRenderer10.drawItem(graphics2D11, (org.jfree.chart.renderer.xy.XYItemRendererState) state13, rectangle2D25, xYPlot27, (org.jfree.chart.axis.ValueAxis) logAxis28, valueAxis30, (org.jfree.data.xy.XYDataset) timeSeriesCollection60, 0, (int) '4', true, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.renderer.xy.XYLineAndShapeRenderer$State cannot be cast to org.jfree.chart.renderer.xy.XYAreaRenderer$XYAreaRendererState");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNull(xYItemLabelGenerator2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator6);
        org.junit.Assert.assertNull(xYCrosshairState16);
        org.junit.Assert.assertNotNull(textBlockAnchor17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(entityCollection21);
        org.junit.Assert.assertNotNull(textBlockAnchor22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) (short) 100);
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange();
        java.util.Date date4 = dateRange3.getUpperDate();
        java.util.Date date5 = dateTickUnit2.rollDate(date4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date5);
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year6.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor2 = timeSeriesCollection1.getXPosition();
        java.lang.Object obj3 = timeSeriesCollection1.clone();
        org.junit.Assert.assertNotNull(timePeriodAnchor2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("EXPAND");
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setMinorTickCount(2);
        boolean boolean5 = dateAxis1.isNegativeArrowVisible();
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        java.awt.Shape shape4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity11 = new org.jfree.chart.entity.PieSectionEntity(shape4, pieDataset5, 1, (int) (short) -1, (java.lang.Comparable) 3, "hi!", "index.html");
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        piePlot13.setStartAngle(1.0d);
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape21, (java.awt.Paint) color22);
        piePlot13.setLabelLinkPaint((java.awt.Paint) color22);
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("", "TimePeriodAnchor.START", "TimePeriodAnchor.START", "DateTickUnitType.SECOND", shape4, (java.awt.Paint) color22);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        legendItem25.setOutlineStroke(stroke26);
        java.awt.Stroke stroke28 = null;
        legendItem25.setOutlineStroke(stroke28);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.05d, 3.0d, (double) 6, (double) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        polarPlot4.setAngleGridlinesVisible(false);
        boolean boolean7 = polarPlot4.isDomainZoomable();
        polarPlot4.setAngleLabelsVisible(false);
        java.awt.Stroke[] strokeArray10 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        boolean boolean11 = polarPlot4.equals((java.lang.Object) strokeArray10);
        java.lang.String str12 = polarPlot4.getNoDataMessage();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(strokeArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("rect");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = labelBlock1.getTextAnchor();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean6 = textBlockAnchor4.equals((java.lang.Object) chartRenderingInfo5);
        java.awt.geom.Rectangle2D rectangle2D7 = chartRenderingInfo5.getChartArea();
        org.jfree.chart.entity.EntityCollection entityCollection8 = chartRenderingInfo5.getEntityCollection();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean11 = textBlockAnchor9.equals((java.lang.Object) chartRenderingInfo10);
        java.awt.geom.Rectangle2D rectangle2D12 = chartRenderingInfo10.getChartArea();
        chartRenderingInfo5.setChartArea(rectangle2D12);
        java.awt.Shape shape18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.general.PieDataset pieDataset19 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity25 = new org.jfree.chart.entity.PieSectionEntity(shape18, pieDataset19, 1, (int) (short) -1, (java.lang.Comparable) 3, "hi!", "index.html");
        org.jfree.data.general.PieDataset pieDataset26 = null;
        org.jfree.chart.plot.PiePlot piePlot27 = new org.jfree.chart.plot.PiePlot(pieDataset26);
        piePlot27.setStartAngle(1.0d);
        java.awt.Shape shape35 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color36 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape35, (java.awt.Paint) color36);
        piePlot27.setLabelLinkPaint((java.awt.Paint) color36);
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("", "TimePeriodAnchor.START", "TimePeriodAnchor.START", "DateTickUnitType.SECOND", shape18, (java.awt.Paint) color36);
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        legendItem39.setFillPaint((java.awt.Paint) color40);
        org.jfree.data.general.Dataset dataset42 = legendItem39.getDataset();
        int int43 = legendItem39.getSeriesIndex();
        try {
            java.lang.Object obj44 = labelBlock1.draw(graphics2D3, rectangle2D12, (java.lang.Object) int43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(entityCollection8);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNull(dataset42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 7, (int) (short) 100, (int) (short) 1);
        segmentedTimeline3.setStartTime((long) 10);
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange();
        java.util.Date date7 = dateRange6.getUpperDate();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment8 = segmentedTimeline3.getSegment(date7);
        long long9 = segment8.getSegmentStart();
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(segment8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + (-4L) + "'", long9 == (-4L));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem9 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape7, (java.awt.Paint) color8);
        int int10 = color8.getGreen();
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("hi!", font1, (java.awt.Paint) color8);
        org.jfree.chart.text.TextFragment textFragment12 = textLine11.getLastTextFragment();
        java.awt.Graphics2D graphics2D13 = null;
        try {
            org.jfree.chart.util.Size2D size2D14 = textFragment12.calculateDimensions(graphics2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 64 + "'", int10 == 64);
        org.junit.Assert.assertNotNull(textFragment12);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke5 = xYLineAndShapeRenderer0.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath8 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean11 = textBlockAnchor9.equals((java.lang.Object) chartRenderingInfo10);
        java.awt.geom.Rectangle2D rectangle2D12 = chartRenderingInfo10.getChartArea();
        org.jfree.chart.RenderingSource renderingSource13 = null;
        combinedRangeXYPlot7.select(generalPath8, rectangle2D12, renderingSource13);
        org.jfree.chart.plot.XYPlot xYPlot15 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset16 = new org.jfree.data.xy.DefaultXYDataset();
        int int18 = defaultXYDataset16.indexOf((java.lang.Comparable) 0.5f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState20 = xYLineAndShapeRenderer0.initialise(graphics2D6, rectangle2D12, xYPlot15, (org.jfree.data.xy.XYDataset) defaultXYDataset16, plotRenderingInfo19);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Shape shape22 = numberAxis3D21.getDownArrow();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer23 = null;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) defaultXYDataset16, (org.jfree.chart.axis.ValueAxis) numberAxis3D21, polarItemRenderer23);
        try {
            java.lang.Number number27 = defaultXYDataset16.getY(500, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 500, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState20);
        org.junit.Assert.assertNotNull(shape22);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        int int1 = barRenderer0.getRowCount();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 100.0d, (java.lang.Number) Double.NaN);
        java.lang.Number number3 = xYDataItem2.getY();
        org.junit.Assert.assertEquals((double) number3, Double.NaN, 0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        polarPlot5.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = polarPlot5.getOrientation();
        combinedRangeXYPlot0.setOrientation(plotOrientation8);
        combinedRangeXYPlot0.setRangeCrosshairValue(0.0d);
        boolean boolean12 = combinedRangeXYPlot0.isDomainCrosshairVisible();
        boolean boolean13 = combinedRangeXYPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor16 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean18 = textBlockAnchor16.equals((java.lang.Object) chartRenderingInfo17);
        java.awt.geom.Rectangle2D rectangle2D19 = chartRenderingInfo17.getChartArea();
        org.jfree.chart.entity.EntityCollection entityCollection20 = chartRenderingInfo17.getEntityCollection();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor21 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean23 = textBlockAnchor21.equals((java.lang.Object) chartRenderingInfo22);
        java.awt.geom.Rectangle2D rectangle2D24 = chartRenderingInfo22.getChartArea();
        chartRenderingInfo17.setChartArea(rectangle2D24);
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection27 = new org.jfree.data.time.TimeSeriesCollection(timeZone26);
        double double29 = timeSeriesCollection27.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer32 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean33 = xYLineAndShapeRenderer32.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer32.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke37 = xYLineAndShapeRenderer32.getBaseOutlineStroke();
        java.awt.Stroke stroke39 = xYLineAndShapeRenderer32.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection27, valueAxis30, valueAxis31, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer32);
        org.jfree.chart.block.LineBorder lineBorder42 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint43 = lineBorder42.getPaint();
        xYLineAndShapeRenderer32.setSeriesItemLabelPaint((int) (short) 0, paint43, false);
        boolean boolean46 = chartRenderingInfo17.equals((java.lang.Object) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = chartRenderingInfo17.getPlotInfo();
        java.awt.geom.Point2D point2D48 = null;
        try {
            combinedRangeXYPlot0.zoomRangeAxes((double) 500, (double) 10, plotRenderingInfo47, point2D48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (525.0) <= upper (10.5).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(textBlockAnchor16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(entityCollection20);
        org.junit.Assert.assertNotNull(textBlockAnchor21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo47);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 7, (int) (short) 100, (int) (short) 1);
        segmentedTimeline3.setStartTime((long) 10);
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType7 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType7, (int) (short) 100);
        org.jfree.data.time.DateRange dateRange10 = new org.jfree.data.time.DateRange();
        java.util.Date date11 = dateRange10.getUpperDate();
        java.util.Date date12 = dateTickUnit9.rollDate(date11);
        boolean boolean13 = blockContainer6.equals((java.lang.Object) date12);
        java.util.List list14 = blockContainer6.getBlocks();
        segmentedTimeline3.addExceptions(list14);
        org.junit.Assert.assertNotNull(dateTickUnitType7);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(list14);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState(0.0d);
        java.util.List list2 = null;
        axisState1.setTicks(list2);
        java.util.List list4 = axisState1.getTicks();
        org.junit.Assert.assertNull(list4);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.setDomainCrosshairValue((double) 9, true);
        combinedRangeXYPlot0.setRangeCrosshairVisible(false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getNumberInstance();
        boolean boolean2 = numberFormat1.isParseIntegerOnly();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) 1, numberFormat1);
        int int4 = numberFormat1.getMaximumFractionDigits();
        int int5 = numberFormat1.getMaximumFractionDigits();
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 1.0f);
        java.awt.Paint paint9 = intervalMarker8.getOutlinePaint();
        java.awt.Stroke stroke10 = intervalMarker8.getOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        intervalMarker8.setLabelAnchor(rectangleAnchor11);
        java.lang.String str13 = intervalMarker8.getLabel();
        java.lang.StringBuffer stringBuffer14 = null;
        java.text.FieldPosition fieldPosition15 = null;
        try {
            java.lang.StringBuffer stringBuffer16 = numberFormat1.format((java.lang.Object) intervalMarker8, stringBuffer14, fieldPosition15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleAnchor11);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        int int1 = barRenderer0.getRowCount();
        double[][] doubleArray4 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray4);
        org.jfree.data.Range range6 = barRenderer0.findRangeBounds(categoryDataset5);
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset5, (java.lang.Comparable) Double.NaN);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset5, (double) (byte) 0);
        java.lang.Number number11 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset5);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(categoryDataset5);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(pieDataset8);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(number11);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) waferMapPlot2);
        java.lang.Object obj4 = legendTitle3.clone();
        org.jfree.chart.entity.TitleEntity titleEntity7 = new org.jfree.chart.entity.TitleEntity(shape1, (org.jfree.chart.title.Title) legendTitle3, "hi!", "");
        org.jfree.chart.block.BlockContainer blockContainer8 = new org.jfree.chart.block.BlockContainer();
        legendTitle3.setWrapper(blockContainer8);
        java.awt.Font font10 = legendTitle3.getItemFont();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.data.Range range13 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) (-1), range13);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = rectangleConstraint14.getWidthConstraintType();
        org.jfree.data.Range range16 = rectangleConstraint14.getWidthRange();
        org.jfree.data.Range range18 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint(0.2d, range18);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = rectangleConstraint14.toRangeWidth(range18);
        try {
            org.jfree.chart.util.Size2D size2D21 = legendTitle3.arrange(graphics2D11, rectangleConstraint14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(lengthConstraintType15);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(rectangleConstraint20);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator1 = xYBarRenderer0.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset2 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range3 = xYBarRenderer0.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset2);
        java.awt.Shape shape5 = xYBarRenderer0.getLegendShape(7);
        org.junit.Assert.assertNull(xYItemLabelGenerator1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(shape5);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState(0.0d);
        double double2 = axisState1.getMax();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesStroke(false);
        barRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray8 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray8);
        org.jfree.data.Range range10 = barRenderer5.findRangeBounds(categoryDataset9);
        org.jfree.data.Range range11 = barRenderer0.findRangeBounds(categoryDataset9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection17, valueAxis18, polarItemRenderer19);
        polarPlot20.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = polarPlot20.getOrientation();
        combinedRangeXYPlot15.setOrientation(plotOrientation23);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer25 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean26 = xYLineAndShapeRenderer25.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer25.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke30 = xYLineAndShapeRenderer25.getBaseOutlineStroke();
        java.awt.Stroke stroke32 = xYLineAndShapeRenderer25.lookupSeriesStroke(4);
        combinedRangeXYPlot15.setDomainCrosshairStroke(stroke32);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        numberAxis34.setFixedAutoRange((double) 9);
        combinedRangeXYPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis34);
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis34.setLeftArrow(shape39);
        java.text.NumberFormat numberFormat41 = java.text.NumberFormat.getNumberInstance();
        boolean boolean42 = numberFormat41.isParseIntegerOnly();
        numberAxis34.setNumberFormatOverride(numberFormat41);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis34, categoryItemRenderer44);
        numberAxis34.setMinorTickMarkInsideLength((float) (-9999));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(numberFormat41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType1 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType1, (int) (short) 100);
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange();
        java.util.Date date5 = dateRange4.getUpperDate();
        java.util.Date date6 = dateTickUnit3.rollDate(date5);
        boolean boolean7 = blockContainer0.equals((java.lang.Object) date6);
        org.jfree.chart.block.Arrangement arrangement8 = blockContainer0.getArrangement();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot10.setDomainZeroBaselineVisible(false);
        combinedRangeXYPlot10.setDomainGridlinesVisible(false);
        org.jfree.data.xy.XYDataset xYDataset15 = combinedRangeXYPlot10.getDataset();
        java.awt.geom.GeneralPath generalPath16 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean18 = xYLineAndShapeRenderer17.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer17.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke22 = xYLineAndShapeRenderer17.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot24 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath25 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor26 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean28 = textBlockAnchor26.equals((java.lang.Object) chartRenderingInfo27);
        java.awt.geom.Rectangle2D rectangle2D29 = chartRenderingInfo27.getChartArea();
        org.jfree.chart.RenderingSource renderingSource30 = null;
        combinedRangeXYPlot24.select(generalPath25, rectangle2D29, renderingSource30);
        org.jfree.chart.plot.XYPlot xYPlot32 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset33 = new org.jfree.data.xy.DefaultXYDataset();
        int int35 = defaultXYDataset33.indexOf((java.lang.Comparable) 0.5f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState37 = xYLineAndShapeRenderer17.initialise(graphics2D23, rectangle2D29, xYPlot32, (org.jfree.data.xy.XYDataset) defaultXYDataset33, plotRenderingInfo36);
        org.jfree.chart.RenderingSource renderingSource38 = null;
        combinedRangeXYPlot10.select(generalPath16, rectangle2D29, renderingSource38);
        try {
            blockContainer0.draw(graphics2D9, rectangle2D29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(arrangement8);
        org.junit.Assert.assertNull(xYDataset15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(textBlockAnchor26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState37);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint3 = xYLineAndShapeRenderer0.lookupLegendTextPaint((int) (short) 100);
        xYLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(true);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.data.Range range9 = combinedRangeXYPlot7.getDataRange(valueAxis8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = combinedRangeXYPlot7.getDomainAxisLocation(0);
        java.lang.String[] strArray13 = new java.lang.String[] {};
        org.jfree.chart.axis.SymbolAxis symbolAxis14 = new org.jfree.chart.axis.SymbolAxis("AxisLocation.BOTTOM_OR_LEFT", strArray13);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot15.setDomainZeroBaselineVisible(false);
        combinedRangeXYPlot15.setDomainGridlinesVisible(false);
        org.jfree.data.xy.XYDataset xYDataset20 = combinedRangeXYPlot15.getDataset();
        java.awt.geom.GeneralPath generalPath21 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer22 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean23 = xYLineAndShapeRenderer22.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer22.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke27 = xYLineAndShapeRenderer22.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot29 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath30 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor31 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean33 = textBlockAnchor31.equals((java.lang.Object) chartRenderingInfo32);
        java.awt.geom.Rectangle2D rectangle2D34 = chartRenderingInfo32.getChartArea();
        org.jfree.chart.RenderingSource renderingSource35 = null;
        combinedRangeXYPlot29.select(generalPath30, rectangle2D34, renderingSource35);
        org.jfree.chart.plot.XYPlot xYPlot37 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset38 = new org.jfree.data.xy.DefaultXYDataset();
        int int40 = defaultXYDataset38.indexOf((java.lang.Comparable) 0.5f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState42 = xYLineAndShapeRenderer22.initialise(graphics2D28, rectangle2D34, xYPlot37, (org.jfree.data.xy.XYDataset) defaultXYDataset38, plotRenderingInfo41);
        org.jfree.chart.RenderingSource renderingSource43 = null;
        combinedRangeXYPlot15.select(generalPath21, rectangle2D34, renderingSource43);
        xYLineAndShapeRenderer0.fillDomainGridBand(graphics2D6, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot7, (org.jfree.chart.axis.ValueAxis) symbolAxis14, rectangle2D34, 100.0d, 0.025d);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer49 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean50 = xYLineAndShapeRenderer49.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer49.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition57 = xYLineAndShapeRenderer49.getNegativeItemLabelPosition(1, (int) (short) 10, true);
        boolean boolean58 = xYLineAndShapeRenderer49.getAutoPopulateSeriesShape();
        java.util.TimeZone timeZone59 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection60 = new org.jfree.data.time.TimeSeriesCollection(timeZone59);
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer62 = null;
        org.jfree.chart.plot.PolarPlot polarPlot63 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection60, valueAxis61, polarItemRenderer62);
        java.awt.Paint paint64 = polarPlot63.getAngleLabelPaint();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer65 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean66 = xYLineAndShapeRenderer65.getAutoPopulateSeriesOutlinePaint();
        java.awt.Font font67 = xYLineAndShapeRenderer65.getBaseItemLabelFont();
        polarPlot63.setAngleLabelFont(font67);
        xYLineAndShapeRenderer49.setBaseLegendTextFont(font67);
        java.awt.Stroke stroke73 = xYLineAndShapeRenderer49.getItemOutlineStroke(0, (-1), false);
        xYLineAndShapeRenderer49.setAutoPopulateSeriesFillPaint(false);
        try {
            combinedRangeXYPlot7.setRenderer(2147483647, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer49);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(strArray13);
        org.junit.Assert.assertNull(xYDataset20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(textBlockAnchor31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState42);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(font67);
        org.junit.Assert.assertNotNull(stroke73);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState0 = new org.jfree.chart.plot.XYCrosshairState();
        java.awt.geom.Point2D point2D1 = xYCrosshairState0.getAnchor();
        xYCrosshairState0.setAnchorX((double) 10);
        int int4 = xYCrosshairState0.getDomainAxisIndex();
        org.junit.Assert.assertNull(point2D1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState0 = new org.jfree.chart.plot.XYCrosshairState();
        xYCrosshairState0.updateCrosshairY((double) (short) 0, (-4145152));
        int int4 = xYCrosshairState0.getRangeAxisIndex();
        xYCrosshairState0.setCrosshairY((double) 1);
        int int7 = xYCrosshairState0.getDomainAxisIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.LineUtilities.clipLine(line2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true);
        xYSeries2.fireSeriesChanged();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries2);
        boolean boolean5 = xYSeries2.isEmpty();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        int int8 = piePlot7.getPieIndex();
        boolean boolean10 = piePlot7.equals((java.lang.Object) "");
        float float11 = piePlot7.getBackgroundImageAlpha();
        java.awt.Shape shape16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity23 = new org.jfree.chart.entity.PieSectionEntity(shape16, pieDataset17, 1, (int) (short) -1, (java.lang.Comparable) 3, "hi!", "index.html");
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot(pieDataset24);
        piePlot25.setStartAngle(1.0d);
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape33, (java.awt.Paint) color34);
        piePlot25.setLabelLinkPaint((java.awt.Paint) color34);
        org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("", "TimePeriodAnchor.START", "TimePeriodAnchor.START", "DateTickUnitType.SECOND", shape16, (java.awt.Paint) color34);
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        legendItem37.setFillPaint((java.awt.Paint) color38);
        piePlot7.setLabelBackgroundPaint((java.awt.Paint) color38);
        boolean boolean41 = xYSeries2.equals((java.lang.Object) color38);
        java.util.List list42 = xYSeries2.getItems();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(list42);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.setDomainZeroBaselineVisible(false);
        combinedRangeXYPlot0.setDomainGridlinesVisible(false);
        boolean boolean5 = combinedRangeXYPlot0.isRangeZeroBaselineVisible();
        combinedRangeXYPlot0.setRangeMinorGridlinesVisible(false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape2 = null;
        xYLineAndShapeRenderer0.setBaseLegendShape(shape2);
        xYLineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, false);
        xYLineAndShapeRenderer0.setSeriesCreateEntities((int) (short) 0, (java.lang.Boolean) true);
        java.lang.Object obj11 = xYLineAndShapeRenderer0.clone();
        java.awt.Paint paint15 = xYLineAndShapeRenderer0.getItemLabelPaint((int) (byte) 1, (int) (byte) 10, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesStroke(false);
        barRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray8 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray8);
        org.jfree.data.Range range10 = barRenderer5.findRangeBounds(categoryDataset9);
        org.jfree.data.Range range11 = barRenderer0.findRangeBounds(categoryDataset9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection17, valueAxis18, polarItemRenderer19);
        polarPlot20.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = polarPlot20.getOrientation();
        combinedRangeXYPlot15.setOrientation(plotOrientation23);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer25 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean26 = xYLineAndShapeRenderer25.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer25.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke30 = xYLineAndShapeRenderer25.getBaseOutlineStroke();
        java.awt.Stroke stroke32 = xYLineAndShapeRenderer25.lookupSeriesStroke(4);
        combinedRangeXYPlot15.setDomainCrosshairStroke(stroke32);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        numberAxis34.setFixedAutoRange((double) 9);
        combinedRangeXYPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis34);
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis34.setLeftArrow(shape39);
        java.text.NumberFormat numberFormat41 = java.text.NumberFormat.getNumberInstance();
        boolean boolean42 = numberFormat41.isParseIntegerOnly();
        numberAxis34.setNumberFormatOverride(numberFormat41);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis34, categoryItemRenderer44);
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        categoryPlot45.setRangeAxis((int) (byte) 100, valueAxis47);
        java.lang.Comparable comparable49 = categoryPlot45.getDomainCrosshairRowKey();
        java.awt.Stroke stroke50 = categoryPlot45.getRangeMinorGridlineStroke();
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = categoryPlot45.getRangeAxisEdge((int) (short) 0);
        categoryPlot45.clearDomainAxes();
        categoryPlot45.setRangeZeroBaselineVisible(true);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(numberFormat41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(comparable49);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(rectangleEdge52);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.lang.Object obj1 = numberAxis0.clone();
        java.awt.Shape shape2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity9 = new org.jfree.chart.entity.PieSectionEntity(shape2, pieDataset3, 1, (int) (short) -1, (java.lang.Comparable) 3, "hi!", "index.html");
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray15 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.data.Range range17 = barRenderer12.findRangeBounds(categoryDataset16);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity20 = new org.jfree.chart.entity.CategoryItemEntity(shape2, "hi!", "hi!", categoryDataset16, (java.lang.Comparable) 64, (java.lang.Comparable) (short) 0);
        numberAxis0.setDownArrow(shape2);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNull(range17);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator1 = new org.jfree.chart.urls.StandardXYURLGenerator("{0}");
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        java.awt.Stroke stroke5 = polarPlot4.getRadiusGridlineStroke();
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        int int2 = piePlot1.getPieIndex();
        double double3 = piePlot1.getMaximumLabelWidth();
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        piePlot1.setLabelBackgroundPaint(paint4);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = piePlot1.getLegendItems();
        java.awt.Paint paint7 = piePlot1.getLabelOutlinePaint();
        java.awt.Stroke stroke8 = piePlot1.getBaseSectionOutlineStroke();
        org.jfree.chart.plot.Plot plot9 = piePlot1.getRootPlot();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.14d + "'", double3 == 0.14d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(plot9);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        java.text.NumberFormat numberFormat4 = java.text.NumberFormat.getNumberInstance();
        boolean boolean5 = numberFormat4.isParseIntegerOnly();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit6 = new org.jfree.chart.axis.NumberTickUnit((double) 1, numberFormat4);
        int int7 = numberFormat4.getMaximumFractionDigits();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit9 = new org.jfree.chart.axis.NumberTickUnit((double) 9, numberFormat4, (int) 'a');
        java.text.NumberFormat numberFormat10 = java.text.NumberFormat.getNumberInstance();
        boolean boolean11 = numberFormat10.isParseIntegerOnly();
        int int12 = numberFormat10.getMinimumIntegerDigits();
        numberFormat10.setMinimumFractionDigits(100);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator15 = new org.jfree.chart.labels.StandardPieToolTipGenerator("12/31/69 4:00 PM", numberFormat4, numberFormat10);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit17 = new org.jfree.chart.axis.NumberTickUnit(0.4d, numberFormat10, 9999);
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertNotNull(numberFormat10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getBaseShapesVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = xYLineAndShapeRenderer0.getDrawingSupplier();
        org.jfree.chart.axis.PeriodAxis periodAxis5 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean7 = xYLineAndShapeRenderer6.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer9.setAutoPopulateSeriesStroke(false);
        barRenderer9.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray17 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray17);
        org.jfree.data.Range range19 = barRenderer14.findRangeBounds(categoryDataset18);
        org.jfree.data.Range range20 = barRenderer9.findRangeBounds(categoryDataset18);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis21.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot24 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection26 = new org.jfree.data.time.TimeSeriesCollection(timeZone25);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer28 = null;
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection26, valueAxis27, polarItemRenderer28);
        polarPlot29.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation32 = polarPlot29.getOrientation();
        combinedRangeXYPlot24.setOrientation(plotOrientation32);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer34 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean35 = xYLineAndShapeRenderer34.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer34.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke39 = xYLineAndShapeRenderer34.getBaseOutlineStroke();
        java.awt.Stroke stroke41 = xYLineAndShapeRenderer34.lookupSeriesStroke(4);
        combinedRangeXYPlot24.setDomainCrosshairStroke(stroke41);
        org.jfree.chart.axis.NumberAxis numberAxis43 = new org.jfree.chart.axis.NumberAxis();
        numberAxis43.setFixedAutoRange((double) 9);
        combinedRangeXYPlot24.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis43);
        java.awt.Shape shape48 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis43.setLeftArrow(shape48);
        java.text.NumberFormat numberFormat50 = java.text.NumberFormat.getNumberInstance();
        boolean boolean51 = numberFormat50.isParseIntegerOnly();
        numberAxis43.setNumberFormatOverride(numberFormat50);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis21, (org.jfree.chart.axis.ValueAxis) numberAxis43, categoryItemRenderer53);
        org.jfree.chart.axis.ValueAxis valueAxis56 = null;
        categoryPlot54.setRangeAxis((int) (byte) 100, valueAxis56);
        java.awt.Stroke stroke58 = categoryPlot54.getRangeCrosshairStroke();
        xYLineAndShapeRenderer6.setSeriesOutlineStroke(64, stroke58);
        periodAxis5.setMinorTickMarkStroke(stroke58);
        xYLineAndShapeRenderer0.setSeriesOutlineStroke((int) (short) 100, stroke58, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(drawingSupplier2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNotNull(plotOrientation32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNotNull(numberFormat50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(stroke58);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo0);
        java.awt.geom.GeneralPath generalPath2 = null;
        state1.seriesPath = generalPath2;
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState4 = state1.getCrosshairState();
        int int5 = state1.getFirstItemIndex();
        org.junit.Assert.assertNull(xYCrosshairState4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        java.awt.Paint paint5 = polarPlot4.getAngleLabelPaint();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        double double7 = legendTitle6.getContentXOffset();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo8 = null;
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) legendTitle6, seriesChangeInfo8);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo10 = null;
        seriesChangeEvent9.setSummary(seriesChangeInfo10);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo12 = null;
        seriesChangeEvent9.setSummary(seriesChangeInfo12);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer1 = null;
        combinedRangeXYPlot0.setRenderer(xYItemRenderer1);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean6 = textBlockAnchor4.equals((java.lang.Object) chartRenderingInfo5);
        java.awt.geom.Rectangle2D rectangle2D7 = chartRenderingInfo5.getChartArea();
        org.jfree.chart.entity.EntityCollection entityCollection8 = chartRenderingInfo5.getEntityCollection();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean11 = textBlockAnchor9.equals((java.lang.Object) chartRenderingInfo10);
        java.awt.geom.Rectangle2D rectangle2D12 = chartRenderingInfo10.getChartArea();
        chartRenderingInfo5.setChartArea(rectangle2D12);
        java.util.TimeZone timeZone14 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection15 = new org.jfree.data.time.TimeSeriesCollection(timeZone14);
        double double17 = timeSeriesCollection15.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer20 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean21 = xYLineAndShapeRenderer20.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer20.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke25 = xYLineAndShapeRenderer20.getBaseOutlineStroke();
        java.awt.Stroke stroke27 = xYLineAndShapeRenderer20.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection15, valueAxis18, valueAxis19, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer20);
        org.jfree.chart.block.LineBorder lineBorder30 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint31 = lineBorder30.getPaint();
        xYLineAndShapeRenderer20.setSeriesItemLabelPaint((int) (short) 0, paint31, false);
        boolean boolean34 = chartRenderingInfo5.equals((java.lang.Object) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = chartRenderingInfo5.getPlotInfo();
        java.awt.geom.Point2D point2D36 = null;
        try {
            combinedRangeXYPlot0.zoomDomainAxes(8.0d, plotRenderingInfo35, point2D36, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(entityCollection8);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo35);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0);
        xYAreaRenderer1.setUseFillPaint(true);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        try {
            org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) 100, (double) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (3.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesStroke(false);
        barRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray8 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray8);
        org.jfree.data.Range range10 = barRenderer5.findRangeBounds(categoryDataset9);
        org.jfree.data.Range range11 = barRenderer0.findRangeBounds(categoryDataset9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection17, valueAxis18, polarItemRenderer19);
        polarPlot20.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = polarPlot20.getOrientation();
        combinedRangeXYPlot15.setOrientation(plotOrientation23);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer25 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean26 = xYLineAndShapeRenderer25.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer25.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke30 = xYLineAndShapeRenderer25.getBaseOutlineStroke();
        java.awt.Stroke stroke32 = xYLineAndShapeRenderer25.lookupSeriesStroke(4);
        combinedRangeXYPlot15.setDomainCrosshairStroke(stroke32);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        numberAxis34.setFixedAutoRange((double) 9);
        combinedRangeXYPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis34);
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis34.setLeftArrow(shape39);
        java.text.NumberFormat numberFormat41 = java.text.NumberFormat.getNumberInstance();
        boolean boolean42 = numberFormat41.isParseIntegerOnly();
        numberAxis34.setNumberFormatOverride(numberFormat41);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis34, categoryItemRenderer44);
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        categoryPlot45.setRangeAxis((int) (byte) 100, valueAxis47);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent49 = null;
        categoryPlot45.markerChanged(markerChangeEvent49);
        org.jfree.chart.axis.AxisSpace axisSpace51 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot45.setFixedRangeAxisSpace(axisSpace51, false);
        axisSpace51.setRight(100.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(numberFormat41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getCurrencyInstance();
        numberFormat0.setMinimumFractionDigits((int) (byte) 100);
        java.util.Currency currency3 = numberFormat0.getCurrency();
        boolean boolean4 = numberFormat0.isParseIntegerOnly();
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertNotNull(currency3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        double double3 = timeSeriesCollection1.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean7 = xYLineAndShapeRenderer6.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer6.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke11 = xYLineAndShapeRenderer6.getBaseOutlineStroke();
        java.awt.Stroke stroke13 = xYLineAndShapeRenderer6.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, valueAxis5, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer6);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot14.getRangeAxisEdge(3);
        int int17 = xYPlot14.getDatasetCount();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = null;
        xYPlot14.datasetChanged(datasetChangeEvent18);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 1.0f);
        java.awt.Paint paint24 = intervalMarker23.getOutlinePaint();
        java.awt.Stroke stroke25 = intervalMarker23.getOutlineStroke();
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str27 = layer26.toString();
        boolean boolean28 = xYPlot14.removeDomainMarker(9999, (org.jfree.chart.plot.Marker) intervalMarker23, layer26);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent29 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker23);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = intervalMarker23.getLabelAnchor();
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "Layer.FOREGROUND" + "'", str27.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.text.TextLine textLine2 = new org.jfree.chart.text.TextLine("index.html", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true);
        xYSeries2.fireSeriesChanged();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries2);
        xYSeries2.setMaximumItemCount((int) ' ');
        xYSeries2.add((java.lang.Number) 9999, (java.lang.Number) 10, true);
        xYSeries2.clear();
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.setDomainZeroBaselineVisible(false);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean7 = combinedRangeXYPlot0.removeDomainMarker((int) (short) 0, marker4, layer5, false);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation9 = axisLocation8.getOpposite();
        combinedRangeXYPlot0.setDomainAxisLocation(axisLocation9, false);
        boolean boolean12 = combinedRangeXYPlot0.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.data.Range range3 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = new org.jfree.chart.block.RectangleConstraint((double) (-1), range3);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType5 = rectangleConstraint4.getWidthConstraintType();
        org.jfree.data.Range range6 = rectangleConstraint4.getWidthRange();
        try {
            org.jfree.chart.util.Size2D size2D7 = blockContainer0.arrange(graphics2D1, rectangleConstraint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (0.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(lengthConstraintType5);
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.setDomainZeroBaselineVisible(false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot3.setDomainCrosshairValue((double) 9, true);
        boolean boolean7 = combinedRangeXYPlot3.isDomainCrosshairLockedOnData();
        combinedRangeXYPlot0.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = null;
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection11, valueAxis12, polarItemRenderer13);
        polarPlot14.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = polarPlot14.getOrientation();
        combinedRangeXYPlot9.setOrientation(plotOrientation17);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer19 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean20 = xYLineAndShapeRenderer19.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer19.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke24 = xYLineAndShapeRenderer19.getBaseOutlineStroke();
        java.awt.Stroke stroke26 = xYLineAndShapeRenderer19.lookupSeriesStroke(4);
        combinedRangeXYPlot9.setDomainCrosshairStroke(stroke26);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        numberAxis28.setFixedAutoRange((double) 9);
        combinedRangeXYPlot9.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis28);
        numberAxis28.setUpperMargin((double) 255);
        combinedRangeXYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis28);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 1.0f);
        java.awt.Paint paint3 = intervalMarker2.getOutlinePaint();
        java.awt.Stroke stroke4 = intervalMarker2.getOutlineStroke();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer5 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer5);
        float float7 = intervalMarker2.getAlpha();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent8 = null;
        intervalMarker2.notifyListeners(markerChangeEvent8);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str11 = categoryAxis10.getLabelURL();
        java.awt.Font font13 = categoryAxis10.getTickLabelFont((java.lang.Comparable) (byte) 100);
        double double14 = categoryAxis10.getFixedDimension();
        boolean boolean15 = categoryAxis10.isAxisLineVisible();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.previous();
        java.awt.Paint paint18 = categoryAxis10.getTickLabelPaint((java.lang.Comparable) regularTimePeriod17);
        intervalMarker2.setPaint(paint18);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.8f + "'", float7 == 0.8f);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray3 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset4 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray3);
        org.jfree.data.Range range5 = barRenderer0.findRangeBounds(categoryDataset4);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = null;
        barRenderer0.setSeriesURLGenerator(255, categoryURLGenerator7, false);
        barRenderer0.setSeriesItemLabelsVisible(500, true);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(categoryDataset4);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        int int2 = piePlot1.getPieIndex();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        piePlot1.notifyListeners(plotChangeEvent3);
        double double5 = piePlot1.getInteriorGap();
        boolean boolean6 = piePlot1.isCircular();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        polarPlot5.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = polarPlot5.getOrientation();
        combinedRangeXYPlot0.setOrientation(plotOrientation8);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean11 = xYLineAndShapeRenderer10.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer10.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke15 = xYLineAndShapeRenderer10.getBaseOutlineStroke();
        java.awt.Stroke stroke17 = xYLineAndShapeRenderer10.lookupSeriesStroke(4);
        combinedRangeXYPlot0.setDomainCrosshairStroke(stroke17);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        numberAxis19.setFixedAutoRange((double) 9);
        combinedRangeXYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis19);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder23 = combinedRangeXYPlot0.getDatasetRenderingOrder();
        combinedRangeXYPlot0.setWeight((int) (byte) 1);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(datasetRenderingOrder23);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) (short) 10, categoryItemLabelGenerator2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator((-4145152), (int) (byte) 1, false);
        int int8 = barRenderer0.getColumnCount();
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean11 = barRenderer10.getShadowsVisible();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = barRenderer10.getBaseURLGenerator();
        barRenderer10.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = null;
        barRenderer10.setBaseToolTipGenerator(categoryToolTipGenerator15, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = barRenderer10.getPositiveItemLabelPosition(8, (int) ' ', true);
        barRenderer0.setSeriesPositiveItemLabelPosition(2958465, itemLabelPosition21, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator24 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator24);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(categoryURLGenerator12);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true);
        xYSeries2.fireSeriesChanged();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries2);
        boolean boolean5 = xYSeriesCollection4.isAutoWidth();
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true);
        xYSeries8.fireSeriesChanged();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection10 = new org.jfree.data.xy.XYSeriesCollection(xYSeries8);
        xYSeriesCollection4.removeSeries(xYSeries8);
        boolean boolean12 = xYSeriesCollection4.isAutoWidth();
        int int13 = xYSeriesCollection4.getSeriesCount();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.plot.PiePlot piePlot2 = new org.jfree.chart.plot.PiePlot(pieDataset1);
        int int3 = piePlot2.getPieIndex();
        double double4 = piePlot2.getMaximumLabelWidth();
        piePlot2.setMaximumLabelWidth((double) (byte) 0);
        boolean boolean7 = xYStepRenderer0.equals((java.lang.Object) piePlot2);
        java.lang.Object obj8 = piePlot2.clone();
        piePlot2.setAutoPopulateSectionOutlinePaint(false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.14d + "'", double4 == 0.14d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        boolean boolean7 = xYLineAndShapeRenderer0.getItemLineVisible((int) (short) 10, (-1));
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator9 = xYLineAndShapeRenderer0.getSeriesURLGenerator(0);
        java.awt.Graphics2D graphics2D10 = null;
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection12 = new org.jfree.data.time.TimeSeriesCollection(timeZone11);
        double double14 = timeSeriesCollection12.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean18 = xYLineAndShapeRenderer17.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer17.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke22 = xYLineAndShapeRenderer17.getBaseOutlineStroke();
        java.awt.Stroke stroke24 = xYLineAndShapeRenderer17.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection12, valueAxis15, valueAxis16, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer17);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = xYPlot25.getInsets();
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYPlot25.setNoDataMessagePaint((java.awt.Paint) color27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot31 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.title.LegendTitle legendTitle32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) waferMapPlot31);
        java.awt.Font font33 = legendTitle32.getItemFont();
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("DateTickUnitType.SECOND", font33);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer35 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Font font37 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer35.setLegendTextFont((int) '#', font37);
        textTitle34.setFont(font37);
        java.awt.Paint paint40 = textTitle34.getBackgroundPaint();
        java.awt.geom.Rectangle2D rectangle2D41 = textTitle34.getBounds();
        try {
            xYLineAndShapeRenderer0.drawDomainGridLine(graphics2D10, xYPlot25, valueAxis29, rectangle2D41, (double) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(xYURLGenerator9);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNull(paint40);
        org.junit.Assert.assertNotNull(rectangle2D41);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        xYStepRenderer0.clearSeriesPaints(false);
        int int3 = xYStepRenderer0.getPassCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2 + "'", int3 == 2);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getShadowsVisible();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator2, false);
        java.awt.Paint paint8 = barRenderer0.getItemFillPaint((-1), 255, false);
        int int9 = barRenderer0.getPassCount();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        polarPlot5.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = polarPlot5.getOrientation();
        combinedRangeXYPlot0.setOrientation(plotOrientation8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = combinedRangeXYPlot0.getAxisOffset();
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer1.setAutoPopulateSeriesStroke(false);
        barRenderer1.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray9);
        org.jfree.data.Range range11 = barRenderer6.findRangeBounds(categoryDataset10);
        org.jfree.data.Range range12 = barRenderer1.findRangeBounds(categoryDataset10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis13.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection18 = new org.jfree.data.time.TimeSeriesCollection(timeZone17);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer20 = null;
        org.jfree.chart.plot.PolarPlot polarPlot21 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection18, valueAxis19, polarItemRenderer20);
        polarPlot21.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = polarPlot21.getOrientation();
        combinedRangeXYPlot16.setOrientation(plotOrientation24);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer26 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean27 = xYLineAndShapeRenderer26.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer26.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke31 = xYLineAndShapeRenderer26.getBaseOutlineStroke();
        java.awt.Stroke stroke33 = xYLineAndShapeRenderer26.lookupSeriesStroke(4);
        combinedRangeXYPlot16.setDomainCrosshairStroke(stroke33);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis();
        numberAxis35.setFixedAutoRange((double) 9);
        combinedRangeXYPlot16.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis35);
        java.awt.Shape shape40 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis35.setLeftArrow(shape40);
        java.text.NumberFormat numberFormat42 = java.text.NumberFormat.getNumberInstance();
        boolean boolean43 = numberFormat42.isParseIntegerOnly();
        numberAxis35.setNumberFormatOverride(numberFormat42);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis35, categoryItemRenderer45);
        categoryPlot46.clearDomainMarkers();
        boolean boolean48 = categoryPlot46.isRangePannable();
        java.awt.Paint paint49 = categoryPlot46.getRangeMinorGridlinePaint();
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart("ERROR : Relative To String", (org.jfree.chart.plot.Plot) categoryPlot46);
        jFreeChart50.fireChartChanged();
        java.awt.Graphics2D graphics2D52 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor53 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo54 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean55 = textBlockAnchor53.equals((java.lang.Object) chartRenderingInfo54);
        java.awt.geom.Rectangle2D rectangle2D56 = chartRenderingInfo54.getChartArea();
        org.jfree.chart.entity.EntityCollection entityCollection57 = chartRenderingInfo54.getEntityCollection();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor58 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo59 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean60 = textBlockAnchor58.equals((java.lang.Object) chartRenderingInfo59);
        java.awt.geom.Rectangle2D rectangle2D61 = chartRenderingInfo59.getChartArea();
        chartRenderingInfo54.setChartArea(rectangle2D61);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor63 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo64 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean65 = textBlockAnchor63.equals((java.lang.Object) chartRenderingInfo64);
        java.awt.geom.Rectangle2D rectangle2D66 = chartRenderingInfo64.getChartArea();
        org.jfree.chart.entity.EntityCollection entityCollection67 = chartRenderingInfo64.getEntityCollection();
        try {
            jFreeChart50.draw(graphics2D52, rectangle2D61, chartRenderingInfo64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(plotOrientation24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(numberFormat42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(textBlockAnchor53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(rectangle2D56);
        org.junit.Assert.assertNotNull(entityCollection57);
        org.junit.Assert.assertNotNull(textBlockAnchor58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(rectangle2D61);
        org.junit.Assert.assertNotNull(textBlockAnchor63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(rectangle2D66);
        org.junit.Assert.assertNotNull(entityCollection67);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape2 = null;
        xYLineAndShapeRenderer0.setBaseLegendShape(shape2);
        xYLineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, false);
        boolean boolean8 = xYLineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        xYLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.lang.Object obj11 = xYLineAndShapeRenderer0.clone();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape2 = null;
        xYLineAndShapeRenderer0.setBaseLegendShape(shape2);
        java.awt.Shape shape5 = xYLineAndShapeRenderer0.getLegendShape(7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(shape5);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelURL();
        categoryAxis0.setUpperMargin(Double.NaN);
        categoryAxis0.setAxisLineVisible(false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection(timeZone7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection8, valueAxis9, polarItemRenderer10);
        polarPlot11.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = polarPlot11.getOrientation();
        combinedRangeXYPlot6.setOrientation(plotOrientation14);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean17 = xYLineAndShapeRenderer16.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer16.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke21 = xYLineAndShapeRenderer16.getBaseOutlineStroke();
        java.awt.Stroke stroke23 = xYLineAndShapeRenderer16.lookupSeriesStroke(4);
        combinedRangeXYPlot6.setDomainCrosshairStroke(stroke23);
        categoryAxis0.setAxisLineStroke(stroke23);
        categoryAxis0.setCategoryMargin(0.025d);
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 1, "Layer.FOREGROUND");
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        logAxis0.setSmallestValue((double) 7);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = logAxis0.getLabelInsets();
        double double5 = rectangleInsets3.calculateBottomOutset((double) 2147483647);
        double double7 = rectangleInsets3.extendWidth((double) 1559372400000L);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.0d + "'", double5 == 3.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.559372400006E12d + "'", double7 == 1.559372400006E12d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("DateTickUnit[DateTickUnitType.YEAR, 100]");
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer2.setAutoPopulateSeriesStroke(false);
        barRenderer2.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray10 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray10);
        org.jfree.data.Range range12 = barRenderer7.findRangeBounds(categoryDataset11);
        org.jfree.data.Range range13 = barRenderer2.findRangeBounds(categoryDataset11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection19 = new org.jfree.data.time.TimeSeriesCollection(timeZone18);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer21 = null;
        org.jfree.chart.plot.PolarPlot polarPlot22 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection19, valueAxis20, polarItemRenderer21);
        polarPlot22.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation25 = polarPlot22.getOrientation();
        combinedRangeXYPlot17.setOrientation(plotOrientation25);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer27 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean28 = xYLineAndShapeRenderer27.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer27.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke32 = xYLineAndShapeRenderer27.getBaseOutlineStroke();
        java.awt.Stroke stroke34 = xYLineAndShapeRenderer27.lookupSeriesStroke(4);
        combinedRangeXYPlot17.setDomainCrosshairStroke(stroke34);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis();
        numberAxis36.setFixedAutoRange((double) 9);
        combinedRangeXYPlot17.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis36);
        java.awt.Shape shape41 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis36.setLeftArrow(shape41);
        java.text.NumberFormat numberFormat43 = java.text.NumberFormat.getNumberInstance();
        boolean boolean44 = numberFormat43.isParseIntegerOnly();
        numberAxis36.setNumberFormatOverride(numberFormat43);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis36, categoryItemRenderer46);
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        categoryPlot47.setRangeAxis((int) (byte) 100, valueAxis49);
        java.lang.Comparable comparable51 = categoryPlot47.getDomainCrosshairRowKey();
        categoryPlot47.setRangeGridlinesVisible(false);
        boolean boolean54 = standardPieSectionLabelGenerator1.equals((java.lang.Object) categoryPlot47);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(plotOrientation25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(numberFormat43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(comparable51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType1 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType1, (int) (short) 100);
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange();
        java.util.Date date5 = dateRange4.getUpperDate();
        java.util.Date date6 = dateTickUnit3.rollDate(date5);
        boolean boolean7 = blockContainer0.equals((java.lang.Object) date6);
        java.util.List list8 = blockContainer0.getBlocks();
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("org.jfree.chart.event.RendererChangeEvent[source=1.0]");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.data.Range range13 = combinedRangeXYPlot11.getDataRange(valueAxis12);
        blockContainer0.add((org.jfree.chart.block.Block) textTitle10, (java.lang.Object) valueAxis12);
        org.junit.Assert.assertNotNull(dateTickUnitType1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNull(range13);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("index.html");
        boolean boolean3 = pieLabelLinkStyle0.equals((java.lang.Object) categoryAxis3D2);
        java.lang.String str5 = categoryAxis3D2.getCategoryLabelToolTip((java.lang.Comparable) ' ');
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) (short) 10, categoryItemLabelGenerator2);
        double[][] doubleArray6 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset7 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray6);
        org.jfree.data.general.PieDataset pieDataset9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset7, (java.lang.Comparable) (byte) -1);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset7, false);
        org.jfree.data.Range range12 = barRenderer0.findRangeBounds(categoryDataset7);
        barRenderer0.setSeriesVisibleInLegend(255, (java.lang.Boolean) false, true);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(categoryDataset7);
        org.junit.Assert.assertNotNull(pieDataset9);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNull(range12);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        boolean boolean4 = textAnchor2.equals((java.lang.Object) (byte) 0);
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        boolean boolean7 = textAnchor5.equals((java.lang.Object) (byte) 0);
        org.jfree.chart.axis.NumberTick numberTick9 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (-4145152), "ERROR : Relative To String", textAnchor2, textAnchor5, (double) (short) 0);
        org.jfree.chart.text.TextAnchor textAnchor10 = numberTick9.getRotationAnchor();
        double double11 = numberTick9.getAngle();
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection13 = new org.jfree.data.time.TimeSeriesCollection(timeZone12);
        double double15 = timeSeriesCollection13.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer18 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean19 = xYLineAndShapeRenderer18.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer18.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke23 = xYLineAndShapeRenderer18.getBaseOutlineStroke();
        java.awt.Stroke stroke25 = xYLineAndShapeRenderer18.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection13, valueAxis16, valueAxis17, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer18);
        org.jfree.chart.block.LineBorder lineBorder28 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint29 = lineBorder28.getPaint();
        xYLineAndShapeRenderer18.setSeriesItemLabelPaint((int) (short) 0, paint29, false);
        boolean boolean32 = numberTick9.equals((java.lang.Object) xYLineAndShapeRenderer18);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator33 = xYLineAndShapeRenderer18.getLegendItemToolTipGenerator();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator33);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        int int2 = piePlot1.getPieIndex();
        double double3 = piePlot1.getMaximumLabelWidth();
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        piePlot1.setLabelBackgroundPaint(paint4);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = piePlot1.getLegendItems();
        java.awt.Paint paint7 = piePlot1.getLabelOutlinePaint();
        java.awt.Stroke stroke8 = piePlot1.getBaseSectionOutlineStroke();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection12 = new org.jfree.data.time.TimeSeriesCollection(timeZone11);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection12, valueAxis13, polarItemRenderer14);
        polarPlot15.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation18 = polarPlot15.getOrientation();
        combinedRangeXYPlot10.setOrientation(plotOrientation18);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer20 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean21 = xYLineAndShapeRenderer20.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer20.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke25 = xYLineAndShapeRenderer20.getBaseOutlineStroke();
        java.awt.Stroke stroke27 = xYLineAndShapeRenderer20.lookupSeriesStroke(4);
        combinedRangeXYPlot10.setDomainCrosshairStroke(stroke27);
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) 8.0d, stroke27);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator31 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("DateTickUnit[DateTickUnitType.YEAR, 100]");
        piePlot1.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator31);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.14d + "'", double3 == 0.14d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(plotOrientation18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean2 = textBlockAnchor0.equals((java.lang.Object) chartRenderingInfo1);
        java.awt.geom.Rectangle2D rectangle2D3 = chartRenderingInfo1.getChartArea();
        org.jfree.chart.entity.EntityCollection entityCollection4 = chartRenderingInfo1.getEntityCollection();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo(entityCollection4);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(entityCollection4);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState0 = new org.jfree.chart.plot.XYCrosshairState();
        java.awt.geom.Point2D point2D1 = xYCrosshairState0.getAnchor();
        xYCrosshairState0.setAnchorX((double) 10);
        double double4 = xYCrosshairState0.getCrosshairY();
        org.junit.Assert.assertNull(point2D1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState0 = new org.jfree.chart.plot.XYCrosshairState();
        java.awt.geom.Point2D point2D1 = xYCrosshairState0.getAnchor();
        xYCrosshairState0.setDatasetIndex((int) ' ');
        org.junit.Assert.assertNull(point2D1);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo1 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean2 = textBlockAnchor0.equals((java.lang.Object) chartRenderingInfo1);
        java.awt.geom.Rectangle2D rectangle2D3 = chartRenderingInfo1.getChartArea();
        org.jfree.chart.entity.EntityCollection entityCollection4 = chartRenderingInfo1.getEntityCollection();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean7 = textBlockAnchor5.equals((java.lang.Object) chartRenderingInfo6);
        java.awt.geom.Rectangle2D rectangle2D8 = chartRenderingInfo6.getChartArea();
        chartRenderingInfo1.setChartArea(rectangle2D8);
        org.jfree.chart.RenderingSource renderingSource10 = chartRenderingInfo1.getRenderingSource();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangle2D3);
        org.junit.Assert.assertNotNull(entityCollection4);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNull(renderingSource10);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 1, (int) (short) -1, (java.lang.Comparable) 3, "hi!", "index.html");
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray13 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray13);
        org.jfree.data.Range range15 = barRenderer10.findRangeBounds(categoryDataset14);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity18 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "hi!", "hi!", categoryDataset14, (java.lang.Comparable) 64, (java.lang.Comparable) (short) 0);
        java.lang.String str19 = categoryItemEntity18.toString();
        org.jfree.data.category.CategoryDataset categoryDataset20 = categoryItemEntity18.getDataset();
        categoryItemEntity18.setURLText("Pie Plot");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(categoryDataset14);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(categoryDataset20);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        double double3 = timeSeriesCollection1.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean7 = xYLineAndShapeRenderer6.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer6.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke11 = xYLineAndShapeRenderer6.getBaseOutlineStroke();
        java.awt.Stroke stroke13 = xYLineAndShapeRenderer6.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, valueAxis5, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer6);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = xYPlot14.getInsets();
        xYPlot14.setNotify(true);
        int int18 = xYPlot14.getWeight();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot19 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot19.setDomainZeroBaselineVisible(false);
        org.jfree.chart.plot.Marker marker23 = null;
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean26 = combinedRangeXYPlot19.removeDomainMarker((int) (short) 0, marker23, layer24, false);
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation28 = axisLocation27.getOpposite();
        combinedRangeXYPlot19.setDomainAxisLocation(axisLocation28, false);
        xYPlot14.setDomainAxisLocation(axisLocation28);
        java.awt.geom.GeneralPath generalPath32 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor33 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo34 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean35 = textBlockAnchor33.equals((java.lang.Object) chartRenderingInfo34);
        java.awt.geom.Rectangle2D rectangle2D36 = chartRenderingInfo34.getChartArea();
        org.jfree.chart.entity.EntityCollection entityCollection37 = chartRenderingInfo34.getEntityCollection();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor38 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo39 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean40 = textBlockAnchor38.equals((java.lang.Object) chartRenderingInfo39);
        java.awt.geom.Rectangle2D rectangle2D41 = chartRenderingInfo39.getChartArea();
        chartRenderingInfo34.setChartArea(rectangle2D41);
        org.jfree.chart.RenderingSource renderingSource43 = null;
        try {
            xYPlot14.select(generalPath32, rectangle2D41, renderingSource43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNotNull(textBlockAnchor33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(entityCollection37);
        org.junit.Assert.assertNotNull(textBlockAnchor38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(rectangle2D41);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean5 = xYLineAndShapeRenderer4.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer4.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke9 = xYLineAndShapeRenderer4.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath12 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean15 = textBlockAnchor13.equals((java.lang.Object) chartRenderingInfo14);
        java.awt.geom.Rectangle2D rectangle2D16 = chartRenderingInfo14.getChartArea();
        org.jfree.chart.RenderingSource renderingSource17 = null;
        combinedRangeXYPlot11.select(generalPath12, rectangle2D16, renderingSource17);
        org.jfree.chart.plot.XYPlot xYPlot19 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset20 = new org.jfree.data.xy.DefaultXYDataset();
        int int22 = defaultXYDataset20.indexOf((java.lang.Comparable) 0.5f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState24 = xYLineAndShapeRenderer4.initialise(graphics2D10, rectangle2D16, xYPlot19, (org.jfree.data.xy.XYDataset) defaultXYDataset20, plotRenderingInfo23);
        combinedRangeXYPlot0.setDataset(64, (org.jfree.data.xy.XYDataset) defaultXYDataset20);
        java.util.TimeZone timeZone26 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection27 = new org.jfree.data.time.TimeSeriesCollection(timeZone26);
        double double29 = timeSeriesCollection27.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer32 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean33 = xYLineAndShapeRenderer32.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer32.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke37 = xYLineAndShapeRenderer32.getBaseOutlineStroke();
        java.awt.Stroke stroke39 = xYLineAndShapeRenderer32.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection27, valueAxis30, valueAxis31, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer32);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = xYPlot40.getInsets();
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYPlot40.setNoDataMessagePaint((java.awt.Paint) color42);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot45 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.AxisLocation axisLocation47 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation48 = axisLocation47.getOpposite();
        combinedRangeXYPlot45.setRangeAxisLocation(0, axisLocation47);
        xYPlot40.setRangeAxisLocation(100, axisLocation47, true);
        combinedRangeXYPlot0.setDomainAxisLocation(axisLocation47);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(textBlockAnchor13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState24);
        org.junit.Assert.assertEquals((double) double29, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(axisLocation47);
        org.junit.Assert.assertNotNull(axisLocation48);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean4 = xYLineAndShapeRenderer3.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer3.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke8 = xYLineAndShapeRenderer3.getBaseOutlineStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYLineAndShapeRenderer3.getBasePositiveItemLabelPosition();
        java.awt.Shape shape10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity17 = new org.jfree.chart.entity.PieSectionEntity(shape10, pieDataset11, 1, (int) (short) -1, (java.lang.Comparable) 3, "hi!", "index.html");
        xYLineAndShapeRenderer3.setBaseShape(shape10, true);
        int int20 = combinedRangeXYPlot0.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer3);
        boolean boolean21 = xYLineAndShapeRenderer3.getUseOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState2 = timeSeriesCollection1.getSelectionState();
        java.util.List list3 = timeSeriesCollection1.getSeries();
        int int5 = timeSeriesCollection1.indexOf((java.lang.Comparable) 1.0f);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate7 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection1, true);
        try {
            java.lang.Number number10 = intervalXYDelegate7.getStartX(2, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(xYDatasetSelectionState2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getShadowsVisible();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator2, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator5, true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer8 = null;
        barRenderer0.setGradientPaintTransformer(gradientPaintTransformer8);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        numberAxis11.setAxisLinePaint((java.awt.Paint) color12);
        try {
            barRenderer0.setSeriesFillPaint((-16777216), (java.awt.Paint) color12, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Font font2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer0.setLegendTextFont((int) '#', font2);
        boolean boolean4 = xYLineAndShapeRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Font font5 = xYLineAndShapeRenderer0.getBaseLegendTextFont();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYLineAndShapeRenderer0.getPositiveItemLabelPosition((int) (short) -1, (int) (byte) -1, false);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor10 = itemLabelPosition9.getItemLabelAnchor();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(itemLabelAnchor10);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState2 = timeSeriesCollection1.getSelectionState();
        java.util.List list3 = timeSeriesCollection1.getSeries();
        int int5 = timeSeriesCollection1.indexOf((java.lang.Comparable) 1.0f);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate7 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection1, true);
        java.lang.Object obj8 = intervalXYDelegate7.clone();
        org.jfree.data.Range range10 = intervalXYDelegate7.getDomainBounds(true);
        double double11 = intervalXYDelegate7.getIntervalPositionFactor();
        org.junit.Assert.assertNotNull(xYDatasetSelectionState2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.5d + "'", double11 == 0.5d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-32640) + "'", int1 == (-32640));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 1.0f);
        java.awt.Paint paint3 = intervalMarker2.getOutlinePaint();
        java.awt.Stroke stroke4 = intervalMarker2.getOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        intervalMarker2.setLabelAnchor(rectangleAnchor5);
        java.lang.String str7 = intervalMarker2.getLabel();
        java.awt.Stroke stroke8 = intervalMarker2.getOutlineStroke();
        java.lang.Class class9 = null;
        try {
            java.util.EventListener[] eventListenerArray10 = intervalMarker2.getListeners(class9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape2 = null;
        xYLineAndShapeRenderer0.setBaseLegendShape(shape2);
        xYLineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, false);
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false);
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.plot.PiePlot piePlot12 = new org.jfree.chart.plot.PiePlot(pieDataset11);
        int int13 = piePlot12.getPieIndex();
        double double14 = piePlot12.getMaximumLabelWidth();
        java.awt.Paint paint15 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        piePlot12.setLabelBackgroundPaint(paint15);
        org.jfree.chart.LegendItemCollection legendItemCollection17 = piePlot12.getLegendItems();
        java.awt.Paint paint18 = piePlot12.getLabelOutlinePaint();
        java.awt.Stroke stroke19 = piePlot12.getBaseSectionOutlineStroke();
        xYLineAndShapeRenderer0.setSeriesStroke(10, stroke19, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.14d + "'", double14 == 0.14d);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(legendItemCollection17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getDrawOutlines();
        boolean boolean5 = xYLineAndShapeRenderer0.isItemLabelVisible(10, (int) (byte) 10, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        polarPlot5.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = polarPlot5.getOrientation();
        combinedRangeXYPlot0.setOrientation(plotOrientation8);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean11 = xYLineAndShapeRenderer10.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer10.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke15 = xYLineAndShapeRenderer10.getBaseOutlineStroke();
        java.awt.Stroke stroke17 = xYLineAndShapeRenderer10.lookupSeriesStroke(4);
        combinedRangeXYPlot0.setDomainCrosshairStroke(stroke17);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        numberAxis19.setFixedAutoRange((double) 9);
        combinedRangeXYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis19);
        boolean boolean23 = combinedRangeXYPlot0.isDomainCrosshairVisible();
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.isVisible();
        numberAxis0.setAutoRangeStickyZero(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) numberAxis0);
        java.lang.String str5 = combinedDomainXYPlot4.getPlotType();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Graphics2D graphics2D8 = null;
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeZone9);
        double double12 = timeSeriesCollection10.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer15 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean16 = xYLineAndShapeRenderer15.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer15.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke20 = xYLineAndShapeRenderer15.getBaseOutlineStroke();
        java.awt.Stroke stroke22 = xYLineAndShapeRenderer15.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection10, valueAxis13, valueAxis14, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = xYPlot23.getRangeAxisEdge(3);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        numberAxis26.setFixedAutoRange((double) 9);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer29 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean30 = xYLineAndShapeRenderer29.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer29.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke34 = xYLineAndShapeRenderer29.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot36 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath37 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor38 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo39 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean40 = textBlockAnchor38.equals((java.lang.Object) chartRenderingInfo39);
        java.awt.geom.Rectangle2D rectangle2D41 = chartRenderingInfo39.getChartArea();
        org.jfree.chart.RenderingSource renderingSource42 = null;
        combinedRangeXYPlot36.select(generalPath37, rectangle2D41, renderingSource42);
        org.jfree.chart.plot.XYPlot xYPlot44 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset45 = new org.jfree.data.xy.DefaultXYDataset();
        int int47 = defaultXYDataset45.indexOf((java.lang.Comparable) 0.5f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState49 = xYLineAndShapeRenderer29.initialise(graphics2D35, rectangle2D41, xYPlot44, (org.jfree.data.xy.XYDataset) defaultXYDataset45, plotRenderingInfo48);
        org.jfree.chart.block.LineBorder lineBorder51 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint52 = lineBorder51.getPaint();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer53 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean54 = xYLineAndShapeRenderer53.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer53.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke58 = xYLineAndShapeRenderer53.getBaseOutlineStroke();
        java.awt.Stroke stroke60 = xYLineAndShapeRenderer53.lookupSeriesStroke(4);
        xYLineAndShapeRenderer7.drawRangeLine(graphics2D8, xYPlot23, (org.jfree.chart.axis.ValueAxis) numberAxis26, rectangle2D41, (double) 7, paint52, stroke60);
        java.awt.geom.Point2D point2D62 = null;
        org.jfree.chart.plot.PlotState plotState63 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor64 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo65 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean66 = textBlockAnchor64.equals((java.lang.Object) chartRenderingInfo65);
        java.awt.geom.Rectangle2D rectangle2D67 = chartRenderingInfo65.getChartArea();
        org.jfree.chart.entity.EntityCollection entityCollection68 = chartRenderingInfo65.getEntityCollection();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor69 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo70 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean71 = textBlockAnchor69.equals((java.lang.Object) chartRenderingInfo70);
        java.awt.geom.Rectangle2D rectangle2D72 = chartRenderingInfo70.getChartArea();
        chartRenderingInfo65.setChartArea(rectangle2D72);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo74 = chartRenderingInfo65.getPlotInfo();
        try {
            combinedDomainXYPlot4.draw(graphics2D6, rectangle2D41, point2D62, plotState63, plotRenderingInfo74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Combined_Domain_XYPlot" + "'", str5.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(textBlockAnchor38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState49);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(textBlockAnchor64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertNotNull(entityCollection68);
        org.junit.Assert.assertNotNull(textBlockAnchor69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(rectangle2D72);
        org.junit.Assert.assertNotNull(plotRenderingInfo74);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke5 = xYLineAndShapeRenderer0.getBaseOutlineStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYLineAndShapeRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        xYLineAndShapeRenderer0.setBaseShape(shape7, true);
        java.awt.Stroke stroke10 = xYLineAndShapeRenderer0.getBaseOutlineStroke();
        xYLineAndShapeRenderer0.clearSeriesStrokes(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        int int1 = barRenderer0.getRowCount();
        double[][] doubleArray4 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray4);
        org.jfree.data.Range range6 = barRenderer0.findRangeBounds(categoryDataset5);
        java.lang.Number number7 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset5);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(categoryDataset5);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNull(number7);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer9 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator10 = xYBarRenderer9.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset11 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range12 = xYBarRenderer9.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset11);
        double double13 = xYBarRenderer9.getShadowXOffset();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator14 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer9.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator14, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer18 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator19 = xYBarRenderer18.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset20 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range21 = xYBarRenderer18.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset20);
        double double22 = xYBarRenderer18.getShadowXOffset();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator23 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer18.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator23, true);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator26 = new org.jfree.chart.urls.StandardXYURLGenerator();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer27 = new org.jfree.chart.renderer.xy.XYAreaRenderer(8, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator23, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator26);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer28 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator14, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator26);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer29 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, xYToolTipGenerator7, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator26);
        java.awt.Stroke stroke33 = xYAreaRenderer29.getItemOutlineStroke((-1), (int) 'a', true);
        java.awt.Paint paint34 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        try {
            org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem(attributedString0, "TextBlockAnchor.BOTTOM_LEFT", "", "PlotOrientation.HORIZONTAL", shape5, stroke33, paint34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(xYItemLabelGenerator10);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator14);
        org.junit.Assert.assertNull(xYItemLabelGenerator19);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 4.0d + "'", double22 == 4.0d);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator23);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape5, (java.awt.Paint) color6);
        java.awt.Font font8 = legendItem7.getLabelFont();
        org.jfree.data.general.Dataset dataset9 = null;
        legendItem7.setDataset(dataset9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_YELLOW;
        legendItem7.setOutlinePaint((java.awt.Paint) color11);
        java.awt.image.ColorModel colorModel13 = null;
        java.awt.Rectangle rectangle14 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor15 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean17 = textBlockAnchor15.equals((java.lang.Object) chartRenderingInfo16);
        java.awt.geom.Rectangle2D rectangle2D18 = chartRenderingInfo16.getChartArea();
        java.awt.geom.AffineTransform affineTransform19 = null;
        java.awt.RenderingHints renderingHints20 = null;
        java.awt.PaintContext paintContext21 = color11.createContext(colorModel13, rectangle14, rectangle2D18, affineTransform19, renderingHints20);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(font8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(textBlockAnchor15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(paintContext21);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor5 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        boolean boolean11 = textAnchor9.equals((java.lang.Object) (byte) 0);
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        boolean boolean14 = textAnchor12.equals((java.lang.Object) (byte) 0);
        org.jfree.chart.axis.NumberTick numberTick16 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (-4145152), "ERROR : Relative To String", textAnchor9, textAnchor12, (double) (short) 0);
        org.jfree.chart.text.TextAnchor textAnchor17 = numberTick16.getRotationAnchor();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor5, textAnchor6, textAnchor17, (double) (byte) 1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor4, textAnchor17);
        try {
            java.awt.geom.Rectangle2D rectangle2D21 = org.jfree.chart.text.TextUtilities.drawAlignedString("June 2019", graphics2D1, (float) ' ', (float) 10, textAnchor17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertNotNull(itemLabelAnchor5);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(textAnchor17);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYLineAndShapeRenderer0.getNegativeItemLabelPosition(1, (int) (short) 10, true);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        xYLineAndShapeRenderer0.setSeriesShape(10, shape11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        categoryAxis13.setLabelPaint((java.awt.Paint) color14);
        org.jfree.chart.entity.AxisEntity axisEntity17 = new org.jfree.chart.entity.AxisEntity(shape11, (org.jfree.chart.axis.Axis) categoryAxis13, "TimePeriodAnchor.START");
        double double18 = categoryAxis13.getFixedDimension();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape5, (java.awt.Paint) color6);
        java.awt.Font font8 = legendItem7.getLabelFont();
        org.jfree.data.general.Dataset dataset9 = null;
        legendItem7.setDataset(dataset9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_YELLOW;
        legendItem7.setOutlinePaint((java.awt.Paint) color11);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath14 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor15 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo16 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean17 = textBlockAnchor15.equals((java.lang.Object) chartRenderingInfo16);
        java.awt.geom.Rectangle2D rectangle2D18 = chartRenderingInfo16.getChartArea();
        org.jfree.chart.RenderingSource renderingSource19 = null;
        combinedRangeXYPlot13.select(generalPath14, rectangle2D18, renderingSource19);
        java.awt.Paint paint21 = combinedRangeXYPlot13.getDomainCrosshairPaint();
        legendItem7.setLabelPaint(paint21);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(font8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(textBlockAnchor15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
        java.util.List list1 = axisCollection0.getAxesAtLeft();
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setSeriesVisibleInLegend(2, (java.lang.Boolean) false);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator5 = xYLineAndShapeRenderer0.getSeriesItemLabelGenerator(2147483647);
        org.junit.Assert.assertNull(xYItemLabelGenerator5);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = xYBarRenderer1.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset3 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range4 = xYBarRenderer1.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset3);
        double double5 = xYBarRenderer1.getShadowXOffset();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator6 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer1.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator6, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator11 = xYBarRenderer10.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset12 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range13 = xYBarRenderer10.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset12);
        double double14 = xYBarRenderer10.getShadowXOffset();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator15 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer10.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator15, true);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator18 = new org.jfree.chart.urls.StandardXYURLGenerator();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer19 = new org.jfree.chart.renderer.xy.XYAreaRenderer(8, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator15, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator18);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer20 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator6, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator18);
        xYStepAreaRenderer20.setShapesFilled(false);
        xYStepAreaRenderer20.removeAnnotations();
        xYStepAreaRenderer20.setShapesFilled(true);
        org.junit.Assert.assertNull(xYItemLabelGenerator2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator6);
        org.junit.Assert.assertNull(xYItemLabelGenerator11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator15);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYLineAndShapeRenderer0.getNegativeItemLabelPosition(1, (int) (short) 10, true);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        xYLineAndShapeRenderer0.setSeriesShape(10, shape11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        categoryAxis13.setLabelPaint((java.awt.Paint) color14);
        org.jfree.chart.entity.AxisEntity axisEntity17 = new org.jfree.chart.entity.AxisEntity(shape11, (org.jfree.chart.axis.Axis) categoryAxis13, "TimePeriodAnchor.START");
        org.jfree.data.general.PieDataset pieDataset18 = null;
        org.jfree.chart.plot.PiePlot piePlot19 = new org.jfree.chart.plot.PiePlot(pieDataset18);
        piePlot19.setStartAngle(1.0d);
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape27, (java.awt.Paint) color28);
        piePlot19.setLabelLinkPaint((java.awt.Paint) color28);
        java.awt.Paint paint31 = piePlot19.getBaseSectionOutlinePaint();
        categoryAxis13.setLabelPaint(paint31);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryAxis13.getTickLabelInsets();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions34 = categoryAxis13.getCategoryLabelPositions();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(categoryLabelPositions34);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = xYBarRenderer1.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset3 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range4 = xYBarRenderer1.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset3);
        double double5 = xYBarRenderer1.getShadowXOffset();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator6 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer1.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator6, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator11 = xYBarRenderer10.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset12 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range13 = xYBarRenderer10.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset12);
        double double14 = xYBarRenderer10.getShadowXOffset();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator15 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer10.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator15, true);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator18 = new org.jfree.chart.urls.StandardXYURLGenerator();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer19 = new org.jfree.chart.renderer.xy.XYAreaRenderer(8, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator15, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator18);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer20 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator6, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator18);
        xYStepAreaRenderer20.setShapesFilled(false);
        xYStepAreaRenderer20.removeAnnotations();
        try {
            xYStepAreaRenderer20.setSeriesVisibleInLegend((int) (short) -1, (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemLabelGenerator2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator6);
        org.junit.Assert.assertNull(xYItemLabelGenerator11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator15);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) waferMapPlot2);
        java.awt.Font font4 = legendTitle3.getItemFont();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("DateTickUnitType.SECOND", font4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Font font8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer6.setLegendTextFont((int) '#', font8);
        textTitle5.setFont(font8);
        java.awt.Paint paint11 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("TimePeriodAnchor.START", font8, paint11);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer13 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean14 = xYLineAndShapeRenderer13.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer13.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = xYLineAndShapeRenderer13.getNegativeItemLabelPosition(1, (int) (short) 10, true);
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        xYLineAndShapeRenderer13.setSeriesShape(10, shape24);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        categoryAxis26.setLabelPaint((java.awt.Paint) color27);
        org.jfree.chart.entity.AxisEntity axisEntity30 = new org.jfree.chart.entity.AxisEntity(shape24, (org.jfree.chart.axis.Axis) categoryAxis26, "TimePeriodAnchor.START");
        boolean boolean31 = textBlock12.equals((java.lang.Object) shape24);
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor35 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        try {
            textBlock12.draw(graphics2D32, (float) 255, (float) 100, textBlockAnchor35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textBlock12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor35);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setStartAngle(1.0d);
        java.awt.Paint paint4 = piePlot1.getLabelLinkPaint();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean10 = textBlockAnchor8.equals((java.lang.Object) chartRenderingInfo9);
        java.awt.geom.Rectangle2D rectangle2D11 = chartRenderingInfo9.getChartArea();
        org.jfree.chart.RenderingSource renderingSource12 = null;
        combinedRangeXYPlot6.select(generalPath7, rectangle2D11, renderingSource12);
        java.awt.geom.Point2D point2D14 = null;
        org.jfree.chart.plot.PlotState plotState15 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor16 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean18 = textBlockAnchor16.equals((java.lang.Object) chartRenderingInfo17);
        java.awt.geom.Rectangle2D rectangle2D19 = chartRenderingInfo17.getChartArea();
        org.jfree.chart.entity.EntityCollection entityCollection20 = chartRenderingInfo17.getEntityCollection();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor21 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean23 = textBlockAnchor21.equals((java.lang.Object) chartRenderingInfo22);
        java.awt.geom.Rectangle2D rectangle2D24 = chartRenderingInfo22.getChartArea();
        chartRenderingInfo17.setChartArea(rectangle2D24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = chartRenderingInfo17.getPlotInfo();
        try {
            piePlot1.draw(graphics2D5, rectangle2D11, point2D14, plotState15, plotRenderingInfo26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(textBlockAnchor16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(entityCollection20);
        org.junit.Assert.assertNotNull(textBlockAnchor21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertNotNull(plotRenderingInfo26);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getBaseShapesVisible();
        java.lang.Boolean boolean3 = xYLineAndShapeRenderer0.getSeriesCreateEntities((int) ' ');
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator5 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("");
        java.lang.Object obj6 = standardXYSeriesLabelGenerator5.clone();
        xYLineAndShapeRenderer0.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator5);
        java.awt.Paint paint11 = xYLineAndShapeRenderer0.getItemFillPaint((int) 'a', (int) (byte) 1, false);
        java.lang.Boolean boolean13 = xYLineAndShapeRenderer0.getSeriesVisibleInLegend((int) '4');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(boolean13);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("org.jfree.chart.event.RendererChangeEvent[source=1.0]");
        boolean boolean2 = textTitle1.isVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset) defaultPieDataset0, (java.lang.Comparable) 10L, (-1.0d), (int) ' ');
        org.jfree.chart.plot.PiePlot piePlot5 = new org.jfree.chart.plot.PiePlot(pieDataset4);
        org.junit.Assert.assertNotNull(pieDataset4);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.addMonths(0, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) (short) 100);
        int int3 = dateTickUnitType0.getCalendarField();
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean3 = xYLineAndShapeRenderer2.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer5.setAutoPopulateSeriesStroke(false);
        barRenderer5.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray13 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray13);
        org.jfree.data.Range range15 = barRenderer10.findRangeBounds(categoryDataset14);
        org.jfree.data.Range range16 = barRenderer5.findRangeBounds(categoryDataset14);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis17.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection22 = new org.jfree.data.time.TimeSeriesCollection(timeZone21);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer24 = null;
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection22, valueAxis23, polarItemRenderer24);
        polarPlot25.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation28 = polarPlot25.getOrientation();
        combinedRangeXYPlot20.setOrientation(plotOrientation28);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer30 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean31 = xYLineAndShapeRenderer30.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer30.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke35 = xYLineAndShapeRenderer30.getBaseOutlineStroke();
        java.awt.Stroke stroke37 = xYLineAndShapeRenderer30.lookupSeriesStroke(4);
        combinedRangeXYPlot20.setDomainCrosshairStroke(stroke37);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis();
        numberAxis39.setFixedAutoRange((double) 9);
        combinedRangeXYPlot20.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis39);
        java.awt.Shape shape44 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis39.setLeftArrow(shape44);
        java.text.NumberFormat numberFormat46 = java.text.NumberFormat.getNumberInstance();
        boolean boolean47 = numberFormat46.isParseIntegerOnly();
        numberAxis39.setNumberFormatOverride(numberFormat46);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis17, (org.jfree.chart.axis.ValueAxis) numberAxis39, categoryItemRenderer49);
        org.jfree.chart.axis.ValueAxis valueAxis52 = null;
        categoryPlot50.setRangeAxis((int) (byte) 100, valueAxis52);
        java.awt.Stroke stroke54 = categoryPlot50.getRangeCrosshairStroke();
        xYLineAndShapeRenderer2.setSeriesOutlineStroke(64, stroke54);
        periodAxis1.setMinorTickMarkStroke(stroke54);
        java.awt.Paint paint57 = periodAxis1.getMinorTickMarkPaint();
        org.jfree.chart.axis.PeriodAxisLabelInfo periodAxisLabelInfo58 = null;
        org.jfree.chart.axis.PeriodAxisLabelInfo[] periodAxisLabelInfoArray59 = new org.jfree.chart.axis.PeriodAxisLabelInfo[] { periodAxisLabelInfo58 };
        periodAxis1.setLabelInfo(periodAxisLabelInfoArray59);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(categoryDataset14);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(plotOrientation28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(numberFormat46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(periodAxisLabelInfoArray59);
    }

//    @Test
//    public void test322() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test322");
//        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
//        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator1 = xYBarRenderer0.getBaseItemLabelGenerator();
//        org.jfree.data.xy.DefaultXYDataset defaultXYDataset2 = new org.jfree.data.xy.DefaultXYDataset();
//        org.jfree.data.Range range3 = xYBarRenderer0.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset2);
//        double double4 = xYBarRenderer0.getShadowXOffset();
//        xYBarRenderer0.setAutoPopulateSeriesStroke(true);
//        java.awt.Shape shape7 = xYBarRenderer0.getLegendBar();
//        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYBarRenderer0.getPositiveItemLabelPositionFallback();
//        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor9 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
//        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
//        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor9, textAnchor10);
//        xYBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition11);
//        boolean boolean13 = xYBarRenderer0.getShadowsVisible();
//        org.junit.Assert.assertNull(xYItemLabelGenerator1);
//        org.junit.Assert.assertNull(range3);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
//        org.junit.Assert.assertNotNull(shape7);
//        org.junit.Assert.assertNull(itemLabelPosition8);
//        org.junit.Assert.assertNotNull(itemLabelAnchor9);
//        org.junit.Assert.assertNotNull(textAnchor10);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean2 = xYLineAndShapeRenderer1.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer1.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYLineAndShapeRenderer1.getNegativeItemLabelPosition(1, (int) (short) 10, true);
        boolean boolean10 = xYLineAndShapeRenderer1.getAutoPopulateSeriesShape();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection12 = new org.jfree.data.time.TimeSeriesCollection(timeZone11);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection12, valueAxis13, polarItemRenderer14);
        java.awt.Paint paint16 = polarPlot15.getAngleLabelPaint();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean18 = xYLineAndShapeRenderer17.getAutoPopulateSeriesOutlinePaint();
        java.awt.Font font19 = xYLineAndShapeRenderer17.getBaseItemLabelFont();
        polarPlot15.setAngleLabelFont(font19);
        xYLineAndShapeRenderer1.setBaseLegendTextFont(font19);
        java.awt.Stroke stroke25 = xYLineAndShapeRenderer1.getItemOutlineStroke(0, (-1), false);
        xYLineAndShapeRenderer1.setAutoPopulateSeriesFillPaint(false);
        boolean boolean28 = axisSpace0.equals((java.lang.Object) xYLineAndShapeRenderer1);
        double double29 = axisSpace0.getBottom();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.isVisible();
        numberAxis0.setAutoRangeStickyZero(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) numberAxis0);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection(timeZone6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection7, valueAxis8, polarItemRenderer9);
        polarPlot10.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = polarPlot10.getOrientation();
        combinedRangeXYPlot5.setOrientation(plotOrientation13);
        combinedRangeXYPlot5.setRangeCrosshairValue(0.0d);
        boolean boolean17 = combinedRangeXYPlot5.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisSpace axisSpace18 = new org.jfree.chart.axis.AxisSpace();
        combinedRangeXYPlot5.setFixedRangeAxisSpace(axisSpace18);
        combinedDomainXYPlot4.setFixedRangeAxisSpace(axisSpace18);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor23 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean25 = textBlockAnchor23.equals((java.lang.Object) chartRenderingInfo24);
        java.awt.geom.Rectangle2D rectangle2D26 = chartRenderingInfo24.getChartArea();
        org.jfree.chart.entity.EntityCollection entityCollection27 = chartRenderingInfo24.getEntityCollection();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor28 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo29 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean30 = textBlockAnchor28.equals((java.lang.Object) chartRenderingInfo29);
        java.awt.geom.Rectangle2D rectangle2D31 = chartRenderingInfo29.getChartArea();
        chartRenderingInfo24.setChartArea(rectangle2D31);
        java.util.TimeZone timeZone33 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection34 = new org.jfree.data.time.TimeSeriesCollection(timeZone33);
        double double36 = timeSeriesCollection34.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer39 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean40 = xYLineAndShapeRenderer39.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer39.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke44 = xYLineAndShapeRenderer39.getBaseOutlineStroke();
        java.awt.Stroke stroke46 = xYLineAndShapeRenderer39.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection34, valueAxis37, valueAxis38, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer39);
        org.jfree.chart.block.LineBorder lineBorder49 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint50 = lineBorder49.getPaint();
        xYLineAndShapeRenderer39.setSeriesItemLabelPaint((int) (short) 0, paint50, false);
        boolean boolean53 = chartRenderingInfo24.equals((java.lang.Object) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = chartRenderingInfo24.getPlotInfo();
        java.awt.geom.Point2D point2D55 = null;
        try {
            combinedDomainXYPlot4.zoomRangeAxes(0.0d, (double) 100.0f, plotRenderingInfo54, point2D55);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(entityCollection27);
        org.junit.Assert.assertNotNull(textBlockAnchor28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertEquals((double) double36, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo54);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        polarPlot5.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = polarPlot5.getOrientation();
        combinedRangeXYPlot0.setOrientation(plotOrientation8);
        combinedRangeXYPlot0.setRangeCrosshairValue(0.0d);
        boolean boolean12 = combinedRangeXYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisSpace axisSpace13 = new org.jfree.chart.axis.AxisSpace();
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace13);
        combinedRangeXYPlot0.mapDatasetToDomainAxis(9999, (int) (byte) -1);
        java.awt.Stroke stroke18 = combinedRangeXYPlot0.getRangeGridlineStroke();
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = null;
        try {
            combinedRangeXYPlot0.setOrientation(plotOrientation19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        java.awt.Paint paint5 = polarPlot4.getAngleLabelPaint();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean7 = xYLineAndShapeRenderer6.getAutoPopulateSeriesOutlinePaint();
        java.awt.Font font8 = xYLineAndShapeRenderer6.getBaseItemLabelFont();
        polarPlot4.setAngleLabelFont(font8);
        java.awt.Font font10 = polarPlot4.getAngleLabelFont();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) (short) 100);
        java.lang.String str3 = dateTickUnit2.toString();
        int int4 = dateTickUnit2.getMultiple();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = new org.jfree.chart.axis.SegmentedTimeline((long) 7, (int) (short) 100, (int) (short) 1);
        segmentedTimeline8.setStartTime((long) 10);
        org.jfree.data.time.DateRange dateRange11 = new org.jfree.data.time.DateRange();
        java.util.Date date12 = dateRange11.getUpperDate();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment13 = segmentedTimeline8.getSegment(date12);
        java.util.TimeZone timeZone14 = null;
        try {
            java.util.Date date15 = dateTickUnit2.rollDate(date12, timeZone14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "DateTickUnit[DateTickUnitType.YEAR, 100]" + "'", str3.equals("DateTickUnit[DateTickUnitType.YEAR, 100]"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(segment13);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        boolean boolean7 = xYLineAndShapeRenderer0.getItemLineVisible((int) (short) 10, (-1));
        java.lang.Boolean boolean9 = xYLineAndShapeRenderer0.getSeriesShapesFilled(10);
        java.awt.Paint paint10 = null;
        try {
            xYLineAndShapeRenderer0.setBaseItemLabelPaint(paint10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(boolean9);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 1, (int) (short) -1, (java.lang.Comparable) 3, "hi!", "index.html");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.setDomainZeroBaselineVisible(false);
        combinedRangeXYPlot8.setDomainGridlinesVisible(false);
        org.jfree.chart.entity.PlotEntity plotEntity15 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) combinedRangeXYPlot8, "EXPAND", "");
        int int16 = combinedRangeXYPlot8.getWeight();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection18 = new org.jfree.data.time.TimeSeriesCollection(timeZone17);
        double double20 = timeSeriesCollection18.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer23 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean24 = xYLineAndShapeRenderer23.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer23.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke28 = xYLineAndShapeRenderer23.getBaseOutlineStroke();
        java.awt.Stroke stroke30 = xYLineAndShapeRenderer23.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection18, valueAxis21, valueAxis22, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer23);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = xYPlot31.getInsets();
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYPlot31.setNoDataMessagePaint((java.awt.Paint) color33);
        org.jfree.chart.axis.LogAxis logAxis35 = new org.jfree.chart.axis.LogAxis();
        boolean boolean36 = logAxis35.isTickMarksVisible();
        java.awt.Paint paint37 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder38 = new org.jfree.chart.block.BlockBorder(paint37);
        java.awt.Paint paint39 = blockBorder38.getPaint();
        logAxis35.setTickMarkPaint(paint39);
        int int41 = xYPlot31.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis35);
        org.jfree.data.Range range42 = combinedRangeXYPlot8.getDataRange((org.jfree.chart.axis.ValueAxis) logAxis35);
        double double43 = logAxis35.getSmallestValue();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0E-100d + "'", double43 == 1.0E-100d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = null;
        polarPlot4.setDrawingSupplier(drawingSupplier5);
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = polarPlot4.getOrientation();
        org.junit.Assert.assertNotNull(plotOrientation7);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        java.util.TimeZone timeZone0 = null;
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource2 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0, locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true);
        xYSeries2.fireSeriesChanged();
        double[][] doubleArray4 = xYSeries2.toArray();
        org.jfree.data.xy.XYDataItem xYDataItem7 = xYSeries2.addOrUpdate(0.0d, (-6.0d));
        try {
            xYSeries2.updateByIndex((int) (byte) 1, (java.lang.Number) Double.NaN);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNull(xYDataItem7);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getShadowsVisible();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator2, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator5, true);
        boolean boolean8 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        org.jfree.chart.util.Layer layer10 = org.jfree.chart.util.Layer.FOREGROUND;
        java.lang.String str11 = layer10.toString();
        try {
            barRenderer0.addAnnotation(categoryAnnotation9, layer10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(layer10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Layer.FOREGROUND" + "'", str11.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        double double3 = timeSeriesCollection1.getDomainLowerBound(false);
        boolean boolean4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor5 = timeSeriesCollection1.getXPosition();
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(timePeriodAnchor5);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection3 = new org.jfree.data.time.TimeSeriesCollection(timeZone2);
        double double5 = timeSeriesCollection3.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean9 = xYLineAndShapeRenderer8.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer8.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke13 = xYLineAndShapeRenderer8.getBaseOutlineStroke();
        java.awt.Stroke stroke15 = xYLineAndShapeRenderer8.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection3, valueAxis6, valueAxis7, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer8);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = xYPlot16.getRangeAxisEdge(3);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        numberAxis19.setFixedAutoRange((double) 9);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer22 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean23 = xYLineAndShapeRenderer22.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer22.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke27 = xYLineAndShapeRenderer22.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot29 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath30 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor31 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean33 = textBlockAnchor31.equals((java.lang.Object) chartRenderingInfo32);
        java.awt.geom.Rectangle2D rectangle2D34 = chartRenderingInfo32.getChartArea();
        org.jfree.chart.RenderingSource renderingSource35 = null;
        combinedRangeXYPlot29.select(generalPath30, rectangle2D34, renderingSource35);
        org.jfree.chart.plot.XYPlot xYPlot37 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset38 = new org.jfree.data.xy.DefaultXYDataset();
        int int40 = defaultXYDataset38.indexOf((java.lang.Comparable) 0.5f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState42 = xYLineAndShapeRenderer22.initialise(graphics2D28, rectangle2D34, xYPlot37, (org.jfree.data.xy.XYDataset) defaultXYDataset38, plotRenderingInfo41);
        org.jfree.chart.block.LineBorder lineBorder44 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint45 = lineBorder44.getPaint();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer46 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean47 = xYLineAndShapeRenderer46.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer46.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke51 = xYLineAndShapeRenderer46.getBaseOutlineStroke();
        java.awt.Stroke stroke53 = xYLineAndShapeRenderer46.lookupSeriesStroke(4);
        xYLineAndShapeRenderer0.drawRangeLine(graphics2D1, xYPlot16, (org.jfree.chart.axis.ValueAxis) numberAxis19, rectangle2D34, (double) 7, paint45, stroke53);
        java.lang.Boolean boolean56 = xYLineAndShapeRenderer0.getSeriesShapesFilled(7);
        org.jfree.data.general.PieDataset pieDataset58 = null;
        org.jfree.chart.plot.PiePlot piePlot59 = new org.jfree.chart.plot.PiePlot(pieDataset58);
        piePlot59.setStartAngle(1.0d);
        java.awt.Shape shape67 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color68 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem69 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape67, (java.awt.Paint) color68);
        piePlot59.setLabelLinkPaint((java.awt.Paint) color68);
        xYLineAndShapeRenderer0.setSeriesOutlinePaint((int) '#', (java.awt.Paint) color68);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(textBlockAnchor31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState42);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNull(boolean56);
        org.junit.Assert.assertNotNull(shape67);
        org.junit.Assert.assertNotNull(color68);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        polarPlot4.setAngleGridlinesVisible(false);
        boolean boolean7 = polarPlot4.isDomainZoomable();
        polarPlot4.setAngleLabelsVisible(false);
        java.awt.Paint paint10 = polarPlot4.getOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem9 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape7, (java.awt.Paint) color8);
        int int10 = color8.getGreen();
        org.jfree.chart.text.TextLine textLine11 = new org.jfree.chart.text.TextLine("hi!", font1, (java.awt.Paint) color8);
        org.jfree.chart.text.TextFragment textFragment12 = textLine11.getLastTextFragment();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor17 = itemLabelPosition16.getTextAnchor();
        try {
            textFragment12.draw(graphics2D13, 10.0f, (float) 8, textAnchor17, (float) 100L, 0.0f, (double) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 64 + "'", int10 == 64);
        org.junit.Assert.assertNotNull(textFragment12);
        org.junit.Assert.assertNotNull(textAnchor17);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        double double3 = timeSeriesCollection1.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean7 = xYLineAndShapeRenderer6.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer6.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke11 = xYLineAndShapeRenderer6.getBaseOutlineStroke();
        java.awt.Stroke stroke13 = xYLineAndShapeRenderer6.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, valueAxis5, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer6);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot14.getRangeAxisEdge(3);
        int int17 = xYPlot14.getDatasetCount();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent18 = null;
        xYPlot14.datasetChanged(datasetChangeEvent18);
        int int20 = xYPlot14.getRangeAxisCount();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.data.Range range24 = combinedRangeXYPlot22.getDataRange(valueAxis23);
        org.jfree.chart.axis.AxisLocation axisLocation26 = combinedRangeXYPlot22.getDomainAxisLocation(0);
        xYPlot14.setDomainAxisLocation(500, axisLocation26, true);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(axisLocation26);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        polarPlot5.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = polarPlot5.getOrientation();
        combinedRangeXYPlot0.setOrientation(plotOrientation8);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean11 = xYLineAndShapeRenderer10.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer10.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke15 = xYLineAndShapeRenderer10.getBaseOutlineStroke();
        java.awt.Stroke stroke17 = xYLineAndShapeRenderer10.lookupSeriesStroke(4);
        combinedRangeXYPlot0.setDomainCrosshairStroke(stroke17);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        numberAxis19.setFixedAutoRange((double) 9);
        combinedRangeXYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis19);
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis19.setLeftArrow(shape24);
        java.lang.String str26 = numberAxis19.getLabelURL();
        numberAxis19.setAutoTickUnitSelection(true, true);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNull(str26);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (-1), range1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getWidthConstraintType();
        org.jfree.data.Range range4 = rectangleConstraint2.getWidthRange();
        org.jfree.data.Range range5 = rectangleConstraint2.getWidthRange();
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment1 = textLine0.getFirstTextFragment();
        org.junit.Assert.assertNull(textFragment1);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        double double1 = barRenderer3D0.getXOffset();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer3.setAutoPopulateSeriesStroke(false);
        barRenderer3.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray11 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray11);
        org.jfree.data.Range range13 = barRenderer8.findRangeBounds(categoryDataset12);
        org.jfree.data.Range range14 = barRenderer3.findRangeBounds(categoryDataset12);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis15.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection20 = new org.jfree.data.time.TimeSeriesCollection(timeZone19);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer22 = null;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection20, valueAxis21, polarItemRenderer22);
        polarPlot23.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation26 = polarPlot23.getOrientation();
        combinedRangeXYPlot18.setOrientation(plotOrientation26);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer28 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean29 = xYLineAndShapeRenderer28.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer28.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke33 = xYLineAndShapeRenderer28.getBaseOutlineStroke();
        java.awt.Stroke stroke35 = xYLineAndShapeRenderer28.lookupSeriesStroke(4);
        combinedRangeXYPlot18.setDomainCrosshairStroke(stroke35);
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        numberAxis37.setFixedAutoRange((double) 9);
        combinedRangeXYPlot18.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis37);
        java.awt.Shape shape42 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis37.setLeftArrow(shape42);
        java.text.NumberFormat numberFormat44 = java.text.NumberFormat.getNumberInstance();
        boolean boolean45 = numberFormat44.isParseIntegerOnly();
        numberAxis37.setNumberFormatOverride(numberFormat44);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis37, categoryItemRenderer47);
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        categoryPlot48.setRangeAxis((int) (byte) 100, valueAxis50);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent52 = null;
        categoryPlot48.markerChanged(markerChangeEvent52);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = categoryPlot48.getRenderer();
        java.awt.Paint paint55 = categoryPlot48.getRangeGridlinePaint();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot56 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath57 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor58 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo59 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean60 = textBlockAnchor58.equals((java.lang.Object) chartRenderingInfo59);
        java.awt.geom.Rectangle2D rectangle2D61 = chartRenderingInfo59.getChartArea();
        org.jfree.chart.RenderingSource renderingSource62 = null;
        combinedRangeXYPlot56.select(generalPath57, rectangle2D61, renderingSource62);
        try {
            barRenderer3D0.drawBackground(graphics2D2, categoryPlot48, rectangle2D61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.0d + "'", double1 == 12.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(categoryDataset12);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(plotOrientation26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(numberFormat44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(categoryItemRenderer54);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(textBlockAnchor58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(rectangle2D61);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 1.0f);
        java.awt.Paint paint3 = intervalMarker2.getOutlinePaint();
        java.awt.Stroke stroke4 = intervalMarker2.getOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        intervalMarker2.setLabelAnchor(rectangleAnchor5);
        java.lang.String str7 = intervalMarker2.getLabel();
        java.awt.Stroke stroke8 = intervalMarker2.getOutlineStroke();
        org.jfree.chart.text.TextAnchor textAnchor9 = null;
        try {
            intervalMarker2.setLabelTextAnchor(textAnchor9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (short) 10, (int) (byte) 100, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer3 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator4 = xYBarRenderer3.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset5 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range6 = xYBarRenderer3.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset5);
        double double7 = xYBarRenderer3.getShadowXOffset();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator8 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer3.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator8, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer12 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator13 = xYBarRenderer12.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset14 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range15 = xYBarRenderer12.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset14);
        double double16 = xYBarRenderer12.getShadowXOffset();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator17 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer12.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator17, true);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator20 = new org.jfree.chart.urls.StandardXYURLGenerator();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer21 = new org.jfree.chart.renderer.xy.XYAreaRenderer(8, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator17, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator20);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer22 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator8, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator20);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer23 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, xYToolTipGenerator1, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator20);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer24 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean25 = xYLineAndShapeRenderer24.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer24.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        xYLineAndShapeRenderer24.setAutoPopulateSeriesPaint(true);
        xYLineAndShapeRenderer24.setSeriesCreateEntities((int) (short) 100, (java.lang.Boolean) false, false);
        java.awt.Shape shape36 = xYLineAndShapeRenderer24.getSeriesShape((int) (byte) 1);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset37 = new org.jfree.data.xy.DefaultXYDataset();
        int int39 = defaultXYDataset37.indexOf((java.lang.Comparable) 0.5f);
        boolean boolean40 = xYLineAndShapeRenderer24.hasListener((java.util.EventListener) defaultXYDataset37);
        java.lang.String str43 = standardXYURLGenerator20.generateURL((org.jfree.data.xy.XYDataset) defaultXYDataset37, 4, (int) 'a');
        org.junit.Assert.assertNull(xYItemLabelGenerator4);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator8);
        org.junit.Assert.assertNull(xYItemLabelGenerator13);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator17);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(shape36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "index.html?series=4&amp;item=97" + "'", str43.equals("index.html?series=4&amp;item=97"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection3 = new org.jfree.data.time.TimeSeriesCollection(timeZone2);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection3, valueAxis4, polarItemRenderer5);
        polarPlot6.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = polarPlot6.getOrientation();
        combinedRangeXYPlot1.setOrientation(plotOrientation9);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean12 = xYLineAndShapeRenderer11.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer11.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke16 = xYLineAndShapeRenderer11.getBaseOutlineStroke();
        java.awt.Stroke stroke18 = xYLineAndShapeRenderer11.lookupSeriesStroke(4);
        combinedRangeXYPlot1.setDomainCrosshairStroke(stroke18);
        java.awt.geom.GeneralPath generalPath20 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer21 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean22 = xYLineAndShapeRenderer21.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer21.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke26 = xYLineAndShapeRenderer21.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot28 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath29 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor30 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean32 = textBlockAnchor30.equals((java.lang.Object) chartRenderingInfo31);
        java.awt.geom.Rectangle2D rectangle2D33 = chartRenderingInfo31.getChartArea();
        org.jfree.chart.RenderingSource renderingSource34 = null;
        combinedRangeXYPlot28.select(generalPath29, rectangle2D33, renderingSource34);
        org.jfree.chart.plot.XYPlot xYPlot36 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset37 = new org.jfree.data.xy.DefaultXYDataset();
        int int39 = defaultXYDataset37.indexOf((java.lang.Comparable) 0.5f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState41 = xYLineAndShapeRenderer21.initialise(graphics2D27, rectangle2D33, xYPlot36, (org.jfree.data.xy.XYDataset) defaultXYDataset37, plotRenderingInfo40);
        org.jfree.chart.RenderingSource renderingSource42 = null;
        combinedRangeXYPlot1.select(generalPath20, rectangle2D33, renderingSource42);
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, (java.awt.Shape) generalPath20, (double) (-32640), (float) ' ', (float) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(textBlockAnchor30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState41);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) (short) 100);
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange();
        java.util.Date date4 = dateRange3.getUpperDate();
        java.util.Date date5 = dateTickUnit2.rollDate(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date5);
        java.util.TimeZone timeZone7 = null;
        try {
            org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(date5, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.removeAnnotations();
        xYBarRenderer0.setShadowVisible(true);
        xYBarRenderer0.clearSeriesPaints(false);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean8 = xYLineAndShapeRenderer7.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape9 = null;
        xYLineAndShapeRenderer7.setBaseLegendShape(shape9);
        xYLineAndShapeRenderer7.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, false);
        java.awt.Stroke stroke16 = xYLineAndShapeRenderer7.getSeriesStroke((int) '4');
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection18 = new org.jfree.data.time.TimeSeriesCollection(timeZone17);
        double double20 = timeSeriesCollection18.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer23 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean24 = xYLineAndShapeRenderer23.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer23.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke28 = xYLineAndShapeRenderer23.getBaseOutlineStroke();
        java.awt.Stroke stroke30 = xYLineAndShapeRenderer23.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection18, valueAxis21, valueAxis22, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer23);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = xYPlot31.getInsets();
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYPlot31.setNoDataMessagePaint((java.awt.Paint) color33);
        xYLineAndShapeRenderer7.setBaseOutlinePaint((java.awt.Paint) color33, true);
        xYBarRenderer0.setSeriesOutlinePaint((int) (short) 1, (java.awt.Paint) color33, false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(stroke16);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(color33);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        int int2 = piePlot1.getPieIndex();
        double double3 = piePlot1.getMaximumLabelWidth();
        piePlot1.setMaximumLabelWidth((double) (byte) 0);
        piePlot1.setInteriorGap(0.0d);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_YELLOW;
        piePlot1.setLabelPaint((java.awt.Paint) color8);
        piePlot1.setMaximumLabelWidth((double) 0L);
        piePlot1.setCircular(false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator14 = piePlot1.getURLGenerator();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.14d + "'", double3 == 0.14d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(pieURLGenerator14);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape2 = null;
        xYLineAndShapeRenderer0.setBaseLegendShape(shape2);
        xYLineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, false);
        boolean boolean8 = xYLineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        xYLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        boolean boolean12 = xYLineAndShapeRenderer0.isSeriesVisibleInLegend(8);
        try {
            xYLineAndShapeRenderer0.setSeriesShapesVisible((-32640), false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setStartAngle(1.0d);
        org.jfree.chart.plot.IntervalMarker intervalMarker6 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 1.0f);
        java.awt.Paint paint7 = intervalMarker6.getOutlinePaint();
        java.awt.Stroke stroke8 = intervalMarker6.getOutlineStroke();
        piePlot1.setLabelOutlineStroke(stroke8);
        piePlot1.setLabelLinksVisible(false);
        java.awt.Paint paint12 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        piePlot1.setNoDataMessagePaint(paint12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = piePlot1.getSimpleLabelOffset();
        double double16 = rectangleInsets14.extendWidth((double) 10L);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 15.625d + "'", double16 == 15.625d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape5, (java.awt.Paint) color6);
        org.jfree.chart.plot.WaferMapPlot waferMapPlot8 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) waferMapPlot8);
        java.lang.Object obj10 = legendTitle9.clone();
        double double11 = legendTitle9.getHeight();
        boolean boolean12 = legendTitle9.visible;
        org.jfree.chart.entity.TitleEntity titleEntity15 = new org.jfree.chart.entity.TitleEntity(shape5, (org.jfree.chart.title.Title) legendTitle9, "rect", "DateTickUnitType.SECOND");
        org.jfree.chart.title.Title title16 = titleEntity15.getTitle();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(title16);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true);
        xYSeries2.fireSeriesChanged();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries2);
        xYSeries2.setMaximumItemCount((int) ' ');
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer7.setAutoPopulateSeriesStroke(false);
        barRenderer7.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray15 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.data.Range range17 = barRenderer12.findRangeBounds(categoryDataset16);
        org.jfree.data.Range range18 = barRenderer7.findRangeBounds(categoryDataset16);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis19.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection(timeZone23);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer26 = null;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection24, valueAxis25, polarItemRenderer26);
        polarPlot27.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = polarPlot27.getOrientation();
        combinedRangeXYPlot22.setOrientation(plotOrientation30);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer32 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean33 = xYLineAndShapeRenderer32.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer32.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke37 = xYLineAndShapeRenderer32.getBaseOutlineStroke();
        java.awt.Stroke stroke39 = xYLineAndShapeRenderer32.lookupSeriesStroke(4);
        combinedRangeXYPlot22.setDomainCrosshairStroke(stroke39);
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis();
        numberAxis41.setFixedAutoRange((double) 9);
        combinedRangeXYPlot22.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis41);
        java.awt.Shape shape46 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis41.setLeftArrow(shape46);
        java.text.NumberFormat numberFormat48 = java.text.NumberFormat.getNumberInstance();
        boolean boolean49 = numberFormat48.isParseIntegerOnly();
        numberAxis41.setNumberFormatOverride(numberFormat48);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis41, categoryItemRenderer51);
        categoryPlot52.clearDomainMarkers();
        boolean boolean54 = xYSeries2.equals((java.lang.Object) categoryPlot52);
        java.awt.Graphics2D graphics2D55 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot57 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.title.LegendTitle legendTitle58 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) waferMapPlot57);
        java.awt.Font font59 = legendTitle58.getItemFont();
        org.jfree.chart.title.TextTitle textTitle60 = new org.jfree.chart.title.TextTitle("DateTickUnitType.SECOND", font59);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer61 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Font font63 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer61.setLegendTextFont((int) '#', font63);
        textTitle60.setFont(font63);
        java.awt.Paint paint66 = textTitle60.getBackgroundPaint();
        java.awt.geom.Rectangle2D rectangle2D67 = textTitle60.getBounds();
        try {
            categoryPlot52.drawBackground(graphics2D55, rectangle2D67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertNotNull(numberFormat48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(font59);
        org.junit.Assert.assertNotNull(font63);
        org.junit.Assert.assertNull(paint66);
        org.junit.Assert.assertNotNull(rectangle2D67);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.isVisible();
        numberAxis0.setAutoRangeStickyZero(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) numberAxis0);
        java.lang.String str5 = combinedDomainXYPlot4.getPlotType();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean8 = textBlockAnchor6.equals((java.lang.Object) chartRenderingInfo7);
        java.awt.geom.Rectangle2D rectangle2D9 = chartRenderingInfo7.getChartArea();
        org.jfree.chart.entity.EntityCollection entityCollection10 = chartRenderingInfo7.getEntityCollection();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor11 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean13 = textBlockAnchor11.equals((java.lang.Object) chartRenderingInfo12);
        java.awt.geom.Rectangle2D rectangle2D14 = chartRenderingInfo12.getChartArea();
        chartRenderingInfo7.setChartArea(rectangle2D14);
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        double double19 = timeSeriesCollection17.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer22 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean23 = xYLineAndShapeRenderer22.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer22.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke27 = xYLineAndShapeRenderer22.getBaseOutlineStroke();
        java.awt.Stroke stroke29 = xYLineAndShapeRenderer22.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection17, valueAxis20, valueAxis21, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer22);
        org.jfree.chart.block.LineBorder lineBorder32 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint33 = lineBorder32.getPaint();
        xYLineAndShapeRenderer22.setSeriesItemLabelPaint((int) (short) 0, paint33, false);
        boolean boolean36 = chartRenderingInfo7.equals((java.lang.Object) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = chartRenderingInfo7.getPlotInfo();
        java.awt.geom.Point2D point2D38 = null;
        try {
            org.jfree.chart.plot.XYPlot xYPlot39 = combinedDomainXYPlot4.findSubplot(plotRenderingInfo37, point2D38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Combined_Domain_XYPlot" + "'", str5.equals("Combined_Domain_XYPlot"));
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(entityCollection10);
        org.junit.Assert.assertNotNull(textBlockAnchor11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertEquals((double) double19, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo37);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray2);
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset3, (java.lang.Comparable) (byte) -1);
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset3, 7);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertNotNull(pieDataset7);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        int int2 = piePlot1.getPieIndex();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent3 = null;
        piePlot1.notifyListeners(plotChangeEvent3);
        java.awt.Shape shape5 = piePlot1.getLegendItemShape();
        java.awt.Paint paint6 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder(paint6);
        java.awt.Paint paint8 = blockBorder7.getPaint();
        org.jfree.chart.title.LegendGraphic legendGraphic9 = new org.jfree.chart.title.LegendGraphic(shape5, paint8);
        java.awt.Paint paint10 = legendGraphic9.getFillPaint();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesStroke(false);
        barRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray8 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray8);
        org.jfree.data.Range range10 = barRenderer5.findRangeBounds(categoryDataset9);
        org.jfree.data.Range range11 = barRenderer0.findRangeBounds(categoryDataset9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection17, valueAxis18, polarItemRenderer19);
        polarPlot20.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = polarPlot20.getOrientation();
        combinedRangeXYPlot15.setOrientation(plotOrientation23);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer25 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean26 = xYLineAndShapeRenderer25.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer25.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke30 = xYLineAndShapeRenderer25.getBaseOutlineStroke();
        java.awt.Stroke stroke32 = xYLineAndShapeRenderer25.lookupSeriesStroke(4);
        combinedRangeXYPlot15.setDomainCrosshairStroke(stroke32);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        numberAxis34.setFixedAutoRange((double) 9);
        combinedRangeXYPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis34);
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis34.setLeftArrow(shape39);
        java.text.NumberFormat numberFormat41 = java.text.NumberFormat.getNumberInstance();
        boolean boolean42 = numberFormat41.isParseIntegerOnly();
        numberAxis34.setNumberFormatOverride(numberFormat41);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis34, categoryItemRenderer44);
        categoryPlot45.clearDomainMarkers();
        boolean boolean47 = categoryPlot45.isRangePannable();
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = categoryPlot45.getRangeAxisEdge();
        categoryPlot45.mapDatasetToRangeAxis((int) (byte) 10, (int) 'a');
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(numberFormat41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(rectangleEdge48);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        double[][] doubleArray2 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray2);
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset3, (java.lang.Comparable) 100);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset3);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(categoryDataset3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true);
        xYSeries2.fireSeriesChanged();
        double[][] doubleArray4 = xYSeries2.toArray();
        java.beans.PropertyChangeListener propertyChangeListener5 = null;
        xYSeries2.removePropertyChangeListener(propertyChangeListener5);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        int int0 = java.text.NumberFormat.FRACTION_FIELD;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape5, (java.awt.Paint) color6);
        java.awt.Font font8 = legendItem7.getLabelFont();
        org.jfree.data.general.Dataset dataset9 = null;
        legendItem7.setDataset(dataset9);
        legendItem7.setDescription("DateTickUnitType.SECOND");
        legendItem7.setShapeVisible(false);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(font8);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesStroke(false);
        barRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray8 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray8);
        org.jfree.data.Range range10 = barRenderer5.findRangeBounds(categoryDataset9);
        org.jfree.data.Range range11 = barRenderer0.findRangeBounds(categoryDataset9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection17, valueAxis18, polarItemRenderer19);
        polarPlot20.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = polarPlot20.getOrientation();
        combinedRangeXYPlot15.setOrientation(plotOrientation23);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer25 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean26 = xYLineAndShapeRenderer25.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer25.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke30 = xYLineAndShapeRenderer25.getBaseOutlineStroke();
        java.awt.Stroke stroke32 = xYLineAndShapeRenderer25.lookupSeriesStroke(4);
        combinedRangeXYPlot15.setDomainCrosshairStroke(stroke32);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        numberAxis34.setFixedAutoRange((double) 9);
        combinedRangeXYPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis34);
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis34.setLeftArrow(shape39);
        java.text.NumberFormat numberFormat41 = java.text.NumberFormat.getNumberInstance();
        boolean boolean42 = numberFormat41.isParseIntegerOnly();
        numberAxis34.setNumberFormatOverride(numberFormat41);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis34, categoryItemRenderer44);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D46.setLabel("org.jfree.chart.event.RendererChangeEvent[source=1.0]");
        org.jfree.data.Range range49 = categoryPlot45.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D46);
        categoryPlot45.setDrawSharedDomainAxis(false);
        categoryPlot45.setRangeZeroBaselineVisible(false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(numberFormat41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(range49);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint3 = xYLineAndShapeRenderer0.lookupLegendTextPaint((int) (short) 100);
        xYLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.data.Range range8 = combinedRangeXYPlot6.getDataRange(valueAxis7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = combinedRangeXYPlot6.getDomainAxisLocation(0);
        combinedRangeXYPlot6.mapDatasetToDomainAxis(10, 0);
        boolean boolean14 = xYLineAndShapeRenderer0.hasListener((java.util.EventListener) combinedRangeXYPlot6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer1.setAutoPopulateSeriesStroke(false);
        barRenderer1.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray9);
        org.jfree.data.Range range11 = barRenderer6.findRangeBounds(categoryDataset10);
        org.jfree.data.Range range12 = barRenderer1.findRangeBounds(categoryDataset10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis13.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection18 = new org.jfree.data.time.TimeSeriesCollection(timeZone17);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer20 = null;
        org.jfree.chart.plot.PolarPlot polarPlot21 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection18, valueAxis19, polarItemRenderer20);
        polarPlot21.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = polarPlot21.getOrientation();
        combinedRangeXYPlot16.setOrientation(plotOrientation24);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer26 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean27 = xYLineAndShapeRenderer26.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer26.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke31 = xYLineAndShapeRenderer26.getBaseOutlineStroke();
        java.awt.Stroke stroke33 = xYLineAndShapeRenderer26.lookupSeriesStroke(4);
        combinedRangeXYPlot16.setDomainCrosshairStroke(stroke33);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis();
        numberAxis35.setFixedAutoRange((double) 9);
        combinedRangeXYPlot16.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis35);
        java.awt.Shape shape40 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis35.setLeftArrow(shape40);
        java.text.NumberFormat numberFormat42 = java.text.NumberFormat.getNumberInstance();
        boolean boolean43 = numberFormat42.isParseIntegerOnly();
        numberAxis35.setNumberFormatOverride(numberFormat42);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis35, categoryItemRenderer45);
        categoryPlot46.clearDomainMarkers();
        boolean boolean48 = categoryPlot46.isRangePannable();
        java.awt.Paint paint49 = categoryPlot46.getRangeMinorGridlinePaint();
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart("ERROR : Relative To String", (org.jfree.chart.plot.Plot) categoryPlot46);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot52 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot52.setDomainZeroBaselineVisible(false);
        org.jfree.chart.plot.Marker marker56 = null;
        org.jfree.chart.util.Layer layer57 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean59 = combinedRangeXYPlot52.removeDomainMarker((int) (short) 0, marker56, layer57, false);
        java.util.Collection collection60 = categoryPlot46.getDomainMarkers(2, layer57);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(plotOrientation24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(numberFormat42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(layer57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNull(collection60);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("EXPAND");
        dateAxis1.setFixedAutoRange((double) 8);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) waferMapPlot2);
        java.lang.Object obj4 = legendTitle3.clone();
        org.jfree.chart.entity.TitleEntity titleEntity7 = new org.jfree.chart.entity.TitleEntity(shape1, (org.jfree.chart.title.Title) legendTitle3, "hi!", "");
        org.jfree.chart.block.BlockContainer blockContainer8 = null;
        legendTitle3.setWrapper(blockContainer8);
        java.awt.Paint paint10 = legendTitle3.getBackgroundPaint();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(paint10);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYLineAndShapeRenderer0.getNegativeItemLabelPosition(1, (int) (short) 10, true);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        xYLineAndShapeRenderer0.setSeriesShape(10, shape11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        categoryAxis13.setLabelPaint((java.awt.Paint) color14);
        org.jfree.chart.entity.AxisEntity axisEntity17 = new org.jfree.chart.entity.AxisEntity(shape11, (org.jfree.chart.axis.Axis) categoryAxis13, "TimePeriodAnchor.START");
        org.jfree.chart.axis.Axis axis18 = axisEntity17.getAxis();
        java.lang.Object obj19 = axisEntity17.clone();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(axis18);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("index.html");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean7 = textBlockAnchor5.equals((java.lang.Object) chartRenderingInfo6);
        java.awt.geom.Rectangle2D rectangle2D8 = chartRenderingInfo6.getChartArea();
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeZone9);
        double double12 = timeSeriesCollection10.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer15 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean16 = xYLineAndShapeRenderer15.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer15.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke20 = xYLineAndShapeRenderer15.getBaseOutlineStroke();
        java.awt.Stroke stroke22 = xYLineAndShapeRenderer15.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection10, valueAxis13, valueAxis14, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer15);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = xYPlot23.getRangeAxisEdge(3);
        int int26 = xYPlot23.getDatasetCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = xYPlot23.getRangeAxisEdge(0);
        try {
            double double29 = categoryAxis3D1.getCategoryJava2DCoordinate(categoryAnchor2, 100, (int) (byte) 1, rectangle2D8, rectangleEdge28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertEquals((double) double12, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Paint paint6 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYLineAndShapeRenderer0.setLegendTextPaint(1, paint6);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean9 = xYLineAndShapeRenderer8.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer8.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = xYLineAndShapeRenderer8.getNegativeItemLabelPosition(1, (int) (short) 10, true);
        java.awt.Shape shape19 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        xYLineAndShapeRenderer8.setSeriesShape(10, shape19);
        java.awt.Paint paint24 = xYLineAndShapeRenderer8.getItemOutlinePaint(2, (int) 'a', false);
        xYLineAndShapeRenderer8.setSeriesItemLabelsVisible(7, true);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator29 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYLineAndShapeRenderer8.setSeriesToolTipGenerator(2958465, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator29, true);
        xYLineAndShapeRenderer0.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator29);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator34 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer36 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator37 = xYBarRenderer36.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset38 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range39 = xYBarRenderer36.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset38);
        double double40 = xYBarRenderer36.getShadowXOffset();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator41 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer36.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator41, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer45 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator46 = xYBarRenderer45.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset47 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range48 = xYBarRenderer45.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset47);
        double double49 = xYBarRenderer45.getShadowXOffset();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator50 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer45.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator50, true);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator53 = new org.jfree.chart.urls.StandardXYURLGenerator();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer54 = new org.jfree.chart.renderer.xy.XYAreaRenderer(8, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator50, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator53);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer55 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator41, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator53);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer56 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, xYToolTipGenerator34, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator53);
        xYLineAndShapeRenderer0.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator53, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator29);
        org.junit.Assert.assertNull(xYItemLabelGenerator37);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 4.0d + "'", double40 == 4.0d);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator41);
        org.junit.Assert.assertNull(xYItemLabelGenerator46);
        org.junit.Assert.assertNull(range48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 4.0d + "'", double49 == 4.0d);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator50);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.setDomainZeroBaselineVisible(false);
        combinedRangeXYPlot0.setDomainGridlinesVisible(false);
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset();
        int int6 = combinedRangeXYPlot0.getSeriesCount();
        double double7 = combinedRangeXYPlot0.getDomainCrosshairValue();
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        boolean boolean4 = textAnchor2.equals((java.lang.Object) (byte) 0);
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        boolean boolean7 = textAnchor5.equals((java.lang.Object) (byte) 0);
        org.jfree.chart.axis.NumberTick numberTick9 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (-4145152), "ERROR : Relative To String", textAnchor2, textAnchor5, (double) (short) 0);
        org.jfree.chart.text.TextAnchor textAnchor10 = numberTick9.getRotationAnchor();
        double double11 = numberTick9.getAngle();
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection13 = new org.jfree.data.time.TimeSeriesCollection(timeZone12);
        double double15 = timeSeriesCollection13.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer18 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean19 = xYLineAndShapeRenderer18.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer18.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke23 = xYLineAndShapeRenderer18.getBaseOutlineStroke();
        java.awt.Stroke stroke25 = xYLineAndShapeRenderer18.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection13, valueAxis16, valueAxis17, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer18);
        org.jfree.chart.block.LineBorder lineBorder28 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint29 = lineBorder28.getPaint();
        xYLineAndShapeRenderer18.setSeriesItemLabelPaint((int) (short) 0, paint29, false);
        boolean boolean32 = numberTick9.equals((java.lang.Object) xYLineAndShapeRenderer18);
        xYLineAndShapeRenderer18.setBaseSeriesVisible(true, false);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true);
        xYSeries2.fireSeriesChanged();
        double[][] doubleArray4 = xYSeries2.toArray();
        org.jfree.data.xy.XYDataItem xYDataItem7 = xYSeries2.addOrUpdate(0.0d, (-6.0d));
        xYSeries2.add((java.lang.Number) 0.8f, (java.lang.Number) 0.05d);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNull(xYDataItem7);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        double double3 = timeSeriesCollection1.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean7 = xYLineAndShapeRenderer6.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer6.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke11 = xYLineAndShapeRenderer6.getBaseOutlineStroke();
        java.awt.Stroke stroke13 = xYLineAndShapeRenderer6.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, valueAxis5, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer6);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = xYPlot14.getInsets();
        double double17 = rectangleInsets15.calculateBottomOutset((double) (short) 0);
        double double19 = rectangleInsets15.calculateRightOutset((double) 0.8f);
        double double21 = rectangleInsets15.calculateLeftOutset((double) 4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer22 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean23 = xYLineAndShapeRenderer22.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer22.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke27 = xYLineAndShapeRenderer22.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot29 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath30 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor31 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean33 = textBlockAnchor31.equals((java.lang.Object) chartRenderingInfo32);
        java.awt.geom.Rectangle2D rectangle2D34 = chartRenderingInfo32.getChartArea();
        org.jfree.chart.RenderingSource renderingSource35 = null;
        combinedRangeXYPlot29.select(generalPath30, rectangle2D34, renderingSource35);
        org.jfree.chart.plot.XYPlot xYPlot37 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset38 = new org.jfree.data.xy.DefaultXYDataset();
        int int40 = defaultXYDataset38.indexOf((java.lang.Comparable) 0.5f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState42 = xYLineAndShapeRenderer22.initialise(graphics2D28, rectangle2D34, xYPlot37, (org.jfree.data.xy.XYDataset) defaultXYDataset38, plotRenderingInfo41);
        org.jfree.chart.plot.IntervalMarker intervalMarker45 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 1.0f);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType46 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.lang.String str47 = lengthAdjustmentType46.toString();
        intervalMarker45.setLabelOffsetType(lengthAdjustmentType46);
        org.jfree.chart.plot.IntervalMarker intervalMarker51 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 1.0f);
        java.awt.Paint paint52 = intervalMarker51.getOutlinePaint();
        java.awt.Stroke stroke53 = intervalMarker51.getOutlineStroke();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType54 = intervalMarker51.getLabelOffsetType();
        java.awt.geom.Rectangle2D rectangle2D55 = rectangleInsets15.createAdjustedRectangle(rectangle2D34, lengthAdjustmentType46, lengthAdjustmentType54);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.0d + "'", double17 == 4.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 8.0d + "'", double19 == 8.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 8.0d + "'", double21 == 8.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(textBlockAnchor31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState42);
        org.junit.Assert.assertNotNull(lengthAdjustmentType46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "EXPAND" + "'", str47.equals("EXPAND"));
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(lengthAdjustmentType54);
        org.junit.Assert.assertNotNull(rectangle2D55);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 7, (int) (short) 100, (int) (short) 1);
        segmentedTimeline3.setStartTime((long) 10);
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange();
        java.util.Date date7 = dateRange6.getUpperDate();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment8 = segmentedTimeline3.getSegment(date7);
        segmentedTimeline3.addException(7L);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(segment8);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke5 = xYLineAndShapeRenderer0.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath8 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean11 = textBlockAnchor9.equals((java.lang.Object) chartRenderingInfo10);
        java.awt.geom.Rectangle2D rectangle2D12 = chartRenderingInfo10.getChartArea();
        org.jfree.chart.RenderingSource renderingSource13 = null;
        combinedRangeXYPlot7.select(generalPath8, rectangle2D12, renderingSource13);
        org.jfree.chart.plot.XYPlot xYPlot15 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset16 = new org.jfree.data.xy.DefaultXYDataset();
        int int18 = defaultXYDataset16.indexOf((java.lang.Comparable) 0.5f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState20 = xYLineAndShapeRenderer0.initialise(graphics2D6, rectangle2D12, xYPlot15, (org.jfree.data.xy.XYDataset) defaultXYDataset16, plotRenderingInfo19);
        int int21 = xYItemRendererState20.getLastItemIndex();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        java.lang.String[] strArray1 = new java.lang.String[] {};
        org.jfree.chart.axis.SymbolAxis symbolAxis2 = new org.jfree.chart.axis.SymbolAxis("AxisLocation.BOTTOM_OR_LEFT", strArray1);
        org.jfree.data.RangeType rangeType3 = symbolAxis2.getRangeType();
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(rangeType3);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        double double3 = timeSeriesCollection1.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean7 = xYLineAndShapeRenderer6.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer6.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke11 = xYLineAndShapeRenderer6.getBaseOutlineStroke();
        java.awt.Stroke stroke13 = xYLineAndShapeRenderer6.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, valueAxis5, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer6);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = xYPlot14.getInsets();
        xYPlot14.setNotify(true);
        int int18 = xYPlot14.getWeight();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot19 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot19.setDomainZeroBaselineVisible(false);
        org.jfree.chart.plot.Marker marker23 = null;
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean26 = combinedRangeXYPlot19.removeDomainMarker((int) (short) 0, marker23, layer24, false);
        org.jfree.chart.axis.AxisLocation axisLocation27 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation28 = axisLocation27.getOpposite();
        combinedRangeXYPlot19.setDomainAxisLocation(axisLocation28, false);
        xYPlot14.setDomainAxisLocation(axisLocation28);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis33 = xYPlot14.getRangeAxisForDataset((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 100 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(axisLocation28);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MILLISECOND;
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        polarPlot5.setAngleGridlinesVisible(false);
        polarPlot5.setAngleGridlinesVisible(false);
        boolean boolean10 = dateTickUnitType0.equals((java.lang.Object) false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 6);
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 1, (int) (short) -1, (java.lang.Comparable) 3, "hi!", "index.html");
        pieSectionEntity7.setToolTipText("index.html");
        org.jfree.data.general.PieDataset pieDataset10 = pieSectionEntity7.getDataset();
        java.lang.Object obj11 = pieSectionEntity7.clone();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint3 = xYLineAndShapeRenderer0.lookupLegendTextPaint((int) (short) 100);
        xYLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator7 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("");
        xYLineAndShapeRenderer0.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator7);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.setDomainZeroBaselineVisible(false);
        combinedRangeXYPlot0.setDomainGridlinesVisible(false);
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset();
        java.awt.geom.GeneralPath generalPath6 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean8 = xYLineAndShapeRenderer7.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer7.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke12 = xYLineAndShapeRenderer7.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath15 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor16 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean18 = textBlockAnchor16.equals((java.lang.Object) chartRenderingInfo17);
        java.awt.geom.Rectangle2D rectangle2D19 = chartRenderingInfo17.getChartArea();
        org.jfree.chart.RenderingSource renderingSource20 = null;
        combinedRangeXYPlot14.select(generalPath15, rectangle2D19, renderingSource20);
        org.jfree.chart.plot.XYPlot xYPlot22 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset23 = new org.jfree.data.xy.DefaultXYDataset();
        int int25 = defaultXYDataset23.indexOf((java.lang.Comparable) 0.5f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState27 = xYLineAndShapeRenderer7.initialise(graphics2D13, rectangle2D19, xYPlot22, (org.jfree.data.xy.XYDataset) defaultXYDataset23, plotRenderingInfo26);
        org.jfree.chart.RenderingSource renderingSource28 = null;
        combinedRangeXYPlot0.select(generalPath6, rectangle2D19, renderingSource28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = combinedRangeXYPlot0.getDomainAxisEdge((int) (byte) 100);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(textBlockAnchor16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState27);
        org.junit.Assert.assertNotNull(rectangleEdge31);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        java.lang.String str2 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        long long4 = month0.getFirstMillisecond();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        polarPlot4.setAngleGridlinesVisible(false);
        boolean boolean7 = polarPlot4.isDomainZoomable();
        polarPlot4.setAngleLabelsVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis10 = polarPlot4.getAxis();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(valueAxis10);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true);
        xYSeries2.fireSeriesChanged();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries2);
        xYSeries2.setMaximumItemCount((int) ' ');
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer7.setAutoPopulateSeriesStroke(false);
        barRenderer7.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray15 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset16 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray15);
        org.jfree.data.Range range17 = barRenderer12.findRangeBounds(categoryDataset16);
        org.jfree.data.Range range18 = barRenderer7.findRangeBounds(categoryDataset16);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis19.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone23 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection(timeZone23);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer26 = null;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection24, valueAxis25, polarItemRenderer26);
        polarPlot27.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = polarPlot27.getOrientation();
        combinedRangeXYPlot22.setOrientation(plotOrientation30);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer32 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean33 = xYLineAndShapeRenderer32.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer32.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke37 = xYLineAndShapeRenderer32.getBaseOutlineStroke();
        java.awt.Stroke stroke39 = xYLineAndShapeRenderer32.lookupSeriesStroke(4);
        combinedRangeXYPlot22.setDomainCrosshairStroke(stroke39);
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis();
        numberAxis41.setFixedAutoRange((double) 9);
        combinedRangeXYPlot22.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis41);
        java.awt.Shape shape46 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis41.setLeftArrow(shape46);
        java.text.NumberFormat numberFormat48 = java.text.NumberFormat.getNumberInstance();
        boolean boolean49 = numberFormat48.isParseIntegerOnly();
        numberAxis41.setNumberFormatOverride(numberFormat48);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis41, categoryItemRenderer51);
        categoryPlot52.clearDomainMarkers();
        boolean boolean54 = xYSeries2.equals((java.lang.Object) categoryPlot52);
        try {
            java.lang.Number number56 = xYSeries2.getY((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(categoryDataset16);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertNotNull(numberFormat48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(2, (int) (short) -1, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        java.lang.Comparable comparable6 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) timeSeriesCollection2, comparable6);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.setDomainZeroBaselineVisible(false);
        combinedRangeXYPlot8.setDomainGridlinesVisible(false);
        java.util.List list13 = combinedRangeXYPlot8.getSubplots();
        org.jfree.data.Range range15 = timeSeriesCollection2.getDomainBounds(list13, false);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate16 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        double double18 = intervalXYDelegate16.getDomainUpperBound(false);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesStroke(false);
        barRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray8 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray8);
        org.jfree.data.Range range10 = barRenderer5.findRangeBounds(categoryDataset9);
        org.jfree.data.Range range11 = barRenderer0.findRangeBounds(categoryDataset9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection17, valueAxis18, polarItemRenderer19);
        polarPlot20.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = polarPlot20.getOrientation();
        combinedRangeXYPlot15.setOrientation(plotOrientation23);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer25 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean26 = xYLineAndShapeRenderer25.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer25.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke30 = xYLineAndShapeRenderer25.getBaseOutlineStroke();
        java.awt.Stroke stroke32 = xYLineAndShapeRenderer25.lookupSeriesStroke(4);
        combinedRangeXYPlot15.setDomainCrosshairStroke(stroke32);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        numberAxis34.setFixedAutoRange((double) 9);
        combinedRangeXYPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis34);
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis34.setLeftArrow(shape39);
        java.text.NumberFormat numberFormat41 = java.text.NumberFormat.getNumberInstance();
        boolean boolean42 = numberFormat41.isParseIntegerOnly();
        numberAxis34.setNumberFormatOverride(numberFormat41);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis34, categoryItemRenderer44);
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        categoryPlot45.setRangeAxis((int) (byte) 100, valueAxis47);
        java.lang.Comparable comparable49 = categoryPlot45.getDomainCrosshairRowKey();
        categoryPlot45.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.IntervalMarker intervalMarker54 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 1.0f);
        java.awt.Paint paint55 = intervalMarker54.getOutlinePaint();
        java.awt.Stroke stroke56 = intervalMarker54.getOutlineStroke();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer57 = null;
        intervalMarker54.setGradientPaintTransformer(gradientPaintTransformer57);
        float float59 = intervalMarker54.getAlpha();
        categoryPlot45.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker54);
        java.awt.Stroke stroke61 = categoryPlot45.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(numberFormat41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(comparable49);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertTrue("'" + float59 + "' != '" + 0.8f + "'", float59 == 0.8f);
        org.junit.Assert.assertNotNull(stroke61);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true);
        xYSeries2.fireSeriesChanged();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries2);
        boolean boolean5 = xYSeries2.isEmpty();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        int int8 = piePlot7.getPieIndex();
        boolean boolean10 = piePlot7.equals((java.lang.Object) "");
        float float11 = piePlot7.getBackgroundImageAlpha();
        java.awt.Shape shape16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.general.PieDataset pieDataset17 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity23 = new org.jfree.chart.entity.PieSectionEntity(shape16, pieDataset17, 1, (int) (short) -1, (java.lang.Comparable) 3, "hi!", "index.html");
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.plot.PiePlot piePlot25 = new org.jfree.chart.plot.PiePlot(pieDataset24);
        piePlot25.setStartAngle(1.0d);
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape33, (java.awt.Paint) color34);
        piePlot25.setLabelLinkPaint((java.awt.Paint) color34);
        org.jfree.chart.LegendItem legendItem37 = new org.jfree.chart.LegendItem("", "TimePeriodAnchor.START", "TimePeriodAnchor.START", "DateTickUnitType.SECOND", shape16, (java.awt.Paint) color34);
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        legendItem37.setFillPaint((java.awt.Paint) color38);
        piePlot7.setLabelBackgroundPaint((java.awt.Paint) color38);
        boolean boolean41 = xYSeries2.equals((java.lang.Object) color38);
        int int42 = color38.getTransparency();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        java.awt.Shape shape0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) waferMapPlot1);
        java.lang.Object obj3 = legendTitle2.clone();
        double double4 = legendTitle2.getHeight();
        try {
            org.jfree.chart.entity.TitleEntity titleEntity7 = new org.jfree.chart.entity.TitleEntity(shape0, (org.jfree.chart.title.Title) legendTitle2, "rect", "{0}");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RangeType.FULL");
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        java.awt.Color color1 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("EXPAND");
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = org.jfree.chart.axis.DateTickMarkPosition.END;
        dateAxis1.setTickMarkPosition(dateTickMarkPosition3);
        boolean boolean6 = dateAxis1.isHiddenValue(100L);
        java.text.DateFormat dateFormat7 = null;
        dateAxis1.setDateFormatOverride(dateFormat7);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesStroke(false);
        barRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray8 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray8);
        org.jfree.data.Range range10 = barRenderer5.findRangeBounds(categoryDataset9);
        org.jfree.data.Range range11 = barRenderer0.findRangeBounds(categoryDataset9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection17, valueAxis18, polarItemRenderer19);
        polarPlot20.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = polarPlot20.getOrientation();
        combinedRangeXYPlot15.setOrientation(plotOrientation23);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer25 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean26 = xYLineAndShapeRenderer25.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer25.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke30 = xYLineAndShapeRenderer25.getBaseOutlineStroke();
        java.awt.Stroke stroke32 = xYLineAndShapeRenderer25.lookupSeriesStroke(4);
        combinedRangeXYPlot15.setDomainCrosshairStroke(stroke32);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        numberAxis34.setFixedAutoRange((double) 9);
        combinedRangeXYPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis34);
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis34.setLeftArrow(shape39);
        java.text.NumberFormat numberFormat41 = java.text.NumberFormat.getNumberInstance();
        boolean boolean42 = numberFormat41.isParseIntegerOnly();
        numberAxis34.setNumberFormatOverride(numberFormat41);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis34, categoryItemRenderer44);
        categoryPlot45.clearDomainMarkers();
        int int47 = categoryPlot45.getCrosshairDatasetIndex();
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str49 = categoryAxis48.getLabelURL();
        categoryAxis48.setUpperMargin(Double.NaN);
        int int52 = categoryPlot45.getDomainAxisIndex(categoryAxis48);
        categoryPlot45.setCrosshairDatasetIndex(0, true);
        java.awt.Shape shape61 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color62 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem63 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape61, (java.awt.Paint) color62);
        categoryPlot45.setDomainCrosshairPaint((java.awt.Paint) color62);
        categoryPlot45.mapDatasetToRangeAxis(0, (int) (short) 1);
        java.awt.Paint paint68 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        categoryPlot45.setNoDataMessagePaint(paint68);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(numberFormat41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(shape61);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(paint68);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.setDomainZeroBaselineVisible(false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot3.setDomainCrosshairValue((double) 9, true);
        boolean boolean7 = combinedRangeXYPlot3.isDomainCrosshairLockedOnData();
        combinedRangeXYPlot0.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3);
        java.util.List list9 = combinedRangeXYPlot3.getAnnotations();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection12 = new org.jfree.data.time.TimeSeriesCollection(timeZone11);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection12, valueAxis13, polarItemRenderer14);
        polarPlot15.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation18 = polarPlot15.getOrientation();
        combinedRangeXYPlot10.setOrientation(plotOrientation18);
        org.jfree.chart.plot.IntervalMarker intervalMarker22 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 1.0f);
        java.awt.Paint paint23 = intervalMarker22.getOutlinePaint();
        java.awt.Stroke stroke24 = intervalMarker22.getOutlineStroke();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer25 = null;
        intervalMarker22.setGradientPaintTransformer(gradientPaintTransformer25);
        float float27 = intervalMarker22.getAlpha();
        combinedRangeXYPlot10.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker22);
        boolean boolean29 = combinedRangeXYPlot3.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker22);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(plotOrientation18);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.8f + "'", float27 == 0.8f);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo0);
        boolean boolean2 = state1.getProcessVisibleItemsOnly();
        java.awt.geom.GeneralPath generalPath3 = state1.seriesPath;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset4 = new org.jfree.data.xy.DefaultXYDataset();
        int int6 = defaultXYDataset4.indexOf((java.lang.Comparable) 0.5f);
        state1.endSeriesPass((org.jfree.data.xy.XYDataset) defaultXYDataset4, (int) (short) 100, 0, (int) (short) 10, (int) (byte) 0, 64);
        java.util.TimeZone timeZone13 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection14 = new org.jfree.data.time.TimeSeriesCollection(timeZone13);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer16 = null;
        org.jfree.chart.plot.PolarPlot polarPlot17 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection14, valueAxis15, polarItemRenderer16);
        boolean boolean18 = polarPlot17.isRadiusGridlinesVisible();
        polarPlot17.addCornerTextItem("hi!");
        defaultXYDataset4.removeChangeListener((org.jfree.data.general.DatasetChangeListener) polarPlot17);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(generalPath3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.util.LogFormat logFormat0 = new org.jfree.chart.util.LogFormat();
        java.lang.Object obj1 = logFormat0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true);
        xYSeries2.fireSeriesChanged();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries2);
        boolean boolean5 = xYSeriesCollection4.isAutoWidth();
        int int7 = xYSeriesCollection4.indexOf((java.lang.Comparable) 6);
        try {
            xYSeriesCollection4.setIntervalWidth((double) (-32640));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'width' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint3 = xYLineAndShapeRenderer0.lookupLegendTextPaint((int) (short) 100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        int int5 = barRenderer4.getRowCount();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        barRenderer4.setSeriesPaint(3, (java.awt.Paint) color7);
        xYLineAndShapeRenderer0.setBasePaint((java.awt.Paint) color7, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        polarPlot4.setAngleGridlinesVisible(false);
        polarPlot4.setAngleGridlinesVisible(false);
        boolean boolean10 = polarPlot4.equals((java.lang.Object) 0.0f);
        boolean boolean11 = polarPlot4.isAngleGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) (short) 10, categoryItemLabelGenerator2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator((-4145152), (int) (byte) 1, false);
        int int8 = barRenderer0.getColumnCount();
        boolean boolean12 = barRenderer0.getItemCreateEntity(0, 15, true);
        barRenderer0.setShadowXOffset((double) 64);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke5 = xYLineAndShapeRenderer0.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath8 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean11 = textBlockAnchor9.equals((java.lang.Object) chartRenderingInfo10);
        java.awt.geom.Rectangle2D rectangle2D12 = chartRenderingInfo10.getChartArea();
        org.jfree.chart.RenderingSource renderingSource13 = null;
        combinedRangeXYPlot7.select(generalPath8, rectangle2D12, renderingSource13);
        org.jfree.chart.plot.XYPlot xYPlot15 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset16 = new org.jfree.data.xy.DefaultXYDataset();
        int int18 = defaultXYDataset16.indexOf((java.lang.Comparable) 0.5f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState20 = xYLineAndShapeRenderer0.initialise(graphics2D6, rectangle2D12, xYPlot15, (org.jfree.data.xy.XYDataset) defaultXYDataset16, plotRenderingInfo19);
        int int21 = xYItemRendererState20.getFirstItemIndex();
        org.jfree.data.xy.XYSeries xYSeries24 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true);
        xYSeries24.fireSeriesChanged();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection26 = new org.jfree.data.xy.XYSeriesCollection(xYSeries24);
        boolean boolean27 = xYSeriesCollection26.isAutoWidth();
        xYSeriesCollection26.setIntervalWidth((double) 3);
        xYItemRendererState20.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) xYSeriesCollection26);
        org.jfree.data.general.DatasetGroup datasetGroup31 = null;
        try {
            xYSeriesCollection26.setGroup(datasetGroup31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'group' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true);
        xYSeries2.fireSeriesChanged();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries2);
        xYSeries2.setMaximumItemCount((int) ' ');
        xYSeries2.clear();
        xYSeries2.setNotify(false);
        boolean boolean10 = xYSeries2.getAutoSort();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getShadowsVisible();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = barRenderer0.getBaseURLGenerator();
        barRenderer0.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = barRenderer0.getSeriesItemLabelGenerator(2958465);
        double double7 = barRenderer0.getLowerClip();
        double double8 = barRenderer0.getBase();
        java.awt.Font font9 = barRenderer0.getBaseLegendTextFont();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(font9);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getPercentInstance();
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 7, (int) (short) 100, (int) (short) 1);
        segmentedTimeline3.setStartTime((long) 10);
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange();
        java.util.Date date7 = dateRange6.getUpperDate();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment8 = segmentedTimeline3.getSegment(date7);
        boolean boolean9 = segment8.inExceptionSegments();
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(segment8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType1 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType1, (int) (short) 100);
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange();
        java.util.Date date5 = dateRange4.getUpperDate();
        java.util.Date date6 = dateTickUnit3.rollDate(date5);
        boolean boolean7 = blockContainer0.equals((java.lang.Object) date6);
        java.util.List list8 = blockContainer0.getBlocks();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot9.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer12 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean13 = xYLineAndShapeRenderer12.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer12.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke17 = xYLineAndShapeRenderer12.getBaseOutlineStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = xYLineAndShapeRenderer12.getBasePositiveItemLabelPosition();
        java.awt.Shape shape19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity26 = new org.jfree.chart.entity.PieSectionEntity(shape19, pieDataset20, 1, (int) (short) -1, (java.lang.Comparable) 3, "hi!", "index.html");
        xYLineAndShapeRenderer12.setBaseShape(shape19, true);
        int int29 = combinedRangeXYPlot9.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer12);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis("EXPAND");
        combinedRangeXYPlot9.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis31);
        boolean boolean33 = dateAxis31.isTickMarksVisible();
        dateAxis31.zoomRange((double) 8, (double) (short) 100);
        boolean boolean37 = blockContainer0.equals((java.lang.Object) 8);
        org.junit.Assert.assertNotNull(dateTickUnitType1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        double double3 = timeSeriesCollection1.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean7 = xYLineAndShapeRenderer6.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer6.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke11 = xYLineAndShapeRenderer6.getBaseOutlineStroke();
        java.awt.Stroke stroke13 = xYLineAndShapeRenderer6.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, valueAxis5, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer6);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = xYPlot14.getInsets();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYPlot14.setNoDataMessagePaint((java.awt.Paint) color16);
        org.jfree.chart.axis.LogAxis logAxis18 = new org.jfree.chart.axis.LogAxis();
        boolean boolean19 = logAxis18.isTickMarksVisible();
        java.awt.Paint paint20 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder(paint20);
        java.awt.Paint paint22 = blockBorder21.getPaint();
        logAxis18.setTickMarkPaint(paint22);
        int int24 = xYPlot14.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis18);
        org.jfree.chart.axis.NumberAxis numberAxis25 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot30 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.title.LegendTitle legendTitle31 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) waferMapPlot30);
        java.awt.Font font32 = legendTitle31.getItemFont();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis25, (-6.0d), (double) (byte) 100, (double) (-1L), 4.0d, font32);
        logAxis18.setLabelFont(font32);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(font32);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator1 = xYBarRenderer0.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset2 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range3 = xYBarRenderer0.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset2);
        double double4 = xYBarRenderer0.getShadowXOffset();
        xYBarRenderer0.setAutoPopulateSeriesStroke(true);
        java.awt.Shape shape7 = xYBarRenderer0.getLegendBar();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYBarRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor9 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor9, textAnchor10);
        xYBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition11);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer13 = null;
        xYBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer13);
        org.junit.Assert.assertNull(xYItemLabelGenerator1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(itemLabelAnchor9);
        org.junit.Assert.assertNotNull(textAnchor10);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone0;
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("EXPAND");
        dateAxis1.centerRange((double) (-2208960000000L));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean4 = textBlockAnchor2.equals((java.lang.Object) chartRenderingInfo3);
        java.awt.geom.Rectangle2D rectangle2D5 = chartRenderingInfo3.getChartArea();
        org.jfree.chart.RenderingSource renderingSource6 = null;
        combinedRangeXYPlot0.select(generalPath1, rectangle2D5, renderingSource6);
        java.awt.Paint paint8 = combinedRangeXYPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = combinedRangeXYPlot0.getDatasetRenderingOrder();
        combinedRangeXYPlot0.setOutlineVisible(false);
        combinedRangeXYPlot0.clearSelection();
        org.jfree.chart.axis.ValueAxis valueAxis13 = combinedRangeXYPlot0.getDomainAxis();
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertNull(valueAxis13);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true);
        xYSeries2.fireSeriesChanged();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries2);
        boolean boolean5 = xYSeriesCollection4.isAutoWidth();
        org.jfree.data.Range range7 = xYSeriesCollection4.getRangeBounds(true);
        try {
            int int9 = xYSeriesCollection4.getItemCount(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(range7);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator1 = xYBarRenderer0.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset2 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range3 = xYBarRenderer0.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset2);
        double double4 = xYBarRenderer0.getShadowXOffset();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean6 = xYLineAndShapeRenderer5.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer5.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke10 = xYLineAndShapeRenderer5.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath13 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean16 = textBlockAnchor14.equals((java.lang.Object) chartRenderingInfo15);
        java.awt.geom.Rectangle2D rectangle2D17 = chartRenderingInfo15.getChartArea();
        org.jfree.chart.RenderingSource renderingSource18 = null;
        combinedRangeXYPlot12.select(generalPath13, rectangle2D17, renderingSource18);
        org.jfree.chart.plot.XYPlot xYPlot20 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset21 = new org.jfree.data.xy.DefaultXYDataset();
        int int23 = defaultXYDataset21.indexOf((java.lang.Comparable) 0.5f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState25 = xYLineAndShapeRenderer5.initialise(graphics2D11, rectangle2D17, xYPlot20, (org.jfree.data.xy.XYDataset) defaultXYDataset21, plotRenderingInfo24);
        org.jfree.data.Range range26 = xYBarRenderer0.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset21);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer27 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean28 = xYLineAndShapeRenderer27.getDrawOutlines();
        java.awt.Shape shape29 = xYLineAndShapeRenderer27.getBaseShape();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor30 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.jfree.chart.text.TextAnchor textAnchor31 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor30, textAnchor31);
        xYLineAndShapeRenderer27.setBaseNegativeItemLabelPosition(itemLabelPosition32);
        xYBarRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition32);
        double double35 = itemLabelPosition32.getAngle();
        boolean boolean37 = itemLabelPosition32.equals((java.lang.Object) 24234L);
        org.junit.Assert.assertNull(xYItemLabelGenerator1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(textBlockAnchor14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState25);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(itemLabelAnchor30);
        org.junit.Assert.assertNotNull(textAnchor31);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true);
        xYSeries2.fireSeriesChanged();
        xYSeries2.setKey((java.lang.Comparable) 15.625d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean4 = xYLineAndShapeRenderer3.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer3.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke8 = xYLineAndShapeRenderer3.getBaseOutlineStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYLineAndShapeRenderer3.getBasePositiveItemLabelPosition();
        java.awt.Shape shape10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity17 = new org.jfree.chart.entity.PieSectionEntity(shape10, pieDataset11, 1, (int) (short) -1, (java.lang.Comparable) 3, "hi!", "index.html");
        xYLineAndShapeRenderer3.setBaseShape(shape10, true);
        int int20 = combinedRangeXYPlot0.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer3);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("EXPAND");
        combinedRangeXYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis22);
        boolean boolean24 = dateAxis22.isTickMarksVisible();
        dateAxis22.zoomRange((double) 0.5f, (double) 500);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getNumberInstance();
        boolean boolean3 = numberFormat2.isParseIntegerOnly();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = new org.jfree.chart.axis.NumberTickUnit((double) 1, numberFormat2);
        int int5 = numberFormat2.getMaximumFractionDigits();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = new org.jfree.chart.axis.NumberTickUnit((double) (-1), numberFormat2, 10);
        numberFormat2.setMaximumFractionDigits((int) (byte) 10);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState2 = timeSeriesCollection1.getSelectionState();
        java.util.List list3 = timeSeriesCollection1.getSeries();
        int int5 = timeSeriesCollection1.indexOf((java.lang.Comparable) 1.0f);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate7 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection1, true);
        java.lang.Object obj8 = intervalXYDelegate7.clone();
        double double9 = intervalXYDelegate7.getIntervalWidth();
        double double10 = intervalXYDelegate7.getIntervalPositionFactor();
        org.junit.Assert.assertNotNull(xYDatasetSelectionState2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.5d + "'", double10 == 0.5d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = blockBorder0.getInsets();
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.setDomainZeroBaselineVisible(false);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean7 = combinedRangeXYPlot0.removeDomainMarker((int) (short) 0, marker4, layer5, false);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation9 = axisLocation8.getOpposite();
        combinedRangeXYPlot0.setDomainAxisLocation(axisLocation9, false);
        combinedRangeXYPlot0.setRangeMinorGridlinesVisible(false);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (-1), range1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getWidthConstraintType();
        org.jfree.data.Range range4 = rectangleConstraint2.getWidthRange();
        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint(0.2d, range6);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint2.toRangeWidth(range6);
        org.jfree.data.time.DateRange dateRange9 = new org.jfree.data.time.DateRange();
        java.util.Date date10 = dateRange9.getUpperDate();
        org.jfree.data.Range range12 = org.jfree.data.Range.scale((org.jfree.data.Range) dateRange9, (double) (byte) 100);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint8.toRangeHeight(range12);
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState2 = timeSeriesCollection1.getSelectionState();
        java.util.List list3 = timeSeriesCollection1.getSeries();
        int int5 = timeSeriesCollection1.indexOf((java.lang.Comparable) 1.0f);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate7 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection1, true);
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str10 = dateTickUnit8.valueToString((double) 2);
        int int11 = dateTickUnit8.getMultiple();
        boolean boolean12 = intervalXYDelegate7.equals((java.lang.Object) dateTickUnit8);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "12/31/69 4:00 PM" + "'", str10.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 1, (int) (short) -1, (java.lang.Comparable) 3, "hi!", "index.html");
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray13 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray13);
        org.jfree.data.Range range15 = barRenderer10.findRangeBounds(categoryDataset14);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity18 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "hi!", "hi!", categoryDataset14, (java.lang.Comparable) 64, (java.lang.Comparable) (short) 0);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer20 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator21 = xYBarRenderer20.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset22 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range23 = xYBarRenderer20.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset22);
        double double24 = xYBarRenderer20.getShadowXOffset();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator25 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer20.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator25, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer29 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator30 = xYBarRenderer29.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset31 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range32 = xYBarRenderer29.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset31);
        double double33 = xYBarRenderer29.getShadowXOffset();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator34 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer29.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator34, true);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator37 = new org.jfree.chart.urls.StandardXYURLGenerator();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer38 = new org.jfree.chart.renderer.xy.XYAreaRenderer(8, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator34, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator37);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer39 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator25, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator37);
        xYStepAreaRenderer39.setShapesFilled(false);
        xYStepAreaRenderer39.removeAnnotations();
        boolean boolean43 = categoryItemEntity18.equals((java.lang.Object) xYStepAreaRenderer39);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(categoryDataset14);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNull(xYItemLabelGenerator21);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 4.0d + "'", double24 == 4.0d);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator25);
        org.junit.Assert.assertNull(xYItemLabelGenerator30);
        org.junit.Assert.assertNull(range32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 4.0d + "'", double33 == 4.0d);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator34);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.chart.axis.LogAxis logAxis1 = new org.jfree.chart.axis.LogAxis();
        org.jfree.chart.axis.LogAxis logAxis2 = new org.jfree.chart.axis.LogAxis();
        boolean boolean3 = logAxis2.isTickMarksVisible();
        java.awt.Paint paint4 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(paint4);
        java.awt.Paint paint6 = blockBorder5.getPaint();
        logAxis2.setTickMarkPaint(paint6);
        java.text.NumberFormat numberFormat8 = java.text.NumberFormat.getIntegerInstance();
        logAxis2.setNumberFormatOverride(numberFormat8);
        logAxis1.setNumberFormatOverride(numberFormat8);
        java.text.NumberFormat numberFormat11 = java.text.NumberFormat.getCurrencyInstance();
        numberFormat11.setMinimumFractionDigits((int) (byte) 100);
        java.util.Currency currency14 = numberFormat11.getCurrency();
        numberFormat8.setCurrency(currency14);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit17 = new org.jfree.chart.axis.NumberTickUnit((double) (-1.0f), numberFormat8, (int) 'a');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(numberFormat8);
        org.junit.Assert.assertNotNull(numberFormat11);
        org.junit.Assert.assertNotNull(currency14);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesStroke(false);
        barRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray8 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray8);
        org.jfree.data.Range range10 = barRenderer5.findRangeBounds(categoryDataset9);
        org.jfree.data.Range range11 = barRenderer0.findRangeBounds(categoryDataset9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection17, valueAxis18, polarItemRenderer19);
        polarPlot20.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = polarPlot20.getOrientation();
        combinedRangeXYPlot15.setOrientation(plotOrientation23);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer25 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean26 = xYLineAndShapeRenderer25.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer25.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke30 = xYLineAndShapeRenderer25.getBaseOutlineStroke();
        java.awt.Stroke stroke32 = xYLineAndShapeRenderer25.lookupSeriesStroke(4);
        combinedRangeXYPlot15.setDomainCrosshairStroke(stroke32);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        numberAxis34.setFixedAutoRange((double) 9);
        combinedRangeXYPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis34);
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis34.setLeftArrow(shape39);
        java.text.NumberFormat numberFormat41 = java.text.NumberFormat.getNumberInstance();
        boolean boolean42 = numberFormat41.isParseIntegerOnly();
        numberAxis34.setNumberFormatOverride(numberFormat41);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis34, categoryItemRenderer44);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D46.setLabel("org.jfree.chart.event.RendererChangeEvent[source=1.0]");
        org.jfree.data.Range range49 = categoryPlot45.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D46);
        categoryPlot45.setDrawSharedDomainAxis(false);
        org.jfree.chart.util.SortOrder sortOrder52 = categoryPlot45.getColumnRenderingOrder();
        org.jfree.data.category.CategoryDataset categoryDataset53 = categoryPlot45.getDataset();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType54 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit56 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType54, (int) (short) 100);
        java.lang.String str57 = dateTickUnit56.toString();
        org.jfree.data.general.PieDataset pieDataset58 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset53, (java.lang.Comparable) str57);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(numberFormat41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertNotNull(sortOrder52);
        org.junit.Assert.assertNotNull(categoryDataset53);
        org.junit.Assert.assertNotNull(dateTickUnitType54);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "DateTickUnit[DateTickUnitType.YEAR, 100]" + "'", str57.equals("DateTickUnit[DateTickUnitType.YEAR, 100]"));
        org.junit.Assert.assertNotNull(pieDataset58);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean5 = xYLineAndShapeRenderer4.getDrawOutlines();
        java.awt.Shape shape6 = xYLineAndShapeRenderer4.getBaseShape();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor7 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor7, textAnchor8);
        xYLineAndShapeRenderer4.setBaseNegativeItemLabelPosition(itemLabelPosition9);
        java.awt.Paint paint12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        xYLineAndShapeRenderer4.setSeriesPaint(0, paint12);
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder((double) (short) 100, (double) ' ', Double.NaN, (double) (-1.0f), paint12);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(itemLabelAnchor7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setStartAngle(1.0d);
        java.awt.Image image4 = null;
        piePlot1.setBackgroundImage(image4);
        double double6 = piePlot1.getMaximumLabelWidth();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle7 = piePlot1.getLabelLinkStyle();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator8 = piePlot1.getLegendLabelURLGenerator();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.14d + "'", double6 == 0.14d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle7);
        org.junit.Assert.assertNull(pieURLGenerator8);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        int int2 = piePlot1.getPieIndex();
        double double3 = piePlot1.getMaximumLabelWidth();
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        piePlot1.setLabelBackgroundPaint(paint4);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = piePlot1.getLegendItems();
        java.awt.Paint paint7 = piePlot1.getLabelOutlinePaint();
        java.awt.Stroke stroke8 = piePlot1.getBaseSectionOutlineStroke();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection12 = new org.jfree.data.time.TimeSeriesCollection(timeZone11);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection12, valueAxis13, polarItemRenderer14);
        polarPlot15.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation18 = polarPlot15.getOrientation();
        combinedRangeXYPlot10.setOrientation(plotOrientation18);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer20 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean21 = xYLineAndShapeRenderer20.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer20.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke25 = xYLineAndShapeRenderer20.getBaseOutlineStroke();
        java.awt.Stroke stroke27 = xYLineAndShapeRenderer20.lookupSeriesStroke(4);
        combinedRangeXYPlot10.setDomainCrosshairStroke(stroke27);
        piePlot1.setSectionOutlineStroke((java.lang.Comparable) 8.0d, stroke27);
        java.text.NumberFormat numberFormat33 = java.text.NumberFormat.getNumberInstance();
        boolean boolean34 = numberFormat33.isParseIntegerOnly();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit35 = new org.jfree.chart.axis.NumberTickUnit((double) 1, numberFormat33);
        int int36 = numberFormat33.getMaximumFractionDigits();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit38 = new org.jfree.chart.axis.NumberTickUnit((double) 9, numberFormat33, (int) 'a');
        java.text.NumberFormat numberFormat39 = java.text.NumberFormat.getNumberInstance();
        boolean boolean40 = numberFormat39.isParseIntegerOnly();
        int int41 = numberFormat39.getMinimumIntegerDigits();
        numberFormat39.setMinimumFractionDigits(100);
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator44 = new org.jfree.chart.labels.StandardPieToolTipGenerator("12/31/69 4:00 PM", numberFormat33, numberFormat39);
        piePlot1.setToolTipGenerator((org.jfree.chart.labels.PieToolTipGenerator) standardPieToolTipGenerator44);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.14d + "'", double3 == 0.14d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(plotOrientation18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(numberFormat33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 3 + "'", int36 == 3);
        org.junit.Assert.assertNotNull(numberFormat39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("");
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("12/31/69 4:00 PM");
        java.lang.Throwable[] throwableArray2 = unknownKeyException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType1 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType1, (int) (short) 100);
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange();
        java.util.Date date5 = dateRange4.getUpperDate();
        java.util.Date date6 = dateTickUnit3.rollDate(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("12/31/69 4:00 PM", (org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) month8);
        float float10 = periodAxis9.getMinorTickMarkInsideLength();
        org.junit.Assert.assertNotNull(dateTickUnitType1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        java.awt.Shape shape4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity11 = new org.jfree.chart.entity.PieSectionEntity(shape4, pieDataset5, 1, (int) (short) -1, (java.lang.Comparable) 3, "hi!", "index.html");
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        piePlot13.setStartAngle(1.0d);
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape21, (java.awt.Paint) color22);
        piePlot13.setLabelLinkPaint((java.awt.Paint) color22);
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("", "TimePeriodAnchor.START", "TimePeriodAnchor.START", "DateTickUnitType.SECOND", shape4, (java.awt.Paint) color22);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer27 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0);
        int int28 = xYAreaRenderer27.getDefaultEntityRadius();
        xYAreaRenderer27.setSeriesItemLabelsVisible((int) (short) 100, false);
        java.awt.Shape shape32 = xYAreaRenderer27.getBaseShape();
        org.jfree.chart.renderer.category.BarRenderer barRenderer34 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer34.setAutoPopulateSeriesStroke(false);
        barRenderer34.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer39 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray42 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset43 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray42);
        org.jfree.data.Range range44 = barRenderer39.findRangeBounds(categoryDataset43);
        org.jfree.data.Range range45 = barRenderer34.findRangeBounds(categoryDataset43);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis46.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot49 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone50 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection51 = new org.jfree.data.time.TimeSeriesCollection(timeZone50);
        org.jfree.chart.axis.ValueAxis valueAxis52 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer53 = null;
        org.jfree.chart.plot.PolarPlot polarPlot54 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection51, valueAxis52, polarItemRenderer53);
        polarPlot54.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation57 = polarPlot54.getOrientation();
        combinedRangeXYPlot49.setOrientation(plotOrientation57);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer59 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean60 = xYLineAndShapeRenderer59.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer59.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke64 = xYLineAndShapeRenderer59.getBaseOutlineStroke();
        java.awt.Stroke stroke66 = xYLineAndShapeRenderer59.lookupSeriesStroke(4);
        combinedRangeXYPlot49.setDomainCrosshairStroke(stroke66);
        org.jfree.chart.axis.NumberAxis numberAxis68 = new org.jfree.chart.axis.NumberAxis();
        numberAxis68.setFixedAutoRange((double) 9);
        combinedRangeXYPlot49.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis68);
        java.awt.Shape shape73 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis68.setLeftArrow(shape73);
        java.text.NumberFormat numberFormat75 = java.text.NumberFormat.getNumberInstance();
        boolean boolean76 = numberFormat75.isParseIntegerOnly();
        numberAxis68.setNumberFormatOverride(numberFormat75);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer78 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot79 = new org.jfree.chart.plot.CategoryPlot(categoryDataset43, categoryAxis46, (org.jfree.chart.axis.ValueAxis) numberAxis68, categoryItemRenderer78);
        categoryPlot79.clearDomainMarkers();
        boolean boolean81 = categoryPlot79.isRangePannable();
        java.awt.Paint paint82 = categoryPlot79.getRangeMinorGridlinePaint();
        org.jfree.chart.JFreeChart jFreeChart83 = new org.jfree.chart.JFreeChart("ERROR : Relative To String", (org.jfree.chart.plot.Plot) categoryPlot79);
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity86 = new org.jfree.chart.entity.JFreeChartEntity(shape32, jFreeChart83, "TextBlockAnchor.BOTTOM_LEFT", "Pie Plot");
        org.jfree.chart.JFreeChart jFreeChart87 = jFreeChartEntity86.getChart();
        org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity88 = new org.jfree.chart.entity.JFreeChartEntity(shape4, jFreeChart87);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 3 + "'", int28 == 3);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(categoryDataset43);
        org.junit.Assert.assertNull(range44);
        org.junit.Assert.assertNull(range45);
        org.junit.Assert.assertNotNull(plotOrientation57);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNotNull(shape73);
        org.junit.Assert.assertNotNull(numberFormat75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(paint82);
        org.junit.Assert.assertNotNull(jFreeChart87);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelURL();
        java.awt.Font font3 = categoryAxis0.getTickLabelFont((java.lang.Comparable) (byte) 100);
        double double4 = categoryAxis0.getFixedDimension();
        boolean boolean5 = categoryAxis0.isAxisLineVisible();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.previous();
        java.awt.Paint paint8 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) regularTimePeriod7);
        java.util.Calendar calendar9 = null;
        try {
            long long10 = regularTimePeriod7.getMiddleMillisecond(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        categoryAxis0.setLabelPaint((java.awt.Paint) color1);
        double double3 = categoryAxis0.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = null;
        try {
            categoryAxis0.setTickLabelInsets(rectangleInsets4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        org.jfree.chart.axis.TickUnit tickUnit5 = polarPlot4.getAngleTickUnit();
        java.awt.Stroke stroke6 = null;
        polarPlot4.setRadiusGridlineStroke(stroke6);
        org.junit.Assert.assertNotNull(tickUnit5);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape2 = null;
        xYLineAndShapeRenderer0.setBaseLegendShape(shape2);
        xYLineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, false);
        java.awt.Stroke stroke9 = xYLineAndShapeRenderer0.getSeriesStroke((int) '4');
        boolean boolean11 = xYLineAndShapeRenderer0.isSeriesVisibleInLegend(9999);
        xYLineAndShapeRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        int int14 = xYLineAndShapeRenderer0.getPassCount();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        try {
            double double5 = polarPlot4.getMaxRadius();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.setDomainZeroBaselineVisible(false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot3.setDomainCrosshairValue((double) 9, true);
        boolean boolean7 = combinedRangeXYPlot3.isDomainCrosshairLockedOnData();
        combinedRangeXYPlot0.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Shape shape10 = numberAxis3D9.getDownArrow();
        combinedRangeXYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D9);
        java.lang.Object obj12 = combinedRangeXYPlot0.clone();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) (short) 100);
        java.lang.String str3 = dateTickUnit2.toString();
        int int4 = dateTickUnit2.getMultiple();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange();
        java.util.Date date6 = dateRange5.getUpperDate();
        java.util.TimeZone timeZone7 = null;
        try {
            java.util.Date date8 = dateTickUnit2.rollDate(date6, timeZone7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "DateTickUnit[DateTickUnitType.YEAR, 100]" + "'", str3.equals("DateTickUnit[DateTickUnitType.YEAR, 100]"));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) waferMapPlot1);
        java.lang.Object obj3 = legendTitle2.clone();
        double double4 = legendTitle2.getHeight();
        boolean boolean5 = legendTitle2.visible;
        java.awt.Font font6 = legendTitle2.getItemFont();
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("RectangleEdge.TOP", font6);
        java.awt.Font font8 = labelBlock7.getFont();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        double double3 = timeSeriesCollection1.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean7 = xYLineAndShapeRenderer6.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer6.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke11 = xYLineAndShapeRenderer6.getBaseOutlineStroke();
        java.awt.Stroke stroke13 = xYLineAndShapeRenderer6.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, valueAxis5, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer6);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = xYPlot14.getInsets();
        xYPlot14.setNotify(true);
        int int18 = xYPlot14.getWeight();
        org.jfree.chart.axis.AxisLocation axisLocation20 = xYPlot14.getRangeAxisLocation(0);
        java.awt.Paint paint21 = xYPlot14.getBackgroundPaint();
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        polarPlot5.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = polarPlot5.getOrientation();
        combinedRangeXYPlot0.setOrientation(plotOrientation8);
        combinedRangeXYPlot0.setRangeCrosshairValue(0.0d);
        boolean boolean12 = combinedRangeXYPlot0.isDomainCrosshairVisible();
        combinedRangeXYPlot0.setDomainCrosshairValue((double) 1.0f);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor17 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean19 = textBlockAnchor17.equals((java.lang.Object) chartRenderingInfo18);
        java.awt.geom.Rectangle2D rectangle2D20 = chartRenderingInfo18.getChartArea();
        org.jfree.chart.entity.EntityCollection entityCollection21 = chartRenderingInfo18.getEntityCollection();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor22 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo23 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean24 = textBlockAnchor22.equals((java.lang.Object) chartRenderingInfo23);
        java.awt.geom.Rectangle2D rectangle2D25 = chartRenderingInfo23.getChartArea();
        chartRenderingInfo18.setChartArea(rectangle2D25);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = chartRenderingInfo18.getPlotInfo();
        java.awt.geom.Point2D point2D28 = null;
        try {
            combinedRangeXYPlot0.zoomDomainAxes(8.0d, (double) '#', plotRenderingInfo27, point2D28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(entityCollection21);
        org.junit.Assert.assertNotNull(textBlockAnchor22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNotNull(plotRenderingInfo27);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true);
        xYSeries2.fireSeriesChanged();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries2);
        try {
            xYSeriesCollection4.setSelected((-1), 2958465, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 0L, 0.025d);
        size2D2.setHeight((double) (short) 100);
        org.jfree.chart.axis.NumberAxis numberAxis5 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot10 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) waferMapPlot10);
        java.awt.Font font12 = legendTitle11.getItemFont();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand13 = new org.jfree.chart.axis.MarkerAxisBand(numberAxis5, (-6.0d), (double) (byte) 100, (double) (-1L), 4.0d, font12);
        boolean boolean14 = size2D2.equals((java.lang.Object) markerAxisBand13);
        size2D2.setWidth(0.2d);
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 1.0f);
        java.awt.Paint paint22 = intervalMarker21.getOutlinePaint();
        java.awt.Stroke stroke23 = intervalMarker21.getOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor24 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        intervalMarker21.setLabelAnchor(rectangleAnchor24);
        java.awt.geom.Rectangle2D rectangle2D26 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D2, (double) '#', (double) 0L, rectangleAnchor24);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(rectangleAnchor24);
        org.junit.Assert.assertNotNull(rectangle2D26);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = xYBarRenderer1.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset3 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range4 = xYBarRenderer1.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset3);
        double double5 = xYBarRenderer1.getShadowXOffset();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator6 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer1.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator6, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator11 = xYBarRenderer10.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset12 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range13 = xYBarRenderer10.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset12);
        double double14 = xYBarRenderer10.getShadowXOffset();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator15 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer10.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator15, true);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator18 = new org.jfree.chart.urls.StandardXYURLGenerator();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer19 = new org.jfree.chart.renderer.xy.XYAreaRenderer(8, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator15, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator18);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer20 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator6, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator18);
        xYStepAreaRenderer20.setShapesFilled(false);
        xYStepAreaRenderer20.removeAnnotations();
        java.awt.Stroke stroke25 = xYStepAreaRenderer20.getSeriesOutlineStroke(4);
        java.awt.Paint paint27 = xYStepAreaRenderer20.getSeriesOutlinePaint((int) (byte) 100);
        org.junit.Assert.assertNull(xYItemLabelGenerator2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator6);
        org.junit.Assert.assertNull(xYItemLabelGenerator11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator15);
        org.junit.Assert.assertNull(stroke25);
        org.junit.Assert.assertNull(paint27);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        java.awt.Shape shape0 = null;
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 1.0f);
        java.awt.Paint paint4 = intervalMarker3.getOutlinePaint();
        try {
            org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape0, paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getNumberInstance();
        boolean boolean2 = numberFormat1.isParseIntegerOnly();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) 1, numberFormat1);
        int int4 = numberFormat1.getMaximumFractionDigits();
        int int5 = numberFormat1.getMaximumFractionDigits();
        int int6 = numberFormat1.getMinimumIntegerDigits();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) (short) 10, categoryItemLabelGenerator2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator((-4145152), (int) (byte) 1, false);
        int int8 = barRenderer0.getColumnCount();
        barRenderer0.clearSeriesPaints(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state12 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo11);
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState13 = new org.jfree.chart.plot.XYCrosshairState();
        state12.setCrosshairState(xYCrosshairState13);
        boolean boolean15 = barRenderer0.equals((java.lang.Object) xYCrosshairState13);
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesStroke(false);
        barRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray8 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray8);
        org.jfree.data.Range range10 = barRenderer5.findRangeBounds(categoryDataset9);
        org.jfree.data.Range range11 = barRenderer0.findRangeBounds(categoryDataset9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection17, valueAxis18, polarItemRenderer19);
        polarPlot20.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = polarPlot20.getOrientation();
        combinedRangeXYPlot15.setOrientation(plotOrientation23);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer25 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean26 = xYLineAndShapeRenderer25.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer25.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke30 = xYLineAndShapeRenderer25.getBaseOutlineStroke();
        java.awt.Stroke stroke32 = xYLineAndShapeRenderer25.lookupSeriesStroke(4);
        combinedRangeXYPlot15.setDomainCrosshairStroke(stroke32);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        numberAxis34.setFixedAutoRange((double) 9);
        combinedRangeXYPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis34);
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis34.setLeftArrow(shape39);
        java.text.NumberFormat numberFormat41 = java.text.NumberFormat.getNumberInstance();
        boolean boolean42 = numberFormat41.isParseIntegerOnly();
        numberAxis34.setNumberFormatOverride(numberFormat41);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis34, categoryItemRenderer44);
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        categoryPlot45.setRangeAxis((int) (byte) 100, valueAxis47);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent49 = null;
        categoryPlot45.markerChanged(markerChangeEvent49);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = categoryPlot45.getRenderer();
        java.awt.Paint paint52 = categoryPlot45.getRangeGridlinePaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor53 = categoryPlot45.getDomainGridlinePosition();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(numberFormat41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(categoryItemRenderer51);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(categoryAnchor53);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        java.text.DateFormat dateFormat1 = standardXYToolTipGenerator0.getXDateFormat();
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator0);
        org.junit.Assert.assertNotNull(dateFormat1);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 7, (int) (short) 100, (int) (short) 1);
        segmentedTimeline3.setStartTime((long) 10);
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange();
        java.util.Date date7 = dateRange6.getUpperDate();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment8 = segmentedTimeline3.getSegment(date7);
        long long10 = segment8.calculateSegmentNumber(7L);
        segment8.moveIndexToEnd();
        long long12 = segment8.getSegmentCount();
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(segment8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-1L) + "'", long10 == (-1L));
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1L + "'", long12 == 1L);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(9999);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) (short) 10, categoryItemLabelGenerator2);
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter7 = new org.jfree.chart.renderer.category.GradientBarPainter(0.14d, (-1.0d), (double) 100);
        barRenderer0.setBarPainter((org.jfree.chart.renderer.category.BarPainter) gradientBarPainter7);
        java.awt.Paint paint12 = barRenderer0.getItemPaint((int) ' ', 0, false);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.setDomainZeroBaselineVisible(false);
        combinedRangeXYPlot0.setDomainGridlinesVisible(false);
        org.jfree.data.xy.XYDataset xYDataset5 = combinedRangeXYPlot0.getDataset();
        java.awt.geom.GeneralPath generalPath6 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean8 = xYLineAndShapeRenderer7.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer7.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke12 = xYLineAndShapeRenderer7.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot14 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath15 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor16 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean18 = textBlockAnchor16.equals((java.lang.Object) chartRenderingInfo17);
        java.awt.geom.Rectangle2D rectangle2D19 = chartRenderingInfo17.getChartArea();
        org.jfree.chart.RenderingSource renderingSource20 = null;
        combinedRangeXYPlot14.select(generalPath15, rectangle2D19, renderingSource20);
        org.jfree.chart.plot.XYPlot xYPlot22 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset23 = new org.jfree.data.xy.DefaultXYDataset();
        int int25 = defaultXYDataset23.indexOf((java.lang.Comparable) 0.5f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState27 = xYLineAndShapeRenderer7.initialise(graphics2D13, rectangle2D19, xYPlot22, (org.jfree.data.xy.XYDataset) defaultXYDataset23, plotRenderingInfo26);
        org.jfree.chart.RenderingSource renderingSource28 = null;
        combinedRangeXYPlot0.select(generalPath6, rectangle2D19, renderingSource28);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.awt.geom.Point2D point2D31 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D19, rectangleAnchor30);
        org.junit.Assert.assertNull(xYDataset5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(textBlockAnchor16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState27);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNotNull(point2D31);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) (short) 100);
        org.jfree.data.xy.XYDataItem xYDataItem5 = new org.jfree.data.xy.XYDataItem((java.lang.Number) 100.0d, (java.lang.Number) Double.NaN);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean7 = xYLineAndShapeRenderer6.getDrawOutlines();
        java.awt.Shape shape8 = xYLineAndShapeRenderer6.getBaseShape();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor9 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor9, textAnchor10);
        xYLineAndShapeRenderer6.setBaseNegativeItemLabelPosition(itemLabelPosition11);
        boolean boolean13 = xYDataItem5.equals((java.lang.Object) xYLineAndShapeRenderer6);
        boolean boolean14 = dateTickUnit2.equals((java.lang.Object) boolean13);
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(itemLabelAnchor9);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.setDomainZeroBaselineVisible(false);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean7 = combinedRangeXYPlot0.removeDomainMarker((int) (short) 0, marker4, layer5, false);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation9 = axisLocation8.getOpposite();
        combinedRangeXYPlot0.setDomainAxisLocation(axisLocation9, false);
        java.lang.String str12 = axisLocation9.toString();
        java.lang.String str13 = axisLocation9.toString();
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str12.equals("AxisLocation.BOTTOM_OR_LEFT"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str13.equals("AxisLocation.BOTTOM_OR_LEFT"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        double double1 = blockContainer0.getHeight();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = xYBarRenderer1.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset3 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range4 = xYBarRenderer1.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset3);
        double double5 = xYBarRenderer1.getShadowXOffset();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator6 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer1.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator6, true);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator9 = new org.jfree.chart.urls.StandardXYURLGenerator();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer10 = new org.jfree.chart.renderer.xy.XYAreaRenderer(8, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator6, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator9);
        org.jfree.chart.LegendItem legendItem13 = xYAreaRenderer10.getLegendItem((int) '#', (int) (short) 1);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean15 = xYLineAndShapeRenderer14.getBaseShapesVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier16 = xYLineAndShapeRenderer14.getDrawingSupplier();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = xYLineAndShapeRenderer14.getNegativeItemLabelPosition(4, (int) (byte) 100, true);
        java.lang.Boolean boolean22 = xYLineAndShapeRenderer14.getSeriesItemLabelsVisible((int) (byte) 1);
        java.lang.Boolean boolean24 = xYLineAndShapeRenderer14.getSeriesShapesVisible((int) 'a');
        java.awt.Color color25 = java.awt.Color.YELLOW;
        xYLineAndShapeRenderer14.setBaseFillPaint((java.awt.Paint) color25, false);
        xYAreaRenderer10.setBaseItemLabelPaint((java.awt.Paint) color25);
        org.junit.Assert.assertNull(xYItemLabelGenerator2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator6);
        org.junit.Assert.assertNull(legendItem13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(drawingSupplier16);
        org.junit.Assert.assertNotNull(itemLabelPosition20);
        org.junit.Assert.assertNull(boolean22);
        org.junit.Assert.assertNull(boolean24);
        org.junit.Assert.assertNotNull(color25);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        polarPlot5.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = polarPlot5.getOrientation();
        combinedRangeXYPlot0.setOrientation(plotOrientation8);
        combinedRangeXYPlot0.setRangeCrosshairValue(0.0d);
        boolean boolean12 = combinedRangeXYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.plot.RingPlot ringPlot13 = new org.jfree.chart.plot.RingPlot();
        ringPlot13.setSeparatorsVisible(true);
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape21, (java.awt.Paint) color22);
        java.awt.Font font24 = legendItem23.getLabelFont();
        org.jfree.data.general.Dataset dataset25 = null;
        legendItem23.setDataset(dataset25);
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_YELLOW;
        legendItem23.setOutlinePaint((java.awt.Paint) color27);
        legendItem23.setURLText("");
        java.awt.Stroke stroke31 = legendItem23.getLineStroke();
        ringPlot13.setSeparatorStroke(stroke31);
        combinedRangeXYPlot0.setRangeMinorGridlineStroke(stroke31);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(font24);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(stroke31);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        int int2 = piePlot1.getPieIndex();
        double double3 = piePlot1.getMaximumLabelWidth();
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        piePlot1.setLabelBackgroundPaint(paint4);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = piePlot1.getLegendItems();
        java.awt.Paint paint7 = piePlot1.getLabelOutlinePaint();
        piePlot1.setPieIndex((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.14d + "'", double3 == 0.14d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelURL();
        categoryAxis0.setUpperMargin(Double.NaN);
        categoryAxis0.setAxisLineVisible(false);
        java.lang.Comparable comparable6 = null;
        try {
            java.awt.Font font7 = categoryAxis0.getTickLabelFont(comparable6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState2 = timeSeriesCollection1.getSelectionState();
        java.util.List list3 = timeSeriesCollection1.getSeries();
        int int5 = timeSeriesCollection1.indexOf((java.lang.Comparable) 1.0f);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate7 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection1, true);
        java.lang.Object obj8 = intervalXYDelegate7.clone();
        double double10 = intervalXYDelegate7.getDomainLowerBound(false);
        try {
            java.lang.Number number13 = intervalXYDelegate7.getEndX(7, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(xYDatasetSelectionState2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.isVisible();
        numberAxis0.setAutoRangeStickyZero(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) numberAxis0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer5.setAutoPopulateSeriesStroke(false);
        barRenderer5.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray13 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray13);
        org.jfree.data.Range range15 = barRenderer10.findRangeBounds(categoryDataset14);
        org.jfree.data.Range range16 = barRenderer5.findRangeBounds(categoryDataset14);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis17.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection22 = new org.jfree.data.time.TimeSeriesCollection(timeZone21);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer24 = null;
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection22, valueAxis23, polarItemRenderer24);
        polarPlot25.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation28 = polarPlot25.getOrientation();
        combinedRangeXYPlot20.setOrientation(plotOrientation28);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer30 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean31 = xYLineAndShapeRenderer30.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer30.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke35 = xYLineAndShapeRenderer30.getBaseOutlineStroke();
        java.awt.Stroke stroke37 = xYLineAndShapeRenderer30.lookupSeriesStroke(4);
        combinedRangeXYPlot20.setDomainCrosshairStroke(stroke37);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis();
        numberAxis39.setFixedAutoRange((double) 9);
        combinedRangeXYPlot20.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis39);
        java.awt.Shape shape44 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis39.setLeftArrow(shape44);
        java.text.NumberFormat numberFormat46 = java.text.NumberFormat.getNumberInstance();
        boolean boolean47 = numberFormat46.isParseIntegerOnly();
        numberAxis39.setNumberFormatOverride(numberFormat46);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis17, (org.jfree.chart.axis.ValueAxis) numberAxis39, categoryItemRenderer49);
        org.jfree.chart.axis.ValueAxis valueAxis52 = null;
        categoryPlot50.setRangeAxis((int) (byte) 100, valueAxis52);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent54 = null;
        categoryPlot50.markerChanged(markerChangeEvent54);
        org.jfree.chart.axis.AxisSpace axisSpace56 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot50.setFixedRangeAxisSpace(axisSpace56, false);
        combinedDomainXYPlot4.setFixedRangeAxisSpace(axisSpace56);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(categoryDataset14);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(plotOrientation28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(numberFormat46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true);
        xYSeries2.fireSeriesChanged();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries2);
        xYSeries2.setMaximumItemCount((int) ' ');
        org.jfree.chart.block.BlockContainer blockContainer7 = new org.jfree.chart.block.BlockContainer();
        boolean boolean8 = xYSeries2.equals((java.lang.Object) blockContainer7);
        double double9 = xYSeries2.getMinY();
        org.jfree.data.xy.XYDataItem xYDataItem12 = xYSeries2.addOrUpdate(1.0d, 0.0d);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        xYSeries2.addPropertyChangeListener(propertyChangeListener13);
        try {
            java.lang.Number number16 = xYSeries2.getX(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNull(xYDataItem12);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.setDomainZeroBaselineVisible(false);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean7 = combinedRangeXYPlot0.removeDomainMarker((int) (short) 0, marker4, layer5, false);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation9 = axisLocation8.getOpposite();
        combinedRangeXYPlot0.setDomainAxisLocation(axisLocation9, false);
        org.jfree.chart.plot.Plot plot12 = null;
        combinedRangeXYPlot0.setParent(plot12);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYLineAndShapeRenderer0.getNegativeItemLabelPosition(1, (int) (short) 10, true);
        boolean boolean9 = xYLineAndShapeRenderer0.getAutoPopulateSeriesShape();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = null;
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection11, valueAxis12, polarItemRenderer13);
        java.awt.Paint paint15 = polarPlot14.getAngleLabelPaint();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean17 = xYLineAndShapeRenderer16.getAutoPopulateSeriesOutlinePaint();
        java.awt.Font font18 = xYLineAndShapeRenderer16.getBaseItemLabelFont();
        polarPlot14.setAngleLabelFont(font18);
        xYLineAndShapeRenderer0.setBaseLegendTextFont(font18);
        java.awt.Stroke stroke24 = xYLineAndShapeRenderer0.getItemOutlineStroke(0, (-1), false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = xYLineAndShapeRenderer0.getBasePositiveItemLabelPosition();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(itemLabelPosition25);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        java.awt.Paint paint6 = polarPlot5.getAngleLabelPaint();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean8 = xYLineAndShapeRenderer7.getAutoPopulateSeriesOutlinePaint();
        java.awt.Font font9 = xYLineAndShapeRenderer7.getBaseItemLabelFont();
        polarPlot5.setAngleLabelFont(font9);
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("TimePeriodAnchor.START", font9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        numberAxis12.setAxisLinePaint((java.awt.Paint) color13);
        labelBlock11.setPaint((java.awt.Paint) color13);
        java.lang.String str16 = labelBlock11.getURLText();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.setDomainZeroBaselineVisible(false);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean7 = combinedRangeXYPlot0.removeDomainMarker((int) (short) 0, marker4, layer5, false);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation9 = axisLocation8.getOpposite();
        combinedRangeXYPlot0.setDomainAxisLocation(axisLocation9, false);
        boolean boolean12 = combinedRangeXYPlot0.isRangeCrosshairVisible();
        boolean boolean13 = combinedRangeXYPlot0.isDomainCrosshairVisible();
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) (byte) -1);
        java.lang.String str2 = pieLabelDistributor1.toString();
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord4 = pieLabelDistributor1.getPieLabelRecord((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean4 = textBlockAnchor2.equals((java.lang.Object) chartRenderingInfo3);
        java.awt.geom.Rectangle2D rectangle2D5 = chartRenderingInfo3.getChartArea();
        org.jfree.chart.RenderingSource renderingSource6 = null;
        combinedRangeXYPlot0.select(generalPath1, rectangle2D5, renderingSource6);
        java.awt.Paint paint8 = combinedRangeXYPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = combinedRangeXYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = combinedRangeXYPlot0.getRenderer();
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertNull(xYItemRenderer10);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0);
        valueMarker1.setValue(0.05d);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor4, textAnchor5);
        boolean boolean7 = valueMarker1.equals((java.lang.Object) textAnchor5);
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) (short) 10, categoryItemLabelGenerator2);
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter7 = new org.jfree.chart.renderer.category.GradientBarPainter(0.14d, (-1.0d), (double) 100);
        barRenderer0.setBarPainter((org.jfree.chart.renderer.category.BarPainter) gradientBarPainter7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo9);
        java.awt.geom.GeneralPath generalPath11 = null;
        state10.seriesPath = generalPath11;
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState13 = state10.getCrosshairState();
        boolean boolean14 = gradientBarPainter7.equals((java.lang.Object) state10);
        org.junit.Assert.assertNull(xYCrosshairState13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesStroke(false);
        barRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray8 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray8);
        org.jfree.data.Range range10 = barRenderer5.findRangeBounds(categoryDataset9);
        org.jfree.data.Range range11 = barRenderer0.findRangeBounds(categoryDataset9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection17, valueAxis18, polarItemRenderer19);
        polarPlot20.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = polarPlot20.getOrientation();
        combinedRangeXYPlot15.setOrientation(plotOrientation23);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer25 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean26 = xYLineAndShapeRenderer25.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer25.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke30 = xYLineAndShapeRenderer25.getBaseOutlineStroke();
        java.awt.Stroke stroke32 = xYLineAndShapeRenderer25.lookupSeriesStroke(4);
        combinedRangeXYPlot15.setDomainCrosshairStroke(stroke32);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        numberAxis34.setFixedAutoRange((double) 9);
        combinedRangeXYPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis34);
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis34.setLeftArrow(shape39);
        java.text.NumberFormat numberFormat41 = java.text.NumberFormat.getNumberInstance();
        boolean boolean42 = numberFormat41.isParseIntegerOnly();
        numberAxis34.setNumberFormatOverride(numberFormat41);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis34, categoryItemRenderer44);
        java.awt.Paint paint46 = categoryPlot45.getDomainGridlinePaint();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer47 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean48 = xYLineAndShapeRenderer47.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer47.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke52 = xYLineAndShapeRenderer47.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D53 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot54 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath55 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor56 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo57 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean58 = textBlockAnchor56.equals((java.lang.Object) chartRenderingInfo57);
        java.awt.geom.Rectangle2D rectangle2D59 = chartRenderingInfo57.getChartArea();
        org.jfree.chart.RenderingSource renderingSource60 = null;
        combinedRangeXYPlot54.select(generalPath55, rectangle2D59, renderingSource60);
        org.jfree.chart.plot.XYPlot xYPlot62 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset63 = new org.jfree.data.xy.DefaultXYDataset();
        int int65 = defaultXYDataset63.indexOf((java.lang.Comparable) 0.5f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo66 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState67 = xYLineAndShapeRenderer47.initialise(graphics2D53, rectangle2D59, xYPlot62, (org.jfree.data.xy.XYDataset) defaultXYDataset63, plotRenderingInfo66);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D68 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Shape shape69 = numberAxis3D68.getDownArrow();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer70 = null;
        org.jfree.chart.plot.PolarPlot polarPlot71 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) defaultXYDataset63, (org.jfree.chart.axis.ValueAxis) numberAxis3D68, polarItemRenderer70);
        org.jfree.chart.axis.NumberAxis numberAxis72 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean73 = numberAxis72.isVisible();
        numberAxis72.setAutoRangeStickyZero(false);
        org.jfree.data.Range range76 = numberAxis72.getDefaultAutoRange();
        numberAxis3D68.setDefaultAutoRange(range76);
        categoryPlot45.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D68);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(numberFormat41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(textBlockAnchor56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(rectangle2D59);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1) + "'", int65 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState67);
        org.junit.Assert.assertNotNull(shape69);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + true + "'", boolean73 == true);
        org.junit.Assert.assertNotNull(range76);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("TextBlockAnchor.BOTTOM_LEFT", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (-1), range1);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType3 = rectangleConstraint2.getWidthConstraintType();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = rectangleConstraint2.getHeightConstraintType();
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange();
        boolean boolean7 = dateRange5.contains((double) 0);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint2.toRangeWidth((org.jfree.data.Range) dateRange5);
        org.junit.Assert.assertNotNull(lengthConstraintType3);
        org.junit.Assert.assertNotNull(lengthConstraintType4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) 1.0d);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot2 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone3 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection4 = new org.jfree.data.time.TimeSeriesCollection(timeZone3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer6 = null;
        org.jfree.chart.plot.PolarPlot polarPlot7 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection4, valueAxis5, polarItemRenderer6);
        polarPlot7.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = polarPlot7.getOrientation();
        combinedRangeXYPlot2.setOrientation(plotOrientation10);
        combinedRangeXYPlot2.setRangeCrosshairValue(0.0d);
        boolean boolean14 = combinedRangeXYPlot2.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisSpace axisSpace15 = new org.jfree.chart.axis.AxisSpace();
        combinedRangeXYPlot2.setFixedRangeAxisSpace(axisSpace15);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent18 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) 1.0d);
        combinedRangeXYPlot2.rendererChanged(rendererChangeEvent18);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType20 = rendererChangeEvent18.getType();
        java.lang.String str21 = chartChangeEventType20.toString();
        rendererChangeEvent1.setType(chartChangeEventType20);
        java.lang.String str23 = rendererChangeEvent1.toString();
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str21.equals("ChartChangeEventType.GENERAL"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.jfree.chart.event.RendererChangeEvent[source=1.0]" + "'", str23.equals("org.jfree.chart.event.RendererChangeEvent[source=1.0]"));
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) waferMapPlot2);
        java.awt.Font font4 = legendTitle3.getItemFont();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("DateTickUnitType.SECOND", font4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Font font8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer6.setLegendTextFont((int) '#', font8);
        textTitle5.setFont(font8);
        java.awt.Paint paint11 = textTitle5.getPaint();
        java.lang.String str12 = textTitle5.getText();
        textTitle5.setURLText("12/31/69 4:00 PM");
        java.lang.String str15 = textTitle5.getURLText();
        boolean boolean16 = rectangleAnchor0.equals((java.lang.Object) textTitle5);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DateTickUnitType.SECOND" + "'", str12.equals("DateTickUnitType.SECOND"));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "12/31/69 4:00 PM" + "'", str15.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape5, (java.awt.Paint) color6);
        java.awt.Font font8 = legendItem7.getLabelFont();
        org.jfree.data.general.Dataset dataset9 = null;
        legendItem7.setDataset(dataset9);
        legendItem7.setDescription("DateTickUnitType.SECOND");
        java.awt.Paint paint13 = legendItem7.getFillPaint();
        java.awt.Paint paint14 = null;
        legendItem7.setLabelPaint(paint14);
        legendItem7.setDescription("DateTickUnit[DateTickUnitType.YEAR, 100]");
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(font8);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("EXPAND");
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = org.jfree.chart.axis.DateTickMarkPosition.END;
        dateAxis1.setTickMarkPosition(dateTickMarkPosition3);
        boolean boolean6 = dateAxis1.isHiddenValue(100L);
        dateAxis1.setAxisLineVisible(true);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("hi!", "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]", "hi!", "item");
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setStartAngle(1.0d);
        java.awt.Image image4 = null;
        piePlot1.setBackgroundImage(image4);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator6 = piePlot1.getLegendLabelGenerator();
        java.awt.Paint paint7 = piePlot1.getBaseSectionPaint();
        java.awt.Paint paint8 = piePlot1.getLabelPaint();
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean2 = xYLineAndShapeRenderer1.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer1.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYLineAndShapeRenderer1.getNegativeItemLabelPosition(1, (int) (short) 10, true);
        boolean boolean10 = xYLineAndShapeRenderer1.getAutoPopulateSeriesShape();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection12 = new org.jfree.data.time.TimeSeriesCollection(timeZone11);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection12, valueAxis13, polarItemRenderer14);
        java.awt.Paint paint16 = polarPlot15.getAngleLabelPaint();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean18 = xYLineAndShapeRenderer17.getAutoPopulateSeriesOutlinePaint();
        java.awt.Font font19 = xYLineAndShapeRenderer17.getBaseItemLabelFont();
        polarPlot15.setAngleLabelFont(font19);
        xYLineAndShapeRenderer1.setBaseLegendTextFont(font19);
        java.awt.Stroke stroke25 = xYLineAndShapeRenderer1.getItemOutlineStroke(0, (-1), false);
        xYLineAndShapeRenderer1.setAutoPopulateSeriesFillPaint(false);
        boolean boolean28 = axisSpace0.equals((java.lang.Object) xYLineAndShapeRenderer1);
        axisSpace0.setBottom((double) 0.8f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode(2958465);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str1 = basicProjectInfo0.getLicenceName();
        org.jfree.chart.ui.Library[] libraryArray2 = basicProjectInfo0.getOptionalLibraries();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(libraryArray2);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getDrawOutlines();
        java.awt.Shape shape2 = xYLineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0);
        int int5 = xYAreaRenderer4.getDefaultEntityRadius();
        xYAreaRenderer4.setSeriesItemLabelsVisible((int) (short) 100, false);
        java.awt.Shape shape9 = xYAreaRenderer4.getBaseShape();
        boolean boolean13 = xYAreaRenderer4.getItemCreateEntity(2, (int) (byte) 10, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator14 = xYAreaRenderer4.getLegendItemLabelGenerator();
        xYLineAndShapeRenderer0.setLegendItemLabelGenerator(xYSeriesLabelGenerator14);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(xYSeriesLabelGenerator14);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true);
        xYSeries2.fireSeriesChanged();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries2);
        boolean boolean5 = xYSeriesCollection4.isAutoWidth();
        org.jfree.data.xy.XYSeries xYSeries8 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true);
        xYSeries8.fireSeriesChanged();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection10 = new org.jfree.data.xy.XYSeriesCollection(xYSeries8);
        xYSeriesCollection4.removeSeries(xYSeries8);
        xYSeries8.add((double) (byte) 1, (java.lang.Number) (-1L), true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape2 = null;
        xYLineAndShapeRenderer0.setBaseLegendShape(shape2);
        xYLineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, false);
        xYLineAndShapeRenderer0.setSeriesCreateEntities((int) (short) 0, (java.lang.Boolean) true);
        java.lang.Object obj11 = xYLineAndShapeRenderer0.clone();
        java.awt.Paint paint12 = xYLineAndShapeRenderer0.getBasePaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        polarPlot5.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = polarPlot5.getOrientation();
        combinedRangeXYPlot0.setOrientation(plotOrientation8);
        combinedRangeXYPlot0.setRangeCrosshairValue(0.0d);
        boolean boolean12 = combinedRangeXYPlot0.isDomainCrosshairVisible();
        combinedRangeXYPlot0.setDomainCrosshairValue((double) 1.0f);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder15 = combinedRangeXYPlot0.getDatasetRenderingOrder();
        java.awt.Stroke stroke16 = combinedRangeXYPlot0.getRangeMinorGridlineStroke();
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder15);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer1.setAutoPopulateSeriesStroke(false);
        barRenderer1.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray9);
        org.jfree.data.Range range11 = barRenderer6.findRangeBounds(categoryDataset10);
        org.jfree.data.Range range12 = barRenderer1.findRangeBounds(categoryDataset10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis13.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection18 = new org.jfree.data.time.TimeSeriesCollection(timeZone17);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer20 = null;
        org.jfree.chart.plot.PolarPlot polarPlot21 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection18, valueAxis19, polarItemRenderer20);
        polarPlot21.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = polarPlot21.getOrientation();
        combinedRangeXYPlot16.setOrientation(plotOrientation24);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer26 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean27 = xYLineAndShapeRenderer26.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer26.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke31 = xYLineAndShapeRenderer26.getBaseOutlineStroke();
        java.awt.Stroke stroke33 = xYLineAndShapeRenderer26.lookupSeriesStroke(4);
        combinedRangeXYPlot16.setDomainCrosshairStroke(stroke33);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis();
        numberAxis35.setFixedAutoRange((double) 9);
        combinedRangeXYPlot16.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis35);
        java.awt.Shape shape40 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis35.setLeftArrow(shape40);
        java.text.NumberFormat numberFormat42 = java.text.NumberFormat.getNumberInstance();
        boolean boolean43 = numberFormat42.isParseIntegerOnly();
        numberAxis35.setNumberFormatOverride(numberFormat42);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis35, categoryItemRenderer45);
        categoryPlot46.clearDomainMarkers();
        boolean boolean48 = categoryPlot46.isRangePannable();
        java.awt.Paint paint49 = categoryPlot46.getRangeMinorGridlinePaint();
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart("ERROR : Relative To String", (org.jfree.chart.plot.Plot) categoryPlot46);
        org.jfree.chart.event.ChartProgressListener chartProgressListener51 = null;
        jFreeChart50.removeProgressListener(chartProgressListener51);
        org.jfree.chart.event.ChartProgressListener chartProgressListener53 = null;
        jFreeChart50.addProgressListener(chartProgressListener53);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(plotOrientation24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(numberFormat42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(paint49);
    }
}

