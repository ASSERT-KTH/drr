import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer((-1.0d));
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getShadowsVisible();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator2, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator5, true);
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.util.TimeZone timeZone9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeZone9);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor11 = timeSeriesCollection10.getXPosition();
        boolean boolean12 = textAnchor8.equals((java.lang.Object) timeSeriesCollection10);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection10);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent14 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) true, (org.jfree.data.general.Dataset) timeSeriesCollection10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(timePeriodAnchor11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(range13);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer1.setAutoPopulateSeriesStroke(false);
        barRenderer1.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray9);
        org.jfree.data.Range range11 = barRenderer6.findRangeBounds(categoryDataset10);
        org.jfree.data.Range range12 = barRenderer1.findRangeBounds(categoryDataset10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis13.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection18 = new org.jfree.data.time.TimeSeriesCollection(timeZone17);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer20 = null;
        org.jfree.chart.plot.PolarPlot polarPlot21 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection18, valueAxis19, polarItemRenderer20);
        polarPlot21.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = polarPlot21.getOrientation();
        combinedRangeXYPlot16.setOrientation(plotOrientation24);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer26 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean27 = xYLineAndShapeRenderer26.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer26.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke31 = xYLineAndShapeRenderer26.getBaseOutlineStroke();
        java.awt.Stroke stroke33 = xYLineAndShapeRenderer26.lookupSeriesStroke(4);
        combinedRangeXYPlot16.setDomainCrosshairStroke(stroke33);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis();
        numberAxis35.setFixedAutoRange((double) 9);
        combinedRangeXYPlot16.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis35);
        java.awt.Shape shape40 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis35.setLeftArrow(shape40);
        java.text.NumberFormat numberFormat42 = java.text.NumberFormat.getNumberInstance();
        boolean boolean43 = numberFormat42.isParseIntegerOnly();
        numberAxis35.setNumberFormatOverride(numberFormat42);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis35, categoryItemRenderer45);
        categoryPlot46.clearDomainMarkers();
        boolean boolean48 = categoryPlot46.isRangePannable();
        java.awt.Paint paint49 = categoryPlot46.getRangeMinorGridlinePaint();
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart("ERROR : Relative To String", (org.jfree.chart.plot.Plot) categoryPlot46);
        jFreeChart50.fireChartChanged();
        org.jfree.chart.title.TextTitle textTitle52 = jFreeChart50.getTitle();
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(plotOrientation24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(numberFormat42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(textTitle52);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.CUBIC_CURVE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("index.html");
        boolean boolean3 = pieLabelLinkStyle0.equals((java.lang.Object) categoryAxis3D2);
        float float4 = categoryAxis3D2.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        java.awt.Font font2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font2);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection6, valueAxis7, polarItemRenderer8);
        polarPlot9.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = polarPlot9.getOrientation();
        combinedRangeXYPlot4.setOrientation(plotOrientation12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        combinedRangeXYPlot4.setDomainCrosshairPaint((java.awt.Paint) color14);
        java.awt.Paint paint16 = combinedRangeXYPlot4.getDomainCrosshairPaint();
        org.jfree.chart.text.TextBlock textBlock17 = org.jfree.chart.text.TextUtilities.createTextBlock("DateTickUnitType.SECOND", font2, paint16);
        java.awt.Graphics2D graphics2D18 = null;
        try {
            org.jfree.chart.util.Size2D size2D19 = textBlock17.calculateDimensions(graphics2D18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(textBlock17);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        boolean boolean4 = textAnchor2.equals((java.lang.Object) (byte) 0);
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        boolean boolean7 = textAnchor5.equals((java.lang.Object) (byte) 0);
        org.jfree.chart.axis.NumberTick numberTick9 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (-4145152), "ERROR : Relative To String", textAnchor2, textAnchor5, (double) (short) 0);
        org.jfree.chart.text.TextAnchor textAnchor10 = numberTick9.getRotationAnchor();
        double double11 = numberTick9.getAngle();
        java.util.TimeZone timeZone12 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection13 = new org.jfree.data.time.TimeSeriesCollection(timeZone12);
        double double15 = timeSeriesCollection13.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer18 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean19 = xYLineAndShapeRenderer18.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer18.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke23 = xYLineAndShapeRenderer18.getBaseOutlineStroke();
        java.awt.Stroke stroke25 = xYLineAndShapeRenderer18.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection13, valueAxis16, valueAxis17, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer18);
        org.jfree.chart.block.LineBorder lineBorder28 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint29 = lineBorder28.getPaint();
        xYLineAndShapeRenderer18.setSeriesItemLabelPaint((int) (short) 0, paint29, false);
        boolean boolean32 = numberTick9.equals((java.lang.Object) xYLineAndShapeRenderer18);
        xYLineAndShapeRenderer18.removeAnnotations();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        polarPlot5.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = polarPlot5.getOrientation();
        combinedRangeXYPlot0.setOrientation(plotOrientation8);
        combinedRangeXYPlot0.setRangeCrosshairValue(0.0d);
        boolean boolean12 = combinedRangeXYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisSpace axisSpace13 = new org.jfree.chart.axis.AxisSpace();
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace13);
        java.awt.Shape shape19 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.general.PieDataset pieDataset20 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity26 = new org.jfree.chart.entity.PieSectionEntity(shape19, pieDataset20, 1, (int) (short) -1, (java.lang.Comparable) 3, "hi!", "index.html");
        org.jfree.data.general.PieDataset pieDataset27 = null;
        org.jfree.chart.plot.PiePlot piePlot28 = new org.jfree.chart.plot.PiePlot(pieDataset27);
        piePlot28.setStartAngle(1.0d);
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color37 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem38 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape36, (java.awt.Paint) color37);
        piePlot28.setLabelLinkPaint((java.awt.Paint) color37);
        org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("", "TimePeriodAnchor.START", "TimePeriodAnchor.START", "DateTickUnitType.SECOND", shape19, (java.awt.Paint) color37);
        combinedRangeXYPlot0.setOutlinePaint((java.awt.Paint) color37);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(color37);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator1 = xYBarRenderer0.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset2 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range3 = xYBarRenderer0.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset2);
        double double4 = xYBarRenderer0.getShadowXOffset();
        java.awt.Paint paint6 = null;
        xYBarRenderer0.setSeriesPaint((int) ' ', paint6);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean9 = xYLineAndShapeRenderer8.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer8.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke13 = xYLineAndShapeRenderer8.getBaseOutlineStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = xYLineAndShapeRenderer8.getBasePositiveItemLabelPosition();
        java.awt.Shape shape15 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.general.PieDataset pieDataset16 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity22 = new org.jfree.chart.entity.PieSectionEntity(shape15, pieDataset16, 1, (int) (short) -1, (java.lang.Comparable) 3, "hi!", "index.html");
        xYLineAndShapeRenderer8.setBaseShape(shape15, true);
        xYBarRenderer0.setLegendBar(shape15);
        org.junit.Assert.assertNull(xYItemLabelGenerator1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(shape15);
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setStartAngle(1.0d);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape9, (java.awt.Paint) color10);
        piePlot1.setLabelLinkPaint((java.awt.Paint) color10);
        java.awt.Paint paint13 = piePlot1.getBaseSectionOutlinePaint();
        piePlot1.setIgnoreZeroValues(true);
        java.awt.Font font16 = piePlot1.getNoDataMessageFont();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator17 = null;
        piePlot1.setLegendLabelURLGenerator(pieURLGenerator17);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        java.awt.Shape shape4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity11 = new org.jfree.chart.entity.PieSectionEntity(shape4, pieDataset5, 1, (int) (short) -1, (java.lang.Comparable) 3, "hi!", "index.html");
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        piePlot13.setStartAngle(1.0d);
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape21, (java.awt.Paint) color22);
        piePlot13.setLabelLinkPaint((java.awt.Paint) color22);
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("", "TimePeriodAnchor.START", "TimePeriodAnchor.START", "DateTickUnitType.SECOND", shape4, (java.awt.Paint) color22);
        java.awt.Paint paint26 = legendItem25.getOutlinePaint();
        legendItem25.setShapeVisible(true);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean2 = xYLineAndShapeRenderer1.getAutoPopulateSeriesOutlinePaint();
        java.awt.Font font3 = xYLineAndShapeRenderer1.getBaseItemLabelFont();
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("TimePeriodAnchor.START", font3);
        java.awt.Paint paint5 = textFragment4.getPaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesStroke(false);
        barRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray8 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray8);
        org.jfree.data.Range range10 = barRenderer5.findRangeBounds(categoryDataset9);
        org.jfree.data.Range range11 = barRenderer0.findRangeBounds(categoryDataset9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection17, valueAxis18, polarItemRenderer19);
        polarPlot20.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = polarPlot20.getOrientation();
        combinedRangeXYPlot15.setOrientation(plotOrientation23);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer25 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean26 = xYLineAndShapeRenderer25.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer25.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke30 = xYLineAndShapeRenderer25.getBaseOutlineStroke();
        java.awt.Stroke stroke32 = xYLineAndShapeRenderer25.lookupSeriesStroke(4);
        combinedRangeXYPlot15.setDomainCrosshairStroke(stroke32);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        numberAxis34.setFixedAutoRange((double) 9);
        combinedRangeXYPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis34);
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis34.setLeftArrow(shape39);
        java.text.NumberFormat numberFormat41 = java.text.NumberFormat.getNumberInstance();
        boolean boolean42 = numberFormat41.isParseIntegerOnly();
        numberAxis34.setNumberFormatOverride(numberFormat41);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis34, categoryItemRenderer44);
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        categoryPlot45.setRangeAxis((int) (byte) 100, valueAxis47);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent49 = null;
        categoryPlot45.markerChanged(markerChangeEvent49);
        org.jfree.chart.axis.AxisSpace axisSpace51 = new org.jfree.chart.axis.AxisSpace();
        categoryPlot45.setFixedRangeAxisSpace(axisSpace51, false);
        java.awt.Graphics2D graphics2D54 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer55 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean56 = xYLineAndShapeRenderer55.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer55.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke60 = xYLineAndShapeRenderer55.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D61 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot62 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath63 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor64 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo65 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean66 = textBlockAnchor64.equals((java.lang.Object) chartRenderingInfo65);
        java.awt.geom.Rectangle2D rectangle2D67 = chartRenderingInfo65.getChartArea();
        org.jfree.chart.RenderingSource renderingSource68 = null;
        combinedRangeXYPlot62.select(generalPath63, rectangle2D67, renderingSource68);
        org.jfree.chart.plot.XYPlot xYPlot70 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset71 = new org.jfree.data.xy.DefaultXYDataset();
        int int73 = defaultXYDataset71.indexOf((java.lang.Comparable) 0.5f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo74 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState75 = xYLineAndShapeRenderer55.initialise(graphics2D61, rectangle2D67, xYPlot70, (org.jfree.data.xy.XYDataset) defaultXYDataset71, plotRenderingInfo74);
        try {
            categoryPlot45.drawBackground(graphics2D54, rectangle2D67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(numberFormat41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(textBlockAnchor64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(rectangle2D67);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState75);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 10, (double) 64, (double) 9, (double) 0);
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets4.getUnitType();
        org.junit.Assert.assertNotNull(unitType5);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) ' ');
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) (short) 100);
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange();
        java.util.Date date4 = dateRange3.getUpperDate();
        java.util.Date date5 = dateTickUnit2.rollDate(date4);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.setDomainZeroBaselineVisible(false);
        combinedRangeXYPlot6.setDomainGridlinesVisible(false);
        org.jfree.data.xy.XYDataset xYDataset11 = combinedRangeXYPlot6.getDataset();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot13.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean17 = xYLineAndShapeRenderer16.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer16.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke21 = xYLineAndShapeRenderer16.getBaseOutlineStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = xYLineAndShapeRenderer16.getBasePositiveItemLabelPosition();
        java.awt.Shape shape23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity30 = new org.jfree.chart.entity.PieSectionEntity(shape23, pieDataset24, 1, (int) (short) -1, (java.lang.Comparable) 3, "hi!", "index.html");
        xYLineAndShapeRenderer16.setBaseShape(shape23, true);
        int int33 = combinedRangeXYPlot13.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer16);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("EXPAND");
        combinedRangeXYPlot13.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis35);
        boolean boolean37 = dateAxis35.isTickMarksVisible();
        combinedRangeXYPlot6.setRangeAxis(64, (org.jfree.chart.axis.ValueAxis) dateAxis35, false);
        java.util.TimeZone timeZone40 = dateAxis35.getTimeZone();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date4, timeZone40);
        java.util.Calendar calendar42 = null;
        try {
            day41.peg(calendar42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(xYDataset11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(timeZone40);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesStroke(false);
        barRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray8 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray8);
        org.jfree.data.Range range10 = barRenderer5.findRangeBounds(categoryDataset9);
        org.jfree.data.Range range11 = barRenderer0.findRangeBounds(categoryDataset9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection17, valueAxis18, polarItemRenderer19);
        polarPlot20.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = polarPlot20.getOrientation();
        combinedRangeXYPlot15.setOrientation(plotOrientation23);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer25 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean26 = xYLineAndShapeRenderer25.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer25.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke30 = xYLineAndShapeRenderer25.getBaseOutlineStroke();
        java.awt.Stroke stroke32 = xYLineAndShapeRenderer25.lookupSeriesStroke(4);
        combinedRangeXYPlot15.setDomainCrosshairStroke(stroke32);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        numberAxis34.setFixedAutoRange((double) 9);
        combinedRangeXYPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis34);
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis34.setLeftArrow(shape39);
        java.text.NumberFormat numberFormat41 = java.text.NumberFormat.getNumberInstance();
        boolean boolean42 = numberFormat41.isParseIntegerOnly();
        numberAxis34.setNumberFormatOverride(numberFormat41);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis34, categoryItemRenderer44);
        categoryPlot45.clearDomainMarkers();
        int int47 = categoryPlot45.getCrosshairDatasetIndex();
        categoryPlot45.configureDomainAxes();
        categoryPlot45.zoom((double) 0.0f);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(numberFormat41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesStroke(false);
        barRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray8 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray8);
        org.jfree.data.Range range10 = barRenderer5.findRangeBounds(categoryDataset9);
        org.jfree.data.Range range11 = barRenderer0.findRangeBounds(categoryDataset9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection17, valueAxis18, polarItemRenderer19);
        polarPlot20.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = polarPlot20.getOrientation();
        combinedRangeXYPlot15.setOrientation(plotOrientation23);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer25 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean26 = xYLineAndShapeRenderer25.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer25.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke30 = xYLineAndShapeRenderer25.getBaseOutlineStroke();
        java.awt.Stroke stroke32 = xYLineAndShapeRenderer25.lookupSeriesStroke(4);
        combinedRangeXYPlot15.setDomainCrosshairStroke(stroke32);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        numberAxis34.setFixedAutoRange((double) 9);
        combinedRangeXYPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis34);
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis34.setLeftArrow(shape39);
        java.text.NumberFormat numberFormat41 = java.text.NumberFormat.getNumberInstance();
        boolean boolean42 = numberFormat41.isParseIntegerOnly();
        numberAxis34.setNumberFormatOverride(numberFormat41);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis34, categoryItemRenderer44);
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        categoryPlot45.setRangeAxis((int) (byte) 100, valueAxis47);
        java.lang.Comparable comparable49 = categoryPlot45.getDomainCrosshairRowKey();
        categoryPlot45.setRangeGridlinesVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset52 = categoryPlot45.getDataset();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(numberFormat41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(comparable49);
        org.junit.Assert.assertNotNull(categoryDataset52);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer1.setAutoPopulateSeriesStroke(false);
        barRenderer1.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray9 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset10 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray9);
        org.jfree.data.Range range11 = barRenderer6.findRangeBounds(categoryDataset10);
        org.jfree.data.Range range12 = barRenderer1.findRangeBounds(categoryDataset10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis13.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection18 = new org.jfree.data.time.TimeSeriesCollection(timeZone17);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer20 = null;
        org.jfree.chart.plot.PolarPlot polarPlot21 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection18, valueAxis19, polarItemRenderer20);
        polarPlot21.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = polarPlot21.getOrientation();
        combinedRangeXYPlot16.setOrientation(plotOrientation24);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer26 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean27 = xYLineAndShapeRenderer26.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer26.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke31 = xYLineAndShapeRenderer26.getBaseOutlineStroke();
        java.awt.Stroke stroke33 = xYLineAndShapeRenderer26.lookupSeriesStroke(4);
        combinedRangeXYPlot16.setDomainCrosshairStroke(stroke33);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis();
        numberAxis35.setFixedAutoRange((double) 9);
        combinedRangeXYPlot16.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis35);
        java.awt.Shape shape40 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis35.setLeftArrow(shape40);
        java.text.NumberFormat numberFormat42 = java.text.NumberFormat.getNumberInstance();
        boolean boolean43 = numberFormat42.isParseIntegerOnly();
        numberAxis35.setNumberFormatOverride(numberFormat42);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis35, categoryItemRenderer45);
        categoryPlot46.clearDomainMarkers();
        boolean boolean48 = categoryPlot46.isRangePannable();
        java.awt.Paint paint49 = categoryPlot46.getRangeMinorGridlinePaint();
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart("ERROR : Relative To String", (org.jfree.chart.plot.Plot) categoryPlot46);
        java.awt.Paint paint51 = jFreeChart50.getBackgroundPaint();
        jFreeChart50.setBackgroundImageAlignment(9999);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(categoryDataset10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(plotOrientation24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(numberFormat42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(paint51);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, (double) (short) 10);
        boolean boolean6 = columnArrangement4.equals((java.lang.Object) "index.html");
        org.jfree.data.general.PieDataset pieDataset7 = null;
        org.jfree.chart.plot.PiePlot piePlot8 = new org.jfree.chart.plot.PiePlot(pieDataset7);
        piePlot8.setStartAngle(1.0d);
        java.awt.Image image11 = null;
        piePlot8.setBackgroundImage(image11);
        double double13 = piePlot8.getMaximumLabelWidth();
        boolean boolean14 = columnArrangement4.equals((java.lang.Object) double13);
        org.jfree.chart.block.BlockContainer blockContainer15 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.14d + "'", double13 == 0.14d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.isVisible();
        numberAxis0.setAutoRangeStickyZero(false);
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot((org.jfree.chart.axis.ValueAxis) numberAxis0);
        combinedDomainXYPlot4.setGap((double) 8);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesStroke(false);
        barRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray8 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray8);
        org.jfree.data.Range range10 = barRenderer5.findRangeBounds(categoryDataset9);
        org.jfree.data.Range range11 = barRenderer0.findRangeBounds(categoryDataset9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection17, valueAxis18, polarItemRenderer19);
        polarPlot20.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = polarPlot20.getOrientation();
        combinedRangeXYPlot15.setOrientation(plotOrientation23);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer25 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean26 = xYLineAndShapeRenderer25.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer25.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke30 = xYLineAndShapeRenderer25.getBaseOutlineStroke();
        java.awt.Stroke stroke32 = xYLineAndShapeRenderer25.lookupSeriesStroke(4);
        combinedRangeXYPlot15.setDomainCrosshairStroke(stroke32);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        numberAxis34.setFixedAutoRange((double) 9);
        combinedRangeXYPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis34);
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis34.setLeftArrow(shape39);
        java.text.NumberFormat numberFormat41 = java.text.NumberFormat.getNumberInstance();
        boolean boolean42 = numberFormat41.isParseIntegerOnly();
        numberAxis34.setNumberFormatOverride(numberFormat41);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis34, categoryItemRenderer44);
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        categoryPlot45.setRangeAxis((int) (byte) 100, valueAxis47);
        java.lang.Comparable comparable49 = categoryPlot45.getDomainCrosshairRowKey();
        categoryPlot45.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.IntervalMarker intervalMarker54 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 1.0f);
        java.awt.Paint paint55 = intervalMarker54.getOutlinePaint();
        java.awt.Stroke stroke56 = intervalMarker54.getOutlineStroke();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer57 = null;
        intervalMarker54.setGradientPaintTransformer(gradientPaintTransformer57);
        float float59 = intervalMarker54.getAlpha();
        categoryPlot45.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker54);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation61 = null;
        try {
            categoryPlot45.addAnnotation(categoryAnnotation61);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(numberFormat41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(comparable49);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertTrue("'" + float59 + "' != '" + 0.8f + "'", float59 == 0.8f);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("RangeType.FULL");
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test27");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true);
        xYSeries2.fireSeriesChanged();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries2);
        xYSeries2.setMaximumItemCount((int) ' ');
        xYSeries2.add((java.lang.Number) 9999, (java.lang.Number) 10, true);
        boolean boolean11 = xYSeries2.getNotify();
        try {
            xYSeries2.update((java.lang.Number) 3600000L, (java.lang.Number) (-4L));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: No observation for x = 3600000");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 7, (int) (short) 100, (int) (short) 1);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis("EXPAND");
        java.text.DateFormat dateFormat6 = dateAxis5.getDateFormatOverride();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType7 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType7, (int) (short) 100);
        java.lang.String str10 = dateTickUnit9.toString();
        java.util.Date date11 = dateAxis5.calculateHighestVisibleTickValue(dateTickUnit9);
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType12 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit14 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType12, (int) (short) 100);
        java.util.Date date15 = dateAxis5.calculateHighestVisibleTickValue(dateTickUnit14);
        segmentedTimeline3.addException(date15);
        org.junit.Assert.assertNull(dateFormat6);
        org.junit.Assert.assertNotNull(dateTickUnitType7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "DateTickUnit[DateTickUnitType.YEAR, 100]" + "'", str10.equals("DateTickUnit[DateTickUnitType.YEAR, 100]"));
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(dateTickUnitType12);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(9999);
        boolean boolean4 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate3);
        java.lang.String str5 = spreadsheetDate1.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "17-May-1927" + "'", str5.equals("17-May-1927"));
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test30");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        int int2 = piePlot1.getPieIndex();
        double double3 = piePlot1.getMaximumLabelWidth();
        piePlot1.setMaximumLabelWidth((double) (byte) 0);
        piePlot1.setInteriorGap(0.0d);
        java.lang.Object obj8 = piePlot1.clone();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator9 = piePlot1.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.14d + "'", double3 == 0.14d);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNull(pieSectionLabelGenerator9);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType1 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType1, (int) (short) 100);
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange();
        java.util.Date date5 = dateRange4.getUpperDate();
        java.util.Date date6 = dateTickUnit3.rollDate(date5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("12/31/69 4:00 PM", (org.jfree.data.time.RegularTimePeriod) year7, (org.jfree.data.time.RegularTimePeriod) month8);
        java.awt.Shape shape10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity17 = new org.jfree.chart.entity.PieSectionEntity(shape10, pieDataset11, 1, (int) (short) -1, (java.lang.Comparable) 3, "hi!", "index.html");
        pieSectionEntity17.setToolTipText("index.html");
        java.lang.Comparable comparable20 = pieSectionEntity17.getSectionKey();
        int int21 = year7.compareTo((java.lang.Object) comparable20);
        org.junit.Assert.assertNotNull(dateTickUnitType1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + 3 + "'", comparable20.equals(3));
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 1.0f);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        intervalMarker2.setLabelAnchor(rectangleAnchor3);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor5 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        boolean boolean11 = textAnchor9.equals((java.lang.Object) (byte) 0);
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        boolean boolean14 = textAnchor12.equals((java.lang.Object) (byte) 0);
        org.jfree.chart.axis.NumberTick numberTick16 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (-4145152), "ERROR : Relative To String", textAnchor9, textAnchor12, (double) (short) 0);
        org.jfree.chart.text.TextAnchor textAnchor17 = numberTick16.getRotationAnchor();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor5, textAnchor6, textAnchor17, (double) (byte) 1);
        intervalMarker2.setLabelTextAnchor(textAnchor17);
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNotNull(itemLabelAnchor5);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(textAnchor17);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test33");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true);
        xYSeries2.fireSeriesChanged();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries2);
        int int5 = xYSeriesCollection4.getSeriesCount();
        xYSeriesCollection4.setAutoWidth(false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test34");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke5 = xYLineAndShapeRenderer0.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath8 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean11 = textBlockAnchor9.equals((java.lang.Object) chartRenderingInfo10);
        java.awt.geom.Rectangle2D rectangle2D12 = chartRenderingInfo10.getChartArea();
        org.jfree.chart.RenderingSource renderingSource13 = null;
        combinedRangeXYPlot7.select(generalPath8, rectangle2D12, renderingSource13);
        org.jfree.chart.plot.XYPlot xYPlot15 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset16 = new org.jfree.data.xy.DefaultXYDataset();
        int int18 = defaultXYDataset16.indexOf((java.lang.Comparable) 0.5f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState20 = xYLineAndShapeRenderer0.initialise(graphics2D6, rectangle2D12, xYPlot15, (org.jfree.data.xy.XYDataset) defaultXYDataset16, plotRenderingInfo19);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate22 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) defaultXYDataset16, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState20);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test35");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator1 = xYBarRenderer0.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset2 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range3 = xYBarRenderer0.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset2);
        double double4 = xYBarRenderer0.getShadowXOffset();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean6 = xYLineAndShapeRenderer5.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer5.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke10 = xYLineAndShapeRenderer5.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath13 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean16 = textBlockAnchor14.equals((java.lang.Object) chartRenderingInfo15);
        java.awt.geom.Rectangle2D rectangle2D17 = chartRenderingInfo15.getChartArea();
        org.jfree.chart.RenderingSource renderingSource18 = null;
        combinedRangeXYPlot12.select(generalPath13, rectangle2D17, renderingSource18);
        org.jfree.chart.plot.XYPlot xYPlot20 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset21 = new org.jfree.data.xy.DefaultXYDataset();
        int int23 = defaultXYDataset21.indexOf((java.lang.Comparable) 0.5f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState25 = xYLineAndShapeRenderer5.initialise(graphics2D11, rectangle2D17, xYPlot20, (org.jfree.data.xy.XYDataset) defaultXYDataset21, plotRenderingInfo24);
        org.jfree.data.Range range26 = xYBarRenderer0.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset21);
        java.awt.Paint paint28 = null;
        xYBarRenderer0.setSeriesPaint(0, paint28);
        double double30 = xYBarRenderer0.getShadowXOffset();
        org.junit.Assert.assertNull(xYItemLabelGenerator1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(textBlockAnchor14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState25);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 4.0d + "'", double30 == 4.0d);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test36");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.setDomainZeroBaselineVisible(false);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean7 = combinedRangeXYPlot0.removeDomainMarker((int) (short) 0, marker4, layer5, false);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation9 = axisLocation8.getOpposite();
        combinedRangeXYPlot0.setDomainAxisLocation(axisLocation9, false);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("EXPAND");
        java.text.DateFormat dateFormat15 = dateAxis14.getDateFormatOverride();
        java.util.Date date16 = dateAxis14.getMaximumDate();
        combinedRangeXYPlot0.setDomainAxis(15, (org.jfree.chart.axis.ValueAxis) dateAxis14, false);
        java.awt.Font font20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape26, (java.awt.Paint) color27);
        int int29 = color27.getGreen();
        org.jfree.chart.text.TextLine textLine30 = new org.jfree.chart.text.TextLine("hi!", font20, (java.awt.Paint) color27);
        combinedRangeXYPlot0.setRangeMinorGridlinePaint((java.awt.Paint) color27);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNull(dateFormat15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 64 + "'", int29 == 64);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test37");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        xYLineAndShapeRenderer0.setAutoPopulateSeriesPaint(true);
        xYLineAndShapeRenderer0.setSeriesCreateEntities((int) (short) 100, (java.lang.Boolean) false, false);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator12 = null;
        xYLineAndShapeRenderer0.setSeriesItemLabelGenerator((int) (byte) 100, xYItemLabelGenerator12);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer15 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Font font17 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer15.setLegendTextFont((int) '#', font17);
        boolean boolean19 = xYLineAndShapeRenderer15.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = xYLineAndShapeRenderer15.getSeriesPositiveItemLabelPosition((int) '#');
        xYLineAndShapeRenderer0.setSeriesNegativeItemLabelPosition(9999, itemLabelPosition21, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test38");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape5, (java.awt.Paint) color6);
        java.awt.Font font8 = legendItem7.getLabelFont();
        org.jfree.data.general.Dataset dataset9 = null;
        legendItem7.setDataset(dataset9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_YELLOW;
        legendItem7.setOutlinePaint((java.awt.Paint) color11);
        legendItem7.setURLText("");
        java.awt.Stroke stroke15 = legendItem7.getOutlineStroke();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(font8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test39");
        java.lang.Object obj0 = null;
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.general.SeriesChangeEvent(obj0, seriesChangeInfo1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test40");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesStroke(false);
        barRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray8 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray8);
        org.jfree.data.Range range10 = barRenderer5.findRangeBounds(categoryDataset9);
        org.jfree.data.Range range11 = barRenderer0.findRangeBounds(categoryDataset9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection17, valueAxis18, polarItemRenderer19);
        polarPlot20.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = polarPlot20.getOrientation();
        combinedRangeXYPlot15.setOrientation(plotOrientation23);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer25 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean26 = xYLineAndShapeRenderer25.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer25.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke30 = xYLineAndShapeRenderer25.getBaseOutlineStroke();
        java.awt.Stroke stroke32 = xYLineAndShapeRenderer25.lookupSeriesStroke(4);
        combinedRangeXYPlot15.setDomainCrosshairStroke(stroke32);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        numberAxis34.setFixedAutoRange((double) 9);
        combinedRangeXYPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis34);
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis34.setLeftArrow(shape39);
        java.text.NumberFormat numberFormat41 = java.text.NumberFormat.getNumberInstance();
        boolean boolean42 = numberFormat41.isParseIntegerOnly();
        numberAxis34.setNumberFormatOverride(numberFormat41);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis34, categoryItemRenderer44);
        categoryPlot45.clearDomainMarkers();
        boolean boolean47 = categoryPlot45.isRangePannable();
        java.awt.Paint paint48 = categoryPlot45.getRangeMinorGridlinePaint();
        org.jfree.chart.plot.IntervalMarker intervalMarker51 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 1.0f);
        java.awt.Paint paint52 = intervalMarker51.getOutlinePaint();
        java.awt.Stroke stroke53 = intervalMarker51.getOutlineStroke();
        intervalMarker51.setEndValue((-1.0d));
        intervalMarker51.setEndValue((double) 1559372400000L);
        intervalMarker51.setLabel("null");
        boolean boolean60 = categoryPlot45.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker51);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(numberFormat41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test41");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MONTH;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test42");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 7, (int) (short) 100, (int) (short) 1);
        segmentedTimeline3.setAdjustForDaylightSaving(false);
        segmentedTimeline3.addException((long) (byte) 100);
        long long8 = segmentedTimeline3.getSegmentSize();
        long long9 = segmentedTimeline3.getSegmentsIncludedSize();
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 7L + "'", long8 == 7L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 700L + "'", long9 == 700L);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test43");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean2 = xYLineAndShapeRenderer1.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer1.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Paint paint6 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYLineAndShapeRenderer1.setBasePaint(paint6, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = xYLineAndShapeRenderer1.getPositiveItemLabelPosition(0, (int) (short) 1, false);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean15 = xYLineAndShapeRenderer14.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape16 = null;
        xYLineAndShapeRenderer14.setBaseLegendShape(shape16);
        xYLineAndShapeRenderer14.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, false);
        xYLineAndShapeRenderer14.setSeriesCreateEntities((int) (short) 0, (java.lang.Boolean) true);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator26 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYLineAndShapeRenderer14.setSeriesToolTipGenerator((int) '4', (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator26);
        xYLineAndShapeRenderer1.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator26, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer31 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator32 = xYBarRenderer31.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset33 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range34 = xYBarRenderer31.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset33);
        double double35 = xYBarRenderer31.getShadowXOffset();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator36 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer31.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator36, true);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator39 = new org.jfree.chart.urls.StandardXYURLGenerator();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer40 = new org.jfree.chart.renderer.xy.XYAreaRenderer(8, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator36, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator39);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer41 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) (byte) 10, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator26, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator39);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator26);
        org.junit.Assert.assertNull(xYItemLabelGenerator32);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 4.0d + "'", double35 == 4.0d);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator36);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test44");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getLowerClip();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test45");
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        java.awt.Paint paint6 = polarPlot5.getAngleLabelPaint();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean8 = xYLineAndShapeRenderer7.getAutoPopulateSeriesOutlinePaint();
        java.awt.Font font9 = xYLineAndShapeRenderer7.getBaseItemLabelFont();
        polarPlot5.setAngleLabelFont(font9);
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("TimePeriodAnchor.START", font9);
        labelBlock11.setURLText("DateTickUnit[DateTickUnitType.YEAR, 100]");
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test46");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = xYBarRenderer1.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset3 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range4 = xYBarRenderer1.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset3);
        double double5 = xYBarRenderer1.getShadowXOffset();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator6 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer1.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator6, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator11 = xYBarRenderer10.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset12 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range13 = xYBarRenderer10.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset12);
        double double14 = xYBarRenderer10.getShadowXOffset();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator15 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer10.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator15, true);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator18 = new org.jfree.chart.urls.StandardXYURLGenerator();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer19 = new org.jfree.chart.renderer.xy.XYAreaRenderer(8, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator15, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator18);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer20 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator6, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator18);
        java.lang.Object obj21 = xYStepAreaRenderer20.clone();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator22 = xYStepAreaRenderer20.getLegendItemToolTipGenerator();
        org.junit.Assert.assertNull(xYItemLabelGenerator2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator6);
        org.junit.Assert.assertNull(xYItemLabelGenerator11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator15);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator22);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test47");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test48");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesStroke(false);
        barRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray8 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray8);
        org.jfree.data.Range range10 = barRenderer5.findRangeBounds(categoryDataset9);
        org.jfree.data.Range range11 = barRenderer0.findRangeBounds(categoryDataset9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection17, valueAxis18, polarItemRenderer19);
        polarPlot20.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = polarPlot20.getOrientation();
        combinedRangeXYPlot15.setOrientation(plotOrientation23);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer25 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean26 = xYLineAndShapeRenderer25.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer25.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke30 = xYLineAndShapeRenderer25.getBaseOutlineStroke();
        java.awt.Stroke stroke32 = xYLineAndShapeRenderer25.lookupSeriesStroke(4);
        combinedRangeXYPlot15.setDomainCrosshairStroke(stroke32);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        numberAxis34.setFixedAutoRange((double) 9);
        combinedRangeXYPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis34);
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis34.setLeftArrow(shape39);
        java.text.NumberFormat numberFormat41 = java.text.NumberFormat.getNumberInstance();
        boolean boolean42 = numberFormat41.isParseIntegerOnly();
        numberAxis34.setNumberFormatOverride(numberFormat41);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis34, categoryItemRenderer44);
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        categoryPlot45.setRangeAxis((int) (byte) 100, valueAxis47);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent49 = null;
        categoryPlot45.markerChanged(markerChangeEvent49);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = categoryPlot45.getRenderer();
        java.awt.Paint paint52 = categoryPlot45.getRangeGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str54 = categoryAxis53.getLabelURL();
        java.awt.Font font56 = categoryAxis53.getTickLabelFont((java.lang.Comparable) (byte) 100);
        double double57 = categoryAxis53.getFixedDimension();
        boolean boolean58 = categoryAxis53.isAxisLineVisible();
        java.util.List list59 = categoryPlot45.getCategoriesForAxis(categoryAxis53);
        categoryAxis53.setLowerMargin((double) 7L);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(numberFormat41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(categoryItemRenderer51);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertNotNull(font56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(list59);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test49");
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState0 = new org.jfree.chart.plot.XYCrosshairState();
        java.awt.geom.Point2D point2D1 = null;
        xYCrosshairState0.setAnchor(point2D1);
        int int3 = xYCrosshairState0.getRangeAxisIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test50");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("TimePeriodAnchor.START", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test51");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setStartAngle(1.0d);
        org.jfree.chart.plot.IntervalMarker intervalMarker6 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 1.0f);
        java.awt.Paint paint7 = intervalMarker6.getOutlinePaint();
        java.awt.Stroke stroke8 = intervalMarker6.getOutlineStroke();
        piePlot1.setLabelOutlineStroke(stroke8);
        piePlot1.setLabelLinksVisible(false);
        piePlot1.setLabelGap(0.14d);
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.plot.PiePlot piePlot15 = new org.jfree.chart.plot.PiePlot(pieDataset14);
        piePlot15.setStartAngle(1.0d);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor18 = piePlot15.getLabelDistributor();
        piePlot1.setLabelDistributor(abstractPieLabelDistributor18);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor18);
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test52");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        int int2 = piePlot1.getPieIndex();
        boolean boolean4 = piePlot1.equals((java.lang.Object) "");
        double double5 = piePlot1.getInteriorGap();
        org.jfree.data.general.PieDataset pieDataset6 = null;
        org.jfree.chart.plot.PiePlot piePlot7 = new org.jfree.chart.plot.PiePlot(pieDataset6);
        piePlot7.setStartAngle(1.0d);
        java.awt.Image image10 = null;
        piePlot7.setBackgroundImage(image10);
        double double12 = piePlot7.getMaximumLabelWidth();
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle13 = piePlot7.getLabelLinkStyle();
        piePlot1.setLabelLinkStyle(pieLabelLinkStyle13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.08d + "'", double5 == 0.08d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.14d + "'", double12 == 0.14d);
        org.junit.Assert.assertNotNull(pieLabelLinkStyle13);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test53");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesStroke(false);
        barRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray8 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray8);
        org.jfree.data.Range range10 = barRenderer5.findRangeBounds(categoryDataset9);
        org.jfree.data.Range range11 = barRenderer0.findRangeBounds(categoryDataset9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection17, valueAxis18, polarItemRenderer19);
        polarPlot20.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = polarPlot20.getOrientation();
        combinedRangeXYPlot15.setOrientation(plotOrientation23);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer25 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean26 = xYLineAndShapeRenderer25.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer25.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke30 = xYLineAndShapeRenderer25.getBaseOutlineStroke();
        java.awt.Stroke stroke32 = xYLineAndShapeRenderer25.lookupSeriesStroke(4);
        combinedRangeXYPlot15.setDomainCrosshairStroke(stroke32);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        numberAxis34.setFixedAutoRange((double) 9);
        combinedRangeXYPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis34);
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis34.setLeftArrow(shape39);
        java.text.NumberFormat numberFormat41 = java.text.NumberFormat.getNumberInstance();
        boolean boolean42 = numberFormat41.isParseIntegerOnly();
        numberAxis34.setNumberFormatOverride(numberFormat41);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis34, categoryItemRenderer44);
        categoryPlot45.clearDomainMarkers();
        boolean boolean47 = categoryPlot45.isRangePannable();
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = categoryPlot45.getRangeAxisEdge();
        categoryPlot45.setCrosshairDatasetIndex(0, false);
        int int52 = categoryPlot45.getWeight();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(numberFormat41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test54");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean3 = xYLineAndShapeRenderer2.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer5.setAutoPopulateSeriesStroke(false);
        barRenderer5.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray13 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray13);
        org.jfree.data.Range range15 = barRenderer10.findRangeBounds(categoryDataset14);
        org.jfree.data.Range range16 = barRenderer5.findRangeBounds(categoryDataset14);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis17.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection22 = new org.jfree.data.time.TimeSeriesCollection(timeZone21);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer24 = null;
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection22, valueAxis23, polarItemRenderer24);
        polarPlot25.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation28 = polarPlot25.getOrientation();
        combinedRangeXYPlot20.setOrientation(plotOrientation28);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer30 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean31 = xYLineAndShapeRenderer30.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer30.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke35 = xYLineAndShapeRenderer30.getBaseOutlineStroke();
        java.awt.Stroke stroke37 = xYLineAndShapeRenderer30.lookupSeriesStroke(4);
        combinedRangeXYPlot20.setDomainCrosshairStroke(stroke37);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis();
        numberAxis39.setFixedAutoRange((double) 9);
        combinedRangeXYPlot20.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis39);
        java.awt.Shape shape44 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis39.setLeftArrow(shape44);
        java.text.NumberFormat numberFormat46 = java.text.NumberFormat.getNumberInstance();
        boolean boolean47 = numberFormat46.isParseIntegerOnly();
        numberAxis39.setNumberFormatOverride(numberFormat46);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis17, (org.jfree.chart.axis.ValueAxis) numberAxis39, categoryItemRenderer49);
        org.jfree.chart.axis.ValueAxis valueAxis52 = null;
        categoryPlot50.setRangeAxis((int) (byte) 100, valueAxis52);
        java.awt.Stroke stroke54 = categoryPlot50.getRangeCrosshairStroke();
        xYLineAndShapeRenderer2.setSeriesOutlineStroke(64, stroke54);
        periodAxis1.setMinorTickMarkStroke(stroke54);
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = periodAxis1.getLabelInsets();
        java.awt.Paint paint58 = periodAxis1.getMinorTickMarkPaint();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(categoryDataset14);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(plotOrientation28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(numberFormat46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertNotNull(paint58);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test55");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        java.lang.String str2 = textBlockAnchor1.toString();
        boolean boolean3 = paintList0.equals((java.lang.Object) str2);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextBlockAnchor.BOTTOM_LEFT" + "'", str2.equals("TextBlockAnchor.BOTTOM_LEFT"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test56");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState2 = timeSeriesCollection1.getSelectionState();
        java.util.List list3 = timeSeriesCollection1.getSeries();
        int int5 = timeSeriesCollection1.indexOf((java.lang.Comparable) 1.0f);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate7 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection1, true);
        double double9 = intervalXYDelegate7.getDomainUpperBound(true);
        double double10 = intervalXYDelegate7.getIntervalPositionFactor();
        intervalXYDelegate7.setAutoWidth(false);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.5d + "'", double10 == 0.5d);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test57");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) (short) 100);
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange();
        java.util.Date date4 = dateRange3.getUpperDate();
        java.util.Date date5 = dateTickUnit2.rollDate(date4);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot6.setDomainZeroBaselineVisible(false);
        combinedRangeXYPlot6.setDomainGridlinesVisible(false);
        org.jfree.data.xy.XYDataset xYDataset11 = combinedRangeXYPlot6.getDataset();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot13.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean17 = xYLineAndShapeRenderer16.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer16.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke21 = xYLineAndShapeRenderer16.getBaseOutlineStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = xYLineAndShapeRenderer16.getBasePositiveItemLabelPosition();
        java.awt.Shape shape23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.general.PieDataset pieDataset24 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity30 = new org.jfree.chart.entity.PieSectionEntity(shape23, pieDataset24, 1, (int) (short) -1, (java.lang.Comparable) 3, "hi!", "index.html");
        xYLineAndShapeRenderer16.setBaseShape(shape23, true);
        int int33 = combinedRangeXYPlot13.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer16);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis("EXPAND");
        combinedRangeXYPlot13.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis35);
        boolean boolean37 = dateAxis35.isTickMarksVisible();
        combinedRangeXYPlot6.setRangeAxis(64, (org.jfree.chart.axis.ValueAxis) dateAxis35, false);
        java.util.TimeZone timeZone40 = dateAxis35.getTimeZone();
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date4, timeZone40);
        java.util.Calendar calendar42 = null;
        try {
            long long43 = day41.getFirstMillisecond(calendar42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNull(xYDataset11);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(timeZone40);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test58");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.setDomainZeroBaselineVisible(false);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean7 = combinedRangeXYPlot0.removeDomainMarker((int) (short) 0, marker4, layer5, false);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation9 = axisLocation8.getOpposite();
        combinedRangeXYPlot0.setDomainAxisLocation(axisLocation9, false);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("EXPAND");
        java.text.DateFormat dateFormat15 = dateAxis14.getDateFormatOverride();
        java.util.Date date16 = dateAxis14.getMaximumDate();
        combinedRangeXYPlot0.setDomainAxis(15, (org.jfree.chart.axis.ValueAxis) dateAxis14, false);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline22 = new org.jfree.chart.axis.SegmentedTimeline((long) 7, (int) (short) 100, (int) (short) 1);
        segmentedTimeline22.setAdjustForDaylightSaving(false);
        segmentedTimeline22.addException((long) (byte) 100);
        int int27 = segmentedTimeline22.getSegmentsExcluded();
        dateAxis14.setTimeline((org.jfree.chart.axis.Timeline) segmentedTimeline22);
        org.jfree.data.time.DateRange dateRange29 = new org.jfree.data.time.DateRange();
        java.util.Date date30 = dateRange29.getUpperDate();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment31 = segmentedTimeline22.getSegment(date30);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNull(dateFormat15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(segment31);
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test59");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesStroke(false);
        barRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray8 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray8);
        org.jfree.data.Range range10 = barRenderer5.findRangeBounds(categoryDataset9);
        org.jfree.data.Range range11 = barRenderer0.findRangeBounds(categoryDataset9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection17, valueAxis18, polarItemRenderer19);
        polarPlot20.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = polarPlot20.getOrientation();
        combinedRangeXYPlot15.setOrientation(plotOrientation23);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer25 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean26 = xYLineAndShapeRenderer25.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer25.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke30 = xYLineAndShapeRenderer25.getBaseOutlineStroke();
        java.awt.Stroke stroke32 = xYLineAndShapeRenderer25.lookupSeriesStroke(4);
        combinedRangeXYPlot15.setDomainCrosshairStroke(stroke32);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        numberAxis34.setFixedAutoRange((double) 9);
        combinedRangeXYPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis34);
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis34.setLeftArrow(shape39);
        java.text.NumberFormat numberFormat41 = java.text.NumberFormat.getNumberInstance();
        boolean boolean42 = numberFormat41.isParseIntegerOnly();
        numberAxis34.setNumberFormatOverride(numberFormat41);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis34, categoryItemRenderer44);
        categoryPlot45.clearDomainMarkers();
        int int47 = categoryPlot45.getCrosshairDatasetIndex();
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str49 = categoryAxis48.getLabelURL();
        categoryAxis48.setUpperMargin(Double.NaN);
        int int52 = categoryPlot45.getDomainAxisIndex(categoryAxis48);
        categoryPlot45.setCrosshairDatasetIndex(0, true);
        java.awt.Shape shape61 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color62 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem63 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape61, (java.awt.Paint) color62);
        categoryPlot45.setDomainCrosshairPaint((java.awt.Paint) color62);
        categoryPlot45.setCrosshairDatasetIndex(64);
        org.jfree.chart.util.RectangleEdge rectangleEdge67 = categoryPlot45.getDomainAxisEdge();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation68 = null;
        try {
            boolean boolean70 = categoryPlot45.removeAnnotation(categoryAnnotation68, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(numberFormat41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(shape61);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(rectangleEdge67);
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test60");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setTop(3.0d);
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test61");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.setValue((java.lang.Comparable) 12.0d, (java.lang.Number) 0.4d);
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test62");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer2.setAutoPopulateSeriesStroke(false);
        barRenderer2.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray10 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray10);
        org.jfree.data.Range range12 = barRenderer7.findRangeBounds(categoryDataset11);
        org.jfree.data.Range range13 = barRenderer2.findRangeBounds(categoryDataset11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis14.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone18 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection19 = new org.jfree.data.time.TimeSeriesCollection(timeZone18);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer21 = null;
        org.jfree.chart.plot.PolarPlot polarPlot22 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection19, valueAxis20, polarItemRenderer21);
        polarPlot22.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation25 = polarPlot22.getOrientation();
        combinedRangeXYPlot17.setOrientation(plotOrientation25);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer27 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean28 = xYLineAndShapeRenderer27.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer27.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke32 = xYLineAndShapeRenderer27.getBaseOutlineStroke();
        java.awt.Stroke stroke34 = xYLineAndShapeRenderer27.lookupSeriesStroke(4);
        combinedRangeXYPlot17.setDomainCrosshairStroke(stroke34);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis();
        numberAxis36.setFixedAutoRange((double) 9);
        combinedRangeXYPlot17.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis36);
        java.awt.Shape shape41 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis36.setLeftArrow(shape41);
        java.text.NumberFormat numberFormat43 = java.text.NumberFormat.getNumberInstance();
        boolean boolean44 = numberFormat43.isParseIntegerOnly();
        numberAxis36.setNumberFormatOverride(numberFormat43);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis36, categoryItemRenderer46);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D48 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D48.setLabel("org.jfree.chart.event.RendererChangeEvent[source=1.0]");
        org.jfree.data.Range range51 = categoryPlot47.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D48);
        categoryPlot47.setDrawSharedDomainAxis(false);
        org.jfree.chart.util.SortOrder sortOrder54 = categoryPlot47.getColumnRenderingOrder();
        defaultPieDataset0.sortByValues(sortOrder54);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(plotOrientation25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(numberFormat43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(range51);
        org.junit.Assert.assertNotNull(sortOrder54);
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test63");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline((long) 7, (int) (short) 100, (int) (short) 1);
        segmentedTimeline3.setStartTime((long) 10);
        org.jfree.data.time.DateRange dateRange6 = new org.jfree.data.time.DateRange();
        java.util.Date date7 = dateRange6.getUpperDate();
        org.jfree.chart.axis.SegmentedTimeline.Segment segment8 = segmentedTimeline3.getSegment(date7);
        segment8.moveIndexToEnd();
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(segment8);
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test64");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = xYBarRenderer1.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset3 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range4 = xYBarRenderer1.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset3);
        double double5 = xYBarRenderer1.getShadowXOffset();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator6 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer1.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator6, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator11 = xYBarRenderer10.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset12 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range13 = xYBarRenderer10.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset12);
        double double14 = xYBarRenderer10.getShadowXOffset();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator15 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer10.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator15, true);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator18 = new org.jfree.chart.urls.StandardXYURLGenerator();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer19 = new org.jfree.chart.renderer.xy.XYAreaRenderer(8, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator15, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator18);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer20 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator6, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator18);
        xYStepAreaRenderer20.setShapesFilled(false);
        xYStepAreaRenderer20.setPlotArea(false);
        java.lang.Object obj25 = xYStepAreaRenderer20.clone();
        org.junit.Assert.assertNull(xYItemLabelGenerator2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator6);
        org.junit.Assert.assertNull(xYItemLabelGenerator11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator15);
        org.junit.Assert.assertNotNull(obj25);
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test65");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType2 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType2, (int) (short) 100);
        org.jfree.data.time.DateRange dateRange5 = new org.jfree.data.time.DateRange();
        java.util.Date date6 = dateRange5.getUpperDate();
        java.util.Date date7 = dateTickUnit4.rollDate(date6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.chart.axis.PeriodAxis periodAxis10 = new org.jfree.chart.axis.PeriodAxis("12/31/69 4:00 PM", (org.jfree.data.time.RegularTimePeriod) year8, (org.jfree.data.time.RegularTimePeriod) month9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(10, year8);
        org.junit.Assert.assertNotNull(dateTickUnitType2);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test66");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer1 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = xYBarRenderer1.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset3 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range4 = xYBarRenderer1.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset3);
        double double5 = xYBarRenderer1.getShadowXOffset();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator6 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer1.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator6, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer10 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator11 = xYBarRenderer10.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset12 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range13 = xYBarRenderer10.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset12);
        double double14 = xYBarRenderer10.getShadowXOffset();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator15 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer10.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator15, true);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator18 = new org.jfree.chart.urls.StandardXYURLGenerator();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer19 = new org.jfree.chart.renderer.xy.XYAreaRenderer(8, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator15, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator18);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer20 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator6, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator18);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer21 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean22 = xYLineAndShapeRenderer21.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape23 = null;
        xYLineAndShapeRenderer21.setBaseLegendShape(shape23);
        java.awt.Shape shape25 = xYLineAndShapeRenderer21.getLegendLine();
        boolean boolean26 = standardXYToolTipGenerator6.equals((java.lang.Object) xYLineAndShapeRenderer21);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer28 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean29 = xYLineAndShapeRenderer28.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape30 = null;
        xYLineAndShapeRenderer28.setBaseLegendShape(shape30);
        xYLineAndShapeRenderer28.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, false);
        java.awt.Stroke stroke37 = xYLineAndShapeRenderer28.getSeriesStroke((int) '4');
        boolean boolean39 = xYLineAndShapeRenderer28.isSeriesVisibleInLegend(9999);
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        xYLineAndShapeRenderer28.setBaseOutlinePaint((java.awt.Paint) color40, false);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator44 = null;
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer46 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator47 = xYBarRenderer46.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset48 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range49 = xYBarRenderer46.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset48);
        double double50 = xYBarRenderer46.getShadowXOffset();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator51 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer46.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator51, true);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer55 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator56 = xYBarRenderer55.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset57 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range58 = xYBarRenderer55.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset57);
        double double59 = xYBarRenderer55.getShadowXOffset();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator60 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYBarRenderer55.setBaseToolTipGenerator((org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator60, true);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator63 = new org.jfree.chart.urls.StandardXYURLGenerator();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer64 = new org.jfree.chart.renderer.xy.XYAreaRenderer(8, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator60, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator63);
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer65 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer((int) (byte) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator51, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator63);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer66 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0, xYToolTipGenerator44, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator63);
        xYLineAndShapeRenderer28.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator63, false);
        xYLineAndShapeRenderer21.setSeriesURLGenerator(0, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator63);
        org.junit.Assert.assertNull(xYItemLabelGenerator2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator6);
        org.junit.Assert.assertNull(xYItemLabelGenerator11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(stroke37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNull(xYItemLabelGenerator47);
        org.junit.Assert.assertNull(range49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 4.0d + "'", double50 == 4.0d);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator51);
        org.junit.Assert.assertNull(xYItemLabelGenerator56);
        org.junit.Assert.assertNull(range58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 4.0d + "'", double59 == 4.0d);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator60);
    }
}

