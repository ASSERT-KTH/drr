import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.awt.Shape shape0 = null;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        try {
            org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity3 = new org.jfree.chart.entity.JFreeChartEntity(shape0, jFreeChart1, "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getCurrencyInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) (byte) 10, (int) 'a', (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.awt.Paint paint1 = null;
        java.awt.Stroke stroke2 = null;
        java.awt.Paint paint3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Stroke stroke4 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) (short) 10, paint1, stroke2, paint3, stroke4, (float) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter3 = new org.jfree.chart.renderer.category.GradientBarPainter((double) (-1L), (double) (-1), (double) 1.0f);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.util.Date date0 = null;
        java.util.Date date1 = null;
        try {
            org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange(date0, date1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("hi!", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        java.awt.geom.Point2D point2D3 = null;
        org.jfree.chart.plot.PlotState plotState4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        try {
            waferMapPlot0.draw(graphics2D1, rectangle2D2, point2D3, plotState4, plotRenderingInfo5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addMonths((int) (byte) -1, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 10.0f, (double) (short) 0, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYLineAndShapeRenderer0.getNegativeItemLabelPosition(1, (int) (short) 10, true);
        java.awt.Stroke stroke9 = null;
        try {
            xYLineAndShapeRenderer0.setBaseStroke(stroke9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        try {
            java.lang.Comparable comparable3 = timeSeriesCollection1.getSeriesKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getBaseShapesVisible();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator3 = null;
        xYLineAndShapeRenderer0.setSeriesURLGenerator(1, xYURLGenerator3);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int0 = org.jfree.data.time.Year.MAXIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor2 = timeSeriesCollection1.getXPosition();
        java.lang.String str3 = timePeriodAnchor2.toString();
        org.junit.Assert.assertNotNull(timePeriodAnchor2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TimePeriodAnchor.START" + "'", str3.equals("TimePeriodAnchor.START"));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.general.DatasetGroup datasetGroup2 = null;
        try {
            timeSeriesCollection1.setGroup(datasetGroup2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'group' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = null;
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = null;
        try {
            org.jfree.chart.util.Size2D size2D4 = centerArrangement0.arrange(blockContainer1, graphics2D2, rectangleConstraint3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.SECOND;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'multiple' > 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.awt.Shape shape0 = null;
        try {
            java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, (double) '4', 1.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.AREA;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekInMonthCode((int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.text.DateFormatSymbols dateFormatSymbols0 = org.jfree.data.time.SerialDate.DATE_FORMAT_SYMBOLS;
        org.junit.Assert.assertNotNull(dateFormatSymbols0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("hi!", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator1 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("");
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection3 = new org.jfree.data.time.TimeSeriesCollection(timeZone2);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState4 = timeSeriesCollection3.getSelectionState();
        try {
            java.lang.String str6 = standardXYSeriesLabelGenerator1.generateLabel((org.jfree.data.xy.XYDataset) timeSeriesCollection3, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(xYDatasetSelectionState4);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape2 = null;
        xYLineAndShapeRenderer0.setBaseLegendShape(shape2);
        xYLineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, false);
        java.awt.Stroke stroke9 = xYLineAndShapeRenderer0.getSeriesStroke((int) '4');
        int int10 = xYLineAndShapeRenderer0.getPassCount();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(stroke9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.time.TimeSeries timeSeries2 = null;
        try {
            timeSeriesCollection1.removeSeries(timeSeries2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) (short) 1, 0.0d, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.lang.String[] strArray1 = null;
        try {
            org.jfree.chart.axis.SymbolAxis symbolAxis2 = new org.jfree.chart.axis.SymbolAxis("TimePeriodAnchor.START", strArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint3 = xYLineAndShapeRenderer0.lookupLegendTextPaint((int) (short) 100);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = xYLineAndShapeRenderer0.getToolTipGenerator(9999, 1, false);
        java.awt.Shape shape9 = null;
        xYLineAndShapeRenderer0.setSeriesShape(2, shape9, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(xYToolTipGenerator7);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState(0.0d);
        axisState1.cursorDown((double) 100);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.lang.Class class0 = null;
        try {
            boolean boolean1 = org.jfree.chart.util.SerialUtilities.isSerializable(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) waferMapPlot0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        waferMapPlot0.handleClick(0, 0, plotRenderingInfo4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            waferMapPlot0.drawBackground(graphics2D6, rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(9999);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultShadowsVisible(false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = null;
        polarPlot4.setDrawingSupplier(drawingSupplier5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        try {
            polarPlot4.zoomRangeAxes(0.0d, plotRenderingInfo8, point2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) "TimePeriodAnchor.START", (double) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getBaseShapesVisible();
        java.lang.Boolean boolean3 = xYLineAndShapeRenderer0.getSeriesCreateEntities((int) ' ');
        java.awt.Paint paint4 = null;
        try {
            xYLineAndShapeRenderer0.setBaseItemLabelPaint(paint4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(boolean3);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.lang.String str0 = org.jfree.chart.urls.StandardXYURLGenerator.DEFAULT_PREFIX;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "index.html" + "'", str0.equals("index.html"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        try {
            double double4 = timeSeriesCollection1.getYValue(0, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        org.jfree.chart.util.Rotation rotation2 = null;
        try {
            piePlot1.setDirection(rotation2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'direction' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        java.awt.Stroke stroke2 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        try {
            xYStepRenderer0.setSeriesStroke((-4145152), stroke2, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = axisSpace0.expand(rectangle2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        java.lang.Comparable comparable6 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) timeSeriesCollection2, comparable6);
        java.lang.Object obj8 = legendItemBlockContainer7.clone();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot11 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.title.LegendTitle legendTitle12 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) waferMapPlot11);
        java.awt.Font font13 = legendTitle12.getItemFont();
        try {
            java.lang.Object obj14 = legendItemBlockContainer7.draw(graphics2D9, rectangle2D10, (java.lang.Object) font13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYLineAndShapeRenderer0.getNegativeItemLabelPosition(1, (int) (short) 10, true);
        org.jfree.chart.text.TextAnchor textAnchor9 = itemLabelPosition8.getTextAnchor();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(textAnchor9);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        try {
            int int4 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) timeSeriesCollection0, (int) (byte) 1, (double) 10, (double) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (1).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment4 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment5 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("", font1, paint2, rectangleEdge3, horizontalAlignment4, verticalAlignment5, rectangleInsets6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'horizontalAlignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(verticalAlignment5);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        boolean boolean0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultShadowsVisible();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint3 = xYLineAndShapeRenderer0.lookupLegendTextPaint((int) (short) 100);
        xYLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean8 = xYLineAndShapeRenderer7.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer7.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Paint paint13 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYLineAndShapeRenderer7.setLegendTextPaint(1, paint13);
        try {
            xYLineAndShapeRenderer0.setSeriesPaint((-4145152), paint13, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (-1), range1);
        org.jfree.data.Range range3 = rectangleConstraint2.getWidthRange();
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo1 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str2 = basicProjectInfo1.getCopyright();
        boolean boolean3 = booleanList0.equals((java.lang.Object) str2);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        int int2 = piePlot1.getPieIndex();
        boolean boolean4 = piePlot1.equals((java.lang.Object) "");
        float float5 = piePlot1.getBackgroundImageAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = null;
        try {
            piePlot1.setLabelPadding(rectangleInsets6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("hi!");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_UPPER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2958465 + "'", int0 == 2958465);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.lang.String str0 = org.jfree.chart.labels.StandardXYSeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        boolean boolean5 = polarPlot4.isRadiusGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        try {
            polarPlot4.zoomRangeAxes((double) (short) -1, plotRenderingInfo7, point2D8, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean10 = textBlockAnchor8.equals((java.lang.Object) chartRenderingInfo9);
        java.awt.geom.Rectangle2D rectangle2D11 = chartRenderingInfo9.getChartArea();
        org.jfree.chart.entity.EntityCollection entityCollection12 = chartRenderingInfo9.getEntityCollection();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean15 = textBlockAnchor13.equals((java.lang.Object) chartRenderingInfo14);
        java.awt.geom.Rectangle2D rectangle2D16 = chartRenderingInfo14.getChartArea();
        chartRenderingInfo9.setChartArea(rectangle2D16);
        try {
            xYLineAndShapeRenderer0.fillDomainGridBand(graphics2D5, xYPlot6, valueAxis7, rectangle2D16, (double) (short) 100, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(entityCollection12);
        org.junit.Assert.assertNotNull(textBlockAnchor13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangle2D16);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape5, (java.awt.Paint) color6);
        java.awt.Font font8 = legendItem7.getLabelFont();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer9 = null;
        try {
            legendItem7.setFillPaintTransformer(gradientPaintTransformer9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'transformer' attribute.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(font8);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.renderer.xy.XYStepRenderer xYStepRenderer0 = new org.jfree.chart.renderer.xy.XYStepRenderer();
        double double1 = xYStepRenderer0.getStepPoint();
        java.awt.Paint paint5 = xYStepRenderer0.getItemPaint((int) (short) 10, 2, true);
        xYStepRenderer0.setSeriesItemLabelsVisible(100, (java.lang.Boolean) false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getShadowsVisible();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = barRenderer0.getBaseURLGenerator();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = barRenderer0.getBaseToolTipGenerator();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNull(categoryToolTipGenerator3);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getNumberInstance();
        boolean boolean1 = numberFormat0.isParseIntegerOnly();
        try {
            java.text.AttributedCharacterIterator attributedCharacterIterator3 = numberFormat0.formatToCharacterIterator((java.lang.Object) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getNumberInstance();
        boolean boolean2 = numberFormat1.isParseIntegerOnly();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) 1, numberFormat1);
        java.text.AttributedCharacterIterator attributedCharacterIterator5 = numberFormat1.formatToCharacterIterator((java.lang.Object) 100);
        int int6 = numberFormat1.getMinimumIntegerDigits();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(attributedCharacterIterator5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (-1L), (double) 1L, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.renderer.RendererUtilities rendererUtilities0 = new org.jfree.chart.renderer.RendererUtilities();
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        int int0 = org.jfree.chart.renderer.xy.XYStepAreaRenderer.AREA;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.awt.Font font0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getShadowsVisible();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor3 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean5 = textBlockAnchor3.equals((java.lang.Object) chartRenderingInfo4);
        java.awt.geom.Rectangle2D rectangle2D6 = chartRenderingInfo4.getChartArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState10 = barRenderer0.initialise(graphics2D2, rectangle2D6, categoryPlot7, (int) (short) 10, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(textBlockAnchor3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangle2D6);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke5 = xYLineAndShapeRenderer0.getBaseOutlineStroke();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        xYLineAndShapeRenderer0.setBasePaint((java.awt.Paint) color6);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.lang.Class class0 = null;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean2 = xYLineAndShapeRenderer1.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer1.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke6 = xYLineAndShapeRenderer1.getBaseOutlineStroke();
        java.awt.Stroke stroke8 = xYLineAndShapeRenderer1.lookupSeriesStroke(4);
        boolean boolean9 = axisLocation0.equals((java.lang.Object) stroke8);
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        java.lang.Comparable comparable6 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) timeSeriesCollection2, comparable6);
        int int8 = timeSeriesCollection2.getSeriesCount();
        java.util.List list9 = null;
        try {
            org.jfree.data.Range range11 = timeSeriesCollection2.getDomainBounds(list9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        boolean boolean5 = polarPlot4.isRadiusGridlinesVisible();
        polarPlot4.addCornerTextItem("hi!");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot10 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.title.LegendTitle legendTitle11 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) waferMapPlot10);
        java.awt.Font font12 = legendTitle11.getItemFont();
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("DateTickUnitType.SECOND", font12);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer14 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Font font16 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer14.setLegendTextFont((int) '#', font16);
        textTitle13.setFont(font16);
        java.awt.Paint paint19 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("TimePeriodAnchor.START", font16, paint19);
        polarPlot4.setNoDataMessagePaint(paint19);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(textBlock20);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) (short) 10, categoryItemLabelGenerator2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean8 = textBlockAnchor6.equals((java.lang.Object) chartRenderingInfo7);
        java.awt.geom.Rectangle2D rectangle2D9 = chartRenderingInfo7.getChartArea();
        try {
            barRenderer0.drawOutline(graphics2D4, categoryPlot5, rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangle2D9);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) (byte) 0, Double.NaN, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = null;
        waferMapPlot0.setDataset(waferMapDataset1);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.net.URL uRL0 = null;
        java.net.URLClassLoader uRLClassLoader1 = null;
        try {
            org.jfree.chart.util.ResourceBundleWrapper.removeCodeBase(uRL0, uRLClassLoader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        java.util.List list1 = null;
        try {
            org.jfree.data.Range range3 = timeSeriesCollection0.getDomainBounds(list1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        polarPlot5.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = polarPlot5.getOrientation();
        combinedRangeXYPlot0.setOrientation(plotOrientation8);
        try {
            combinedRangeXYPlot0.mapDatasetToDomainAxis((int) (short) -1, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'index' >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation8);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (double) 0.5f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.END;
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.ChartTheme chartTheme0 = org.jfree.chart.StandardChartTheme.createLegacyTheme();
        org.junit.Assert.assertNotNull(chartTheme0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        int int1 = color0.getRGB();
        float[] floatArray2 = new float[] {};
        try {
            float[] floatArray3 = color0.getColorComponents(floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-4145152) + "'", int1 == (-4145152));
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        org.jfree.chart.axis.TickUnit tickUnit5 = polarPlot4.getAngleTickUnit();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean10 = textBlockAnchor8.equals((java.lang.Object) chartRenderingInfo9);
        java.awt.geom.Rectangle2D rectangle2D11 = chartRenderingInfo9.getChartArea();
        org.jfree.chart.entity.EntityCollection entityCollection12 = chartRenderingInfo9.getEntityCollection();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean15 = textBlockAnchor13.equals((java.lang.Object) chartRenderingInfo14);
        java.awt.geom.Rectangle2D rectangle2D16 = chartRenderingInfo14.getChartArea();
        chartRenderingInfo9.setChartArea(rectangle2D16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = chartRenderingInfo9.getPlotInfo();
        java.awt.geom.Point2D point2D19 = null;
        try {
            polarPlot4.zoomRangeAxes(0.14d, (double) 1.0f, plotRenderingInfo18, point2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tickUnit5);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(entityCollection12);
        org.junit.Assert.assertNotNull(textBlockAnchor13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(plotRenderingInfo18);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.SECOND;
        java.lang.String str1 = dateTickUnitType0.toString();
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'multiple' > 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DateTickUnitType.SECOND" + "'", str1.equals("DateTickUnitType.SECOND"));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((-4145152), serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape2 = null;
        xYLineAndShapeRenderer0.setBaseLegendShape(shape2);
        xYLineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, false);
        boolean boolean8 = xYLineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        xYLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.data.Range range12 = xYLineAndShapeRenderer0.findDomainBounds(xYDataset11);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(range12);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) waferMapPlot0);
        java.lang.Object obj2 = legendTitle1.clone();
        org.jfree.chart.event.TitleChangeListener titleChangeListener3 = null;
        legendTitle1.removeChangeListener(titleChangeListener3);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.title.LegendTitle legendTitle1 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) waferMapPlot0);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent2 = null;
        waferMapPlot0.notifyListeners(plotChangeEvent2);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.awt.Paint paint2 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        piePlot1.setLabelLinkPaint(paint2);
        piePlot1.setIgnoreNullValues(false);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-2208960000000L) + "'", long0 == (-2208960000000L));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        java.awt.Font font0 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        java.lang.Comparable[] comparableArray6 = new java.lang.Comparable[] { '4', 10.0d, "hi!", (short) -1, 2, "hi!" };
        java.lang.Comparable[] comparableArray9 = new java.lang.Comparable[] { 100, 1.0f };
        double[][] doubleArray10 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray6, comparableArray9, doubleArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Duplicate items in 'rowKeys'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray6);
        org.junit.Assert.assertNotNull(comparableArray9);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name , locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getNumberInstance();
        boolean boolean2 = numberFormat1.isParseIntegerOnly();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) 1, numberFormat1);
        int int4 = numberFormat1.getMaximumFractionDigits();
        java.math.RoundingMode roundingMode5 = null;
        try {
            numberFormat1.setRoundingMode(roundingMode5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.MIDDLE;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test142");
//        java.util.Locale locale1 = null;
//        java.lang.Class class2 = null;
//        java.lang.ClassLoader classLoader3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class2);
//        java.util.ResourceBundle.Control control4 = null;
//        try {
//            java.util.ResourceBundle resourceBundle5 = java.util.ResourceBundle.getBundle("index.html", locale1, classLoader3, control4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(classLoader3);
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Paint paint5 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYLineAndShapeRenderer0.setBasePaint(paint5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = xYLineAndShapeRenderer0.getPositiveItemLabelPosition(0, (int) (short) 1, false);
        org.jfree.chart.text.TextAnchor textAnchor12 = itemLabelPosition11.getTextAnchor();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(textAnchor12);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        try {
            org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) 1.0f, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState(0.0d);
        axisState1.cursorUp((double) (byte) -1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.data.Range range2 = combinedRangeXYPlot0.getDataRange(valueAxis1);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation3 = null;
        try {
            boolean boolean4 = combinedRangeXYPlot0.removeAnnotation(xYAnnotation3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape5, (java.awt.Paint) color6);
        java.awt.Font font8 = legendItem7.getLabelFont();
        org.jfree.data.general.Dataset dataset9 = null;
        legendItem7.setDataset(dataset9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_YELLOW;
        legendItem7.setOutlinePaint((java.awt.Paint) color11);
        legendItem7.setURLText("");
        int int15 = legendItem7.getSeriesIndex();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(font8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem9 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape7, (java.awt.Paint) color8);
        java.awt.Font font10 = legendItem9.getLabelFont();
        org.jfree.data.general.Dataset dataset11 = null;
        legendItem9.setDataset(dataset11);
        boolean boolean13 = verticalAlignment1.equals((java.lang.Object) dataset11);
        boolean boolean14 = datasetRenderingOrder0.equals((java.lang.Object) boolean13);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        java.lang.Comparable comparable6 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) timeSeriesCollection2, comparable6);
        try {
            boolean boolean10 = timeSeriesCollection2.isSelected((int) '4', 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (52).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        double double3 = timeSeriesCollection1.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean7 = xYLineAndShapeRenderer6.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer6.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke11 = xYLineAndShapeRenderer6.getBaseOutlineStroke();
        java.awt.Stroke stroke13 = xYLineAndShapeRenderer6.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, valueAxis5, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer6);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor16 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean18 = textBlockAnchor16.equals((java.lang.Object) chartRenderingInfo17);
        java.awt.geom.Rectangle2D rectangle2D19 = chartRenderingInfo17.getChartArea();
        try {
            xYPlot14.drawBackground(graphics2D15, rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(textBlockAnchor16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangle2D19);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo0);
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState2 = new org.jfree.chart.plot.XYCrosshairState();
        state1.setCrosshairState(xYCrosshairState2);
        java.awt.geom.Line2D line2D4 = null;
        state1.workingLine = line2D4;
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        java.lang.Comparable comparable6 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) timeSeriesCollection2, comparable6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean11 = textBlockAnchor9.equals((java.lang.Object) chartRenderingInfo10);
        java.awt.geom.Rectangle2D rectangle2D12 = chartRenderingInfo10.getChartArea();
        try {
            legendItemBlockContainer7.draw(graphics2D8, rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangle2D12);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYLineAndShapeRenderer0.getNegativeItemLabelPosition(1, (int) (short) 10, true);
        boolean boolean9 = xYLineAndShapeRenderer0.getAutoPopulateSeriesShape();
        java.awt.Paint paint13 = xYLineAndShapeRenderer0.getItemLabelPaint(3, (int) (byte) 100, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) (short) 10, categoryItemLabelGenerator2);
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter7 = new org.jfree.chart.renderer.category.GradientBarPainter(0.14d, (-1.0d), (double) 100);
        barRenderer0.setBarPainter((org.jfree.chart.renderer.category.BarPainter) gradientBarPainter7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean11 = barRenderer10.getShadowsVisible();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = barRenderer10.getBaseURLGenerator();
        barRenderer10.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath19 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor20 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean22 = textBlockAnchor20.equals((java.lang.Object) chartRenderingInfo21);
        java.awt.geom.Rectangle2D rectangle2D23 = chartRenderingInfo21.getChartArea();
        org.jfree.chart.RenderingSource renderingSource24 = null;
        combinedRangeXYPlot18.select(generalPath19, rectangle2D23, renderingSource24);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        try {
            gradientBarPainter7.paintBarShadow(graphics2D9, barRenderer10, (int) (short) 0, 2958465, true, (java.awt.geom.RectangularShape) rectangle2D23, rectangleEdge26, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(categoryURLGenerator12);
        org.junit.Assert.assertNotNull(textBlockAnchor20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) waferMapPlot2);
        java.lang.Object obj4 = legendTitle3.clone();
        org.jfree.chart.entity.TitleEntity titleEntity7 = new org.jfree.chart.entity.TitleEntity(shape1, (org.jfree.chart.title.Title) legendTitle3, "hi!", "");
        org.jfree.chart.title.Title title8 = titleEntity7.getTitle();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(title8);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        double double0 = org.jfree.chart.plot.PiePlot.MAX_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.4d + "'", double0 == 0.4d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        try {
            timeSeriesCollection1.setSelected((int) 'a', 1, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (97).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test163");
//        java.util.Locale locale1 = null;
//        java.lang.Class class2 = null;
//        java.lang.ClassLoader classLoader3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class2);
//        try {
//            java.util.ResourceBundle resourceBundle4 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("", locale1, classLoader3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(classLoader3);
//    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getShadowsVisible();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator2, false);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean7 = xYLineAndShapeRenderer6.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer6.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        xYLineAndShapeRenderer6.setAutoPopulateSeriesPaint(true);
        xYLineAndShapeRenderer6.setSeriesLinesVisible((int) (byte) 100, (java.lang.Boolean) false);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state18 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo17);
        java.awt.geom.GeneralPath generalPath19 = null;
        state18.seriesPath = generalPath19;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer21 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean22 = xYLineAndShapeRenderer21.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer21.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke26 = xYLineAndShapeRenderer21.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot28 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath29 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor30 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean32 = textBlockAnchor30.equals((java.lang.Object) chartRenderingInfo31);
        java.awt.geom.Rectangle2D rectangle2D33 = chartRenderingInfo31.getChartArea();
        org.jfree.chart.RenderingSource renderingSource34 = null;
        combinedRangeXYPlot28.select(generalPath29, rectangle2D33, renderingSource34);
        org.jfree.chart.plot.XYPlot xYPlot36 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset37 = new org.jfree.data.xy.DefaultXYDataset();
        int int39 = defaultXYDataset37.indexOf((java.lang.Comparable) 0.5f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState41 = xYLineAndShapeRenderer21.initialise(graphics2D27, rectangle2D33, xYPlot36, (org.jfree.data.xy.XYDataset) defaultXYDataset37, plotRenderingInfo40);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot42 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone43 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection44 = new org.jfree.data.time.TimeSeriesCollection(timeZone43);
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer46 = null;
        org.jfree.chart.plot.PolarPlot polarPlot47 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection44, valueAxis45, polarItemRenderer46);
        polarPlot47.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation50 = polarPlot47.getOrientation();
        combinedRangeXYPlot42.setOrientation(plotOrientation50);
        combinedRangeXYPlot42.setRangeCrosshairValue(0.0d);
        boolean boolean54 = combinedRangeXYPlot42.isDomainCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        org.jfree.chart.axis.ValueAxis valueAxis56 = null;
        java.util.TimeZone timeZone57 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection58 = new org.jfree.data.time.TimeSeriesCollection(timeZone57);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor59 = timeSeriesCollection58.getXPosition();
        xYLineAndShapeRenderer6.drawItem(graphics2D16, (org.jfree.chart.renderer.xy.XYItemRendererState) state18, rectangle2D33, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot42, valueAxis55, valueAxis56, (org.jfree.data.xy.XYDataset) timeSeriesCollection58, (-1), 15, false, (-4145152));
        org.jfree.chart.plot.CategoryPlot categoryPlot65 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor67 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo68 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean69 = textBlockAnchor67.equals((java.lang.Object) chartRenderingInfo68);
        java.awt.geom.Rectangle2D rectangle2D70 = chartRenderingInfo68.getChartArea();
        org.jfree.chart.entity.EntityCollection entityCollection71 = chartRenderingInfo68.getEntityCollection();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor72 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo73 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean74 = textBlockAnchor72.equals((java.lang.Object) chartRenderingInfo73);
        java.awt.geom.Rectangle2D rectangle2D75 = chartRenderingInfo73.getChartArea();
        chartRenderingInfo68.setChartArea(rectangle2D75);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo77 = chartRenderingInfo68.getPlotInfo();
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState78 = barRenderer0.initialise(graphics2D5, rectangle2D33, categoryPlot65, 9, plotRenderingInfo77);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(textBlockAnchor30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState41);
        org.junit.Assert.assertNotNull(plotOrientation50);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(timePeriodAnchor59);
        org.junit.Assert.assertNotNull(textBlockAnchor67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(rectangle2D70);
        org.junit.Assert.assertNotNull(entityCollection71);
        org.junit.Assert.assertNotNull(textBlockAnchor72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(rectangle2D75);
        org.junit.Assert.assertNotNull(plotRenderingInfo77);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.lang.Comparable[] comparableArray2 = new java.lang.Comparable[] { 0.0f, "ERROR : Relative To String" };
        java.lang.String[] strArray4 = org.jfree.data.time.SerialDate.getMonths(true);
        double[][] doubleArray7 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset8 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray7);
        try {
            org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray2, (java.lang.Comparable[]) strArray4, doubleArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray2);
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(categoryDataset8);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint(paint0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = null;
        java.util.TimeZone timeZone3 = null;
        java.util.Locale locale4 = null;
        try {
            org.jfree.chart.axis.PeriodAxis periodAxis5 = new org.jfree.chart.axis.PeriodAxis("TimePeriodAnchor.START", regularTimePeriod1, regularTimePeriod2, timeZone3, locale4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'timeZone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        xYLineAndShapeRenderer0.setAutoPopulateSeriesPaint(true);
        xYLineAndShapeRenderer0.setSeriesCreateEntities((int) (short) 100, (java.lang.Boolean) false, false);
        xYLineAndShapeRenderer0.setSeriesItemLabelsVisible((int) (byte) 1, (java.lang.Boolean) false, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape5, (java.awt.Paint) color6);
        java.awt.Font font8 = legendItem7.getLabelFont();
        org.jfree.data.general.Dataset dataset9 = null;
        legendItem7.setDataset(dataset9);
        legendItem7.setToolTipText("{0}");
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(font8);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Color color2 = java.awt.Color.orange;
        try {
            xYLineAndShapeRenderer0.setSeriesOutlinePaint((int) (short) -1, (java.awt.Paint) color2, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor2 = timeSeriesCollection1.getXPosition();
        try {
            java.lang.Comparable comparable4 = timeSeriesCollection1.getSeriesKey((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (100).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodAnchor2);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 1, (int) (short) -1, (java.lang.Comparable) 3, "hi!", "index.html");
        org.jfree.data.general.PieDataset pieDataset8 = pieSectionEntity7.getDataset();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(pieDataset8);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        boolean boolean4 = color1.equals((java.lang.Object) 'a');
        java.awt.Color color5 = java.awt.Color.getColor("ERROR : Relative To String", color1);
        int int6 = color1.getAlpha();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 255 + "'", int6 == 255);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Font font2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer0.setLegendTextFont((int) '#', font2);
        boolean boolean6 = xYLineAndShapeRenderer0.getItemVisible((int) (short) 100, 0);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        int int2 = piePlot1.getPieIndex();
        double double3 = piePlot1.getMaximumLabelWidth();
        piePlot1.setMinimumArcAngleToDraw((double) 10.0f);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.14d + "'", double3 == 0.14d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) 1.0d);
        java.lang.Object obj2 = rendererChangeEvent1.getRenderer();
        java.lang.String str3 = rendererChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 1.0d + "'", obj2.equals(1.0d));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.chart.event.RendererChangeEvent[source=1.0]" + "'", str3.equals("org.jfree.chart.event.RendererChangeEvent[source=1.0]"));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.AxisState axisState3 = new org.jfree.chart.axis.AxisState(0.0d);
        org.jfree.chart.plot.WaferMapPlot waferMapPlot5 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) waferMapPlot5);
        java.awt.Font font7 = legendTitle6.getItemFont();
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("DateTickUnitType.SECOND", font7);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer9 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Font font11 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer9.setLegendTextFont((int) '#', font11);
        textTitle8.setFont(font11);
        java.awt.Paint paint14 = textTitle8.getBackgroundPaint();
        java.awt.geom.Rectangle2D rectangle2D15 = textTitle8.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        try {
            java.util.List list17 = numberAxis3D0.refreshTicks(graphics2D1, axisState3, rectangle2D15, rectangleEdge16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setStartAngle(1.0d);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor4 = piePlot1.getLabelDistributor();
        java.awt.Paint paint5 = null;
        try {
            piePlot1.setLabelPaint(paint5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor4);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.awt.geom.Line2D line2D0 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) chartRenderingInfo2);
        java.awt.geom.Rectangle2D rectangle2D4 = chartRenderingInfo2.getChartArea();
        org.jfree.chart.entity.EntityCollection entityCollection5 = chartRenderingInfo2.getEntityCollection();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean8 = textBlockAnchor6.equals((java.lang.Object) chartRenderingInfo7);
        java.awt.geom.Rectangle2D rectangle2D9 = chartRenderingInfo7.getChartArea();
        chartRenderingInfo2.setChartArea(rectangle2D9);
        try {
            boolean boolean11 = org.jfree.chart.util.LineUtilities.clipLine(line2D0, rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(entityCollection5);
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangle2D9);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) (short) 10, categoryItemLabelGenerator2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean10 = textBlockAnchor8.equals((java.lang.Object) chartRenderingInfo9);
        java.awt.geom.Rectangle2D rectangle2D11 = chartRenderingInfo9.getChartArea();
        org.jfree.chart.RenderingSource renderingSource12 = null;
        combinedRangeXYPlot6.select(generalPath7, rectangle2D11, renderingSource12);
        try {
            barRenderer0.drawOutline(graphics2D4, categoryPlot5, rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangle2D11);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (java.lang.Comparable) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.setDomainZeroBaselineVisible(false);
        combinedRangeXYPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.plot.Marker marker5 = null;
        try {
            boolean boolean6 = combinedRangeXYPlot0.removeRangeMarker(marker5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(0.2d, range1);
        org.jfree.data.Range range3 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean4 = range1.intersects(range3);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getBaseShapesVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier2 = xYLineAndShapeRenderer0.getDrawingSupplier();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 10, (java.lang.Boolean) true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(drawingSupplier2);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setStartAngle(1.0d);
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor4 = piePlot1.getLabelDistributor();
        piePlot1.setSectionOutlinesVisible(false);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor4);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Stroke stroke1 = org.jfree.chart.util.SerialUtilities.readStroke(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        try {
            double double3 = timeSeriesCollection0.getXValue(0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray1 = basicProjectInfo0.getOptionalLibraries();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo2 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str3 = basicProjectInfo2.getName();
        basicProjectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo2);
        java.lang.String str5 = basicProjectInfo2.getName();
        org.jfree.chart.ui.Library[] libraryArray6 = basicProjectInfo2.getLibraries();
        basicProjectInfo2.setCopyright("TimePeriodAnchor.START");
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(libraryArray6);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        categoryAxis0.setLabelPaint((java.awt.Paint) color1);
        double double3 = categoryAxis0.getLowerMargin();
        double double4 = categoryAxis0.getLabelAngle();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        int int1 = objectList0.size();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.util.LineUtilities lineUtilities0 = new org.jfree.chart.util.LineUtilities();
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getCurrencyInstance();
        numberFormat0.setMinimumFractionDigits((int) (byte) 100);
        java.util.Currency currency3 = numberFormat0.getCurrency();
        numberFormat0.setMaximumIntegerDigits(2958465);
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertNotNull(currency3);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset) defaultPieDataset0, (java.lang.Comparable) 10L, (-1.0d), (int) ' ');
        try {
            java.lang.Comparable comparable6 = defaultPieDataset0.getKey(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset4);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        int int2 = piePlot1.getPieIndex();
        boolean boolean4 = piePlot1.equals((java.lang.Object) "");
        java.awt.Stroke stroke5 = null;
        piePlot1.setOutlineStroke(stroke5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        categoryAxis0.setLabelPaint((java.awt.Paint) color1);
        java.lang.Comparable comparable3 = null;
        try {
            categoryAxis0.removeCategoryLabelToolTip(comparable3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(0, (int) (byte) 10, (int) (short) 10);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getDrawOutlines();
        java.lang.Boolean boolean3 = xYLineAndShapeRenderer0.getSeriesCreateEntities((int) (byte) 0);
        java.awt.Shape shape5 = xYLineAndShapeRenderer0.getLegendShape((int) '4');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNull(shape5);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        xYLineAndShapeRenderer0.setAutoPopulateSeriesPaint(true);
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) '4', false);
        xYLineAndShapeRenderer0.removeAnnotations();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.CLOCKWISE;
        org.junit.Assert.assertNotNull(rotation0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        polarPlot5.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = polarPlot5.getOrientation();
        combinedRangeXYPlot0.setOrientation(plotOrientation8);
        combinedRangeXYPlot0.setRangeCrosshairValue(0.0d);
        boolean boolean12 = combinedRangeXYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisSpace axisSpace13 = new org.jfree.chart.axis.AxisSpace();
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace13);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis16 = combinedRangeXYPlot0.getDomainAxisForDataset((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 10 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        polarPlot5.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = polarPlot5.getOrientation();
        combinedRangeXYPlot0.setOrientation(plotOrientation8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        combinedRangeXYPlot0.setDomainCrosshairPaint((java.awt.Paint) color10);
        org.jfree.chart.plot.WaferMapPlot waferMapPlot12 = new org.jfree.chart.plot.WaferMapPlot();
        boolean boolean13 = combinedRangeXYPlot0.equals((java.lang.Object) waferMapPlot12);
        try {
            org.jfree.chart.LegendItemCollection legendItemCollection14 = waferMapPlot12.getLegendItems();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean3 = textBlockAnchor1.equals((java.lang.Object) chartRenderingInfo2);
        java.awt.geom.Rectangle2D rectangle2D4 = chartRenderingInfo2.getChartArea();
        try {
            boolean boolean5 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D0, rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangle2D4);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getNumberInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYLineAndShapeRenderer0.getNegativeItemLabelPosition(1, (int) (short) 10, true);
        boolean boolean9 = xYLineAndShapeRenderer0.getAutoPopulateSeriesShape();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = null;
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection11, valueAxis12, polarItemRenderer13);
        java.awt.Paint paint15 = polarPlot14.getAngleLabelPaint();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean17 = xYLineAndShapeRenderer16.getAutoPopulateSeriesOutlinePaint();
        java.awt.Font font18 = xYLineAndShapeRenderer16.getBaseItemLabelFont();
        polarPlot14.setAngleLabelFont(font18);
        xYLineAndShapeRenderer0.setBaseLegendTextFont(font18);
        java.awt.Paint paint22 = xYLineAndShapeRenderer0.lookupSeriesOutlinePaint((int) (byte) -1);
        xYLineAndShapeRenderer0.setDefaultEntityRadius(15);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        int int2 = piePlot1.getPieIndex();
        double double3 = piePlot1.getMaximumLabelWidth();
        piePlot1.setExplodePercent((java.lang.Comparable) 10, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.14d + "'", double3 == 0.14d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke5 = xYLineAndShapeRenderer0.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath8 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean11 = textBlockAnchor9.equals((java.lang.Object) chartRenderingInfo10);
        java.awt.geom.Rectangle2D rectangle2D12 = chartRenderingInfo10.getChartArea();
        org.jfree.chart.RenderingSource renderingSource13 = null;
        combinedRangeXYPlot7.select(generalPath8, rectangle2D12, renderingSource13);
        org.jfree.chart.plot.XYPlot xYPlot15 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset16 = new org.jfree.data.xy.DefaultXYDataset();
        int int18 = defaultXYDataset16.indexOf((java.lang.Comparable) 0.5f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState20 = xYLineAndShapeRenderer0.initialise(graphics2D6, rectangle2D12, xYPlot15, (org.jfree.data.xy.XYDataset) defaultXYDataset16, plotRenderingInfo19);
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState21 = xYItemRendererState20.getCrosshairState();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState20);
        org.junit.Assert.assertNull(xYCrosshairState21);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        try {
            defaultPieDataset0.remove((java.lang.Comparable) false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (false) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setStartAngle(1.0d);
        java.awt.Font font4 = piePlot1.getLabelFont();
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("{0}", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.junit.Assert.assertNotNull(dateRange0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        java.lang.Comparable comparable6 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) timeSeriesCollection2, comparable6);
        java.lang.Object obj8 = legendItemBlockContainer7.clone();
        org.jfree.data.general.Dataset dataset9 = legendItemBlockContainer7.getDataset();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot11 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath12 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean15 = textBlockAnchor13.equals((java.lang.Object) chartRenderingInfo14);
        java.awt.geom.Rectangle2D rectangle2D16 = chartRenderingInfo14.getChartArea();
        org.jfree.chart.RenderingSource renderingSource17 = null;
        combinedRangeXYPlot11.select(generalPath12, rectangle2D16, renderingSource17);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset19 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.data.general.PieDataset pieDataset23 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset) defaultPieDataset19, (java.lang.Comparable) 10L, (-1.0d), (int) ' ');
        try {
            java.lang.Object obj24 = legendItemBlockContainer7.draw(graphics2D10, rectangle2D16, (java.lang.Object) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(dataset9);
        org.junit.Assert.assertNotNull(textBlockAnchor13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertNotNull(pieDataset23);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        boolean boolean2 = xYLineAndShapeRenderer0.getAutoPopulateSeriesPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        java.awt.Shape shape4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity11 = new org.jfree.chart.entity.PieSectionEntity(shape4, pieDataset5, 1, (int) (short) -1, (java.lang.Comparable) 3, "hi!", "index.html");
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        piePlot13.setStartAngle(1.0d);
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape21, (java.awt.Paint) color22);
        piePlot13.setLabelLinkPaint((java.awt.Paint) color22);
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("", "TimePeriodAnchor.START", "TimePeriodAnchor.START", "DateTickUnitType.SECOND", shape4, (java.awt.Paint) color22);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        legendItem25.setFillPaint((java.awt.Paint) color26);
        java.awt.Paint paint28 = legendItem25.getLabelPaint();
        boolean boolean29 = legendItem25.isLineVisible();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate2 = new org.jfree.data.xy.IntervalXYDelegate(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MAJOR;
        org.junit.Assert.assertNotNull(tickType0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        polarPlot5.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = polarPlot5.getOrientation();
        combinedRangeXYPlot0.setOrientation(plotOrientation8);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean11 = xYLineAndShapeRenderer10.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer10.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke15 = xYLineAndShapeRenderer10.getBaseOutlineStroke();
        java.awt.Stroke stroke17 = xYLineAndShapeRenderer10.lookupSeriesStroke(4);
        combinedRangeXYPlot0.setDomainCrosshairStroke(stroke17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = combinedRangeXYPlot0.getLegendItems();
        java.awt.Shape shape24 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.general.PieDataset pieDataset25 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity31 = new org.jfree.chart.entity.PieSectionEntity(shape24, pieDataset25, 1, (int) (short) -1, (java.lang.Comparable) 3, "hi!", "index.html");
        org.jfree.data.general.PieDataset pieDataset32 = null;
        org.jfree.chart.plot.PiePlot piePlot33 = new org.jfree.chart.plot.PiePlot(pieDataset32);
        piePlot33.setStartAngle(1.0d);
        java.awt.Shape shape41 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color42 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem43 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape41, (java.awt.Paint) color42);
        piePlot33.setLabelLinkPaint((java.awt.Paint) color42);
        org.jfree.chart.LegendItem legendItem45 = new org.jfree.chart.LegendItem("", "TimePeriodAnchor.START", "TimePeriodAnchor.START", "DateTickUnitType.SECOND", shape24, (java.awt.Paint) color42);
        java.awt.Color color46 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        legendItem45.setFillPaint((java.awt.Paint) color46);
        org.jfree.data.general.Dataset dataset48 = legendItem45.getDataset();
        legendItemCollection19.add(legendItem45);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(legendItemCollection19);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNull(dataset48);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        polarPlot5.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = polarPlot5.getOrientation();
        combinedRangeXYPlot0.setOrientation(plotOrientation8);
        combinedRangeXYPlot0.setRangeCrosshairValue(0.0d);
        boolean boolean12 = combinedRangeXYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisSpace axisSpace13 = new org.jfree.chart.axis.AxisSpace();
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace13);
        double double15 = axisSpace13.getTop();
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.awt.Shape shape4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.general.PieDataset pieDataset5 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity11 = new org.jfree.chart.entity.PieSectionEntity(shape4, pieDataset5, 1, (int) (short) -1, (java.lang.Comparable) 3, "hi!", "index.html");
        org.jfree.data.general.PieDataset pieDataset12 = null;
        org.jfree.chart.plot.PiePlot piePlot13 = new org.jfree.chart.plot.PiePlot(pieDataset12);
        piePlot13.setStartAngle(1.0d);
        java.awt.Shape shape21 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape21, (java.awt.Paint) color22);
        piePlot13.setLabelLinkPaint((java.awt.Paint) color22);
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("", "TimePeriodAnchor.START", "TimePeriodAnchor.START", "DateTickUnitType.SECOND", shape4, (java.awt.Paint) color22);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        legendItem25.setFillPaint((java.awt.Paint) color26);
        org.jfree.data.general.Dataset dataset28 = legendItem25.getDataset();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer29 = null;
        try {
            legendItem25.setFillPaintTransformer(gradientPaintTransformer29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'transformer' attribute.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNull(dataset28);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        polarPlot4.setAngleGridlinesVisible(false);
        polarPlot4.setAngleGridlinesVisible(false);
        boolean boolean9 = polarPlot4.isRadiusGridlinesVisible();
        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str12 = dateTickUnit10.valueToString((double) 2);
        int int13 = dateTickUnit10.getMultiple();
        polarPlot4.setAngleTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit10);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dateTickUnit10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "12/31/69 4:00 PM" + "'", str12.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        java.awt.Paint paint5 = polarPlot4.getAngleLabelPaint();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) polarPlot4);
        java.awt.Paint paint7 = polarPlot4.getAngleLabelPaint();
        polarPlot4.setForegroundAlpha((float) 10L);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo0);
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState2 = new org.jfree.chart.plot.XYCrosshairState();
        state1.setCrosshairState(xYCrosshairState2);
        xYCrosshairState2.updateCrosshairY(0.0d, 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        boolean boolean8 = textAnchor6.equals((java.lang.Object) (byte) 0);
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        boolean boolean11 = textAnchor9.equals((java.lang.Object) (byte) 0);
        org.jfree.chart.axis.NumberTick numberTick13 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (-4145152), "ERROR : Relative To String", textAnchor6, textAnchor9, (double) (short) 0);
        org.jfree.chart.text.TextAnchor textAnchor14 = numberTick13.getRotationAnchor();
        java.lang.String str15 = numberTick13.getText();
        org.jfree.chart.text.TextAnchor textAnchor16 = numberTick13.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor18 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        try {
            java.awt.Shape shape19 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("TimePeriodAnchor.START", graphics2D1, 0.0f, (float) 3, textAnchor16, (double) 64, textAnchor18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ERROR : Relative To String" + "'", str15.equals("ERROR : Relative To String"));
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertNotNull(textAnchor18);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        polarPlot4.setAngleGridlinesVisible(false);
        boolean boolean7 = polarPlot4.isDomainZoomable();
        org.jfree.chart.axis.TickUnit tickUnit8 = polarPlot4.getAngleTickUnit();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(tickUnit8);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("hi!");
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        logAxis0.zoomRange(Double.NaN, (double) 2958465);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str1 = basicProjectInfo0.getLicenceName();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo2 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str3 = basicProjectInfo2.getCopyright();
        basicProjectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo2);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.08d + "'", double0 == 0.08d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getBaseShapesVisible();
        java.lang.Boolean boolean3 = xYLineAndShapeRenderer0.getSeriesCreateEntities((int) ' ');
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator5 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("");
        java.lang.Object obj6 = standardXYSeriesLabelGenerator5.clone();
        xYLineAndShapeRenderer0.setLegendItemLabelGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator5);
        java.lang.Object obj8 = standardXYSeriesLabelGenerator5.clone();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        int int0 = org.jfree.data.time.Year.MINIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-9999) + "'", int0 == (-9999));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Font font2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer0.setLegendTextFont((int) '#', font2);
        boolean boolean4 = xYLineAndShapeRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Font font5 = xYLineAndShapeRenderer0.getBaseLegendTextFont();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean7 = xYLineAndShapeRenderer6.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer6.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke11 = xYLineAndShapeRenderer6.getBaseOutlineStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = xYLineAndShapeRenderer6.getBasePositiveItemLabelPosition();
        java.awt.Shape shape13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.general.PieDataset pieDataset14 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity20 = new org.jfree.chart.entity.PieSectionEntity(shape13, pieDataset14, 1, (int) (short) -1, (java.lang.Comparable) 3, "hi!", "index.html");
        xYLineAndShapeRenderer6.setBaseShape(shape13, true);
        xYLineAndShapeRenderer0.setBaseShape(shape13);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.NONE;
        org.junit.Assert.assertNotNull(domainOrder0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray1 = basicProjectInfo0.getOptionalLibraries();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo2 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str3 = basicProjectInfo2.getName();
        basicProjectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo2);
        java.lang.String str5 = basicProjectInfo0.getVersion();
        basicProjectInfo0.setVersion("index.html");
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers((int) (short) 10);
        java.util.List list3 = combinedRangeXYPlot0.getAnnotations();
        org.jfree.chart.axis.LogAxis logAxis5 = new org.jfree.chart.axis.LogAxis();
        boolean boolean6 = logAxis5.isTickMarksVisible();
        try {
            combinedRangeXYPlot0.setRangeAxis((-1), (org.jfree.chart.axis.ValueAxis) logAxis5, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) waferMapPlot2);
        java.lang.Object obj4 = legendTitle3.clone();
        org.jfree.chart.entity.TitleEntity titleEntity7 = new org.jfree.chart.entity.TitleEntity(shape1, (org.jfree.chart.title.Title) legendTitle3, "hi!", "");
        java.lang.Object obj8 = titleEntity7.clone();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        double double3 = timeSeriesCollection1.getDomainLowerBound(false);
        try {
            int[] intArray7 = org.jfree.chart.renderer.RendererUtilities.findLiveItems((org.jfree.data.xy.XYDataset) timeSeriesCollection1, 4, (double) (short) -1, (double) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (4).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range2 = xYBarRenderer0.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        try {
            double double5 = timeSeriesCollection1.getXValue(2958465, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2958465, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.data.Range range2 = combinedRangeXYPlot0.getDataRange(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = combinedRangeXYPlot0.getDomainAxis();
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        boolean boolean8 = textAnchor6.equals((java.lang.Object) (byte) 0);
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        boolean boolean11 = textAnchor9.equals((java.lang.Object) (byte) 0);
        org.jfree.chart.axis.NumberTick numberTick13 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (-4145152), "ERROR : Relative To String", textAnchor6, textAnchor9, (double) (short) 0);
        boolean boolean14 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) valueAxis3, (java.lang.Object) "ERROR : Relative To String");
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        double double3 = timeSeriesCollection1.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean7 = xYLineAndShapeRenderer6.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer6.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke11 = xYLineAndShapeRenderer6.getBaseOutlineStroke();
        java.awt.Stroke stroke13 = xYLineAndShapeRenderer6.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, valueAxis5, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer6);
        try {
            double double17 = timeSeriesCollection1.getEndYValue(3, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        double double3 = timeSeriesCollection1.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean7 = xYLineAndShapeRenderer6.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer6.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke11 = xYLineAndShapeRenderer6.getBaseOutlineStroke();
        java.awt.Stroke stroke13 = xYLineAndShapeRenderer6.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, valueAxis5, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer6);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = xYPlot14.getInsets();
        xYPlot14.setRangeCrosshairValue((double) 10L);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection19 = new org.jfree.data.time.TimeSeriesCollection();
        xYPlot14.setDataset(64, (org.jfree.data.xy.XYDataset) timeSeriesCollection19);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor2 = timeSeriesCollection1.getXPosition();
        try {
            timeSeriesCollection1.setSelected((int) (short) 10, 9999, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (10).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodAnchor2);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape2 = null;
        xYLineAndShapeRenderer0.setBaseLegendShape(shape2);
        xYLineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, false);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot9.setDomainZeroBaselineVisible(false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot12.setDomainCrosshairValue((double) 9, true);
        boolean boolean16 = combinedRangeXYPlot12.isDomainCrosshairLockedOnData();
        combinedRangeXYPlot9.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot12);
        org.jfree.chart.plot.IntervalMarker intervalMarker20 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 1.0f);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot21 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot21.setDomainZeroBaselineVisible(false);
        org.jfree.chart.plot.Marker marker25 = null;
        org.jfree.chart.util.Layer layer26 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean28 = combinedRangeXYPlot21.removeDomainMarker((int) (short) 0, marker25, layer26, false);
        combinedRangeXYPlot12.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker20, layer26);
        try {
            xYLineAndShapeRenderer0.addAnnotation(xYAnnotation8, layer26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(layer26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState0 = new org.jfree.chart.plot.XYCrosshairState();
        xYCrosshairState0.updateCrosshairY((double) (short) 0, (-4145152));
        xYCrosshairState0.updateCrosshairY((double) 0, (-1));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.removeAnnotations();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo3);
        boolean boolean5 = state4.getProcessVisibleItemsOnly();
        java.awt.geom.GeneralPath generalPath6 = state4.seriesPath;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer7 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean8 = xYLineAndShapeRenderer7.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer7.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        xYLineAndShapeRenderer7.setAutoPopulateSeriesPaint(true);
        xYLineAndShapeRenderer7.setSeriesLinesVisible((int) (byte) 100, (java.lang.Boolean) false);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state19 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo18);
        java.awt.geom.GeneralPath generalPath20 = null;
        state19.seriesPath = generalPath20;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer22 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean23 = xYLineAndShapeRenderer22.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer22.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke27 = xYLineAndShapeRenderer22.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot29 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath30 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor31 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo32 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean33 = textBlockAnchor31.equals((java.lang.Object) chartRenderingInfo32);
        java.awt.geom.Rectangle2D rectangle2D34 = chartRenderingInfo32.getChartArea();
        org.jfree.chart.RenderingSource renderingSource35 = null;
        combinedRangeXYPlot29.select(generalPath30, rectangle2D34, renderingSource35);
        org.jfree.chart.plot.XYPlot xYPlot37 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset38 = new org.jfree.data.xy.DefaultXYDataset();
        int int40 = defaultXYDataset38.indexOf((java.lang.Comparable) 0.5f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState42 = xYLineAndShapeRenderer22.initialise(graphics2D28, rectangle2D34, xYPlot37, (org.jfree.data.xy.XYDataset) defaultXYDataset38, plotRenderingInfo41);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot43 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone44 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection45 = new org.jfree.data.time.TimeSeriesCollection(timeZone44);
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer47 = null;
        org.jfree.chart.plot.PolarPlot polarPlot48 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection45, valueAxis46, polarItemRenderer47);
        polarPlot48.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation51 = polarPlot48.getOrientation();
        combinedRangeXYPlot43.setOrientation(plotOrientation51);
        combinedRangeXYPlot43.setRangeCrosshairValue(0.0d);
        boolean boolean55 = combinedRangeXYPlot43.isDomainCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis56 = null;
        org.jfree.chart.axis.ValueAxis valueAxis57 = null;
        java.util.TimeZone timeZone58 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection59 = new org.jfree.data.time.TimeSeriesCollection(timeZone58);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor60 = timeSeriesCollection59.getXPosition();
        xYLineAndShapeRenderer7.drawItem(graphics2D17, (org.jfree.chart.renderer.xy.XYItemRendererState) state19, rectangle2D34, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot43, valueAxis56, valueAxis57, (org.jfree.data.xy.XYDataset) timeSeriesCollection59, (-1), 15, false, (-4145152));
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot66 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot66.setDomainCrosshairValue((double) 9, true);
        org.jfree.chart.axis.NumberAxis numberAxis70 = new org.jfree.chart.axis.NumberAxis();
        numberAxis70.setFixedAutoRange((double) 9);
        org.jfree.chart.axis.NumberAxis numberAxis73 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset74 = new org.jfree.data.xy.DefaultXYDataset();
        try {
            xYBarRenderer0.drawItem(graphics2D2, (org.jfree.chart.renderer.xy.XYItemRendererState) state4, rectangle2D34, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot66, (org.jfree.chart.axis.ValueAxis) numberAxis70, (org.jfree.chart.axis.ValueAxis) numberAxis73, (org.jfree.data.xy.XYDataset) defaultXYDataset74, 0, 4, false, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.data.xy.DefaultXYDataset cannot be cast to org.jfree.data.xy.IntervalXYDataset");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(generalPath6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(textBlockAnchor31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState42);
        org.junit.Assert.assertNotNull(plotOrientation51);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(timePeriodAnchor60);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        double double3 = timeSeriesCollection1.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean7 = xYLineAndShapeRenderer6.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer6.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke11 = xYLineAndShapeRenderer6.getBaseOutlineStroke();
        java.awt.Stroke stroke13 = xYLineAndShapeRenderer6.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, valueAxis5, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer6);
        xYLineAndShapeRenderer6.setDrawSeriesLineAsPath(true);
        java.awt.Stroke stroke18 = xYLineAndShapeRenderer6.lookupSeriesOutlineStroke(4);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setStartAngle(1.0d);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape9, (java.awt.Paint) color10);
        piePlot1.setLabelLinkPaint((java.awt.Paint) color10);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer13 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Font font15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer13.setLegendTextFont((int) '#', font15);
        piePlot1.setLabelFont(font15);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        try {
            org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) 6, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (6.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState0 = new org.jfree.chart.plot.XYCrosshairState();
        java.awt.geom.Point2D point2D1 = null;
        xYCrosshairState0.setAnchor(point2D1);
        xYCrosshairState0.updateCrosshairY((double) 2958465, 6);
        xYCrosshairState0.setAnchorX(0.0d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape5, (java.awt.Paint) color6);
        org.jfree.chart.axis.Axis axis8 = null;
        try {
            org.jfree.chart.entity.AxisEntity axisEntity10 = new org.jfree.chart.entity.AxisEntity(shape5, axis8, "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getDrawOutlines();
        java.awt.Shape shape2 = xYLineAndShapeRenderer0.getBaseShape();
        java.awt.Font font4 = null;
        xYLineAndShapeRenderer0.setLegendTextFont((int) (byte) 10, font4);
        xYLineAndShapeRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        java.lang.Comparable comparable6 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) timeSeriesCollection2, comparable6);
        try {
            int int9 = timeSeriesCollection2.getItemCount(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (255).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getShadowsVisible();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator2, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        try {
            barRenderer0.setSeriesToolTipGenerator((-9999), categoryToolTipGenerator6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) waferMapPlot2);
        java.lang.Object obj4 = legendTitle3.clone();
        org.jfree.chart.entity.TitleEntity titleEntity7 = new org.jfree.chart.entity.TitleEntity(shape1, (org.jfree.chart.title.Title) legendTitle3, "hi!", "");
        legendTitle3.setVisible(true);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(true);
        java.lang.String[] strArray3 = org.jfree.data.time.SerialDate.getMonths(true);
        double[] doubleArray7 = new double[] { 1, (-9999), 0.0f };
        double[] doubleArray11 = new double[] { 1, (-9999), 0.0f };
        double[] doubleArray15 = new double[] { 1, (-9999), 0.0f };
        double[] doubleArray19 = new double[] { 1, (-9999), 0.0f };
        double[] doubleArray23 = new double[] { 1, (-9999), 0.0f };
        double[][] doubleArray24 = new double[][] { doubleArray7, doubleArray11, doubleArray15, doubleArray19, doubleArray23 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable[]) strArray1, (java.lang.Comparable[]) strArray3, doubleArray24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of row keys does not match the number of rows in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.DESCENDING;
        java.awt.Paint paint1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder(paint1);
        boolean boolean3 = domainOrder0.equals((java.lang.Object) paint1);
        java.awt.Shape shape9 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape9, (java.awt.Paint) color10);
        int int12 = color10.getTransparency();
        boolean boolean13 = domainOrder0.equals((java.lang.Object) color10);
        org.junit.Assert.assertNotNull(domainOrder0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) waferMapPlot2);
        java.awt.Font font4 = legendTitle3.getItemFont();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("DateTickUnitType.SECOND", font4);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Font font8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer6.setLegendTextFont((int) '#', font8);
        textTitle5.setFont(font8);
        java.awt.Paint paint11 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("TimePeriodAnchor.START", font8, paint11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor16 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        try {
            java.awt.Shape shape20 = textBlock12.calculateBounds(graphics2D13, 0.0f, (float) (-9999), textBlockAnchor16, 0.0f, (float) '4', (double) (-9999));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textBlock12);
        org.junit.Assert.assertNotNull(textBlockAnchor16);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 1, (int) (short) -1, (java.lang.Comparable) 3, "hi!", "index.html");
        int int8 = pieSectionEntity7.getPieIndex();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.awt.Font font2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font2);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone5 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection6 = new org.jfree.data.time.TimeSeriesCollection(timeZone5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer8 = null;
        org.jfree.chart.plot.PolarPlot polarPlot9 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection6, valueAxis7, polarItemRenderer8);
        polarPlot9.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = polarPlot9.getOrientation();
        combinedRangeXYPlot4.setOrientation(plotOrientation12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        combinedRangeXYPlot4.setDomainCrosshairPaint((java.awt.Paint) color14);
        java.awt.Paint paint16 = combinedRangeXYPlot4.getDomainCrosshairPaint();
        org.jfree.chart.text.TextBlock textBlock17 = org.jfree.chart.text.TextUtilities.createTextBlock("DateTickUnitType.SECOND", font2, paint16);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = null;
        try {
            textBlock17.setLineAlignment(horizontalAlignment18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(textBlock17);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        int int0 = java.text.NumberFormat.INTEGER_FIELD;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date0, timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelURL();
        categoryAxis0.setUpperMargin(Double.NaN);
        int int4 = categoryAxis0.getMaximumCategoryLabelLines();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getCurrencyInstance();
        numberFormat0.setMinimumFractionDigits((int) (byte) 100);
        java.util.Currency currency3 = numberFormat0.getCurrency();
        numberFormat0.setMinimumIntegerDigits(100);
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertNotNull(currency3);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range2 = xYBarRenderer0.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot4.setDomainZeroBaselineVisible(false);
        org.jfree.chart.plot.Marker marker8 = null;
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean11 = combinedRangeXYPlot4.removeDomainMarker((int) (short) 0, marker8, layer9, false);
        try {
            xYBarRenderer0.addAnnotation(xYAnnotation3, layer9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 1.0f);
        java.awt.Paint paint3 = intervalMarker2.getOutlinePaint();
        java.awt.Stroke stroke4 = intervalMarker2.getOutlineStroke();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = intervalMarker2.getLabelOffsetType();
        try {
            intervalMarker2.setAlpha((float) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(lengthAdjustmentType5);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.text.AttributedString attributedString0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeAttributedString(attributedString0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        try {
            defaultPieDataset0.insertValue(3, (java.lang.Comparable) (short) -1, (java.lang.Number) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getCurrencyInstance();
        numberFormat0.setMinimumFractionDigits((int) (byte) 100);
        boolean boolean3 = numberFormat0.isGroupingUsed();
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        org.jfree.chart.block.CenterArrangement centerArrangement1 = new org.jfree.chart.block.CenterArrangement();
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection3 = new org.jfree.data.time.TimeSeriesCollection(timeZone2);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer5 = null;
        org.jfree.chart.plot.PolarPlot polarPlot6 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection3, valueAxis4, polarItemRenderer5);
        java.lang.Comparable comparable7 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer8 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement1, (org.jfree.data.general.Dataset) timeSeriesCollection3, comparable7);
        java.lang.Number number9 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection3);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor10 = timeSeriesCollection3.getXPosition();
        try {
            java.lang.String str13 = standardXYToolTipGenerator0.generateToolTip((org.jfree.data.xy.XYDataset) timeSeriesCollection3, (int) (short) -1, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (-1).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator0);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertNotNull(timePeriodAnchor10);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.LINES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.awt.Paint paint4 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) (byte) 1, (double) 7, 0.0d, (double) 9999, paint4);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean4 = textBlockAnchor2.equals((java.lang.Object) chartRenderingInfo3);
        java.awt.geom.Rectangle2D rectangle2D5 = chartRenderingInfo3.getChartArea();
        org.jfree.chart.entity.EntityCollection entityCollection6 = chartRenderingInfo3.getEntityCollection();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean9 = textBlockAnchor7.equals((java.lang.Object) chartRenderingInfo8);
        java.awt.geom.Rectangle2D rectangle2D10 = chartRenderingInfo8.getChartArea();
        chartRenderingInfo3.setChartArea(rectangle2D10);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean16 = textBlockAnchor14.equals((java.lang.Object) chartRenderingInfo15);
        java.awt.geom.Rectangle2D rectangle2D17 = chartRenderingInfo15.getChartArea();
        org.jfree.chart.entity.EntityCollection entityCollection18 = chartRenderingInfo15.getEntityCollection();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean21 = textBlockAnchor19.equals((java.lang.Object) chartRenderingInfo20);
        java.awt.geom.Rectangle2D rectangle2D22 = chartRenderingInfo20.getChartArea();
        chartRenderingInfo15.setChartArea(rectangle2D22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = chartRenderingInfo15.getPlotInfo();
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState25 = barRenderer3D0.initialise(graphics2D1, rectangle2D10, categoryPlot12, (int) (short) -1, plotRenderingInfo24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(entityCollection6);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(textBlockAnchor14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertNotNull(entityCollection18);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(plotRenderingInfo24);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean6 = xYLineAndShapeRenderer5.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer5.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        xYLineAndShapeRenderer5.setAutoPopulateSeriesPaint(true);
        xYLineAndShapeRenderer5.setSeriesLinesVisible((int) (byte) 100, (java.lang.Boolean) false);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state17 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo16);
        java.awt.geom.GeneralPath generalPath18 = null;
        state17.seriesPath = generalPath18;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer20 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean21 = xYLineAndShapeRenderer20.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer20.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke25 = xYLineAndShapeRenderer20.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot27 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath28 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor29 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo30 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean31 = textBlockAnchor29.equals((java.lang.Object) chartRenderingInfo30);
        java.awt.geom.Rectangle2D rectangle2D32 = chartRenderingInfo30.getChartArea();
        org.jfree.chart.RenderingSource renderingSource33 = null;
        combinedRangeXYPlot27.select(generalPath28, rectangle2D32, renderingSource33);
        org.jfree.chart.plot.XYPlot xYPlot35 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset36 = new org.jfree.data.xy.DefaultXYDataset();
        int int38 = defaultXYDataset36.indexOf((java.lang.Comparable) 0.5f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState40 = xYLineAndShapeRenderer20.initialise(graphics2D26, rectangle2D32, xYPlot35, (org.jfree.data.xy.XYDataset) defaultXYDataset36, plotRenderingInfo39);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot41 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone42 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection43 = new org.jfree.data.time.TimeSeriesCollection(timeZone42);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer45 = null;
        org.jfree.chart.plot.PolarPlot polarPlot46 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection43, valueAxis44, polarItemRenderer45);
        polarPlot46.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation49 = polarPlot46.getOrientation();
        combinedRangeXYPlot41.setOrientation(plotOrientation49);
        combinedRangeXYPlot41.setRangeCrosshairValue(0.0d);
        boolean boolean53 = combinedRangeXYPlot41.isDomainCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis54 = null;
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        java.util.TimeZone timeZone56 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection57 = new org.jfree.data.time.TimeSeriesCollection(timeZone56);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor58 = timeSeriesCollection57.getXPosition();
        xYLineAndShapeRenderer5.drawItem(graphics2D15, (org.jfree.chart.renderer.xy.XYItemRendererState) state17, rectangle2D32, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot41, valueAxis54, valueAxis55, (org.jfree.data.xy.XYDataset) timeSeriesCollection57, (-1), 15, false, (-4145152));
        java.util.TimeZone timeZone64 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection65 = new org.jfree.data.time.TimeSeriesCollection(timeZone64);
        double double67 = timeSeriesCollection65.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis68 = null;
        org.jfree.chart.axis.ValueAxis valueAxis69 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer70 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean71 = xYLineAndShapeRenderer70.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer70.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke75 = xYLineAndShapeRenderer70.getBaseOutlineStroke();
        java.awt.Stroke stroke77 = xYLineAndShapeRenderer70.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot78 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection65, valueAxis68, valueAxis69, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer70);
        org.jfree.chart.util.RectangleEdge rectangleEdge80 = xYPlot78.getRangeAxisEdge(3);
        try {
            double double81 = categoryAxis3D1.getCategoryJava2DCoordinate(categoryAnchor2, (int) (byte) 1, 2, rectangle2D32, rectangleEdge80);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(textBlockAnchor29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangle2D32);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState40);
        org.junit.Assert.assertNotNull(plotOrientation49);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(timePeriodAnchor58);
        org.junit.Assert.assertEquals((double) double67, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(stroke75);
        org.junit.Assert.assertNotNull(stroke77);
        org.junit.Assert.assertNotNull(rectangleEdge80);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.awt.Image image0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeImage(image0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        java.lang.Comparable comparable6 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) timeSeriesCollection2, comparable6);
        java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection2);
        try {
            org.jfree.data.time.TimeSeries timeSeries10 = timeSeriesCollection2.getSeries(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (4).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(number8);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getPercentInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.util.Rotation rotation0 = org.jfree.chart.util.Rotation.ANTICLOCKWISE;
        org.junit.Assert.assertNotNull(rotation0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        org.jfree.chart.plot.WaferMapPlot waferMapPlot3 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.title.LegendTitle legendTitle4 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) waferMapPlot3);
        java.lang.Object obj5 = legendTitle4.clone();
        org.jfree.chart.entity.TitleEntity titleEntity8 = new org.jfree.chart.entity.TitleEntity(shape2, (org.jfree.chart.title.Title) legendTitle4, "hi!", "");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        legendTitle4.setLegendItemGraphicLocation(rectangleAnchor9);
        boolean boolean11 = rectangleEdge0.equals((java.lang.Object) legendTitle4);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.Range range14 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((double) (-1), range14);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType16 = rectangleConstraint15.getWidthConstraintType();
        org.jfree.data.Range range17 = rectangleConstraint15.getWidthRange();
        try {
            org.jfree.chart.util.Size2D size2D18 = legendTitle4.arrange(graphics2D12, rectangleConstraint15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(lengthConstraintType16);
        org.junit.Assert.assertNull(range17);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getShadowsVisible();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator2 = barRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator((int) (short) 100, categoryURLGenerator4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator2);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 1.0f);
        java.awt.Paint paint3 = intervalMarker2.getOutlinePaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType4 = intervalMarker2.getLabelOffsetType();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(lengthAdjustmentType4);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.general.DefaultPieDataset defaultPieDataset0 = new org.jfree.data.general.DefaultPieDataset();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        try {
            defaultPieDataset0.insertValue(2958465, (java.lang.Comparable) month2, (double) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        java.awt.Font font0 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 1, (int) (short) -1, (java.lang.Comparable) 3, "hi!", "index.html");
        pieSectionEntity7.setToolTipText("index.html");
        org.jfree.data.general.PieDataset pieDataset10 = pieSectionEntity7.getDataset();
        pieSectionEntity7.setSectionKey((java.lang.Comparable) 255);
        int int13 = pieSectionEntity7.getSectionIndex();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNull(pieDataset10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter3 = new org.jfree.chart.renderer.category.GradientBarPainter(0.14d, (-1.0d), (double) 100);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean6 = barRenderer5.getShadowsVisible();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = barRenderer5.getLegendItemToolTipGenerator();
        java.awt.geom.RectangularShape rectangularShape11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        try {
            gradientBarPainter3.paintBarShadow(graphics2D4, barRenderer5, 15, (int) ' ', true, rectangularShape11, rectangleEdge12, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator7);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        double double3 = timeSeriesCollection1.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean7 = xYLineAndShapeRenderer6.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer6.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke11 = xYLineAndShapeRenderer6.getBaseOutlineStroke();
        java.awt.Stroke stroke13 = xYLineAndShapeRenderer6.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, valueAxis5, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer6);
        try {
            double double17 = timeSeriesCollection1.getStartXValue(9, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        int int1 = barRenderer0.getRowCount();
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter5 = new org.jfree.chart.renderer.category.GradientBarPainter(0.14d, (-1.0d), (double) 100);
        barRenderer0.setBarPainter((org.jfree.chart.renderer.category.BarPainter) gradientBarPainter5);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator1 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("");
        java.lang.Object obj2 = standardXYSeriesLabelGenerator1.clone();
        java.util.TimeZone timeZone3 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection4 = new org.jfree.data.time.TimeSeriesCollection(timeZone3);
        try {
            java.lang.String str6 = standardXYSeriesLabelGenerator1.generateLabel((org.jfree.data.xy.XYDataset) timeSeriesCollection4, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (1).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo0);
        boolean boolean2 = state1.isLastPointGood();
        org.jfree.chart.block.CenterArrangement centerArrangement3 = new org.jfree.chart.block.CenterArrangement();
        java.util.TimeZone timeZone4 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection5 = new org.jfree.data.time.TimeSeriesCollection(timeZone4);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer7 = null;
        org.jfree.chart.plot.PolarPlot polarPlot8 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection5, valueAxis6, polarItemRenderer7);
        java.lang.Comparable comparable9 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer10 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement3, (org.jfree.data.general.Dataset) timeSeriesCollection5, comparable9);
        java.lang.Number number11 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) timeSeriesCollection5);
        state1.setSelectionState((org.jfree.data.xy.XYDatasetSelectionState) timeSeriesCollection5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(number11);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setLabel("org.jfree.chart.event.RendererChangeEvent[source=1.0]");
        org.jfree.data.Range range3 = numberAxis3D0.getRange();
        org.junit.Assert.assertNotNull(range3);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator1 = xYBarRenderer0.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter2 = org.jfree.chart.renderer.xy.XYBarRenderer.getDefaultBarPainter();
        xYBarRenderer0.setBarPainter(xYBarPainter2);
        org.junit.Assert.assertNull(xYItemLabelGenerator1);
        org.junit.Assert.assertNotNull(xYBarPainter2);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        boolean boolean5 = polarPlot4.isRadiusGridlinesVisible();
        java.awt.Paint paint6 = polarPlot4.getRadiusGridlinePaint();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) 0L, 0.025d);
        size2D2.setHeight((double) (short) 100);
        size2D2.setWidth((double) 1L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) (short) 10, categoryItemLabelGenerator2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator((-4145152), (int) (byte) 1, false);
        int int8 = barRenderer0.getRowCount();
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(9);
        int int2 = objectList1.size();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape5, (java.awt.Paint) color6);
        java.awt.Font font8 = legendItem7.getLabelFont();
        org.jfree.data.general.Dataset dataset9 = null;
        legendItem7.setDataset(dataset9);
        java.awt.Paint paint11 = legendItem7.getFillPaint();
        java.lang.String str12 = legendItem7.getURLText();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "TimePeriodAnchor.START" + "'", str12.equals("TimePeriodAnchor.START"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        java.awt.Font font0 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) (short) 10, categoryItemLabelGenerator2);
        java.awt.Shape shape5 = barRenderer0.lookupLegendShape((int) '#');
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString(64);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 64");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        polarPlot4.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = polarPlot4.getOrientation();
        polarPlot4.setAngleGridlinesVisible(true);
        polarPlot4.removeCornerTextItem("DateTickUnitType.SECOND");
        org.junit.Assert.assertNotNull(plotOrientation7);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        xYLineAndShapeRenderer0.setAutoPopulateSeriesPaint(true);
        xYLineAndShapeRenderer0.setSeriesCreateEntities((int) (short) 100, (java.lang.Boolean) false, false);
        java.awt.Shape shape12 = xYLineAndShapeRenderer0.getSeriesShape((int) (byte) 1);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset13 = new org.jfree.data.xy.DefaultXYDataset();
        int int15 = defaultXYDataset13.indexOf((java.lang.Comparable) 0.5f);
        boolean boolean16 = xYLineAndShapeRenderer0.hasListener((java.util.EventListener) defaultXYDataset13);
        xYLineAndShapeRenderer0.removeAnnotations();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(shape12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) ' ');
        java.awt.Paint paint4 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) '#');
        org.jfree.chart.plot.WaferMapPlot waferMapPlot5 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) waferMapPlot5);
        java.awt.Font font7 = legendTitle6.getItemFont();
        categoryAxis0.setLabelFont(font7);
        java.lang.String str9 = categoryAxis0.getLabelToolTip();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape5, (java.awt.Paint) color6);
        java.awt.Font font8 = legendItem7.getLabelFont();
        java.awt.Font font9 = null;
        legendItem7.setLabelFont(font9);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(font8);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        polarPlot5.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = polarPlot5.getOrientation();
        combinedRangeXYPlot0.setOrientation(plotOrientation8);
        combinedRangeXYPlot0.setRangeCrosshairValue(0.0d);
        boolean boolean12 = combinedRangeXYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisSpace axisSpace13 = new org.jfree.chart.axis.AxisSpace();
        combinedRangeXYPlot0.setFixedRangeAxisSpace(axisSpace13);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) 1.0d);
        combinedRangeXYPlot0.rendererChanged(rendererChangeEvent16);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType18 = rendererChangeEvent16.getType();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer19 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean20 = xYLineAndShapeRenderer19.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape21 = null;
        xYLineAndShapeRenderer19.setBaseLegendShape(shape21);
        boolean boolean25 = xYLineAndShapeRenderer19.getItemShapeVisible(9, (int) (byte) 0);
        boolean boolean26 = chartChangeEventType18.equals((java.lang.Object) boolean25);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date1 = null;
        try {
            java.lang.String str2 = dateTickUnit0.dateToString(date1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator1 = xYBarRenderer0.getBaseItemLabelGenerator();
        double double2 = xYBarRenderer0.getBarAlignmentFactor();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator4 = null;
        xYBarRenderer0.setSeriesItemLabelGenerator(3, xYItemLabelGenerator4, true);
        org.junit.Assert.assertNull(xYItemLabelGenerator1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot2 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0, waferMapRenderer1);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        int int2 = piePlot1.getPieIndex();
        double double3 = piePlot1.getMaximumLabelWidth();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = null;
        try {
            piePlot1.setInsets(rectangleInsets4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.14d + "'", double3 == 0.14d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers((int) (short) 10);
        java.util.List list3 = combinedRangeXYPlot0.getAnnotations();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean8 = textBlockAnchor6.equals((java.lang.Object) chartRenderingInfo7);
        java.awt.geom.Rectangle2D rectangle2D9 = chartRenderingInfo7.getChartArea();
        org.jfree.chart.entity.EntityCollection entityCollection10 = chartRenderingInfo7.getEntityCollection();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor11 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo12 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean13 = textBlockAnchor11.equals((java.lang.Object) chartRenderingInfo12);
        java.awt.geom.Rectangle2D rectangle2D14 = chartRenderingInfo12.getChartArea();
        chartRenderingInfo7.setChartArea(rectangle2D14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = chartRenderingInfo7.getPlotInfo();
        java.awt.geom.Point2D point2D17 = null;
        try {
            combinedRangeXYPlot0.zoomDomainAxes((double) 2, (double) (-1L), plotRenderingInfo16, point2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(entityCollection10);
        org.junit.Assert.assertNotNull(textBlockAnchor11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(plotRenderingInfo16);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.data.Range range2 = combinedRangeXYPlot0.getDataRange(valueAxis1);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo5 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean6 = textBlockAnchor4.equals((java.lang.Object) chartRenderingInfo5);
        java.awt.geom.Rectangle2D rectangle2D7 = chartRenderingInfo5.getChartArea();
        org.jfree.chart.entity.EntityCollection entityCollection8 = chartRenderingInfo5.getEntityCollection();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean11 = textBlockAnchor9.equals((java.lang.Object) chartRenderingInfo10);
        java.awt.geom.Rectangle2D rectangle2D12 = chartRenderingInfo10.getChartArea();
        chartRenderingInfo5.setChartArea(rectangle2D12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = chartRenderingInfo5.getPlotInfo();
        java.awt.geom.Point2D point2D15 = null;
        try {
            combinedRangeXYPlot0.zoomDomainAxes(0.0d, plotRenderingInfo14, point2D15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'source' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(entityCollection8);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(plotRenderingInfo14);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke5 = xYLineAndShapeRenderer0.getBaseOutlineStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYLineAndShapeRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.general.PieDataset pieDataset8 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity14 = new org.jfree.chart.entity.PieSectionEntity(shape7, pieDataset8, 1, (int) (short) -1, (java.lang.Comparable) 3, "hi!", "index.html");
        xYLineAndShapeRenderer0.setBaseShape(shape7, true);
        boolean boolean17 = xYLineAndShapeRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        double double3 = timeSeriesCollection1.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean7 = xYLineAndShapeRenderer6.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer6.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke11 = xYLineAndShapeRenderer6.getBaseOutlineStroke();
        java.awt.Stroke stroke13 = xYLineAndShapeRenderer6.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, valueAxis5, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer6);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = xYPlot14.getInsets();
        xYPlot14.setRangeCrosshairValue((double) 10L);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder18 = null;
        try {
            xYPlot14.setSeriesRenderingOrder(seriesRenderingOrder18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabelAngle(0.025d);
        java.lang.Object obj3 = categoryAxis0.clone();
        org.jfree.chart.plot.WaferMapPlot waferMapPlot7 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) waferMapPlot7);
        java.awt.Font font9 = legendTitle8.getItemFont();
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("DateTickUnitType.SECOND", font9);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Font font13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer11.setLegendTextFont((int) '#', font13);
        textTitle10.setFont(font13);
        java.awt.Paint paint16 = textTitle10.getBackgroundPaint();
        java.awt.geom.Rectangle2D rectangle2D17 = textTitle10.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        try {
            double double19 = categoryAxis0.getCategoryMiddle(100, (int) (byte) 1, rectangle2D17, rectangleEdge18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(rectangle2D17);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo0);
        boolean boolean2 = state1.isLastPointGood();
        java.awt.geom.Line2D line2D3 = null;
        state1.workingLine = line2D3;
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        java.awt.geom.Line2D line2D0 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean2 = xYLineAndShapeRenderer1.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer1.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        xYLineAndShapeRenderer1.setAutoPopulateSeriesPaint(true);
        xYLineAndShapeRenderer1.setSeriesLinesVisible((int) (byte) 100, (java.lang.Boolean) false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state13 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo12);
        java.awt.geom.GeneralPath generalPath14 = null;
        state13.seriesPath = generalPath14;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean17 = xYLineAndShapeRenderer16.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer16.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke21 = xYLineAndShapeRenderer16.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot23 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath24 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor25 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean27 = textBlockAnchor25.equals((java.lang.Object) chartRenderingInfo26);
        java.awt.geom.Rectangle2D rectangle2D28 = chartRenderingInfo26.getChartArea();
        org.jfree.chart.RenderingSource renderingSource29 = null;
        combinedRangeXYPlot23.select(generalPath24, rectangle2D28, renderingSource29);
        org.jfree.chart.plot.XYPlot xYPlot31 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset32 = new org.jfree.data.xy.DefaultXYDataset();
        int int34 = defaultXYDataset32.indexOf((java.lang.Comparable) 0.5f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState36 = xYLineAndShapeRenderer16.initialise(graphics2D22, rectangle2D28, xYPlot31, (org.jfree.data.xy.XYDataset) defaultXYDataset32, plotRenderingInfo35);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot37 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection39 = new org.jfree.data.time.TimeSeriesCollection(timeZone38);
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer41 = null;
        org.jfree.chart.plot.PolarPlot polarPlot42 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection39, valueAxis40, polarItemRenderer41);
        polarPlot42.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation45 = polarPlot42.getOrientation();
        combinedRangeXYPlot37.setOrientation(plotOrientation45);
        combinedRangeXYPlot37.setRangeCrosshairValue(0.0d);
        boolean boolean49 = combinedRangeXYPlot37.isDomainCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        java.util.TimeZone timeZone52 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection53 = new org.jfree.data.time.TimeSeriesCollection(timeZone52);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor54 = timeSeriesCollection53.getXPosition();
        xYLineAndShapeRenderer1.drawItem(graphics2D11, (org.jfree.chart.renderer.xy.XYItemRendererState) state13, rectangle2D28, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot37, valueAxis50, valueAxis51, (org.jfree.data.xy.XYDataset) timeSeriesCollection53, (-1), 15, false, (-4145152));
        try {
            boolean boolean60 = org.jfree.chart.util.ShapeUtilities.clipLine(line2D0, rectangle2D28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(textBlockAnchor25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState36);
        org.junit.Assert.assertNotNull(plotOrientation45);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(timePeriodAnchor54);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelURL();
        categoryAxis0.setUpperMargin(Double.NaN);
        categoryAxis0.setAxisLineVisible(false);
        float float6 = categoryAxis0.getMinorTickMarkInsideLength();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.data.time.DateRange dateRange3 = new org.jfree.data.time.DateRange((double) 0.0f, (double) 1);
        boolean boolean4 = range0.intersects((org.jfree.data.Range) dateRange3);
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) 15);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) waferMapPlot1);
        java.awt.Font font3 = legendTitle2.getItemFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("DateTickUnitType.SECOND", font3);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer5.setLegendTextFont((int) '#', font7);
        textTitle4.setFont(font7);
        java.awt.Paint paint10 = textTitle4.getBackgroundPaint();
        java.awt.geom.Rectangle2D rectangle2D11 = textTitle4.getBounds();
        org.jfree.chart.event.TitleChangeListener titleChangeListener12 = null;
        textTitle4.addChangeListener(titleChangeListener12);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(rectangle2D11);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true);
        xYSeries2.fireSeriesChanged();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries2);
        try {
            java.lang.Number number7 = xYSeriesCollection4.getEndY(500, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 500, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation1 = axisLocation0.getOpposite();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(axisLocation1);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "hi!" + "'", str0.equals("hi!"));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState2 = timeSeriesCollection1.getSelectionState();
        timeSeriesCollection1.clearSelection();
        org.junit.Assert.assertNotNull(xYDatasetSelectionState2);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setLabel("org.jfree.chart.event.RendererChangeEvent[source=1.0]");
        numberAxis3D0.setAutoRangeStickyZero(false);
        java.awt.Font font5 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        numberAxis3D0.setTickLabelFont(font5);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) (short) 10, categoryItemLabelGenerator2);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = barRenderer0.getURLGenerator((-4145152), (int) (byte) 1, false);
        int int8 = barRenderer0.getColumnCount();
        boolean boolean12 = barRenderer0.getItemCreateEntity(0, 15, true);
        barRenderer0.setShadowVisible(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator15 = barRenderer0.getLegendItemLabelGenerator();
        org.junit.Assert.assertNull(categoryURLGenerator7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator15);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getShadowsVisible();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = barRenderer0.getBaseURLGenerator();
        barRenderer0.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = barRenderer0.getSeriesItemLabelGenerator(2958465);
        double double7 = barRenderer0.getLowerClip();
        double double8 = barRenderer0.getBase();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState10 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer11 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean12 = xYLineAndShapeRenderer11.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer11.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke16 = xYLineAndShapeRenderer11.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot18 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath19 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor20 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean22 = textBlockAnchor20.equals((java.lang.Object) chartRenderingInfo21);
        java.awt.geom.Rectangle2D rectangle2D23 = chartRenderingInfo21.getChartArea();
        org.jfree.chart.RenderingSource renderingSource24 = null;
        combinedRangeXYPlot18.select(generalPath19, rectangle2D23, renderingSource24);
        org.jfree.chart.plot.XYPlot xYPlot26 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset27 = new org.jfree.data.xy.DefaultXYDataset();
        int int29 = defaultXYDataset27.indexOf((java.lang.Comparable) 0.5f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState31 = xYLineAndShapeRenderer11.initialise(graphics2D17, rectangle2D23, xYPlot26, (org.jfree.data.xy.XYDataset) defaultXYDataset27, plotRenderingInfo30);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        categoryAxis33.setLabelPaint((java.awt.Paint) color34);
        double double36 = categoryAxis33.getLowerMargin();
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer38 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer38.setAutoPopulateSeriesStroke(false);
        barRenderer38.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer43 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray46 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset47 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray46);
        org.jfree.data.Range range48 = barRenderer43.findRangeBounds(categoryDataset47);
        org.jfree.data.Range range49 = barRenderer38.findRangeBounds(categoryDataset47);
        try {
            barRenderer0.drawItem(graphics2D9, categoryItemRendererState10, rectangle2D23, categoryPlot32, categoryAxis33, valueAxis37, categoryDataset47, 1, (int) 'a', false, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNull(categoryItemLabelGenerator6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(textBlockAnchor20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState31);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.05d + "'", double36 == 0.05d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(categoryDataset47);
        org.junit.Assert.assertNull(range48);
        org.junit.Assert.assertNull(range49);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean4 = textBlockAnchor2.equals((java.lang.Object) chartRenderingInfo3);
        java.awt.geom.Rectangle2D rectangle2D5 = chartRenderingInfo3.getChartArea();
        org.jfree.chart.RenderingSource renderingSource6 = null;
        combinedRangeXYPlot0.select(generalPath1, rectangle2D5, renderingSource6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean11 = textBlockAnchor9.equals((java.lang.Object) chartRenderingInfo10);
        java.awt.geom.Rectangle2D rectangle2D12 = chartRenderingInfo10.getChartArea();
        try {
            combinedRangeXYPlot0.drawBackground(graphics2D8, rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangle2D12);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.junit.Assert.assertNull(range1);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        try {
            org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity4 = new org.jfree.chart.entity.JFreeChartEntity(shape1, jFreeChart2, "TimePeriodAnchor.START");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'chart' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Shape shape1 = org.jfree.chart.util.SerialUtilities.readShape(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        polarPlot5.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = polarPlot5.getOrientation();
        combinedRangeXYPlot0.setOrientation(plotOrientation8);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean11 = xYLineAndShapeRenderer10.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer10.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke15 = xYLineAndShapeRenderer10.getBaseOutlineStroke();
        java.awt.Stroke stroke17 = xYLineAndShapeRenderer10.lookupSeriesStroke(4);
        combinedRangeXYPlot0.setDomainCrosshairStroke(stroke17);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        numberAxis19.setFixedAutoRange((double) 9);
        combinedRangeXYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis19);
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis19.setLeftArrow(shape24);
        java.lang.String str26 = numberAxis19.getLabelURL();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit27 = numberAxis19.getTickUnit();
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(numberTickUnit27);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true);
        xYSeries2.fireSeriesChanged();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries2);
        boolean boolean5 = xYSeriesCollection4.isAutoWidth();
        try {
            java.lang.Number number8 = xYSeriesCollection4.getX(6, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Font font2 = xYLineAndShapeRenderer0.getBaseItemLabelFont();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation3 = null;
        try {
            xYLineAndShapeRenderer0.addAnnotation(xYAnnotation3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke5 = xYLineAndShapeRenderer0.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath8 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean11 = textBlockAnchor9.equals((java.lang.Object) chartRenderingInfo10);
        java.awt.geom.Rectangle2D rectangle2D12 = chartRenderingInfo10.getChartArea();
        org.jfree.chart.RenderingSource renderingSource13 = null;
        combinedRangeXYPlot7.select(generalPath8, rectangle2D12, renderingSource13);
        org.jfree.chart.plot.XYPlot xYPlot15 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset16 = new org.jfree.data.xy.DefaultXYDataset();
        int int18 = defaultXYDataset16.indexOf((java.lang.Comparable) 0.5f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState20 = xYLineAndShapeRenderer0.initialise(graphics2D6, rectangle2D12, xYPlot15, (org.jfree.data.xy.XYDataset) defaultXYDataset16, plotRenderingInfo19);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Shape shape22 = numberAxis3D21.getDownArrow();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer23 = null;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) defaultXYDataset16, (org.jfree.chart.axis.ValueAxis) numberAxis3D21, polarItemRenderer23);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot26 = new org.jfree.chart.plot.WaferMapPlot();
        java.lang.Object obj27 = waferMapPlot26.clone();
        java.awt.Image image28 = null;
        waferMapPlot26.setBackgroundImage(image28);
        org.jfree.chart.plot.WaferMapPlot waferMapPlot31 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.title.LegendTitle legendTitle32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) waferMapPlot31);
        java.awt.Font font33 = legendTitle32.getItemFont();
        org.jfree.chart.title.TextTitle textTitle34 = new org.jfree.chart.title.TextTitle("DateTickUnitType.SECOND", font33);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer35 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Font font37 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer35.setLegendTextFont((int) '#', font37);
        textTitle34.setFont(font37);
        java.awt.Paint paint40 = textTitle34.getBackgroundPaint();
        java.awt.geom.Rectangle2D rectangle2D41 = textTitle34.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = org.jfree.chart.util.RectangleEdge.BOTTOM;
        org.jfree.chart.axis.AxisSpace axisSpace43 = new org.jfree.chart.axis.AxisSpace();
        try {
            org.jfree.chart.axis.AxisSpace axisSpace44 = numberAxis3D21.reserveSpace(graphics2D25, (org.jfree.chart.plot.Plot) waferMapPlot26, rectangle2D41, rectangleEdge42, axisSpace43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState20);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNull(paint40);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(rectangleEdge42);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        xYLineAndShapeRenderer0.setAutoPopulateSeriesPaint(true);
        xYLineAndShapeRenderer0.setSeriesCreateEntities((int) (short) 100, (java.lang.Boolean) false, false);
        java.awt.Shape shape12 = xYLineAndShapeRenderer0.getSeriesShape((int) (byte) 1);
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset13 = new org.jfree.data.xy.DefaultXYDataset();
        int int15 = defaultXYDataset13.indexOf((java.lang.Comparable) 0.5f);
        boolean boolean16 = xYLineAndShapeRenderer0.hasListener((java.util.EventListener) defaultXYDataset13);
        xYLineAndShapeRenderer0.setDefaultEntityRadius(10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(shape12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        java.util.TimeZone timeZone1 = null;
        java.util.Locale locale2 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis("", timeZone1, locale2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        int int2 = piePlot1.getPieIndex();
        org.jfree.data.general.PieDataset pieDataset3 = null;
        org.jfree.chart.plot.PiePlot piePlot4 = new org.jfree.chart.plot.PiePlot(pieDataset3);
        piePlot4.setStartAngle(1.0d);
        java.awt.Paint paint7 = piePlot4.getLabelLinkPaint();
        piePlot1.setLabelPaint(paint7);
        java.awt.Paint paint9 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        piePlot1.setLabelBackgroundPaint(paint9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Paint paint1 = barRenderer3D0.getWallPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray1 = basicProjectInfo0.getOptionalLibraries();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo2 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str3 = basicProjectInfo2.getName();
        basicProjectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo2);
        basicProjectInfo2.setLicenceName("EXPAND");
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getLGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape5, (java.awt.Paint) color6);
        java.awt.Font font8 = legendItem7.getLabelFont();
        boolean boolean9 = legendItem7.isShapeVisible();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(font8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setStartAngle(1.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.lang.String str6 = dateTickUnit4.valueToString((double) 2);
        int int7 = dateTickUnit4.getMultiple();
        int int8 = dateTickUnit4.getMinorTickCount();
        java.awt.Stroke stroke9 = piePlot1.getSectionOutlineStroke((java.lang.Comparable) int8);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "12/31/69 4:00 PM" + "'", str6.equals("12/31/69 4:00 PM"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNull(stroke9);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) ' ');
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) (byte) 0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        double double3 = timeSeriesCollection1.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean7 = xYLineAndShapeRenderer6.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer6.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke11 = xYLineAndShapeRenderer6.getBaseOutlineStroke();
        java.awt.Stroke stroke13 = xYLineAndShapeRenderer6.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, valueAxis5, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer6);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = xYPlot14.getInsets();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYPlot14.setNoDataMessagePaint((java.awt.Paint) color16);
        org.jfree.chart.axis.LogAxis logAxis18 = new org.jfree.chart.axis.LogAxis();
        boolean boolean19 = logAxis18.isTickMarksVisible();
        java.awt.Paint paint20 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder(paint20);
        java.awt.Paint paint22 = blockBorder21.getPaint();
        logAxis18.setTickMarkPaint(paint22);
        int int24 = xYPlot14.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis18);
        java.awt.Shape shape25 = null;
        try {
            logAxis18.setLeftArrow(shape25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState0 = new org.jfree.chart.plot.XYCrosshairState();
        java.awt.geom.Point2D point2D1 = null;
        xYCrosshairState0.setAnchor(point2D1);
        xYCrosshairState0.updateCrosshairY((double) 2958465, 6);
        xYCrosshairState0.updateCrosshairY((double) (-9999));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        java.lang.String str1 = basicProjectInfo0.getName();
        java.lang.String str2 = basicProjectInfo0.getCopyright();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator1 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("org.jfree.chart.event.RendererChangeEvent[source=1.0]");
        java.lang.Object obj2 = null;
        boolean boolean3 = standardXYSeriesLabelGenerator1.equals(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        int int0 = org.jfree.chart.renderer.xy.XYStepAreaRenderer.SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 1, (int) (short) -1, (java.lang.Comparable) 3, "hi!", "index.html");
        pieSectionEntity7.setPieIndex(0);
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0);
        xYAreaRenderer1.setOutline(false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelURL();
        java.awt.Font font3 = categoryAxis0.getTickLabelFont((java.lang.Comparable) (byte) 100);
        double double4 = categoryAxis0.getFixedDimension();
        boolean boolean5 = categoryAxis0.isTickMarksVisible();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(64, (int) (short) 10, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYLineAndShapeRenderer0.getNegativeItemLabelPosition(1, (int) (short) 10, true);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        xYLineAndShapeRenderer0.setSeriesShape(10, shape11);
        xYLineAndShapeRenderer0.setBaseLinesVisible(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, 0.0d, (double) (short) 10);
        org.jfree.chart.block.BlockContainer blockContainer5 = null;
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.data.Range range8 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((double) (-1), range8);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType10 = rectangleConstraint9.getWidthConstraintType();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType11 = rectangleConstraint9.getHeightConstraintType();
        try {
            org.jfree.chart.util.Size2D size2D12 = columnArrangement4.arrange(blockContainer5, graphics2D6, rectangleConstraint9);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(verticalAlignment1);
        org.junit.Assert.assertNotNull(lengthConstraintType10);
        org.junit.Assert.assertNotNull(lengthConstraintType11);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        polarPlot4.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation7 = polarPlot4.getOrientation();
        org.jfree.chart.axis.TickUnit tickUnit8 = null;
        try {
            polarPlot4.setAngleTickUnit(tickUnit8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation7);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        boolean boolean1 = logAxis0.isTickMarksVisible();
        double double2 = logAxis0.getUpperBound();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = new org.jfree.chart.axis.AxisState();
        axisState4.cursorLeft((double) 100);
        org.jfree.chart.plot.WaferMapPlot waferMapPlot8 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) waferMapPlot8);
        java.awt.Font font10 = legendTitle9.getItemFont();
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("DateTickUnitType.SECOND", font10);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer12 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Font font14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer12.setLegendTextFont((int) '#', font14);
        textTitle11.setFont(font14);
        java.awt.Paint paint17 = textTitle11.getBackgroundPaint();
        java.awt.geom.Rectangle2D rectangle2D18 = textTitle11.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.util.RectangleEdge.TOP;
        try {
            java.util.List list20 = logAxis0.refreshTicks(graphics2D3, axisState4, rectangle2D18, rectangleEdge19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke5 = xYLineAndShapeRenderer0.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath8 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean11 = textBlockAnchor9.equals((java.lang.Object) chartRenderingInfo10);
        java.awt.geom.Rectangle2D rectangle2D12 = chartRenderingInfo10.getChartArea();
        org.jfree.chart.RenderingSource renderingSource13 = null;
        combinedRangeXYPlot7.select(generalPath8, rectangle2D12, renderingSource13);
        org.jfree.chart.plot.XYPlot xYPlot15 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset16 = new org.jfree.data.xy.DefaultXYDataset();
        int int18 = defaultXYDataset16.indexOf((java.lang.Comparable) 0.5f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState20 = xYLineAndShapeRenderer0.initialise(graphics2D6, rectangle2D12, xYPlot15, (org.jfree.data.xy.XYDataset) defaultXYDataset16, plotRenderingInfo19);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Shape shape22 = numberAxis3D21.getDownArrow();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer23 = null;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) defaultXYDataset16, (org.jfree.chart.axis.ValueAxis) numberAxis3D21, polarItemRenderer23);
        try {
            double double27 = defaultXYDataset16.getXValue(0, 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState20);
        org.junit.Assert.assertNotNull(shape22);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo3 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean4 = textBlockAnchor2.equals((java.lang.Object) chartRenderingInfo3);
        java.awt.geom.Rectangle2D rectangle2D5 = chartRenderingInfo3.getChartArea();
        org.jfree.chart.RenderingSource renderingSource6 = null;
        combinedRangeXYPlot0.select(generalPath1, rectangle2D5, renderingSource6);
        java.awt.Paint paint8 = combinedRangeXYPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot10.setDomainZeroBaselineVisible(false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot13.setDomainCrosshairValue((double) 9, true);
        boolean boolean17 = combinedRangeXYPlot13.isDomainCrosshairLockedOnData();
        combinedRangeXYPlot10.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot13);
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 1.0f);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot22 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot22.setDomainZeroBaselineVisible(false);
        org.jfree.chart.plot.Marker marker26 = null;
        org.jfree.chart.util.Layer layer27 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean29 = combinedRangeXYPlot22.removeDomainMarker((int) (short) 0, marker26, layer27, false);
        combinedRangeXYPlot13.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker21, layer27);
        org.jfree.chart.util.Layer layer31 = null;
        try {
            combinedRangeXYPlot0.addDomainMarker(500, (org.jfree.chart.plot.Marker) intervalMarker21, layer31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(rectangle2D5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(layer27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true);
        xYSeries2.fireSeriesChanged();
        try {
            xYSeries2.delete((int) 'a', 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: toIndex = 16");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true);
        xYSeries2.fireSeriesChanged();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries2);
        xYSeries2.setMaximumItemCount((int) ' ');
        org.jfree.data.xy.XYDataItem xYDataItem9 = xYSeries2.addOrUpdate((double) (byte) 1, 0.0d);
        org.junit.Assert.assertNull(xYDataItem9);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape2 = null;
        xYLineAndShapeRenderer0.setBaseLegendShape(shape2);
        xYLineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, false);
        java.awt.Stroke stroke9 = xYLineAndShapeRenderer0.getSeriesStroke((int) '4');
        boolean boolean11 = xYLineAndShapeRenderer0.isSeriesVisibleInLegend(9999);
        xYLineAndShapeRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        java.awt.Graphics2D graphics2D14 = null;
        java.util.TimeZone timeZone15 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection16 = new org.jfree.data.time.TimeSeriesCollection(timeZone15);
        double double18 = timeSeriesCollection16.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer21 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean22 = xYLineAndShapeRenderer21.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer21.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke26 = xYLineAndShapeRenderer21.getBaseOutlineStroke();
        java.awt.Stroke stroke28 = xYLineAndShapeRenderer21.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection16, valueAxis19, valueAxis20, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer21);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = xYPlot29.getInsets();
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        xYPlot29.setNoDataMessagePaint((java.awt.Paint) color31);
        org.jfree.chart.axis.LogAxis logAxis33 = new org.jfree.chart.axis.LogAxis();
        boolean boolean34 = logAxis33.isTickMarksVisible();
        java.awt.Paint paint35 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder36 = new org.jfree.chart.block.BlockBorder(paint35);
        java.awt.Paint paint37 = blockBorder36.getPaint();
        logAxis33.setTickMarkPaint(paint37);
        int int39 = xYPlot29.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) logAxis33);
        xYPlot29.clearRangeMarkers();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D41 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Shape shape42 = numberAxis3D41.getDownArrow();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot43 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath44 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor45 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo46 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean47 = textBlockAnchor45.equals((java.lang.Object) chartRenderingInfo46);
        java.awt.geom.Rectangle2D rectangle2D48 = chartRenderingInfo46.getChartArea();
        org.jfree.chart.RenderingSource renderingSource49 = null;
        combinedRangeXYPlot43.select(generalPath44, rectangle2D48, renderingSource49);
        java.util.TimeZone timeZone52 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection53 = new org.jfree.data.time.TimeSeriesCollection(timeZone52);
        double double55 = timeSeriesCollection53.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis56 = null;
        org.jfree.chart.axis.ValueAxis valueAxis57 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer58 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean59 = xYLineAndShapeRenderer58.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer58.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke63 = xYLineAndShapeRenderer58.getBaseOutlineStroke();
        java.awt.Stroke stroke65 = xYLineAndShapeRenderer58.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot66 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection53, valueAxis56, valueAxis57, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer58);
        org.jfree.chart.block.LineBorder lineBorder68 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint69 = lineBorder68.getPaint();
        xYLineAndShapeRenderer58.setSeriesItemLabelPaint((int) (short) 0, paint69, false);
        java.util.TimeZone timeZone72 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection73 = new org.jfree.data.time.TimeSeriesCollection(timeZone72);
        double double75 = timeSeriesCollection73.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis76 = null;
        org.jfree.chart.axis.ValueAxis valueAxis77 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer78 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean79 = xYLineAndShapeRenderer78.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer78.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke83 = xYLineAndShapeRenderer78.getBaseOutlineStroke();
        java.awt.Stroke stroke85 = xYLineAndShapeRenderer78.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot86 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection73, valueAxis76, valueAxis77, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer78);
        org.jfree.chart.util.RectangleInsets rectangleInsets87 = xYPlot86.getInsets();
        xYPlot86.setNotify(true);
        java.awt.Stroke stroke90 = xYPlot86.getDomainMinorGridlineStroke();
        try {
            xYLineAndShapeRenderer0.drawDomainLine(graphics2D14, xYPlot29, (org.jfree.chart.axis.ValueAxis) numberAxis3D41, rectangle2D48, (double) 0.5f, paint69, stroke90);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertEquals((double) double18, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(textBlockAnchor45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertEquals((double) double55, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertEquals((double) double75, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(stroke83);
        org.junit.Assert.assertNotNull(stroke85);
        org.junit.Assert.assertNotNull(rectangleInsets87);
        org.junit.Assert.assertNotNull(stroke90);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        xYLineAndShapeRenderer0.setAutoPopulateSeriesPaint(true);
        xYLineAndShapeRenderer0.setSeriesCreateEntities((int) (short) 100, (java.lang.Boolean) false, false);
        xYLineAndShapeRenderer0.removeAnnotations();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape2 = null;
        xYLineAndShapeRenderer0.setBaseLegendShape(shape2);
        xYLineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, false);
        java.awt.Stroke stroke9 = xYLineAndShapeRenderer0.getSeriesStroke((int) '4');
        xYLineAndShapeRenderer0.setSeriesItemLabelsVisible(8, (java.lang.Boolean) false, true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator17 = xYLineAndShapeRenderer0.getItemLabelGenerator(6, (int) 'a', false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(stroke9);
        org.junit.Assert.assertNull(xYItemLabelGenerator17);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state1 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo0);
        boolean boolean2 = state1.getProcessVisibleItemsOnly();
        java.awt.geom.GeneralPath generalPath3 = state1.seriesPath;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset4 = new org.jfree.data.xy.DefaultXYDataset();
        int int6 = defaultXYDataset4.indexOf((java.lang.Comparable) 0.5f);
        state1.endSeriesPass((org.jfree.data.xy.XYDataset) defaultXYDataset4, (int) (short) 100, 0, (int) (short) 10, (int) (byte) 0, 64);
        state1.setLastPointGood(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(generalPath3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator1 = xYBarRenderer0.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset2 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range3 = xYBarRenderer0.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset2);
        double double4 = xYBarRenderer0.getShadowXOffset();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean6 = xYLineAndShapeRenderer5.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer5.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke10 = xYLineAndShapeRenderer5.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath13 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo15 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean16 = textBlockAnchor14.equals((java.lang.Object) chartRenderingInfo15);
        java.awt.geom.Rectangle2D rectangle2D17 = chartRenderingInfo15.getChartArea();
        org.jfree.chart.RenderingSource renderingSource18 = null;
        combinedRangeXYPlot12.select(generalPath13, rectangle2D17, renderingSource18);
        org.jfree.chart.plot.XYPlot xYPlot20 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset21 = new org.jfree.data.xy.DefaultXYDataset();
        int int23 = defaultXYDataset21.indexOf((java.lang.Comparable) 0.5f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState25 = xYLineAndShapeRenderer5.initialise(graphics2D11, rectangle2D17, xYPlot20, (org.jfree.data.xy.XYDataset) defaultXYDataset21, plotRenderingInfo24);
        org.jfree.data.Range range26 = xYBarRenderer0.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset21);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = xYBarRenderer0.getNegativeItemLabelPosition((int) (short) 10, 100, true);
        org.junit.Assert.assertNull(xYItemLabelGenerator1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(textBlockAnchor14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState25);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNotNull(itemLabelPosition30);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.HOUR_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 3600000L + "'", long0 == 3600000L);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke5 = xYLineAndShapeRenderer0.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath8 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean11 = textBlockAnchor9.equals((java.lang.Object) chartRenderingInfo10);
        java.awt.geom.Rectangle2D rectangle2D12 = chartRenderingInfo10.getChartArea();
        org.jfree.chart.RenderingSource renderingSource13 = null;
        combinedRangeXYPlot7.select(generalPath8, rectangle2D12, renderingSource13);
        org.jfree.chart.plot.XYPlot xYPlot15 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset16 = new org.jfree.data.xy.DefaultXYDataset();
        int int18 = defaultXYDataset16.indexOf((java.lang.Comparable) 0.5f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState20 = xYLineAndShapeRenderer0.initialise(graphics2D6, rectangle2D12, xYPlot15, (org.jfree.data.xy.XYDataset) defaultXYDataset16, plotRenderingInfo19);
        org.jfree.chart.entity.EntityCollection entityCollection21 = xYItemRendererState20.getEntityCollection();
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection23 = new org.jfree.data.time.TimeSeriesCollection(timeZone22);
        double double25 = timeSeriesCollection23.getDomainLowerBound(false);
        boolean boolean26 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.xy.XYDataset) timeSeriesCollection23);
        xYItemRendererState20.startSeriesPass((org.jfree.data.xy.XYDataset) timeSeriesCollection23, 1, 1, 100, 1, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState20);
        org.junit.Assert.assertNull(entityCollection21);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint3 = xYLineAndShapeRenderer0.lookupLegendTextPaint((int) (short) 100);
        xYLineAndShapeRenderer0.setAutoPopulateSeriesShape(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.chart.JFreeChart jFreeChart2 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) timeZone0, jFreeChart2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.awt.Shape shape5 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("", "hi!", "TimePeriodAnchor.START", "TimePeriodAnchor.START", shape5, (java.awt.Paint) color6);
        int int8 = color6.getGreen();
        int int9 = color6.getRed();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 64 + "'", int8 == 64);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) 1.0d);
        java.lang.Object obj2 = rendererChangeEvent1.getRenderer();
        java.lang.Object obj3 = rendererChangeEvent1.getRenderer();
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        rendererChangeEvent1.setChart(jFreeChart4);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection(timeZone7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection8, valueAxis9, polarItemRenderer10);
        polarPlot11.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = polarPlot11.getOrientation();
        combinedRangeXYPlot6.setOrientation(plotOrientation14);
        combinedRangeXYPlot6.setRangeCrosshairValue(0.0d);
        boolean boolean18 = combinedRangeXYPlot6.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisSpace axisSpace19 = new org.jfree.chart.axis.AxisSpace();
        combinedRangeXYPlot6.setFixedRangeAxisSpace(axisSpace19);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent22 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) 1.0d);
        combinedRangeXYPlot6.rendererChanged(rendererChangeEvent22);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType24 = rendererChangeEvent22.getType();
        rendererChangeEvent1.setType(chartChangeEventType24);
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 1.0d + "'", obj2.equals(1.0d));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 1.0d + "'", obj3.equals(1.0d));
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType24);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.setDomainZeroBaselineVisible(false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot3.setDomainCrosshairValue((double) 9, true);
        boolean boolean7 = combinedRangeXYPlot3.isDomainCrosshairLockedOnData();
        combinedRangeXYPlot0.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean11 = xYLineAndShapeRenderer10.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape12 = null;
        xYLineAndShapeRenderer10.setBaseLegendShape(shape12);
        xYLineAndShapeRenderer10.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, false);
        xYLineAndShapeRenderer10.setSeriesCreateEntities((int) (short) 0, (java.lang.Boolean) true);
        java.lang.Object obj21 = xYLineAndShapeRenderer10.clone();
        combinedRangeXYPlot3.setRenderer((int) '4', (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer10, true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYLineAndShapeRenderer0.getNegativeItemLabelPosition(1, (int) (short) 10, true);
        boolean boolean9 = xYLineAndShapeRenderer0.getAutoPopulateSeriesShape();
        java.util.TimeZone timeZone10 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection11 = new org.jfree.data.time.TimeSeriesCollection(timeZone10);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer13 = null;
        org.jfree.chart.plot.PolarPlot polarPlot14 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection11, valueAxis12, polarItemRenderer13);
        java.awt.Paint paint15 = polarPlot14.getAngleLabelPaint();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean17 = xYLineAndShapeRenderer16.getAutoPopulateSeriesOutlinePaint();
        java.awt.Font font18 = xYLineAndShapeRenderer16.getBaseItemLabelFont();
        polarPlot14.setAngleLabelFont(font18);
        xYLineAndShapeRenderer0.setBaseLegendTextFont(font18);
        java.awt.Paint paint22 = xYLineAndShapeRenderer0.lookupSeriesOutlinePaint((int) (byte) -1);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot24 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot24.setDomainZeroBaselineVisible(false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot27 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot27.setDomainCrosshairValue((double) 9, true);
        boolean boolean31 = combinedRangeXYPlot27.isDomainCrosshairLockedOnData();
        combinedRangeXYPlot24.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot27);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D33 = new org.jfree.chart.axis.NumberAxis3D();
        java.awt.Shape shape34 = numberAxis3D33.getDownArrow();
        combinedRangeXYPlot24.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D33);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent36 = null;
        combinedRangeXYPlot24.axisChanged(axisChangeEvent36);
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis("EXPAND");
        org.jfree.chart.plot.IntervalMarker intervalMarker42 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 1.0f);
        java.awt.Paint paint43 = intervalMarker42.getOutlinePaint();
        java.awt.Stroke stroke44 = intervalMarker42.getOutlineStroke();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer45 = null;
        intervalMarker42.setGradientPaintTransformer(gradientPaintTransformer45);
        float float47 = intervalMarker42.getAlpha();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent48 = null;
        intervalMarker42.notifyListeners(markerChangeEvent48);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor50 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo51 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean52 = textBlockAnchor50.equals((java.lang.Object) chartRenderingInfo51);
        java.awt.geom.Rectangle2D rectangle2D53 = chartRenderingInfo51.getChartArea();
        org.jfree.chart.entity.EntityCollection entityCollection54 = chartRenderingInfo51.getEntityCollection();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor55 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo56 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean57 = textBlockAnchor55.equals((java.lang.Object) chartRenderingInfo56);
        java.awt.geom.Rectangle2D rectangle2D58 = chartRenderingInfo56.getChartArea();
        chartRenderingInfo51.setChartArea(rectangle2D58);
        try {
            xYLineAndShapeRenderer0.drawDomainMarker(graphics2D23, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot24, (org.jfree.chart.axis.ValueAxis) dateAxis39, (org.jfree.chart.plot.Marker) intervalMarker42, rectangle2D58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 0.8f + "'", float47 == 0.8f);
        org.junit.Assert.assertNotNull(textBlockAnchor50);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(entityCollection54);
        org.junit.Assert.assertNotNull(textBlockAnchor55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(rectangle2D58);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getShadowsVisible();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = barRenderer0.getBaseURLGenerator();
        barRenderer0.setAutoPopulateSeriesShape(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(categoryURLGenerator2);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("Layer.FOREGROUND", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = xYBarRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator2 = xYBarRenderer0.getBaseToolTipGenerator();
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNull(xYToolTipGenerator2);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean7 = xYLineAndShapeRenderer6.getBaseShapesVisible();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = xYLineAndShapeRenderer6.getDrawingSupplier();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = xYLineAndShapeRenderer6.getNegativeItemLabelPosition(4, (int) (byte) 100, true);
        xYLineAndShapeRenderer0.setSeriesNegativeItemLabelPosition((int) (short) 1, itemLabelPosition12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(drawingSupplier8);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        polarPlot4.setAngleGridlinesVisible(false);
        polarPlot4.setAngleGridlinesVisible(false);
        boolean boolean9 = polarPlot4.isRadiusGridlinesVisible();
        java.awt.Font font10 = polarPlot4.getNoDataMessageFont();
        java.awt.Paint paint11 = polarPlot4.getAngleLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        java.lang.String str0 = org.jfree.chart.urls.StandardXYURLGenerator.DEFAULT_SERIES_PARAMETER;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "series" + "'", str0.equals("series"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        java.lang.String str1 = rangeType0.toString();
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RangeType.FULL" + "'", str1.equals("RangeType.FULL"));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        polarPlot5.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = polarPlot5.getOrientation();
        combinedRangeXYPlot0.setOrientation(plotOrientation8);
        combinedRangeXYPlot0.setRangeCrosshairValue(0.0d);
        boolean boolean12 = combinedRangeXYPlot0.isDomainCrosshairVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean14 = barRenderer13.getShadowsVisible();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = barRenderer13.getBaseURLGenerator();
        barRenderer13.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator19 = barRenderer13.getSeriesItemLabelGenerator(2958465);
        double double20 = barRenderer13.getLowerClip();
        double double21 = barRenderer13.getBase();
        java.awt.Paint paint23 = barRenderer13.lookupSeriesFillPaint(8);
        combinedRangeXYPlot0.setDomainZeroBaselinePaint(paint23);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(categoryURLGenerator15);
        org.junit.Assert.assertNull(categoryItemLabelGenerator19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(true);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setGenerateEntities(true);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        polarPlot5.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = polarPlot5.getOrientation();
        combinedRangeXYPlot0.setOrientation(plotOrientation8);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer10 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean11 = xYLineAndShapeRenderer10.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer10.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke15 = xYLineAndShapeRenderer10.getBaseOutlineStroke();
        java.awt.Stroke stroke17 = xYLineAndShapeRenderer10.lookupSeriesStroke(4);
        combinedRangeXYPlot0.setDomainCrosshairStroke(stroke17);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        numberAxis19.setFixedAutoRange((double) 9);
        combinedRangeXYPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis19);
        java.awt.Shape shape24 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis19.setLeftArrow(shape24);
        numberAxis19.setAutoRangeIncludesZero(false);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(shape24);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        double double3 = timeSeriesCollection1.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean7 = xYLineAndShapeRenderer6.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer6.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke11 = xYLineAndShapeRenderer6.getBaseOutlineStroke();
        java.awt.Stroke stroke13 = xYLineAndShapeRenderer6.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, valueAxis5, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer6);
        boolean boolean15 = xYPlot14.isDomainZoomable();
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        java.lang.String str2 = piePlot1.getPlotType();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Pie Plot" + "'", str2.equals("Pie Plot"));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        polarPlot4.setAngleGridlinesVisible(false);
        polarPlot4.setAngleGridlinesVisible(false);
        boolean boolean10 = polarPlot4.equals((java.lang.Object) 0.0f);
        java.lang.String str11 = polarPlot4.getPlotType();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Polar Plot" + "'", str11.equals("Polar Plot"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 1, (int) (short) -1, (java.lang.Comparable) 3, "hi!", "index.html");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot8 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot8.setDomainZeroBaselineVisible(false);
        combinedRangeXYPlot8.setDomainGridlinesVisible(false);
        org.jfree.chart.entity.PlotEntity plotEntity15 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) combinedRangeXYPlot8, "EXPAND", "");
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer16.setAutoPopulateSeriesStroke(false);
        barRenderer16.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray24 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset25 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray24);
        org.jfree.data.Range range26 = barRenderer21.findRangeBounds(categoryDataset25);
        org.jfree.data.Range range27 = barRenderer16.findRangeBounds(categoryDataset25);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis28.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot31 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone32 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection33 = new org.jfree.data.time.TimeSeriesCollection(timeZone32);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer35 = null;
        org.jfree.chart.plot.PolarPlot polarPlot36 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection33, valueAxis34, polarItemRenderer35);
        polarPlot36.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation39 = polarPlot36.getOrientation();
        combinedRangeXYPlot31.setOrientation(plotOrientation39);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer41 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean42 = xYLineAndShapeRenderer41.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer41.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke46 = xYLineAndShapeRenderer41.getBaseOutlineStroke();
        java.awt.Stroke stroke48 = xYLineAndShapeRenderer41.lookupSeriesStroke(4);
        combinedRangeXYPlot31.setDomainCrosshairStroke(stroke48);
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis();
        numberAxis50.setFixedAutoRange((double) 9);
        combinedRangeXYPlot31.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis50);
        java.awt.Shape shape55 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis50.setLeftArrow(shape55);
        java.text.NumberFormat numberFormat57 = java.text.NumberFormat.getNumberInstance();
        boolean boolean58 = numberFormat57.isParseIntegerOnly();
        numberAxis50.setNumberFormatOverride(numberFormat57);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer60 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot61 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis28, (org.jfree.chart.axis.ValueAxis) numberAxis50, categoryItemRenderer60);
        boolean boolean62 = plotEntity15.equals((java.lang.Object) categoryItemRenderer60);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(categoryDataset25);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertNotNull(plotOrientation39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(shape55);
        org.junit.Assert.assertNotNull(numberFormat57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setItemMargin((double) (-2208960000000L));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        java.lang.String str1 = rectangleEdge0.toString();
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleEdge.TOP" + "'", str1.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer(0);
        boolean boolean2 = xYAreaRenderer1.getPlotShapes();
        java.lang.Object obj3 = xYAreaRenderer1.clone();
        org.jfree.chart.LegendItem legendItem6 = xYAreaRenderer1.getLegendItem(10, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(legendItem6);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) 15);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesStroke(false);
        barRenderer0.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray8 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray8);
        org.jfree.data.Range range10 = barRenderer5.findRangeBounds(categoryDataset9);
        org.jfree.data.Range range11 = barRenderer0.findRangeBounds(categoryDataset9);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot15 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone16 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection17 = new org.jfree.data.time.TimeSeriesCollection(timeZone16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer19 = null;
        org.jfree.chart.plot.PolarPlot polarPlot20 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection17, valueAxis18, polarItemRenderer19);
        polarPlot20.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = polarPlot20.getOrientation();
        combinedRangeXYPlot15.setOrientation(plotOrientation23);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer25 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean26 = xYLineAndShapeRenderer25.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer25.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke30 = xYLineAndShapeRenderer25.getBaseOutlineStroke();
        java.awt.Stroke stroke32 = xYLineAndShapeRenderer25.lookupSeriesStroke(4);
        combinedRangeXYPlot15.setDomainCrosshairStroke(stroke32);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        numberAxis34.setFixedAutoRange((double) 9);
        combinedRangeXYPlot15.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis34);
        java.awt.Shape shape39 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis34.setLeftArrow(shape39);
        java.text.NumberFormat numberFormat41 = java.text.NumberFormat.getNumberInstance();
        boolean boolean42 = numberFormat41.isParseIntegerOnly();
        numberAxis34.setNumberFormatOverride(numberFormat41);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis34, categoryItemRenderer44);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D46.setLabel("org.jfree.chart.event.RendererChangeEvent[source=1.0]");
        org.jfree.data.Range range49 = categoryPlot45.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D46);
        numberAxis3D46.setPositiveArrowVisible(false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(numberFormat41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(range49);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) (short) 10, categoryItemLabelGenerator2);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer5.setAutoPopulateSeriesStroke(false);
        barRenderer5.setIncludeBaseInRange(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        double[][] doubleArray13 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset14 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray13);
        org.jfree.data.Range range15 = barRenderer10.findRangeBounds(categoryDataset14);
        org.jfree.data.Range range16 = barRenderer5.findRangeBounds(categoryDataset14);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis17.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot20 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection22 = new org.jfree.data.time.TimeSeriesCollection(timeZone21);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer24 = null;
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection22, valueAxis23, polarItemRenderer24);
        polarPlot25.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation28 = polarPlot25.getOrientation();
        combinedRangeXYPlot20.setOrientation(plotOrientation28);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer30 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean31 = xYLineAndShapeRenderer30.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer30.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke35 = xYLineAndShapeRenderer30.getBaseOutlineStroke();
        java.awt.Stroke stroke37 = xYLineAndShapeRenderer30.lookupSeriesStroke(4);
        combinedRangeXYPlot20.setDomainCrosshairStroke(stroke37);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis();
        numberAxis39.setFixedAutoRange((double) 9);
        combinedRangeXYPlot20.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis39);
        java.awt.Shape shape44 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis39.setLeftArrow(shape44);
        java.text.NumberFormat numberFormat46 = java.text.NumberFormat.getNumberInstance();
        boolean boolean47 = numberFormat46.isParseIntegerOnly();
        numberAxis39.setNumberFormatOverride(numberFormat46);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis17, (org.jfree.chart.axis.ValueAxis) numberAxis39, categoryItemRenderer49);
        categoryPlot50.clearDomainMarkers();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor52 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo53 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean54 = textBlockAnchor52.equals((java.lang.Object) chartRenderingInfo53);
        java.awt.geom.Rectangle2D rectangle2D55 = chartRenderingInfo53.getChartArea();
        org.jfree.chart.entity.EntityCollection entityCollection56 = chartRenderingInfo53.getEntityCollection();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor57 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo58 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean59 = textBlockAnchor57.equals((java.lang.Object) chartRenderingInfo58);
        java.awt.geom.Rectangle2D rectangle2D60 = chartRenderingInfo58.getChartArea();
        chartRenderingInfo53.setChartArea(rectangle2D60);
        java.util.TimeZone timeZone63 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection64 = new org.jfree.data.time.TimeSeriesCollection(timeZone63);
        double double66 = timeSeriesCollection64.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis67 = null;
        org.jfree.chart.axis.ValueAxis valueAxis68 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer69 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean70 = xYLineAndShapeRenderer69.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer69.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke74 = xYLineAndShapeRenderer69.getBaseOutlineStroke();
        java.awt.Stroke stroke76 = xYLineAndShapeRenderer69.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot77 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection64, valueAxis67, valueAxis68, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer69);
        org.jfree.chart.block.LineBorder lineBorder79 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint80 = lineBorder79.getPaint();
        xYLineAndShapeRenderer69.setSeriesItemLabelPaint((int) (short) 0, paint80, false);
        java.awt.Stroke stroke83 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        try {
            barRenderer0.drawDomainLine(graphics2D4, categoryPlot50, rectangle2D60, (double) 100L, paint80, stroke83);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(categoryDataset14);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(plotOrientation28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(numberFormat46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertNotNull(entityCollection56);
        org.junit.Assert.assertNotNull(textBlockAnchor57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertEquals((double) double66, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(stroke76);
        org.junit.Assert.assertNotNull(paint80);
        org.junit.Assert.assertNotNull(stroke83);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        piePlot1.setStartAngle(1.0d);
        java.awt.Image image4 = null;
        piePlot1.setBackgroundImage(image4);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator6 = piePlot1.getLegendLabelURLGenerator();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = piePlot1.getLegendLabelGenerator();
        org.junit.Assert.assertNull(pieURLGenerator6);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator7);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true);
        xYSeries2.fireSeriesChanged();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries2);
        boolean boolean5 = xYSeriesCollection4.isAutoWidth();
        org.jfree.data.Range range7 = xYSeriesCollection4.getRangeBounds(true);
        try {
            int int9 = xYSeriesCollection4.getItemCount(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(range7);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.xy.XYSeries xYSeries2 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "hi!", true);
        xYSeries2.fireSeriesChanged();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection4 = new org.jfree.data.xy.XYSeriesCollection(xYSeries2);
        org.jfree.data.xy.XYDataItem xYDataItem5 = null;
        try {
            xYSeries2.add(xYDataItem5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState2 = timeSeriesCollection1.getSelectionState();
        java.util.List list3 = timeSeriesCollection1.getSeries();
        int int5 = timeSeriesCollection1.indexOf((java.lang.Comparable) 1.0f);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate7 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection1, true);
        try {
            java.lang.Number number10 = timeSeriesCollection1.getX(0, 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(xYDatasetSelectionState2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.String str1 = categoryAxis0.getLabelURL();
        categoryAxis0.setUpperMargin(Double.NaN);
        categoryAxis0.setAxisLineVisible(false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection(timeZone7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection8, valueAxis9, polarItemRenderer10);
        polarPlot11.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = polarPlot11.getOrientation();
        combinedRangeXYPlot6.setOrientation(plotOrientation14);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean17 = xYLineAndShapeRenderer16.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer16.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke21 = xYLineAndShapeRenderer16.getBaseOutlineStroke();
        java.awt.Stroke stroke23 = xYLineAndShapeRenderer16.lookupSeriesStroke(4);
        combinedRangeXYPlot6.setDomainCrosshairStroke(stroke23);
        categoryAxis0.setAxisLineStroke(stroke23);
        java.awt.Font font26 = null;
        try {
            categoryAxis0.setLabelFont(font26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator1 = xYBarRenderer0.getBaseItemLabelGenerator();
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset2 = new org.jfree.data.xy.DefaultXYDataset();
        org.jfree.data.Range range3 = xYBarRenderer0.findDomainBounds((org.jfree.data.xy.XYDataset) defaultXYDataset2);
        double double4 = xYBarRenderer0.getShadowXOffset();
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection(timeZone6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection7, valueAxis8, polarItemRenderer9);
        polarPlot10.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = polarPlot10.getOrientation();
        combinedRangeXYPlot5.setOrientation(plotOrientation13);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer15 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean16 = xYLineAndShapeRenderer15.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer15.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke20 = xYLineAndShapeRenderer15.getBaseOutlineStroke();
        java.awt.Stroke stroke22 = xYLineAndShapeRenderer15.lookupSeriesStroke(4);
        combinedRangeXYPlot5.setDomainCrosshairStroke(stroke22);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        numberAxis24.setFixedAutoRange((double) 9);
        combinedRangeXYPlot5.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis24);
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) '4');
        numberAxis24.setLeftArrow(shape29);
        xYBarRenderer0.setBaseShape(shape29, true);
        org.junit.Assert.assertNull(xYItemLabelGenerator1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(shape29);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("rect");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name rect, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        int int2 = piePlot1.getPieIndex();
        double double3 = piePlot1.getMaximumLabelWidth();
        java.awt.Paint paint4 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        piePlot1.setLabelBackgroundPaint(paint4);
        org.jfree.chart.LegendItemCollection legendItemCollection6 = piePlot1.getLegendItems();
        int int7 = legendItemCollection6.getItemCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.14d + "'", double3 == 0.14d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(legendItemCollection6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = xYBarRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Shape shape2 = xYBarRenderer0.getLegendBar();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer4 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean5 = xYLineAndShapeRenderer4.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer4.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        xYLineAndShapeRenderer4.setAutoPopulateSeriesPaint(true);
        xYLineAndShapeRenderer4.setSeriesLinesVisible((int) (byte) 100, (java.lang.Boolean) false);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State state16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer.State(plotRenderingInfo15);
        java.awt.geom.GeneralPath generalPath17 = null;
        state16.seriesPath = generalPath17;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer19 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean20 = xYLineAndShapeRenderer19.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer19.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke24 = xYLineAndShapeRenderer19.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot26 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.geom.GeneralPath generalPath27 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor28 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo29 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean30 = textBlockAnchor28.equals((java.lang.Object) chartRenderingInfo29);
        java.awt.geom.Rectangle2D rectangle2D31 = chartRenderingInfo29.getChartArea();
        org.jfree.chart.RenderingSource renderingSource32 = null;
        combinedRangeXYPlot26.select(generalPath27, rectangle2D31, renderingSource32);
        org.jfree.chart.plot.XYPlot xYPlot34 = null;
        org.jfree.data.xy.DefaultXYDataset defaultXYDataset35 = new org.jfree.data.xy.DefaultXYDataset();
        int int37 = defaultXYDataset35.indexOf((java.lang.Comparable) 0.5f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState39 = xYLineAndShapeRenderer19.initialise(graphics2D25, rectangle2D31, xYPlot34, (org.jfree.data.xy.XYDataset) defaultXYDataset35, plotRenderingInfo38);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot40 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone41 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection42 = new org.jfree.data.time.TimeSeriesCollection(timeZone41);
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer44 = null;
        org.jfree.chart.plot.PolarPlot polarPlot45 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection42, valueAxis43, polarItemRenderer44);
        polarPlot45.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation48 = polarPlot45.getOrientation();
        combinedRangeXYPlot40.setOrientation(plotOrientation48);
        combinedRangeXYPlot40.setRangeCrosshairValue(0.0d);
        boolean boolean52 = combinedRangeXYPlot40.isDomainCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        org.jfree.chart.axis.ValueAxis valueAxis54 = null;
        java.util.TimeZone timeZone55 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection56 = new org.jfree.data.time.TimeSeriesCollection(timeZone55);
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor57 = timeSeriesCollection56.getXPosition();
        xYLineAndShapeRenderer4.drawItem(graphics2D14, (org.jfree.chart.renderer.xy.XYItemRendererState) state16, rectangle2D31, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot40, valueAxis53, valueAxis54, (org.jfree.data.xy.XYDataset) timeSeriesCollection56, (-1), 15, false, (-4145152));
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot63 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot63.setDomainZeroBaselineVisible(false);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot66 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot66.setDomainCrosshairValue((double) 9, true);
        boolean boolean70 = combinedRangeXYPlot66.isDomainCrosshairLockedOnData();
        combinedRangeXYPlot63.add((org.jfree.chart.plot.XYPlot) combinedRangeXYPlot66);
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer72 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection73 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range74 = xYBarRenderer72.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection73);
        java.lang.Object obj75 = timeSeriesCollection73.clone();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor76 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo77 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean78 = textBlockAnchor76.equals((java.lang.Object) chartRenderingInfo77);
        java.awt.geom.Rectangle2D rectangle2D79 = chartRenderingInfo77.getChartArea();
        org.jfree.chart.entity.EntityCollection entityCollection80 = chartRenderingInfo77.getEntityCollection();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor81 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo82 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean83 = textBlockAnchor81.equals((java.lang.Object) chartRenderingInfo82);
        java.awt.geom.Rectangle2D rectangle2D84 = chartRenderingInfo82.getChartArea();
        chartRenderingInfo77.setChartArea(rectangle2D84);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo86 = chartRenderingInfo77.getPlotInfo();
        try {
            org.jfree.chart.renderer.xy.XYItemRendererState xYItemRendererState87 = xYBarRenderer0.initialise(graphics2D3, rectangle2D31, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot66, (org.jfree.data.xy.XYDataset) timeSeriesCollection73, plotRenderingInfo86);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index -1 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(textBlockAnchor28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(rectangle2D31);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(xYItemRendererState39);
        org.junit.Assert.assertNotNull(plotOrientation48);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(timePeriodAnchor57);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertNull(range74);
        org.junit.Assert.assertNotNull(obj75);
        org.junit.Assert.assertNotNull(textBlockAnchor76);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(rectangle2D79);
        org.junit.Assert.assertNotNull(entityCollection80);
        org.junit.Assert.assertNotNull(textBlockAnchor81);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(rectangle2D84);
        org.junit.Assert.assertNotNull(plotRenderingInfo86);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) waferMapPlot1);
        java.awt.Font font3 = legendTitle2.getItemFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("DateTickUnitType.SECOND", font3);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer5.setLegendTextFont((int) '#', font7);
        textTitle4.setFont(font7);
        textTitle4.setVisible(true);
        java.awt.Font font12 = textTitle4.getFont();
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        logAxis0.setSmallestValue((double) 7);
        logAxis0.setPositiveArrowVisible(true);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState0 = new org.jfree.chart.plot.XYCrosshairState();
        java.awt.geom.Point2D point2D1 = xYCrosshairState0.getAnchor();
        xYCrosshairState0.setAnchorX((double) 10);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot10 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone11 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection12 = new org.jfree.data.time.TimeSeriesCollection(timeZone11);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer14 = null;
        org.jfree.chart.plot.PolarPlot polarPlot15 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection12, valueAxis13, polarItemRenderer14);
        polarPlot15.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation18 = polarPlot15.getOrientation();
        combinedRangeXYPlot10.setOrientation(plotOrientation18);
        xYCrosshairState0.updateCrosshairPoint((double) (-2208960000000L), (double) (byte) 10, 2958465, (int) (short) 0, (double) (-1), (double) 64, plotOrientation18);
        org.junit.Assert.assertNull(point2D1);
        org.junit.Assert.assertNotNull(plotOrientation18);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint3 = xYLineAndShapeRenderer0.lookupLegendTextPaint((int) (short) 100);
        xYLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(true);
        boolean boolean6 = xYLineAndShapeRenderer0.getBaseLinesVisible();
        java.awt.Font font7 = xYLineAndShapeRenderer0.getBaseItemLabelFont();
        java.awt.Font font8 = xYLineAndShapeRenderer0.getBaseItemLabelFont();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean9 = textBlockAnchor7.equals((java.lang.Object) chartRenderingInfo8);
        java.awt.geom.Rectangle2D rectangle2D10 = chartRenderingInfo8.getChartArea();
        org.jfree.chart.entity.EntityCollection entityCollection11 = chartRenderingInfo8.getEntityCollection();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = new org.jfree.chart.ChartRenderingInfo();
        boolean boolean14 = textBlockAnchor12.equals((java.lang.Object) chartRenderingInfo13);
        java.awt.geom.Rectangle2D rectangle2D15 = chartRenderingInfo13.getChartArea();
        chartRenderingInfo8.setChartArea(rectangle2D15);
        java.util.TimeZone timeZone17 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection18 = new org.jfree.data.time.TimeSeriesCollection(timeZone17);
        double double20 = timeSeriesCollection18.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer23 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean24 = xYLineAndShapeRenderer23.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer23.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke28 = xYLineAndShapeRenderer23.getBaseOutlineStroke();
        java.awt.Stroke stroke30 = xYLineAndShapeRenderer23.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection18, valueAxis21, valueAxis22, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer23);
        org.jfree.chart.block.LineBorder lineBorder33 = new org.jfree.chart.block.LineBorder();
        java.awt.Paint paint34 = lineBorder33.getPaint();
        xYLineAndShapeRenderer23.setSeriesItemLabelPaint((int) (short) 0, paint34, false);
        boolean boolean37 = chartRenderingInfo8.equals((java.lang.Object) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = chartRenderingInfo8.getPlotInfo();
        java.awt.geom.Point2D point2D39 = null;
        try {
            polarPlot4.zoomRangeAxes((double) (short) -1, Double.NaN, plotRenderingInfo38, point2D39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(entityCollection11);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertEquals((double) double20, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(plotRenderingInfo38);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        org.jfree.chart.plot.PiePlot piePlot1 = new org.jfree.chart.plot.PiePlot(pieDataset0);
        int int2 = piePlot1.getPieIndex();
        double double3 = piePlot1.getMaximumLabelWidth();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType4 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType4, (int) (short) 100);
        org.jfree.data.time.DateRange dateRange7 = new org.jfree.data.time.DateRange();
        java.util.Date date8 = dateRange7.getUpperDate();
        java.util.Date date9 = dateTickUnit6.rollDate(date8);
        double double10 = piePlot1.getExplodePercent((java.lang.Comparable) date9);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.14d + "'", double3 == 0.14d);
        org.junit.Assert.assertNotNull(dateTickUnitType4);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 1, (int) (short) -1, (java.lang.Comparable) 3, "hi!", "index.html");
        java.lang.Object obj8 = null;
        boolean boolean9 = pieSectionEntity7.equals(obj8);
        java.awt.Shape shape10 = pieSectionEntity7.getArea();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape2 = null;
        xYLineAndShapeRenderer0.setBaseLegendShape(shape2);
        xYLineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, false);
        xYLineAndShapeRenderer0.setSeriesCreateEntities((int) (short) 0, (java.lang.Boolean) true);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator12 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYLineAndShapeRenderer0.setSeriesToolTipGenerator((int) '4', (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator12);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator14 = xYLineAndShapeRenderer0.getLegendItemToolTipGenerator();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator12);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator14);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.DomainOrder domainOrder1 = org.jfree.data.DomainOrder.DESCENDING;
        java.awt.Paint paint2 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.jfree.chart.block.BlockBorder blockBorder3 = new org.jfree.chart.block.BlockBorder(paint2);
        boolean boolean4 = domainOrder1.equals((java.lang.Object) paint2);
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot5 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.util.TimeZone timeZone6 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection(timeZone6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer9 = null;
        org.jfree.chart.plot.PolarPlot polarPlot10 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection7, valueAxis8, polarItemRenderer9);
        polarPlot10.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = polarPlot10.getOrientation();
        combinedRangeXYPlot5.setOrientation(plotOrientation13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        combinedRangeXYPlot5.setDomainCrosshairPaint((java.awt.Paint) color15);
        boolean boolean17 = org.jfree.chart.util.PaintUtilities.equal(paint2, (java.awt.Paint) color15);
        java.awt.Color color18 = java.awt.Color.getColor("DateTickUnitType.SECOND", color15);
        org.junit.Assert.assertNotNull(domainOrder1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        double double3 = timeSeriesCollection1.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean7 = xYLineAndShapeRenderer6.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer6.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke11 = xYLineAndShapeRenderer6.getBaseOutlineStroke();
        java.awt.Stroke stroke13 = xYLineAndShapeRenderer6.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, valueAxis5, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer6);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = xYPlot14.getInsets();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean17 = xYLineAndShapeRenderer16.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer16.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke21 = xYLineAndShapeRenderer16.getBaseOutlineStroke();
        java.awt.Stroke stroke23 = xYLineAndShapeRenderer16.lookupSeriesStroke(4);
        xYPlot14.setDomainGridlineStroke(stroke23);
        boolean boolean25 = xYPlot14.isRangeCrosshairVisible();
        boolean boolean26 = xYPlot14.isDomainMinorGridlinesVisible();
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.general.PieDataset pieDataset1 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity7 = new org.jfree.chart.entity.PieSectionEntity(shape0, pieDataset1, 1, (int) (short) -1, (java.lang.Comparable) 3, "hi!", "index.html");
        java.lang.Object obj8 = null;
        boolean boolean9 = pieSectionEntity7.equals(obj8);
        java.lang.Object obj10 = pieSectionEntity7.clone();
        java.lang.String str11 = pieSectionEntity7.getURLText();
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator12 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator13 = null;
        try {
            java.lang.String str14 = pieSectionEntity7.getImageMapAreaTag(toolTipTagFragmentGenerator12, uRLTagFragmentGenerator13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "index.html" + "'", str11.equals("index.html"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYLineAndShapeRenderer0.getNegativeItemLabelPosition(1, (int) (short) 10, true);
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-1L));
        xYLineAndShapeRenderer0.setSeriesShape(10, shape11);
        java.awt.Paint paint16 = xYLineAndShapeRenderer0.getItemOutlinePaint(2, (int) 'a', false);
        java.awt.Shape shape20 = xYLineAndShapeRenderer0.getItemShape((-9999), (int) 'a', false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(shape20);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getShadowsVisible();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = barRenderer0.getBaseURLGenerator();
        barRenderer0.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator5, false);
        java.awt.Font font8 = barRenderer0.getBaseItemLabelFont();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(categoryURLGenerator2);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        org.jfree.data.time.TimeSeries timeSeries5 = null;
        try {
            timeSeriesCollection1.addSeries(timeSeries5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        xYBarRenderer0.removeAnnotations();
        xYBarRenderer0.setShadowVisible(true);
        xYBarRenderer0.clearSeriesPaints(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = xYBarRenderer0.getBasePositiveItemLabelPosition();
        boolean boolean7 = xYBarRenderer0.getBaseCreateEntities();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        boolean boolean4 = textAnchor2.equals((java.lang.Object) (byte) 0);
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        boolean boolean7 = textAnchor5.equals((java.lang.Object) (byte) 0);
        org.jfree.chart.axis.NumberTick numberTick9 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (-4145152), "ERROR : Relative To String", textAnchor2, textAnchor5, (double) (short) 0);
        org.jfree.chart.text.TextAnchor textAnchor10 = numberTick9.getRotationAnchor();
        java.lang.String str11 = numberTick9.getText();
        java.lang.Object obj12 = numberTick9.clone();
        java.lang.String str13 = numberTick9.toString();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ERROR : Relative To String" + "'", str11.equals("ERROR : Relative To String"));
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "ERROR : Relative To String" + "'", str13.equals("ERROR : Relative To String"));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        java.awt.Color color0 = java.awt.Color.black;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        boolean boolean4 = color1.equals((java.lang.Object) 'a');
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.color.ColorSpace colorSpace6 = color5.getColorSpace();
        float[] floatArray10 = new float[] { (short) 100, 3, 0L };
        float[] floatArray11 = color1.getColorComponents(colorSpace6, floatArray10);
        float[] floatArray12 = color0.getRGBColorComponents(floatArray10);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(colorSpace6);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.setDomainZeroBaselineVisible(false);
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean7 = combinedRangeXYPlot0.removeDomainMarker((int) (short) 0, marker4, layer5, false);
        org.jfree.chart.axis.AxisLocation axisLocation8 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation9 = axisLocation8.getOpposite();
        combinedRangeXYPlot0.setDomainAxisLocation(axisLocation9, false);
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        try {
            combinedRangeXYPlot0.setDomainAxisLocation(axisLocation12, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer0.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Paint paint5 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYLineAndShapeRenderer0.setBasePaint(paint5, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = xYLineAndShapeRenderer0.getPositiveItemLabelPosition(0, (int) (short) 1, false);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer13 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean14 = xYLineAndShapeRenderer13.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape15 = null;
        xYLineAndShapeRenderer13.setBaseLegendShape(shape15);
        xYLineAndShapeRenderer13.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, false);
        xYLineAndShapeRenderer13.setSeriesCreateEntities((int) (short) 0, (java.lang.Boolean) true);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator25 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYLineAndShapeRenderer13.setSeriesToolTipGenerator((int) '4', (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator25);
        xYLineAndShapeRenderer0.setSeriesToolTipGenerator((int) (short) 1, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator25, true);
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator30 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        xYLineAndShapeRenderer0.setSeriesToolTipGenerator((int) '4', (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator30);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator25);
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator30);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState0 = new org.jfree.chart.plot.XYCrosshairState();
        xYCrosshairState0.updateCrosshairY((double) (short) 0, (-4145152));
        java.awt.geom.Point2D point2D4 = xYCrosshairState0.getAnchor();
        org.junit.Assert.assertNull(point2D4);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint3 = xYLineAndShapeRenderer0.lookupLegendTextPaint((int) (short) 100);
        xYLineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(true);
        boolean boolean6 = xYLineAndShapeRenderer0.getBaseLinesVisible();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = xYLineAndShapeRenderer0.getSeriesNegativeItemLabelPosition(64);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState0 = new org.jfree.chart.plot.XYCrosshairState();
        xYCrosshairState0.updateCrosshairY((double) (short) 0, (-4145152));
        java.util.TimeZone timeZone8 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection9 = new org.jfree.data.time.TimeSeriesCollection(timeZone8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection9, valueAxis10, polarItemRenderer11);
        polarPlot12.setAngleGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = polarPlot12.getOrientation();
        xYCrosshairState0.updateCrosshairPoint((double) 1.0f, (double) 0.0f, (double) 100L, (double) 0L, plotOrientation15);
        double double17 = xYCrosshairState0.getAnchorX();
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.setDomainCrosshairValue((double) 9, true);
        boolean boolean4 = combinedRangeXYPlot0.isDomainCrosshairLockedOnData();
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean6 = xYLineAndShapeRenderer5.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer5.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Paint paint11 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        xYLineAndShapeRenderer5.setLegendTextPaint(1, paint11);
        int int13 = combinedRangeXYPlot0.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer5);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) 0.0f, (double) 1);
        java.lang.String str3 = dateRange2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]" + "'", str3.equals("[Dec 31, 1969 4:00:00 PM --> Dec 31, 1969 4:00:00 PM]"));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray1 = basicProjectInfo0.getOptionalLibraries();
        java.lang.String str2 = basicProjectInfo0.getInfo();
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType1 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType1, (int) (short) 100);
        org.jfree.data.time.DateRange dateRange4 = new org.jfree.data.time.DateRange();
        java.util.Date date5 = dateRange4.getUpperDate();
        java.util.Date date6 = dateTickUnit3.rollDate(date5);
        boolean boolean7 = blockContainer0.equals((java.lang.Object) date6);
        org.jfree.chart.plot.WaferMapPlot waferMapPlot9 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.title.LegendTitle legendTitle10 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) waferMapPlot9);
        java.awt.Font font11 = legendTitle10.getItemFont();
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("DateTickUnitType.SECOND", font11);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer13 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Font font15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer13.setLegendTextFont((int) '#', font15);
        textTitle12.setFont(font15);
        blockContainer0.add((org.jfree.chart.block.Block) textTitle12);
        org.junit.Assert.assertNotNull(dateTickUnitType1);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(font15);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        double double3 = timeSeriesCollection1.getDomainLowerBound(false);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer6 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean7 = xYLineAndShapeRenderer6.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer6.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke11 = xYLineAndShapeRenderer6.getBaseOutlineStroke();
        java.awt.Stroke stroke13 = xYLineAndShapeRenderer6.lookupSeriesStroke(4);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis4, valueAxis5, (org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer6);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = xYPlot14.getInsets();
        xYPlot14.clearRangeMarkers();
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleInsets15);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            java.awt.Shape shape7 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("{0}", graphics2D1, (float) (-1L), 0.0f, (double) 10L, (float) (byte) -1, (float) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getNumberInstance();
        boolean boolean2 = numberFormat1.isParseIntegerOnly();
        int int3 = numberFormat1.getMinimumIntegerDigits();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = new org.jfree.chart.axis.NumberTickUnit(0.0d, numberFormat1, 2958465);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.ASCENDING;
        org.junit.Assert.assertNotNull(domainOrder0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(true);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = org.jfree.chart.labels.StandardXYToolTipGenerator.getTimeSeriesInstance();
        java.lang.String str1 = standardXYToolTipGenerator0.getNullYString();
        org.junit.Assert.assertNotNull(standardXYToolTipGenerator0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "null" + "'", str1.equals("null"));
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer3 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean4 = xYLineAndShapeRenderer3.getAutoPopulateSeriesOutlinePaint();
        xYLineAndShapeRenderer3.setSeriesLinesVisible((int) (byte) 1, (java.lang.Boolean) false);
        java.awt.Stroke stroke8 = xYLineAndShapeRenderer3.getBaseOutlineStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = xYLineAndShapeRenderer3.getBasePositiveItemLabelPosition();
        java.awt.Shape shape10 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.data.general.PieDataset pieDataset11 = null;
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity17 = new org.jfree.chart.entity.PieSectionEntity(shape10, pieDataset11, 1, (int) (short) -1, (java.lang.Comparable) 3, "hi!", "index.html");
        xYLineAndShapeRenderer3.setBaseShape(shape10, true);
        int int20 = combinedRangeXYPlot0.getIndexOf((org.jfree.chart.renderer.xy.XYItemRenderer) xYLineAndShapeRenderer3);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis("EXPAND");
        combinedRangeXYPlot0.setDomainAxis((org.jfree.chart.axis.ValueAxis) dateAxis22);
        boolean boolean24 = dateAxis22.isTickMarksVisible();
        try {
            dateAxis22.zoomRange((double) 500, (double) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (500.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("org.jfree.chart.event.RendererChangeEvent[source=1.0]");
        textTitle1.setText("null");
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.color.ColorSpace colorSpace4 = color3.getColorSpace();
        boolean boolean6 = color3.equals((java.lang.Object) 'a');
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_BLUE;
        java.awt.color.ColorSpace colorSpace8 = color7.getColorSpace();
        float[] floatArray12 = new float[] { (short) 100, 3, 0L };
        float[] floatArray13 = color3.getColorComponents(colorSpace8, floatArray12);
        float[] floatArray14 = java.awt.Color.RGBtoHSB((int) ' ', 15, (int) (byte) 100, floatArray12);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(colorSpace4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(colorSpace8);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(0.2d, range1);
        double double3 = range1.getLowerBound();
        boolean boolean5 = range1.contains((double) '#');
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        java.util.TimeZone timeZone1 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection(timeZone1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer4 = null;
        org.jfree.chart.plot.PolarPlot polarPlot5 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection2, valueAxis3, polarItemRenderer4);
        java.lang.Comparable comparable6 = null;
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) centerArrangement0, (org.jfree.data.general.Dataset) timeSeriesCollection2, comparable6);
        org.jfree.chart.block.Arrangement arrangement8 = legendItemBlockContainer7.getArrangement();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.data.Range range11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((double) (-1), range11);
        try {
            org.jfree.chart.util.Size2D size2D13 = legendItemBlockContainer7.arrange(graphics2D9, rectangleConstraint12);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(arrangement8);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.START;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.firstMondayAfter1900();
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + (-2208960000000L) + "'", long0 == (-2208960000000L));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.renderer.xy.XYBarRenderer xYBarRenderer0 = new org.jfree.chart.renderer.xy.XYBarRenderer();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.Range range2 = xYBarRenderer0.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1);
        java.lang.Object obj3 = timeSeriesCollection1.clone();
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, true);
        try {
            int int7 = timeSeriesCollection1.getItemCount((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (1).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        polarPlot4.setAngleGridlinesVisible(false);
        polarPlot4.setAngleGridlinesVisible(false);
        polarPlot4.clearCornerTextItems();
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        int int1 = barRenderer0.getRowCount();
        double[][] doubleArray4 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "hi!", doubleArray4);
        org.jfree.data.Range range6 = barRenderer0.findRangeBounds(categoryDataset5);
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset5, (java.lang.Comparable) Double.NaN);
        boolean boolean9 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset8);
        org.jfree.data.general.PieDataset pieDataset12 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset8, (java.lang.Comparable) "RectangleEdge.TOP", (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(categoryDataset5);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(pieDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(pieDataset12);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.title.LegendTitle legendTitle2 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) waferMapPlot1);
        java.awt.Font font3 = legendTitle2.getItemFont();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("DateTickUnitType.SECOND", font3);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer5 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.awt.Font font7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        xYLineAndShapeRenderer5.setLegendTextFont((int) '#', font7);
        textTitle4.setFont(font7);
        java.awt.Paint paint10 = textTitle4.getPaint();
        java.lang.String str11 = textTitle4.getText();
        textTitle4.setExpandToFitSpace(true);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "DateTickUnitType.SECOND" + "'", str11.equals("DateTickUnitType.SECOND"));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Shape shape2 = null;
        xYLineAndShapeRenderer0.setBaseLegendShape(shape2);
        xYLineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 0, (java.lang.Boolean) true, false);
        java.awt.Stroke stroke9 = xYLineAndShapeRenderer0.getSeriesStroke((int) '4');
        boolean boolean11 = xYLineAndShapeRenderer0.isSeriesVisibleInLegend(9999);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        xYLineAndShapeRenderer0.setBaseOutlinePaint((java.awt.Paint) color12, false);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation15 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot16 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot16.setDomainZeroBaselineVisible(false);
        org.jfree.chart.plot.Marker marker20 = null;
        org.jfree.chart.util.Layer layer21 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean23 = combinedRangeXYPlot16.removeDomainMarker((int) (short) 0, marker20, layer21, false);
        java.lang.String str24 = layer21.toString();
        try {
            xYLineAndShapeRenderer0.addAnnotation(xYAnnotation15, layer21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(layer21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Layer.FOREGROUND" + "'", str24.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        java.util.TimeZone timeZone0 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer3 = null;
        org.jfree.chart.plot.PolarPlot polarPlot4 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, valueAxis2, polarItemRenderer3);
        boolean boolean5 = polarPlot4.isRadiusGridlinesVisible();
        org.jfree.chart.axis.TickUnit tickUnit6 = polarPlot4.getAngleTickUnit();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = null;
        polarPlot4.datasetChanged(datasetChangeEvent7);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(tickUnit6);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        boolean boolean4 = textAnchor2.equals((java.lang.Object) (byte) 0);
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        boolean boolean7 = textAnchor5.equals((java.lang.Object) (byte) 0);
        org.jfree.chart.axis.NumberTick numberTick9 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (-4145152), "ERROR : Relative To String", textAnchor2, textAnchor5, (double) (short) 0);
        org.jfree.chart.text.TextAnchor textAnchor10 = numberTick9.getRotationAnchor();
        java.lang.String str11 = numberTick9.getText();
        java.lang.String str12 = numberTick9.toString();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ERROR : Relative To String" + "'", str11.equals("ERROR : Relative To String"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ERROR : Relative To String" + "'", str12.equals("ERROR : Relative To String"));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        int int0 = org.jfree.data.time.SerialDate.NEAREST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        barRenderer3D0.setSeriesURLGenerator(0, categoryURLGenerator2, true);
    }
}

