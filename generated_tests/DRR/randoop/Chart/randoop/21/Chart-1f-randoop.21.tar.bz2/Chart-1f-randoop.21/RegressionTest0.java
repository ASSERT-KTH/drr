import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.0d, 10.0d, (double) (short) 100, (double) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        try {
            org.jfree.chart.LegendItem legendItem2 = legendItemCollection0.get((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.awt.Color color1 = null;
        try {
            org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator5 = new org.jfree.chart.util.DefaultShadowGenerator((int) (byte) 0, color1, 2.0f, (int) (byte) 100, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'color' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = new org.jfree.chart.LegendItemCollection();
        legendItemCollection0.addAll(legendItemCollection1);
        try {
            org.jfree.chart.LegendItem legendItem4 = legendItemCollection1.get(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        java.util.List list10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        try {
            double double13 = categoryAxis0.getCategoryMiddle((java.lang.Comparable) '#', list10, rectangle2D11, rectangleEdge12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'categories' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = null;
        try {
            double double5 = categoryAxis0.getCategoryMiddle(1, 0, rectangle2D3, rectangleEdge4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: 1");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        java.util.List list11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        try {
            double double14 = categoryAxis0.getCategoryMiddle((java.lang.Comparable) 100, list11, rectangle2D12, rectangleEdge13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'categories' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 100L, (double) (short) 0, (double) (-1), (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("CategoryAnchor.START", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.net.URL uRL0 = null;
        java.net.URLClassLoader uRLClassLoader1 = null;
        try {
            org.jfree.chart.util.ResourceBundleWrapper.removeCodeBase(uRL0, uRLClassLoader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getRight();
        double double3 = rectangleInsets0.calculateBottomOutset((double) (short) 100);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj2 = standardGradientPaintTransformer1.clone();
        boolean boolean3 = categoryAxis0.equals((java.lang.Object) standardGradientPaintTransformer1);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = null;
        try {
            categoryAxis0.setCategoryLabelPositions(categoryLabelPositions4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) rectangleInsets0, jFreeChart1);
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = new org.jfree.chart.LegendItemCollection();
        legendItemCollection0.addAll(legendItemCollection1);
        int int3 = legendItemCollection0.getItemCount();
        org.jfree.chart.LegendItem legendItem4 = null;
        legendItemCollection0.add(legendItem4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = categoryAxis6.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D12, rectangleEdge13);
        java.awt.Stroke stroke15 = categoryAxis6.getTickMarkStroke();
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_RED;
        try {
            org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem(attributedString0, "", "", "", shape4, stroke15, (java.awt.Paint) color16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        boolean boolean0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultShadowsVisible();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(true);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            rectangleInsets0.trim(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMinorTickMarkInsideLength();
        boolean boolean2 = categoryAxis0.isMinorTickMarksVisible();
        categoryAxis0.setLabelURL("hi!");
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        try {
            double double11 = categoryAxis0.getCategorySeriesMiddle((java.lang.Comparable) 1L, (java.lang.Comparable) true, categoryDataset7, (double) (byte) -1, rectangle2D9, rectangleEdge10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = keyedObjects2D0.clone();
        try {
            java.lang.Object obj4 = keyedObjects2D0.getObject((java.lang.Comparable) (-1.0f), (java.lang.Comparable) 0.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (-1.0) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateTopInset((double) 10);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets0.createOutsetRectangle(rectangle2D3, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.setMaximumCategoryLabelLines(4);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor12 = org.jfree.chart.axis.CategoryAnchor.START;
        java.lang.String str13 = categoryAnchor12.toString();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor12, 4, (int) '#', rectangle2D16, rectangleEdge17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        try {
            org.jfree.chart.axis.AxisState axisState25 = categoryAxis0.draw(graphics2D19, 100.0d, rectangle2D21, rectangle2D22, rectangleEdge23, plotRenderingInfo24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(categoryAnchor12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "CategoryAnchor.START" + "'", str13.equals("CategoryAnchor.START"));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabelURL("");
        categoryAxis0.setAxisLineVisible(true);
        double double5 = categoryAxis0.getLabelAngle();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj2 = standardGradientPaintTransformer1.clone();
        boolean boolean3 = categoryAxis0.equals((java.lang.Object) standardGradientPaintTransformer1);
        categoryAxis0.setLabelToolTip("CategoryAnchor.START");
        categoryAxis0.configure();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = null;
        try {
            categoryAxis0.setCategoryLabelPositions(categoryLabelPositions7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.color.ColorSpace colorSpace1 = null;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int3 = color2.getBlue();
        float[] floatArray7 = new float[] { '#', (byte) 10, (short) 100 };
        float[] floatArray8 = color2.getColorComponents(floatArray7);
        try {
            float[] floatArray9 = color0.getColorComponents(colorSpace1, floatArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = categoryAxis6.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D12, rectangleEdge13);
        java.awt.Stroke stroke15 = categoryAxis6.getTickMarkStroke();
        java.awt.Paint paint16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        try {
            org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem(attributedString0, "", "ItemLabelAnchor.INSIDE6", "hi!", shape4, stroke15, paint16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = keyedObjects2D0.clone();
        int int3 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 'a');
        int int4 = keyedObjects2D0.getColumnCount();
        try {
            keyedObjects2D0.removeRow((java.lang.Comparable) 2.0f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (2.0) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.setMaximumCategoryLabelLines(4);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.Plot plot13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        org.jfree.chart.axis.AxisSpace axisSpace16 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace17 = categoryAxis0.reserveSpace(graphics2D12, plot13, rectangle2D14, rectangleEdge15, axisSpace16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getLeft();
        double double2 = rectangleInsets0.getLeft();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.awt.Color color1 = java.awt.Color.BLACK;
        boolean boolean2 = keyedObjects2D0.equals((java.lang.Object) color1);
        int int4 = keyedObjects2D0.getRowIndex((java.lang.Comparable) 1.0d);
        try {
            java.lang.Object obj7 = keyedObjects2D0.getObject((int) (byte) 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        boolean boolean3 = plotOrientation1.equals((java.lang.Object) color2);
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = keyedObjects2D0.clone();
        int int3 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 'a');
        try {
            java.lang.Object obj6 = keyedObjects2D0.getObject((java.lang.Comparable) "{0}", (java.lang.Comparable) (-1.0d));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key ({0}) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = keyedObjects2D0.clone();
        int int3 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 'a');
        int int4 = keyedObjects2D0.getColumnCount();
        keyedObjects2D0.clear();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.trimHeight(0.0d);
        double double4 = rectangleInsets0.trimWidth((double) 0);
        double double5 = rectangleInsets0.getLeft();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            rectangleInsets0.trim(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.KeyedObject keyedObject2 = new org.jfree.data.KeyedObject((java.lang.Comparable) 100, (java.lang.Object) (short) 0);
        java.lang.Object obj3 = keyedObject2.clone();
        java.lang.Object obj4 = null;
        boolean boolean5 = keyedObject2.equals(obj4);
        boolean boolean7 = keyedObject2.equals((java.lang.Object) "ChartChangeEventType.GENERAL");
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(false);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        try {
            java.awt.Color color1 = java.awt.Color.decode("hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"hi!\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.awt.Color color1 = java.awt.Color.BLACK;
        boolean boolean2 = keyedObjects2D0.equals((java.lang.Object) color1);
        int int4 = keyedObjects2D0.getRowIndex((java.lang.Comparable) 1.0d);
        keyedObjects2D0.clear();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor3);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor5 = itemLabelPosition4.getItemLabelAnchor();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(itemLabelAnchor5);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape5);
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape13 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = categoryAxis14.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D20, rectangleEdge21);
        java.awt.Stroke stroke23 = categoryAxis14.getTickMarkStroke();
        java.awt.Color color24 = java.awt.Color.YELLOW;
        try {
            org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem(attributedString0, "DatasetRenderingOrder.FORWARD", "{0}", "", true, shape5, false, paint8, true, (java.awt.Paint) color10, stroke11, false, shape13, stroke23, (java.awt.Paint) color24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color24);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.awt.Color color1 = java.awt.Color.BLACK;
        boolean boolean2 = keyedObjects2D0.equals((java.lang.Object) color1);
        try {
            java.lang.Comparable comparable4 = keyedObjects2D0.getColumnKey(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.lang.Number number0 = null;
        org.jfree.data.SelectableValue selectableValue1 = new org.jfree.data.SelectableValue(number0);
        selectableValue1.setSelected(false);
        boolean boolean4 = selectableValue1.isSelected();
        selectableValue1.setSelected(true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateTopInset((double) 10);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.setMaximumCategoryLabelLines(4);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.AxisState axisState13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        try {
            java.util.List list16 = categoryAxis0.refreshTicks(graphics2D12, axisState13, rectangle2D14, rectangleEdge15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.plot.Marker marker16 = null;
        try {
            categoryPlot15.addRangeMarker(marker16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        try {
            java.lang.String str3 = standardCategorySeriesLabelGenerator0.generateLabel(categoryDataset1, 64);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj2 = standardGradientPaintTransformer1.clone();
        boolean boolean3 = categoryAxis0.equals((java.lang.Object) standardGradientPaintTransformer1);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) (short) 10, (java.awt.Paint) color5);
        double double7 = categoryAxis0.getUpperMargin();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean19 = categoryPlot15.removeDomainMarker(marker17, layer18);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation20 = null;
        try {
            categoryPlot15.addAnnotation(categoryAnnotation20, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int int3 = java.awt.Color.HSBtoRGB((float) (byte) 100, 0.0f, (float) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16777216) + "'", int3 == (-16777216));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator5 = new org.jfree.chart.util.DefaultShadowGenerator(255, color1, (float) (-1L), (int) (byte) -1, (double) (-1L));
        float float6 = defaultShadowGenerator5.getShadowOpacity();
        int int7 = defaultShadowGenerator5.calculateOffsetX();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-255) + "'", int7 == (-255));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation18 = null;
        try {
            categoryPlot15.setRangeAxisLocation((-1), axisLocation18, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        boolean boolean2 = plotOrientation0.equals((java.lang.Object) color1);
        java.lang.String str3 = plotOrientation0.toString();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PlotOrientation.VERTICAL" + "'", str3.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape5, "");
        java.lang.String str8 = chartEntity7.getShapeType();
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape9, "");
        java.awt.Shape shape12 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape12);
        chartEntity11.setArea(shape12);
        chartEntity7.setArea(shape12);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer18 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj19 = standardGradientPaintTransformer18.clone();
        boolean boolean20 = categoryAxis17.equals((java.lang.Object) standardGradientPaintTransformer18);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryAxis17.setTickLabelPaint((java.lang.Comparable) (short) 10, (java.awt.Paint) color22);
        java.awt.Paint paint25 = null;
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Shape shape28 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        java.awt.Shape shape33 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity35 = new org.jfree.chart.entity.ChartEntity(shape33, "");
        java.awt.Shape shape36 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent37 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape36);
        chartEntity35.setArea(shape36);
        java.awt.Color color39 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape36, (java.awt.Paint) color39);
        legendItem40.setURLText("{0}");
        java.awt.Stroke stroke43 = legendItem40.getOutlineStroke();
        java.awt.Color color44 = java.awt.Color.green;
        try {
            org.jfree.chart.LegendItem legendItem45 = new org.jfree.chart.LegendItem(attributedString0, "poly", "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0", "poly", false, shape12, false, (java.awt.Paint) color22, true, paint25, stroke26, true, shape28, stroke43, (java.awt.Paint) color44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "poly" + "'", str8.equals("poly"));
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(color44);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean19 = categoryPlot15.removeDomainMarker(marker17, layer18);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray20 = null;
        try {
            categoryPlot15.setDomainAxes(categoryAxisArray20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        java.awt.Font font17 = null;
        try {
            categoryPlot15.setNoDataMessageFont(font17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = keyedObjects2D0.clone();
        int int3 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 'a');
        java.lang.Comparable comparable4 = null;
        try {
            int int5 = keyedObjects2D0.getColumnIndex(comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = keyedObjects2D0.clone();
        try {
            keyedObjects2D0.removeColumn((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font11 = null;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 1, font11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double14 = rectangleInsets13.getRight();
        categoryAxis0.setLabelInsets(rectangleInsets13, true);
        org.jfree.chart.util.UnitType unitType17 = rectangleInsets13.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets(unitType17, 10.0d, (double) 0, (double) (-1L), (-1.0d));
        java.awt.Shape shape27 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity29 = new org.jfree.chart.entity.ChartEntity(shape27, "");
        java.awt.Shape shape30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape30);
        chartEntity29.setArea(shape30);
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape30, (java.awt.Paint) color33);
        legendItem34.setURLText("");
        boolean boolean37 = unitType17.equals((java.lang.Object) legendItem34);
        legendItem34.setToolTipText("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        int int40 = legendItem34.getDatasetIndex();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(unitType17);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font11 = null;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 1, font11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double14 = rectangleInsets13.getRight();
        categoryAxis0.setLabelInsets(rectangleInsets13, true);
        float float17 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        categoryAxis0.setFixedDimension((double) 1.0f);
        java.lang.Comparable comparable20 = null;
        try {
            java.awt.Paint paint21 = categoryAxis0.getTickLabelPaint(comparable20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.0f + "'", float17 == 0.0f);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font11 = null;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 1, font11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double14 = rectangleInsets13.getRight();
        categoryAxis0.setLabelInsets(rectangleInsets13, true);
        float float17 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        categoryAxis0.setFixedDimension((double) 1.0f);
        categoryAxis0.setCategoryMargin(1.0d);
        org.jfree.data.KeyedObjects2D keyedObjects2D23 = new org.jfree.data.KeyedObjects2D();
        java.awt.Color color24 = java.awt.Color.BLACK;
        boolean boolean25 = keyedObjects2D23.equals((java.lang.Object) color24);
        java.util.List list26 = keyedObjects2D23.getColumnKeys();
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = null;
        try {
            double double29 = categoryAxis0.getCategoryMiddle((java.lang.Comparable) '#', list26, rectangle2D27, rectangleEdge28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.0f + "'", float17 == 0.0f);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(list26);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = keyedObjects2D0.clone();
        int int3 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 'a');
        int int4 = keyedObjects2D0.getColumnCount();
        java.lang.Comparable comparable5 = null;
        try {
            keyedObjects2D0.removeColumn(comparable5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "");
        java.awt.Stroke stroke7 = null;
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        try {
            org.jfree.chart.LegendItem legendItem9 = new org.jfree.chart.LegendItem("org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "GradientPaintTransformType.CENTER_HORIZONTAL", "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0", "", shape4, stroke7, (java.awt.Paint) color8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'lineStroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMinorTickMarkInsideLength();
        boolean boolean2 = categoryAxis0.isMinorTickMarksVisible();
        java.lang.String str4 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) 1);
        java.lang.String str5 = categoryAxis0.getLabel();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        java.awt.Paint paint18 = categoryPlot15.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        categoryPlot15.setDataset(categoryDataset19);
        org.jfree.chart.LegendItemCollection legendItemCollection21 = categoryPlot15.getLegendItems();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation22 = null;
        try {
            boolean boolean23 = categoryPlot15.removeAnnotation(categoryAnnotation22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(legendItemCollection21);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.awt.Color color1 = java.awt.Color.blue;
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator5 = new org.jfree.chart.util.DefaultShadowGenerator(0, color1, 0.0f, (int) '4', 0.0d);
        int int6 = defaultShadowGenerator5.calculateOffsetY();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getRight();
        double double3 = rectangleInsets0.extendWidth((double) (byte) 0);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        java.lang.String str3 = chartEntity2.getShapeType();
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "");
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape7);
        chartEntity6.setArea(shape7);
        chartEntity2.setArea(shape7);
        java.awt.Shape shape11 = chartEntity2.getArea();
        chartEntity2.setToolTipText("PlotOrientation.VERTICAL");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "poly" + "'", str3.equals("poly"));
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font11 = null;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 1, font11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double14 = rectangleInsets13.getRight();
        categoryAxis0.setLabelInsets(rectangleInsets13, true);
        org.jfree.chart.util.UnitType unitType17 = rectangleInsets13.getUnitType();
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType19 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType20 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D21 = rectangleInsets13.createAdjustedRectangle(rectangle2D18, lengthAdjustmentType19, lengthAdjustmentType20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(unitType17);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMinorTickMarkInsideLength();
        boolean boolean2 = categoryAxis0.isMinorTickMarksVisible();
        java.lang.String str4 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) 1);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor25 = categoryPlot23.getDomainGridlinePosition();
        java.awt.Paint paint26 = categoryPlot23.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        categoryPlot23.setDataset(categoryDataset27);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot23.getRangeAxisEdge();
        try {
            double double30 = categoryAxis0.getCategoryStart(4, 1, rectangle2D7, rectangleEdge29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(categoryAnchor25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(rectangleEdge29);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMinorTickMarkInsideLength();
        boolean boolean2 = categoryAxis0.isMinorTickMarksVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis4.setLabelURL("");
        categoryAxis4.setAxisLineVisible(true);
        java.lang.String str9 = categoryAxis4.getLabelToolTip();
        java.awt.Font font11 = categoryAxis4.getTickLabelFont((java.lang.Comparable) "poly");
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 0L, font11);
        boolean boolean13 = categoryAxis0.isVisible();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        java.awt.Paint paint18 = categoryPlot15.getBackgroundPaint();
        org.jfree.data.KeyedObjects2D keyedObjects2D20 = new org.jfree.data.KeyedObjects2D();
        java.awt.Color color21 = java.awt.Color.BLACK;
        boolean boolean22 = keyedObjects2D20.equals((java.lang.Object) color21);
        java.util.List list23 = keyedObjects2D20.getColumnKeys();
        try {
            categoryPlot15.mapDatasetToRangeAxes(4, list23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(list23);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        java.lang.Number number0 = null;
        org.jfree.data.SelectableValue selectableValue1 = new org.jfree.data.SelectableValue(number0);
        selectableValue1.setSelected(false);
        selectableValue1.setSelected(true);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.renderer.category.BarPainter barPainter0 = null;
        try {
            org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(barPainter0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'painter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.awt.Color color1 = java.awt.Color.BLACK;
        boolean boolean2 = keyedObjects2D0.equals((java.lang.Object) color1);
        int int4 = keyedObjects2D0.getRowIndex((java.lang.Comparable) 1.0d);
        try {
            keyedObjects2D0.removeRow((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis2.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D8, rectangleEdge9);
        int int11 = categoryAxis2.getCategoryLabelPositionOffset();
        categoryAxis2.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis14, categoryItemRenderer15);
        java.awt.Paint paint17 = categoryPlot16.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = categoryPlot16.removeDomainMarker(marker18, layer19);
        boolean boolean21 = categoryPlot16.isRangeMinorGridlinesVisible();
        boolean boolean22 = abstractCategoryDataset0.hasListener((java.util.EventListener) categoryPlot16);
        org.jfree.chart.axis.AxisLocation axisLocation24 = categoryPlot16.getDomainAxisLocation(4);
        java.lang.Comparable comparable25 = categoryPlot16.getDomainCrosshairColumnKey();
        org.jfree.chart.axis.ValueAxis valueAxis26 = categoryPlot16.getRangeAxis();
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNull(comparable25);
        org.junit.Assert.assertNull(valueAxis26);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font11 = null;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 1, font11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double14 = rectangleInsets13.getRight();
        categoryAxis0.setLabelInsets(rectangleInsets13, true);
        org.jfree.chart.util.UnitType unitType17 = rectangleInsets13.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets(unitType17, 10.0d, (double) 0, (double) (-1L), (-1.0d));
        java.awt.Shape shape27 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity29 = new org.jfree.chart.entity.ChartEntity(shape27, "");
        java.awt.Shape shape30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape30);
        chartEntity29.setArea(shape30);
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape30, (java.awt.Paint) color33);
        legendItem34.setURLText("");
        boolean boolean37 = unitType17.equals((java.lang.Object) legendItem34);
        legendItem34.setDescription("DatasetRenderingOrder.FORWARD");
        java.awt.Paint paint40 = legendItem34.getLinePaint();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(unitType17);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(paint40);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        int int17 = categoryPlot15.getWeight();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        categoryPlot15.setRenderer(categoryItemRenderer18);
        double double20 = categoryPlot15.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        java.awt.Paint paint18 = categoryPlot15.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        categoryPlot15.setDataset(categoryDataset19);
        org.jfree.chart.LegendItemCollection legendItemCollection21 = categoryPlot15.getLegendItems();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = null;
        categoryPlot15.notifyListeners(plotChangeEvent22);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis25 = categoryPlot15.getRangeAxisForDataset((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'index'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(legendItemCollection21);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Color color3 = java.awt.Color.blue;
        renderAttributes1.setSeriesFillPaint(0, (java.awt.Paint) color3);
        java.awt.Paint paint7 = renderAttributes1.getItemPaint((int) (byte) 10, 255);
        java.awt.Paint paint9 = renderAttributes1.getSeriesPaint((-1));
        java.awt.Paint paint10 = renderAttributes1.getDefaultFillPaint();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNull(paint10);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.plot.Marker marker16 = null;
        org.jfree.chart.util.Layer layer17 = null;
        try {
            boolean boolean18 = categoryPlot15.removeRangeMarker(marker16, layer17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font11 = null;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 1, font11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double14 = rectangleInsets13.getRight();
        categoryAxis0.setLabelInsets(rectangleInsets13, true);
        org.jfree.chart.util.UnitType unitType17 = rectangleInsets13.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets(unitType17, 10.0d, (double) 0, (double) (-1L), (-1.0d));
        java.awt.Shape shape27 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity29 = new org.jfree.chart.entity.ChartEntity(shape27, "");
        java.awt.Shape shape30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape30);
        chartEntity29.setArea(shape30);
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape30, (java.awt.Paint) color33);
        legendItem34.setURLText("");
        boolean boolean37 = unitType17.equals((java.lang.Object) legendItem34);
        legendItem34.setDescription("");
        java.text.AttributedString attributedString40 = legendItem34.getAttributedLabel();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(unitType17);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(attributedString40);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.event.DatasetChangeListener datasetChangeListener1 = null;
        abstractCategoryDataset0.removeChangeListener(datasetChangeListener1);
        org.jfree.data.general.DatasetGroup datasetGroup3 = null;
        try {
            abstractCategoryDataset0.setGroup(datasetGroup3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'group' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMinorTickMarkInsideLength();
        boolean boolean2 = categoryAxis0.isMinorTickMarksVisible();
        java.lang.String str4 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) 1);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = categoryAxis0.getCategorySeriesMiddle((int) (byte) 10, (int) '#', (int) (short) 1, (-8323073), (double) 1.0f, rectangle2D10, rectangleEdge11);
        categoryAxis0.setLabel("{0}");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMinorTickMarkInsideLength();
        double double2 = categoryAxis0.getFixedDimension();
        categoryAxis0.clearCategoryLabelToolTips();
        categoryAxis0.setUpperMargin(0.0d);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateTopInset((double) 10);
        double double4 = rectangleInsets0.calculateRightOutset(100.0d);
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.renderer.RenderAttributes renderAttributes7 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint9 = renderAttributes7.getSeriesOutlinePaint((int) '4');
        java.awt.Paint paint10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        renderAttributes7.setDefaultOutlinePaint(paint10);
        boolean boolean12 = textAnchor5.equals((java.lang.Object) renderAttributes7);
        boolean boolean13 = rectangleInsets0.equals((java.lang.Object) renderAttributes7);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D15 = rectangleInsets0.createInsetRectangle(rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        java.lang.String str3 = chartEntity2.getShapeType();
        java.lang.String str4 = chartEntity2.getShapeCoords();
        java.lang.Object obj5 = chartEntity2.clone();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "poly" + "'", str3.equals("poly"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0" + "'", str4.equals("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0"));
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.awt.Color color1 = java.awt.Color.BLACK;
        boolean boolean2 = keyedObjects2D0.equals((java.lang.Object) color1);
        try {
            keyedObjects2D0.removeObject((java.lang.Comparable) 10L, (java.lang.Comparable) 10.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (10) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj1 = standardGradientPaintTransformer0.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        boolean boolean3 = standardGradientPaintTransformer0.equals((java.lang.Object) rectangleInsets2);
        double double4 = rectangleInsets2.getTop();
        double double6 = rectangleInsets2.calculateBottomInset((double) 64);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Color color3 = java.awt.Color.blue;
        renderAttributes1.setSeriesFillPaint(0, (java.awt.Paint) color3);
        java.awt.Paint paint7 = renderAttributes1.getItemPaint((int) (byte) 10, 255);
        java.awt.Paint paint9 = renderAttributes1.getSeriesPaint((-1));
        java.awt.Stroke stroke11 = renderAttributes1.getSeriesStroke(4);
        java.awt.Paint paint13 = null;
        try {
            renderAttributes1.setSeriesFillPaint((-1), paint13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNull(stroke11);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        int int17 = categoryPlot15.getWeight();
        java.lang.Comparable comparable18 = null;
        categoryPlot15.setDomainCrosshairRowKey(comparable18, true);
        org.jfree.chart.util.SortOrder sortOrder21 = categoryPlot15.getRowRenderingOrder();
        boolean boolean23 = sortOrder21.equals((java.lang.Object) 10);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(sortOrder21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        java.awt.Stroke stroke17 = categoryPlot15.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot15.zoomRangeAxes((double) (short) -1, plotRenderingInfo19, point2D20, false);
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = null;
        org.jfree.chart.util.Layer layer25 = null;
        try {
            categoryPlot15.addDomainMarker((-255), categoryMarker24, layer25, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (short) 100, 1, (-14336));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.awt.Color color1 = java.awt.Color.BLACK;
        boolean boolean2 = keyedObjects2D0.equals((java.lang.Object) color1);
        int int3 = keyedObjects2D0.getRowCount();
        try {
            java.lang.Object obj6 = keyedObjects2D0.getObject((java.lang.Comparable) (byte) 100, (java.lang.Comparable) "org.jfree.data.UnknownKeyException: 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (100) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape8, "");
        java.awt.Shape shape11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape11);
        chartEntity10.setArea(shape11);
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape11, (java.awt.Paint) color14);
        legendItem15.setURLText("{0}");
        java.awt.Paint paint18 = legendItem15.getOutlinePaint();
        java.awt.Paint paint19 = legendItem15.getLinePaint();
        java.awt.Shape shape24 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity26 = new org.jfree.chart.entity.ChartEntity(shape24, "");
        java.awt.Shape shape27 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape27);
        chartEntity26.setArea(shape27);
        java.awt.Color color30 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape27, (java.awt.Paint) color30);
        legendItem15.setShape(shape27);
        java.awt.Color color33 = org.jfree.chart.ChartColor.DARK_CYAN;
        try {
            org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem(attributedString0, "poly", "", "", shape27, (java.awt.Paint) color33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color33);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.INSIDE10" + "'", str1.equals("ItemLabelAnchor.INSIDE10"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        java.lang.String str3 = chartEntity2.getShapeType();
        java.lang.Object obj4 = chartEntity2.clone();
        java.lang.String str5 = chartEntity2.getToolTipText();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "poly" + "'", str3.equals("poly"));
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        int int3 = java.awt.Color.HSBtoRGB((float) 64, (float) 255, (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-254) + "'", int3 == (-254));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "");
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape7);
        chartEntity6.setArea(shape7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape7, (java.awt.Paint) color10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis13.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D19, rectangleEdge20);
        int int22 = categoryAxis13.getCategoryLabelPositionOffset();
        categoryAxis13.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis25, categoryItemRenderer26);
        java.awt.Paint paint28 = categoryPlot27.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor29 = categoryPlot27.getDomainGridlinePosition();
        org.jfree.chart.entity.PlotEntity plotEntity30 = new org.jfree.chart.entity.PlotEntity(shape7, (org.jfree.chart.plot.Plot) categoryPlot27);
        java.lang.Object obj31 = plotEntity30.clone();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(categoryAnchor29);
        org.junit.Assert.assertNotNull(obj31);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.awt.Color color0 = java.awt.Color.gray;
        java.awt.Color color1 = java.awt.Color.DARK_GRAY;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        java.awt.Color color3 = java.awt.Color.YELLOW;
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int5 = color4.getBlue();
        float[] floatArray9 = new float[] { '#', (byte) 10, (short) 100 };
        float[] floatArray10 = color4.getColorComponents(floatArray9);
        float[] floatArray11 = color3.getColorComponents(floatArray9);
        try {
            float[] floatArray12 = color0.getComponents(colorSpace2, floatArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Color color3 = java.awt.Color.blue;
        renderAttributes1.setSeriesFillPaint(0, (java.awt.Paint) color3);
        java.lang.Boolean boolean5 = renderAttributes1.getDefaultLabelVisible();
        java.awt.Paint paint8 = renderAttributes1.getItemFillPaint((int) (short) 100, (int) '4');
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "");
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape7);
        chartEntity6.setArea(shape7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("ItemLabelAnchor.INSIDE6", "DatasetRenderingOrder.FORWARD", "{0}", "ChartChangeEventType.GENERAL", shape7, (java.awt.Paint) color10);
        java.awt.Paint paint12 = legendItem11.getLabelPaint();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(paint12);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (byte) 10, 0, 5);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "");
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape7);
        chartEntity6.setArea(shape7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape7, (java.awt.Paint) color10);
        legendItem11.setURLText("{0}");
        java.awt.Stroke stroke14 = legendItem11.getOutlineStroke();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke16 = defaultDrawingSupplier15.getNextStroke();
        legendItem11.setOutlineStroke(stroke16);
        boolean boolean18 = legendItem11.isShapeOutlineVisible();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        java.awt.Stroke stroke17 = categoryPlot15.getDomainGridlineStroke();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        try {
            int int19 = categoryPlot15.getRangeAxisIndex(valueAxis18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.awt.Paint[] paintArray0 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape6, "");
        java.awt.Shape shape9 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape9);
        chartEntity8.setArea(shape9);
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape9, (java.awt.Paint) color12);
        legendItem13.setURLText("{0}");
        java.awt.Stroke stroke16 = legendItem13.getOutlineStroke();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke18 = defaultDrawingSupplier17.getNextStroke();
        legendItem13.setOutlineStroke(stroke18);
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = null;
        double double33 = categoryAxis25.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D31, rectangleEdge32);
        int int34 = categoryAxis25.getCategoryLabelPositionOffset();
        categoryAxis25.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis37, categoryItemRenderer38);
        java.awt.Paint paint40 = categoryPlot39.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor41 = categoryPlot39.getDomainGridlinePosition();
        java.awt.Paint paint42 = categoryPlot39.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset43 = null;
        categoryPlot39.setDataset(categoryDataset43);
        org.jfree.chart.LegendItemCollection legendItemCollection45 = categoryPlot39.getLegendItems();
        java.awt.Stroke stroke46 = categoryPlot39.getRangeGridlineStroke();
        java.awt.Stroke[] strokeArray47 = new java.awt.Stroke[] { stroke18, stroke20, stroke21, stroke22, stroke23, stroke46 };
        java.awt.Stroke[] strokeArray48 = null;
        java.awt.Shape[] shapeArray49 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier50 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, strokeArray47, strokeArray48, shapeArray49);
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 4 + "'", int34 == 4);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(categoryAnchor41);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(legendItemCollection45);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(strokeArray47);
        org.junit.Assert.assertNotNull(shapeArray49);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) 1.0f);
        double double4 = rectangleInsets0.calculateRightOutset((double) (byte) 10);
        double double6 = rectangleInsets0.extendHeight(0.0d);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D10 = rectangleInsets0.createInsetRectangle(rectangle2D7, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        int int17 = categoryPlot15.getWeight();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        categoryPlot15.setRenderer(categoryItemRenderer18);
        categoryPlot15.clearRangeMarkers((-255));
        java.awt.Paint paint22 = categoryPlot15.getOutlinePaint();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        int int17 = categoryPlot15.getWeight();
        java.lang.Comparable comparable18 = null;
        categoryPlot15.setDomainCrosshairRowKey(comparable18, true);
        org.jfree.chart.axis.AxisSpace axisSpace21 = categoryPlot15.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot15.getRangeMarkers((-2), layer23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        java.awt.geom.Point2D point2D28 = null;
        categoryPlot15.zoomRangeAxes((double) (-14336), (double) '4', plotRenderingInfo27, point2D28);
        org.jfree.chart.plot.CategoryMarker categoryMarker31 = null;
        org.jfree.chart.util.Layer layer32 = null;
        try {
            categoryPlot15.addDomainMarker((-1), categoryMarker31, layer32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(axisSpace21);
        org.junit.Assert.assertNull(collection24);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        java.awt.Shape shape29 = lineAndShapeRenderer2.getBaseLegendShape();
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset31 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis33.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D39, rectangleEdge40);
        int int42 = categoryAxis33.getCategoryLabelPositionOffset();
        categoryAxis33.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis45, categoryItemRenderer46);
        java.awt.Paint paint48 = categoryPlot47.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker49 = null;
        org.jfree.chart.util.Layer layer50 = null;
        boolean boolean51 = categoryPlot47.removeDomainMarker(marker49, layer50);
        boolean boolean52 = categoryPlot47.isRangeMinorGridlinesVisible();
        boolean boolean53 = abstractCategoryDataset31.hasListener((java.util.EventListener) categoryPlot47);
        org.jfree.chart.axis.AxisLocation axisLocation55 = categoryPlot47.getDomainAxisLocation(4);
        java.lang.Comparable comparable56 = categoryPlot47.getDomainCrosshairColumnKey();
        boolean boolean57 = categoryPlot47.isNotify();
        org.jfree.chart.axis.ValueAxis valueAxis58 = null;
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        java.awt.Paint paint61 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        java.awt.Stroke stroke62 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        try {
            lineAndShapeRenderer2.drawRangeLine(graphics2D30, categoryPlot47, valueAxis58, rectangle2D59, (double) 64, paint61, stroke62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(shape29);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 4 + "'", int42 == 4);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(axisLocation55);
        org.junit.Assert.assertNull(comparable56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(stroke62);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.setMaximumCategoryLabelLines(4);
        categoryAxis0.setLowerMargin(0.0d);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis0.getCategorySeriesMiddle((int) (byte) 1, (int) ' ', (int) (byte) 10, 0, 3.0d, rectangle2D19, rectangleEdge20);
        java.awt.Font font22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis0.setTickLabelFont(font22);
        boolean boolean24 = categoryAxis0.isVisible();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        categoryPlot15.addChangeListener(plotChangeListener16);
        java.awt.Image image18 = categoryPlot15.getBackgroundImage();
        org.jfree.data.KeyedObjects2D keyedObjects2D20 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj21 = keyedObjects2D20.clone();
        int int23 = keyedObjects2D20.getColumnIndex((java.lang.Comparable) 'a');
        int int24 = keyedObjects2D20.getColumnCount();
        java.awt.Paint[] paintArray25 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        boolean boolean26 = keyedObjects2D20.equals((java.lang.Object) paintArray25);
        java.util.List list27 = keyedObjects2D20.getColumnKeys();
        try {
            categoryPlot15.mapDatasetToRangeAxes((int) (short) 1, list27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNull(image18);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(paintArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(list27);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        categoryPlot15.addChangeListener(plotChangeListener16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot15.zoomDomainAxes((double) 8, plotRenderingInfo19, point2D20);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        java.awt.Shape shape2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape2);
        java.lang.String str4 = chartChangeEvent3.toString();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = chartChangeEvent3.getType();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) itemLabelAnchor0, jFreeChart1, chartChangeEventType5);
        org.jfree.chart.JFreeChart jFreeChart7 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) jFreeChart1, jFreeChart7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]" + "'", str4.equals("org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]"));
        org.junit.Assert.assertNotNull(chartChangeEventType5);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "");
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape7);
        chartEntity6.setArea(shape7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("ItemLabelAnchor.INSIDE6", "DatasetRenderingOrder.FORWARD", "{0}", "ChartChangeEventType.GENERAL", shape7, (java.awt.Paint) color10);
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity(shape7);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj1 = standardGradientPaintTransformer0.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        boolean boolean3 = standardGradientPaintTransformer0.equals((java.lang.Object) rectangleInsets2);
        double double5 = rectangleInsets2.trimHeight((double) 5);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 5.0d + "'", double5 == 5.0d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator5, true);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType9 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        java.lang.String str10 = gradientPaintTransformType9.toString();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        boolean boolean12 = gradientPaintTransformType9.equals((java.lang.Object) color11);
        try {
            lineAndShapeRenderer2.setSeriesPaint((-16777216), (java.awt.Paint) color11, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformType9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "GradientPaintTransformType.CENTER_HORIZONTAL" + "'", str10.equals("GradientPaintTransformType.CENTER_HORIZONTAL"));
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = abstractCategoryDataset0.hasListener(eventListener1);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener3 = null;
        abstractCategoryDataset0.removeChangeListener(datasetChangeListener3);
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState5 = null;
        abstractCategoryDataset0.setSelectionState(categoryDatasetSelectionState5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(2);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "");
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape7);
        chartEntity6.setArea(shape7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape7, (java.awt.Paint) color10);
        legendItem11.setURLText("");
        boolean boolean14 = legendItem11.isShapeFilled();
        java.lang.Object obj15 = legendItem11.clone();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabelURL("");
        categoryAxis0.setCategoryMargin(0.0d);
        double double5 = categoryAxis0.getCategoryMargin();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj2 = standardGradientPaintTransformer1.clone();
        boolean boolean3 = categoryAxis0.equals((java.lang.Object) standardGradientPaintTransformer1);
        categoryAxis0.setLabelToolTip("CategoryAnchor.START");
        categoryAxis0.configure();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int9 = color8.getAlpha();
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator13 = new org.jfree.chart.util.DefaultShadowGenerator((int) (short) 0, color8, (-1.0f), 10, (double) (short) 1);
        java.awt.Color color14 = defaultShadowGenerator13.getShadowColor();
        categoryAxis0.setTickMarkPaint((java.awt.Paint) color14);
        boolean boolean16 = categoryAxis0.isMinorTickMarksVisible();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        java.awt.Shape shape2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape2);
        java.lang.String str4 = chartChangeEvent3.toString();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = chartChangeEvent3.getType();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) itemLabelAnchor0, jFreeChart1, chartChangeEventType5);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = chartChangeEvent6.getType();
        java.lang.String str8 = chartChangeEvent6.toString();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = chartChangeEvent6.getType();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]" + "'", str4.equals("org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]"));
        org.junit.Assert.assertNotNull(chartChangeEventType5);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=ItemLabelAnchor.OUTSIDE7]" + "'", str8.equals("org.jfree.chart.event.ChartChangeEvent[source=ItemLabelAnchor.OUTSIDE7]"));
        org.junit.Assert.assertNotNull(chartChangeEventType9);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor29 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor30 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor29, textAnchor30);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj34 = standardGradientPaintTransformer33.clone();
        boolean boolean35 = categoryAxis32.equals((java.lang.Object) standardGradientPaintTransformer33);
        boolean boolean36 = itemLabelPosition31.equals((java.lang.Object) boolean35);
        double double37 = itemLabelPosition31.getAngle();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor38 = itemLabelPosition31.getItemLabelAnchor();
        lineAndShapeRenderer2.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition31);
        lineAndShapeRenderer2.setUseOutlinePaint(false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(itemLabelAnchor29);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor38);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator5, true);
        java.awt.Font font9 = lineAndShapeRenderer2.lookupLegendTextFont((int) (byte) 0);
        java.lang.Boolean boolean11 = lineAndShapeRenderer2.getSeriesItemLabelsVisible(4);
        lineAndShapeRenderer2.setSeriesShapesFilled((int) '#', false);
        org.junit.Assert.assertNull(font9);
        org.junit.Assert.assertNull(boolean11);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMinorTickMarkInsideLength();
        boolean boolean2 = categoryAxis0.isMinorTickMarksVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis4.setLabelURL("");
        categoryAxis4.setAxisLineVisible(true);
        java.lang.String str9 = categoryAxis4.getLabelToolTip();
        java.awt.Font font11 = categoryAxis4.getTickLabelFont((java.lang.Comparable) "poly");
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 0L, font11);
        categoryAxis0.clearCategoryLabelToolTips();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Shape shape3 = renderAttributes1.getSeriesShape(4);
        org.junit.Assert.assertNull(shape3);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = null;
        try {
            lineAndShapeRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font11 = null;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 1, font11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double14 = rectangleInsets13.getRight();
        categoryAxis0.setLabelInsets(rectangleInsets13, true);
        org.jfree.chart.util.UnitType unitType17 = rectangleInsets13.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets(unitType17, 10.0d, (double) 0, (double) (-1L), (-1.0d));
        java.awt.Shape shape27 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity29 = new org.jfree.chart.entity.ChartEntity(shape27, "");
        java.awt.Shape shape30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape30);
        chartEntity29.setArea(shape30);
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape30, (java.awt.Paint) color33);
        legendItem34.setURLText("");
        boolean boolean37 = unitType17.equals((java.lang.Object) legendItem34);
        legendItem34.setDescription("");
        java.lang.String str40 = legendItem34.getURLText();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(unitType17);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "" + "'", str40.equals(""));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabelURL("");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = org.jfree.chart.axis.CategoryAnchor.START;
        java.lang.String str4 = categoryAnchor3.toString();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor5 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        boolean boolean6 = categoryAnchor3.equals((java.lang.Object) itemLabelAnchor5);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = categoryAxis11.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D17, rectangleEdge18);
        int int20 = categoryAxis11.getCategoryLabelPositionOffset();
        categoryAxis11.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis23, categoryItemRenderer24);
        java.awt.Paint paint26 = categoryPlot25.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor27 = categoryPlot25.getDomainGridlinePosition();
        java.awt.Paint paint28 = categoryPlot25.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        categoryPlot25.setDataset(categoryDataset29);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot25.getRangeAxisEdge();
        try {
            double double32 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor3, 0, (int) 'a', rectangle2D9, rectangleEdge31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categoryAnchor3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CategoryAnchor.START" + "'", str4.equals("CategoryAnchor.START"));
        org.junit.Assert.assertNotNull(itemLabelAnchor5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(categoryAnchor27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(rectangleEdge31);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str1 = datasetRenderingOrder0.toString();
        java.lang.String str2 = datasetRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str1.equals("DatasetRenderingOrder.FORWARD"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str2.equals("DatasetRenderingOrder.FORWARD"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font11 = null;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 1, font11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double14 = rectangleInsets13.getRight();
        categoryAxis0.setLabelInsets(rectangleInsets13, true);
        double double18 = rectangleInsets13.calculateBottomOutset((double) (byte) 10);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D20 = rectangleInsets13.createOutsetRectangle(rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint33 = renderAttributes31.getSeriesOutlinePaint((int) '4');
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes31.setDefaultStroke(stroke34);
        lineAndShapeRenderer2.setSeriesStroke(0, stroke34, false);
        java.lang.Object obj38 = lineAndShapeRenderer2.clone();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(obj38);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.renderer.category.BarPainter barPainter1 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
        boolean boolean2 = standardGradientPaintTransformer0.equals((java.lang.Object) barPainter1);
        org.junit.Assert.assertNotNull(barPainter1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        java.awt.Paint paint18 = categoryPlot15.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        categoryPlot15.setDataset(categoryDataset19);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot15.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = categoryPlot15.getAxisOffset();
        java.awt.Stroke stroke23 = null;
        try {
            categoryPlot15.setRangeCrosshairStroke(stroke23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        java.awt.Font font12 = null;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) 1, font12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double15 = rectangleInsets14.getRight();
        categoryAxis1.setLabelInsets(rectangleInsets14, true);
        org.jfree.chart.util.UnitType unitType18 = rectangleInsets14.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = new org.jfree.chart.util.RectangleInsets(unitType18, 10.0d, (double) 0, (double) (-1L), (-1.0d));
        java.awt.Shape shape28 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity30 = new org.jfree.chart.entity.ChartEntity(shape28, "");
        java.awt.Shape shape31 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent32 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape31);
        chartEntity30.setArea(shape31);
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape31, (java.awt.Paint) color34);
        legendItem35.setURLText("");
        boolean boolean38 = unitType18.equals((java.lang.Object) legendItem35);
        org.jfree.data.KeyedObject keyedObject39 = new org.jfree.data.KeyedObject((java.lang.Comparable) (-1.0d), (java.lang.Object) unitType18);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(unitType18);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        java.lang.String str2 = unknownKeyException1.toString();
        org.jfree.data.UnknownKeyException unknownKeyException4 = new org.jfree.data.UnknownKeyException("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        java.lang.String str5 = unknownKeyException4.toString();
        unknownKeyException1.addSuppressed((java.lang.Throwable) unknownKeyException4);
        java.lang.String str7 = unknownKeyException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.UnknownKeyException: 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0" + "'", str2.equals("org.jfree.data.UnknownKeyException: 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.UnknownKeyException: 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0" + "'", str5.equals("org.jfree.data.UnknownKeyException: 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.UnknownKeyException: 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0" + "'", str7.equals("org.jfree.data.UnknownKeyException: 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0"));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        java.awt.Font font28 = lineAndShapeRenderer2.getBaseItemLabelFont();
        java.awt.Shape shape34 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity36 = new org.jfree.chart.entity.ChartEntity(shape34, "");
        java.awt.Shape shape37 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent38 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape37);
        chartEntity36.setArea(shape37);
        java.awt.Color color40 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem41 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape37, (java.awt.Paint) color40);
        legendItem41.setURLText("{0}");
        java.awt.Paint paint44 = legendItem41.getOutlinePaint();
        java.awt.Paint paint45 = legendItem41.getLinePaint();
        try {
            lineAndShapeRenderer2.setSeriesPaint((-16777216), paint45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(paint45);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        java.awt.Shape shape3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape3);
        chartEntity2.setArea(shape3);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = categoryAxis7.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D13, rectangleEdge14);
        int int16 = categoryAxis7.getCategoryLabelPositionOffset();
        categoryAxis7.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.util.ObjectList objectList24 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        float float27 = categoryAxis26.getMinorTickMarkInsideLength();
        boolean boolean28 = categoryAxis26.isMinorTickMarksVisible();
        categoryAxis26.setLabelURL("hi!");
        objectList24.set((int) (short) 10, (java.lang.Object) categoryAxis26);
        org.jfree.chart.plot.Plot plot32 = null;
        categoryAxis26.setPlot(plot32);
        categoryAxis26.setCategoryMargin((double) (-1));
        categoryPlot21.setDomainAxis((int) '#', categoryAxis26);
        categoryPlot21.configureRangeAxes();
        org.jfree.chart.entity.PlotEntity plotEntity38 = new org.jfree.chart.entity.PlotEntity(shape3, (org.jfree.chart.plot.Plot) categoryPlot21);
        boolean boolean39 = categoryPlot21.canSelectByPoint();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray40 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot21.setDomainAxes(categoryAxisArray40);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.0f + "'", float27 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray40);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.awt.Stroke stroke2 = strokeList0.getStroke((-1));
        java.awt.Stroke stroke4 = strokeList0.getStroke((-8323073));
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNull(stroke4);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj2 = standardGradientPaintTransformer1.clone();
        boolean boolean3 = categoryAxis0.equals((java.lang.Object) standardGradientPaintTransformer1);
        categoryAxis0.setLabelToolTip("CategoryAnchor.START");
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis13.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D19, rectangleEdge20);
        int int22 = categoryAxis13.getCategoryLabelPositionOffset();
        categoryAxis13.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis25, categoryItemRenderer26);
        java.awt.Paint paint28 = categoryPlot27.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor29 = categoryPlot27.getDomainGridlinePosition();
        java.awt.Paint paint30 = categoryPlot27.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        categoryPlot27.setDataset(categoryDataset31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = categoryPlot27.getRangeAxisEdge();
        try {
            double double34 = categoryAxis0.getCategorySeriesMiddle((int) '#', (int) (byte) -1, 5, (int) (byte) -1, (double) 4, rectangle2D11, rectangleEdge33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(categoryAnchor29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(rectangleEdge33);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        java.lang.String str3 = chartEntity2.getShapeType();
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "");
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape7);
        chartEntity6.setArea(shape7);
        chartEntity2.setArea(shape7);
        java.awt.Shape shape11 = chartEntity2.getArea();
        chartEntity2.setToolTipText("CategoryAnchor.START");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "poly" + "'", str3.equals("poly"));
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMinorTickMarkInsideLength();
        boolean boolean2 = categoryAxis0.isMinorTickMarksVisible();
        java.lang.String str4 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) 1);
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 'a', "hi!");
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis13.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D19, rectangleEdge20);
        int int22 = categoryAxis13.getCategoryLabelPositionOffset();
        categoryAxis13.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis25, categoryItemRenderer26);
        java.awt.Paint paint28 = categoryPlot27.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor29 = categoryPlot27.getDomainGridlinePosition();
        java.awt.Paint paint30 = categoryPlot27.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        categoryPlot27.setDataset(categoryDataset31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = categoryPlot27.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        try {
            org.jfree.chart.axis.AxisState axisState35 = categoryAxis0.draw(graphics2D8, (-1.0d), rectangle2D10, rectangle2D11, rectangleEdge33, plotRenderingInfo34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(categoryAnchor29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(rectangleEdge33);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) 10L);
        categoryAxis0.setMinorTickMarksVisible(true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        categoryPlot15.addChangeListener(plotChangeListener16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = categoryAxis19.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D25, rectangleEdge26);
        int int28 = categoryAxis19.getCategoryLabelPositionOffset();
        categoryAxis19.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis31, categoryItemRenderer32);
        java.awt.Paint paint34 = categoryPlot33.getRangeCrosshairPaint();
        java.awt.Stroke stroke35 = categoryPlot33.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        java.awt.geom.Point2D point2D38 = null;
        categoryPlot33.zoomRangeAxes((double) (short) -1, plotRenderingInfo37, point2D38, false);
        org.jfree.chart.axis.AxisLocation axisLocation41 = categoryPlot33.getDomainAxisLocation();
        categoryPlot15.setDomainAxisLocation(axisLocation41, true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(axisLocation41);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator5, true);
        java.lang.Boolean boolean9 = lineAndShapeRenderer2.getSeriesVisible((int) (short) 100);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator10 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        lineAndShapeRenderer2.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        try {
            java.lang.String str14 = standardCategorySeriesLabelGenerator10.generateLabel(categoryDataset12, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean9);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        java.lang.String str3 = chartEntity2.getShapeType();
        java.lang.Object obj4 = chartEntity2.clone();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape5, "");
        chartEntity2.setArea(shape5);
        chartEntity2.setToolTipText("");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "poly" + "'", str3.equals("poly"));
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.awt.Color color0 = java.awt.Color.darkGray;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-12566464) + "'", int1 == (-12566464));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        java.awt.Color color0 = java.awt.Color.gray;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=128,g=128,b=128]" + "'", str1.equals("java.awt.Color[r=128,g=128,b=128]"));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean19 = categoryPlot15.removeDomainMarker(marker17, layer18);
        boolean boolean20 = categoryPlot15.isRangeMinorGridlinesVisible();
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = null;
        org.jfree.chart.util.Layer layer22 = null;
        try {
            categoryPlot15.addDomainMarker(categoryMarker21, layer22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot4.getDomainMarkers(layer10);
        org.junit.Assert.assertNull(collection11);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis2.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D8, rectangleEdge9);
        int int11 = categoryAxis2.getCategoryLabelPositionOffset();
        categoryAxis2.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis14, categoryItemRenderer15);
        java.awt.Paint paint17 = categoryPlot16.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = categoryPlot16.removeDomainMarker(marker18, layer19);
        boolean boolean21 = categoryPlot16.isRangeMinorGridlinesVisible();
        boolean boolean22 = abstractCategoryDataset0.hasListener((java.util.EventListener) categoryPlot16);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot16.getDomainMarkers(layer23);
        boolean boolean25 = categoryPlot16.isDomainPannable();
        categoryPlot16.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryPlot16.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = categoryPlot16.getDatasetRenderingOrder();
        java.lang.String str30 = datasetRenderingOrder29.toString();
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str30.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font11 = null;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 1, font11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double14 = rectangleInsets13.getRight();
        categoryAxis0.setLabelInsets(rectangleInsets13, true);
        double double18 = rectangleInsets13.calculateBottomInset(100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.setMaximumCategoryLabelLines(4);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = categoryAxis14.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D20, rectangleEdge21);
        int int23 = categoryAxis14.getCategoryLabelPositionOffset();
        categoryAxis14.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis26, categoryItemRenderer27);
        java.awt.Paint paint29 = categoryPlot28.getRangeCrosshairPaint();
        int int30 = categoryPlot28.getWeight();
        java.lang.Comparable comparable31 = null;
        categoryPlot28.setDomainCrosshairRowKey(comparable31, true);
        categoryPlot28.clearAnnotations();
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = null;
        double double45 = categoryAxis37.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D43, rectangleEdge44);
        int int46 = categoryAxis37.getCategoryLabelPositionOffset();
        categoryAxis37.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset36, categoryAxis37, valueAxis49, categoryItemRenderer50);
        java.awt.Paint paint52 = categoryPlot51.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor53 = categoryPlot51.getDomainGridlinePosition();
        java.awt.Paint paint54 = categoryPlot51.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset55 = null;
        categoryPlot51.setDataset(categoryDataset55);
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = categoryPlot51.getRangeAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace58 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace59 = categoryAxis0.reserveSpace(graphics2D12, (org.jfree.chart.plot.Plot) categoryPlot28, rectangle2D35, rectangleEdge57, axisSpace58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 4 + "'", int46 == 4);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNotNull(categoryAnchor53);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(rectangleEdge57);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.trimHeight(0.0d);
        double double4 = rectangleInsets0.trimWidth((double) 0);
        double double5 = rectangleInsets0.getLeft();
        double double7 = rectangleInsets0.calculateRightInset((double) (short) 10);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        java.lang.String str3 = chartEntity2.getShapeType();
        java.lang.Object obj4 = chartEntity2.clone();
        java.lang.String str5 = chartEntity2.getURLText();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "poly" + "'", str3.equals("poly"));
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis2.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D8, rectangleEdge9);
        int int11 = categoryAxis2.getCategoryLabelPositionOffset();
        categoryAxis2.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis14, categoryItemRenderer15);
        java.awt.Paint paint17 = categoryPlot16.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = categoryPlot16.removeDomainMarker(marker18, layer19);
        boolean boolean21 = categoryPlot16.isRangeMinorGridlinesVisible();
        boolean boolean22 = abstractCategoryDataset0.hasListener((java.util.EventListener) categoryPlot16);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot16.getDomainMarkers(layer23);
        boolean boolean25 = categoryPlot16.isDomainPannable();
        categoryPlot16.setRangeMinorGridlinesVisible(false);
        boolean boolean28 = categoryPlot16.isRangeCrosshairVisible();
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font11 = null;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 1, font11);
        categoryAxis0.setTickMarkOutsideLength((float) '4');
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font11 = null;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 1, font11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double14 = rectangleInsets13.getRight();
        categoryAxis0.setLabelInsets(rectangleInsets13, true);
        double double18 = rectangleInsets13.calculateRightInset((double) (short) -1);
        double double20 = rectangleInsets13.calculateLeftOutset((double) 255);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape0);
        java.lang.String str2 = chartChangeEvent1.toString();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = chartChangeEvent1.getType();
        java.lang.String str4 = chartChangeEventType3.toString();
        java.lang.String str5 = chartChangeEventType3.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]" + "'", str2.equals("org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]"));
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str4.equals("ChartChangeEventType.GENERAL"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str5.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = keyedObjects2D0.clone();
        int int3 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 'a');
        org.jfree.data.KeyedObjects2D keyedObjects2D4 = new org.jfree.data.KeyedObjects2D();
        java.awt.Color color5 = java.awt.Color.BLACK;
        boolean boolean6 = keyedObjects2D4.equals((java.lang.Object) color5);
        boolean boolean7 = keyedObjects2D0.equals((java.lang.Object) keyedObjects2D4);
        int int8 = keyedObjects2D4.getColumnCount();
        try {
            keyedObjects2D4.removeRow((java.lang.Comparable) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (100) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "");
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape7);
        chartEntity6.setArea(shape7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape7, (java.awt.Paint) color10);
        legendItem11.setURLText("");
        java.awt.Shape shape14 = legendItem11.getShape();
        java.lang.String str15 = legendItem11.getDescription();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "ItemLabelAnchor.INSIDE6" + "'", str15.equals("ItemLabelAnchor.INSIDE6"));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        categoryPlot15.addChangeListener(plotChangeListener16);
        java.awt.Paint paint18 = categoryPlot15.getRangeGridlinePaint();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.event.DatasetChangeListener datasetChangeListener1 = null;
        abstractCategoryDataset0.addChangeListener(datasetChangeListener1);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        abstractCategoryDataset0.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot7);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        java.awt.Paint paint18 = categoryPlot15.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        categoryPlot15.setDataset(categoryDataset19);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot15.getRangeAxisEdge();
        boolean boolean22 = categoryPlot15.isRangeGridlinesVisible();
        org.jfree.chart.renderer.RenderAttributes renderAttributes24 = new org.jfree.chart.renderer.RenderAttributes(false);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        double double34 = categoryAxis26.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D32, rectangleEdge33);
        int int35 = categoryAxis26.getCategoryLabelPositionOffset();
        categoryAxis26.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, valueAxis38, categoryItemRenderer39);
        java.awt.Paint paint41 = categoryPlot40.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor42 = categoryPlot40.getDomainGridlinePosition();
        java.awt.Paint paint43 = categoryPlot40.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset44 = null;
        categoryPlot40.setDataset(categoryDataset44);
        org.jfree.chart.LegendItemCollection legendItemCollection46 = categoryPlot40.getLegendItems();
        java.awt.Stroke stroke47 = categoryPlot40.getRangeGridlineStroke();
        renderAttributes24.setDefaultStroke(stroke47);
        categoryPlot15.setRangeCrosshairStroke(stroke47);
        categoryPlot15.setDomainCrosshairColumnKey((java.lang.Comparable) (-1.0f));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(categoryAnchor42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(legendItemCollection46);
        org.junit.Assert.assertNotNull(stroke47);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        categoryPlot15.addChangeListener(plotChangeListener16);
        boolean boolean18 = categoryPlot15.isRangeZoomable();
        org.jfree.chart.axis.AxisSpace axisSpace19 = categoryPlot15.getFixedDomainAxisSpace();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation20 = null;
        try {
            boolean boolean22 = categoryPlot15.removeAnnotation(categoryAnnotation20, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(axisSpace19);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator5, true);
        java.lang.Boolean boolean9 = lineAndShapeRenderer2.getSeriesVisible((int) (short) 100);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator10 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        lineAndShapeRenderer2.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator10);
        boolean boolean14 = lineAndShapeRenderer2.getItemShapeVisible((int) 'a', 10);
        boolean boolean18 = lineAndShapeRenderer2.isItemLabelVisible((-14336), 0, true);
        java.awt.Font font20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        try {
            lineAndShapeRenderer2.setSeriesItemLabelFont((-8323073), font20, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(font20);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) '#', (float) 'a', (float) (-2));
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
        objectList1.clear();
        int int4 = objectList1.indexOf((java.lang.Object) (short) 1);
        java.lang.Object obj6 = objectList1.get(1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(obj6);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape0);
        java.lang.String str2 = chartChangeEvent1.toString();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType3 = chartChangeEvent1.getType();
        java.lang.String str4 = chartChangeEvent1.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]" + "'", str2.equals("org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]"));
        org.junit.Assert.assertNotNull(chartChangeEventType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]" + "'", str4.equals("org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]"));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = categoryAxis19.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D25, rectangleEdge26);
        int int28 = categoryAxis19.getCategoryLabelPositionOffset();
        categoryAxis19.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis31, categoryItemRenderer32);
        java.awt.Paint paint34 = categoryPlot33.getRangeCrosshairPaint();
        int int35 = categoryPlot33.getWeight();
        java.lang.Comparable comparable36 = null;
        categoryPlot33.setDomainCrosshairRowKey(comparable36, true);
        org.jfree.chart.util.SortOrder sortOrder39 = categoryPlot33.getRowRenderingOrder();
        categoryPlot15.setRowRenderingOrder(sortOrder39);
        java.awt.Color color41 = org.jfree.chart.ChartColor.LIGHT_RED;
        categoryPlot15.setBackgroundPaint((java.awt.Paint) color41);
        java.awt.Color color46 = java.awt.Color.YELLOW;
        java.awt.Color color47 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int48 = color47.getBlue();
        float[] floatArray52 = new float[] { '#', (byte) 10, (short) 100 };
        float[] floatArray53 = color47.getColorComponents(floatArray52);
        float[] floatArray54 = color46.getColorComponents(floatArray52);
        float[] floatArray55 = java.awt.Color.RGBtoHSB(64, (int) '#', (int) (short) 1, floatArray54);
        try {
            float[] floatArray56 = color41.getRGBComponents(floatArray55);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(sortOrder39);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(floatArray52);
        org.junit.Assert.assertNotNull(floatArray53);
        org.junit.Assert.assertNotNull(floatArray54);
        org.junit.Assert.assertNotNull(floatArray55);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabelURL("");
        categoryAxis0.setAxisLineVisible(true);
        double double5 = categoryAxis0.getCategoryMargin();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.2d + "'", double5 == 0.2d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        float float4 = categoryAxis3.getMinorTickMarkInsideLength();
        boolean boolean5 = categoryAxis3.isMinorTickMarksVisible();
        categoryAxis3.setLabelURL("hi!");
        objectList1.set((int) (short) 10, (java.lang.Object) categoryAxis3);
        java.awt.Color color9 = java.awt.Color.YELLOW;
        boolean boolean10 = objectList1.equals((java.lang.Object) color9);
        org.jfree.chart.util.BooleanList booleanList12 = new org.jfree.chart.util.BooleanList();
        try {
            objectList1.set((-255), (java.lang.Object) booleanList12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean19 = categoryPlot15.removeDomainMarker(marker17, layer18);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot15.getRangeMarkers(layer20);
        java.awt.Font font22 = categoryPlot15.getNoDataMessageFont();
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        categoryPlot15.setRangeMinorGridlinePaint((java.awt.Paint) color23);
        try {
            categoryPlot15.zoom((double) (-8323073));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(color23);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor29 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor30 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor29, textAnchor30);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj34 = standardGradientPaintTransformer33.clone();
        boolean boolean35 = categoryAxis32.equals((java.lang.Object) standardGradientPaintTransformer33);
        boolean boolean36 = itemLabelPosition31.equals((java.lang.Object) boolean35);
        double double37 = itemLabelPosition31.getAngle();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor38 = itemLabelPosition31.getItemLabelAnchor();
        lineAndShapeRenderer2.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition31);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator41 = null;
        lineAndShapeRenderer2.setSeriesURLGenerator(1, categoryURLGenerator41);
        lineAndShapeRenderer2.setBaseSeriesVisibleInLegend(true, false);
        lineAndShapeRenderer2.setBaseLinesVisible(true);
        boolean boolean48 = lineAndShapeRenderer2.getBaseSeriesVisibleInLegend();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(itemLabelAnchor29);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor38);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.awt.Color color1 = java.awt.Color.BLACK;
        boolean boolean2 = keyedObjects2D0.equals((java.lang.Object) color1);
        java.awt.Color color3 = java.awt.Color.DARK_GRAY;
        java.awt.color.ColorSpace colorSpace4 = color3.getColorSpace();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int6 = color5.getBlue();
        float[] floatArray10 = new float[] { '#', (byte) 10, (short) 100 };
        float[] floatArray11 = color5.getColorComponents(floatArray10);
        float[] floatArray12 = color1.getColorComponents(colorSpace4, floatArray10);
        java.awt.Shape shape17 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity19 = new org.jfree.chart.entity.ChartEntity(shape17, "");
        java.awt.Shape shape20 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent21 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape20);
        chartEntity19.setArea(shape20);
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape20, (java.awt.Paint) color23);
        legendItem24.setURLText("{0}");
        boolean boolean27 = color1.equals((java.lang.Object) legendItem24);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(colorSpace4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.awt.Color color1 = java.awt.Color.BLACK;
        boolean boolean2 = keyedObjects2D0.equals((java.lang.Object) color1);
        int int4 = keyedObjects2D0.getRowIndex((java.lang.Comparable) 1.0d);
        java.lang.Comparable comparable5 = null;
        try {
            int int6 = keyedObjects2D0.getRowIndex(comparable5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator5, true);
        java.awt.Font font9 = lineAndShapeRenderer2.lookupLegendTextFont((int) (byte) 0);
        java.lang.Boolean boolean11 = lineAndShapeRenderer2.getSeriesItemLabelsVisible(4);
        lineAndShapeRenderer2.setSeriesItemLabelsVisible(0, (java.lang.Boolean) false);
        org.junit.Assert.assertNull(font9);
        org.junit.Assert.assertNull(boolean11);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor29 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor30 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor29, textAnchor30);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj34 = standardGradientPaintTransformer33.clone();
        boolean boolean35 = categoryAxis32.equals((java.lang.Object) standardGradientPaintTransformer33);
        boolean boolean36 = itemLabelPosition31.equals((java.lang.Object) boolean35);
        double double37 = itemLabelPosition31.getAngle();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor38 = itemLabelPosition31.getItemLabelAnchor();
        lineAndShapeRenderer2.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition31);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator41 = null;
        lineAndShapeRenderer2.setSeriesURLGenerator(1, categoryURLGenerator41);
        lineAndShapeRenderer2.setBaseSeriesVisibleInLegend(true, false);
        lineAndShapeRenderer2.setBaseLinesVisible(true);
        java.awt.Shape shape49 = lineAndShapeRenderer2.getSeriesShape((int) (byte) 100);
        java.awt.Color color51 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        try {
            lineAndShapeRenderer2.setSeriesOutlinePaint((-254), (java.awt.Paint) color51, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(itemLabelAnchor29);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor38);
        org.junit.Assert.assertNull(shape49);
        org.junit.Assert.assertNotNull(color51);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean19 = categoryPlot15.removeDomainMarker(marker17, layer18);
        try {
            categoryPlot15.setBackgroundImageAlpha((float) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator5, true);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        lineAndShapeRenderer2.setBaseItemLabelPaint((java.awt.Paint) color8, true);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int3 = color2.getAlpha();
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator7 = new org.jfree.chart.util.DefaultShadowGenerator((int) (short) 0, color2, (-1.0f), 10, (double) (short) 1);
        java.awt.Color color8 = defaultShadowGenerator7.getShadowColor();
        renderAttributes0.setDefaultOutlinePaint((java.awt.Paint) color8);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint33 = renderAttributes31.getSeriesOutlinePaint((int) '4');
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes31.setDefaultStroke(stroke34);
        lineAndShapeRenderer2.setSeriesStroke(0, stroke34, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation38 = null;
        boolean boolean39 = lineAndShapeRenderer2.removeAnnotation(categoryAnnotation38);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (byte) 10, false);
        java.awt.Paint paint44 = lineAndShapeRenderer2.getSeriesFillPaint(0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(paint44);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        double double16 = categoryPlot15.getAnchorValue();
        float float17 = categoryPlot15.getBackgroundImageAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = null;
        try {
            categoryPlot15.setInsets(rectangleInsets18, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj2 = standardGradientPaintTransformer1.clone();
        boolean boolean3 = categoryAxis0.equals((java.lang.Object) standardGradientPaintTransformer1);
        org.jfree.chart.LegendItem legendItem5 = new org.jfree.chart.LegendItem("ItemLabelAnchor.INSIDE6");
        boolean boolean6 = standardGradientPaintTransformer1.equals((java.lang.Object) legendItem5);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        int int17 = categoryPlot15.getWeight();
        java.lang.Comparable comparable18 = null;
        categoryPlot15.setDomainCrosshairRowKey(comparable18, true);
        org.jfree.chart.axis.AxisSpace axisSpace21 = categoryPlot15.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot15.getRangeMarkers((-2), layer23);
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = null;
        org.jfree.chart.util.Layer layer26 = null;
        try {
            categoryPlot15.addDomainMarker(categoryMarker25, layer26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(axisSpace21);
        org.junit.Assert.assertNull(collection24);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        double double16 = categoryPlot15.getAnchorValue();
        float float17 = categoryPlot15.getBackgroundImageAlpha();
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = null;
        try {
            categoryPlot15.addDomainMarker(categoryMarker18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        java.awt.Shape shape29 = lineAndShapeRenderer2.getBaseLegendShape();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator30 = null;
        lineAndShapeRenderer2.setBaseItemLabelGenerator(categoryItemLabelGenerator30);
        lineAndShapeRenderer2.setBaseSeriesVisible(true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(shape29);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj2 = standardGradientPaintTransformer1.clone();
        boolean boolean3 = categoryAxis0.equals((java.lang.Object) standardGradientPaintTransformer1);
        boolean boolean4 = categoryAxis0.isAxisLineVisible();
        categoryAxis0.setMinorTickMarksVisible(true);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.util.ObjectList objectList18 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        float float21 = categoryAxis20.getMinorTickMarkInsideLength();
        boolean boolean22 = categoryAxis20.isMinorTickMarksVisible();
        categoryAxis20.setLabelURL("hi!");
        objectList18.set((int) (short) 10, (java.lang.Object) categoryAxis20);
        org.jfree.chart.plot.Plot plot26 = null;
        categoryAxis20.setPlot(plot26);
        categoryAxis20.setCategoryMargin((double) (-1));
        categoryPlot15.setDomainAxis((int) '#', categoryAxis20);
        org.jfree.chart.axis.ValueAxis valueAxis31 = categoryPlot15.getRangeAxis();
        boolean boolean32 = categoryPlot15.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(valueAxis31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("java.awt.Color[r=128,g=128,b=128]");
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "");
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape7);
        chartEntity6.setArea(shape7);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = categoryAxis11.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D17, rectangleEdge18);
        int int20 = categoryAxis11.getCategoryLabelPositionOffset();
        categoryAxis11.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis23, categoryItemRenderer24);
        org.jfree.chart.util.ObjectList objectList28 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis();
        float float31 = categoryAxis30.getMinorTickMarkInsideLength();
        boolean boolean32 = categoryAxis30.isMinorTickMarksVisible();
        categoryAxis30.setLabelURL("hi!");
        objectList28.set((int) (short) 10, (java.lang.Object) categoryAxis30);
        org.jfree.chart.plot.Plot plot36 = null;
        categoryAxis30.setPlot(plot36);
        categoryAxis30.setCategoryMargin((double) (-1));
        categoryPlot25.setDomainAxis((int) '#', categoryAxis30);
        categoryPlot25.configureRangeAxes();
        org.jfree.chart.entity.PlotEntity plotEntity42 = new org.jfree.chart.entity.PlotEntity(shape7, (org.jfree.chart.plot.Plot) categoryPlot25);
        lineAndShapeRenderer2.setSeriesShape(8, shape7);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 0.0f + "'", float31 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = null;
        org.jfree.chart.util.Layer layer29 = null;
        try {
            categoryPlot23.addDomainMarker(categoryMarker28, layer29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateTopInset((double) 10);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            rectangleInsets0.trim(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font11 = null;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 1, font11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double14 = rectangleInsets13.getRight();
        categoryAxis0.setLabelInsets(rectangleInsets13, true);
        float float17 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        categoryAxis0.setFixedDimension((double) 1.0f);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions20 = null;
        try {
            categoryAxis0.setCategoryLabelPositions(categoryLabelPositions20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.0f + "'", float17 == 0.0f);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        int int17 = categoryPlot15.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace18 = null;
        categoryPlot15.setFixedDomainAxisSpace(axisSpace18);
        org.jfree.chart.axis.AxisSpace axisSpace20 = categoryPlot15.getFixedDomainAxisSpace();
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        double double30 = categoryAxis22.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D28, rectangleEdge29);
        int int31 = categoryAxis22.getCategoryLabelPositionOffset();
        categoryAxis22.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis34, categoryItemRenderer35);
        java.awt.Paint paint37 = categoryPlot36.getRangeCrosshairPaint();
        int int38 = categoryPlot36.getWeight();
        java.lang.Comparable comparable39 = null;
        categoryPlot36.setDomainCrosshairRowKey(comparable39, true);
        org.jfree.chart.util.SortOrder sortOrder42 = categoryPlot36.getRowRenderingOrder();
        categoryPlot15.setColumnRenderingOrder(sortOrder42);
        java.lang.Object obj44 = categoryPlot15.clone();
        try {
            categoryPlot15.mapDatasetToDomainAxis((-16777216), 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'index' >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(axisSpace20);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(sortOrder42);
        org.junit.Assert.assertNotNull(obj44);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        java.awt.Font font5 = lineAndShapeRenderer2.getBaseItemLabelFont();
        java.lang.Boolean boolean7 = lineAndShapeRenderer2.getSeriesVisible((-14336));
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double11 = rectangleInsets9.calculateTopInset((double) 10);
        double double13 = rectangleInsets9.calculateRightOutset(100.0d);
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.renderer.RenderAttributes renderAttributes16 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint18 = renderAttributes16.getSeriesOutlinePaint((int) '4');
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        renderAttributes16.setDefaultOutlinePaint(paint19);
        boolean boolean21 = textAnchor14.equals((java.lang.Object) renderAttributes16);
        boolean boolean22 = rectangleInsets9.equals((java.lang.Object) renderAttributes16);
        java.awt.Paint paint24 = renderAttributes16.getSeriesOutlinePaint(5);
        java.awt.Paint paint27 = renderAttributes16.getItemPaint((int) ' ', (int) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier28 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke29 = defaultDrawingSupplier28.getNextStroke();
        renderAttributes16.setDefaultOutlineStroke(stroke29);
        try {
            lineAndShapeRenderer2.setSeriesStroke((-12566464), stroke29, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertNull(paint27);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        java.awt.Stroke stroke17 = categoryPlot15.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot15.zoomRangeAxes((double) (short) -1, plotRenderingInfo19, point2D20, false);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot15.getRowRenderingOrder();
        try {
            categoryPlot15.zoom((double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(sortOrder23);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        java.awt.Paint paint18 = categoryPlot15.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        categoryPlot15.setDataset(categoryDataset19);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot15.getRangeAxisEdge();
        org.jfree.chart.plot.Plot plot22 = categoryPlot15.getRootPlot();
        categoryPlot15.setDomainCrosshairColumnKey((java.lang.Comparable) 255, true);
        int int26 = categoryPlot15.getCrosshairDatasetIndex();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(plot22);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator5, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer2.getBaseNegativeItemLabelPosition();
        org.junit.Assert.assertNotNull(itemLabelPosition8);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "");
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape7);
        chartEntity6.setArea(shape7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape7, (java.awt.Paint) color10);
        legendItem11.setURLText("{0}");
        java.awt.Stroke stroke14 = legendItem11.getOutlineStroke();
        legendItem11.setShapeVisible(false);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = new org.jfree.chart.LegendItemCollection();
        legendItemCollection0.addAll(legendItemCollection1);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = categoryAxis3.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D9, rectangleEdge10);
        int int12 = categoryAxis3.getCategoryLabelPositionOffset();
        categoryAxis3.setMaximumCategoryLabelLines(4);
        categoryAxis3.setLowerMargin(0.0d);
        float float17 = categoryAxis3.getMinorTickMarkOutsideLength();
        boolean boolean18 = legendItemCollection0.equals((java.lang.Object) float17);
        java.lang.Object obj19 = legendItemCollection0.clone();
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 2.0f + "'", float17 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Color color3 = java.awt.Color.blue;
        renderAttributes1.setSeriesFillPaint(0, (java.awt.Paint) color3);
        java.awt.Font font5 = renderAttributes1.getDefaultLabelFont();
        java.awt.Stroke stroke8 = renderAttributes1.getItemStroke(4, (int) (short) 100);
        java.awt.Color color9 = java.awt.Color.GREEN;
        renderAttributes1.setDefaultPaint((java.awt.Paint) color9);
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        renderAttributes1.setSeriesFillPaint((int) (byte) 100, paint12);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNull(stroke8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj1 = standardGradientPaintTransformer0.clone();
        java.lang.Object obj2 = standardGradientPaintTransformer0.clone();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType3 = standardGradientPaintTransformer0.getType();
        java.lang.String str4 = gradientPaintTransformType3.toString();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(gradientPaintTransformType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GradientPaintTransformType.VERTICAL" + "'", str4.equals("GradientPaintTransformType.VERTICAL"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMinorTickMarkInsideLength();
        boolean boolean2 = categoryAxis0.isMinorTickMarksVisible();
        boolean boolean3 = categoryAxis0.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot4 = null;
        categoryAxis0.setPlot(plot4);
        java.awt.Paint paint7 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) 100L);
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        categoryAxis0.setLabelPaint((java.awt.Paint) color8);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int2 = color1.getAlpha();
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator6 = new org.jfree.chart.util.DefaultShadowGenerator((int) (short) 0, color1, (-1.0f), 10, (double) (short) 1);
        java.awt.Color color7 = defaultShadowGenerator6.getShadowColor();
        int int8 = color7.getGreen();
        java.awt.Color color9 = java.awt.Color.DARK_GRAY;
        java.awt.color.ColorSpace colorSpace10 = color9.getColorSpace();
        org.jfree.data.KeyedObjects2D keyedObjects2D11 = new org.jfree.data.KeyedObjects2D();
        java.awt.Color color12 = java.awt.Color.BLACK;
        boolean boolean13 = keyedObjects2D11.equals((java.lang.Object) color12);
        java.awt.Color color14 = java.awt.Color.DARK_GRAY;
        java.awt.color.ColorSpace colorSpace15 = color14.getColorSpace();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int17 = color16.getBlue();
        float[] floatArray21 = new float[] { '#', (byte) 10, (short) 100 };
        float[] floatArray22 = color16.getColorComponents(floatArray21);
        float[] floatArray23 = color12.getColorComponents(colorSpace15, floatArray21);
        try {
            float[] floatArray24 = color7.getComponents(colorSpace10, floatArray21);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 128 + "'", int8 == 128);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(colorSpace10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(colorSpace15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        org.jfree.chart.plot.Plot plot9 = categoryAxis0.getPlot();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(plot9);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        java.awt.Shape shape3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape3);
        chartEntity2.setArea(shape3);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = categoryAxis7.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D13, rectangleEdge14);
        int int16 = categoryAxis7.getCategoryLabelPositionOffset();
        categoryAxis7.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.util.ObjectList objectList24 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        float float27 = categoryAxis26.getMinorTickMarkInsideLength();
        boolean boolean28 = categoryAxis26.isMinorTickMarksVisible();
        categoryAxis26.setLabelURL("hi!");
        objectList24.set((int) (short) 10, (java.lang.Object) categoryAxis26);
        org.jfree.chart.plot.Plot plot32 = null;
        categoryAxis26.setPlot(plot32);
        categoryAxis26.setCategoryMargin((double) (-1));
        categoryPlot21.setDomainAxis((int) '#', categoryAxis26);
        categoryPlot21.configureRangeAxes();
        org.jfree.chart.entity.PlotEntity plotEntity38 = new org.jfree.chart.entity.PlotEntity(shape3, (org.jfree.chart.plot.Plot) categoryPlot21);
        boolean boolean39 = categoryPlot21.canSelectByPoint();
        categoryPlot21.setRangeCrosshairValue((double) (short) 10, false);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.0f + "'", float27 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = abstractCategoryDataset0.hasListener(eventListener1);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener3 = null;
        abstractCategoryDataset0.removeChangeListener(datasetChangeListener3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = categoryAxis6.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D12, rectangleEdge13);
        int int15 = categoryAxis6.getCategoryLabelPositionOffset();
        categoryAxis6.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis18, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeCrosshairPaint();
        int int22 = categoryPlot20.getWeight();
        abstractCategoryDataset0.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot20);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = null;
        double double33 = categoryAxis25.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D31, rectangleEdge32);
        int int34 = categoryAxis25.getCategoryLabelPositionOffset();
        categoryAxis25.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis37, categoryItemRenderer38);
        org.jfree.chart.util.ObjectList objectList42 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis();
        float float45 = categoryAxis44.getMinorTickMarkInsideLength();
        boolean boolean46 = categoryAxis44.isMinorTickMarksVisible();
        categoryAxis44.setLabelURL("hi!");
        objectList42.set((int) (short) 10, (java.lang.Object) categoryAxis44);
        org.jfree.chart.plot.Plot plot50 = null;
        categoryAxis44.setPlot(plot50);
        categoryAxis44.setCategoryMargin((double) (-1));
        categoryPlot39.setDomainAxis((int) '#', categoryAxis44);
        org.jfree.chart.axis.ValueAxis valueAxis55 = categoryPlot39.getRangeAxis();
        boolean boolean56 = abstractCategoryDataset0.hasListener((java.util.EventListener) categoryPlot39);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 4 + "'", int34 == 4);
        org.junit.Assert.assertTrue("'" + float45 + "' != '" + 0.0f + "'", float45 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(valueAxis55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        java.awt.Paint paint18 = categoryPlot15.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        categoryPlot15.setDataset(categoryDataset19);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot15.getRangeAxisEdge();
        boolean boolean22 = categoryPlot15.isRangeGridlinesVisible();
        org.jfree.chart.renderer.RenderAttributes renderAttributes24 = new org.jfree.chart.renderer.RenderAttributes(false);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        double double34 = categoryAxis26.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D32, rectangleEdge33);
        int int35 = categoryAxis26.getCategoryLabelPositionOffset();
        categoryAxis26.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, valueAxis38, categoryItemRenderer39);
        java.awt.Paint paint41 = categoryPlot40.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor42 = categoryPlot40.getDomainGridlinePosition();
        java.awt.Paint paint43 = categoryPlot40.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset44 = null;
        categoryPlot40.setDataset(categoryDataset44);
        org.jfree.chart.LegendItemCollection legendItemCollection46 = categoryPlot40.getLegendItems();
        java.awt.Stroke stroke47 = categoryPlot40.getRangeGridlineStroke();
        renderAttributes24.setDefaultStroke(stroke47);
        categoryPlot15.setRangeCrosshairStroke(stroke47);
        categoryPlot15.clearSelection();
        java.awt.Paint paint51 = categoryPlot15.getDomainGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        java.awt.geom.Point2D point2D55 = null;
        categoryPlot15.zoomRangeAxes((double) 4, 0.0d, plotRenderingInfo54, point2D55);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(categoryAnchor42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(legendItemCollection46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(paint51);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        java.awt.Font font5 = lineAndShapeRenderer2.getBaseItemLabelFont();
        java.lang.Boolean boolean7 = lineAndShapeRenderer2.getSeriesVisible((-14336));
        lineAndShapeRenderer2.setSeriesShapesFilled((int) ' ', false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset15 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener16 = null;
        boolean boolean17 = abstractCategoryDataset15.hasListener(eventListener16);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener18 = null;
        abstractCategoryDataset15.removeChangeListener(datasetChangeListener18);
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = null;
        double double29 = categoryAxis21.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D27, rectangleEdge28);
        int int30 = categoryAxis21.getCategoryLabelPositionOffset();
        categoryAxis21.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, valueAxis33, categoryItemRenderer34);
        java.awt.Paint paint36 = categoryPlot35.getRangeCrosshairPaint();
        int int37 = categoryPlot35.getWeight();
        abstractCategoryDataset15.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot35);
        lineAndShapeRenderer14.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot35);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor41 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor42 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition43 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor41, textAnchor42);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer45 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj46 = standardGradientPaintTransformer45.clone();
        boolean boolean47 = categoryAxis44.equals((java.lang.Object) standardGradientPaintTransformer45);
        boolean boolean48 = itemLabelPosition43.equals((java.lang.Object) boolean47);
        double double49 = itemLabelPosition43.getAngle();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor50 = itemLabelPosition43.getItemLabelAnchor();
        lineAndShapeRenderer14.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition43);
        lineAndShapeRenderer2.setSeriesNegativeItemLabelPosition(0, itemLabelPosition43, true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(itemLabelAnchor41);
        org.junit.Assert.assertNotNull(textAnchor42);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor50);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        abstractCategoryDataset0.validateObject();
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMinorTickMarkInsideLength();
        boolean boolean2 = categoryAxis0.isMinorTickMarksVisible();
        java.lang.String str4 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) 1);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = categoryAxis0.getCategorySeriesMiddle((int) (byte) 10, (int) '#', (int) (short) 1, (-8323073), (double) 1.0f, rectangle2D10, rectangleEdge11);
        categoryAxis0.setTickMarkInsideLength((float) 5);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator0 = new org.jfree.chart.util.DefaultShadowGenerator();
        int int1 = defaultShadowGenerator0.calculateOffsetY();
        int int2 = defaultShadowGenerator0.getDistance();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2) + "'", int1 == (-2));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        java.lang.String str3 = chartEntity2.getShapeType();
        java.lang.String str4 = chartEntity2.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "poly" + "'", str3.equals("poly"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "ChartEntity: tooltip = " + "'", str4.equals("ChartEntity: tooltip = "));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        java.awt.Paint paint18 = categoryPlot15.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        categoryPlot15.setDataset(categoryDataset19);
        org.jfree.chart.LegendItemCollection legendItemCollection21 = categoryPlot15.getLegendItems();
        boolean boolean22 = categoryPlot15.canSelectByPoint();
        int int23 = categoryPlot15.getRangeAxisCount();
        categoryPlot15.setDrawSharedDomainAxis(true);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = null;
        try {
            categoryPlot15.setDatasetRenderingOrder(datasetRenderingOrder26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(legendItemCollection21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        boolean boolean18 = categoryPlot15.isNotify();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = null;
        try {
            categoryPlot15.setAxisOffset(rectangleInsets19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'offset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("java.awt.Color[r=128,g=128,b=128]");
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        java.awt.Paint paint18 = categoryPlot15.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        categoryPlot15.setDataset(categoryDataset19);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot15.getRangeAxisEdge();
        boolean boolean22 = categoryPlot15.isRangeGridlinesVisible();
        org.jfree.chart.renderer.RenderAttributes renderAttributes24 = new org.jfree.chart.renderer.RenderAttributes(false);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        double double34 = categoryAxis26.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D32, rectangleEdge33);
        int int35 = categoryAxis26.getCategoryLabelPositionOffset();
        categoryAxis26.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, valueAxis38, categoryItemRenderer39);
        java.awt.Paint paint41 = categoryPlot40.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor42 = categoryPlot40.getDomainGridlinePosition();
        java.awt.Paint paint43 = categoryPlot40.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset44 = null;
        categoryPlot40.setDataset(categoryDataset44);
        org.jfree.chart.LegendItemCollection legendItemCollection46 = categoryPlot40.getLegendItems();
        java.awt.Stroke stroke47 = categoryPlot40.getRangeGridlineStroke();
        renderAttributes24.setDefaultStroke(stroke47);
        categoryPlot15.setRangeCrosshairStroke(stroke47);
        categoryPlot15.clearSelection();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        java.awt.geom.Point2D point2D53 = null;
        categoryPlot15.panRangeAxes(0.0d, plotRenderingInfo52, point2D53);
        org.jfree.chart.axis.CategoryAxis categoryAxis56 = categoryPlot15.getDomainAxis(255);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(categoryAnchor42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(legendItemCollection46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNull(categoryAxis56);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        java.lang.String str3 = chartEntity2.getShapeType();
        java.lang.String str4 = chartEntity2.getShapeCoords();
        java.awt.Shape shape5 = chartEntity2.getArea();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape6, "");
        java.lang.String str9 = chartEntity8.getShapeType();
        java.lang.Object obj10 = chartEntity8.clone();
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape11, "");
        chartEntity8.setArea(shape11);
        chartEntity2.setArea(shape11);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "poly" + "'", str3.equals("poly"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0" + "'", str4.equals("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0"));
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "poly" + "'", str9.equals("poly"));
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font11 = null;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 1, font11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double14 = rectangleInsets13.getRight();
        categoryAxis0.setLabelInsets(rectangleInsets13, true);
        org.jfree.chart.util.UnitType unitType17 = rectangleInsets13.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets(unitType17, 10.0d, (double) 0, (double) (-1L), (-1.0d));
        java.awt.Shape shape27 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity29 = new org.jfree.chart.entity.ChartEntity(shape27, "");
        java.awt.Shape shape30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape30);
        chartEntity29.setArea(shape30);
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape30, (java.awt.Paint) color33);
        legendItem34.setURLText("");
        boolean boolean37 = unitType17.equals((java.lang.Object) legendItem34);
        int int38 = legendItem34.getSeriesIndex();
        boolean boolean39 = legendItem34.isShapeVisible();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(unitType17);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        java.awt.Paint paint18 = categoryPlot15.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        categoryPlot15.setDataset(categoryDataset19);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot15.getRangeAxisEdge();
        boolean boolean22 = categoryPlot15.isRangeGridlinesVisible();
        boolean boolean23 = categoryPlot15.isDomainPannable();
        categoryPlot15.setDomainCrosshairColumnKey((java.lang.Comparable) "", true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.awt.Color color1 = java.awt.Color.BLACK;
        boolean boolean2 = keyedObjects2D0.equals((java.lang.Object) color1);
        int int4 = keyedObjects2D0.getRowIndex((java.lang.Comparable) 1.0d);
        java.lang.Comparable comparable5 = null;
        try {
            java.lang.Object obj7 = keyedObjects2D0.getObject(comparable5, (java.lang.Comparable) "PlotEntity: tooltip = null");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        int int17 = categoryPlot15.getWeight();
        categoryPlot15.configureDomainAxes();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray19 = null;
        try {
            categoryPlot15.setRangeAxes(valueAxisArray19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.setMaximumCategoryLabelLines(4);
        categoryAxis0.setLowerMargin(0.0d);
        double double14 = categoryAxis0.getFixedDimension();
        float float15 = categoryAxis0.getTickMarkOutsideLength();
        float float16 = categoryAxis0.getTickMarkInsideLength();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 2.0f + "'", float15 == 2.0f);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.0f + "'", float16 == 0.0f);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateTopInset((double) 10);
        double double4 = rectangleInsets0.calculateRightOutset(100.0d);
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.renderer.RenderAttributes renderAttributes7 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint9 = renderAttributes7.getSeriesOutlinePaint((int) '4');
        java.awt.Paint paint10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        renderAttributes7.setDefaultOutlinePaint(paint10);
        boolean boolean12 = textAnchor5.equals((java.lang.Object) renderAttributes7);
        boolean boolean13 = rectangleInsets0.equals((java.lang.Object) renderAttributes7);
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes7.setDefaultOutlineStroke(stroke14);
        java.awt.Color color17 = java.awt.Color.red;
        renderAttributes7.setSeriesFillPaint((int) '4', (java.awt.Paint) color17);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=128,g=0,b=128]" + "'", str1.equals("java.awt.Color[r=128,g=0,b=128]"));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis2.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D8, rectangleEdge9);
        int int11 = categoryAxis2.getCategoryLabelPositionOffset();
        categoryAxis2.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis14, categoryItemRenderer15);
        java.awt.Paint paint17 = categoryPlot16.getRangeCrosshairPaint();
        int int18 = categoryPlot16.getWeight();
        boolean boolean19 = categoryPlot16.canSelectByPoint();
        java.awt.Paint paint20 = categoryPlot16.getRangeZeroBaselinePaint();
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("ItemLabelAnchor.INSIDE6", paint20);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font11 = null;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 1, font11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double14 = rectangleInsets13.getRight();
        categoryAxis0.setLabelInsets(rectangleInsets13, true);
        org.jfree.chart.util.UnitType unitType17 = rectangleInsets13.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets(unitType17, 10.0d, (double) 0, (double) (-1L), (-1.0d));
        java.awt.Shape shape27 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity29 = new org.jfree.chart.entity.ChartEntity(shape27, "");
        java.awt.Shape shape30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape30);
        chartEntity29.setArea(shape30);
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape30, (java.awt.Paint) color33);
        legendItem34.setURLText("");
        boolean boolean37 = unitType17.equals((java.lang.Object) legendItem34);
        legendItem34.setDescription("DatasetRenderingOrder.FORWARD");
        java.awt.Paint paint40 = legendItem34.getFillPaint();
        java.awt.Stroke stroke41 = legendItem34.getLineStroke();
        legendItem34.setLineVisible(false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(unitType17);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font11 = null;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 1, font11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double14 = rectangleInsets13.getRight();
        categoryAxis0.setLabelInsets(rectangleInsets13, true);
        float float17 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        categoryAxis0.setFixedDimension((double) 1.0f);
        boolean boolean20 = categoryAxis0.isAxisLineVisible();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.0f + "'", float17 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        categoryPlot15.addChangeListener(plotChangeListener16);
        boolean boolean18 = categoryPlot15.isRangeZoomable();
        int int19 = categoryPlot15.getDomainAxisCount();
        org.jfree.chart.LegendItemCollection legendItemCollection20 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.LegendItemCollection legendItemCollection21 = new org.jfree.chart.LegendItemCollection();
        legendItemCollection20.addAll(legendItemCollection21);
        int int23 = legendItemCollection20.getItemCount();
        java.util.Iterator iterator24 = legendItemCollection20.iterator();
        int int25 = legendItemCollection20.getItemCount();
        categoryPlot15.setFixedLegendItems(legendItemCollection20);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation27 = null;
        try {
            boolean boolean29 = categoryPlot15.removeAnnotation(categoryAnnotation27, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(iterator24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        org.jfree.data.KeyedObjects2D keyedObjects2D18 = new org.jfree.data.KeyedObjects2D();
        java.awt.Color color19 = java.awt.Color.BLACK;
        boolean boolean20 = keyedObjects2D18.equals((java.lang.Object) color19);
        int int21 = color19.getTransparency();
        categoryPlot15.setRangeGridlinePaint((java.awt.Paint) color19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot15.zoomRangeAxes((double) 0L, plotRenderingInfo24, point2D25, true);
        org.jfree.chart.util.ShadowGenerator shadowGenerator28 = categoryPlot15.getShadowGenerator();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(shadowGenerator28);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = java.awt.Color.YELLOW;
        try {
            org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem(attributedString0, "java.awt.Color[r=128,g=0,b=128]", "org.jfree.data.UnknownKeyException: 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0", "", shape4, (java.awt.Paint) color5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        boolean boolean2 = legendItem1.isShapeOutlineVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        java.awt.Color color1 = java.awt.Color.blue;
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator5 = new org.jfree.chart.util.DefaultShadowGenerator(0, color1, 0.0f, (int) '4', 0.0d);
        java.awt.image.BufferedImage bufferedImage6 = null;
        try {
            java.awt.image.BufferedImage bufferedImage7 = defaultShadowGenerator5.createDropShadow(bufferedImage6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator5, true);
        java.lang.Boolean boolean9 = lineAndShapeRenderer2.getSeriesVisible((int) (short) 100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        lineAndShapeRenderer2.setSeriesItemLabelGenerator(1, categoryItemLabelGenerator11);
        org.junit.Assert.assertNull(boolean9);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        int int17 = categoryPlot15.getWeight();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        categoryPlot15.setRenderer(categoryItemRenderer18);
        categoryPlot15.clearRangeMarkers((-255));
        org.jfree.chart.LegendItemCollection legendItemCollection22 = new org.jfree.chart.LegendItemCollection();
        categoryPlot15.setFixedLegendItems(legendItemCollection22);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = categoryPlot15.getDomainAxis((-1));
        categoryPlot15.setAnchorValue((double) (short) 10, false);
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        org.jfree.chart.plot.CategoryCrosshairState categoryCrosshairState33 = null;
        boolean boolean34 = categoryPlot15.render(graphics2D29, rectangle2D30, (int) (byte) 10, plotRenderingInfo32, categoryCrosshairState33);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(categoryAxis25);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        java.awt.Paint paint18 = categoryPlot15.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        categoryPlot15.setDataset(categoryDataset19);
        org.jfree.chart.LegendItemCollection legendItemCollection21 = categoryPlot15.getLegendItems();
        boolean boolean22 = categoryPlot15.canSelectByPoint();
        org.jfree.chart.event.PlotChangeListener plotChangeListener23 = null;
        categoryPlot15.removeChangeListener(plotChangeListener23);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(legendItemCollection21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = keyedObjects2D0.clone();
        int int3 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 'a');
        int int4 = keyedObjects2D0.getColumnCount();
        org.jfree.chart.renderer.category.BarPainter barPainter5 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
        org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(barPainter5);
        java.lang.Comparable comparable7 = null;
        try {
            keyedObjects2D0.addObject((java.lang.Object) barPainter5, comparable7, (java.lang.Comparable) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(barPainter5);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "");
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape7);
        chartEntity6.setArea(shape7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape7, (java.awt.Paint) color10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int13 = color12.getBlue();
        float[] floatArray17 = new float[] { '#', (byte) 10, (short) 100 };
        float[] floatArray18 = color12.getColorComponents(floatArray17);
        legendItem11.setFillPaint((java.awt.Paint) color12);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        java.awt.Stroke stroke9 = categoryAxis0.getTickMarkStroke();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = categoryAxis12.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D18, rectangleEdge19);
        int int21 = categoryAxis12.getCategoryLabelPositionOffset();
        categoryAxis12.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis24, categoryItemRenderer25);
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        double double37 = categoryAxis29.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D35, rectangleEdge36);
        int int38 = categoryAxis29.getCategoryLabelPositionOffset();
        categoryAxis29.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis41, categoryItemRenderer42);
        org.jfree.chart.event.PlotChangeListener plotChangeListener44 = null;
        categoryPlot43.addChangeListener(plotChangeListener44);
        categoryPlot43.setDomainCrosshairColumnKey((java.lang.Comparable) 5, false);
        categoryPlot43.mapDatasetToRangeAxis(0, 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = categoryPlot43.getDomainAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace53 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace54 = categoryAxis0.reserveSpace(graphics2D10, (org.jfree.chart.plot.Plot) categoryPlot26, rectangle2D27, rectangleEdge52, axisSpace53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 4 + "'", int38 == 4);
        org.junit.Assert.assertNotNull(rectangleEdge52);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape0);
        java.lang.String str2 = chartChangeEvent1.toString();
        org.jfree.chart.JFreeChart jFreeChart3 = chartChangeEvent1.getChart();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]" + "'", str2.equals("org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]"));
        org.junit.Assert.assertNull(jFreeChart3);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        java.awt.Paint paint18 = categoryPlot15.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        categoryPlot15.setDataset(categoryDataset19);
        org.jfree.chart.LegendItemCollection legendItemCollection21 = categoryPlot15.getLegendItems();
        boolean boolean22 = categoryPlot15.canSelectByPoint();
        int int23 = categoryPlot15.getRangeAxisCount();
        categoryPlot15.clearRangeAxes();
        categoryPlot15.setCrosshairDatasetIndex(0);
        org.jfree.chart.util.ShadowGenerator shadowGenerator27 = categoryPlot15.getShadowGenerator();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(legendItemCollection21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(shadowGenerator27);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        java.lang.Number number0 = null;
        org.jfree.data.SelectableValue selectableValue1 = new org.jfree.data.SelectableValue(number0);
        selectableValue1.setSelected(false);
        boolean boolean4 = selectableValue1.isSelected();
        selectableValue1.setSelected(false);
        boolean boolean7 = selectableValue1.isSelected();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint33 = renderAttributes31.getSeriesOutlinePaint((int) '4');
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes31.setDefaultStroke(stroke34);
        lineAndShapeRenderer2.setSeriesStroke(0, stroke34, false);
        boolean boolean40 = lineAndShapeRenderer2.getItemShapeVisible((-16777216), 8);
        java.awt.Paint paint41 = null;
        lineAndShapeRenderer2.setBaseLegendTextPaint(paint41);
        boolean boolean43 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = keyedObjects2D0.clone();
        int int3 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 'a');
        int int4 = keyedObjects2D0.getColumnCount();
        try {
            keyedObjects2D0.removeColumn((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.util.ObjectList objectList18 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        float float21 = categoryAxis20.getMinorTickMarkInsideLength();
        boolean boolean22 = categoryAxis20.isMinorTickMarksVisible();
        categoryAxis20.setLabelURL("hi!");
        objectList18.set((int) (short) 10, (java.lang.Object) categoryAxis20);
        org.jfree.chart.plot.Plot plot26 = null;
        categoryAxis20.setPlot(plot26);
        categoryAxis20.setCategoryMargin((double) (-1));
        categoryPlot15.setDomainAxis((int) '#', categoryAxis20);
        categoryPlot15.configureRangeAxes();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder32 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str33 = datasetRenderingOrder32.toString();
        categoryPlot15.setDatasetRenderingOrder(datasetRenderingOrder32);
        java.lang.String str35 = datasetRenderingOrder32.toString();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str33.equals("DatasetRenderingOrder.FORWARD"));
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str35.equals("DatasetRenderingOrder.FORWARD"));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity1 = new org.jfree.chart.entity.ChartEntity(shape0);
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        boolean boolean5 = lineAndShapeRenderer2.getBaseShapesFilled();
        java.lang.Boolean boolean7 = lineAndShapeRenderer2.getSeriesCreateEntities(2);
        lineAndShapeRenderer2.setAutoPopulateSeriesOutlinePaint(false);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = categoryAxis11.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D17, rectangleEdge18);
        int int20 = categoryAxis11.getCategoryLabelPositionOffset();
        categoryAxis11.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis23, categoryItemRenderer24);
        org.jfree.chart.event.PlotChangeListener plotChangeListener26 = null;
        categoryPlot25.addChangeListener(plotChangeListener26);
        boolean boolean28 = lineAndShapeRenderer2.hasListener((java.util.EventListener) plotChangeListener26);
        lineAndShapeRenderer2.setSeriesVisibleInLegend((int) (short) 1, (java.lang.Boolean) true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint33 = renderAttributes31.getSeriesOutlinePaint((int) '4');
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes31.setDefaultStroke(stroke34);
        lineAndShapeRenderer2.setSeriesStroke(0, stroke34, false);
        java.awt.Paint paint39 = lineAndShapeRenderer2.getSeriesItemLabelPaint((int) (byte) 10);
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset41 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset42 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = null;
        double double51 = categoryAxis43.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D49, rectangleEdge50);
        int int52 = categoryAxis43.getCategoryLabelPositionOffset();
        categoryAxis43.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer56 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, valueAxis55, categoryItemRenderer56);
        java.awt.Paint paint58 = categoryPlot57.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker59 = null;
        org.jfree.chart.util.Layer layer60 = null;
        boolean boolean61 = categoryPlot57.removeDomainMarker(marker59, layer60);
        boolean boolean62 = categoryPlot57.isRangeMinorGridlinesVisible();
        boolean boolean63 = abstractCategoryDataset41.hasListener((java.util.EventListener) categoryPlot57);
        org.jfree.chart.util.Layer layer64 = null;
        java.util.Collection collection65 = categoryPlot57.getDomainMarkers(layer64);
        boolean boolean66 = categoryPlot57.isDomainPannable();
        categoryPlot57.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets69 = categoryPlot57.getAxisOffset();
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        java.awt.Color color72 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.data.category.CategoryDataset categoryDataset73 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis74 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D80 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge81 = null;
        double double82 = categoryAxis74.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D80, rectangleEdge81);
        int int83 = categoryAxis74.getCategoryLabelPositionOffset();
        categoryAxis74.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis86 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer87 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot88 = new org.jfree.chart.plot.CategoryPlot(categoryDataset73, categoryAxis74, valueAxis86, categoryItemRenderer87);
        java.awt.Paint paint89 = categoryPlot88.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor90 = categoryPlot88.getDomainGridlinePosition();
        java.awt.Paint paint91 = categoryPlot88.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset92 = null;
        categoryPlot88.setDataset(categoryDataset92);
        org.jfree.chart.LegendItemCollection legendItemCollection94 = categoryPlot88.getLegendItems();
        java.awt.Stroke stroke95 = categoryPlot88.getRangeGridlineStroke();
        try {
            lineAndShapeRenderer2.drawDomainLine(graphics2D40, categoryPlot57, rectangle2D70, 100.0d, (java.awt.Paint) color72, stroke95);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 4 + "'", int52 == 4);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNull(collection65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(rectangleInsets69);
        org.junit.Assert.assertNotNull(color72);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 4 + "'", int83 == 4);
        org.junit.Assert.assertNotNull(paint89);
        org.junit.Assert.assertNotNull(categoryAnchor90);
        org.junit.Assert.assertNotNull(paint91);
        org.junit.Assert.assertNotNull(legendItemCollection94);
        org.junit.Assert.assertNotNull(stroke95);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean19 = categoryPlot15.removeDomainMarker(marker17, layer18);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot15.getRangeMarkers(layer20);
        java.awt.Font font22 = categoryPlot15.getNoDataMessageFont();
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        categoryPlot15.setRangeMinorGridlinePaint((java.awt.Paint) color23);
        java.awt.Paint paint25 = categoryPlot15.getOutlinePaint();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "");
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape7);
        chartEntity6.setArea(shape7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape7, (java.awt.Paint) color10);
        legendItem11.setURLText("{0}");
        java.awt.Paint paint14 = legendItem11.getOutlinePaint();
        java.awt.Paint paint15 = legendItem11.getLinePaint();
        java.lang.String str16 = legendItem11.getToolTipText();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]" + "'", str16.equals("org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]"));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.lang.Object obj1 = shapeList0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator5, true);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator8 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        lineAndShapeRenderer2.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator8);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = lineAndShapeRenderer2.getLegendItemToolTipGenerator();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = categoryAxis12.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D18, rectangleEdge19);
        int int21 = categoryAxis12.getCategoryLabelPositionOffset();
        categoryAxis12.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis24, categoryItemRenderer25);
        java.awt.Paint paint27 = categoryPlot26.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor28 = categoryPlot26.getDomainGridlinePosition();
        org.jfree.data.KeyedObjects2D keyedObjects2D29 = new org.jfree.data.KeyedObjects2D();
        java.awt.Color color30 = java.awt.Color.BLACK;
        boolean boolean31 = keyedObjects2D29.equals((java.lang.Object) color30);
        int int32 = color30.getTransparency();
        categoryPlot26.setRangeGridlinePaint((java.awt.Paint) color30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        categoryPlot26.zoomRangeAxes((double) 0L, plotRenderingInfo35, point2D36, true);
        lineAndShapeRenderer2.setPlot(categoryPlot26);
        java.awt.Graphics2D graphics2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        try {
            categoryPlot26.drawBackground(graphics2D40, rectangle2D41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categorySeriesLabelGenerator10);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(categoryAnchor28);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        java.lang.String str3 = chartEntity2.getShapeCoords();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0" + "'", str3.equals("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        int int17 = categoryPlot15.getWeight();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        categoryPlot15.setRenderer(categoryItemRenderer18);
        categoryPlot15.clearRangeMarkers((-255));
        org.jfree.chart.LegendItemCollection legendItemCollection22 = new org.jfree.chart.LegendItemCollection();
        categoryPlot15.setFixedLegendItems(legendItemCollection22);
        boolean boolean24 = categoryPlot15.isDomainCrosshairVisible();
        boolean boolean25 = categoryPlot15.isRangePannable();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        java.awt.Stroke stroke9 = categoryAxis0.getAxisLineStroke();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis2.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D8, rectangleEdge9);
        int int11 = categoryAxis2.getCategoryLabelPositionOffset();
        categoryAxis2.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis14, categoryItemRenderer15);
        java.awt.Paint paint17 = categoryPlot16.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = categoryPlot16.removeDomainMarker(marker18, layer19);
        boolean boolean21 = categoryPlot16.isRangeMinorGridlinesVisible();
        boolean boolean22 = abstractCategoryDataset0.hasListener((java.util.EventListener) categoryPlot16);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot16.getDomainMarkers(layer23);
        boolean boolean25 = categoryPlot16.isDomainPannable();
        categoryPlot16.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryPlot16.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = categoryPlot16.getDatasetRenderingOrder();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer33.setBaseItemLabelsVisible(false);
        boolean boolean36 = lineAndShapeRenderer33.getBaseShapesFilled();
        categoryPlot16.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer33);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator38 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        java.lang.Object obj39 = standardCategorySeriesLabelGenerator38.clone();
        lineAndShapeRenderer33.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator38);
        try {
            lineAndShapeRenderer33.setSeriesVisible((-254), (java.lang.Boolean) true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(obj39);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        int int17 = categoryPlot15.getWeight();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        categoryPlot15.setRenderer(categoryItemRenderer18);
        categoryPlot15.clearRangeMarkers((-255));
        org.jfree.chart.LegendItemCollection legendItemCollection22 = new org.jfree.chart.LegendItemCollection();
        categoryPlot15.setFixedLegendItems(legendItemCollection22);
        categoryPlot15.setOutlineVisible(false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        int int17 = categoryPlot15.getWeight();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        categoryPlot15.setRenderer(categoryItemRenderer18);
        categoryPlot15.clearRangeMarkers((-255));
        org.jfree.chart.LegendItemCollection legendItemCollection22 = new org.jfree.chart.LegendItemCollection();
        categoryPlot15.setFixedLegendItems(legendItemCollection22);
        try {
            org.jfree.chart.LegendItem legendItem25 = legendItemCollection22.get((-254));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        boolean boolean5 = lineAndShapeRenderer2.getBaseShapesFilled();
        java.lang.Boolean boolean7 = lineAndShapeRenderer2.getSeriesLinesVisible(100);
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = lineAndShapeRenderer2.getSelectedItemAttributes();
        lineAndShapeRenderer2.setSeriesShapesVisible((int) (byte) 0, true);
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        try {
            lineAndShapeRenderer2.setLegendTextFont((-254), font13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        java.awt.Paint paint18 = categoryPlot15.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        categoryPlot15.setDataset(categoryDataset19);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = categoryPlot15.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(drawingSupplier21);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = keyedObjects2D0.clone();
        int int3 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 'a');
        int int4 = keyedObjects2D0.getColumnCount();
        java.awt.Paint[] paintArray5 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        boolean boolean6 = keyedObjects2D0.equals((java.lang.Object) paintArray5);
        java.util.List list7 = keyedObjects2D0.getColumnKeys();
        try {
            keyedObjects2D0.removeRow((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.trimHeight(0.0d);
        double double3 = rectangleInsets0.getLeft();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = rectangleInsets0.createInsetRectangle(rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis2.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D8, rectangleEdge9);
        int int11 = categoryAxis2.getCategoryLabelPositionOffset();
        categoryAxis2.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis14, categoryItemRenderer15);
        java.awt.Paint paint17 = categoryPlot16.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = categoryPlot16.removeDomainMarker(marker18, layer19);
        boolean boolean21 = categoryPlot16.isRangeMinorGridlinesVisible();
        boolean boolean22 = abstractCategoryDataset0.hasListener((java.util.EventListener) categoryPlot16);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot16.getDomainMarkers(layer23);
        boolean boolean25 = categoryPlot16.isDomainPannable();
        categoryPlot16.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryPlot16.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = categoryPlot16.getDatasetRenderingOrder();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer33.setBaseItemLabelsVisible(false);
        boolean boolean36 = lineAndShapeRenderer33.getBaseShapesFilled();
        categoryPlot16.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer33);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator38 = lineAndShapeRenderer33.getBaseItemLabelGenerator();
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNull(categoryItemLabelGenerator38);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.setMaximumCategoryLabelLines(4);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor12 = org.jfree.chart.axis.CategoryAnchor.START;
        java.lang.String str13 = categoryAnchor12.toString();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor12, 4, (int) '#', rectangle2D16, rectangleEdge17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double21 = rectangleInsets19.calculateTopInset((double) 10);
        double double22 = rectangleInsets19.getTop();
        boolean boolean23 = categoryAnchor12.equals((java.lang.Object) double22);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(categoryAnchor12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "CategoryAnchor.START" + "'", str13.equals("CategoryAnchor.START"));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator5 = new org.jfree.chart.util.DefaultShadowGenerator(255, color1, (float) (-1L), (int) (byte) -1, (double) (-1L));
        float float6 = defaultShadowGenerator5.getShadowOpacity();
        int int7 = defaultShadowGenerator5.calculateOffsetY();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-255) + "'", int7 == (-255));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis2.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D8, rectangleEdge9);
        int int11 = categoryAxis2.getCategoryLabelPositionOffset();
        categoryAxis2.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis14, categoryItemRenderer15);
        java.awt.Paint paint17 = categoryPlot16.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = categoryPlot16.removeDomainMarker(marker18, layer19);
        boolean boolean21 = categoryPlot16.isRangeMinorGridlinesVisible();
        boolean boolean22 = abstractCategoryDataset0.hasListener((java.util.EventListener) categoryPlot16);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot16.getDomainMarkers(layer23);
        boolean boolean25 = categoryPlot16.isDomainPannable();
        categoryPlot16.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryPlot16.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = categoryPlot16.getDatasetRenderingOrder();
        org.jfree.chart.event.AnnotationChangeEvent annotationChangeEvent30 = null;
        categoryPlot16.annotationChanged(annotationChangeEvent30);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        java.awt.Paint paint18 = categoryPlot15.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        categoryPlot15.setDataset(categoryDataset19);
        org.jfree.chart.LegendItemCollection legendItemCollection21 = categoryPlot15.getLegendItems();
        categoryPlot15.setCrosshairDatasetIndex(0);
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = null;
        try {
            categoryPlot15.addDomainMarker(categoryMarker24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(legendItemCollection21);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.setMaximumCategoryLabelLines(4);
        categoryAxis0.setLowerMargin(0.0d);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis0.getCategorySeriesMiddle((int) (byte) 1, (int) ' ', (int) (byte) 10, 0, 3.0d, rectangle2D19, rectangleEdge20);
        java.awt.Font font22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis0.setTickLabelFont(font22);
        org.jfree.chart.plot.Plot plot24 = categoryAxis0.getPlot();
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        double double34 = categoryAxis26.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D32, rectangleEdge33);
        int int35 = categoryAxis26.getCategoryLabelPositionOffset();
        categoryAxis26.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, valueAxis38, categoryItemRenderer39);
        java.awt.Paint paint41 = categoryPlot40.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor42 = categoryPlot40.getDomainGridlinePosition();
        java.awt.Paint paint43 = categoryPlot40.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset44 = null;
        categoryPlot40.setDataset(categoryDataset44);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = categoryPlot40.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = categoryPlot40.getAxisOffset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        java.awt.geom.Point2D point2D50 = null;
        categoryPlot40.panDomainAxes((double) (-1L), plotRenderingInfo49, point2D50);
        boolean boolean52 = categoryAxis0.hasListener((java.util.EventListener) categoryPlot40);
        org.jfree.chart.util.Layer layer54 = null;
        java.util.Collection collection55 = categoryPlot40.getDomainMarkers((int) 'a', layer54);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNull(plot24);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(categoryAnchor42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNull(collection55);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.CENTER;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset5 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener6 = null;
        boolean boolean7 = abstractCategoryDataset5.hasListener(eventListener6);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener8 = null;
        abstractCategoryDataset5.removeChangeListener(datasetChangeListener8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = categoryAxis11.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D17, rectangleEdge18);
        int int20 = categoryAxis11.getCategoryLabelPositionOffset();
        categoryAxis11.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis23, categoryItemRenderer24);
        java.awt.Paint paint26 = categoryPlot25.getRangeCrosshairPaint();
        int int27 = categoryPlot25.getWeight();
        abstractCategoryDataset5.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot25);
        lineAndShapeRenderer4.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot25);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor31 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor32 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor31, textAnchor32);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer35 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj36 = standardGradientPaintTransformer35.clone();
        boolean boolean37 = categoryAxis34.equals((java.lang.Object) standardGradientPaintTransformer35);
        boolean boolean38 = itemLabelPosition33.equals((java.lang.Object) boolean37);
        double double39 = itemLabelPosition33.getAngle();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor40 = itemLabelPosition33.getItemLabelAnchor();
        lineAndShapeRenderer4.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition33);
        org.jfree.chart.text.TextAnchor textAnchor42 = itemLabelPosition33.getTextAnchor();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition44 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1, textAnchor42, (double) 255);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(itemLabelAnchor31);
        org.junit.Assert.assertNotNull(textAnchor32);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor40);
        org.junit.Assert.assertNotNull(textAnchor42);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer32 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset33 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener34 = null;
        boolean boolean35 = abstractCategoryDataset33.hasListener(eventListener34);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener36 = null;
        abstractCategoryDataset33.removeChangeListener(datasetChangeListener36);
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = null;
        double double47 = categoryAxis39.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D45, rectangleEdge46);
        int int48 = categoryAxis39.getCategoryLabelPositionOffset();
        categoryAxis39.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, categoryAxis39, valueAxis51, categoryItemRenderer52);
        java.awt.Paint paint54 = categoryPlot53.getRangeCrosshairPaint();
        int int55 = categoryPlot53.getWeight();
        abstractCategoryDataset33.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot53);
        lineAndShapeRenderer32.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot53);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor59 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor60 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition61 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor59, textAnchor60);
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer63 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj64 = standardGradientPaintTransformer63.clone();
        boolean boolean65 = categoryAxis62.equals((java.lang.Object) standardGradientPaintTransformer63);
        boolean boolean66 = itemLabelPosition61.equals((java.lang.Object) boolean65);
        double double67 = itemLabelPosition61.getAngle();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor68 = itemLabelPosition61.getItemLabelAnchor();
        lineAndShapeRenderer32.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition61);
        try {
            lineAndShapeRenderer2.setSeriesPositiveItemLabelPosition((-12566464), itemLabelPosition61);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 4 + "'", int48 == 4);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(itemLabelAnchor59);
        org.junit.Assert.assertNotNull(textAnchor60);
        org.junit.Assert.assertNotNull(obj64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor68);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint33 = renderAttributes31.getSeriesOutlinePaint((int) '4');
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes31.setDefaultStroke(stroke34);
        lineAndShapeRenderer2.setSeriesStroke(0, stroke34, false);
        java.awt.Shape shape38 = lineAndShapeRenderer2.getBaseLegendShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition42 = lineAndShapeRenderer2.getPositiveItemLabelPosition((int) (short) -1, (-1), true);
        java.awt.Paint paint43 = lineAndShapeRenderer2.getBaseLegendTextPaint();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNull(shape38);
        org.junit.Assert.assertNotNull(itemLabelPosition42);
        org.junit.Assert.assertNull(paint43);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = keyedObjects2D0.clone();
        int int3 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 'a');
        org.jfree.data.KeyedObjects2D keyedObjects2D4 = new org.jfree.data.KeyedObjects2D();
        java.awt.Color color5 = java.awt.Color.BLACK;
        boolean boolean6 = keyedObjects2D4.equals((java.lang.Object) color5);
        boolean boolean7 = keyedObjects2D0.equals((java.lang.Object) keyedObjects2D4);
        keyedObjects2D4.clear();
        try {
            java.lang.Object obj11 = keyedObjects2D4.getObject((java.lang.Comparable) (-255), (java.lang.Comparable) 128);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (-255) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "");
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape7);
        chartEntity6.setArea(shape7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape7, (java.awt.Paint) color10);
        legendItem11.setURLText("");
        boolean boolean14 = legendItem11.isShapeFilled();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = categoryAxis16.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D22, rectangleEdge23);
        int int25 = categoryAxis16.getCategoryLabelPositionOffset();
        categoryAxis16.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis28, categoryItemRenderer29);
        org.jfree.chart.event.PlotChangeListener plotChangeListener31 = null;
        categoryPlot30.addChangeListener(plotChangeListener31);
        categoryPlot30.setDomainCrosshairColumnKey((java.lang.Comparable) 5, false);
        categoryPlot30.mapDatasetToRangeAxis(0, 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = categoryPlot30.getDomainAxisEdge();
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer41 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj42 = standardGradientPaintTransformer41.clone();
        boolean boolean43 = categoryAxis40.equals((java.lang.Object) standardGradientPaintTransformer41);
        boolean boolean44 = categoryAxis40.isMinorTickMarksVisible();
        java.util.List list45 = categoryPlot30.getCategoriesForAxis(categoryAxis40);
        boolean boolean46 = legendItem11.equals((java.lang.Object) categoryAxis40);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 4 + "'", int25 == 4);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(list45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font11 = null;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 1, font11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double14 = rectangleInsets13.getRight();
        categoryAxis0.setLabelInsets(rectangleInsets13, true);
        org.jfree.chart.util.UnitType unitType17 = rectangleInsets13.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets(unitType17, 10.0d, (double) 0, (double) (-1L), (-1.0d));
        java.awt.Shape shape27 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity29 = new org.jfree.chart.entity.ChartEntity(shape27, "");
        java.awt.Shape shape30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape30);
        chartEntity29.setArea(shape30);
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape30, (java.awt.Paint) color33);
        legendItem34.setURLText("");
        boolean boolean37 = unitType17.equals((java.lang.Object) legendItem34);
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = null;
        double double47 = categoryAxis39.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D45, rectangleEdge46);
        int int48 = categoryAxis39.getCategoryLabelPositionOffset();
        categoryAxis39.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, categoryAxis39, valueAxis51, categoryItemRenderer52);
        java.awt.Paint paint54 = categoryPlot53.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker55 = null;
        org.jfree.chart.util.Layer layer56 = null;
        boolean boolean57 = categoryPlot53.removeDomainMarker(marker55, layer56);
        org.jfree.chart.util.Layer layer58 = null;
        java.util.Collection collection59 = categoryPlot53.getRangeMarkers(layer58);
        java.awt.Stroke stroke60 = categoryPlot53.getDomainCrosshairStroke();
        legendItem34.setOutlineStroke(stroke60);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(unitType17);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 4 + "'", int48 == 4);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(collection59);
        org.junit.Assert.assertNotNull(stroke60);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        java.awt.Font font5 = lineAndShapeRenderer2.getBaseItemLabelFont();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = categoryAxis8.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D14, rectangleEdge15);
        int int17 = categoryAxis8.getCategoryLabelPositionOffset();
        categoryAxis8.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis20, categoryItemRenderer21);
        java.awt.Paint paint23 = categoryPlot22.getRangeCrosshairPaint();
        int int24 = categoryPlot22.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        categoryPlot22.setFixedDomainAxisSpace(axisSpace25);
        org.jfree.chart.axis.AxisSpace axisSpace27 = categoryPlot22.getFixedDomainAxisSpace();
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        double double37 = categoryAxis29.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D35, rectangleEdge36);
        int int38 = categoryAxis29.getCategoryLabelPositionOffset();
        categoryAxis29.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis41, categoryItemRenderer42);
        java.awt.Paint paint44 = categoryPlot43.getRangeCrosshairPaint();
        int int45 = categoryPlot43.getWeight();
        java.lang.Comparable comparable46 = null;
        categoryPlot43.setDomainCrosshairRowKey(comparable46, true);
        org.jfree.chart.util.SortOrder sortOrder49 = categoryPlot43.getRowRenderingOrder();
        categoryPlot22.setColumnRenderingOrder(sortOrder49);
        org.jfree.chart.util.SortOrder sortOrder51 = categoryPlot22.getColumnRenderingOrder();
        categoryPlot22.setCrosshairDatasetIndex(10);
        org.jfree.chart.axis.ValueAxis valueAxis54 = null;
        org.jfree.chart.plot.Marker marker55 = null;
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        lineAndShapeRenderer2.drawRangeMarker(graphics2D6, categoryPlot22, valueAxis54, marker55, rectangle2D56);
        lineAndShapeRenderer2.clearSeriesPaints(false);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNull(axisSpace27);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 4 + "'", int38 == 4);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(sortOrder49);
        org.junit.Assert.assertNotNull(sortOrder51);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = categoryAxis3.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D9, rectangleEdge10);
        int int12 = categoryAxis3.getCategoryLabelPositionOffset();
        categoryAxis3.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis15, categoryItemRenderer16);
        java.awt.Paint paint18 = categoryPlot17.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor19 = categoryPlot17.getDomainGridlinePosition();
        java.awt.Paint paint20 = categoryPlot17.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot17.setDataset(categoryDataset21);
        org.jfree.chart.LegendItemCollection legendItemCollection23 = categoryPlot17.getLegendItems();
        java.awt.Stroke stroke24 = categoryPlot17.getRangeGridlineStroke();
        renderAttributes1.setDefaultStroke(stroke24);
        java.awt.Shape shape26 = renderAttributes1.getDefaultShape();
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(categoryAnchor19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(legendItemCollection23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(shape26);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer3.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = null;
        lineAndShapeRenderer3.setBaseURLGenerator(categoryURLGenerator6, true);
        java.awt.Font font10 = lineAndShapeRenderer3.lookupLegendTextFont((int) (byte) 0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer13.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator16 = null;
        lineAndShapeRenderer13.setBaseURLGenerator(categoryURLGenerator16, true);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator19 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        lineAndShapeRenderer13.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator19);
        lineAndShapeRenderer3.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator19);
        boolean boolean22 = booleanList0.equals((java.lang.Object) lineAndShapeRenderer3);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        boolean boolean5 = lineAndShapeRenderer2.getBaseShapesFilled();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = categoryAxis8.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D14, rectangleEdge15);
        int int17 = categoryAxis8.getCategoryLabelPositionOffset();
        categoryAxis8.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis20, categoryItemRenderer21);
        java.awt.Paint paint23 = categoryPlot22.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor24 = categoryPlot22.getDomainGridlinePosition();
        java.awt.Paint paint25 = categoryPlot22.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        categoryPlot22.setDataset(categoryDataset26);
        org.jfree.chart.LegendItemCollection legendItemCollection28 = categoryPlot22.getLegendItems();
        boolean boolean29 = categoryPlot22.canSelectByPoint();
        int int30 = categoryPlot22.getRangeAxisCount();
        categoryPlot22.clearRangeAxes();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        java.awt.Paint paint34 = null;
        java.awt.Shape shape39 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity41 = new org.jfree.chart.entity.ChartEntity(shape39, "");
        java.awt.Shape shape42 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent43 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape42);
        chartEntity41.setArea(shape42);
        java.awt.Color color45 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem46 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape42, (java.awt.Paint) color45);
        legendItem46.setURLText("{0}");
        java.awt.Stroke stroke49 = legendItem46.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart50 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent51 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendItem46, jFreeChart50);
        java.awt.Stroke stroke52 = legendItem46.getLineStroke();
        try {
            lineAndShapeRenderer2.drawDomainLine(graphics2D6, categoryPlot22, rectangle2D32, (double) (byte) 1, paint34, stroke52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(categoryAnchor24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(legendItemCollection28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(stroke52);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        java.awt.Font font28 = lineAndShapeRenderer2.getBaseItemLabelFont();
        boolean boolean29 = lineAndShapeRenderer2.getBaseCreateEntities();
        java.awt.Paint paint31 = lineAndShapeRenderer2.lookupSeriesFillPaint((int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) 1.0f);
        double double4 = rectangleInsets0.calculateRightOutset((double) (byte) 10);
        double double6 = rectangleInsets0.extendHeight(0.0d);
        double double7 = rectangleInsets0.getLeft();
        java.lang.String str8 = rectangleInsets0.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str8.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Color color3 = java.awt.Color.blue;
        renderAttributes1.setSeriesFillPaint(0, (java.awt.Paint) color3);
        java.awt.Font font5 = renderAttributes1.getDefaultLabelFont();
        java.awt.Stroke stroke8 = renderAttributes1.getItemStroke(4, (int) (short) 100);
        java.awt.Color color9 = java.awt.Color.GREEN;
        renderAttributes1.setDefaultPaint((java.awt.Paint) color9);
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity17 = new org.jfree.chart.entity.ChartEntity(shape15, "");
        java.awt.Shape shape18 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent19 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape18);
        chartEntity17.setArea(shape18);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape18, (java.awt.Paint) color21);
        legendItem22.setURLText("{0}");
        java.awt.Paint paint25 = legendItem22.getOutlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        double double34 = categoryAxis26.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D32, rectangleEdge33);
        int int35 = categoryAxis26.getCategoryLabelPositionOffset();
        categoryAxis26.setMaximumCategoryLabelLines(4);
        categoryAxis26.setLowerMargin(0.0d);
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = null;
        double double47 = categoryAxis26.getCategorySeriesMiddle((int) (byte) 1, (int) ' ', (int) (byte) 10, 0, 3.0d, rectangle2D45, rectangleEdge46);
        java.awt.Font font48 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis26.setTickLabelFont(font48);
        legendItem22.setLabelFont(font48);
        renderAttributes1.setDefaultLabelFont(font48);
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis53.setLabelURL("");
        org.jfree.chart.axis.CategoryAxis categoryAxis56 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D62 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = null;
        double double64 = categoryAxis56.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D62, rectangleEdge63);
        java.awt.Stroke stroke65 = categoryAxis56.getTickMarkStroke();
        categoryAxis53.setAxisLineStroke(stroke65);
        try {
            renderAttributes1.setSeriesOutlineStroke((-255), stroke65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNull(stroke8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
        org.junit.Assert.assertEquals((double) double47, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(stroke65);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        categoryPlot15.addChangeListener(plotChangeListener16);
        categoryPlot15.setDomainCrosshairColumnKey((java.lang.Comparable) 5, false);
        org.jfree.chart.plot.Marker marker21 = null;
        org.jfree.chart.util.Layer layer22 = null;
        try {
            boolean boolean23 = categoryPlot15.removeRangeMarker(marker21, layer22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        java.awt.Paint paint18 = categoryPlot15.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        categoryPlot15.setDataset(categoryDataset19);
        org.jfree.chart.LegendItemCollection legendItemCollection21 = categoryPlot15.getLegendItems();
        boolean boolean22 = categoryPlot15.canSelectByPoint();
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        java.awt.geom.Point2D point2D25 = null;
        org.jfree.chart.plot.PlotState plotState26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        try {
            categoryPlot15.draw(graphics2D23, rectangle2D24, point2D25, plotState26, plotRenderingInfo27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(legendItemCollection21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "");
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape7);
        chartEntity6.setArea(shape7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape7, (java.awt.Paint) color10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis13.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D19, rectangleEdge20);
        int int22 = categoryAxis13.getCategoryLabelPositionOffset();
        categoryAxis13.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis25, categoryItemRenderer26);
        java.awt.Paint paint28 = categoryPlot27.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor29 = categoryPlot27.getDomainGridlinePosition();
        org.jfree.chart.entity.PlotEntity plotEntity30 = new org.jfree.chart.entity.PlotEntity(shape7, (org.jfree.chart.plot.Plot) categoryPlot27);
        java.awt.Paint paint31 = categoryPlot27.getOutlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset33 = categoryPlot27.getDataset(1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(categoryAnchor29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNull(categoryDataset33);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        java.awt.Font font28 = lineAndShapeRenderer2.getBaseItemLabelFont();
        boolean boolean29 = lineAndShapeRenderer2.getBaseCreateEntities();
        boolean boolean30 = lineAndShapeRenderer2.getAutoPopulateSeriesOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj1 = standardGradientPaintTransformer0.clone();
        java.lang.Object obj2 = standardGradientPaintTransformer0.clone();
        java.lang.Object obj3 = standardGradientPaintTransformer0.clone();
        java.lang.Object obj4 = standardGradientPaintTransformer0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        java.awt.Paint paint18 = categoryPlot15.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        categoryPlot15.setDataset(categoryDataset19);
        org.jfree.chart.LegendItemCollection legendItemCollection21 = categoryPlot15.getLegendItems();
        boolean boolean22 = categoryPlot15.canSelectByPoint();
        int int23 = categoryPlot15.getRangeAxisCount();
        categoryPlot15.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = categoryPlot15.getDomainAxisEdge();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation26 = null;
        try {
            boolean boolean27 = categoryPlot15.removeAnnotation(categoryAnnotation26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(legendItemCollection21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator5 = new org.jfree.chart.util.DefaultShadowGenerator(255, color1, (float) (-1L), (int) (byte) -1, (double) (-1L));
        java.awt.Color color6 = defaultShadowGenerator5.getShadowColor();
        int int7 = color6.getBlue();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 128 + "'", int7 == 128);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint3 = renderAttributes1.getSeriesOutlinePaint((int) '4');
        java.awt.Paint paint4 = renderAttributes1.getDefaultOutlinePaint();
        java.awt.Paint paint6 = renderAttributes1.getSeriesPaint((-16777216));
        org.jfree.chart.renderer.RenderAttributes renderAttributes9 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Color color11 = java.awt.Color.blue;
        renderAttributes9.setSeriesFillPaint(0, (java.awt.Paint) color11);
        renderAttributes1.setSeriesOutlinePaint((int) (short) 1, (java.awt.Paint) color11);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        java.awt.Font font28 = lineAndShapeRenderer2.getBaseItemLabelFont();
        java.awt.Paint paint29 = lineAndShapeRenderer2.getBaseLegendTextPaint();
        java.awt.Font font30 = lineAndShapeRenderer2.getBaseLegendTextFont();
        try {
            lineAndShapeRenderer2.setSeriesItemLabelsVisible((int) (short) -1, (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertNull(font30);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        boolean boolean5 = lineAndShapeRenderer2.getBaseShapesFilled();
        java.lang.Boolean boolean7 = lineAndShapeRenderer2.getSeriesLinesVisible(100);
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = lineAndShapeRenderer2.getSelectedItemAttributes();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = categoryAxis11.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D17, rectangleEdge18);
        int int20 = categoryAxis11.getCategoryLabelPositionOffset();
        categoryAxis11.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis23, categoryItemRenderer24);
        java.awt.Paint paint26 = categoryPlot25.getRangeCrosshairPaint();
        int int27 = categoryPlot25.getWeight();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        categoryPlot25.setRenderer(categoryItemRenderer28);
        categoryPlot25.clearRangeMarkers((-255));
        org.jfree.chart.LegendItemCollection legendItemCollection32 = new org.jfree.chart.LegendItemCollection();
        categoryPlot25.setFixedLegendItems(legendItemCollection32);
        boolean boolean34 = categoryPlot25.isDomainCrosshairVisible();
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        try {
            lineAndShapeRenderer2.drawBackground(graphics2D9, categoryPlot25, rectangle2D35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        org.jfree.data.KeyedObjects2D keyedObjects2D18 = new org.jfree.data.KeyedObjects2D();
        java.awt.Color color19 = java.awt.Color.BLACK;
        boolean boolean20 = keyedObjects2D18.equals((java.lang.Object) color19);
        int int21 = color19.getTransparency();
        categoryPlot15.setRangeGridlinePaint((java.awt.Paint) color19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot15.zoomRangeAxes((double) 0L, plotRenderingInfo24, point2D25, true);
        float float28 = categoryPlot15.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 1.0f + "'", float28 == 1.0f);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getAutoPopulateSeriesOutlineStroke();
        java.awt.Shape shape33 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity35 = new org.jfree.chart.entity.ChartEntity(shape33, "");
        java.awt.Shape shape36 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent37 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape36);
        chartEntity35.setArea(shape36);
        java.awt.Color color39 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape36, (java.awt.Paint) color39);
        lineAndShapeRenderer2.setBaseShape(shape36);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(color39);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        boolean boolean5 = lineAndShapeRenderer2.getBaseShapesFilled();
        java.lang.Boolean boolean7 = lineAndShapeRenderer2.getSeriesLinesVisible(100);
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = lineAndShapeRenderer2.getSelectedItemAttributes();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        float float10 = categoryAxis9.getMinorTickMarkInsideLength();
        boolean boolean11 = categoryAxis9.isMinorTickMarksVisible();
        boolean boolean12 = categoryAxis9.isTickLabelsVisible();
        java.awt.Paint paint13 = categoryAxis9.getTickMarkPaint();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = categoryAxis15.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D21, rectangleEdge22);
        int int24 = categoryAxis15.getCategoryLabelPositionOffset();
        categoryAxis15.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis27, categoryItemRenderer28);
        org.jfree.chart.event.PlotChangeListener plotChangeListener30 = null;
        categoryPlot29.addChangeListener(plotChangeListener30);
        categoryPlot29.setDomainCrosshairColumnKey((java.lang.Comparable) 5, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        int int36 = categoryPlot29.getIndexOf(categoryItemRenderer35);
        categoryAxis9.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot29);
        java.awt.Font font38 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis9.setLabelFont(font38);
        lineAndShapeRenderer2.setBaseItemLabelFont(font38, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator43 = null;
        try {
            lineAndShapeRenderer2.setSeriesItemLabelGenerator((int) (byte) -1, categoryItemLabelGenerator43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(font38);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) (-1L), "");
        categoryAxis0.setLabelAngle(0.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint33 = renderAttributes31.getSeriesOutlinePaint((int) '4');
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes31.setDefaultStroke(stroke34);
        lineAndShapeRenderer2.setSeriesStroke(0, stroke34, false);
        java.awt.Shape shape38 = lineAndShapeRenderer2.getBaseLegendShape();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation39 = null;
        boolean boolean40 = lineAndShapeRenderer2.removeAnnotation(categoryAnnotation39);
        boolean boolean43 = lineAndShapeRenderer2.getItemShapeVisible((int) (short) 0, (int) (short) 1);
        try {
            lineAndShapeRenderer2.setSeriesShapesVisible((-14336), (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNull(shape38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        int int17 = categoryPlot15.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace18 = null;
        categoryPlot15.setFixedDomainAxisSpace(axisSpace18);
        org.jfree.chart.plot.Marker marker20 = null;
        org.jfree.chart.util.Layer layer21 = null;
        try {
            boolean boolean22 = categoryPlot15.removeRangeMarker(marker20, layer21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "");
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape7);
        chartEntity6.setArea(shape7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape7, (java.awt.Paint) color10);
        legendItem11.setURLText("{0}");
        java.awt.Stroke stroke14 = legendItem11.getOutlineStroke();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer15 = legendItem11.getFillPaintTransformer();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer16 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj17 = standardGradientPaintTransformer16.clone();
        java.lang.Object obj18 = standardGradientPaintTransformer16.clone();
        java.lang.Object obj19 = standardGradientPaintTransformer16.clone();
        legendItem11.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer16);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        double double30 = categoryAxis22.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D28, rectangleEdge29);
        int int31 = categoryAxis22.getCategoryLabelPositionOffset();
        categoryAxis22.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis34, categoryItemRenderer35);
        java.awt.Paint paint37 = categoryPlot36.getRangeCrosshairPaint();
        int int38 = categoryPlot36.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace39 = null;
        categoryPlot36.setFixedDomainAxisSpace(axisSpace39);
        org.jfree.chart.axis.AxisSpace axisSpace41 = categoryPlot36.getFixedDomainAxisSpace();
        org.jfree.data.category.CategoryDataset categoryDataset42 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = null;
        double double51 = categoryAxis43.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D49, rectangleEdge50);
        int int52 = categoryAxis43.getCategoryLabelPositionOffset();
        categoryAxis43.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer56 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, valueAxis55, categoryItemRenderer56);
        java.awt.Paint paint58 = categoryPlot57.getRangeCrosshairPaint();
        int int59 = categoryPlot57.getWeight();
        java.lang.Comparable comparable60 = null;
        categoryPlot57.setDomainCrosshairRowKey(comparable60, true);
        org.jfree.chart.util.SortOrder sortOrder63 = categoryPlot57.getRowRenderingOrder();
        categoryPlot36.setColumnRenderingOrder(sortOrder63);
        boolean boolean65 = standardGradientPaintTransformer16.equals((java.lang.Object) categoryPlot36);
        java.awt.Graphics2D graphics2D66 = null;
        java.awt.geom.Rectangle2D rectangle2D67 = null;
        java.awt.geom.Point2D point2D68 = null;
        org.jfree.chart.plot.PlotState plotState69 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo70 = null;
        try {
            categoryPlot36.draw(graphics2D66, rectangle2D67, point2D68, plotState69, plotRenderingInfo70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(gradientPaintTransformer15);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNull(axisSpace41);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 4 + "'", int52 == 4);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(sortOrder63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "");
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape7);
        chartEntity6.setArea(shape7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape7, (java.awt.Paint) color10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis13.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D19, rectangleEdge20);
        int int22 = categoryAxis13.getCategoryLabelPositionOffset();
        categoryAxis13.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis25, categoryItemRenderer26);
        java.awt.Paint paint28 = categoryPlot27.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor29 = categoryPlot27.getDomainGridlinePosition();
        org.jfree.chart.entity.PlotEntity plotEntity30 = new org.jfree.chart.entity.PlotEntity(shape7, (org.jfree.chart.plot.Plot) categoryPlot27);
        boolean boolean32 = plotEntity30.equals((java.lang.Object) "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(categoryAnchor29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        boolean boolean5 = lineAndShapeRenderer2.getBaseShapesFilled();
        java.lang.Boolean boolean7 = lineAndShapeRenderer2.getSeriesCreateEntities(2);
        lineAndShapeRenderer2.setAutoPopulateSeriesOutlinePaint(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer13.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator16 = null;
        lineAndShapeRenderer13.setBaseURLGenerator(categoryURLGenerator16, true);
        java.lang.Boolean boolean20 = lineAndShapeRenderer13.getSeriesVisible((int) (short) 100);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator21 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        lineAndShapeRenderer13.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator21);
        java.awt.Paint paint23 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer13.setBaseLegendTextPaint(paint23);
        try {
            lineAndShapeRenderer2.setSeriesItemLabelPaint((-254), paint23, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertNull(boolean20);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.setMaximumCategoryLabelLines(4);
        categoryAxis0.setMaximumCategoryLabelWidthRatio(1.0f);
        categoryAxis0.setMaximumCategoryLabelWidthRatio(2.0f);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator5, true);
        java.awt.Font font9 = lineAndShapeRenderer2.lookupLegendTextFont((int) (byte) 0);
        lineAndShapeRenderer2.setUseSeriesOffset(true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation12 = null;
        try {
            lineAndShapeRenderer2.addAnnotation(categoryAnnotation12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(font9);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        java.lang.String str1 = gradientPaintTransformType0.toString();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        boolean boolean3 = gradientPaintTransformType0.equals((java.lang.Object) color2);
        java.lang.Class<?> wildcardClass4 = color2.getClass();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GradientPaintTransformType.CENTER_HORIZONTAL" + "'", str1.equals("GradientPaintTransformType.CENTER_HORIZONTAL"));
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint33 = renderAttributes31.getSeriesOutlinePaint((int) '4');
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes31.setDefaultStroke(stroke34);
        lineAndShapeRenderer2.setSeriesStroke(0, stroke34, false);
        boolean boolean40 = lineAndShapeRenderer2.getItemVisible((int) (short) 0, 8);
        java.awt.Paint paint41 = lineAndShapeRenderer2.getBaseFillPaint();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
        objectList1.clear();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot8.zoomRangeAxes((double) 100, plotRenderingInfo10, point2D11, false);
        java.awt.Stroke stroke14 = categoryPlot8.getRangeGridlineStroke();
        try {
            objectList1.set((int) (short) -1, (java.lang.Object) stroke14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "");
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape7);
        chartEntity6.setArea(shape7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape7, (java.awt.Paint) color10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis13.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D19, rectangleEdge20);
        int int22 = categoryAxis13.getCategoryLabelPositionOffset();
        categoryAxis13.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis25, categoryItemRenderer26);
        java.awt.Paint paint28 = categoryPlot27.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor29 = categoryPlot27.getDomainGridlinePosition();
        org.jfree.chart.entity.PlotEntity plotEntity30 = new org.jfree.chart.entity.PlotEntity(shape7, (org.jfree.chart.plot.Plot) categoryPlot27);
        java.lang.String str31 = plotEntity30.toString();
        java.lang.String str32 = plotEntity30.getShapeCoords();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(categoryAnchor29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "PlotEntity: tooltip = null" + "'", str31.equals("PlotEntity: tooltip = null"));
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "-3,-3,3,3" + "'", str32.equals("-3,-3,3,3"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor29 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor30 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor29, textAnchor30);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj34 = standardGradientPaintTransformer33.clone();
        boolean boolean35 = categoryAxis32.equals((java.lang.Object) standardGradientPaintTransformer33);
        boolean boolean36 = itemLabelPosition31.equals((java.lang.Object) boolean35);
        double double37 = itemLabelPosition31.getAngle();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor38 = itemLabelPosition31.getItemLabelAnchor();
        lineAndShapeRenderer2.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition31);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator41 = null;
        lineAndShapeRenderer2.setSeriesURLGenerator(1, categoryURLGenerator41);
        java.awt.Paint paint44 = lineAndShapeRenderer2.getSeriesPaint((int) (byte) 1);
        boolean boolean46 = lineAndShapeRenderer2.isSeriesVisible((int) '4');
        org.jfree.data.KeyedObjects2D keyedObjects2D47 = new org.jfree.data.KeyedObjects2D();
        java.awt.Color color48 = java.awt.Color.BLACK;
        boolean boolean49 = keyedObjects2D47.equals((java.lang.Object) color48);
        lineAndShapeRenderer2.setBaseOutlinePaint((java.awt.Paint) color48);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator52 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        java.lang.Object obj53 = standardCategorySeriesLabelGenerator52.clone();
        lineAndShapeRenderer2.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator52);
        java.awt.Paint paint56 = lineAndShapeRenderer2.getSeriesItemLabelPaint((int) '4');
        java.awt.Stroke stroke58 = lineAndShapeRenderer2.lookupSeriesStroke(3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(itemLabelAnchor29);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor38);
        org.junit.Assert.assertNull(paint44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(obj53);
        org.junit.Assert.assertNull(paint56);
        org.junit.Assert.assertNotNull(stroke58);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint33 = renderAttributes31.getSeriesOutlinePaint((int) '4');
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes31.setDefaultStroke(stroke34);
        lineAndShapeRenderer2.setSeriesStroke(0, stroke34, false);
        java.awt.Shape shape38 = lineAndShapeRenderer2.getBaseLegendShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition42 = lineAndShapeRenderer2.getPositiveItemLabelPosition((int) (short) -1, (-1), true);
        java.awt.Stroke stroke44 = lineAndShapeRenderer2.lookupSeriesOutlineStroke((int) (byte) 0);
        org.jfree.data.category.CategoryDataset categoryDataset45 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = null;
        double double54 = categoryAxis46.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D52, rectangleEdge53);
        int int55 = categoryAxis46.getCategoryLabelPositionOffset();
        categoryAxis46.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis58 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer59 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, valueAxis58, categoryItemRenderer59);
        org.jfree.chart.event.PlotChangeListener plotChangeListener61 = null;
        categoryPlot60.addChangeListener(plotChangeListener61);
        boolean boolean63 = categoryPlot60.isRangeZoomable();
        org.jfree.chart.axis.AxisSpace axisSpace64 = categoryPlot60.getFixedDomainAxisSpace();
        lineAndShapeRenderer2.setPlot(categoryPlot60);
        org.jfree.chart.LegendItemCollection legendItemCollection66 = categoryPlot60.getFixedLegendItems();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNull(shape38);
        org.junit.Assert.assertNotNull(itemLabelPosition42);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 4 + "'", int55 == 4);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNull(axisSpace64);
        org.junit.Assert.assertNull(legendItemCollection66);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        categoryPlot23.setBackgroundAlpha((float) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Color color3 = java.awt.Color.blue;
        renderAttributes1.setSeriesFillPaint(0, (java.awt.Paint) color3);
        java.awt.Font font5 = renderAttributes1.getDefaultLabelFont();
        java.awt.Stroke stroke8 = renderAttributes1.getItemStroke(4, (int) (short) 100);
        java.awt.Color color9 = java.awt.Color.GREEN;
        renderAttributes1.setDefaultPaint((java.awt.Paint) color9);
        java.awt.Paint paint12 = renderAttributes1.getSeriesOutlinePaint((-255));
        java.awt.Paint paint13 = renderAttributes1.getDefaultFillPaint();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNull(stroke8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNull(paint13);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        java.awt.Stroke stroke17 = categoryPlot15.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot15.zoomRangeAxes((double) (short) -1, plotRenderingInfo19, point2D20, false);
        org.jfree.chart.axis.AxisLocation axisLocation23 = categoryPlot15.getDomainAxisLocation();
        boolean boolean24 = categoryPlot15.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMinorTickMarkInsideLength();
        boolean boolean2 = categoryAxis0.isMinorTickMarksVisible();
        boolean boolean3 = categoryAxis0.isTickLabelsVisible();
        java.awt.Paint paint4 = categoryAxis0.getTickMarkPaint();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = categoryAxis6.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D12, rectangleEdge13);
        int int15 = categoryAxis6.getCategoryLabelPositionOffset();
        categoryAxis6.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot20.addChangeListener(plotChangeListener21);
        categoryPlot20.setDomainCrosshairColumnKey((java.lang.Comparable) 5, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        int int27 = categoryPlot20.getIndexOf(categoryItemRenderer26);
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot20);
        java.awt.Font font29 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis0.setLabelFont(font29);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = null;
        double double40 = categoryAxis32.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D38, rectangleEdge39);
        int int41 = categoryAxis32.getCategoryLabelPositionOffset();
        categoryAxis32.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, valueAxis44, categoryItemRenderer45);
        java.awt.Paint paint47 = categoryPlot46.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor48 = categoryPlot46.getDomainGridlinePosition();
        org.jfree.data.category.CategoryDataset categoryDataset49 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = null;
        double double58 = categoryAxis50.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D56, rectangleEdge57);
        int int59 = categoryAxis50.getCategoryLabelPositionOffset();
        categoryAxis50.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis62 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer63 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot64 = new org.jfree.chart.plot.CategoryPlot(categoryDataset49, categoryAxis50, valueAxis62, categoryItemRenderer63);
        java.awt.Paint paint65 = categoryPlot64.getRangeCrosshairPaint();
        int int66 = categoryPlot64.getWeight();
        java.lang.Comparable comparable67 = null;
        categoryPlot64.setDomainCrosshairRowKey(comparable67, true);
        org.jfree.chart.util.SortOrder sortOrder70 = categoryPlot64.getRowRenderingOrder();
        categoryPlot46.setRowRenderingOrder(sortOrder70);
        java.awt.Color color72 = org.jfree.chart.ChartColor.LIGHT_RED;
        categoryPlot46.setBackgroundPaint((java.awt.Paint) color72);
        categoryAxis0.setLabelPaint((java.awt.Paint) color72);
        categoryAxis0.setLabelAngle((double) 1.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 4 + "'", int41 == 4);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(categoryAnchor48);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 4 + "'", int59 == 4);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(sortOrder70);
        org.junit.Assert.assertNotNull(color72);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer2 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj3 = standardGradientPaintTransformer2.clone();
        boolean boolean4 = categoryAxis1.equals((java.lang.Object) standardGradientPaintTransformer2);
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryAxis1.setAxisLineStroke(stroke5);
        org.jfree.data.KeyedObject keyedObject7 = new org.jfree.data.KeyedObject((java.lang.Comparable) (byte) 1, (java.lang.Object) categoryAxis1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        objectList0.clear();
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape8, "");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor11 = org.jfree.chart.axis.CategoryAnchor.START;
        java.lang.String str12 = categoryAnchor11.toString();
        java.awt.Color color15 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", 0);
        boolean boolean16 = categoryAnchor11.equals((java.lang.Object) color15);
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("ChartChangeEventType.GENERAL", "hi!", "org.jfree.chart.event.ChartChangeEvent[source=ItemLabelAnchor.OUTSIDE7]", "org.jfree.chart.event.ChartChangeEvent[source=ItemLabelAnchor.OUTSIDE7]", shape8, (java.awt.Paint) color15);
        java.awt.Color color20 = java.awt.Color.getColor("ItemLabelAnchor.INSIDE6", (int) (byte) -1);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        double double30 = categoryAxis22.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D28, rectangleEdge29);
        int int31 = categoryAxis22.getCategoryLabelPositionOffset();
        categoryAxis22.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis34, categoryItemRenderer35);
        java.awt.Paint paint37 = categoryPlot36.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor38 = categoryPlot36.getDomainGridlinePosition();
        java.awt.Paint paint39 = categoryPlot36.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset40 = null;
        categoryPlot36.setDataset(categoryDataset40);
        org.jfree.chart.LegendItemCollection legendItemCollection42 = categoryPlot36.getLegendItems();
        java.awt.Stroke stroke43 = categoryPlot36.getRangeGridlineStroke();
        java.awt.Paint paint44 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        try {
            org.jfree.chart.LegendItem legendItem45 = new org.jfree.chart.LegendItem(attributedString0, "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0", "java.awt.Color[r=128,g=128,b=128]", "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0", shape8, (java.awt.Paint) color20, stroke43, paint44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(categoryAnchor11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "CategoryAnchor.START" + "'", str12.equals("CategoryAnchor.START"));
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(categoryAnchor38);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(legendItemCollection42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(paint44);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        java.awt.Paint paint18 = categoryPlot15.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        categoryPlot15.setDataset(categoryDataset19);
        org.jfree.chart.LegendItemCollection legendItemCollection21 = categoryPlot15.getLegendItems();
        boolean boolean22 = categoryPlot15.canSelectByPoint();
        int int23 = categoryPlot15.getRangeAxisCount();
        categoryPlot15.clearRangeAxes();
        java.lang.Comparable comparable25 = categoryPlot15.getDomainCrosshairRowKey();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(legendItemCollection21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNull(comparable25);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis2.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D8, rectangleEdge9);
        int int11 = categoryAxis2.getCategoryLabelPositionOffset();
        categoryAxis2.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis14, categoryItemRenderer15);
        java.awt.Paint paint17 = categoryPlot16.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = categoryPlot16.removeDomainMarker(marker18, layer19);
        boolean boolean21 = categoryPlot16.isRangeMinorGridlinesVisible();
        boolean boolean22 = abstractCategoryDataset0.hasListener((java.util.EventListener) categoryPlot16);
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState23 = null;
        abstractCategoryDataset0.setSelectionState(categoryDatasetSelectionState23);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean19 = categoryPlot15.removeDomainMarker(marker17, layer18);
        boolean boolean20 = categoryPlot15.isRangeMinorGridlinesVisible();
        categoryPlot15.setCrosshairDatasetIndex((-16777216), false);
        categoryPlot15.configureRangeAxes();
        categoryPlot15.clearSelection();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint33 = renderAttributes31.getSeriesOutlinePaint((int) '4');
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes31.setDefaultStroke(stroke34);
        lineAndShapeRenderer2.setSeriesStroke(0, stroke34, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation38 = null;
        boolean boolean39 = lineAndShapeRenderer2.removeAnnotation(categoryAnnotation38);
        lineAndShapeRenderer2.setSeriesShapesVisible(0, true);
        java.awt.Color color43 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int44 = color43.getBlue();
        float[] floatArray48 = new float[] { '#', (byte) 10, (short) 100 };
        float[] floatArray49 = color43.getColorComponents(floatArray48);
        lineAndShapeRenderer2.setBaseLegendTextPaint((java.awt.Paint) color43);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertNotNull(floatArray49);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.event.DatasetChangeListener datasetChangeListener1 = null;
        abstractCategoryDataset0.addChangeListener(datasetChangeListener1);
        java.lang.Object obj3 = abstractCategoryDataset0.clone();
        abstractCategoryDataset0.validateObject();
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.setMaximumCategoryLabelLines(4);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor12 = org.jfree.chart.axis.CategoryAnchor.START;
        java.lang.String str13 = categoryAnchor12.toString();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor12, 4, (int) '#', rectangle2D16, rectangleEdge17);
        categoryAxis0.setFixedDimension((double) (-1L));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(categoryAnchor12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "CategoryAnchor.START" + "'", str13.equals("CategoryAnchor.START"));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMinorTickMarkInsideLength();
        double double2 = categoryAxis0.getFixedDimension();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = categoryAxis6.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D12, rectangleEdge13);
        int int15 = categoryAxis6.getCategoryLabelPositionOffset();
        categoryAxis6.setMaximumCategoryLabelWidthRatio((float) 10L);
        categoryAxis6.setTickMarkInsideLength((float) 64);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
        double double32 = categoryAxis24.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D30, rectangleEdge31);
        int int33 = categoryAxis24.getCategoryLabelPositionOffset();
        categoryAxis24.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis36, categoryItemRenderer37);
        java.awt.Paint paint39 = categoryPlot38.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor40 = categoryPlot38.getDomainGridlinePosition();
        java.awt.Paint paint41 = categoryPlot38.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset42 = null;
        categoryPlot38.setDataset(categoryDataset42);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = categoryPlot38.getRangeAxisEdge();
        org.jfree.chart.axis.AxisState axisState45 = null;
        categoryAxis6.drawTickMarks(graphics2D20, (double) 5, rectangle2D22, rectangleEdge44, axisState45);
        try {
            double double47 = categoryAxis0.getCategoryStart((-12566464), (int) (byte) 1, rectangle2D5, rectangleEdge44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(categoryAnchor40);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(rectangleEdge44);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        boolean boolean5 = lineAndShapeRenderer2.getBaseShapesFilled();
        java.lang.Boolean boolean7 = lineAndShapeRenderer2.getSeriesLinesVisible(100);
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = lineAndShapeRenderer2.getSelectedItemAttributes();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        float float10 = categoryAxis9.getMinorTickMarkInsideLength();
        boolean boolean11 = categoryAxis9.isMinorTickMarksVisible();
        boolean boolean12 = categoryAxis9.isTickLabelsVisible();
        java.awt.Paint paint13 = categoryAxis9.getTickMarkPaint();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = categoryAxis15.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D21, rectangleEdge22);
        int int24 = categoryAxis15.getCategoryLabelPositionOffset();
        categoryAxis15.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis27, categoryItemRenderer28);
        org.jfree.chart.event.PlotChangeListener plotChangeListener30 = null;
        categoryPlot29.addChangeListener(plotChangeListener30);
        categoryPlot29.setDomainCrosshairColumnKey((java.lang.Comparable) 5, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        int int36 = categoryPlot29.getIndexOf(categoryItemRenderer35);
        categoryAxis9.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot29);
        java.awt.Font font38 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis9.setLabelFont(font38);
        lineAndShapeRenderer2.setBaseItemLabelFont(font38, false);
        try {
            lineAndShapeRenderer2.setSeriesItemLabelsVisible((-255), (java.lang.Boolean) true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(font38);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        java.awt.Paint paint18 = categoryPlot15.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        categoryPlot15.setDataset(categoryDataset19);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot15.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = categoryPlot15.getAxisOffset();
        double double24 = rectangleInsets22.calculateTopInset(0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 4.0d + "'", double24 == 4.0d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint33 = renderAttributes31.getSeriesOutlinePaint((int) '4');
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes31.setDefaultStroke(stroke34);
        lineAndShapeRenderer2.setSeriesStroke(0, stroke34, false);
        java.awt.Shape shape38 = lineAndShapeRenderer2.getBaseLegendShape();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation39 = null;
        boolean boolean40 = lineAndShapeRenderer2.removeAnnotation(categoryAnnotation39);
        boolean boolean43 = lineAndShapeRenderer2.getItemShapeVisible((int) (short) 0, (int) (short) 1);
        boolean boolean44 = lineAndShapeRenderer2.getAutoPopulateSeriesPaint();
        java.awt.Paint paint46 = lineAndShapeRenderer2.lookupSeriesFillPaint((int) '#');
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNull(shape38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(paint46);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMinorTickMarkInsideLength();
        boolean boolean2 = categoryAxis0.isMinorTickMarksVisible();
        boolean boolean3 = categoryAxis0.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot4 = null;
        categoryAxis0.setPlot(plot4);
        categoryAxis0.setTickMarkOutsideLength((float) 8);
        java.lang.Comparable comparable8 = null;
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        try {
            categoryAxis0.setTickLabelFont(comparable8, font9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateTopInset((double) 10);
        double double4 = rectangleInsets0.calculateRightOutset(100.0d);
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.renderer.RenderAttributes renderAttributes7 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint9 = renderAttributes7.getSeriesOutlinePaint((int) '4');
        java.awt.Paint paint10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        renderAttributes7.setDefaultOutlinePaint(paint10);
        boolean boolean12 = textAnchor5.equals((java.lang.Object) renderAttributes7);
        boolean boolean13 = rectangleInsets0.equals((java.lang.Object) renderAttributes7);
        java.awt.Paint paint15 = renderAttributes7.getSeriesOutlinePaint(5);
        java.awt.Paint paint18 = renderAttributes7.getItemPaint((int) ' ', (int) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke20 = defaultDrawingSupplier19.getNextStroke();
        renderAttributes7.setDefaultOutlineStroke(stroke20);
        java.awt.Shape shape27 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity29 = new org.jfree.chart.entity.ChartEntity(shape27, "");
        java.awt.Shape shape30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape30);
        chartEntity29.setArea(shape30);
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape30, (java.awt.Paint) color33);
        legendItem34.setURLText("{0}");
        java.awt.Stroke stroke37 = legendItem34.getOutlineStroke();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer38 = legendItem34.getFillPaintTransformer();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer39 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj40 = standardGradientPaintTransformer39.clone();
        java.lang.Object obj41 = standardGradientPaintTransformer39.clone();
        java.lang.Object obj42 = standardGradientPaintTransformer39.clone();
        legendItem34.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer39);
        java.awt.Shape shape52 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity54 = new org.jfree.chart.entity.ChartEntity(shape52, "");
        java.awt.Shape shape55 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent56 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape55);
        chartEntity54.setArea(shape55);
        java.awt.Color color58 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.jfree.chart.LegendItem legendItem59 = new org.jfree.chart.LegendItem("ItemLabelAnchor.INSIDE6", "DatasetRenderingOrder.FORWARD", "{0}", "ChartChangeEventType.GENERAL", shape55, (java.awt.Paint) color58);
        java.awt.Color color60 = java.awt.Color.green;
        org.jfree.chart.LegendItem legendItem61 = new org.jfree.chart.LegendItem("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0", "org.jfree.data.UnknownKeyException: 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0", "DatasetRenderingOrder.FORWARD", "ChartChangeEventType.GENERAL", shape55, (java.awt.Paint) color60);
        legendItem34.setLine(shape55);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer65 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer65.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator68 = null;
        lineAndShapeRenderer65.setBaseURLGenerator(categoryURLGenerator68, true);
        java.lang.Boolean boolean72 = lineAndShapeRenderer65.getSeriesVisible((int) (short) 100);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator73 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        lineAndShapeRenderer65.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator73);
        java.awt.Paint paint75 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer65.setBaseLegendTextPaint(paint75);
        legendItem34.setLabelPaint(paint75);
        renderAttributes7.setSeriesOutlinePaint((int) (byte) 1, paint75);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(gradientPaintTransformer38);
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNotNull(shape55);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNull(boolean72);
        org.junit.Assert.assertNotNull(paint75);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        java.awt.Font font28 = lineAndShapeRenderer2.getBaseItemLabelFont();
        java.awt.Paint paint29 = lineAndShapeRenderer2.getBaseLegendTextPaint();
        java.awt.Shape shape33 = lineAndShapeRenderer2.getItemShape((-12566464), 0, true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertNotNull(shape33);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        java.awt.Color color1 = java.awt.Color.red;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("-3,-3,3,3", (java.awt.Paint) color1);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint33 = renderAttributes31.getSeriesOutlinePaint((int) '4');
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes31.setDefaultStroke(stroke34);
        lineAndShapeRenderer2.setSeriesStroke(0, stroke34, false);
        java.awt.Shape shape38 = lineAndShapeRenderer2.getBaseLegendShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition42 = lineAndShapeRenderer2.getPositiveItemLabelPosition((int) (short) -1, (-1), true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor43 = itemLabelPosition42.getItemLabelAnchor();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNull(shape38);
        org.junit.Assert.assertNotNull(itemLabelPosition42);
        org.junit.Assert.assertNotNull(itemLabelAnchor43);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis2.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D8, rectangleEdge9);
        int int11 = categoryAxis2.getCategoryLabelPositionOffset();
        categoryAxis2.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis14, categoryItemRenderer15);
        java.awt.Paint paint17 = categoryPlot16.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = categoryPlot16.removeDomainMarker(marker18, layer19);
        boolean boolean21 = categoryPlot16.isRangeMinorGridlinesVisible();
        boolean boolean22 = abstractCategoryDataset0.hasListener((java.util.EventListener) categoryPlot16);
        org.jfree.chart.axis.AxisLocation axisLocation24 = categoryPlot16.getDomainAxisLocation(4);
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double27 = rectangleInsets25.calculateBottomInset((double) 1.0f);
        double double29 = rectangleInsets25.calculateRightOutset((double) (byte) 10);
        double double31 = rectangleInsets25.extendHeight(0.0d);
        org.jfree.chart.util.UnitType unitType32 = rectangleInsets25.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = new org.jfree.chart.util.RectangleInsets(unitType32, (double) '#', (double) (short) 100, 0.05d, (double) (byte) 100);
        categoryPlot16.setAxisOffset(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(unitType32);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-32513) + "'", int1 == (-32513));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean19 = categoryPlot15.removeDomainMarker(marker17, layer18);
        boolean boolean20 = categoryPlot15.isRangeMinorGridlinesVisible();
        categoryPlot15.clearDomainMarkers((int) '4');
        categoryPlot15.setAnchorValue(Double.NaN, false);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = null;
        double double36 = categoryAxis28.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D34, rectangleEdge35);
        int int37 = categoryAxis28.getCategoryLabelPositionOffset();
        categoryAxis28.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, valueAxis40, categoryItemRenderer41);
        java.awt.Paint paint43 = categoryPlot42.getRangeCrosshairPaint();
        java.awt.Stroke stroke44 = categoryPlot42.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        java.awt.geom.Point2D point2D47 = null;
        categoryPlot42.zoomRangeAxes((double) (short) -1, plotRenderingInfo46, point2D47, false);
        org.jfree.chart.axis.AxisLocation axisLocation50 = categoryPlot42.getDomainAxisLocation();
        try {
            categoryPlot15.setDomainAxisLocation((-14336), axisLocation50, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 4 + "'", int37 == 4);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(axisLocation50);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        java.awt.Font font28 = lineAndShapeRenderer2.getBaseItemLabelFont();
        java.awt.Paint paint29 = lineAndShapeRenderer2.getBaseLegendTextPaint();
        java.awt.Font font30 = lineAndShapeRenderer2.getBaseLegendTextFont();
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis33.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D39, rectangleEdge40);
        int int42 = categoryAxis33.getCategoryLabelPositionOffset();
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.util.Layer layer44 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        try {
            lineAndShapeRenderer2.drawAnnotations(graphics2D31, rectangle2D32, categoryAxis33, valueAxis43, layer44, plotRenderingInfo45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertNull(font30);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 4 + "'", int42 == 4);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        double double16 = categoryPlot15.getAnchorValue();
        float float17 = categoryPlot15.getBackgroundImageAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot15.getDomainAxisLocation();
        categoryPlot15.setRangeZeroBaselineVisible(false);
        java.awt.Paint paint21 = categoryPlot15.getDomainGridlinePaint();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = chartChangeEvent1.getType();
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        chartChangeEvent1.setChart(jFreeChart3);
        java.awt.Shape shape5 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape5);
        java.lang.String str7 = chartChangeEvent6.toString();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType8 = chartChangeEvent6.getType();
        chartChangeEvent1.setType(chartChangeEventType8);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]" + "'", str7.equals("org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]"));
        org.junit.Assert.assertNotNull(chartChangeEventType8);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = keyedObjects2D0.clone();
        int int3 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 'a');
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset7 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener8 = null;
        boolean boolean9 = abstractCategoryDataset7.hasListener(eventListener8);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener10 = null;
        abstractCategoryDataset7.removeChangeListener(datasetChangeListener10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis13.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D19, rectangleEdge20);
        int int22 = categoryAxis13.getCategoryLabelPositionOffset();
        categoryAxis13.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis25, categoryItemRenderer26);
        java.awt.Paint paint28 = categoryPlot27.getRangeCrosshairPaint();
        int int29 = categoryPlot27.getWeight();
        abstractCategoryDataset7.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot27);
        lineAndShapeRenderer6.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot27);
        boolean boolean32 = lineAndShapeRenderer6.getBaseShapesFilled();
        org.jfree.chart.renderer.RenderAttributes renderAttributes35 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint37 = renderAttributes35.getSeriesOutlinePaint((int) '4');
        java.awt.Stroke stroke38 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes35.setDefaultStroke(stroke38);
        lineAndShapeRenderer6.setSeriesStroke(0, stroke38, false);
        java.awt.Paint paint43 = lineAndShapeRenderer6.getSeriesFillPaint(0);
        keyedObjects2D0.addObject((java.lang.Object) 0, (java.lang.Comparable) (-1.0d), (java.lang.Comparable) "poly");
        try {
            keyedObjects2D0.removeRow((java.lang.Comparable) "CategoryAnchor.START");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (CategoryAnchor.START) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNull(paint37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNull(paint43);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = categoryAxis19.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D25, rectangleEdge26);
        int int28 = categoryAxis19.getCategoryLabelPositionOffset();
        categoryAxis19.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis31, categoryItemRenderer32);
        java.awt.Paint paint34 = categoryPlot33.getRangeCrosshairPaint();
        int int35 = categoryPlot33.getWeight();
        java.lang.Comparable comparable36 = null;
        categoryPlot33.setDomainCrosshairRowKey(comparable36, true);
        org.jfree.chart.util.SortOrder sortOrder39 = categoryPlot33.getRowRenderingOrder();
        categoryPlot15.setRowRenderingOrder(sortOrder39);
        java.awt.Color color41 = org.jfree.chart.ChartColor.LIGHT_RED;
        categoryPlot15.setBackgroundPaint((java.awt.Paint) color41);
        categoryPlot15.clearAnnotations();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = categoryPlot15.getRenderer(4);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(sortOrder39);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNull(categoryItemRenderer45);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = chartChangeEvent1.getType();
        java.lang.String str3 = chartChangeEventType2.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str3.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        java.lang.String str1 = axisLocation0.toString();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str1.equals("AxisLocation.TOP_OR_RIGHT"));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        java.awt.Font font28 = lineAndShapeRenderer2.getBaseItemLabelFont();
        java.awt.Paint paint29 = lineAndShapeRenderer2.getBaseLegendTextPaint();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator31 = lineAndShapeRenderer2.getSeriesURLGenerator(128);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertNull(categoryURLGenerator31);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.awt.Color color1 = java.awt.Color.BLACK;
        boolean boolean2 = keyedObjects2D0.equals((java.lang.Object) color1);
        int int3 = keyedObjects2D0.getRowCount();
        java.util.List list4 = keyedObjects2D0.getColumnKeys();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.setMaximumCategoryLabelLines(4);
        categoryAxis0.setLowerMargin(0.0d);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis0.getCategorySeriesMiddle((int) (byte) 1, (int) ' ', (int) (byte) 10, 0, 3.0d, rectangle2D19, rectangleEdge20);
        boolean boolean22 = categoryAxis0.isMinorTickMarksVisible();
        boolean boolean23 = categoryAxis0.isAxisLineVisible();
        java.awt.Paint paint24 = categoryAxis0.getAxisLinePaint();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.awt.Color color1 = java.awt.Color.BLACK;
        boolean boolean2 = keyedObjects2D0.equals((java.lang.Object) color1);
        int int4 = keyedObjects2D0.getRowIndex((java.lang.Comparable) 1.0d);
        try {
            java.lang.Object obj7 = keyedObjects2D0.getObject((java.lang.Comparable) 100L, (java.lang.Comparable) (-12566464));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (100) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.trimHeight(0.0d);
        double double4 = rectangleInsets0.trimWidth((double) 0);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets0.createInsetRectangle(rectangle2D5, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis2.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D8, rectangleEdge9);
        int int11 = categoryAxis2.getCategoryLabelPositionOffset();
        categoryAxis2.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis14, categoryItemRenderer15);
        java.awt.Paint paint17 = categoryPlot16.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = categoryPlot16.removeDomainMarker(marker18, layer19);
        boolean boolean21 = categoryPlot16.isRangeMinorGridlinesVisible();
        boolean boolean22 = abstractCategoryDataset0.hasListener((java.util.EventListener) categoryPlot16);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot16.getDomainMarkers(layer23);
        boolean boolean25 = categoryPlot16.isDomainPannable();
        categoryPlot16.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryPlot16.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = categoryPlot16.getDatasetRenderingOrder();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer33.setBaseItemLabelsVisible(false);
        boolean boolean36 = lineAndShapeRenderer33.getBaseShapesFilled();
        categoryPlot16.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer33);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator38 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        java.lang.Object obj39 = standardCategorySeriesLabelGenerator38.clone();
        lineAndShapeRenderer33.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator38);
        java.awt.Shape shape45 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity47 = new org.jfree.chart.entity.ChartEntity(shape45, "");
        java.awt.Shape shape48 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent49 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape48);
        chartEntity47.setArea(shape48);
        java.awt.Color color51 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem52 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape48, (java.awt.Paint) color51);
        legendItem52.setURLText("");
        java.awt.Shape shape55 = legendItem52.getShape();
        lineAndShapeRenderer33.setBaseShape(shape55, false);
        boolean boolean58 = lineAndShapeRenderer33.getAutoPopulateSeriesShape();
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(shape55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMinorTickMarkInsideLength();
        boolean boolean2 = categoryAxis0.isMinorTickMarksVisible();
        boolean boolean3 = categoryAxis0.isTickLabelsVisible();
        java.awt.Paint paint4 = categoryAxis0.getTickMarkPaint();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = categoryAxis6.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D12, rectangleEdge13);
        int int15 = categoryAxis6.getCategoryLabelPositionOffset();
        categoryAxis6.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot20.addChangeListener(plotChangeListener21);
        categoryPlot20.setDomainCrosshairColumnKey((java.lang.Comparable) 5, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        int int27 = categoryPlot20.getIndexOf(categoryItemRenderer26);
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot20);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent29 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot20);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot20.getRowRenderingOrder();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(sortOrder30);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        boolean boolean5 = lineAndShapeRenderer2.getBaseShapesFilled();
        java.lang.Boolean boolean7 = lineAndShapeRenderer2.getSeriesCreateEntities(2);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        lineAndShapeRenderer2.setBaseToolTipGenerator(categoryToolTipGenerator8, true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(boolean7);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Color color3 = java.awt.Color.blue;
        renderAttributes1.setSeriesFillPaint(0, (java.awt.Paint) color3);
        java.awt.Paint paint7 = renderAttributes1.getItemPaint((int) (byte) 10, 255);
        java.awt.Paint paint9 = renderAttributes1.getSeriesPaint((-1));
        java.awt.Stroke stroke10 = null;
        try {
            renderAttributes1.setDefaultStroke(stroke10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNull(paint9);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor29 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor30 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor29, textAnchor30);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj34 = standardGradientPaintTransformer33.clone();
        boolean boolean35 = categoryAxis32.equals((java.lang.Object) standardGradientPaintTransformer33);
        boolean boolean36 = itemLabelPosition31.equals((java.lang.Object) boolean35);
        double double37 = itemLabelPosition31.getAngle();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor38 = itemLabelPosition31.getItemLabelAnchor();
        lineAndShapeRenderer2.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition31);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator41 = null;
        lineAndShapeRenderer2.setSeriesURLGenerator(1, categoryURLGenerator41);
        java.awt.Paint paint44 = lineAndShapeRenderer2.getSeriesPaint((int) (byte) 1);
        boolean boolean46 = lineAndShapeRenderer2.isSeriesVisible((int) '4');
        org.jfree.data.KeyedObjects2D keyedObjects2D47 = new org.jfree.data.KeyedObjects2D();
        java.awt.Color color48 = java.awt.Color.BLACK;
        boolean boolean49 = keyedObjects2D47.equals((java.lang.Object) color48);
        lineAndShapeRenderer2.setBaseOutlinePaint((java.awt.Paint) color48);
        java.awt.Paint paint52 = lineAndShapeRenderer2.lookupSeriesPaint(0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(itemLabelAnchor29);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor38);
        org.junit.Assert.assertNull(paint44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(paint52);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.setMaximumCategoryLabelLines(4);
        categoryAxis0.setLowerMargin(0.0d);
        double double14 = categoryAxis0.getFixedDimension();
        categoryAxis0.setMinorTickMarksVisible(true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.SelectableValue selectableValue1 = new org.jfree.data.SelectableValue((java.lang.Number) (byte) 100);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = keyedObjects2D0.clone();
        int int3 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 'a');
        org.jfree.data.KeyedObjects2D keyedObjects2D4 = new org.jfree.data.KeyedObjects2D();
        java.awt.Color color5 = java.awt.Color.BLACK;
        boolean boolean6 = keyedObjects2D4.equals((java.lang.Object) color5);
        boolean boolean7 = keyedObjects2D0.equals((java.lang.Object) keyedObjects2D4);
        try {
            java.lang.Object obj10 = keyedObjects2D0.getObject((java.lang.Comparable) 5, (java.lang.Comparable) 3.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (5) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        java.awt.Shape shape29 = lineAndShapeRenderer2.getBaseLegendShape();
        java.awt.Shape shape33 = lineAndShapeRenderer2.getItemShape((int) (byte) 100, (-14336), true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator37 = lineAndShapeRenderer2.getItemLabelGenerator((-14336), (int) ' ', true);
        java.awt.Font font38 = lineAndShapeRenderer2.getBaseItemLabelFont();
        java.awt.Shape shape39 = lineAndShapeRenderer2.getBaseLegendShape();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(shape29);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNull(categoryItemLabelGenerator37);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNull(shape39);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font11 = null;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 1, font11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double14 = rectangleInsets13.getRight();
        categoryAxis0.setLabelInsets(rectangleInsets13, true);
        org.jfree.chart.util.UnitType unitType17 = rectangleInsets13.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets(unitType17, 10.0d, (double) 0, (double) (-1L), (-1.0d));
        java.awt.Shape shape27 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity29 = new org.jfree.chart.entity.ChartEntity(shape27, "");
        java.awt.Shape shape30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape30);
        chartEntity29.setArea(shape30);
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape30, (java.awt.Paint) color33);
        legendItem34.setURLText("");
        boolean boolean37 = unitType17.equals((java.lang.Object) legendItem34);
        legendItem34.setToolTipText("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        java.awt.Paint paint40 = legendItem34.getLinePaint();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(unitType17);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(paint40);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        java.awt.Paint paint18 = categoryPlot15.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        categoryPlot15.setDataset(categoryDataset19);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot15.getRangeAxisEdge();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = categoryPlot15.getAxisOffset();
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        categoryPlot15.setRangeAxis((int) (short) 100, valueAxis24);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor26 = categoryPlot15.getDomainGridlinePosition();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(categoryAnchor26);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Font font2 = renderAttributes1.getDefaultLabelFont();
        java.lang.Boolean boolean3 = renderAttributes1.getDefaultLabelVisible();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke5 = defaultDrawingSupplier4.getNextStroke();
        java.awt.Shape shape6 = defaultDrawingSupplier4.getNextShape();
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape6);
        renderAttributes1.setDefaultShape(shape6);
        org.junit.Assert.assertNull(font2);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis2.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D8, rectangleEdge9);
        int int11 = categoryAxis2.getCategoryLabelPositionOffset();
        categoryAxis2.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis14, categoryItemRenderer15);
        java.awt.Paint paint17 = categoryPlot16.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = categoryPlot16.removeDomainMarker(marker18, layer19);
        boolean boolean21 = categoryPlot16.isRangeMinorGridlinesVisible();
        boolean boolean22 = abstractCategoryDataset0.hasListener((java.util.EventListener) categoryPlot16);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot16.getDomainMarkers(layer23);
        boolean boolean25 = categoryPlot16.isDomainPannable();
        categoryPlot16.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryPlot16.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = categoryPlot16.getDatasetRenderingOrder();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer33.setBaseItemLabelsVisible(false);
        boolean boolean36 = lineAndShapeRenderer33.getBaseShapesFilled();
        categoryPlot16.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer33);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator38 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        java.lang.Object obj39 = standardCategorySeriesLabelGenerator38.clone();
        lineAndShapeRenderer33.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator38);
        lineAndShapeRenderer33.setSeriesVisible((int) (short) 0, (java.lang.Boolean) true, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator46 = null;
        lineAndShapeRenderer33.setSeriesItemLabelGenerator((int) (short) 10, categoryItemLabelGenerator46, true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(obj39);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.trimHeight(0.0d);
        double double4 = rectangleInsets0.trimWidth((double) 0);
        double double6 = rectangleInsets0.calculateBottomOutset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        java.awt.Color color3 = java.awt.Color.getHSBColor(0.0f, (float) (byte) -1, (float) (short) 10);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateBottomInset((double) 1.0f);
        double double4 = rectangleInsets0.calculateRightOutset((double) (byte) 10);
        double double6 = rectangleInsets0.extendHeight(0.0d);
        org.jfree.chart.util.UnitType unitType7 = rectangleInsets0.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = new org.jfree.chart.util.RectangleInsets(unitType7, (double) '#', (double) (short) 100, 0.05d, (double) (byte) 100);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D16 = rectangleInsets12.createOutsetRectangle(rectangle2D13, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(unitType7);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis2.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D8, rectangleEdge9);
        int int11 = categoryAxis2.getCategoryLabelPositionOffset();
        categoryAxis2.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis14, categoryItemRenderer15);
        java.awt.Paint paint17 = categoryPlot16.getRangeCrosshairPaint();
        int int18 = categoryPlot16.getWeight();
        boolean boolean19 = legendItemCollection0.equals((java.lang.Object) int18);
        int int20 = legendItemCollection0.getItemCount();
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        java.awt.Font font28 = lineAndShapeRenderer2.getBaseItemLabelFont();
        java.awt.Paint paint29 = lineAndShapeRenderer2.getBaseLegendTextPaint();
        lineAndShapeRenderer2.setBaseShapesVisible(false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNull(paint29);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator5, true);
        java.lang.Boolean boolean9 = lineAndShapeRenderer2.getSeriesVisible((int) (short) 100);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator10 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        lineAndShapeRenderer2.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator10);
        boolean boolean14 = lineAndShapeRenderer2.getItemShapeVisible((int) 'a', 10);
        boolean boolean18 = lineAndShapeRenderer2.isItemLabelVisible((-14336), 0, true);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator20 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        lineAndShapeRenderer2.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator20);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator23 = null;
        lineAndShapeRenderer2.setSeriesItemLabelGenerator(2, categoryItemLabelGenerator23, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint33 = renderAttributes31.getSeriesOutlinePaint((int) '4');
        java.awt.Paint paint34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        renderAttributes31.setDefaultOutlinePaint(paint34);
        lineAndShapeRenderer28.setSeriesFillPaint((int) (byte) 0, paint34);
        lineAndShapeRenderer2.setBaseItemLabelPaint(paint34);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        java.lang.String str2 = unknownKeyException1.toString();
        org.jfree.data.UnknownKeyException unknownKeyException4 = new org.jfree.data.UnknownKeyException("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        java.lang.String str5 = unknownKeyException4.toString();
        java.lang.Throwable[] throwableArray6 = unknownKeyException4.getSuppressed();
        java.lang.String str7 = unknownKeyException4.toString();
        unknownKeyException1.addSuppressed((java.lang.Throwable) unknownKeyException4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.UnknownKeyException: 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0" + "'", str2.equals("org.jfree.data.UnknownKeyException: 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.UnknownKeyException: 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0" + "'", str5.equals("org.jfree.data.UnknownKeyException: 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0"));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.jfree.data.UnknownKeyException: 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0" + "'", str7.equals("org.jfree.data.UnknownKeyException: 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0"));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        java.awt.Paint paint1 = null;
        try {
            org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("", paint1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.util.ObjectList objectList18 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        float float21 = categoryAxis20.getMinorTickMarkInsideLength();
        boolean boolean22 = categoryAxis20.isMinorTickMarksVisible();
        categoryAxis20.setLabelURL("hi!");
        objectList18.set((int) (short) 10, (java.lang.Object) categoryAxis20);
        org.jfree.chart.plot.Plot plot26 = null;
        categoryAxis20.setPlot(plot26);
        categoryAxis20.setCategoryMargin((double) (-1));
        categoryPlot15.setDomainAxis((int) '#', categoryAxis20);
        categoryPlot15.setDomainCrosshairRowKey((java.lang.Comparable) 5, true);
        categoryPlot15.setRangeZeroBaselineVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset36 = categoryPlot15.getDataset();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(categoryDataset36);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Color color5 = java.awt.Color.GRAY;
        try {
            org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem(attributedString0, "ChartEntity: tooltip = ", "{0}", "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0", shape4, (java.awt.Paint) color5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMinorTickMarkInsideLength();
        boolean boolean2 = categoryAxis0.isMinorTickMarksVisible();
        boolean boolean3 = categoryAxis0.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot4 = null;
        categoryAxis0.setPlot(plot4);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = org.jfree.chart.axis.CategoryAnchor.START;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor6, (int) ' ', (int) (byte) 100, rectangle2D9, rectangleEdge10);
        categoryAxis0.setLabelToolTip("ItemLabelAnchor.INSIDE9");
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        java.awt.Paint paint18 = categoryPlot15.getBackgroundPaint();
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot15.getRangeAxis();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(valueAxis19);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes((double) 100, plotRenderingInfo6, point2D7, false);
        categoryPlot4.setRangeGridlinesVisible(false);
        org.jfree.data.KeyedObjects2D keyedObjects2D12 = new org.jfree.data.KeyedObjects2D();
        java.awt.Color color13 = java.awt.Color.BLACK;
        boolean boolean14 = keyedObjects2D12.equals((java.lang.Object) color13);
        int int15 = color13.getTransparency();
        categoryPlot4.setRangeGridlinePaint((java.awt.Paint) color13);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = keyedObjects2D0.clone();
        int int3 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 'a');
        org.jfree.data.KeyedObjects2D keyedObjects2D4 = new org.jfree.data.KeyedObjects2D();
        java.awt.Color color5 = java.awt.Color.BLACK;
        boolean boolean6 = keyedObjects2D4.equals((java.lang.Object) color5);
        boolean boolean7 = keyedObjects2D0.equals((java.lang.Object) keyedObjects2D4);
        int int8 = keyedObjects2D4.getColumnCount();
        java.lang.Comparable comparable9 = null;
        try {
            java.lang.Object obj11 = keyedObjects2D4.getObject(comparable9, (java.lang.Comparable) 0.2d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "");
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape7);
        chartEntity6.setArea(shape7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape7, (java.awt.Paint) color10);
        legendItem11.setURLText("{0}");
        java.awt.Paint paint14 = legendItem11.getOutlinePaint();
        boolean boolean15 = legendItem11.isShapeVisible();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        java.awt.Stroke stroke17 = categoryPlot15.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot15.zoomRangeAxes((double) (short) -1, plotRenderingInfo19, point2D20, false);
        org.jfree.chart.axis.AxisLocation axisLocation23 = categoryPlot15.getDomainAxisLocation();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) axisLocation23);
        org.jfree.chart.JFreeChart jFreeChart25 = chartChangeEvent24.getChart();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNull(jFreeChart25);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator5, true);
        java.lang.Boolean boolean9 = lineAndShapeRenderer2.getSeriesVisible((int) (short) 100);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator10 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        lineAndShapeRenderer2.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator10);
        boolean boolean14 = lineAndShapeRenderer2.getItemShapeVisible((int) 'a', 10);
        boolean boolean18 = lineAndShapeRenderer2.isItemLabelVisible((-14336), 0, true);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.data.Range range20 = lineAndShapeRenderer2.findRangeBounds(categoryDataset19);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(range20);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj2 = standardGradientPaintTransformer1.clone();
        boolean boolean3 = categoryAxis0.equals((java.lang.Object) standardGradientPaintTransformer1);
        categoryAxis0.setLabelToolTip("CategoryAnchor.START");
        categoryAxis0.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryAxis0.getTickLabelInsets();
        double double8 = categoryAxis0.getUpperMargin();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator5, true);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator8 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        lineAndShapeRenderer2.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator8);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = lineAndShapeRenderer2.getLegendItemToolTipGenerator();
        lineAndShapeRenderer2.setSeriesShapesFilled((int) (byte) 1, false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator10);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        int int17 = categoryPlot15.getWeight();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        categoryPlot15.setRenderer(categoryItemRenderer18);
        categoryPlot15.clearRangeMarkers((-255));
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        categoryPlot15.zoomRangeAxes((double) (-1L), plotRenderingInfo23, point2D24);
        categoryPlot15.setDomainCrosshairVisible(true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.setMaximumCategoryLabelLines(4);
        categoryAxis0.setLowerMargin(0.0d);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis0.getCategorySeriesMiddle((int) (byte) 1, (int) ' ', (int) (byte) 10, 0, 3.0d, rectangle2D19, rectangleEdge20);
        boolean boolean22 = categoryAxis0.isMinorTickMarksVisible();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = null;
        double double35 = categoryAxis27.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D33, rectangleEdge34);
        int int36 = categoryAxis27.getCategoryLabelPositionOffset();
        categoryAxis27.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, valueAxis39, categoryItemRenderer40);
        java.awt.Paint paint42 = categoryPlot41.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor43 = categoryPlot41.getDomainGridlinePosition();
        java.awt.Paint paint44 = categoryPlot41.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset45 = null;
        categoryPlot41.setDataset(categoryDataset45);
        org.jfree.chart.LegendItemCollection legendItemCollection47 = categoryPlot41.getLegendItems();
        boolean boolean48 = categoryPlot41.canSelectByPoint();
        int int49 = categoryPlot41.getRangeAxisCount();
        categoryPlot41.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = categoryPlot41.getDomainAxisEdge();
        try {
            double double52 = categoryAxis0.getCategoryMiddle((-32513), (int) 'a', rectangle2D25, rectangleEdge51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -32513");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 4 + "'", int36 == 4);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(categoryAnchor43);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(legendItemCollection47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1 + "'", int49 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge51);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font11 = null;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 1, font11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double14 = rectangleInsets13.getRight();
        categoryAxis0.setLabelInsets(rectangleInsets13, true);
        org.jfree.chart.util.UnitType unitType17 = rectangleInsets13.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets(unitType17, 10.0d, (double) 0, (double) (-1L), (-1.0d));
        java.awt.Shape shape27 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity29 = new org.jfree.chart.entity.ChartEntity(shape27, "");
        java.awt.Shape shape30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape30);
        chartEntity29.setArea(shape30);
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape30, (java.awt.Paint) color33);
        legendItem34.setURLText("");
        boolean boolean37 = unitType17.equals((java.lang.Object) legendItem34);
        legendItem34.setShapeVisible(true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(unitType17);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        java.lang.String str18 = categoryAnchor17.toString();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str18.equals("CategoryAnchor.MIDDLE"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.util.ObjectList objectList18 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        float float21 = categoryAxis20.getMinorTickMarkInsideLength();
        boolean boolean22 = categoryAxis20.isMinorTickMarksVisible();
        categoryAxis20.setLabelURL("hi!");
        objectList18.set((int) (short) 10, (java.lang.Object) categoryAxis20);
        org.jfree.chart.plot.Plot plot26 = null;
        categoryAxis20.setPlot(plot26);
        categoryAxis20.setCategoryMargin((double) (-1));
        categoryPlot15.setDomainAxis((int) '#', categoryAxis20);
        categoryPlot15.setDomainCrosshairRowKey((java.lang.Comparable) 5, true);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray35 = new org.jfree.chart.axis.ValueAxis[] { valueAxis34 };
        categoryPlot15.setRangeAxes(valueAxisArray35);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(valueAxisArray35);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        java.awt.Paint paint18 = categoryPlot15.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        categoryPlot15.setDataset(categoryDataset19);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot15.getRangeAxisEdge();
        org.jfree.chart.plot.Plot plot22 = categoryPlot15.getRootPlot();
        categoryPlot15.setDomainCrosshairColumnKey((java.lang.Comparable) 255, true);
        java.awt.Stroke stroke26 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot15.setRangeCrosshairStroke(stroke26);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(plot22);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes((double) 100, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis10.setLabelURL("");
        java.awt.Paint paint13 = categoryAxis10.getAxisLinePaint();
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset14 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener15 = null;
        boolean boolean16 = abstractCategoryDataset14.hasListener(eventListener15);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener17 = null;
        abstractCategoryDataset14.removeChangeListener(datasetChangeListener17);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = categoryAxis20.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D26, rectangleEdge27);
        int int29 = categoryAxis20.getCategoryLabelPositionOffset();
        categoryAxis20.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis32, categoryItemRenderer33);
        java.awt.Paint paint35 = categoryPlot34.getRangeCrosshairPaint();
        int int36 = categoryPlot34.getWeight();
        abstractCategoryDataset14.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot34);
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo38 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent39 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) categoryAxis10, (org.jfree.data.general.Dataset) abstractCategoryDataset14, datasetChangeInfo38);
        org.jfree.data.general.Dataset dataset40 = datasetChangeEvent39.getDataset();
        categoryPlot4.datasetChanged(datasetChangeEvent39);
        float float42 = categoryPlot4.getForegroundAlpha();
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(dataset40);
        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 1.0f + "'", float42 == 1.0f);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor29 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor30 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor29, textAnchor30);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj34 = standardGradientPaintTransformer33.clone();
        boolean boolean35 = categoryAxis32.equals((java.lang.Object) standardGradientPaintTransformer33);
        boolean boolean36 = itemLabelPosition31.equals((java.lang.Object) boolean35);
        double double37 = itemLabelPosition31.getAngle();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor38 = itemLabelPosition31.getItemLabelAnchor();
        lineAndShapeRenderer2.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition31);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator41 = null;
        lineAndShapeRenderer2.setSeriesURLGenerator(1, categoryURLGenerator41);
        java.awt.Paint paint44 = lineAndShapeRenderer2.getSeriesPaint((int) (byte) 1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer47 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer47.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator50 = null;
        lineAndShapeRenderer47.setBaseURLGenerator(categoryURLGenerator50, true);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator53 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        lineAndShapeRenderer47.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator53);
        lineAndShapeRenderer2.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator53);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis();
        boolean boolean58 = categoryAxis57.isAxisLineVisible();
        java.awt.Color color59 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int60 = color59.getBlue();
        float[] floatArray64 = new float[] { '#', (byte) 10, (short) 100 };
        float[] floatArray65 = color59.getColorComponents(floatArray64);
        categoryAxis57.setAxisLinePaint((java.awt.Paint) color59);
        lineAndShapeRenderer2.setSeriesPaint((int) (short) 100, (java.awt.Paint) color59);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(itemLabelAnchor29);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor38);
        org.junit.Assert.assertNull(paint44);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(floatArray64);
        org.junit.Assert.assertNotNull(floatArray65);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        java.awt.Stroke stroke9 = categoryAxis0.getTickMarkStroke();
        categoryAxis0.setMinorTickMarkOutsideLength((float) 10);
        categoryAxis0.setTickMarksVisible(false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        int int17 = categoryPlot15.getWeight();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        categoryPlot15.setRenderer(categoryItemRenderer18);
        categoryPlot15.clearRangeMarkers((-255));
        org.jfree.chart.LegendItemCollection legendItemCollection22 = new org.jfree.chart.LegendItemCollection();
        categoryPlot15.setFixedLegendItems(legendItemCollection22);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = categoryPlot15.getDomainAxis((-1));
        int int26 = categoryPlot15.getDatasetCount();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(categoryAxis25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("");
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes((double) 100, plotRenderingInfo6, point2D7, false);
        categoryPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        try {
            categoryPlot4.handleClick(1, 5, plotRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor29 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor30 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor29, textAnchor30);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj34 = standardGradientPaintTransformer33.clone();
        boolean boolean35 = categoryAxis32.equals((java.lang.Object) standardGradientPaintTransformer33);
        boolean boolean36 = itemLabelPosition31.equals((java.lang.Object) boolean35);
        double double37 = itemLabelPosition31.getAngle();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor38 = itemLabelPosition31.getItemLabelAnchor();
        lineAndShapeRenderer2.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition31);
        lineAndShapeRenderer2.setBaseCreateEntities(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator42 = null;
        lineAndShapeRenderer2.setBaseToolTipGenerator(categoryToolTipGenerator42, true);
        java.awt.Shape shape46 = lineAndShapeRenderer2.lookupLegendShape((-2));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(itemLabelAnchor29);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor38);
        org.junit.Assert.assertNotNull(shape46);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabelURL("");
        java.awt.Paint paint3 = categoryAxis0.getAxisLinePaint();
        categoryAxis0.setCategoryLabelPositionOffset(5);
        double double6 = categoryAxis0.getFixedDimension();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        java.awt.Shape shape29 = lineAndShapeRenderer2.getBaseLegendShape();
        java.awt.Shape shape33 = lineAndShapeRenderer2.getItemShape((int) (byte) 100, (-14336), true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator37 = lineAndShapeRenderer2.getItemLabelGenerator((-14336), (int) ' ', true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator41 = lineAndShapeRenderer2.getToolTipGenerator(0, (int) 'a', false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(shape29);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNull(categoryItemLabelGenerator37);
        org.junit.Assert.assertNull(categoryToolTipGenerator41);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        double double16 = categoryPlot15.getAnchorValue();
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot15.getRangeAxis((int) (short) 10);
        categoryPlot15.setDrawSharedDomainAxis(false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNull(valueAxis18);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "");
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape7);
        chartEntity6.setArea(shape7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape7, (java.awt.Paint) color10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis13.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D19, rectangleEdge20);
        int int22 = categoryAxis13.getCategoryLabelPositionOffset();
        categoryAxis13.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis25, categoryItemRenderer26);
        java.awt.Paint paint28 = categoryPlot27.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor29 = categoryPlot27.getDomainGridlinePosition();
        org.jfree.chart.entity.PlotEntity plotEntity30 = new org.jfree.chart.entity.PlotEntity(shape7, (org.jfree.chart.plot.Plot) categoryPlot27);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset34 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener35 = null;
        boolean boolean36 = abstractCategoryDataset34.hasListener(eventListener35);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener37 = null;
        abstractCategoryDataset34.removeChangeListener(datasetChangeListener37);
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = null;
        double double48 = categoryAxis40.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D46, rectangleEdge47);
        int int49 = categoryAxis40.getCategoryLabelPositionOffset();
        categoryAxis40.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis52 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, valueAxis52, categoryItemRenderer53);
        java.awt.Paint paint55 = categoryPlot54.getRangeCrosshairPaint();
        int int56 = categoryPlot54.getWeight();
        abstractCategoryDataset34.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot54);
        lineAndShapeRenderer33.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot54);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor60 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor61 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition62 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor60, textAnchor61);
        org.jfree.chart.axis.CategoryAxis categoryAxis63 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer64 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj65 = standardGradientPaintTransformer64.clone();
        boolean boolean66 = categoryAxis63.equals((java.lang.Object) standardGradientPaintTransformer64);
        boolean boolean67 = itemLabelPosition62.equals((java.lang.Object) boolean66);
        double double68 = itemLabelPosition62.getAngle();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor69 = itemLabelPosition62.getItemLabelAnchor();
        lineAndShapeRenderer33.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition62);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator72 = null;
        lineAndShapeRenderer33.setSeriesURLGenerator(1, categoryURLGenerator72);
        java.awt.Paint paint75 = lineAndShapeRenderer33.getSeriesPaint((int) (byte) 1);
        boolean boolean77 = lineAndShapeRenderer33.isSeriesVisible((int) '4');
        org.jfree.data.KeyedObjects2D keyedObjects2D78 = new org.jfree.data.KeyedObjects2D();
        java.awt.Color color79 = java.awt.Color.BLACK;
        boolean boolean80 = keyedObjects2D78.equals((java.lang.Object) color79);
        lineAndShapeRenderer33.setBaseOutlinePaint((java.awt.Paint) color79);
        categoryPlot27.setRangeZeroBaselinePaint((java.awt.Paint) color79);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(categoryAnchor29);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 4 + "'", int49 == 4);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(itemLabelAnchor60);
        org.junit.Assert.assertNotNull(textAnchor61);
        org.junit.Assert.assertNotNull(obj65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor69);
        org.junit.Assert.assertNull(paint75);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertNotNull(color79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator5, true);
        java.awt.Font font9 = lineAndShapeRenderer2.lookupLegendTextFont((int) (byte) 0);
        java.lang.Boolean boolean11 = lineAndShapeRenderer2.getSeriesItemLabelsVisible(4);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = lineAndShapeRenderer2.getSeriesItemLabelGenerator((-254));
        org.junit.Assert.assertNull(font9);
        org.junit.Assert.assertNull(boolean11);
        org.junit.Assert.assertNull(categoryItemLabelGenerator13);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        int int17 = categoryPlot15.getWeight();
        java.lang.Comparable comparable18 = null;
        categoryPlot15.setDomainCrosshairRowKey(comparable18, true);
        org.jfree.chart.util.SortOrder sortOrder21 = categoryPlot15.getRowRenderingOrder();
        java.lang.String str22 = sortOrder21.toString();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(sortOrder21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "SortOrder.ASCENDING" + "'", str22.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.2d, (double) (byte) 0, (double) 255, (double) (-14336));
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets4.createOutsetRectangle(rectangle2D5, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Color color3 = java.awt.Color.blue;
        renderAttributes1.setSeriesFillPaint(0, (java.awt.Paint) color3);
        java.awt.Paint paint7 = renderAttributes1.getItemPaint((int) (byte) 10, 255);
        java.awt.Stroke stroke8 = renderAttributes1.getDefaultOutlineStroke();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNull(stroke8);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.util.ObjectList objectList18 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        float float21 = categoryAxis20.getMinorTickMarkInsideLength();
        boolean boolean22 = categoryAxis20.isMinorTickMarksVisible();
        categoryAxis20.setLabelURL("hi!");
        objectList18.set((int) (short) 10, (java.lang.Object) categoryAxis20);
        org.jfree.chart.plot.Plot plot26 = null;
        categoryAxis20.setPlot(plot26);
        categoryAxis20.setCategoryMargin((double) (-1));
        categoryPlot15.setDomainAxis((int) '#', categoryAxis20);
        categoryPlot15.configureRangeAxes();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder32 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str33 = datasetRenderingOrder32.toString();
        categoryPlot15.setDatasetRenderingOrder(datasetRenderingOrder32);
        org.jfree.chart.event.AnnotationChangeEvent annotationChangeEvent35 = null;
        categoryPlot15.annotationChanged(annotationChangeEvent35);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = categoryPlot15.getDomainAxisForDataset(64);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer41 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset42 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener43 = null;
        boolean boolean44 = abstractCategoryDataset42.hasListener(eventListener43);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener45 = null;
        abstractCategoryDataset42.removeChangeListener(datasetChangeListener45);
        org.jfree.data.category.CategoryDataset categoryDataset47 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = null;
        double double56 = categoryAxis48.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D54, rectangleEdge55);
        int int57 = categoryAxis48.getCategoryLabelPositionOffset();
        categoryAxis48.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset47, categoryAxis48, valueAxis60, categoryItemRenderer61);
        java.awt.Paint paint63 = categoryPlot62.getRangeCrosshairPaint();
        int int64 = categoryPlot62.getWeight();
        abstractCategoryDataset42.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot62);
        lineAndShapeRenderer41.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot62);
        boolean boolean67 = lineAndShapeRenderer41.getBaseShapesFilled();
        org.jfree.chart.renderer.RenderAttributes renderAttributes70 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint72 = renderAttributes70.getSeriesOutlinePaint((int) '4');
        java.awt.Stroke stroke73 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes70.setDefaultStroke(stroke73);
        lineAndShapeRenderer41.setSeriesStroke(0, stroke73, false);
        org.jfree.data.category.CategoryDataset categoryDataset77 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis78 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D84 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge85 = null;
        double double86 = categoryAxis78.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D84, rectangleEdge85);
        int int87 = categoryAxis78.getCategoryLabelPositionOffset();
        categoryAxis78.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis90 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer91 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot92 = new org.jfree.chart.plot.CategoryPlot(categoryDataset77, categoryAxis78, valueAxis90, categoryItemRenderer91);
        org.jfree.chart.event.PlotChangeListener plotChangeListener93 = null;
        categoryPlot92.addChangeListener(plotChangeListener93);
        lineAndShapeRenderer41.setPlot(categoryPlot92);
        categoryAxis38.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot92);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str33.equals("DatasetRenderingOrder.FORWARD"));
        org.junit.Assert.assertNotNull(categoryAxis38);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 4 + "'", int57 == 4);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNull(paint72);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 4 + "'", int87 == 4);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint33 = renderAttributes31.getSeriesOutlinePaint((int) '4');
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes31.setDefaultStroke(stroke34);
        lineAndShapeRenderer2.setSeriesStroke(0, stroke34, false);
        lineAndShapeRenderer2.clearSeriesStrokes(true);
        java.lang.Boolean boolean41 = lineAndShapeRenderer2.getSeriesVisible((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNull(boolean41);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis2.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D8, rectangleEdge9);
        int int11 = categoryAxis2.getCategoryLabelPositionOffset();
        categoryAxis2.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis14, categoryItemRenderer15);
        java.awt.Paint paint17 = categoryPlot16.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = categoryPlot16.removeDomainMarker(marker18, layer19);
        boolean boolean21 = categoryPlot16.isRangeMinorGridlinesVisible();
        boolean boolean22 = abstractCategoryDataset0.hasListener((java.util.EventListener) categoryPlot16);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot16.getDomainMarkers(layer23);
        boolean boolean25 = categoryPlot16.isDomainPannable();
        categoryPlot16.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryPlot16.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = categoryPlot16.getDatasetRenderingOrder();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer33.setBaseItemLabelsVisible(false);
        boolean boolean36 = lineAndShapeRenderer33.getBaseShapesFilled();
        categoryPlot16.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer33);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator38 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        java.lang.Object obj39 = standardCategorySeriesLabelGenerator38.clone();
        lineAndShapeRenderer33.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator38);
        lineAndShapeRenderer33.setSeriesShapesFilled(4, false);
        java.awt.Graphics2D graphics2D44 = null;
        org.jfree.data.category.CategoryDataset categoryDataset45 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = null;
        double double54 = categoryAxis46.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D52, rectangleEdge53);
        int int55 = categoryAxis46.getCategoryLabelPositionOffset();
        categoryAxis46.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis58 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer59 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, valueAxis58, categoryItemRenderer59);
        java.awt.Paint paint61 = categoryPlot60.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker62 = null;
        org.jfree.chart.util.Layer layer63 = null;
        boolean boolean64 = categoryPlot60.removeDomainMarker(marker62, layer63);
        boolean boolean65 = categoryPlot60.isRangeMinorGridlinesVisible();
        categoryPlot60.clearDomainMarkers((int) '4');
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        try {
            lineAndShapeRenderer33.drawOutline(graphics2D44, categoryPlot60, rectangle2D68);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 4 + "'", int55 == 4);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj2 = standardGradientPaintTransformer1.clone();
        boolean boolean3 = categoryAxis0.equals((java.lang.Object) standardGradientPaintTransformer1);
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 3.0d, "poly");
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = categoryAxis8.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D14, rectangleEdge15);
        int int17 = categoryAxis8.getCategoryLabelPositionOffset();
        categoryAxis8.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis20, categoryItemRenderer21);
        java.awt.Paint paint23 = categoryPlot22.getRangeCrosshairPaint();
        int int24 = categoryPlot22.getWeight();
        categoryPlot22.configureDomainAxes();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot22);
        categoryAxis0.setTickMarkOutsideLength(0.0f);
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = null;
        double double38 = categoryAxis30.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D36, rectangleEdge37);
        int int39 = categoryAxis30.getCategoryLabelPositionOffset();
        categoryAxis30.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, valueAxis42, categoryItemRenderer43);
        org.jfree.chart.event.PlotChangeListener plotChangeListener45 = null;
        categoryPlot44.addChangeListener(plotChangeListener45);
        categoryPlot44.setDomainCrosshairColumnKey((java.lang.Comparable) 5, false);
        categoryPlot44.mapDatasetToRangeAxis(0, 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = categoryPlot44.getDomainAxisEdge();
        boolean boolean54 = categoryAxis0.hasListener((java.util.EventListener) categoryPlot44);
        float float55 = categoryPlot44.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 4 + "'", int39 == 4);
        org.junit.Assert.assertNotNull(rectangleEdge53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + float55 + "' != '" + 1.0f + "'", float55 == 1.0f);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        java.awt.Shape shape3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape3);
        chartEntity2.setArea(shape3);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = categoryAxis7.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D13, rectangleEdge14);
        int int16 = categoryAxis7.getCategoryLabelPositionOffset();
        categoryAxis7.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.util.ObjectList objectList24 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        float float27 = categoryAxis26.getMinorTickMarkInsideLength();
        boolean boolean28 = categoryAxis26.isMinorTickMarksVisible();
        categoryAxis26.setLabelURL("hi!");
        objectList24.set((int) (short) 10, (java.lang.Object) categoryAxis26);
        org.jfree.chart.plot.Plot plot32 = null;
        categoryAxis26.setPlot(plot32);
        categoryAxis26.setCategoryMargin((double) (-1));
        categoryPlot21.setDomainAxis((int) '#', categoryAxis26);
        categoryPlot21.configureRangeAxes();
        org.jfree.chart.entity.PlotEntity plotEntity38 = new org.jfree.chart.entity.PlotEntity(shape3, (org.jfree.chart.plot.Plot) categoryPlot21);
        categoryPlot21.setNoDataMessage("GradientPaintTransformType.VERTICAL");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.0f + "'", float27 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis2.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D8, rectangleEdge9);
        int int11 = categoryAxis2.getCategoryLabelPositionOffset();
        categoryAxis2.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis14, categoryItemRenderer15);
        java.awt.Paint paint17 = categoryPlot16.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = categoryPlot16.removeDomainMarker(marker18, layer19);
        boolean boolean21 = categoryPlot16.isRangeMinorGridlinesVisible();
        boolean boolean22 = abstractCategoryDataset0.hasListener((java.util.EventListener) categoryPlot16);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot16.getDomainMarkers(layer23);
        boolean boolean25 = categoryPlot16.isDomainPannable();
        categoryPlot16.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryPlot16.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = categoryPlot16.getDatasetRenderingOrder();
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset30 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener31 = null;
        boolean boolean32 = abstractCategoryDataset30.hasListener(eventListener31);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener33 = null;
        abstractCategoryDataset30.removeChangeListener(datasetChangeListener33);
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = null;
        double double44 = categoryAxis36.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D42, rectangleEdge43);
        int int45 = categoryAxis36.getCategoryLabelPositionOffset();
        categoryAxis36.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, valueAxis48, categoryItemRenderer49);
        java.awt.Paint paint51 = categoryPlot50.getRangeCrosshairPaint();
        int int52 = categoryPlot50.getWeight();
        abstractCategoryDataset30.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot50);
        java.awt.Shape shape58 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity60 = new org.jfree.chart.entity.ChartEntity(shape58, "");
        java.awt.Shape shape61 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent62 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape61);
        chartEntity60.setArea(shape61);
        java.awt.Color color64 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem65 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape61, (java.awt.Paint) color64);
        legendItem65.setURLText("{0}");
        java.awt.Stroke stroke68 = legendItem65.getOutlineStroke();
        categoryPlot50.setDomainCrosshairStroke(stroke68);
        categoryPlot16.setOutlineStroke(stroke68);
        java.awt.Paint paint71 = categoryPlot16.getRangeGridlinePaint();
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 4 + "'", int45 == 4);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(shape58);
        org.junit.Assert.assertNotNull(shape61);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNotNull(paint71);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis2.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D8, rectangleEdge9);
        int int11 = categoryAxis2.getCategoryLabelPositionOffset();
        categoryAxis2.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis14, categoryItemRenderer15);
        java.awt.Paint paint17 = categoryPlot16.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = categoryPlot16.removeDomainMarker(marker18, layer19);
        boolean boolean21 = categoryPlot16.isRangeMinorGridlinesVisible();
        boolean boolean22 = abstractCategoryDataset0.hasListener((java.util.EventListener) categoryPlot16);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot16.getDomainMarkers(layer23);
        boolean boolean25 = categoryPlot16.isDomainPannable();
        categoryPlot16.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryPlot16.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = categoryPlot16.getDatasetRenderingOrder();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer33.setBaseItemLabelsVisible(false);
        boolean boolean36 = lineAndShapeRenderer33.getBaseShapesFilled();
        categoryPlot16.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer33);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator38 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        java.lang.Object obj39 = standardCategorySeriesLabelGenerator38.clone();
        lineAndShapeRenderer33.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator38);
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        org.jfree.data.Range range42 = lineAndShapeRenderer33.findRangeBounds(categoryDataset41);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNull(range42);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMinorTickMarkInsideLength();
        boolean boolean2 = categoryAxis0.isMinorTickMarksVisible();
        boolean boolean3 = categoryAxis0.isTickLabelsVisible();
        java.awt.Paint paint4 = categoryAxis0.getTickMarkPaint();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = categoryAxis6.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D12, rectangleEdge13);
        int int15 = categoryAxis6.getCategoryLabelPositionOffset();
        categoryAxis6.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot20.addChangeListener(plotChangeListener21);
        categoryPlot20.setDomainCrosshairColumnKey((java.lang.Comparable) 5, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        int int27 = categoryPlot20.getIndexOf(categoryItemRenderer26);
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot20);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent29 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot20);
        org.jfree.chart.plot.Plot plot30 = plotChangeEvent29.getPlot();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(plot30);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int3 = color2.getAlpha();
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator7 = new org.jfree.chart.util.DefaultShadowGenerator((int) (short) 0, color2, (-1.0f), 10, (double) (short) 1);
        java.awt.Color color8 = defaultShadowGenerator7.getShadowColor();
        int int9 = defaultShadowGenerator7.calculateOffsetX();
        int int10 = defaultShadowGenerator7.getShadowSize();
        boolean boolean11 = booleanList0.equals((java.lang.Object) int10);
        java.lang.Boolean boolean13 = booleanList0.getBoolean((int) (byte) 10);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 5 + "'", int9 == 5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(boolean13);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMinorTickMarkInsideLength();
        boolean boolean2 = categoryAxis0.isMinorTickMarksVisible();
        categoryAxis0.setLabelURL("hi!");
        java.awt.Paint paint5 = categoryAxis0.getTickLabelPaint();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator5, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = lineAndShapeRenderer2.getBaseItemLabelGenerator();
        org.junit.Assert.assertNull(categoryItemLabelGenerator8);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        java.awt.Font font5 = lineAndShapeRenderer2.getBaseItemLabelFont();
        java.lang.Boolean boolean7 = lineAndShapeRenderer2.getSeriesVisible((-14336));
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker25 = null;
        org.jfree.chart.util.Layer layer26 = null;
        boolean boolean27 = categoryPlot23.removeDomainMarker(marker25, layer26);
        org.jfree.chart.util.Layer layer28 = null;
        java.util.Collection collection29 = categoryPlot23.getRangeMarkers(layer28);
        java.awt.Font font30 = categoryPlot23.getNoDataMessageFont();
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        categoryPlot23.setRangeMinorGridlinePaint((java.awt.Paint) color31);
        lineAndShapeRenderer2.setBaseLegendTextPaint((java.awt.Paint) color31);
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = null;
        double double44 = categoryAxis36.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D42, rectangleEdge43);
        int int45 = categoryAxis36.getCategoryLabelPositionOffset();
        categoryAxis36.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, valueAxis48, categoryItemRenderer49);
        java.awt.Paint paint51 = categoryPlot50.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor52 = categoryPlot50.getDomainGridlinePosition();
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        java.awt.Shape shape60 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity62 = new org.jfree.chart.entity.ChartEntity(shape60, "");
        java.awt.Shape shape63 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent64 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape63);
        chartEntity62.setArea(shape63);
        java.awt.Color color66 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem67 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape63, (java.awt.Paint) color66);
        int int68 = color66.getBlue();
        int int69 = color66.getBlue();
        org.jfree.chart.util.RectangleInsets rectangleInsets70 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double72 = rectangleInsets70.calculateTopInset((double) 10);
        double double74 = rectangleInsets70.calculateRightOutset(100.0d);
        org.jfree.chart.text.TextAnchor textAnchor75 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.renderer.RenderAttributes renderAttributes77 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint79 = renderAttributes77.getSeriesOutlinePaint((int) '4');
        java.awt.Paint paint80 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        renderAttributes77.setDefaultOutlinePaint(paint80);
        boolean boolean82 = textAnchor75.equals((java.lang.Object) renderAttributes77);
        boolean boolean83 = rectangleInsets70.equals((java.lang.Object) renderAttributes77);
        java.awt.Paint paint85 = renderAttributes77.getSeriesOutlinePaint(5);
        java.awt.Paint paint88 = renderAttributes77.getItemPaint((int) ' ', (int) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier89 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke90 = defaultDrawingSupplier89.getNextStroke();
        renderAttributes77.setDefaultOutlineStroke(stroke90);
        try {
            lineAndShapeRenderer2.drawRangeLine(graphics2D34, categoryPlot50, valueAxis53, rectangle2D54, (double) (byte) -1, (java.awt.Paint) color66, stroke90);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(collection29);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 4 + "'", int45 == 4);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(categoryAnchor52);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(shape63);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 64 + "'", int68 == 64);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 64 + "'", int69 == 64);
        org.junit.Assert.assertNotNull(rectangleInsets70);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertNotNull(textAnchor75);
        org.junit.Assert.assertNull(paint79);
        org.junit.Assert.assertNotNull(paint80);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNull(paint85);
        org.junit.Assert.assertNull(paint88);
        org.junit.Assert.assertNotNull(stroke90);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) 10L);
        categoryAxis0.setTickMarkInsideLength((float) 64);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
        double double26 = categoryAxis18.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D24, rectangleEdge25);
        int int27 = categoryAxis18.getCategoryLabelPositionOffset();
        categoryAxis18.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis30, categoryItemRenderer31);
        java.awt.Paint paint33 = categoryPlot32.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor34 = categoryPlot32.getDomainGridlinePosition();
        java.awt.Paint paint35 = categoryPlot32.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset36 = null;
        categoryPlot32.setDataset(categoryDataset36);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = categoryPlot32.getRangeAxisEdge();
        org.jfree.chart.axis.AxisState axisState39 = null;
        categoryAxis0.drawTickMarks(graphics2D14, (double) 5, rectangle2D16, rectangleEdge38, axisState39);
        java.awt.Color color41 = java.awt.Color.gray;
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color41);
        java.awt.Paint paint43 = categoryAxis0.getTickLabelPaint();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(categoryAnchor34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(paint43);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabelURL("");
        java.awt.Font font3 = categoryAxis0.getTickLabelFont();
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint33 = renderAttributes31.getSeriesOutlinePaint((int) '4');
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes31.setDefaultStroke(stroke34);
        lineAndShapeRenderer2.setSeriesStroke(0, stroke34, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation38 = null;
        boolean boolean39 = lineAndShapeRenderer2.removeAnnotation(categoryAnnotation38);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (byte) 10, false);
        int int43 = lineAndShapeRenderer2.getDefaultEntityRadius();
        int int44 = lineAndShapeRenderer2.getDefaultEntityRadius();
        java.awt.Paint paint48 = lineAndShapeRenderer2.getItemOutlinePaint(0, 5, false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 3 + "'", int43 == 3);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 3 + "'", int44 == 3);
        org.junit.Assert.assertNotNull(paint48);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int2 = color1.getAlpha();
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator6 = new org.jfree.chart.util.DefaultShadowGenerator((int) (short) 0, color1, (-1.0f), 10, (double) (short) 1);
        java.awt.Color color7 = defaultShadowGenerator6.getShadowColor();
        java.awt.image.BufferedImage bufferedImage8 = null;
        try {
            java.awt.image.BufferedImage bufferedImage9 = defaultShadowGenerator6.createDropShadow(bufferedImage8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL");
        legendItem1.setToolTipText("DatasetRenderingOrder.REVERSE");
        java.awt.Stroke stroke4 = legendItem1.getOutlineStroke();
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        java.awt.Paint paint18 = categoryPlot15.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        categoryPlot15.setDataset(categoryDataset19);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot15.getRangeAxisEdge();
        boolean boolean22 = categoryPlot15.isRangeGridlinesVisible();
        org.jfree.chart.renderer.RenderAttributes renderAttributes24 = new org.jfree.chart.renderer.RenderAttributes(false);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        double double34 = categoryAxis26.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D32, rectangleEdge33);
        int int35 = categoryAxis26.getCategoryLabelPositionOffset();
        categoryAxis26.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, valueAxis38, categoryItemRenderer39);
        java.awt.Paint paint41 = categoryPlot40.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor42 = categoryPlot40.getDomainGridlinePosition();
        java.awt.Paint paint43 = categoryPlot40.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset44 = null;
        categoryPlot40.setDataset(categoryDataset44);
        org.jfree.chart.LegendItemCollection legendItemCollection46 = categoryPlot40.getLegendItems();
        java.awt.Stroke stroke47 = categoryPlot40.getRangeGridlineStroke();
        renderAttributes24.setDefaultStroke(stroke47);
        categoryPlot15.setRangeCrosshairStroke(stroke47);
        org.jfree.chart.util.Layer layer51 = null;
        java.util.Collection collection52 = categoryPlot15.getDomainMarkers((-254), layer51);
        categoryPlot15.setDomainCrosshairColumnKey((java.lang.Comparable) (-1.0d), false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(categoryAnchor42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(legendItemCollection46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNull(collection52);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        int int17 = categoryPlot15.getWeight();
        java.lang.Comparable comparable18 = null;
        categoryPlot15.setDomainCrosshairRowKey(comparable18, true);
        categoryPlot15.clearAnnotations();
        java.awt.geom.GeneralPath generalPath22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.RenderingSource renderingSource24 = null;
        categoryPlot15.select(generalPath22, rectangle2D23, renderingSource24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = categoryPlot15.getDatasetRenderingOrder();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint33 = renderAttributes31.getSeriesOutlinePaint((int) '4');
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes31.setDefaultStroke(stroke34);
        lineAndShapeRenderer2.setSeriesStroke(0, stroke34, false);
        boolean boolean40 = lineAndShapeRenderer2.getItemVisible((int) (short) 0, 8);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation41 = null;
        try {
            lineAndShapeRenderer2.addAnnotation(categoryAnnotation41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }
}

