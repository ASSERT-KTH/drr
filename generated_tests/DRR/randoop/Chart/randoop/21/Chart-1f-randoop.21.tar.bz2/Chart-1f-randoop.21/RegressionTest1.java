import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        categoryPlot15.addChangeListener(plotChangeListener16);
        categoryPlot15.setDomainCrosshairColumnKey((java.lang.Comparable) 5, false);
        categoryPlot15.mapDatasetToRangeAxis(0, 0);
        java.awt.Paint paint24 = categoryPlot15.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer26 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj27 = standardGradientPaintTransformer26.clone();
        boolean boolean28 = categoryAxis25.equals((java.lang.Object) standardGradientPaintTransformer26);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        double double37 = categoryAxis29.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D35, rectangleEdge36);
        int int38 = categoryAxis29.getCategoryLabelPositionOffset();
        java.awt.Font font40 = null;
        categoryAxis29.setTickLabelFont((java.lang.Comparable) 1, font40);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double43 = rectangleInsets42.getRight();
        categoryAxis29.setLabelInsets(rectangleInsets42, true);
        float float46 = categoryAxis29.getMaximumCategoryLabelWidthRatio();
        categoryAxis29.setFixedDimension((double) 1.0f);
        categoryAxis29.setCategoryMargin(1.0d);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = null;
        double double59 = categoryAxis51.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D57, rectangleEdge58);
        int int60 = categoryAxis51.getCategoryLabelPositionOffset();
        categoryAxis51.setMaximumCategoryLabelLines(4);
        categoryAxis51.setLowerMargin(0.0d);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray65 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis25, categoryAxis29, categoryAxis51 };
        categoryPlot15.setDomainAxes(categoryAxisArray65);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 4 + "'", int38 == 4);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + float46 + "' != '" + 0.0f + "'", float46 == 0.0f);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 4 + "'", int60 == 4);
        org.junit.Assert.assertNotNull(categoryAxisArray65);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint33 = renderAttributes31.getSeriesOutlinePaint((int) '4');
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes31.setDefaultStroke(stroke34);
        lineAndShapeRenderer2.setSeriesStroke(0, stroke34, false);
        java.awt.Shape shape38 = lineAndShapeRenderer2.getBaseLegendShape();
        lineAndShapeRenderer2.setSeriesShapesVisible(8, (java.lang.Boolean) false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNull(shape38);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.util.ObjectList objectList18 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        float float21 = categoryAxis20.getMinorTickMarkInsideLength();
        boolean boolean22 = categoryAxis20.isMinorTickMarksVisible();
        categoryAxis20.setLabelURL("hi!");
        objectList18.set((int) (short) 10, (java.lang.Object) categoryAxis20);
        org.jfree.chart.plot.Plot plot26 = null;
        categoryAxis20.setPlot(plot26);
        categoryAxis20.setCategoryMargin((double) (-1));
        categoryPlot15.setDomainAxis((int) '#', categoryAxis20);
        categoryPlot15.setDomainCrosshairRowKey((java.lang.Comparable) 5, true);
        java.awt.Paint paint34 = categoryPlot15.getRangeZeroBaselinePaint();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.OUTSIDE4" + "'", str1.equals("ItemLabelAnchor.OUTSIDE4"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        java.lang.Number number0 = null;
        org.jfree.data.SelectableValue selectableValue1 = new org.jfree.data.SelectableValue(number0);
        selectableValue1.setSelected(false);
        boolean boolean4 = selectableValue1.isSelected();
        selectableValue1.setSelected(false);
        java.lang.Number number7 = selectableValue1.getValue();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(number7);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMinorTickMarkInsideLength();
        double double2 = categoryAxis0.getFixedDimension();
        int int3 = categoryAxis0.getMaximumCategoryLabelLines();
        int int4 = categoryAxis0.getMaximumCategoryLabelLines();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.util.ObjectList objectList18 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        float float21 = categoryAxis20.getMinorTickMarkInsideLength();
        boolean boolean22 = categoryAxis20.isMinorTickMarksVisible();
        categoryAxis20.setLabelURL("hi!");
        objectList18.set((int) (short) 10, (java.lang.Object) categoryAxis20);
        org.jfree.chart.plot.Plot plot26 = null;
        categoryAxis20.setPlot(plot26);
        categoryAxis20.setCategoryMargin((double) (-1));
        categoryPlot15.setDomainAxis((int) '#', categoryAxis20);
        categoryPlot15.configureRangeAxes();
        org.jfree.chart.plot.Marker marker32 = null;
        boolean boolean33 = categoryPlot15.removeDomainMarker(marker32);
        org.jfree.chart.axis.AxisSpace axisSpace34 = categoryPlot15.getFixedRangeAxisSpace();
        int int35 = categoryPlot15.getDatasetCount();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(axisSpace34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.util.ObjectList objectList18 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        float float21 = categoryAxis20.getMinorTickMarkInsideLength();
        boolean boolean22 = categoryAxis20.isMinorTickMarksVisible();
        categoryAxis20.setLabelURL("hi!");
        objectList18.set((int) (short) 10, (java.lang.Object) categoryAxis20);
        org.jfree.chart.plot.Plot plot26 = null;
        categoryAxis20.setPlot(plot26);
        categoryAxis20.setCategoryMargin((double) (-1));
        categoryPlot15.setDomainAxis((int) '#', categoryAxis20);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = categoryAxis20.getLabelInsets();
        org.jfree.chart.util.UnitType unitType32 = rectangleInsets31.getUnitType();
        double double34 = rectangleInsets31.calculateRightOutset((double) (-1));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(unitType32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 3.0d + "'", double34 == 3.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor29 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor30 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor29, textAnchor30);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj34 = standardGradientPaintTransformer33.clone();
        boolean boolean35 = categoryAxis32.equals((java.lang.Object) standardGradientPaintTransformer33);
        boolean boolean36 = itemLabelPosition31.equals((java.lang.Object) boolean35);
        double double37 = itemLabelPosition31.getAngle();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor38 = itemLabelPosition31.getItemLabelAnchor();
        lineAndShapeRenderer2.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition31);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator41 = null;
        lineAndShapeRenderer2.setSeriesURLGenerator(1, categoryURLGenerator41);
        lineAndShapeRenderer2.setBaseSeriesVisibleInLegend(true, false);
        boolean boolean46 = lineAndShapeRenderer2.getUseFillPaint();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(itemLabelAnchor29);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor38);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        java.awt.Font font28 = lineAndShapeRenderer2.getBaseItemLabelFont();
        java.awt.Paint paint29 = lineAndShapeRenderer2.getBaseLegendTextPaint();
        java.awt.Font font30 = lineAndShapeRenderer2.getBaseLegendTextFont();
        lineAndShapeRenderer2.setSeriesLinesVisible(0, false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertNull(font30);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Shape shape4 = renderAttributes1.getItemShape((-16777216), 0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer8.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = null;
        lineAndShapeRenderer8.setBaseURLGenerator(categoryURLGenerator11, true);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator14 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        lineAndShapeRenderer8.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator14);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = lineAndShapeRenderer8.getLegendItemToolTipGenerator();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
        double double26 = categoryAxis18.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D24, rectangleEdge25);
        int int27 = categoryAxis18.getCategoryLabelPositionOffset();
        categoryAxis18.setMaximumCategoryLabelLines(4);
        categoryAxis18.setLowerMargin(0.0d);
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        double double39 = categoryAxis18.getCategorySeriesMiddle((int) (byte) 1, (int) ' ', (int) (byte) 10, 0, 3.0d, rectangle2D37, rectangleEdge38);
        java.awt.Font font40 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis18.setTickLabelFont(font40);
        lineAndShapeRenderer8.setSeriesItemLabelFont((int) (short) 0, font40, true);
        java.awt.Shape shape45 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity47 = new org.jfree.chart.entity.ChartEntity(shape45, "");
        java.awt.Shape shape48 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent49 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape48);
        chartEntity47.setArea(shape48);
        org.jfree.data.category.CategoryDataset categoryDataset51 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = null;
        double double60 = categoryAxis52.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D58, rectangleEdge59);
        int int61 = categoryAxis52.getCategoryLabelPositionOffset();
        categoryAxis52.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis64 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer65 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot66 = new org.jfree.chart.plot.CategoryPlot(categoryDataset51, categoryAxis52, valueAxis64, categoryItemRenderer65);
        org.jfree.chart.util.ObjectList objectList69 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis71 = new org.jfree.chart.axis.CategoryAxis();
        float float72 = categoryAxis71.getMinorTickMarkInsideLength();
        boolean boolean73 = categoryAxis71.isMinorTickMarksVisible();
        categoryAxis71.setLabelURL("hi!");
        objectList69.set((int) (short) 10, (java.lang.Object) categoryAxis71);
        org.jfree.chart.plot.Plot plot77 = null;
        categoryAxis71.setPlot(plot77);
        categoryAxis71.setCategoryMargin((double) (-1));
        categoryPlot66.setDomainAxis((int) '#', categoryAxis71);
        categoryPlot66.configureRangeAxes();
        org.jfree.chart.entity.PlotEntity plotEntity83 = new org.jfree.chart.entity.PlotEntity(shape48, (org.jfree.chart.plot.Plot) categoryPlot66);
        lineAndShapeRenderer8.setLegendShape(0, shape48);
        renderAttributes1.setSeriesShape(64, shape48);
        org.junit.Assert.assertNull(shape4);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator16);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 4 + "'", int61 == 4);
        org.junit.Assert.assertTrue("'" + float72 + "' != '" + 0.0f + "'", float72 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        categoryPlot15.addChangeListener(plotChangeListener16);
        org.jfree.data.general.DatasetGroup datasetGroup18 = categoryPlot15.getDatasetGroup();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNull(datasetGroup18);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            defaultCategoryDataset0.removeRow((java.lang.Comparable) 1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (1) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "");
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape7);
        chartEntity6.setArea(shape7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape7, (java.awt.Paint) color10);
        legendItem11.setURLText("{0}");
        java.awt.Paint paint14 = legendItem11.getOutlinePaint();
        java.awt.Paint paint15 = legendItem11.getLinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        boolean boolean17 = categoryAxis16.isAxisLineVisible();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int19 = color18.getBlue();
        float[] floatArray23 = new float[] { '#', (byte) 10, (short) 100 };
        float[] floatArray24 = color18.getColorComponents(floatArray23);
        categoryAxis16.setAxisLinePaint((java.awt.Paint) color18);
        boolean boolean26 = legendItem11.equals((java.lang.Object) color18);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Color color3 = java.awt.Color.blue;
        renderAttributes1.setSeriesFillPaint(0, (java.awt.Paint) color3);
        java.lang.Boolean boolean5 = renderAttributes1.getDefaultLabelVisible();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        renderAttributes1.setDefaultShape(shape6);
        java.lang.Boolean boolean8 = renderAttributes1.getDefaultCreateEntity();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(boolean8);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor29 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor30 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor29, textAnchor30);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj34 = standardGradientPaintTransformer33.clone();
        boolean boolean35 = categoryAxis32.equals((java.lang.Object) standardGradientPaintTransformer33);
        boolean boolean36 = itemLabelPosition31.equals((java.lang.Object) boolean35);
        double double37 = itemLabelPosition31.getAngle();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor38 = itemLabelPosition31.getItemLabelAnchor();
        lineAndShapeRenderer2.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition31);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator41 = null;
        lineAndShapeRenderer2.setSeriesURLGenerator(1, categoryURLGenerator41);
        lineAndShapeRenderer2.setBaseSeriesVisibleInLegend(true, false);
        lineAndShapeRenderer2.setBaseLinesVisible(true);
        java.awt.Paint paint51 = lineAndShapeRenderer2.getItemLabelPaint(5, (int) 'a', true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(itemLabelAnchor29);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor38);
        org.junit.Assert.assertNotNull(paint51);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        boolean boolean5 = lineAndShapeRenderer2.getBaseShapesFilled();
        java.lang.Boolean boolean7 = lineAndShapeRenderer2.getSeriesLinesVisible(100);
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = lineAndShapeRenderer2.getSelectedItemAttributes();
        java.awt.Color color9 = java.awt.Color.WHITE;
        lineAndShapeRenderer2.setBaseFillPaint((java.awt.Paint) color9);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = lineAndShapeRenderer2.getBaseToolTipGenerator();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(categoryToolTipGenerator11);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor29 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor30 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor29, textAnchor30);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj34 = standardGradientPaintTransformer33.clone();
        boolean boolean35 = categoryAxis32.equals((java.lang.Object) standardGradientPaintTransformer33);
        boolean boolean36 = itemLabelPosition31.equals((java.lang.Object) boolean35);
        double double37 = itemLabelPosition31.getAngle();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor38 = itemLabelPosition31.getItemLabelAnchor();
        lineAndShapeRenderer2.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition31);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator41 = null;
        lineAndShapeRenderer2.setSeriesURLGenerator(1, categoryURLGenerator41);
        java.awt.Paint paint44 = lineAndShapeRenderer2.getSeriesPaint((int) (byte) 1);
        boolean boolean46 = lineAndShapeRenderer2.isSeriesVisible((int) '4');
        org.jfree.data.KeyedObjects2D keyedObjects2D47 = new org.jfree.data.KeyedObjects2D();
        java.awt.Color color48 = java.awt.Color.BLACK;
        boolean boolean49 = keyedObjects2D47.equals((java.lang.Object) color48);
        lineAndShapeRenderer2.setBaseOutlinePaint((java.awt.Paint) color48);
        lineAndShapeRenderer2.setAutoPopulateSeriesOutlinePaint(false);
        lineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false, false);
        lineAndShapeRenderer2.setSeriesItemLabelsVisible(64, (java.lang.Boolean) false, true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(itemLabelAnchor29);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor38);
        org.junit.Assert.assertNull(paint44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj2 = standardGradientPaintTransformer1.clone();
        boolean boolean3 = categoryAxis0.equals((java.lang.Object) standardGradientPaintTransformer1);
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryAxis0.setAxisLineStroke(stroke4);
        java.lang.String str6 = categoryAxis0.getLabelURL();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        int int17 = categoryPlot15.getWeight();
        java.lang.Comparable comparable18 = null;
        categoryPlot15.setDomainCrosshairRowKey(comparable18, true);
        org.jfree.chart.axis.AxisSpace axisSpace21 = categoryPlot15.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot15.getRangeMarkers((-2), layer23);
        categoryPlot15.clearRangeMarkers();
        java.awt.Stroke stroke26 = categoryPlot15.getRangeMinorGridlineStroke();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(axisSpace21);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        int int17 = categoryPlot15.getWeight();
        java.lang.Comparable comparable18 = null;
        categoryPlot15.setDomainCrosshairRowKey(comparable18, true);
        categoryPlot15.clearAnnotations();
        java.awt.geom.GeneralPath generalPath22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.RenderingSource renderingSource24 = null;
        categoryPlot15.select(generalPath22, rectangle2D23, renderingSource24);
        java.awt.Stroke stroke26 = categoryPlot15.getOutlineStroke();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder27 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str28 = datasetRenderingOrder27.toString();
        categoryPlot15.setDatasetRenderingOrder(datasetRenderingOrder27);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(datasetRenderingOrder27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str28.equals("DatasetRenderingOrder.FORWARD"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor29 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor30 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor29, textAnchor30);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj34 = standardGradientPaintTransformer33.clone();
        boolean boolean35 = categoryAxis32.equals((java.lang.Object) standardGradientPaintTransformer33);
        boolean boolean36 = itemLabelPosition31.equals((java.lang.Object) boolean35);
        double double37 = itemLabelPosition31.getAngle();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor38 = itemLabelPosition31.getItemLabelAnchor();
        lineAndShapeRenderer2.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition31);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator41 = null;
        lineAndShapeRenderer2.setSeriesURLGenerator(1, categoryURLGenerator41);
        java.awt.Paint paint44 = lineAndShapeRenderer2.getSeriesPaint((int) (byte) 1);
        boolean boolean46 = lineAndShapeRenderer2.isSeriesVisible((int) '4');
        org.jfree.data.KeyedObjects2D keyedObjects2D47 = new org.jfree.data.KeyedObjects2D();
        java.awt.Color color48 = java.awt.Color.BLACK;
        boolean boolean49 = keyedObjects2D47.equals((java.lang.Object) color48);
        lineAndShapeRenderer2.setBaseOutlinePaint((java.awt.Paint) color48);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator52 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        java.lang.Object obj53 = standardCategorySeriesLabelGenerator52.clone();
        lineAndShapeRenderer2.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator52);
        lineAndShapeRenderer2.setSeriesVisible((int) (short) 1, (java.lang.Boolean) true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(itemLabelAnchor29);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor38);
        org.junit.Assert.assertNull(paint44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(obj53);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMinorTickMarkInsideLength();
        boolean boolean2 = categoryAxis0.isMinorTickMarksVisible();
        boolean boolean3 = categoryAxis0.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot4 = null;
        categoryAxis0.setPlot(plot4);
        categoryAxis0.setTickMarkOutsideLength((float) 8);
        float float8 = categoryAxis0.getMinorTickMarkInsideLength();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis2.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D8, rectangleEdge9);
        int int11 = categoryAxis2.getCategoryLabelPositionOffset();
        categoryAxis2.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis14, categoryItemRenderer15);
        java.awt.Paint paint17 = categoryPlot16.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = categoryPlot16.removeDomainMarker(marker18, layer19);
        boolean boolean21 = categoryPlot16.isRangeMinorGridlinesVisible();
        boolean boolean22 = abstractCategoryDataset0.hasListener((java.util.EventListener) categoryPlot16);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot16.getDomainMarkers(layer23);
        boolean boolean25 = categoryPlot16.isDomainPannable();
        categoryPlot16.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryPlot16.getAxisOffset();
        double double30 = rectangleInsets28.calculateRightOutset((double) (-32513));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 4.0d + "'", double30 == 4.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Color color3 = java.awt.Color.blue;
        renderAttributes1.setSeriesFillPaint(0, (java.awt.Paint) color3);
        java.awt.Shape shape5 = renderAttributes1.getDefaultShape();
        java.awt.Paint paint8 = renderAttributes1.getItemFillPaint(10, 0);
        java.awt.Stroke stroke10 = renderAttributes1.getSeriesStroke((-16777216));
        java.awt.Paint paint12 = renderAttributes1.getSeriesPaint((int) (short) 10);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(stroke10);
        org.junit.Assert.assertNull(paint12);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        java.awt.Shape shape29 = lineAndShapeRenderer2.getBaseLegendShape();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator30 = null;
        lineAndShapeRenderer2.setBaseItemLabelGenerator(categoryItemLabelGenerator30);
        boolean boolean32 = lineAndShapeRenderer2.getUseSeriesOffset();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(shape29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font11 = null;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 1, font11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double14 = rectangleInsets13.getRight();
        categoryAxis0.setLabelInsets(rectangleInsets13, true);
        double double18 = rectangleInsets13.extendHeight((double) ' ');
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 32.0d + "'", double18 == 32.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        java.awt.Shape shape29 = lineAndShapeRenderer2.getBaseLegendShape();
        java.awt.Shape shape33 = lineAndShapeRenderer2.getItemShape((int) (byte) 100, (-14336), true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        lineAndShapeRenderer2.notifyListeners(rendererChangeEvent34);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(shape29);
        org.junit.Assert.assertNotNull(shape33);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.calculateTopOutset((double) (-12566464));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer2 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj3 = standardGradientPaintTransformer2.clone();
        boolean boolean4 = categoryAxis1.equals((java.lang.Object) standardGradientPaintTransformer2);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset9 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener10 = null;
        boolean boolean11 = abstractCategoryDataset9.hasListener(eventListener10);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener12 = null;
        abstractCategoryDataset9.removeChangeListener(datasetChangeListener12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = categoryAxis15.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D21, rectangleEdge22);
        int int24 = categoryAxis15.getCategoryLabelPositionOffset();
        categoryAxis15.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis27, categoryItemRenderer28);
        java.awt.Paint paint30 = categoryPlot29.getRangeCrosshairPaint();
        int int31 = categoryPlot29.getWeight();
        abstractCategoryDataset9.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot29);
        lineAndShapeRenderer8.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot29);
        boolean boolean34 = lineAndShapeRenderer8.getBaseShapesFilled();
        org.jfree.chart.renderer.RenderAttributes renderAttributes37 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint39 = renderAttributes37.getSeriesOutlinePaint((int) '4');
        java.awt.Stroke stroke40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes37.setDefaultStroke(stroke40);
        lineAndShapeRenderer8.setSeriesStroke(0, stroke40, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation44 = null;
        boolean boolean45 = lineAndShapeRenderer8.removeAnnotation(categoryAnnotation44);
        java.awt.Paint paint47 = null;
        lineAndShapeRenderer8.setSeriesItemLabelPaint((int) (short) 100, paint47, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer8);
        categoryAxis1.setTickLabelsVisible(true);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        java.lang.String str1 = gradientPaintTransformType0.toString();
        java.lang.Object obj2 = null;
        boolean boolean3 = gradientPaintTransformType0.equals(obj2);
        java.lang.String str4 = gradientPaintTransformType0.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GradientPaintTransformType.CENTER_HORIZONTAL" + "'", str1.equals("GradientPaintTransformType.CENTER_HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "GradientPaintTransformType.CENTER_HORIZONTAL" + "'", str4.equals("GradientPaintTransformType.CENTER_HORIZONTAL"));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        java.lang.String str3 = chartEntity2.getShapeType();
        java.lang.String str4 = chartEntity2.getURLText();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "poly" + "'", str3.equals("poly"));
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.setMaximumCategoryLabelLines(4);
        categoryAxis0.setLowerMargin(0.0d);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis0.getCategorySeriesMiddle((int) (byte) 1, (int) ' ', (int) (byte) 10, 0, 3.0d, rectangle2D19, rectangleEdge20);
        java.awt.Font font22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis0.setTickLabelFont(font22);
        categoryAxis0.setMaximumCategoryLabelLines(8);
        java.awt.Font font27 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) "DatasetRenderingOrder.FORWARD", font27);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(font27);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint33 = renderAttributes31.getSeriesOutlinePaint((int) '4');
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes31.setDefaultStroke(stroke34);
        lineAndShapeRenderer2.setSeriesStroke(0, stroke34, false);
        boolean boolean39 = lineAndShapeRenderer2.isSeriesItemLabelsVisible(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator40 = lineAndShapeRenderer2.getLegendItemURLGenerator();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator40);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj2 = standardGradientPaintTransformer1.clone();
        boolean boolean3 = categoryAxis0.equals((java.lang.Object) standardGradientPaintTransformer1);
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryAxis0.setAxisLineStroke(stroke4);
        categoryAxis0.setLowerMargin((double) 0L);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getRowKeys();
        try {
            defaultCategoryDataset0.setSelected(128, (int) (short) 100, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 128, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 0L, 0.05d, 3.0d, (double) 1L);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        boolean boolean5 = lineAndShapeRenderer2.getBaseShapesFilled();
        java.lang.Boolean boolean7 = lineAndShapeRenderer2.getSeriesLinesVisible(100);
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = lineAndShapeRenderer2.getSelectedItemAttributes();
        java.awt.Color color9 = java.awt.Color.WHITE;
        lineAndShapeRenderer2.setBaseFillPaint((java.awt.Paint) color9);
        java.awt.color.ColorSpace colorSpace11 = null;
        java.awt.Color color15 = java.awt.Color.YELLOW;
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int17 = color16.getBlue();
        float[] floatArray21 = new float[] { '#', (byte) 10, (short) 100 };
        float[] floatArray22 = color16.getColorComponents(floatArray21);
        float[] floatArray23 = color15.getColorComponents(floatArray21);
        float[] floatArray24 = java.awt.Color.RGBtoHSB(64, (int) '#', (int) (short) 1, floatArray23);
        try {
            float[] floatArray25 = color9.getComponents(colorSpace11, floatArray24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        java.lang.String str1 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryAnchor.END" + "'", str1.equals("CategoryAnchor.END"));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextFillPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        java.awt.Stroke stroke3 = defaultDrawingSupplier0.getNextOutlineStroke();
        java.lang.Object obj4 = defaultDrawingSupplier0.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint1 = null;
        try {
            renderAttributes0.setDefaultPaint(paint1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        double double16 = categoryPlot15.getAnchorValue();
        float float17 = categoryPlot15.getBackgroundImageAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot15.getDomainAxisLocation();
        org.jfree.chart.plot.Marker marker19 = null;
        org.jfree.chart.util.Layer layer20 = null;
        boolean boolean21 = categoryPlot15.removeDomainMarker(marker19, layer20);
        java.awt.Stroke stroke22 = categoryPlot15.getRangeGridlineStroke();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj2 = standardGradientPaintTransformer1.clone();
        boolean boolean3 = categoryAxis0.equals((java.lang.Object) standardGradientPaintTransformer1);
        categoryAxis0.setLabelToolTip("CategoryAnchor.START");
        categoryAxis0.configure();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int9 = color8.getAlpha();
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator13 = new org.jfree.chart.util.DefaultShadowGenerator((int) (short) 0, color8, (-1.0f), 10, (double) (short) 1);
        java.awt.Color color14 = defaultShadowGenerator13.getShadowColor();
        categoryAxis0.setTickMarkPaint((java.awt.Paint) color14);
        float float16 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.0f + "'", float16 == 0.0f);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        java.awt.Font font28 = lineAndShapeRenderer2.getBaseItemLabelFont();
        boolean boolean29 = lineAndShapeRenderer2.getBaseCreateEntities();
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = null;
        double double40 = categoryAxis32.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D38, rectangleEdge39);
        int int41 = categoryAxis32.getCategoryLabelPositionOffset();
        categoryAxis32.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, valueAxis44, categoryItemRenderer45);
        java.awt.Paint paint47 = categoryPlot46.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor48 = categoryPlot46.getDomainGridlinePosition();
        java.awt.Paint paint49 = categoryPlot46.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset50 = null;
        categoryPlot46.setDataset(categoryDataset50);
        org.jfree.chart.LegendItemCollection legendItemCollection52 = categoryPlot46.getLegendItems();
        boolean boolean53 = categoryPlot46.canSelectByPoint();
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        java.awt.Color color57 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int58 = color57.getAlpha();
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator62 = new org.jfree.chart.util.DefaultShadowGenerator((int) (short) 0, color57, (-1.0f), 10, (double) (short) 1);
        java.awt.Color color63 = defaultShadowGenerator62.getShadowColor();
        java.awt.Shape shape68 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity70 = new org.jfree.chart.entity.ChartEntity(shape68, "");
        java.awt.Shape shape71 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent72 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape71);
        chartEntity70.setArea(shape71);
        java.awt.Color color74 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem75 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape71, (java.awt.Paint) color74);
        legendItem75.setURLText("");
        java.lang.String str78 = legendItem75.getToolTipText();
        legendItem75.setURLText("org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]");
        java.awt.Stroke stroke81 = legendItem75.getOutlineStroke();
        try {
            lineAndShapeRenderer2.drawDomainLine(graphics2D30, categoryPlot46, rectangle2D54, (double) 4, (java.awt.Paint) color63, stroke81);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 4 + "'", int41 == 4);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(categoryAnchor48);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(legendItemCollection52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 255 + "'", int58 == 255);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(shape68);
        org.junit.Assert.assertNotNull(shape71);
        org.junit.Assert.assertNotNull(color74);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]" + "'", str78.equals("org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]"));
        org.junit.Assert.assertNotNull(stroke81);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMinorTickMarkInsideLength();
        double double2 = categoryAxis0.getFixedDimension();
        java.awt.Paint paint3 = categoryAxis0.getTickLabelPaint();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = categoryAxis5.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D11, rectangleEdge12);
        int int14 = categoryAxis5.getCategoryLabelPositionOffset();
        categoryAxis5.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis17, categoryItemRenderer18);
        java.awt.Paint paint20 = categoryPlot19.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker21 = null;
        org.jfree.chart.util.Layer layer22 = null;
        boolean boolean23 = categoryPlot19.removeDomainMarker(marker21, layer22);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot19);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateTopInset((double) 10);
        double double4 = rectangleInsets0.calculateRightOutset(100.0d);
        double double6 = rectangleInsets0.calculateBottomInset((double) (-1L));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        int int1 = color0.getRGB();
        java.awt.Color color2 = java.awt.Color.DARK_GRAY;
        java.awt.color.ColorSpace colorSpace3 = color2.getColorSpace();
        java.awt.Color color4 = java.awt.Color.YELLOW;
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int6 = color5.getBlue();
        float[] floatArray10 = new float[] { '#', (byte) 10, (short) 100 };
        float[] floatArray11 = color5.getColorComponents(floatArray10);
        float[] floatArray12 = color4.getColorComponents(floatArray10);
        try {
            float[] floatArray13 = color0.getComponents(colorSpace3, floatArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-8323073) + "'", int1 == (-8323073));
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor29 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor30 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor29, textAnchor30);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj34 = standardGradientPaintTransformer33.clone();
        boolean boolean35 = categoryAxis32.equals((java.lang.Object) standardGradientPaintTransformer33);
        boolean boolean36 = itemLabelPosition31.equals((java.lang.Object) boolean35);
        double double37 = itemLabelPosition31.getAngle();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor38 = itemLabelPosition31.getItemLabelAnchor();
        lineAndShapeRenderer2.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition31);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator41 = null;
        lineAndShapeRenderer2.setSeriesURLGenerator(1, categoryURLGenerator41);
        java.awt.Paint paint44 = lineAndShapeRenderer2.getSeriesPaint((int) (byte) 1);
        boolean boolean46 = lineAndShapeRenderer2.isSeriesVisible((int) '4');
        lineAndShapeRenderer2.setBaseSeriesVisible(true);
        lineAndShapeRenderer2.setSeriesShapesFilled((int) (short) 100, false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(itemLabelAnchor29);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor38);
        org.junit.Assert.assertNull(paint44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.SelectableValue selectableValue1 = new org.jfree.data.SelectableValue((java.lang.Number) (short) 10);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMinorTickMarkInsideLength();
        boolean boolean2 = categoryAxis0.isMinorTickMarksVisible();
        boolean boolean3 = categoryAxis0.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot4 = null;
        categoryAxis0.setPlot(plot4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double8 = rectangleInsets6.calculateTopInset((double) 10);
        categoryAxis0.setLabelInsets(rectangleInsets6);
        java.awt.Stroke stroke10 = categoryAxis0.getAxisLineStroke();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator5, true);
        lineAndShapeRenderer2.setUseSeriesOffset(true);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset10 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = categoryAxis12.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D18, rectangleEdge19);
        int int21 = categoryAxis12.getCategoryLabelPositionOffset();
        categoryAxis12.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis24, categoryItemRenderer25);
        java.awt.Paint paint27 = categoryPlot26.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker28 = null;
        org.jfree.chart.util.Layer layer29 = null;
        boolean boolean30 = categoryPlot26.removeDomainMarker(marker28, layer29);
        boolean boolean31 = categoryPlot26.isRangeMinorGridlinesVisible();
        boolean boolean32 = abstractCategoryDataset10.hasListener((java.util.EventListener) categoryPlot26);
        org.jfree.chart.util.Layer layer33 = null;
        java.util.Collection collection34 = categoryPlot26.getDomainMarkers(layer33);
        boolean boolean35 = categoryPlot26.isDomainPannable();
        categoryPlot26.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = categoryPlot26.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder39 = categoryPlot26.getDatasetRenderingOrder();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer43 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer43.setBaseItemLabelsVisible(false);
        boolean boolean46 = lineAndShapeRenderer43.getBaseShapesFilled();
        categoryPlot26.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer43);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator48 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        java.lang.Object obj49 = standardCategorySeriesLabelGenerator48.clone();
        lineAndShapeRenderer43.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator48);
        lineAndShapeRenderer2.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator48);
        boolean boolean52 = lineAndShapeRenderer2.getDrawOutlines();
        try {
            lineAndShapeRenderer2.setSeriesShapesFilled((-8323073), true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertNotNull(datasetRenderingOrder39);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(obj49);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.util.ObjectList objectList18 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        float float21 = categoryAxis20.getMinorTickMarkInsideLength();
        boolean boolean22 = categoryAxis20.isMinorTickMarksVisible();
        categoryAxis20.setLabelURL("hi!");
        objectList18.set((int) (short) 10, (java.lang.Object) categoryAxis20);
        org.jfree.chart.plot.Plot plot26 = null;
        categoryAxis20.setPlot(plot26);
        categoryAxis20.setCategoryMargin((double) (-1));
        categoryPlot15.setDomainAxis((int) '#', categoryAxis20);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = categoryAxis20.getLabelInsets();
        categoryAxis20.setLabelAngle((double) (-1));
        java.awt.Paint paint34 = categoryAxis20.getAxisLinePaint();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        double double16 = categoryPlot15.getAnchorValue();
        float float17 = categoryPlot15.getBackgroundImageAlpha();
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        try {
            categoryPlot15.addDomainMarker(categoryMarker18, layer19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D0.clear();
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "");
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape7);
        chartEntity6.setArea(shape7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape7, (java.awt.Paint) color10);
        legendItem11.setURLText("{0}");
        java.awt.Paint paint14 = legendItem11.getOutlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = categoryAxis15.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D21, rectangleEdge22);
        int int24 = categoryAxis15.getCategoryLabelPositionOffset();
        categoryAxis15.setMaximumCategoryLabelLines(4);
        categoryAxis15.setLowerMargin(0.0d);
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = null;
        double double36 = categoryAxis15.getCategorySeriesMiddle((int) (byte) 1, (int) ' ', (int) (byte) 10, 0, 3.0d, rectangle2D34, rectangleEdge35);
        java.awt.Font font37 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis15.setTickLabelFont(font37);
        legendItem11.setLabelFont(font37);
        boolean boolean40 = legendItem11.isShapeOutlineVisible();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer43 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer43.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator46 = null;
        lineAndShapeRenderer43.setBaseURLGenerator(categoryURLGenerator46, true);
        java.awt.Font font50 = lineAndShapeRenderer43.lookupLegendTextFont((int) (byte) 0);
        java.awt.Color color51 = java.awt.Color.red;
        lineAndShapeRenderer43.setBaseItemLabelPaint((java.awt.Paint) color51);
        lineAndShapeRenderer43.setUseOutlinePaint(true);
        java.awt.Font font55 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        lineAndShapeRenderer43.setBaseLegendTextFont(font55);
        legendItem11.setLabelFont(font55);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
        org.junit.Assert.assertEquals((double) double36, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(font50);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(font55);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Color color3 = java.awt.Color.blue;
        renderAttributes1.setSeriesFillPaint(0, (java.awt.Paint) color3);
        java.awt.Font font5 = renderAttributes1.getDefaultLabelFont();
        java.awt.Stroke stroke8 = renderAttributes1.getItemStroke(4, (int) (short) 100);
        java.awt.Color color9 = java.awt.Color.GREEN;
        renderAttributes1.setDefaultPaint((java.awt.Paint) color9);
        java.awt.Paint paint12 = renderAttributes1.getSeriesOutlinePaint((-255));
        renderAttributes1.setDefaultCreateEntity((java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(font5);
        org.junit.Assert.assertNull(stroke8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(paint12);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMinorTickMarkInsideLength();
        boolean boolean2 = categoryAxis0.isMinorTickMarksVisible();
        categoryAxis0.setLabelURL("hi!");
        categoryAxis0.setUpperMargin(0.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double9 = rectangleInsets7.calculateBottomInset((double) 1.0f);
        double double11 = rectangleInsets7.calculateRightOutset((double) (byte) 10);
        double double13 = rectangleInsets7.extendHeight(0.0d);
        categoryAxis0.setLabelInsets(rectangleInsets7, false);
        double double17 = rectangleInsets7.trimHeight((double) (-32513));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-32513.0d) + "'", double17 == (-32513.0d));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = lineAndShapeRenderer2.getSeriesPositiveItemLabelPosition((int) 'a');
        lineAndShapeRenderer2.setDefaultEntityRadius(4);
        java.awt.Font font33 = lineAndShapeRenderer2.getLegendTextFont((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(itemLabelPosition29);
        org.junit.Assert.assertNull(font33);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        categoryPlot15.addChangeListener(plotChangeListener16);
        boolean boolean18 = categoryPlot15.isRangeZoomable();
        org.jfree.chart.axis.AxisSpace axisSpace19 = categoryPlot15.getFixedDomainAxisSpace();
        categoryPlot15.setNotify(false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset22 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
        double double32 = categoryAxis24.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D30, rectangleEdge31);
        int int33 = categoryAxis24.getCategoryLabelPositionOffset();
        categoryAxis24.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis36, categoryItemRenderer37);
        java.awt.Paint paint39 = categoryPlot38.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker40 = null;
        org.jfree.chart.util.Layer layer41 = null;
        boolean boolean42 = categoryPlot38.removeDomainMarker(marker40, layer41);
        boolean boolean43 = categoryPlot38.isRangeMinorGridlinesVisible();
        boolean boolean44 = abstractCategoryDataset22.hasListener((java.util.EventListener) categoryPlot38);
        org.jfree.chart.axis.AxisLocation axisLocation46 = categoryPlot38.getDomainAxisLocation(4);
        categoryPlot15.setDomainAxisLocation(axisLocation46, true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(axisSpace19);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(axisLocation46);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint7 = renderAttributes5.getSeriesOutlinePaint((int) '4');
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        renderAttributes5.setDefaultOutlinePaint(paint8);
        lineAndShapeRenderer2.setSeriesFillPaint((int) (byte) 0, paint8);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset14 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener15 = null;
        boolean boolean16 = abstractCategoryDataset14.hasListener(eventListener15);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener17 = null;
        abstractCategoryDataset14.removeChangeListener(datasetChangeListener17);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = categoryAxis20.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D26, rectangleEdge27);
        int int29 = categoryAxis20.getCategoryLabelPositionOffset();
        categoryAxis20.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis32, categoryItemRenderer33);
        java.awt.Paint paint35 = categoryPlot34.getRangeCrosshairPaint();
        int int36 = categoryPlot34.getWeight();
        abstractCategoryDataset14.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot34);
        lineAndShapeRenderer13.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot34);
        boolean boolean39 = lineAndShapeRenderer13.getAutoPopulateSeriesOutlineStroke();
        java.awt.Paint paint43 = lineAndShapeRenderer13.getItemOutlinePaint(4, (int) (byte) -1, false);
        lineAndShapeRenderer2.setBaseOutlinePaint(paint43);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(paint43);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        float float4 = categoryAxis3.getMinorTickMarkInsideLength();
        boolean boolean5 = categoryAxis3.isMinorTickMarksVisible();
        categoryAxis3.setLabelURL("hi!");
        objectList1.set((int) (short) 10, (java.lang.Object) categoryAxis3);
        org.jfree.chart.plot.Plot plot9 = null;
        categoryAxis3.setPlot(plot9);
        categoryAxis3.setLabel("ItemLabelAnchor.INSIDE6");
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        java.awt.Color color1 = java.awt.Color.blue;
        java.awt.Color color2 = java.awt.Color.getColor("", color1);
        int int3 = color2.getRGB();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16776961) + "'", int3 == (-16776961));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMinorTickMarkInsideLength();
        boolean boolean2 = categoryAxis0.isMinorTickMarksVisible();
        boolean boolean3 = categoryAxis0.isTickLabelsVisible();
        java.awt.Paint paint4 = categoryAxis0.getTickMarkPaint();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = categoryAxis6.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D12, rectangleEdge13);
        int int15 = categoryAxis6.getCategoryLabelPositionOffset();
        categoryAxis6.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot20.addChangeListener(plotChangeListener21);
        categoryPlot20.setDomainCrosshairColumnKey((java.lang.Comparable) 5, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        int int27 = categoryPlot20.getIndexOf(categoryItemRenderer26);
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot20);
        boolean boolean29 = categoryPlot20.isDomainGridlinesVisible();
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot20.getRowRenderingOrder();
        org.jfree.chart.util.ObjectList objectList32 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
        int int33 = objectList32.size();
        boolean boolean34 = sortOrder30.equals((java.lang.Object) objectList32);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint33 = renderAttributes31.getSeriesOutlinePaint((int) '4');
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes31.setDefaultStroke(stroke34);
        lineAndShapeRenderer2.setSeriesStroke(0, stroke34, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation38 = null;
        boolean boolean39 = lineAndShapeRenderer2.removeAnnotation(categoryAnnotation38);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (byte) 10, false);
        int int43 = lineAndShapeRenderer2.getDefaultEntityRadius();
        int int44 = lineAndShapeRenderer2.getDefaultEntityRadius();
        lineAndShapeRenderer2.setSeriesCreateEntities(0, (java.lang.Boolean) true);
        lineAndShapeRenderer2.setAutoPopulateSeriesOutlineStroke(true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 3 + "'", int43 == 3);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 3 + "'", int44 == 3);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setUseFillPaint(false);
        java.awt.Stroke stroke6 = lineAndShapeRenderer2.lookupSeriesStroke((int) (byte) -1);
        java.awt.Paint paint8 = lineAndShapeRenderer2.getLegendTextPaint((int) ' ');
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        try {
            java.util.ResourceBundle resourceBundle1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name , locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint33 = renderAttributes31.getSeriesOutlinePaint((int) '4');
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes31.setDefaultStroke(stroke34);
        lineAndShapeRenderer2.setSeriesStroke(0, stroke34, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation38 = null;
        boolean boolean39 = lineAndShapeRenderer2.removeAnnotation(categoryAnnotation38);
        lineAndShapeRenderer2.setSeriesShapesVisible(0, true);
        java.awt.Stroke stroke46 = lineAndShapeRenderer2.getItemStroke((int) (short) -1, 10, false);
        int int47 = lineAndShapeRenderer2.getPassCount();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2 + "'", int47 == 2);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(0.2d, (double) (byte) 0, (double) 255, (double) (-14336));
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset8 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener9 = null;
        boolean boolean10 = abstractCategoryDataset8.hasListener(eventListener9);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener11 = null;
        abstractCategoryDataset8.removeChangeListener(datasetChangeListener11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = categoryAxis14.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D20, rectangleEdge21);
        int int23 = categoryAxis14.getCategoryLabelPositionOffset();
        categoryAxis14.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis26, categoryItemRenderer27);
        java.awt.Paint paint29 = categoryPlot28.getRangeCrosshairPaint();
        int int30 = categoryPlot28.getWeight();
        abstractCategoryDataset8.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot28);
        lineAndShapeRenderer7.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot28);
        java.awt.Font font33 = lineAndShapeRenderer7.getBaseItemLabelFont();
        boolean boolean34 = lineAndShapeRenderer7.getBaseShapesVisible();
        boolean boolean35 = rectangleInsets4.equals((java.lang.Object) lineAndShapeRenderer7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 4 + "'", int23 == 4);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextStroke();
        java.lang.Object obj2 = defaultDrawingSupplier0.clone();
        java.awt.Paint paint3 = defaultDrawingSupplier0.getNextFillPaint();
        java.awt.Paint paint4 = defaultDrawingSupplier0.getNextOutlinePaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        java.awt.Paint paint18 = categoryPlot15.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        categoryPlot15.setDataset(categoryDataset19);
        org.jfree.chart.LegendItemCollection legendItemCollection21 = categoryPlot15.getLegendItems();
        categoryPlot15.setCrosshairDatasetIndex(0);
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot15.setDomainAxisLocation(axisLocation24, true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(legendItemCollection21);
        org.junit.Assert.assertNotNull(axisLocation24);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator5, true);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator8 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        lineAndShapeRenderer2.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator8);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = lineAndShapeRenderer2.getLegendItemToolTipGenerator();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = categoryAxis12.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D18, rectangleEdge19);
        int int21 = categoryAxis12.getCategoryLabelPositionOffset();
        categoryAxis12.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis24, categoryItemRenderer25);
        java.awt.Paint paint27 = categoryPlot26.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor28 = categoryPlot26.getDomainGridlinePosition();
        org.jfree.data.KeyedObjects2D keyedObjects2D29 = new org.jfree.data.KeyedObjects2D();
        java.awt.Color color30 = java.awt.Color.BLACK;
        boolean boolean31 = keyedObjects2D29.equals((java.lang.Object) color30);
        int int32 = color30.getTransparency();
        categoryPlot26.setRangeGridlinePaint((java.awt.Paint) color30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        categoryPlot26.zoomRangeAxes((double) 0L, plotRenderingInfo35, point2D36, true);
        lineAndShapeRenderer2.setPlot(categoryPlot26);
        org.jfree.chart.util.Layer layer40 = null;
        java.util.Collection collection41 = categoryPlot26.getRangeMarkers(layer40);
        categoryPlot26.setDrawSharedDomainAxis(false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = categoryPlot26.getRenderer((int) ' ');
        java.awt.Graphics2D graphics2D46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        categoryPlot26.drawBackgroundImage(graphics2D46, rectangle2D47);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator10);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(categoryAnchor28);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNull(collection41);
        org.junit.Assert.assertNull(categoryItemRenderer45);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        java.awt.Paint paint18 = categoryPlot15.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        categoryPlot15.setDataset(categoryDataset19);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot15.getRangeAxisEdge();
        boolean boolean22 = categoryPlot15.isRangeGridlinesVisible();
        org.jfree.chart.renderer.RenderAttributes renderAttributes24 = new org.jfree.chart.renderer.RenderAttributes(false);
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        double double34 = categoryAxis26.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D32, rectangleEdge33);
        int int35 = categoryAxis26.getCategoryLabelPositionOffset();
        categoryAxis26.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, valueAxis38, categoryItemRenderer39);
        java.awt.Paint paint41 = categoryPlot40.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor42 = categoryPlot40.getDomainGridlinePosition();
        java.awt.Paint paint43 = categoryPlot40.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset44 = null;
        categoryPlot40.setDataset(categoryDataset44);
        org.jfree.chart.LegendItemCollection legendItemCollection46 = categoryPlot40.getLegendItems();
        java.awt.Stroke stroke47 = categoryPlot40.getRangeGridlineStroke();
        renderAttributes24.setDefaultStroke(stroke47);
        categoryPlot15.setRangeCrosshairStroke(stroke47);
        categoryPlot15.clearSelection();
        java.awt.Paint paint51 = categoryPlot15.getDomainGridlinePaint();
        org.jfree.chart.util.SortOrder sortOrder52 = categoryPlot15.getRowRenderingOrder();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(categoryAnchor42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(legendItemCollection46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNotNull(sortOrder52);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        java.awt.Paint paint18 = categoryPlot15.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        categoryPlot15.setDataset(categoryDataset19);
        org.jfree.chart.LegendItemCollection legendItemCollection21 = categoryPlot15.getLegendItems();
        java.awt.Stroke stroke22 = categoryPlot15.getRangeGridlineStroke();
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int24 = color23.getAlpha();
        categoryPlot15.setOutlinePaint((java.awt.Paint) color23);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset27 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list28 = defaultCategoryDataset27.getRowKeys();
        try {
            categoryPlot15.mapDatasetToDomainAxes(2, list28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(legendItemCollection21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 255 + "'", int24 == 255);
        org.junit.Assert.assertNotNull(list28);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.setMaximumCategoryLabelLines(4);
        categoryAxis0.setMaximumCategoryLabelWidthRatio(1.0f);
        categoryAxis0.setMaximumCategoryLabelLines((int) (byte) 10);
        boolean boolean16 = categoryAxis0.isTickLabelsVisible();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateTopInset((double) 10);
        double double4 = rectangleInsets0.calculateRightOutset(100.0d);
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.renderer.RenderAttributes renderAttributes7 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint9 = renderAttributes7.getSeriesOutlinePaint((int) '4');
        java.awt.Paint paint10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        renderAttributes7.setDefaultOutlinePaint(paint10);
        boolean boolean12 = textAnchor5.equals((java.lang.Object) renderAttributes7);
        boolean boolean13 = rectangleInsets0.equals((java.lang.Object) renderAttributes7);
        java.awt.Paint paint15 = renderAttributes7.getSeriesOutlinePaint(5);
        java.awt.Color color16 = java.awt.Color.black;
        renderAttributes7.setDefaultFillPaint((java.awt.Paint) color16);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = keyedObjects2D0.clone();
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset2 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener3 = null;
        boolean boolean4 = abstractCategoryDataset2.hasListener(eventListener3);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener5 = null;
        abstractCategoryDataset2.removeChangeListener(datasetChangeListener5);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = categoryAxis8.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D14, rectangleEdge15);
        int int17 = categoryAxis8.getCategoryLabelPositionOffset();
        categoryAxis8.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis20, categoryItemRenderer21);
        java.awt.Paint paint23 = categoryPlot22.getRangeCrosshairPaint();
        int int24 = categoryPlot22.getWeight();
        abstractCategoryDataset2.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot22);
        categoryPlot22.clearSelection();
        boolean boolean27 = keyedObjects2D0.equals((java.lang.Object) categoryPlot22);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator5, true);
        java.awt.Font font9 = lineAndShapeRenderer2.lookupLegendTextFont((int) (byte) 0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer12.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = null;
        lineAndShapeRenderer12.setBaseURLGenerator(categoryURLGenerator15, true);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator18 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        lineAndShapeRenderer12.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator18);
        lineAndShapeRenderer2.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator18);
        boolean boolean21 = lineAndShapeRenderer2.getAutoPopulateSeriesPaint();
        org.junit.Assert.assertNull(font9);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = keyedObjects2D0.clone();
        int int3 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 'a');
        int int4 = keyedObjects2D0.getRowCount();
        keyedObjects2D0.clear();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getRight();
        double double3 = rectangleInsets0.extendHeight(0.05d);
        double double5 = rectangleInsets0.calculateTopInset((double) 10L);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets0.createOutsetRectangle(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis2.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D8, rectangleEdge9);
        int int11 = categoryAxis2.getCategoryLabelPositionOffset();
        categoryAxis2.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis14, categoryItemRenderer15);
        java.awt.Paint paint17 = categoryPlot16.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor18 = categoryPlot16.getDomainGridlinePosition();
        org.jfree.data.KeyedObjects2D keyedObjects2D19 = new org.jfree.data.KeyedObjects2D();
        java.awt.Color color20 = java.awt.Color.BLACK;
        boolean boolean21 = keyedObjects2D19.equals((java.lang.Object) color20);
        int int22 = color20.getTransparency();
        categoryPlot16.setRangeGridlinePaint((java.awt.Paint) color20);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator27 = new org.jfree.chart.util.DefaultShadowGenerator((-16777216), color20, 0.0f, (-16776961), 4.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(categoryAnchor18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator5, true);
        java.lang.Boolean boolean9 = lineAndShapeRenderer2.getSeriesVisible((int) (short) 100);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator10 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        lineAndShapeRenderer2.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator10);
        boolean boolean14 = lineAndShapeRenderer2.getItemShapeVisible((int) 'a', 10);
        boolean boolean18 = lineAndShapeRenderer2.isItemLabelVisible((-14336), 0, true);
        lineAndShapeRenderer2.setSeriesShapesVisible(0, (java.lang.Boolean) true);
        java.awt.Color color23 = java.awt.Color.RED;
        lineAndShapeRenderer2.setSeriesItemLabelPaint((int) (byte) 0, (java.awt.Paint) color23, false);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(color23);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor29 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor30 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor29, textAnchor30);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj34 = standardGradientPaintTransformer33.clone();
        boolean boolean35 = categoryAxis32.equals((java.lang.Object) standardGradientPaintTransformer33);
        boolean boolean36 = itemLabelPosition31.equals((java.lang.Object) boolean35);
        double double37 = itemLabelPosition31.getAngle();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor38 = itemLabelPosition31.getItemLabelAnchor();
        lineAndShapeRenderer2.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition31);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator41 = null;
        lineAndShapeRenderer2.setSeriesURLGenerator(1, categoryURLGenerator41);
        lineAndShapeRenderer2.setBaseSeriesVisibleInLegend(true, false);
        java.awt.Paint paint46 = lineAndShapeRenderer2.getBaseOutlinePaint();
        java.awt.Paint paint48 = lineAndShapeRenderer2.getSeriesFillPaint((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(itemLabelAnchor29);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor38);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNull(paint48);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj2 = standardGradientPaintTransformer1.clone();
        boolean boolean3 = categoryAxis0.equals((java.lang.Object) standardGradientPaintTransformer1);
        boolean boolean4 = categoryAxis0.isMinorTickMarksVisible();
        java.awt.Paint paint5 = categoryAxis0.getTickLabelPaint();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator5, true);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator8 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        lineAndShapeRenderer2.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator8);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = lineAndShapeRenderer2.getLegendItemToolTipGenerator();
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset11 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis13.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D19, rectangleEdge20);
        int int22 = categoryAxis13.getCategoryLabelPositionOffset();
        categoryAxis13.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis25, categoryItemRenderer26);
        java.awt.Paint paint28 = categoryPlot27.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker29 = null;
        org.jfree.chart.util.Layer layer30 = null;
        boolean boolean31 = categoryPlot27.removeDomainMarker(marker29, layer30);
        boolean boolean32 = categoryPlot27.isRangeMinorGridlinesVisible();
        boolean boolean33 = abstractCategoryDataset11.hasListener((java.util.EventListener) categoryPlot27);
        org.jfree.chart.axis.AxisLocation axisLocation35 = categoryPlot27.getDomainAxisLocation(4);
        java.lang.Comparable comparable36 = categoryPlot27.getDomainCrosshairColumnKey();
        lineAndShapeRenderer2.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot27);
        org.jfree.chart.plot.CategoryMarker categoryMarker39 = null;
        org.jfree.chart.util.Layer layer40 = null;
        try {
            categoryPlot27.addDomainMarker((int) (short) -1, categoryMarker39, layer40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categorySeriesLabelGenerator10);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNull(comparable36);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.KeyedObject keyedObject2 = new org.jfree.data.KeyedObject((java.lang.Comparable) false, (java.lang.Object) "ChartChangeEventType.GENERAL");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = categoryAxis4.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D10, rectangleEdge11);
        int int13 = categoryAxis4.getCategoryLabelPositionOffset();
        categoryAxis4.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis16, categoryItemRenderer17);
        java.awt.Paint paint19 = categoryPlot18.getRangeCrosshairPaint();
        int int20 = categoryPlot18.getWeight();
        java.lang.Comparable comparable21 = null;
        categoryPlot18.setDomainCrosshairRowKey(comparable21, true);
        categoryPlot18.clearAnnotations();
        java.awt.geom.GeneralPath generalPath25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.RenderingSource renderingSource27 = null;
        categoryPlot18.select(generalPath25, rectangle2D26, renderingSource27);
        java.awt.Stroke stroke29 = categoryPlot18.getOutlineStroke();
        keyedObject2.setObject((java.lang.Object) categoryPlot18);
        int int31 = categoryPlot18.getCrosshairDatasetIndex();
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        java.awt.Font font5 = lineAndShapeRenderer2.getBaseItemLabelFont();
        java.lang.Boolean boolean7 = lineAndShapeRenderer2.getSeriesVisible((-14336));
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker25 = null;
        org.jfree.chart.util.Layer layer26 = null;
        boolean boolean27 = categoryPlot23.removeDomainMarker(marker25, layer26);
        org.jfree.chart.util.Layer layer28 = null;
        java.util.Collection collection29 = categoryPlot23.getRangeMarkers(layer28);
        java.awt.Font font30 = categoryPlot23.getNoDataMessageFont();
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        categoryPlot23.setRangeMinorGridlinePaint((java.awt.Paint) color31);
        lineAndShapeRenderer2.setBaseLegendTextPaint((java.awt.Paint) color31);
        boolean boolean34 = lineAndShapeRenderer2.getAutoPopulateSeriesPaint();
        java.awt.Stroke stroke35 = lineAndShapeRenderer2.getBaseOutlineStroke();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(collection29);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(stroke35);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "");
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape7);
        chartEntity6.setArea(shape7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape7, (java.awt.Paint) color10);
        legendItem11.setURLText("{0}");
        java.awt.Stroke stroke14 = legendItem11.getOutlineStroke();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer15 = legendItem11.getFillPaintTransformer();
        org.jfree.chart.renderer.RenderAttributes renderAttributes17 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Color color19 = java.awt.Color.blue;
        renderAttributes17.setSeriesFillPaint(0, (java.awt.Paint) color19);
        java.awt.Font font21 = renderAttributes17.getDefaultLabelFont();
        java.awt.Stroke stroke24 = renderAttributes17.getItemStroke(4, (int) (short) 100);
        java.awt.Color color25 = java.awt.Color.GREEN;
        renderAttributes17.setDefaultPaint((java.awt.Paint) color25);
        java.awt.Shape shape31 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity33 = new org.jfree.chart.entity.ChartEntity(shape31, "");
        java.awt.Shape shape34 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent35 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape34);
        chartEntity33.setArea(shape34);
        java.awt.Color color37 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem38 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape34, (java.awt.Paint) color37);
        legendItem38.setURLText("{0}");
        java.awt.Paint paint41 = legendItem38.getOutlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = null;
        double double50 = categoryAxis42.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D48, rectangleEdge49);
        int int51 = categoryAxis42.getCategoryLabelPositionOffset();
        categoryAxis42.setMaximumCategoryLabelLines(4);
        categoryAxis42.setLowerMargin(0.0d);
        java.awt.geom.Rectangle2D rectangle2D61 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = null;
        double double63 = categoryAxis42.getCategorySeriesMiddle((int) (byte) 1, (int) ' ', (int) (byte) 10, 0, 3.0d, rectangle2D61, rectangleEdge62);
        java.awt.Font font64 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis42.setTickLabelFont(font64);
        legendItem38.setLabelFont(font64);
        renderAttributes17.setDefaultLabelFont(font64);
        legendItem11.setLabelFont(font64);
        legendItem11.setLineVisible(false);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(gradientPaintTransformer15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(font21);
        org.junit.Assert.assertNull(stroke24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 4 + "'", int51 == 4);
        org.junit.Assert.assertEquals((double) double63, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font64);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor29 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor30 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor29, textAnchor30);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj34 = standardGradientPaintTransformer33.clone();
        boolean boolean35 = categoryAxis32.equals((java.lang.Object) standardGradientPaintTransformer33);
        boolean boolean36 = itemLabelPosition31.equals((java.lang.Object) boolean35);
        double double37 = itemLabelPosition31.getAngle();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor38 = itemLabelPosition31.getItemLabelAnchor();
        lineAndShapeRenderer2.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition31);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator41 = null;
        lineAndShapeRenderer2.setSeriesURLGenerator(1, categoryURLGenerator41);
        java.awt.Graphics2D graphics2D43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.data.category.CategoryDataset categoryDataset45 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = null;
        double double54 = categoryAxis46.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D52, rectangleEdge53);
        int int55 = categoryAxis46.getCategoryLabelPositionOffset();
        categoryAxis46.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis58 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer59 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, valueAxis58, categoryItemRenderer59);
        java.awt.Paint paint61 = categoryPlot60.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor62 = categoryPlot60.getDomainGridlinePosition();
        java.awt.Paint paint63 = categoryPlot60.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset64 = null;
        categoryPlot60.setDataset(categoryDataset64);
        org.jfree.chart.LegendItemCollection legendItemCollection66 = categoryPlot60.getLegendItems();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent67 = null;
        categoryPlot60.notifyListeners(plotChangeEvent67);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer70 = null;
        categoryPlot60.setRenderer((int) ' ', categoryItemRenderer70, true);
        org.jfree.data.category.CategoryDataset categoryDataset73 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo74 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState75 = lineAndShapeRenderer2.initialise(graphics2D43, rectangle2D44, categoryPlot60, categoryDataset73, plotRenderingInfo74);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation76 = null;
        org.jfree.chart.util.Layer layer77 = null;
        try {
            lineAndShapeRenderer2.addAnnotation(categoryAnnotation76, layer77);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(itemLabelAnchor29);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor38);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 4 + "'", int55 == 4);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(categoryAnchor62);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(legendItemCollection66);
        org.junit.Assert.assertNotNull(categoryItemRendererState75);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        boolean boolean2 = barRenderer0.isDrawBarOutline();
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        java.awt.Paint paint18 = categoryPlot15.getBackgroundPaint();
        org.jfree.chart.plot.Marker marker19 = null;
        org.jfree.chart.util.Layer layer20 = null;
        try {
            categoryPlot15.addRangeMarker(marker19, layer20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        java.awt.Color color2 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=ItemLabelAnchor.OUTSIDE7]", (int) 'a');
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        categoryPlot15.addChangeListener(plotChangeListener16);
        categoryPlot15.setDomainCrosshairColumnKey((java.lang.Comparable) 5, false);
        categoryPlot15.mapDatasetToRangeAxis(0, 0);
        java.awt.Paint paint24 = categoryPlot15.getDomainGridlinePaint();
        categoryPlot15.setDomainCrosshairRowKey((java.lang.Comparable) (-1L));
        org.jfree.chart.plot.Marker marker27 = null;
        org.jfree.chart.util.Layer layer28 = null;
        try {
            boolean boolean29 = categoryPlot15.removeRangeMarker(marker27, layer28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        org.jfree.data.KeyedObjects2D keyedObjects2D18 = new org.jfree.data.KeyedObjects2D();
        java.awt.Color color19 = java.awt.Color.BLACK;
        boolean boolean20 = keyedObjects2D18.equals((java.lang.Object) color19);
        int int21 = color19.getTransparency();
        categoryPlot15.setRangeGridlinePaint((java.awt.Paint) color19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot15.zoomRangeAxes((double) 0L, plotRenderingInfo24, point2D25, true);
        boolean boolean28 = categoryPlot15.isRangeZeroBaselineVisible();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint3 = renderAttributes1.getSeriesOutlinePaint((int) '4');
        java.awt.Stroke stroke4 = renderAttributes1.getDefaultOutlineStroke();
        java.awt.Paint paint6 = renderAttributes1.getSeriesFillPaint(0);
        java.awt.Stroke stroke9 = renderAttributes1.getItemStroke((int) (byte) -1, (int) (byte) -1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNull(stroke9);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = keyedObjects2D0.clone();
        int int3 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 'a');
        int int4 = keyedObjects2D0.getRowCount();
        try {
            java.lang.Comparable comparable6 = keyedObjects2D0.getColumnKey((-2));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        java.awt.Paint paint18 = categoryPlot15.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        categoryPlot15.setDataset(categoryDataset19);
        org.jfree.chart.LegendItemCollection legendItemCollection21 = categoryPlot15.getLegendItems();
        java.awt.Shape shape26 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity28 = new org.jfree.chart.entity.ChartEntity(shape26, "");
        java.awt.Shape shape29 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent30 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape29);
        chartEntity28.setArea(shape29);
        java.awt.Color color32 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape29, (java.awt.Paint) color32);
        legendItem33.setURLText("{0}");
        legendItem33.setSeriesIndex(8);
        legendItemCollection21.add(legendItem33);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(legendItemCollection21);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(color32);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        int int17 = categoryPlot15.getWeight();
        java.lang.Comparable comparable18 = null;
        categoryPlot15.setDomainCrosshairRowKey(comparable18, true);
        categoryPlot15.clearAnnotations();
        java.awt.geom.GeneralPath generalPath22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.RenderingSource renderingSource24 = null;
        categoryPlot15.select(generalPath22, rectangle2D23, renderingSource24);
        categoryPlot15.setRangeCrosshairValue((double) (-1.0f));
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = null;
        org.jfree.chart.util.Layer layer30 = null;
        try {
            categoryPlot15.addDomainMarker((int) '4', categoryMarker29, layer30, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        boolean boolean5 = lineAndShapeRenderer2.getBaseShapesFilled();
        java.lang.Boolean boolean7 = lineAndShapeRenderer2.getSeriesLinesVisible(100);
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = lineAndShapeRenderer2.getSelectedItemAttributes();
        boolean boolean9 = lineAndShapeRenderer2.getBaseSeriesVisible();
        boolean boolean10 = lineAndShapeRenderer2.getBaseItemLabelsVisible();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertNotNull(renderAttributes8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        java.lang.String str3 = chartEntity2.getShapeType();
        chartEntity2.setToolTipText("org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]");
        java.lang.String str6 = chartEntity2.getToolTipText();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "poly" + "'", str3.equals("poly"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]" + "'", str6.equals("org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        java.awt.Shape shape29 = lineAndShapeRenderer2.getBaseLegendShape();
        java.awt.Shape shape33 = lineAndShapeRenderer2.getItemShape((int) (byte) 100, (-14336), true);
        java.awt.Paint paint37 = lineAndShapeRenderer2.getItemOutlinePaint(100, 100, false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(shape29);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.util.ObjectList objectList18 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        float float21 = categoryAxis20.getMinorTickMarkInsideLength();
        boolean boolean22 = categoryAxis20.isMinorTickMarksVisible();
        categoryAxis20.setLabelURL("hi!");
        objectList18.set((int) (short) 10, (java.lang.Object) categoryAxis20);
        org.jfree.chart.plot.Plot plot26 = null;
        categoryAxis20.setPlot(plot26);
        categoryAxis20.setCategoryMargin((double) (-1));
        categoryPlot15.setDomainAxis((int) '#', categoryAxis20);
        categoryPlot15.configureRangeAxes();
        org.jfree.chart.plot.Marker marker32 = null;
        boolean boolean33 = categoryPlot15.removeDomainMarker(marker32);
        boolean boolean34 = categoryPlot15.isRangeCrosshairVisible();
        org.jfree.chart.util.SortOrder sortOrder35 = categoryPlot15.getRowRenderingOrder();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(sortOrder35);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor29 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor30 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor29, textAnchor30);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj34 = standardGradientPaintTransformer33.clone();
        boolean boolean35 = categoryAxis32.equals((java.lang.Object) standardGradientPaintTransformer33);
        boolean boolean36 = itemLabelPosition31.equals((java.lang.Object) boolean35);
        double double37 = itemLabelPosition31.getAngle();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor38 = itemLabelPosition31.getItemLabelAnchor();
        lineAndShapeRenderer2.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition31);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator41 = null;
        lineAndShapeRenderer2.setSeriesURLGenerator(1, categoryURLGenerator41);
        java.awt.Graphics2D graphics2D43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.data.category.CategoryDataset categoryDataset45 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = null;
        double double54 = categoryAxis46.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D52, rectangleEdge53);
        int int55 = categoryAxis46.getCategoryLabelPositionOffset();
        categoryAxis46.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis58 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer59 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot(categoryDataset45, categoryAxis46, valueAxis58, categoryItemRenderer59);
        java.awt.Paint paint61 = categoryPlot60.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor62 = categoryPlot60.getDomainGridlinePosition();
        java.awt.Paint paint63 = categoryPlot60.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset64 = null;
        categoryPlot60.setDataset(categoryDataset64);
        org.jfree.chart.LegendItemCollection legendItemCollection66 = categoryPlot60.getLegendItems();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent67 = null;
        categoryPlot60.notifyListeners(plotChangeEvent67);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer70 = null;
        categoryPlot60.setRenderer((int) ' ', categoryItemRenderer70, true);
        org.jfree.data.category.CategoryDataset categoryDataset73 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo74 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState75 = lineAndShapeRenderer2.initialise(graphics2D43, rectangle2D44, categoryPlot60, categoryDataset73, plotRenderingInfo74);
        org.jfree.data.category.CategoryDataset categoryDataset77 = categoryPlot60.getDataset((-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(itemLabelAnchor29);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor38);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 4 + "'", int55 == 4);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(categoryAnchor62);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(legendItemCollection66);
        org.junit.Assert.assertNotNull(categoryItemRendererState75);
        org.junit.Assert.assertNull(categoryDataset77);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Shape shape4 = renderAttributes1.getItemShape((-16777216), 0);
        java.awt.Stroke stroke5 = renderAttributes1.getDefaultStroke();
        java.awt.Color color7 = java.awt.Color.CYAN;
        renderAttributes1.setSeriesOutlinePaint(3, (java.awt.Paint) color7);
        org.junit.Assert.assertNull(shape4);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "");
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape7);
        chartEntity6.setArea(shape7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape7, (java.awt.Paint) color10);
        legendItem11.setURLText("{0}");
        java.awt.Stroke stroke14 = legendItem11.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart15 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendItem11, jFreeChart15);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset17 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = categoryAxis19.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D25, rectangleEdge26);
        int int28 = categoryAxis19.getCategoryLabelPositionOffset();
        categoryAxis19.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis31, categoryItemRenderer32);
        java.awt.Paint paint34 = categoryPlot33.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker35 = null;
        org.jfree.chart.util.Layer layer36 = null;
        boolean boolean37 = categoryPlot33.removeDomainMarker(marker35, layer36);
        boolean boolean38 = categoryPlot33.isRangeMinorGridlinesVisible();
        boolean boolean39 = abstractCategoryDataset17.hasListener((java.util.EventListener) categoryPlot33);
        legendItem11.setDataset((org.jfree.data.general.Dataset) abstractCategoryDataset17);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset41 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list42 = defaultCategoryDataset41.getRowKeys();
        abstractCategoryDataset17.setSelectionState((org.jfree.data.category.CategoryDatasetSelectionState) defaultCategoryDataset41);
        int int45 = defaultCategoryDataset41.getColumnIndex((java.lang.Comparable) "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]");
        java.lang.Comparable comparable48 = null;
        try {
            defaultCategoryDataset41.addValue(0.05d, (java.lang.Comparable) "GradientPaintTransformType.VERTICAL", comparable48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'columnKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        float float4 = categoryAxis3.getMinorTickMarkInsideLength();
        boolean boolean5 = categoryAxis3.isMinorTickMarksVisible();
        categoryAxis3.setLabelURL("hi!");
        objectList1.set((int) (short) 10, (java.lang.Object) categoryAxis3);
        org.jfree.chart.plot.Plot plot9 = null;
        categoryAxis3.setPlot(plot9);
        double double11 = categoryAxis3.getCategoryMargin();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = abstractCategoryDataset0.hasListener(eventListener1);
        java.lang.Object obj3 = abstractCategoryDataset0.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        java.awt.Paint paint18 = categoryPlot15.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        categoryPlot15.setDataset(categoryDataset19);
        org.jfree.chart.LegendItemCollection legendItemCollection21 = categoryPlot15.getLegendItems();
        boolean boolean22 = categoryPlot15.canSelectByPoint();
        int int23 = categoryPlot15.getRangeAxisCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot15.getDomainAxis();
        categoryAxis24.setFixedDimension((double) (-8323073));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(legendItemCollection21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(categoryAxis24);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator5, true);
        java.awt.Font font9 = lineAndShapeRenderer2.getLegendTextFont(0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset13 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener14 = null;
        boolean boolean15 = abstractCategoryDataset13.hasListener(eventListener14);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener16 = null;
        abstractCategoryDataset13.removeChangeListener(datasetChangeListener16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = categoryAxis19.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D25, rectangleEdge26);
        int int28 = categoryAxis19.getCategoryLabelPositionOffset();
        categoryAxis19.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis31, categoryItemRenderer32);
        java.awt.Paint paint34 = categoryPlot33.getRangeCrosshairPaint();
        int int35 = categoryPlot33.getWeight();
        abstractCategoryDataset13.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot33);
        lineAndShapeRenderer12.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot33);
        boolean boolean38 = lineAndShapeRenderer12.getBaseShapesFilled();
        org.jfree.chart.renderer.RenderAttributes renderAttributes41 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint43 = renderAttributes41.getSeriesOutlinePaint((int) '4');
        java.awt.Stroke stroke44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes41.setDefaultStroke(stroke44);
        lineAndShapeRenderer12.setSeriesStroke(0, stroke44, false);
        boolean boolean50 = lineAndShapeRenderer12.getItemShapeVisible((-16777216), 8);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor52 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor53 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition54 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor52, textAnchor53);
        org.jfree.chart.text.TextAnchor textAnchor55 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition56 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor52, textAnchor55);
        lineAndShapeRenderer12.setSeriesNegativeItemLabelPosition(8, itemLabelPosition56);
        lineAndShapeRenderer2.setBasePositiveItemLabelPosition(itemLabelPosition56, true);
        org.junit.Assert.assertNull(font9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNull(paint43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(itemLabelAnchor52);
        org.junit.Assert.assertNotNull(textAnchor53);
        org.junit.Assert.assertNotNull(textAnchor55);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        java.lang.String str3 = chartEntity2.getShapeType();
        java.lang.String str4 = chartEntity2.getShapeCoords();
        java.awt.Shape shape5 = chartEntity2.getArea();
        java.lang.Object obj6 = chartEntity2.clone();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "poly" + "'", str3.equals("poly"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0" + "'", str4.equals("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0"));
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint33 = renderAttributes31.getSeriesOutlinePaint((int) '4');
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes31.setDefaultStroke(stroke34);
        lineAndShapeRenderer2.setSeriesStroke(0, stroke34, false);
        boolean boolean40 = lineAndShapeRenderer2.getItemShapeVisible((-16777216), 8);
        java.awt.Paint paint41 = null;
        lineAndShapeRenderer2.setBaseLegendTextPaint(paint41);
        java.awt.Shape shape44 = lineAndShapeRenderer2.getSeriesShape(3);
        lineAndShapeRenderer2.setAutoPopulateSeriesShape(false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(shape44);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        int int17 = categoryPlot15.getWeight();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        categoryPlot15.setRenderer(categoryItemRenderer18);
        categoryPlot15.clearRangeMarkers((-255));
        org.jfree.chart.LegendItemCollection legendItemCollection22 = new org.jfree.chart.LegendItemCollection();
        categoryPlot15.setFixedLegendItems(legendItemCollection22);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = categoryPlot15.getDomainAxis((-1));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = categoryPlot15.getRenderer();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(categoryAxis25);
        org.junit.Assert.assertNull(categoryItemRenderer26);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int1 = color0.getBlue();
        float[] floatArray5 = new float[] { '#', (byte) 10, (short) 100 };
        float[] floatArray6 = color0.getColorComponents(floatArray5);
        java.awt.Color color7 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        java.awt.Font font28 = lineAndShapeRenderer2.getBaseItemLabelFont();
        boolean boolean29 = lineAndShapeRenderer2.getBaseCreateEntities();
        java.lang.Boolean boolean31 = lineAndShapeRenderer2.getSeriesLinesVisible((int) (short) 10);
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator37 = new org.jfree.chart.util.DefaultShadowGenerator(255, color33, (float) (-1L), (int) (byte) -1, (double) (-1L));
        int int38 = color33.getRed();
        lineAndShapeRenderer2.setBaseOutlinePaint((java.awt.Paint) color33, false);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator42 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("java.awt.Color[r=128,g=128,b=128]");
        lineAndShapeRenderer2.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator42);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNull(boolean31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        boolean boolean5 = lineAndShapeRenderer2.getBaseShapesFilled();
        java.lang.Boolean boolean7 = lineAndShapeRenderer2.getSeriesLinesVisible(100);
        lineAndShapeRenderer2.setUseFillPaint(false);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = categoryAxis12.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D18, rectangleEdge19);
        int int21 = categoryAxis12.getCategoryLabelPositionOffset();
        categoryAxis12.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis24, categoryItemRenderer25);
        java.lang.Comparable comparable27 = categoryPlot26.getDomainCrosshairColumnKey();
        org.jfree.chart.plot.PlotOrientation plotOrientation28 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        boolean boolean30 = plotOrientation28.equals((java.lang.Object) color29);
        categoryPlot26.setRangeZeroBaselinePaint((java.awt.Paint) color29);
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        try {
            lineAndShapeRenderer2.drawBackground(graphics2D10, categoryPlot26, rectangle2D32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNull(comparable27);
        org.junit.Assert.assertNotNull(plotOrientation28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        double double16 = categoryPlot15.getAnchorValue();
        float float17 = categoryPlot15.getBackgroundImageAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot15.getDomainAxisLocation();
        categoryPlot15.setRangeZeroBaselineVisible(false);
        org.jfree.chart.JFreeChart jFreeChart21 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType22 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent23 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) false, jFreeChart21, chartChangeEventType22);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(chartChangeEventType22);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        categoryPlot15.addChangeListener(plotChangeListener16);
        boolean boolean18 = categoryPlot15.isRangeZoomable();
        int int19 = categoryPlot15.getDomainAxisCount();
        org.jfree.data.category.CategoryDataset categoryDataset20 = categoryPlot15.getDataset();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNull(categoryDataset20);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        java.lang.String str1 = gradientPaintTransformType0.toString();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        boolean boolean3 = gradientPaintTransformType0.equals((java.lang.Object) color2);
        java.awt.image.ColorModel colorModel4 = null;
        java.awt.Rectangle rectangle5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.AffineTransform affineTransform7 = null;
        java.awt.RenderingHints renderingHints8 = null;
        java.awt.PaintContext paintContext9 = color2.createContext(colorModel4, rectangle5, rectangle2D6, affineTransform7, renderingHints8);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GradientPaintTransformType.CENTER_HORIZONTAL" + "'", str1.equals("GradientPaintTransformType.CENTER_HORIZONTAL"));
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paintContext9);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        java.awt.Paint paint18 = categoryPlot15.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        categoryPlot15.setDataset(categoryDataset19);
        org.jfree.chart.renderer.RenderAttributes renderAttributes22 = new org.jfree.chart.renderer.RenderAttributes(false);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
        double double32 = categoryAxis24.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D30, rectangleEdge31);
        int int33 = categoryAxis24.getCategoryLabelPositionOffset();
        categoryAxis24.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis36, categoryItemRenderer37);
        java.awt.Paint paint39 = categoryPlot38.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor40 = categoryPlot38.getDomainGridlinePosition();
        java.awt.Paint paint41 = categoryPlot38.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset42 = null;
        categoryPlot38.setDataset(categoryDataset42);
        org.jfree.chart.LegendItemCollection legendItemCollection44 = categoryPlot38.getLegendItems();
        java.awt.Stroke stroke45 = categoryPlot38.getRangeGridlineStroke();
        renderAttributes22.setDefaultStroke(stroke45);
        categoryPlot15.setRangeGridlineStroke(stroke45);
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = null;
        try {
            categoryPlot15.setInsets(rectangleInsets48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(categoryAnchor40);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(legendItemCollection44);
        org.junit.Assert.assertNotNull(stroke45);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        java.lang.String str3 = chartEntity2.getShapeType();
        java.lang.Object obj4 = chartEntity2.clone();
        java.lang.String str5 = chartEntity2.getShapeType();
        java.lang.String str6 = chartEntity2.getShapeCoords();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "poly" + "'", str3.equals("poly"));
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "poly" + "'", str5.equals("poly"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0" + "'", str6.equals("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0"));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Color color3 = java.awt.Color.blue;
        renderAttributes1.setSeriesFillPaint(0, (java.awt.Paint) color3);
        java.awt.Color color5 = java.awt.Color.GRAY;
        renderAttributes1.setDefaultOutlinePaint((java.awt.Paint) color5);
        java.awt.Shape shape8 = renderAttributes1.getSeriesShape((-1));
        java.lang.Boolean boolean9 = renderAttributes1.getDefaultLabelVisible();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertNull(boolean9);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator0 = new org.jfree.chart.util.DefaultShadowGenerator();
        int int1 = defaultShadowGenerator0.calculateOffsetY();
        int int2 = defaultShadowGenerator0.getShadowSize();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2) + "'", int1 == (-2));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean19 = categoryPlot15.removeDomainMarker(marker17, layer18);
        boolean boolean20 = categoryPlot15.isRangeMinorGridlinesVisible();
        org.jfree.chart.axis.AxisSpace axisSpace21 = null;
        categoryPlot15.setFixedDomainAxisSpace(axisSpace21);
        java.awt.Paint paint23 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        categoryPlot15.setRangeCrosshairPaint(paint23);
        java.awt.Font font25 = categoryPlot15.getNoDataMessageFont();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(font25);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "");
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape7);
        chartEntity6.setArea(shape7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape7, (java.awt.Paint) color10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis13.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D19, rectangleEdge20);
        int int22 = categoryAxis13.getCategoryLabelPositionOffset();
        categoryAxis13.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis25, categoryItemRenderer26);
        java.awt.Paint paint28 = categoryPlot27.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor29 = categoryPlot27.getDomainGridlinePosition();
        org.jfree.chart.entity.PlotEntity plotEntity30 = new org.jfree.chart.entity.PlotEntity(shape7, (org.jfree.chart.plot.Plot) categoryPlot27);
        java.awt.Paint paint31 = categoryPlot27.getOutlinePaint();
        java.lang.Object obj32 = categoryPlot27.clone();
        java.awt.Paint paint33 = categoryPlot27.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(categoryAnchor29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(paint33);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 1L, (double) 2.0f, (double) 100L, (double) (byte) 0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "");
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape7);
        chartEntity6.setArea(shape7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape7, (java.awt.Paint) color10);
        legendItem11.setURLText("{0}");
        java.awt.Paint paint14 = legendItem11.getOutlinePaint();
        java.awt.Paint paint15 = legendItem11.getLinePaint();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape20, "");
        java.awt.Shape shape23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape23);
        chartEntity22.setArea(shape23);
        java.awt.Color color26 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape23, (java.awt.Paint) color26);
        legendItem11.setShape(shape23);
        legendItem11.setURLText("ItemLabelAnchor.INSIDE6");
        int int31 = legendItem11.getSeriesIndex();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getAutoPopulateSeriesOutlineStroke();
        lineAndShapeRenderer2.setAutoPopulateSeriesStroke(true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabelURL("");
        categoryAxis0.setAxisLineVisible(true);
        boolean boolean5 = categoryAxis0.isTickMarksVisible();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.lang.String str1 = rectangleInsets0.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str1.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint33 = renderAttributes31.getSeriesOutlinePaint((int) '4');
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes31.setDefaultStroke(stroke34);
        lineAndShapeRenderer2.setSeriesStroke(0, stroke34, false);
        boolean boolean40 = lineAndShapeRenderer2.getItemShapeVisible((-16777216), 8);
        lineAndShapeRenderer2.setUseSeriesOffset(true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMinorTickMarkInsideLength();
        boolean boolean2 = categoryAxis0.isMinorTickMarksVisible();
        boolean boolean3 = categoryAxis0.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot4 = null;
        categoryAxis0.setPlot(plot4);
        java.awt.Paint paint7 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) 100L);
        int int8 = categoryAxis0.getCategoryLabelPositionOffset();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint33 = renderAttributes31.getSeriesOutlinePaint((int) '4');
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes31.setDefaultStroke(stroke34);
        lineAndShapeRenderer2.setSeriesStroke(0, stroke34, false);
        lineAndShapeRenderer2.clearSeriesStrokes(true);
        java.awt.Paint paint43 = lineAndShapeRenderer2.getItemFillPaint(8, (-1), true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator44 = null;
        lineAndShapeRenderer2.setBaseToolTipGenerator(categoryToolTipGenerator44);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(paint43);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMinorTickMarkInsideLength();
        boolean boolean2 = categoryAxis0.isMinorTickMarksVisible();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset5 = new org.jfree.data.category.DefaultCategoryDataset();
        int int6 = defaultCategoryDataset5.getRowCount();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis10.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D16, rectangleEdge17);
        int int19 = categoryAxis10.getCategoryLabelPositionOffset();
        categoryAxis10.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis22, categoryItemRenderer23);
        java.awt.Paint paint25 = categoryPlot24.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor26 = categoryPlot24.getDomainGridlinePosition();
        java.awt.Paint paint27 = categoryPlot24.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        categoryPlot24.setDataset(categoryDataset28);
        org.jfree.chart.LegendItemCollection legendItemCollection30 = categoryPlot24.getLegendItems();
        boolean boolean31 = categoryPlot24.canSelectByPoint();
        int int32 = categoryPlot24.getRangeAxisCount();
        categoryPlot24.clearRangeAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = categoryPlot24.getDomainAxisEdge();
        try {
            double double35 = categoryAxis0.getCategorySeriesMiddle((java.lang.Comparable) true, (java.lang.Comparable) (-16777216), (org.jfree.data.category.CategoryDataset) defaultCategoryDataset5, 0.0d, rectangle2D8, rectangleEdge34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(categoryAnchor26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(legendItemCollection30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge34);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint33 = renderAttributes31.getSeriesOutlinePaint((int) '4');
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes31.setDefaultStroke(stroke34);
        lineAndShapeRenderer2.setSeriesStroke(0, stroke34, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation38 = null;
        boolean boolean39 = lineAndShapeRenderer2.removeAnnotation(categoryAnnotation38);
        java.awt.Paint paint41 = lineAndShapeRenderer2.lookupSeriesFillPaint(0);
        java.awt.Stroke stroke45 = lineAndShapeRenderer2.getItemStroke((int) (byte) 10, (-12566464), false);
        lineAndShapeRenderer2.setSeriesShapesFilled((int) (byte) 100, true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(stroke45);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        int int17 = categoryPlot15.getWeight();
        categoryPlot15.configureDomainAxes();
        org.jfree.chart.plot.Marker marker19 = null;
        org.jfree.chart.util.Layer layer20 = null;
        boolean boolean21 = categoryPlot15.removeDomainMarker(marker19, layer20);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor29 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor30 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor29, textAnchor30);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj34 = standardGradientPaintTransformer33.clone();
        boolean boolean35 = categoryAxis32.equals((java.lang.Object) standardGradientPaintTransformer33);
        boolean boolean36 = itemLabelPosition31.equals((java.lang.Object) boolean35);
        double double37 = itemLabelPosition31.getAngle();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor38 = itemLabelPosition31.getItemLabelAnchor();
        lineAndShapeRenderer2.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition31);
        lineAndShapeRenderer2.setBaseCreateEntities(false);
        lineAndShapeRenderer2.setSeriesCreateEntities((int) 'a', (java.lang.Boolean) true);
        java.awt.Shape shape45 = lineAndShapeRenderer2.getBaseLegendShape();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(itemLabelAnchor29);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor38);
        org.junit.Assert.assertNull(shape45);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMinorTickMarkInsideLength();
        boolean boolean2 = categoryAxis0.isMinorTickMarksVisible();
        java.lang.String str4 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) 1);
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 'a', "hi!");
        categoryAxis0.setLabelURL("org.jfree.data.UnknownKeyException: 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        double double10 = categoryAxis0.getCategoryMargin();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.2d + "'", double10 == 0.2d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int3 = color2.getAlpha();
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator7 = new org.jfree.chart.util.DefaultShadowGenerator((int) (short) 0, color2, (-1.0f), 10, (double) (short) 1);
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("org.jfree.data.UnknownKeyException: 4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0", (java.awt.Paint) color2);
        java.lang.String str9 = legendItem8.getURLText();
        java.awt.Color color10 = java.awt.Color.MAGENTA;
        legendItem8.setOutlinePaint((java.awt.Paint) color10);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        int int17 = categoryPlot15.getWeight();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        categoryPlot15.setRenderer(categoryItemRenderer18);
        categoryPlot15.clearRangeMarkers((-255));
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot15.getRangeMarkers((int) '4', layer23);
        categoryPlot15.setDomainCrosshairRowKey((java.lang.Comparable) 1.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(collection24);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) '4');
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        java.awt.Font font5 = lineAndShapeRenderer2.getBaseItemLabelFont();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = categoryAxis8.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D14, rectangleEdge15);
        int int17 = categoryAxis8.getCategoryLabelPositionOffset();
        categoryAxis8.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis20, categoryItemRenderer21);
        java.awt.Paint paint23 = categoryPlot22.getRangeCrosshairPaint();
        int int24 = categoryPlot22.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        categoryPlot22.setFixedDomainAxisSpace(axisSpace25);
        org.jfree.chart.axis.AxisSpace axisSpace27 = categoryPlot22.getFixedDomainAxisSpace();
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        double double37 = categoryAxis29.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D35, rectangleEdge36);
        int int38 = categoryAxis29.getCategoryLabelPositionOffset();
        categoryAxis29.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis41, categoryItemRenderer42);
        java.awt.Paint paint44 = categoryPlot43.getRangeCrosshairPaint();
        int int45 = categoryPlot43.getWeight();
        java.lang.Comparable comparable46 = null;
        categoryPlot43.setDomainCrosshairRowKey(comparable46, true);
        org.jfree.chart.util.SortOrder sortOrder49 = categoryPlot43.getRowRenderingOrder();
        categoryPlot22.setColumnRenderingOrder(sortOrder49);
        org.jfree.chart.util.SortOrder sortOrder51 = categoryPlot22.getColumnRenderingOrder();
        categoryPlot22.setCrosshairDatasetIndex(10);
        org.jfree.chart.axis.ValueAxis valueAxis54 = null;
        org.jfree.chart.plot.Marker marker55 = null;
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        lineAndShapeRenderer2.drawRangeMarker(graphics2D6, categoryPlot22, valueAxis54, marker55, rectangle2D56);
        lineAndShapeRenderer2.setSeriesVisibleInLegend(128, (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNull(axisSpace27);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 4 + "'", int38 == 4);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(sortOrder49);
        org.junit.Assert.assertNotNull(sortOrder51);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "");
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape7);
        chartEntity6.setArea(shape7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape7, (java.awt.Paint) color10);
        legendItem11.setURLText("{0}");
        java.awt.Stroke stroke14 = legendItem11.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart15 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendItem11, jFreeChart15);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset17 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = categoryAxis19.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D25, rectangleEdge26);
        int int28 = categoryAxis19.getCategoryLabelPositionOffset();
        categoryAxis19.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis31, categoryItemRenderer32);
        java.awt.Paint paint34 = categoryPlot33.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker35 = null;
        org.jfree.chart.util.Layer layer36 = null;
        boolean boolean37 = categoryPlot33.removeDomainMarker(marker35, layer36);
        boolean boolean38 = categoryPlot33.isRangeMinorGridlinesVisible();
        boolean boolean39 = abstractCategoryDataset17.hasListener((java.util.EventListener) categoryPlot33);
        legendItem11.setDataset((org.jfree.data.general.Dataset) abstractCategoryDataset17);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset41 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list42 = defaultCategoryDataset41.getRowKeys();
        abstractCategoryDataset17.setSelectionState((org.jfree.data.category.CategoryDatasetSelectionState) defaultCategoryDataset41);
        int int45 = defaultCategoryDataset41.getColumnIndex((java.lang.Comparable) (byte) 1);
        defaultCategoryDataset41.addValue((double) 10L, (java.lang.Comparable) "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", (java.lang.Comparable) (-32513.0d));
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        int int17 = categoryPlot15.getWeight();
        boolean boolean18 = categoryPlot15.canSelectByPoint();
        float float19 = categoryPlot15.getBackgroundAlpha();
        java.awt.Shape shape24 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity26 = new org.jfree.chart.entity.ChartEntity(shape24, "");
        java.awt.Shape shape27 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape27);
        chartEntity26.setArea(shape27);
        java.awt.Color color30 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape27, (java.awt.Paint) color30);
        legendItem31.setURLText("{0}");
        org.jfree.chart.renderer.RenderAttributes renderAttributes35 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Color color37 = java.awt.Color.blue;
        renderAttributes35.setSeriesFillPaint(0, (java.awt.Paint) color37);
        legendItem31.setLinePaint((java.awt.Paint) color37);
        categoryPlot15.setBackgroundPaint((java.awt.Paint) color37);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = categoryPlot15.getAxisOffset();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(rectangleInsets41);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "");
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape7);
        chartEntity6.setArea(shape7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape7, (java.awt.Paint) color10);
        legendItem11.setURLText("{0}");
        org.jfree.chart.renderer.RenderAttributes renderAttributes15 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Color color17 = java.awt.Color.blue;
        renderAttributes15.setSeriesFillPaint(0, (java.awt.Paint) color17);
        legendItem11.setLinePaint((java.awt.Paint) color17);
        java.awt.Paint paint20 = legendItem11.getLinePaint();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextStroke();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = categoryAxis5.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D11, rectangleEdge12);
        int int14 = categoryAxis5.getCategoryLabelPositionOffset();
        categoryAxis5.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis17, categoryItemRenderer18);
        java.awt.Paint paint20 = categoryPlot19.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker21 = null;
        org.jfree.chart.util.Layer layer22 = null;
        boolean boolean23 = categoryPlot19.removeDomainMarker(marker21, layer22);
        boolean boolean24 = categoryPlot19.isRangeMinorGridlinesVisible();
        boolean boolean25 = abstractCategoryDataset3.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot19.getDomainMarkers(layer26);
        categoryPlot19.setNoDataMessage("hi!");
        org.jfree.chart.entity.PlotEntity plotEntity32 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot19, "GradientPaintTransformType.VERTICAL", "ItemLabelAnchor.INSIDE6");
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(collection27);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.lang.Boolean boolean2 = booleanList0.getBoolean(5);
        java.lang.Boolean boolean4 = booleanList0.getBoolean(5);
        try {
            booleanList0.setBoolean((-16776961), (java.lang.Boolean) true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNull(boolean4);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        java.awt.Shape shape3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape3);
        chartEntity2.setArea(shape3);
        chartEntity2.setToolTipText("");
        java.lang.String str8 = chartEntity2.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "ChartEntity: tooltip = " + "'", str8.equals("ChartEntity: tooltip = "));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = keyedObjects2D0.clone();
        int int3 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 'a');
        java.util.List list4 = keyedObjects2D0.getRowKeys();
        try {
            java.lang.Object obj7 = keyedObjects2D0.getObject((-16776961), (-16776961));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createInsetRectangle(rectangle2D1, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.SelectableValue selectableValue1 = new org.jfree.data.SelectableValue((java.lang.Number) 10);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        double double1 = barRenderer0.getMaximumBarWidth();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset5 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener6 = null;
        boolean boolean7 = abstractCategoryDataset5.hasListener(eventListener6);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener8 = null;
        abstractCategoryDataset5.removeChangeListener(datasetChangeListener8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = categoryAxis11.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D17, rectangleEdge18);
        int int20 = categoryAxis11.getCategoryLabelPositionOffset();
        categoryAxis11.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis23, categoryItemRenderer24);
        java.awt.Paint paint26 = categoryPlot25.getRangeCrosshairPaint();
        int int27 = categoryPlot25.getWeight();
        abstractCategoryDataset5.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot25);
        lineAndShapeRenderer4.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot25);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = lineAndShapeRenderer4.getSeriesPositiveItemLabelPosition((int) 'a');
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition31);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(itemLabelPosition31);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMinorTickMarkInsideLength();
        boolean boolean2 = categoryAxis0.isMinorTickMarksVisible();
        boolean boolean3 = categoryAxis0.isTickLabelsVisible();
        java.awt.Paint paint4 = categoryAxis0.getTickMarkPaint();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = categoryAxis6.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D12, rectangleEdge13);
        int int15 = categoryAxis6.getCategoryLabelPositionOffset();
        categoryAxis6.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot20.addChangeListener(plotChangeListener21);
        categoryPlot20.setDomainCrosshairColumnKey((java.lang.Comparable) 5, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        int int27 = categoryPlot20.getIndexOf(categoryItemRenderer26);
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot20);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent29 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot20);
        java.util.List list30 = categoryPlot20.getCategories();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNull(list30);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean19 = categoryPlot15.removeDomainMarker(marker17, layer18);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot15.getRangeMarkers(layer20);
        java.awt.Font font22 = categoryPlot15.getNoDataMessageFont();
        org.jfree.chart.axis.AxisSpace axisSpace23 = categoryPlot15.getFixedRangeAxisSpace();
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        categoryPlot15.removeChangeListener(plotChangeListener24);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent26 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot15);
        org.jfree.chart.plot.Plot plot27 = plotChangeEvent26.getPlot();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNull(axisSpace23);
        org.junit.Assert.assertNotNull(plot27);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean19 = categoryPlot15.removeDomainMarker(marker17, layer18);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot15.getRangeMarkers(layer20);
        java.awt.Stroke stroke22 = categoryPlot15.getDomainCrosshairStroke();
        boolean boolean23 = categoryPlot15.isDomainZoomable();
        org.jfree.chart.plot.Marker marker25 = null;
        org.jfree.chart.util.Layer layer26 = null;
        try {
            boolean boolean28 = categoryPlot15.removeRangeMarker((int) (byte) 10, marker25, layer26, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Color color3 = java.awt.Color.blue;
        renderAttributes1.setSeriesFillPaint(0, (java.awt.Paint) color3);
        java.awt.Color color5 = java.awt.Color.GRAY;
        renderAttributes1.setDefaultOutlinePaint((java.awt.Paint) color5);
        java.awt.Paint paint7 = renderAttributes1.getDefaultFillPaint();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        boolean boolean5 = lineAndShapeRenderer2.getBaseShapesFilled();
        int int6 = lineAndShapeRenderer2.getPassCount();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.util.ObjectList objectList18 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        float float21 = categoryAxis20.getMinorTickMarkInsideLength();
        boolean boolean22 = categoryAxis20.isMinorTickMarksVisible();
        categoryAxis20.setLabelURL("hi!");
        objectList18.set((int) (short) 10, (java.lang.Object) categoryAxis20);
        org.jfree.chart.plot.Plot plot26 = null;
        categoryAxis20.setPlot(plot26);
        categoryAxis20.setCategoryMargin((double) (-1));
        categoryPlot15.setDomainAxis((int) '#', categoryAxis20);
        categoryPlot15.configureRangeAxes();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder32 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str33 = datasetRenderingOrder32.toString();
        categoryPlot15.setDatasetRenderingOrder(datasetRenderingOrder32);
        java.awt.Shape shape39 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity41 = new org.jfree.chart.entity.ChartEntity(shape39, "");
        java.awt.Shape shape42 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent43 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape42);
        chartEntity41.setArea(shape42);
        java.awt.Color color45 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem46 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape42, (java.awt.Paint) color45);
        legendItem46.setURLText("{0}");
        java.awt.Stroke stroke49 = legendItem46.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart50 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent51 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendItem46, jFreeChart50);
        java.awt.Stroke stroke52 = legendItem46.getLineStroke();
        java.text.AttributedString attributedString53 = legendItem46.getAttributedLabel();
        boolean boolean54 = datasetRenderingOrder32.equals((java.lang.Object) legendItem46);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str33.equals("DatasetRenderingOrder.FORWARD"));
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(attributedString53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition0 = new org.jfree.chart.labels.ItemLabelPosition();
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        java.awt.Shape shape29 = lineAndShapeRenderer2.getBaseLegendShape();
        java.awt.Shape shape33 = lineAndShapeRenderer2.getItemShape((int) (byte) 100, (-14336), true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator37 = lineAndShapeRenderer2.getItemLabelGenerator((-14336), (int) ' ', true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation38 = null;
        boolean boolean39 = lineAndShapeRenderer2.removeAnnotation(categoryAnnotation38);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier40 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke41 = defaultDrawingSupplier40.getNextStroke();
        java.awt.Paint paint42 = defaultDrawingSupplier40.getNextFillPaint();
        lineAndShapeRenderer2.setBaseFillPaint(paint42);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(shape29);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNull(categoryItemLabelGenerator37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(paint42);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis2.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D8, rectangleEdge9);
        int int11 = categoryAxis2.getCategoryLabelPositionOffset();
        categoryAxis2.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis14, categoryItemRenderer15);
        java.awt.Paint paint17 = categoryPlot16.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = categoryPlot16.removeDomainMarker(marker18, layer19);
        boolean boolean21 = categoryPlot16.isRangeMinorGridlinesVisible();
        boolean boolean22 = abstractCategoryDataset0.hasListener((java.util.EventListener) categoryPlot16);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot16.getDomainMarkers(layer23);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder25 = categoryPlot16.getDatasetRenderingOrder();
        categoryPlot16.setRangeGridlinesVisible(false);
        boolean boolean28 = categoryPlot16.isRangeZoomable();
        float float29 = categoryPlot16.getBackgroundAlpha();
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNotNull(datasetRenderingOrder25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 1.0f + "'", float29 == 1.0f);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("SortOrder.ASCENDING", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        java.awt.Font font28 = lineAndShapeRenderer2.getBaseItemLabelFont();
        boolean boolean29 = lineAndShapeRenderer2.getAutoPopulateSeriesShape();
        java.lang.Boolean boolean31 = lineAndShapeRenderer2.getSeriesCreateEntities((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNull(boolean31);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        java.awt.Shape shape29 = lineAndShapeRenderer2.getBaseLegendShape();
        java.awt.Shape shape33 = lineAndShapeRenderer2.getItemShape((int) (byte) 100, (-14336), true);
        lineAndShapeRenderer2.setAutoPopulateSeriesShape(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator36 = lineAndShapeRenderer2.getLegendItemLabelGenerator();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator40 = lineAndShapeRenderer2.getURLGenerator((int) (short) 1, (-16777216), false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(shape29);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator36);
        org.junit.Assert.assertNull(categoryURLGenerator40);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        categoryPlot15.addChangeListener(plotChangeListener16);
        java.awt.Image image18 = categoryPlot15.getBackgroundImage();
        categoryPlot15.setAnchorValue(4.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNull(image18);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator5, true);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator8 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        lineAndShapeRenderer2.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = lineAndShapeRenderer2.getBasePositiveItemLabelPosition();
        org.junit.Assert.assertNotNull(itemLabelPosition10);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        boolean boolean5 = lineAndShapeRenderer2.getBaseShapesFilled();
        java.lang.Boolean boolean7 = lineAndShapeRenderer2.getSeriesCreateEntities(2);
        lineAndShapeRenderer2.setAutoPopulateSeriesOutlinePaint(false);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = null;
        double double19 = categoryAxis11.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D17, rectangleEdge18);
        int int20 = categoryAxis11.getCategoryLabelPositionOffset();
        categoryAxis11.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis23, categoryItemRenderer24);
        org.jfree.chart.event.PlotChangeListener plotChangeListener26 = null;
        categoryPlot25.addChangeListener(plotChangeListener26);
        boolean boolean28 = lineAndShapeRenderer2.hasListener((java.util.EventListener) plotChangeListener26);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = lineAndShapeRenderer2.getNegativeItemLabelPosition((int) (short) 10, (int) '4', true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 4 + "'", int20 == 4);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        categoryPlot15.addChangeListener(plotChangeListener16);
        categoryPlot15.setDomainCrosshairColumnKey((java.lang.Comparable) 5, false);
        categoryPlot15.mapDatasetToRangeAxis(0, 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot15.getDomainAxisEdge();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer26 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj27 = standardGradientPaintTransformer26.clone();
        boolean boolean28 = categoryAxis25.equals((java.lang.Object) standardGradientPaintTransformer26);
        boolean boolean29 = categoryAxis25.isMinorTickMarksVisible();
        java.util.List list30 = categoryPlot15.getCategoriesForAxis(categoryAxis25);
        categoryAxis25.configure();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(obj27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(list30);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "");
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape7);
        chartEntity6.setArea(shape7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape7, (java.awt.Paint) color10);
        legendItem11.setURLText("{0}");
        org.jfree.chart.renderer.RenderAttributes renderAttributes15 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Color color17 = java.awt.Color.blue;
        renderAttributes15.setSeriesFillPaint(0, (java.awt.Paint) color17);
        legendItem11.setLinePaint((java.awt.Paint) color17);
        java.text.AttributedString attributedString20 = legendItem11.getAttributedLabel();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(attributedString20);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        java.awt.Font font5 = lineAndShapeRenderer2.getBaseItemLabelFont();
        java.lang.Boolean boolean7 = lineAndShapeRenderer2.getSeriesVisible((-14336));
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker25 = null;
        org.jfree.chart.util.Layer layer26 = null;
        boolean boolean27 = categoryPlot23.removeDomainMarker(marker25, layer26);
        org.jfree.chart.util.Layer layer28 = null;
        java.util.Collection collection29 = categoryPlot23.getRangeMarkers(layer28);
        java.awt.Font font30 = categoryPlot23.getNoDataMessageFont();
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        categoryPlot23.setRangeMinorGridlinePaint((java.awt.Paint) color31);
        lineAndShapeRenderer2.setBaseLegendTextPaint((java.awt.Paint) color31);
        boolean boolean34 = lineAndShapeRenderer2.getAutoPopulateSeriesPaint();
        boolean boolean35 = lineAndShapeRenderer2.getBaseCreateEntities();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(collection29);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMinorTickMarkInsideLength();
        boolean boolean2 = categoryAxis0.isMinorTickMarksVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis4.setLabelURL("");
        categoryAxis4.setAxisLineVisible(true);
        java.lang.String str9 = categoryAxis4.getLabelToolTip();
        java.awt.Font font11 = categoryAxis4.getTickLabelFont((java.lang.Comparable) "poly");
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 0L, font11);
        categoryAxis0.setVisible(true);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis2.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D8, rectangleEdge9);
        int int11 = categoryAxis2.getCategoryLabelPositionOffset();
        categoryAxis2.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis14, categoryItemRenderer15);
        java.awt.Paint paint17 = categoryPlot16.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = categoryPlot16.removeDomainMarker(marker18, layer19);
        boolean boolean21 = categoryPlot16.isRangeMinorGridlinesVisible();
        boolean boolean22 = abstractCategoryDataset0.hasListener((java.util.EventListener) categoryPlot16);
        categoryPlot16.setRangeMinorGridlinesVisible(false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int1 = defaultCategoryDataset0.getRowCount();
        java.lang.Object obj2 = defaultCategoryDataset0.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.renderer.RenderAttributes renderAttributes4 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint6 = renderAttributes4.getSeriesOutlinePaint((int) '4');
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        renderAttributes4.setDefaultOutlinePaint(paint7);
        boolean boolean9 = textAnchor2.equals((java.lang.Object) renderAttributes4);
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor2, textAnchor10, 4.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.INSIDE9" + "'", str1.equals("ItemLabelAnchor.INSIDE9"));
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(textAnchor10);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor29 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor30 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor29, textAnchor30);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj34 = standardGradientPaintTransformer33.clone();
        boolean boolean35 = categoryAxis32.equals((java.lang.Object) standardGradientPaintTransformer33);
        boolean boolean36 = itemLabelPosition31.equals((java.lang.Object) boolean35);
        double double37 = itemLabelPosition31.getAngle();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor38 = itemLabelPosition31.getItemLabelAnchor();
        lineAndShapeRenderer2.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition31);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator41 = null;
        lineAndShapeRenderer2.setSeriesURLGenerator(1, categoryURLGenerator41);
        java.awt.Paint paint44 = lineAndShapeRenderer2.getSeriesPaint((int) (byte) 1);
        boolean boolean46 = lineAndShapeRenderer2.isSeriesVisible((int) '4');
        org.jfree.data.KeyedObjects2D keyedObjects2D47 = new org.jfree.data.KeyedObjects2D();
        java.awt.Color color48 = java.awt.Color.BLACK;
        boolean boolean49 = keyedObjects2D47.equals((java.lang.Object) color48);
        lineAndShapeRenderer2.setBaseOutlinePaint((java.awt.Paint) color48);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator52 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        java.lang.Object obj53 = standardCategorySeriesLabelGenerator52.clone();
        lineAndShapeRenderer2.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator52);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator55 = lineAndShapeRenderer2.getLegendItemToolTipGenerator();
        lineAndShapeRenderer2.setDefaultEntityRadius(2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(itemLabelAnchor29);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor38);
        org.junit.Assert.assertNull(paint44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(obj53);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator55);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        categoryPlot15.addChangeListener(plotChangeListener16);
        categoryPlot15.setDomainCrosshairColumnKey((java.lang.Comparable) 5, false);
        categoryPlot15.mapDatasetToRangeAxis(0, 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot15.getDomainAxisEdge();
        int int25 = categoryPlot15.getWeight();
        float float26 = categoryPlot15.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMinorTickMarkInsideLength();
        boolean boolean2 = categoryAxis0.isMinorTickMarksVisible();
        categoryAxis0.setLabelURL("hi!");
        float float5 = categoryAxis0.getTickMarkInsideLength();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = abstractCategoryDataset0.hasListener(eventListener1);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener3 = null;
        abstractCategoryDataset0.removeChangeListener(datasetChangeListener3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = categoryAxis6.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D12, rectangleEdge13);
        int int15 = categoryAxis6.getCategoryLabelPositionOffset();
        categoryAxis6.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis18, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeCrosshairPaint();
        int int22 = categoryPlot20.getWeight();
        abstractCategoryDataset0.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot20);
        java.util.EventListener eventListener24 = null;
        boolean boolean25 = abstractCategoryDataset0.hasListener(eventListener24);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        java.awt.Shape shape3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape3);
        chartEntity2.setArea(shape3);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = categoryAxis7.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D13, rectangleEdge14);
        int int16 = categoryAxis7.getCategoryLabelPositionOffset();
        categoryAxis7.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.util.ObjectList objectList24 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        float float27 = categoryAxis26.getMinorTickMarkInsideLength();
        boolean boolean28 = categoryAxis26.isMinorTickMarksVisible();
        categoryAxis26.setLabelURL("hi!");
        objectList24.set((int) (short) 10, (java.lang.Object) categoryAxis26);
        org.jfree.chart.plot.Plot plot32 = null;
        categoryAxis26.setPlot(plot32);
        categoryAxis26.setCategoryMargin((double) (-1));
        categoryPlot21.setDomainAxis((int) '#', categoryAxis26);
        categoryPlot21.configureRangeAxes();
        org.jfree.chart.entity.PlotEntity plotEntity38 = new org.jfree.chart.entity.PlotEntity(shape3, (org.jfree.chart.plot.Plot) categoryPlot21);
        org.jfree.chart.plot.Plot plot39 = null;
        try {
            org.jfree.chart.entity.PlotEntity plotEntity41 = new org.jfree.chart.entity.PlotEntity(shape3, plot39, "ItemLabelAnchor.OUTSIDE4");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.0f + "'", float27 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        int int17 = categoryPlot15.getWeight();
        boolean boolean18 = categoryPlot15.canSelectByPoint();
        java.awt.Paint paint19 = categoryPlot15.getRangeZeroBaselinePaint();
        java.awt.Paint paint20 = categoryPlot15.getRangeMinorGridlinePaint();
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.chart.plot.CategoryCrosshairState categoryCrosshairState25 = null;
        boolean boolean26 = categoryPlot15.render(graphics2D21, rectangle2D22, 5, plotRenderingInfo24, categoryCrosshairState25);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        boolean boolean5 = lineAndShapeRenderer2.getBaseShapesFilled();
        java.lang.Boolean boolean7 = lineAndShapeRenderer2.getSeriesLinesVisible(100);
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = lineAndShapeRenderer2.getSelectedItemAttributes();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator9);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertNotNull(renderAttributes8);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        java.awt.Shape shape29 = lineAndShapeRenderer2.getBaseLegendShape();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier30 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke31 = defaultDrawingSupplier30.getNextStroke();
        java.awt.Paint paint32 = defaultDrawingSupplier30.getNextFillPaint();
        lineAndShapeRenderer2.setBaseFillPaint(paint32);
        boolean boolean35 = lineAndShapeRenderer2.isSeriesVisible((int) (byte) 100);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = null;
        double double46 = categoryAxis38.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D44, rectangleEdge45);
        int int47 = categoryAxis38.getCategoryLabelPositionOffset();
        categoryAxis38.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis50, categoryItemRenderer51);
        java.awt.Paint paint53 = categoryPlot52.getRangeCrosshairPaint();
        int int54 = categoryPlot52.getWeight();
        java.lang.Comparable comparable55 = null;
        categoryPlot52.setDomainCrosshairRowKey(comparable55, true);
        org.jfree.chart.axis.AxisSpace axisSpace58 = categoryPlot52.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer60 = null;
        java.util.Collection collection61 = categoryPlot52.getRangeMarkers((-2), layer60);
        java.awt.geom.Rectangle2D rectangle2D62 = null;
        try {
            lineAndShapeRenderer2.drawBackground(graphics2D36, categoryPlot52, rectangle2D62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(shape29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 4 + "'", int47 == 4);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNull(axisSpace58);
        org.junit.Assert.assertNull(collection61);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        boolean boolean5 = lineAndShapeRenderer2.getBaseShapesFilled();
        java.lang.Boolean boolean7 = lineAndShapeRenderer2.getSeriesLinesVisible(100);
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = lineAndShapeRenderer2.getSelectedItemAttributes();
        lineAndShapeRenderer2.setSeriesShapesVisible((int) (byte) 0, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        lineAndShapeRenderer2.setSeriesItemLabelGenerator((int) (short) 0, categoryItemLabelGenerator13, true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertNotNull(renderAttributes8);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        java.awt.Stroke stroke17 = categoryPlot15.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot15.zoomRangeAxes((double) (short) -1, plotRenderingInfo19, point2D20, false);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot15.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot15.getDomainAxis();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(categoryAxis24);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.lang.Boolean boolean2 = booleanList0.getBoolean(5);
        java.lang.Boolean boolean4 = booleanList0.getBoolean((-254));
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNull(boolean4);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        double double16 = categoryPlot15.getAnchorValue();
        float float17 = categoryPlot15.getBackgroundImageAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot15.getDomainAxisLocation();
        org.jfree.chart.plot.Marker marker19 = null;
        org.jfree.chart.util.Layer layer20 = null;
        boolean boolean21 = categoryPlot15.removeDomainMarker(marker19, layer20);
        org.jfree.chart.axis.AxisSpace axisSpace22 = categoryPlot15.getFixedRangeAxisSpace();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.5f + "'", float17 == 0.5f);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(axisSpace22);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        int int17 = categoryPlot15.getWeight();
        boolean boolean18 = categoryPlot15.canSelectByPoint();
        float float19 = categoryPlot15.getBackgroundAlpha();
        java.awt.Shape shape24 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity26 = new org.jfree.chart.entity.ChartEntity(shape24, "");
        java.awt.Shape shape27 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape27);
        chartEntity26.setArea(shape27);
        java.awt.Color color30 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape27, (java.awt.Paint) color30);
        legendItem31.setURLText("{0}");
        org.jfree.chart.renderer.RenderAttributes renderAttributes35 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Color color37 = java.awt.Color.blue;
        renderAttributes35.setSeriesFillPaint(0, (java.awt.Paint) color37);
        legendItem31.setLinePaint((java.awt.Paint) color37);
        categoryPlot15.setBackgroundPaint((java.awt.Paint) color37);
        boolean boolean41 = categoryPlot15.getDrawSharedDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = categoryPlot15.getDomainAxis();
        java.awt.Stroke stroke43 = categoryPlot15.getRangeCrosshairStroke();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(categoryAxis42);
        org.junit.Assert.assertNotNull(stroke43);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator5, true);
        lineAndShapeRenderer2.setUseSeriesOffset(true);
        java.awt.Stroke stroke10 = lineAndShapeRenderer2.getBaseOutlineStroke();
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        java.awt.Font font28 = lineAndShapeRenderer2.getBaseItemLabelFont();
        java.awt.Paint paint29 = lineAndShapeRenderer2.getBaseLegendTextPaint();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator31 = lineAndShapeRenderer2.getSeriesItemLabelGenerator((-8323073));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertNull(categoryItemLabelGenerator31);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        org.jfree.chart.plot.Plot plot10 = categoryAxis0.getPlot();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNull(plot10);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        java.awt.Paint paint18 = categoryPlot15.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        categoryPlot15.setDataset(categoryDataset19);
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double23 = rectangleInsets21.calculateTopInset((double) 10);
        double double25 = rectangleInsets21.calculateLeftOutset((double) 100);
        double double26 = rectangleInsets21.getBottom();
        categoryPlot15.setAxisOffset(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        java.awt.Paint paint18 = categoryPlot15.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        categoryPlot15.setDataset(categoryDataset19);
        org.jfree.chart.LegendItemCollection legendItemCollection21 = categoryPlot15.getLegendItems();
        categoryPlot15.setCrosshairDatasetIndex(0);
        java.awt.Paint paint24 = categoryPlot15.getBackgroundPaint();
        categoryPlot15.setDomainCrosshairColumnKey((java.lang.Comparable) (-255));
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot15.getRangeAxisEdge();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(legendItemCollection21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis2.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D8, rectangleEdge9);
        int int11 = categoryAxis2.getCategoryLabelPositionOffset();
        categoryAxis2.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis14, categoryItemRenderer15);
        java.awt.Paint paint17 = categoryPlot16.getRangeCrosshairPaint();
        int int18 = categoryPlot16.getWeight();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        categoryPlot16.setRenderer(categoryItemRenderer19);
        categoryPlot16.clearRangeMarkers((-255));
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = categoryPlot16.getRangeMarkers((int) '4', layer24);
        boolean boolean26 = defaultCategoryDataset0.equals((java.lang.Object) '4');
        java.lang.Comparable comparable28 = null;
        try {
            java.lang.Number number29 = defaultCategoryDataset0.getValue((java.lang.Comparable) 100.0d, comparable28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'columnKey' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator5, true);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator8 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        lineAndShapeRenderer2.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator8);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = lineAndShapeRenderer2.getLegendItemToolTipGenerator();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = categoryAxis12.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D18, rectangleEdge19);
        int int21 = categoryAxis12.getCategoryLabelPositionOffset();
        categoryAxis12.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis24, categoryItemRenderer25);
        java.awt.Paint paint27 = categoryPlot26.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor28 = categoryPlot26.getDomainGridlinePosition();
        org.jfree.data.KeyedObjects2D keyedObjects2D29 = new org.jfree.data.KeyedObjects2D();
        java.awt.Color color30 = java.awt.Color.BLACK;
        boolean boolean31 = keyedObjects2D29.equals((java.lang.Object) color30);
        int int32 = color30.getTransparency();
        categoryPlot26.setRangeGridlinePaint((java.awt.Paint) color30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        categoryPlot26.zoomRangeAxes((double) 0L, plotRenderingInfo35, point2D36, true);
        lineAndShapeRenderer2.setPlot(categoryPlot26);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis();
        float float41 = categoryAxis40.getMinorTickMarkInsideLength();
        boolean boolean42 = categoryAxis40.isMinorTickMarksVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis44.setLabelURL("");
        categoryAxis44.setAxisLineVisible(true);
        java.lang.String str49 = categoryAxis44.getLabelToolTip();
        java.awt.Font font51 = categoryAxis44.getTickLabelFont((java.lang.Comparable) "poly");
        categoryAxis40.setTickLabelFont((java.lang.Comparable) 0L, font51);
        lineAndShapeRenderer2.setBaseItemLabelFont(font51);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator10);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(categoryAnchor28);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 0.0f + "'", float41 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNotNull(font51);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        java.awt.Shape shape29 = lineAndShapeRenderer2.getBaseLegendShape();
        java.awt.Shape shape33 = lineAndShapeRenderer2.getItemShape((int) (byte) 100, (-14336), true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator37 = lineAndShapeRenderer2.getItemLabelGenerator((-14336), (int) ' ', true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation38 = null;
        boolean boolean39 = lineAndShapeRenderer2.removeAnnotation(categoryAnnotation38);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator40 = lineAndShapeRenderer2.getBaseItemLabelGenerator();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(shape29);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNull(categoryItemLabelGenerator37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator40);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.SelectableValue selectableValue1 = new org.jfree.data.SelectableValue((java.lang.Number) (byte) 10);
        boolean boolean2 = selectableValue1.isSelected();
        java.lang.Number number3 = selectableValue1.getValue();
        selectableValue1.setSelected(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + (byte) 10 + "'", number3.equals((byte) 10));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        java.awt.Stroke stroke17 = categoryPlot15.getDomainGridlineStroke();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str19 = datasetRenderingOrder18.toString();
        categoryPlot15.setDatasetRenderingOrder(datasetRenderingOrder18);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str19.equals("DatasetRenderingOrder.FORWARD"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = keyedObjects2D0.clone();
        boolean boolean3 = keyedObjects2D0.equals((java.lang.Object) (-1.0f));
        int int4 = keyedObjects2D0.getRowCount();
        int int5 = keyedObjects2D0.getRowCount();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMinorTickMarkInsideLength();
        boolean boolean2 = categoryAxis0.isMinorTickMarksVisible();
        boolean boolean3 = categoryAxis0.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot4 = null;
        categoryAxis0.setPlot(plot4);
        java.awt.Paint paint6 = categoryAxis0.getTickMarkPaint();
        categoryAxis0.setLabelAngle((double) (short) 1);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int11 = color10.getAlpha();
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator15 = new org.jfree.chart.util.DefaultShadowGenerator((int) (short) 0, color10, (-1.0f), 10, (double) (short) 1);
        java.awt.Color color16 = defaultShadowGenerator15.getShadowColor();
        int int17 = defaultShadowGenerator15.calculateOffsetX();
        int int18 = defaultShadowGenerator15.getShadowSize();
        boolean boolean19 = categoryAxis0.equals((java.lang.Object) int18);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 5 + "'", int17 == 5);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        java.awt.Font font28 = lineAndShapeRenderer2.getBaseItemLabelFont();
        java.awt.Font font30 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        lineAndShapeRenderer2.setSeriesItemLabelFont((int) 'a', font30, false);
        lineAndShapeRenderer2.setBaseSeriesVisible(false, false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(font30);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        java.awt.Stroke stroke1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        boolean boolean2 = itemLabelAnchor0.equals((java.lang.Object) stroke1);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        int int17 = categoryPlot15.getWeight();
        java.lang.Comparable comparable18 = null;
        categoryPlot15.setDomainCrosshairRowKey(comparable18, true);
        org.jfree.chart.axis.AxisSpace axisSpace21 = categoryPlot15.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot15.getRangeMarkers((-2), layer23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        java.awt.geom.Point2D point2D28 = null;
        categoryPlot15.zoomRangeAxes((double) (-14336), (double) '4', plotRenderingInfo27, point2D28);
        org.jfree.chart.axis.AxisSpace axisSpace30 = categoryPlot15.getFixedDomainAxisSpace();
        java.awt.Shape shape36 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity38 = new org.jfree.chart.entity.ChartEntity(shape36, "");
        java.awt.Shape shape39 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent40 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape39);
        chartEntity38.setArea(shape39);
        java.awt.Color color42 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem43 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape39, (java.awt.Paint) color42);
        legendItem43.setURLText("{0}");
        java.awt.Stroke stroke46 = legendItem43.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart47 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent48 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendItem43, jFreeChart47);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset49 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset50 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = null;
        double double59 = categoryAxis51.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D57, rectangleEdge58);
        int int60 = categoryAxis51.getCategoryLabelPositionOffset();
        categoryAxis51.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis63 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer64 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot65 = new org.jfree.chart.plot.CategoryPlot(categoryDataset50, categoryAxis51, valueAxis63, categoryItemRenderer64);
        java.awt.Paint paint66 = categoryPlot65.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker67 = null;
        org.jfree.chart.util.Layer layer68 = null;
        boolean boolean69 = categoryPlot65.removeDomainMarker(marker67, layer68);
        boolean boolean70 = categoryPlot65.isRangeMinorGridlinesVisible();
        boolean boolean71 = abstractCategoryDataset49.hasListener((java.util.EventListener) categoryPlot65);
        legendItem43.setDataset((org.jfree.data.general.Dataset) abstractCategoryDataset49);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset73 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list74 = defaultCategoryDataset73.getRowKeys();
        abstractCategoryDataset49.setSelectionState((org.jfree.data.category.CategoryDatasetSelectionState) defaultCategoryDataset73);
        categoryPlot15.setDataset((int) 'a', (org.jfree.data.category.CategoryDataset) defaultCategoryDataset73);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(axisSpace21);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNull(axisSpace30);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 4 + "'", int60 == 4);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(list74);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        legendItem1.setLineVisible(false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator5, true);
        java.awt.Font font9 = lineAndShapeRenderer2.lookupLegendTextFont((int) (byte) 0);
        java.awt.Color color10 = java.awt.Color.red;
        lineAndShapeRenderer2.setBaseItemLabelPaint((java.awt.Paint) color10);
        lineAndShapeRenderer2.setUseOutlinePaint(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = lineAndShapeRenderer2.getSeriesToolTipGenerator((int) (short) -1);
        lineAndShapeRenderer2.setUseOutlinePaint(true);
        java.awt.Paint paint18 = lineAndShapeRenderer2.getBasePaint();
        org.junit.Assert.assertNull(font9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator5, true);
        java.lang.Boolean boolean9 = lineAndShapeRenderer2.getSeriesVisible((int) (short) 100);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator10 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        lineAndShapeRenderer2.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator10);
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        lineAndShapeRenderer2.setBaseLegendTextPaint(paint12);
        boolean boolean14 = lineAndShapeRenderer2.getDrawOutlines();
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape8, "");
        java.awt.Shape shape11 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape11);
        chartEntity10.setArea(shape11);
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape11, (java.awt.Paint) color14);
        legendItem15.setURLText("");
        boolean boolean18 = legendItem15.isShapeFilled();
        java.awt.Shape shape19 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        legendItem15.setShape(shape19);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        double double30 = categoryAxis22.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D28, rectangleEdge29);
        int int31 = categoryAxis22.getCategoryLabelPositionOffset();
        categoryAxis22.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis34, categoryItemRenderer35);
        java.awt.Paint paint37 = categoryPlot36.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor38 = categoryPlot36.getDomainGridlinePosition();
        java.awt.Paint paint39 = categoryPlot36.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset40 = null;
        categoryPlot36.setDataset(categoryDataset40);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot36.getRangeAxisEdge();
        boolean boolean43 = categoryPlot36.isRangeGridlinesVisible();
        org.jfree.chart.renderer.RenderAttributes renderAttributes45 = new org.jfree.chart.renderer.RenderAttributes(false);
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = null;
        double double55 = categoryAxis47.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D53, rectangleEdge54);
        int int56 = categoryAxis47.getCategoryLabelPositionOffset();
        categoryAxis47.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis59 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer60 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot61 = new org.jfree.chart.plot.CategoryPlot(categoryDataset46, categoryAxis47, valueAxis59, categoryItemRenderer60);
        java.awt.Paint paint62 = categoryPlot61.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor63 = categoryPlot61.getDomainGridlinePosition();
        java.awt.Paint paint64 = categoryPlot61.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset65 = null;
        categoryPlot61.setDataset(categoryDataset65);
        org.jfree.chart.LegendItemCollection legendItemCollection67 = categoryPlot61.getLegendItems();
        java.awt.Stroke stroke68 = categoryPlot61.getRangeGridlineStroke();
        renderAttributes45.setDefaultStroke(stroke68);
        categoryPlot36.setRangeCrosshairStroke(stroke68);
        java.awt.Paint paint71 = null;
        try {
            org.jfree.chart.LegendItem legendItem72 = new org.jfree.chart.LegendItem(attributedString0, "CategoryAnchor.START", "ItemLabelAnchor.INSIDE10", "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", shape19, stroke68, paint71);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 4 + "'", int31 == 4);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(categoryAnchor38);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 4 + "'", int56 == 4);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNotNull(categoryAnchor63);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(legendItemCollection67);
        org.junit.Assert.assertNotNull(stroke68);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis2.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D8, rectangleEdge9);
        int int11 = categoryAxis2.getCategoryLabelPositionOffset();
        categoryAxis2.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis14, categoryItemRenderer15);
        java.awt.Paint paint17 = categoryPlot16.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = categoryPlot16.removeDomainMarker(marker18, layer19);
        boolean boolean21 = categoryPlot16.isRangeMinorGridlinesVisible();
        boolean boolean22 = abstractCategoryDataset0.hasListener((java.util.EventListener) categoryPlot16);
        org.jfree.chart.axis.AxisLocation axisLocation24 = categoryPlot16.getDomainAxisLocation(4);
        org.jfree.chart.axis.AxisLocation axisLocation25 = axisLocation24.getOpposite();
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(axisLocation25);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint33 = renderAttributes31.getSeriesOutlinePaint((int) '4');
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes31.setDefaultStroke(stroke34);
        lineAndShapeRenderer2.setSeriesStroke(0, stroke34, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator38 = null;
        lineAndShapeRenderer2.setBaseItemLabelGenerator(categoryItemLabelGenerator38);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator5, true);
        java.awt.Font font9 = lineAndShapeRenderer2.lookupLegendTextFont((int) (byte) 0);
        lineAndShapeRenderer2.setUseSeriesOffset(true);
        lineAndShapeRenderer2.setSeriesLinesVisible(0, (java.lang.Boolean) true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer18.setBaseItemLabelsVisible(false);
        java.awt.Font font21 = lineAndShapeRenderer18.getBaseItemLabelFont();
        lineAndShapeRenderer2.setSeriesItemLabelFont(255, font21);
        org.junit.Assert.assertNull(font9);
        org.junit.Assert.assertNotNull(font21);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        java.awt.Stroke stroke17 = categoryPlot15.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot15.zoomRangeAxes((double) (short) -1, plotRenderingInfo19, point2D20, false);
        org.jfree.chart.util.SortOrder sortOrder23 = categoryPlot15.getRowRenderingOrder();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot15.zoomRangeAxes((double) 255, plotRenderingInfo25, point2D26);
        org.jfree.chart.plot.PlotOrientation plotOrientation28 = categoryPlot15.getOrientation();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(sortOrder23);
        org.junit.Assert.assertNotNull(plotOrientation28);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator5, true);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator8 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        lineAndShapeRenderer2.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator8);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = lineAndShapeRenderer2.getLegendItemToolTipGenerator();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        double double20 = categoryAxis12.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D18, rectangleEdge19);
        int int21 = categoryAxis12.getCategoryLabelPositionOffset();
        categoryAxis12.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis24, categoryItemRenderer25);
        java.awt.Paint paint27 = categoryPlot26.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor28 = categoryPlot26.getDomainGridlinePosition();
        org.jfree.data.KeyedObjects2D keyedObjects2D29 = new org.jfree.data.KeyedObjects2D();
        java.awt.Color color30 = java.awt.Color.BLACK;
        boolean boolean31 = keyedObjects2D29.equals((java.lang.Object) color30);
        int int32 = color30.getTransparency();
        categoryPlot26.setRangeGridlinePaint((java.awt.Paint) color30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        categoryPlot26.zoomRangeAxes((double) 0L, plotRenderingInfo35, point2D36, true);
        lineAndShapeRenderer2.setPlot(categoryPlot26);
        org.jfree.chart.util.Layer layer40 = null;
        java.util.Collection collection41 = categoryPlot26.getRangeMarkers(layer40);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset43 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list44 = defaultCategoryDataset43.getRowKeys();
        try {
            categoryPlot26.mapDatasetToRangeAxes((int) 'a', list44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categorySeriesLabelGenerator10);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 4 + "'", int21 == 4);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(categoryAnchor28);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNull(collection41);
        org.junit.Assert.assertNotNull(list44);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean19 = categoryPlot15.removeDomainMarker(marker17, layer18);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot15.getRangeMarkers(layer20);
        java.awt.Font font22 = categoryPlot15.getNoDataMessageFont();
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        categoryPlot15.setRangeMinorGridlinePaint((java.awt.Paint) color23);
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = null;
        org.jfree.chart.util.Layer layer27 = null;
        try {
            categoryPlot15.addDomainMarker(100, categoryMarker26, layer27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(color23);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = abstractCategoryDataset0.hasListener(eventListener1);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener3 = null;
        abstractCategoryDataset0.removeChangeListener(datasetChangeListener3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = categoryAxis6.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D12, rectangleEdge13);
        int int15 = categoryAxis6.getCategoryLabelPositionOffset();
        categoryAxis6.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis18, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeCrosshairPaint();
        int int22 = categoryPlot20.getWeight();
        abstractCategoryDataset0.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot20);
        categoryPlot20.clearSelection();
        java.awt.Color color27 = java.awt.Color.getColor("ItemLabelAnchor.INSIDE6", (int) (byte) -1);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset28 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.event.DatasetChangeListener datasetChangeListener29 = null;
        abstractCategoryDataset28.addChangeListener(datasetChangeListener29);
        java.lang.Object obj31 = abstractCategoryDataset28.clone();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo32 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent33 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) color27, (org.jfree.data.general.Dataset) abstractCategoryDataset28, datasetChangeInfo32);
        categoryPlot20.setOutlinePaint((java.awt.Paint) color27);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(obj31);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        int int17 = categoryPlot15.getWeight();
        java.lang.Comparable comparable18 = null;
        categoryPlot15.setDomainCrosshairRowKey(comparable18, true);
        org.jfree.chart.util.SortOrder sortOrder21 = categoryPlot15.getRowRenderingOrder();
        java.awt.Font font22 = categoryPlot15.getNoDataMessageFont();
        int int23 = categoryPlot15.getBackgroundImageAlignment();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(sortOrder21);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 15 + "'", int23 == 15);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Color color33 = java.awt.Color.blue;
        renderAttributes31.setSeriesFillPaint(0, (java.awt.Paint) color33);
        java.awt.Color color35 = java.awt.Color.GRAY;
        renderAttributes31.setDefaultOutlinePaint((java.awt.Paint) color35);
        java.awt.Stroke stroke38 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes31.setSeriesStroke((int) (short) 1, stroke38);
        lineAndShapeRenderer2.setSeriesStroke(100, stroke38, false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(stroke38);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        boolean boolean5 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = null;
        try {
            lineAndShapeRenderer2.setSeriesItemLabelGenerator((-1), categoryItemLabelGenerator7, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.util.ObjectList objectList18 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        float float21 = categoryAxis20.getMinorTickMarkInsideLength();
        boolean boolean22 = categoryAxis20.isMinorTickMarksVisible();
        categoryAxis20.setLabelURL("hi!");
        objectList18.set((int) (short) 10, (java.lang.Object) categoryAxis20);
        org.jfree.chart.plot.Plot plot26 = null;
        categoryAxis20.setPlot(plot26);
        categoryAxis20.setCategoryMargin((double) (-1));
        categoryPlot15.setDomainAxis((int) '#', categoryAxis20);
        categoryPlot15.configureRangeAxes();
        org.jfree.chart.plot.Marker marker32 = null;
        boolean boolean33 = categoryPlot15.removeDomainMarker(marker32);
        org.jfree.chart.event.AnnotationChangeEvent annotationChangeEvent34 = null;
        categoryPlot15.annotationChanged(annotationChangeEvent34);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "");
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape7);
        chartEntity6.setArea(shape7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape7, (java.awt.Paint) color10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis13.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D19, rectangleEdge20);
        int int22 = categoryAxis13.getCategoryLabelPositionOffset();
        categoryAxis13.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis25, categoryItemRenderer26);
        java.awt.Paint paint28 = categoryPlot27.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor29 = categoryPlot27.getDomainGridlinePosition();
        org.jfree.chart.entity.PlotEntity plotEntity30 = new org.jfree.chart.entity.PlotEntity(shape7, (org.jfree.chart.plot.Plot) categoryPlot27);
        java.lang.String str31 = plotEntity30.getToolTipText();
        java.lang.String str32 = plotEntity30.toString();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 4 + "'", int22 == 4);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(categoryAnchor29);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "PlotEntity: tooltip = null" + "'", str32.equals("PlotEntity: tooltip = null"));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean19 = categoryPlot15.removeDomainMarker(marker17, layer18);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot15.getRangeMarkers(layer20);
        boolean boolean22 = categoryPlot15.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        int int17 = categoryPlot15.getWeight();
        boolean boolean18 = categoryPlot15.canSelectByPoint();
        float float19 = categoryPlot15.getBackgroundAlpha();
        java.awt.Shape shape24 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity26 = new org.jfree.chart.entity.ChartEntity(shape24, "");
        java.awt.Shape shape27 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape27);
        chartEntity26.setArea(shape27);
        java.awt.Color color30 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape27, (java.awt.Paint) color30);
        legendItem31.setURLText("{0}");
        org.jfree.chart.renderer.RenderAttributes renderAttributes35 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Color color37 = java.awt.Color.blue;
        renderAttributes35.setSeriesFillPaint(0, (java.awt.Paint) color37);
        legendItem31.setLinePaint((java.awt.Paint) color37);
        categoryPlot15.setBackgroundPaint((java.awt.Paint) color37);
        boolean boolean41 = categoryPlot15.getDrawSharedDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = categoryPlot15.getDomainAxis();
        java.awt.Paint paint43 = categoryPlot15.getRangeMinorGridlinePaint();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 1.0f + "'", float19 == 1.0f);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(categoryAxis42);
        org.junit.Assert.assertNotNull(paint43);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.setMaximumCategoryLabelLines(4);
        categoryAxis0.setLowerMargin(0.0d);
        double double14 = categoryAxis0.getFixedDimension();
        float float15 = categoryAxis0.getTickMarkOutsideLength();
        int int16 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font17 = categoryAxis0.getLabelFont();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 2.0f + "'", float15 == 2.0f);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        boolean boolean5 = lineAndShapeRenderer2.getBaseShapesFilled();
        java.lang.Boolean boolean7 = lineAndShapeRenderer2.getSeriesLinesVisible(100);
        int int8 = lineAndShapeRenderer2.getPassCount();
        boolean boolean9 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean19 = categoryPlot15.removeDomainMarker(marker17, layer18);
        boolean boolean20 = categoryPlot15.isRangeMinorGridlinesVisible();
        java.awt.Stroke stroke21 = categoryPlot15.getRangeZeroBaselineStroke();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font11 = null;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 1, font11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double14 = rectangleInsets13.getRight();
        categoryAxis0.setLabelInsets(rectangleInsets13, true);
        org.jfree.chart.util.UnitType unitType17 = rectangleInsets13.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets(unitType17, 10.0d, (double) 0, (double) (-1L), (-1.0d));
        java.awt.Shape shape27 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity29 = new org.jfree.chart.entity.ChartEntity(shape27, "");
        java.awt.Shape shape30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape30);
        chartEntity29.setArea(shape30);
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape30, (java.awt.Paint) color33);
        legendItem34.setURLText("");
        boolean boolean37 = unitType17.equals((java.lang.Object) legendItem34);
        legendItem34.setToolTipText("4,0,2,2,0,4,-2,2,-4,0,-2,-2,0,-4,2,-2,4,0,4,0");
        java.lang.String str40 = legendItem34.getDescription();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(unitType17);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "ItemLabelAnchor.INSIDE6" + "'", str40.equals("ItemLabelAnchor.INSIDE6"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Shape shape4 = renderAttributes1.getItemShape((-16777216), 0);
        java.awt.Shape shape6 = renderAttributes1.getSeriesShape(0);
        org.junit.Assert.assertNull(shape4);
        org.junit.Assert.assertNull(shape6);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint33 = renderAttributes31.getSeriesOutlinePaint((int) '4');
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes31.setDefaultStroke(stroke34);
        lineAndShapeRenderer2.setSeriesStroke(0, stroke34, false);
        boolean boolean40 = lineAndShapeRenderer2.getItemShapeVisible((-16777216), 8);
        lineAndShapeRenderer2.setSeriesShapesFilled((int) (byte) 100, (java.lang.Boolean) true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier44 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint45 = defaultDrawingSupplier44.getNextFillPaint();
        java.awt.Shape shape46 = defaultDrawingSupplier44.getNextShape();
        lineAndShapeRenderer2.setBaseLegendShape(shape46);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(shape46);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.KeyedObject keyedObject2 = new org.jfree.data.KeyedObject((java.lang.Comparable) false, (java.lang.Object) "ChartChangeEventType.GENERAL");
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = null;
        double double12 = categoryAxis4.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D10, rectangleEdge11);
        int int13 = categoryAxis4.getCategoryLabelPositionOffset();
        categoryAxis4.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis16, categoryItemRenderer17);
        java.awt.Paint paint19 = categoryPlot18.getRangeCrosshairPaint();
        int int20 = categoryPlot18.getWeight();
        java.lang.Comparable comparable21 = null;
        categoryPlot18.setDomainCrosshairRowKey(comparable21, true);
        categoryPlot18.clearAnnotations();
        java.awt.geom.GeneralPath generalPath25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.RenderingSource renderingSource27 = null;
        categoryPlot18.select(generalPath25, rectangle2D26, renderingSource27);
        java.awt.Stroke stroke29 = categoryPlot18.getOutlineStroke();
        keyedObject2.setObject((java.lang.Object) categoryPlot18);
        java.awt.Font font31 = categoryPlot18.getNoDataMessageFont();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot18.panDomainAxes((double) 8, plotRenderingInfo33, point2D34);
        categoryPlot18.setRangeZeroBaselineVisible(false);
        java.awt.Paint paint38 = categoryPlot18.getRangeGridlinePaint();
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        int int17 = categoryPlot15.getWeight();
        java.lang.Comparable comparable18 = null;
        categoryPlot15.setDomainCrosshairRowKey(comparable18, true);
        java.awt.Stroke stroke21 = categoryPlot15.getOutlineStroke();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator5, true);
        java.awt.Font font9 = lineAndShapeRenderer2.lookupLegendTextFont((int) (byte) 0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer12.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = null;
        lineAndShapeRenderer12.setBaseURLGenerator(categoryURLGenerator15, true);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator18 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        lineAndShapeRenderer12.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator18);
        lineAndShapeRenderer2.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator18);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = lineAndShapeRenderer2.getNegativeItemLabelPosition(1, 0, false);
        try {
            lineAndShapeRenderer2.setSeriesShapesVisible((-8323073), (java.lang.Boolean) true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(font9);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator5, true);
        java.awt.Font font9 = lineAndShapeRenderer2.lookupLegendTextFont((int) (byte) 0);
        boolean boolean10 = lineAndShapeRenderer2.getAutoPopulateSeriesFillPaint();
        org.junit.Assert.assertNull(font9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
        org.jfree.chart.text.TextAnchor textAnchor3 = itemLabelPosition2.getTextAnchor();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(textAnchor3);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        int int17 = categoryPlot15.getWeight();
        boolean boolean18 = categoryPlot15.canSelectByPoint();
        double double19 = categoryPlot15.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj2 = standardGradientPaintTransformer1.clone();
        boolean boolean3 = categoryAxis0.equals((java.lang.Object) standardGradientPaintTransformer1);
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryAxis0.setAxisLineStroke(stroke4);
        java.lang.Object obj6 = categoryAxis0.clone();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.setMaximumCategoryLabelLines(4);
        categoryAxis0.setLowerMargin(0.0d);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis0.getCategorySeriesMiddle((int) (byte) 1, (int) ' ', (int) (byte) 10, 0, 3.0d, rectangle2D19, rectangleEdge20);
        java.awt.Font font22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        categoryAxis0.setTickLabelFont(font22);
        double double24 = categoryAxis0.getCategoryMargin();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.2d + "'", double24 == 0.2d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator5, true);
        java.lang.Boolean boolean9 = lineAndShapeRenderer2.getSeriesVisible((int) (short) 100);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator10 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        lineAndShapeRenderer2.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator10);
        boolean boolean14 = lineAndShapeRenderer2.getItemShapeVisible((int) 'a', 10);
        boolean boolean18 = lineAndShapeRenderer2.isItemLabelVisible((-14336), 0, true);
        lineAndShapeRenderer2.setSeriesShapesVisible(0, (java.lang.Boolean) true);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        boolean boolean25 = categoryAxis24.isAxisLineVisible();
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int27 = color26.getBlue();
        float[] floatArray31 = new float[] { '#', (byte) 10, (short) 100 };
        float[] floatArray32 = color26.getColorComponents(floatArray31);
        categoryAxis24.setAxisLinePaint((java.awt.Paint) color26);
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        categoryAxis24.setTickMarkStroke(stroke34);
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.util.Layer layer37 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        try {
            lineAndShapeRenderer2.drawAnnotations(graphics2D22, rectangle2D23, categoryAxis24, valueAxis36, layer37, plotRenderingInfo38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis2.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D8, rectangleEdge9);
        int int11 = categoryAxis2.getCategoryLabelPositionOffset();
        categoryAxis2.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis14, categoryItemRenderer15);
        java.awt.Paint paint17 = categoryPlot16.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor18 = categoryPlot16.getDomainGridlinePosition();
        java.awt.Paint paint19 = categoryPlot16.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        categoryPlot16.setDataset(categoryDataset20);
        org.jfree.chart.renderer.RenderAttributes renderAttributes23 = new org.jfree.chart.renderer.RenderAttributes(false);
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = null;
        double double33 = categoryAxis25.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D31, rectangleEdge32);
        int int34 = categoryAxis25.getCategoryLabelPositionOffset();
        categoryAxis25.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis37, categoryItemRenderer38);
        java.awt.Paint paint40 = categoryPlot39.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor41 = categoryPlot39.getDomainGridlinePosition();
        java.awt.Paint paint42 = categoryPlot39.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset43 = null;
        categoryPlot39.setDataset(categoryDataset43);
        org.jfree.chart.LegendItemCollection legendItemCollection45 = categoryPlot39.getLegendItems();
        java.awt.Stroke stroke46 = categoryPlot39.getRangeGridlineStroke();
        renderAttributes23.setDefaultStroke(stroke46);
        categoryPlot16.setRangeGridlineStroke(stroke46);
        org.jfree.chart.entity.PlotEntity plotEntity49 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot16);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(categoryAnchor18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 4 + "'", int34 == 4);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(categoryAnchor41);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(legendItemCollection45);
        org.junit.Assert.assertNotNull(stroke46);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis2.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D8, rectangleEdge9);
        int int11 = categoryAxis2.getCategoryLabelPositionOffset();
        categoryAxis2.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis14, categoryItemRenderer15);
        java.awt.Paint paint17 = categoryPlot16.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = categoryPlot16.removeDomainMarker(marker18, layer19);
        boolean boolean21 = categoryPlot16.isRangeMinorGridlinesVisible();
        boolean boolean22 = abstractCategoryDataset0.hasListener((java.util.EventListener) categoryPlot16);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot16.getDomainMarkers(layer23);
        boolean boolean25 = categoryPlot16.isDomainPannable();
        categoryPlot16.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryPlot16.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = categoryPlot16.getDatasetRenderingOrder();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer33.setBaseItemLabelsVisible(false);
        boolean boolean36 = lineAndShapeRenderer33.getBaseShapesFilled();
        categoryPlot16.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer33);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator38 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        java.lang.Object obj39 = standardCategorySeriesLabelGenerator38.clone();
        lineAndShapeRenderer33.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator38);
        lineAndShapeRenderer33.setSeriesVisible((int) (short) 0, (java.lang.Boolean) true, true);
        java.awt.Shape shape49 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity51 = new org.jfree.chart.entity.ChartEntity(shape49, "");
        java.awt.Shape shape52 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent53 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape52);
        chartEntity51.setArea(shape52);
        java.awt.Color color55 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem56 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape52, (java.awt.Paint) color55);
        int int57 = color55.getBlue();
        int int58 = color55.getBlue();
        lineAndShapeRenderer33.setBaseItemLabelPaint((java.awt.Paint) color55, false);
        lineAndShapeRenderer33.setBaseSeriesVisibleInLegend(true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 64 + "'", int57 == 64);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 64 + "'", int58 == 64);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor29 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor30 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor29, textAnchor30);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj34 = standardGradientPaintTransformer33.clone();
        boolean boolean35 = categoryAxis32.equals((java.lang.Object) standardGradientPaintTransformer33);
        boolean boolean36 = itemLabelPosition31.equals((java.lang.Object) boolean35);
        double double37 = itemLabelPosition31.getAngle();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor38 = itemLabelPosition31.getItemLabelAnchor();
        lineAndShapeRenderer2.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition31);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator41 = null;
        lineAndShapeRenderer2.setSeriesURLGenerator(1, categoryURLGenerator41);
        java.awt.Paint paint44 = lineAndShapeRenderer2.getSeriesPaint((int) (byte) 1);
        boolean boolean46 = lineAndShapeRenderer2.isSeriesVisible((int) '4');
        org.jfree.data.KeyedObjects2D keyedObjects2D47 = new org.jfree.data.KeyedObjects2D();
        java.awt.Color color48 = java.awt.Color.BLACK;
        boolean boolean49 = keyedObjects2D47.equals((java.lang.Object) color48);
        lineAndShapeRenderer2.setBaseOutlinePaint((java.awt.Paint) color48);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator52 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        java.lang.Object obj53 = standardCategorySeriesLabelGenerator52.clone();
        lineAndShapeRenderer2.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator52);
        java.awt.Color color55 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        lineAndShapeRenderer2.setBaseFillPaint((java.awt.Paint) color55);
        boolean boolean57 = lineAndShapeRenderer2.getDrawOutlines();
        java.awt.Stroke stroke59 = lineAndShapeRenderer2.getSeriesOutlineStroke((int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(itemLabelAnchor29);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor38);
        org.junit.Assert.assertNull(paint44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(obj53);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNull(stroke59);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMinorTickMarkInsideLength();
        boolean boolean2 = categoryAxis0.isMinorTickMarksVisible();
        boolean boolean3 = categoryAxis0.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot4 = null;
        categoryAxis0.setPlot(plot4);
        java.awt.Paint paint6 = categoryAxis0.getTickMarkPaint();
        java.awt.Font font8 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) (byte) 10, font8);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.util.ObjectList objectList18 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        float float21 = categoryAxis20.getMinorTickMarkInsideLength();
        boolean boolean22 = categoryAxis20.isMinorTickMarksVisible();
        categoryAxis20.setLabelURL("hi!");
        objectList18.set((int) (short) 10, (java.lang.Object) categoryAxis20);
        org.jfree.chart.plot.Plot plot26 = null;
        categoryAxis20.setPlot(plot26);
        categoryAxis20.setCategoryMargin((double) (-1));
        categoryPlot15.setDomainAxis((int) '#', categoryAxis20);
        categoryPlot15.setDomainCrosshairRowKey((java.lang.Comparable) 5, true);
        categoryPlot15.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.Marker marker37 = null;
        org.jfree.chart.util.Layer layer38 = null;
        try {
            categoryPlot15.addRangeMarker((int) (short) 10, marker37, layer38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.KeyedObject keyedObject2 = new org.jfree.data.KeyedObject((java.lang.Comparable) false, (java.lang.Object) "ChartChangeEventType.GENERAL");
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.renderer.RenderAttributes renderAttributes5 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint7 = renderAttributes5.getSeriesOutlinePaint((int) '4');
        java.awt.Paint paint8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        renderAttributes5.setDefaultOutlinePaint(paint8);
        boolean boolean10 = textAnchor3.equals((java.lang.Object) renderAttributes5);
        keyedObject2.setObject((java.lang.Object) textAnchor3);
        java.lang.Object obj12 = keyedObject2.getObject();
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font11 = null;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 1, font11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double14 = rectangleInsets13.getRight();
        categoryAxis0.setLabelInsets(rectangleInsets13, true);
        org.jfree.chart.util.UnitType unitType17 = rectangleInsets13.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets(unitType17, 10.0d, (double) 0, (double) (-1L), (-1.0d));
        java.awt.Shape shape27 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity29 = new org.jfree.chart.entity.ChartEntity(shape27, "");
        java.awt.Shape shape30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape30);
        chartEntity29.setArea(shape30);
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape30, (java.awt.Paint) color33);
        legendItem34.setURLText("");
        boolean boolean37 = unitType17.equals((java.lang.Object) legendItem34);
        java.lang.String str38 = unitType17.toString();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(unitType17);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UnitType.ABSOLUTE" + "'", str38.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.setMaximumCategoryLabelLines(4);
        categoryAxis0.setMaximumCategoryLabelWidthRatio(1.0f);
        categoryAxis0.setMaximumCategoryLabelLines((int) (byte) 10);
        categoryAxis0.setMinorTickMarksVisible(true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.KeyedObject keyedObject2 = new org.jfree.data.KeyedObject((java.lang.Comparable) 100, (java.lang.Object) (short) 0);
        java.lang.Comparable comparable3 = keyedObject2.getKey();
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset4 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = categoryAxis6.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D12, rectangleEdge13);
        int int15 = categoryAxis6.getCategoryLabelPositionOffset();
        categoryAxis6.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis18, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker22 = null;
        org.jfree.chart.util.Layer layer23 = null;
        boolean boolean24 = categoryPlot20.removeDomainMarker(marker22, layer23);
        boolean boolean25 = categoryPlot20.isRangeMinorGridlinesVisible();
        boolean boolean26 = abstractCategoryDataset4.hasListener((java.util.EventListener) categoryPlot20);
        org.jfree.chart.util.Layer layer27 = null;
        java.util.Collection collection28 = categoryPlot20.getDomainMarkers(layer27);
        boolean boolean29 = categoryPlot20.isDomainPannable();
        categoryPlot20.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = categoryPlot20.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder33 = categoryPlot20.getDatasetRenderingOrder();
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset34 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener35 = null;
        boolean boolean36 = abstractCategoryDataset34.hasListener(eventListener35);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener37 = null;
        abstractCategoryDataset34.removeChangeListener(datasetChangeListener37);
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = null;
        double double48 = categoryAxis40.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D46, rectangleEdge47);
        int int49 = categoryAxis40.getCategoryLabelPositionOffset();
        categoryAxis40.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis52 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, valueAxis52, categoryItemRenderer53);
        java.awt.Paint paint55 = categoryPlot54.getRangeCrosshairPaint();
        int int56 = categoryPlot54.getWeight();
        abstractCategoryDataset34.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot54);
        java.awt.Shape shape62 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity64 = new org.jfree.chart.entity.ChartEntity(shape62, "");
        java.awt.Shape shape65 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent66 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape65);
        chartEntity64.setArea(shape65);
        java.awt.Color color68 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem69 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape65, (java.awt.Paint) color68);
        legendItem69.setURLText("{0}");
        java.awt.Stroke stroke72 = legendItem69.getOutlineStroke();
        categoryPlot54.setDomainCrosshairStroke(stroke72);
        categoryPlot20.setOutlineStroke(stroke72);
        keyedObject2.setObject((java.lang.Object) categoryPlot20);
        org.junit.Assert.assertTrue("'" + comparable3 + "' != '" + 100 + "'", comparable3.equals(100));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(datasetRenderingOrder33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 4 + "'", int49 == 4);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(shape62);
        org.junit.Assert.assertNotNull(shape65);
        org.junit.Assert.assertNotNull(color68);
        org.junit.Assert.assertNotNull(stroke72);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        java.awt.Color color1 = java.awt.Color.red;
        java.awt.Color color2 = java.awt.Color.getColor("ItemLabelAnchor.OUTSIDE4", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        java.lang.String str1 = datasetRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str1.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        java.lang.Object obj1 = legendItemCollection0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        java.awt.Color color0 = java.awt.Color.green;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("ItemLabelAnchor.INSIDE6");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = legendItem1.getFillPaintTransformer();
        boolean boolean3 = legendItem1.isShapeFilled();
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        int int17 = categoryPlot15.getWeight();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        categoryPlot15.setRenderer(categoryItemRenderer18);
        categoryPlot15.clearRangeMarkers((-255));
        org.jfree.chart.LegendItemCollection legendItemCollection22 = new org.jfree.chart.LegendItemCollection();
        categoryPlot15.setFixedLegendItems(legendItemCollection22);
        boolean boolean24 = categoryPlot15.isDomainCrosshairVisible();
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = null;
        double double34 = categoryAxis26.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D32, rectangleEdge33);
        int int35 = categoryAxis26.getCategoryLabelPositionOffset();
        categoryAxis26.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, valueAxis38, categoryItemRenderer39);
        java.awt.Paint paint41 = categoryPlot40.getRangeCrosshairPaint();
        java.awt.Stroke stroke42 = categoryPlot40.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        java.awt.geom.Point2D point2D45 = null;
        categoryPlot40.zoomRangeAxes((double) (short) -1, plotRenderingInfo44, point2D45, false);
        org.jfree.chart.axis.AxisLocation axisLocation48 = categoryPlot40.getDomainAxisLocation();
        categoryPlot15.setDomainAxisLocation(axisLocation48);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = null;
        double double58 = categoryAxis50.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D56, rectangleEdge57);
        int int59 = categoryAxis50.getCategoryLabelPositionOffset();
        java.awt.Font font61 = null;
        categoryAxis50.setTickLabelFont((java.lang.Comparable) 1, font61);
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double64 = rectangleInsets63.getRight();
        categoryAxis50.setLabelInsets(rectangleInsets63, true);
        categoryPlot15.setAxisOffset(rectangleInsets63);
        categoryPlot15.setDomainCrosshairColumnKey((java.lang.Comparable) "DatasetRenderingOrder.REVERSE", true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 4 + "'", int59 == 4);
        org.junit.Assert.assertNotNull(rectangleInsets63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        java.awt.Shape shape3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape3);
        chartEntity2.setArea(shape3);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = categoryAxis7.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D13, rectangleEdge14);
        int int16 = categoryAxis7.getCategoryLabelPositionOffset();
        categoryAxis7.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.util.ObjectList objectList24 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        float float27 = categoryAxis26.getMinorTickMarkInsideLength();
        boolean boolean28 = categoryAxis26.isMinorTickMarksVisible();
        categoryAxis26.setLabelURL("hi!");
        objectList24.set((int) (short) 10, (java.lang.Object) categoryAxis26);
        org.jfree.chart.plot.Plot plot32 = null;
        categoryAxis26.setPlot(plot32);
        categoryAxis26.setCategoryMargin((double) (-1));
        categoryPlot21.setDomainAxis((int) '#', categoryAxis26);
        categoryPlot21.configureRangeAxes();
        org.jfree.chart.entity.PlotEntity plotEntity38 = new org.jfree.chart.entity.PlotEntity(shape3, (org.jfree.chart.plot.Plot) categoryPlot21);
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, valueAxis41, categoryItemRenderer42);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        java.awt.geom.Point2D point2D46 = null;
        categoryPlot43.zoomRangeAxes((double) 100, plotRenderingInfo45, point2D46, false);
        org.jfree.chart.entity.PlotEntity plotEntity51 = new org.jfree.chart.entity.PlotEntity(shape3, (org.jfree.chart.plot.Plot) categoryPlot43, "org.jfree.chart.event.ChartChangeEvent[source=ItemLabelAnchor.OUTSIDE7]", "ItemLabelAnchor.OUTSIDE4");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.0f + "'", float27 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateTopInset((double) 10);
        double double4 = rectangleInsets0.calculateRightOutset(100.0d);
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.renderer.RenderAttributes renderAttributes7 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint9 = renderAttributes7.getSeriesOutlinePaint((int) '4');
        java.awt.Paint paint10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        renderAttributes7.setDefaultOutlinePaint(paint10);
        boolean boolean12 = textAnchor5.equals((java.lang.Object) renderAttributes7);
        boolean boolean13 = rectangleInsets0.equals((java.lang.Object) renderAttributes7);
        java.awt.Paint paint15 = renderAttributes7.getSeriesOutlinePaint(5);
        java.awt.Paint paint18 = renderAttributes7.getItemPaint((int) ' ', (int) (short) -1);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke20 = defaultDrawingSupplier19.getNextStroke();
        renderAttributes7.setDefaultOutlineStroke(stroke20);
        java.awt.Font font22 = renderAttributes7.getDefaultLabelFont();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNull(font22);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint3 = renderAttributes1.getSeriesOutlinePaint((int) '4');
        java.awt.Paint paint4 = renderAttributes1.getDefaultOutlinePaint();
        java.awt.Paint paint7 = renderAttributes1.getItemPaint((int) (byte) 0, (-1));
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor25 = categoryPlot23.getDomainGridlinePosition();
        java.awt.Paint paint26 = categoryPlot23.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        categoryPlot23.setDataset(categoryDataset27);
        org.jfree.chart.LegendItemCollection legendItemCollection29 = categoryPlot23.getLegendItems();
        categoryPlot23.setCrosshairDatasetIndex(0);
        java.awt.Paint paint32 = categoryPlot23.getBackgroundPaint();
        renderAttributes1.setDefaultLabelPaint(paint32);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(categoryAnchor25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(legendItemCollection29);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        java.awt.Stroke stroke17 = categoryPlot15.getDomainGridlineStroke();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        categoryPlot15.setRangeAxis(128, valueAxis19);
        org.jfree.chart.plot.Marker marker21 = null;
        org.jfree.chart.util.Layer layer22 = null;
        boolean boolean23 = categoryPlot15.removeDomainMarker(marker21, layer22);
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = categoryPlot15.getRangeMarkers(layer24);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(collection25);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.util.ObjectList objectList18 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        float float21 = categoryAxis20.getMinorTickMarkInsideLength();
        boolean boolean22 = categoryAxis20.isMinorTickMarksVisible();
        categoryAxis20.setLabelURL("hi!");
        objectList18.set((int) (short) 10, (java.lang.Object) categoryAxis20);
        org.jfree.chart.plot.Plot plot26 = null;
        categoryAxis20.setPlot(plot26);
        categoryAxis20.setCategoryMargin((double) (-1));
        categoryPlot15.setDomainAxis((int) '#', categoryAxis20);
        categoryPlot15.configureRangeAxes();
        org.jfree.chart.plot.Marker marker32 = null;
        boolean boolean33 = categoryPlot15.removeDomainMarker(marker32);
        boolean boolean34 = categoryPlot15.isRangeZoomable();
        org.jfree.chart.util.ShadowGenerator shadowGenerator35 = categoryPlot15.getShadowGenerator();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(shadowGenerator35);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "");
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape7);
        chartEntity6.setArea(shape7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape7, (java.awt.Paint) color10);
        legendItem11.setURLText("{0}");
        java.awt.Stroke stroke14 = legendItem11.getOutlineStroke();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer15 = legendItem11.getFillPaintTransformer();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer16 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj17 = standardGradientPaintTransformer16.clone();
        java.lang.Object obj18 = standardGradientPaintTransformer16.clone();
        java.lang.Object obj19 = standardGradientPaintTransformer16.clone();
        legendItem11.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer16);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset21 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener22 = null;
        boolean boolean23 = abstractCategoryDataset21.hasListener(eventListener22);
        boolean boolean24 = legendItem11.equals((java.lang.Object) eventListener22);
        legendItem11.setDatasetIndex((-16777216));
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(gradientPaintTransformer15);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint3 = renderAttributes1.getSeriesOutlinePaint((int) '4');
        java.awt.Stroke stroke4 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes1.setDefaultStroke(stroke4);
        java.awt.Shape shape6 = renderAttributes1.getDefaultShape();
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(shape6);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        java.awt.Paint paint18 = categoryPlot15.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        categoryPlot15.setDataset(categoryDataset19);
        org.jfree.chart.LegendItemCollection legendItemCollection21 = categoryPlot15.getLegendItems();
        boolean boolean22 = categoryPlot15.canSelectByPoint();
        int int23 = categoryPlot15.getRangeAxisCount();
        categoryPlot15.setDrawSharedDomainAxis(true);
        categoryPlot15.clearRangeAxes();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(legendItemCollection21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        java.awt.Font font28 = lineAndShapeRenderer2.getBaseItemLabelFont();
        boolean boolean29 = lineAndShapeRenderer2.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator30 = lineAndShapeRenderer2.getBaseItemLabelGenerator();
        boolean boolean31 = lineAndShapeRenderer2.getUseFillPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = lineAndShapeRenderer2.getNegativeItemLabelPosition(1, (-16776961), true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNull(categoryItemLabelGenerator30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition35);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        java.awt.Color color2 = java.awt.Color.getColor("CategoryAnchor.START", (-12566464));
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis2.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D8, rectangleEdge9);
        int int11 = categoryAxis2.getCategoryLabelPositionOffset();
        categoryAxis2.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis14, categoryItemRenderer15);
        java.awt.Paint paint17 = categoryPlot16.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = categoryPlot16.removeDomainMarker(marker18, layer19);
        boolean boolean21 = categoryPlot16.isRangeMinorGridlinesVisible();
        boolean boolean22 = abstractCategoryDataset0.hasListener((java.util.EventListener) categoryPlot16);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot16.getDomainMarkers(layer23);
        boolean boolean25 = categoryPlot16.isDomainPannable();
        categoryPlot16.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryPlot16.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = categoryPlot16.getDatasetRenderingOrder();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer33.setBaseItemLabelsVisible(false);
        boolean boolean36 = lineAndShapeRenderer33.getBaseShapesFilled();
        categoryPlot16.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer33);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator38 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        java.lang.Object obj39 = standardCategorySeriesLabelGenerator38.clone();
        lineAndShapeRenderer33.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator38);
        lineAndShapeRenderer33.setSeriesShapesFilled(4, false);
        java.awt.Stroke stroke45 = lineAndShapeRenderer33.getSeriesStroke(5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNull(stroke45);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.awt.Color color1 = java.awt.Color.BLACK;
        boolean boolean2 = keyedObjects2D0.equals((java.lang.Object) color1);
        int int4 = keyedObjects2D0.getRowIndex((java.lang.Comparable) 1.0d);
        int int6 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) (-16776961));
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.renderer.category.BarPainter barPainter2 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
        org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(barPainter2);
        barRenderer0.setBarPainter(barPainter2);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = categoryAxis6.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D12, rectangleEdge13);
        int int15 = categoryAxis6.getCategoryLabelPositionOffset();
        categoryAxis6.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis18, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker22 = null;
        org.jfree.chart.util.Layer layer23 = null;
        boolean boolean24 = categoryPlot20.removeDomainMarker(marker22, layer23);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = categoryPlot20.getRangeMarkers(layer25);
        java.awt.Font font27 = categoryPlot20.getNoDataMessageFont();
        java.awt.Color color28 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        categoryPlot20.setRangeMinorGridlinePaint((java.awt.Paint) color28);
        barRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot20);
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(barPainter2);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(color28);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj1 = standardGradientPaintTransformer0.clone();
        java.awt.GradientPaint gradientPaint2 = null;
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape3, "");
        java.awt.Shape shape6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape6);
        chartEntity5.setArea(shape6);
        try {
            java.awt.GradientPaint gradientPaint9 = standardGradientPaintTransformer0.transform(gradientPaint2, shape6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int2 = color1.getAlpha();
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator6 = new org.jfree.chart.util.DefaultShadowGenerator((int) (short) 0, color1, (-1.0f), 10, (double) (short) 1);
        java.awt.Color color7 = defaultShadowGenerator6.getShadowColor();
        int int8 = defaultShadowGenerator6.calculateOffsetX();
        int int9 = defaultShadowGenerator6.getShadowSize();
        float float10 = defaultShadowGenerator6.getShadowOpacity();
        int int11 = defaultShadowGenerator6.calculateOffsetX();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 5 + "'", int8 == 5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + (-1.0f) + "'", float10 == (-1.0f));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.setMaximumCategoryLabelLines(4);
        categoryAxis0.setLowerMargin(0.0d);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis0.getCategorySeriesMiddle((int) (byte) 1, (int) ' ', (int) (byte) 10, 0, 3.0d, rectangle2D19, rectangleEdge20);
        float float22 = categoryAxis0.getMinorTickMarkInsideLength();
        categoryAxis0.setFixedDimension(0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        java.awt.Stroke stroke17 = categoryPlot15.getDomainGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = categoryPlot15.getRenderer(255);
        org.jfree.chart.plot.Plot plot20 = categoryPlot15.getParent();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset24 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener25 = null;
        boolean boolean26 = abstractCategoryDataset24.hasListener(eventListener25);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener27 = null;
        abstractCategoryDataset24.removeChangeListener(datasetChangeListener27);
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = null;
        double double38 = categoryAxis30.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D36, rectangleEdge37);
        int int39 = categoryAxis30.getCategoryLabelPositionOffset();
        categoryAxis30.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset29, categoryAxis30, valueAxis42, categoryItemRenderer43);
        java.awt.Paint paint45 = categoryPlot44.getRangeCrosshairPaint();
        int int46 = categoryPlot44.getWeight();
        abstractCategoryDataset24.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot44);
        lineAndShapeRenderer23.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot44);
        boolean boolean49 = lineAndShapeRenderer23.getBaseShapesFilled();
        org.jfree.chart.renderer.RenderAttributes renderAttributes52 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint54 = renderAttributes52.getSeriesOutlinePaint((int) '4');
        java.awt.Stroke stroke55 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes52.setDefaultStroke(stroke55);
        lineAndShapeRenderer23.setSeriesStroke(0, stroke55, false);
        lineAndShapeRenderer23.clearSeriesStrokes(true);
        java.awt.Paint paint64 = lineAndShapeRenderer23.getItemFillPaint(8, (-1), true);
        categoryPlot15.setDomainCrosshairPaint(paint64);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent66 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot15);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(categoryItemRenderer19);
        org.junit.Assert.assertNull(plot20);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 4 + "'", int39 == 4);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNull(paint54);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(paint64);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font11 = null;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 1, font11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double14 = rectangleInsets13.getRight();
        categoryAxis0.setLabelInsets(rectangleInsets13, true);
        float float17 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        categoryAxis0.setVisible(true);
        boolean boolean20 = categoryAxis0.isTickMarksVisible();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.0f + "'", float17 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "");
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape7);
        chartEntity6.setArea(shape7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape7, (java.awt.Paint) color10);
        legendItem11.setURLText("{0}");
        java.awt.Stroke stroke14 = legendItem11.getOutlineStroke();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer15 = legendItem11.getFillPaintTransformer();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer16 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj17 = standardGradientPaintTransformer16.clone();
        java.lang.Object obj18 = standardGradientPaintTransformer16.clone();
        java.lang.Object obj19 = standardGradientPaintTransformer16.clone();
        legendItem11.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer16);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset21 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener22 = null;
        boolean boolean23 = abstractCategoryDataset21.hasListener(eventListener22);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener24 = null;
        abstractCategoryDataset21.removeChangeListener(datasetChangeListener24);
        abstractCategoryDataset21.validateObject();
        legendItem11.setDataset((org.jfree.data.general.Dataset) abstractCategoryDataset21);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(gradientPaintTransformer15);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        java.awt.Font font5 = lineAndShapeRenderer2.getBaseItemLabelFont();
        java.lang.Boolean boolean7 = lineAndShapeRenderer2.getSeriesVisible((-14336));
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker25 = null;
        org.jfree.chart.util.Layer layer26 = null;
        boolean boolean27 = categoryPlot23.removeDomainMarker(marker25, layer26);
        org.jfree.chart.util.Layer layer28 = null;
        java.util.Collection collection29 = categoryPlot23.getRangeMarkers(layer28);
        java.awt.Font font30 = categoryPlot23.getNoDataMessageFont();
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        categoryPlot23.setRangeMinorGridlinePaint((java.awt.Paint) color31);
        lineAndShapeRenderer2.setBaseLegendTextPaint((java.awt.Paint) color31);
        lineAndShapeRenderer2.setBaseShapesFilled(true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(collection29);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(color31);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMinorTickMarkInsideLength();
        boolean boolean2 = categoryAxis0.isMinorTickMarksVisible();
        boolean boolean3 = categoryAxis0.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot4 = null;
        categoryAxis0.setPlot(plot4);
        java.awt.Paint paint7 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) 100L);
        categoryAxis0.setCategoryMargin((double) 128);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.renderer.category.BarPainter barPainter2 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
        org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(barPainter2);
        barRenderer0.setBarPainter(barPainter2);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Color color6 = color5.brighter();
        barRenderer0.setShadowPaint((java.awt.Paint) color5);
        org.jfree.chart.renderer.category.BarPainter barPainter8 = barRenderer0.getBarPainter();
        java.awt.Paint paint9 = barRenderer0.getShadowPaint();
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(barPainter2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(barPainter8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "");
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape7);
        chartEntity6.setArea(shape7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape7, (java.awt.Paint) color10);
        legendItem11.setURLText("");
        java.awt.Font font14 = legendItem11.getLabelFont();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(font14);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        int int1 = color0.getRGB();
        java.awt.image.ColorModel colorModel2 = null;
        java.awt.Rectangle rectangle3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.AffineTransform affineTransform5 = null;
        java.awt.RenderingHints renderingHints6 = null;
        java.awt.PaintContext paintContext7 = color0.createContext(colorModel2, rectangle3, rectangle2D4, affineTransform5, renderingHints6);
        int int8 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-14336) + "'", int1 == (-14336));
        org.junit.Assert.assertNotNull(paintContext7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 255 + "'", int8 == 255);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMinorTickMarkInsideLength();
        double double2 = categoryAxis0.getFixedDimension();
        java.awt.Paint paint3 = categoryAxis0.getTickLabelPaint();
        java.lang.String str4 = categoryAxis0.getLabel();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.setMaximumCategoryLabelLines(4);
        categoryAxis0.setLowerMargin(0.0d);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis0.getCategorySeriesMiddle((int) (byte) 1, (int) ' ', (int) (byte) 10, 0, 3.0d, rectangle2D19, rectangleEdge20);
        boolean boolean22 = categoryAxis0.isMinorTickMarksVisible();
        boolean boolean23 = categoryAxis0.isAxisLineVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        float float25 = categoryAxis24.getMinorTickMarkInsideLength();
        boolean boolean26 = categoryAxis24.isMinorTickMarksVisible();
        java.lang.String str28 = categoryAxis24.getCategoryLabelToolTip((java.lang.Comparable) 1);
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = null;
        double double36 = categoryAxis24.getCategorySeriesMiddle((int) (byte) 10, (int) '#', (int) (short) 1, (-8323073), (double) 1.0f, rectangle2D34, rectangleEdge35);
        org.jfree.chart.event.AxisChangeListener axisChangeListener37 = null;
        categoryAxis24.addChangeListener(axisChangeListener37);
        java.awt.Font font39 = categoryAxis24.getTickLabelFont();
        categoryAxis0.setTickLabelFont(font39);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertEquals((double) double21, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.0f + "'", float25 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(font39);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition1 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.renderer.category.BarPainter barPainter2 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
        org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(barPainter2);
        barRenderer0.setBarPainter(barPainter2);
        boolean boolean5 = barRenderer0.getIncludeBaseInRange();
        java.awt.Color color9 = java.awt.Color.getHSBColor((float) 64, (float) 100, (float) 3);
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color9);
        org.junit.Assert.assertNull(itemLabelPosition1);
        org.junit.Assert.assertNotNull(barPainter2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint33 = renderAttributes31.getSeriesOutlinePaint((int) '4');
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes31.setDefaultStroke(stroke34);
        lineAndShapeRenderer2.setSeriesStroke(0, stroke34, false);
        java.awt.Shape shape38 = lineAndShapeRenderer2.getBaseLegendShape();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition42 = lineAndShapeRenderer2.getPositiveItemLabelPosition((int) (short) -1, (-1), true);
        java.awt.Stroke stroke44 = lineAndShapeRenderer2.lookupSeriesOutlineStroke((int) (byte) 0);
        lineAndShapeRenderer2.setAutoPopulateSeriesStroke(true);
        lineAndShapeRenderer2.setBaseShapesVisible(false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNull(shape38);
        org.junit.Assert.assertNotNull(itemLabelPosition42);
        org.junit.Assert.assertNotNull(stroke44);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor29 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor30 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor29, textAnchor30);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj34 = standardGradientPaintTransformer33.clone();
        boolean boolean35 = categoryAxis32.equals((java.lang.Object) standardGradientPaintTransformer33);
        boolean boolean36 = itemLabelPosition31.equals((java.lang.Object) boolean35);
        double double37 = itemLabelPosition31.getAngle();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor38 = itemLabelPosition31.getItemLabelAnchor();
        lineAndShapeRenderer2.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition31);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator41 = null;
        lineAndShapeRenderer2.setSeriesURLGenerator(1, categoryURLGenerator41);
        lineAndShapeRenderer2.setBaseSeriesVisibleInLegend(true, false);
        java.awt.Paint paint46 = lineAndShapeRenderer2.getBaseOutlinePaint();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator48 = null;
        lineAndShapeRenderer2.setSeriesURLGenerator((int) (short) 0, categoryURLGenerator48);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(itemLabelAnchor29);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor38);
        org.junit.Assert.assertNotNull(paint46);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint10 = renderAttributes8.getSeriesOutlinePaint((int) '4');
        java.awt.Paint paint11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        renderAttributes8.setDefaultOutlinePaint(paint11);
        lineAndShapeRenderer5.setSeriesFillPaint((int) (byte) 0, paint11);
        renderAttributes1.setSeriesOutlinePaint(2, paint11);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset18 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener19 = null;
        boolean boolean20 = abstractCategoryDataset18.hasListener(eventListener19);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener21 = null;
        abstractCategoryDataset18.removeChangeListener(datasetChangeListener21);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
        double double32 = categoryAxis24.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D30, rectangleEdge31);
        int int33 = categoryAxis24.getCategoryLabelPositionOffset();
        categoryAxis24.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis36, categoryItemRenderer37);
        java.awt.Paint paint39 = categoryPlot38.getRangeCrosshairPaint();
        int int40 = categoryPlot38.getWeight();
        abstractCategoryDataset18.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot38);
        lineAndShapeRenderer17.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot38);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor44 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor45 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition46 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor44, textAnchor45);
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer48 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj49 = standardGradientPaintTransformer48.clone();
        boolean boolean50 = categoryAxis47.equals((java.lang.Object) standardGradientPaintTransformer48);
        boolean boolean51 = itemLabelPosition46.equals((java.lang.Object) boolean50);
        double double52 = itemLabelPosition46.getAngle();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor53 = itemLabelPosition46.getItemLabelAnchor();
        lineAndShapeRenderer17.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition46);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator56 = null;
        lineAndShapeRenderer17.setSeriesURLGenerator(1, categoryURLGenerator56);
        java.awt.Paint paint59 = lineAndShapeRenderer17.getSeriesPaint((int) (byte) 1);
        boolean boolean61 = lineAndShapeRenderer17.isSeriesVisible((int) '4');
        lineAndShapeRenderer17.setBaseSeriesVisible(true);
        java.awt.Paint paint65 = lineAndShapeRenderer17.lookupSeriesFillPaint(0);
        renderAttributes1.setDefaultFillPaint(paint65);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 4 + "'", int33 == 4);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(itemLabelAnchor44);
        org.junit.Assert.assertNotNull(textAnchor45);
        org.junit.Assert.assertNotNull(obj49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor53);
        org.junit.Assert.assertNull(paint59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(paint65);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis2.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D8, rectangleEdge9);
        int int11 = categoryAxis2.getCategoryLabelPositionOffset();
        categoryAxis2.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis14, categoryItemRenderer15);
        java.awt.Paint paint17 = categoryPlot16.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = categoryPlot16.removeDomainMarker(marker18, layer19);
        boolean boolean21 = categoryPlot16.isRangeMinorGridlinesVisible();
        boolean boolean22 = abstractCategoryDataset0.hasListener((java.util.EventListener) categoryPlot16);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot16.getDomainMarkers(layer23);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder25 = categoryPlot16.getDatasetRenderingOrder();
        categoryPlot16.setRangeGridlinesVisible(false);
        boolean boolean28 = categoryPlot16.isRangeZoomable();
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset30 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = null;
        double double40 = categoryAxis32.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D38, rectangleEdge39);
        int int41 = categoryAxis32.getCategoryLabelPositionOffset();
        categoryAxis32.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset31, categoryAxis32, valueAxis44, categoryItemRenderer45);
        java.awt.Paint paint47 = categoryPlot46.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker48 = null;
        org.jfree.chart.util.Layer layer49 = null;
        boolean boolean50 = categoryPlot46.removeDomainMarker(marker48, layer49);
        boolean boolean51 = categoryPlot46.isRangeMinorGridlinesVisible();
        boolean boolean52 = abstractCategoryDataset30.hasListener((java.util.EventListener) categoryPlot46);
        org.jfree.chart.util.Layer layer53 = null;
        java.util.Collection collection54 = categoryPlot46.getDomainMarkers(layer53);
        boolean boolean55 = categoryPlot46.isDomainPannable();
        categoryPlot46.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = categoryPlot46.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder59 = categoryPlot46.getDatasetRenderingOrder();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer63 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer63.setBaseItemLabelsVisible(false);
        boolean boolean66 = lineAndShapeRenderer63.getBaseShapesFilled();
        categoryPlot46.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer63);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator68 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        java.lang.Object obj69 = standardCategorySeriesLabelGenerator68.clone();
        lineAndShapeRenderer63.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator68);
        lineAndShapeRenderer63.setSeriesVisible((int) (short) 0, (java.lang.Boolean) true, true);
        java.awt.Shape shape79 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity81 = new org.jfree.chart.entity.ChartEntity(shape79, "");
        java.awt.Shape shape82 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent83 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape82);
        chartEntity81.setArea(shape82);
        java.awt.Color color85 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem86 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape82, (java.awt.Paint) color85);
        int int87 = color85.getBlue();
        int int88 = color85.getBlue();
        lineAndShapeRenderer63.setBaseItemLabelPaint((java.awt.Paint) color85, false);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator94 = new org.jfree.chart.util.DefaultShadowGenerator((int) '4', color85, (float) (-32513), 8, 0.2d);
        categoryPlot16.setDomainCrosshairPaint((java.awt.Paint) color85);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent96 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot16);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNotNull(datasetRenderingOrder25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 4 + "'", int41 == 4);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNull(collection54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertNotNull(datasetRenderingOrder59);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNotNull(obj69);
        org.junit.Assert.assertNotNull(shape79);
        org.junit.Assert.assertNotNull(shape82);
        org.junit.Assert.assertNotNull(color85);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 64 + "'", int87 == 64);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 64 + "'", int88 == 64);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.util.ObjectList objectList18 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        float float21 = categoryAxis20.getMinorTickMarkInsideLength();
        boolean boolean22 = categoryAxis20.isMinorTickMarksVisible();
        categoryAxis20.setLabelURL("hi!");
        objectList18.set((int) (short) 10, (java.lang.Object) categoryAxis20);
        org.jfree.chart.plot.Plot plot26 = null;
        categoryAxis20.setPlot(plot26);
        categoryAxis20.setCategoryMargin((double) (-1));
        categoryPlot15.setDomainAxis((int) '#', categoryAxis20);
        java.awt.Font font31 = categoryAxis20.getTickLabelFont();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(font31);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        java.awt.Font font28 = lineAndShapeRenderer2.getBaseItemLabelFont();
        boolean boolean29 = lineAndShapeRenderer2.getAutoPopulateSeriesShape();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator30 = lineAndShapeRenderer2.getBaseItemLabelGenerator();
        java.awt.Paint paint32 = lineAndShapeRenderer2.lookupLegendTextPaint(4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNull(categoryItemLabelGenerator30);
        org.junit.Assert.assertNull(paint32);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = categoryAxis19.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D25, rectangleEdge26);
        int int28 = categoryAxis19.getCategoryLabelPositionOffset();
        categoryAxis19.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis31, categoryItemRenderer32);
        java.awt.Paint paint34 = categoryPlot33.getRangeCrosshairPaint();
        int int35 = categoryPlot33.getWeight();
        java.lang.Comparable comparable36 = null;
        categoryPlot33.setDomainCrosshairRowKey(comparable36, true);
        org.jfree.chart.util.SortOrder sortOrder39 = categoryPlot33.getRowRenderingOrder();
        categoryPlot15.setRowRenderingOrder(sortOrder39);
        java.awt.Color color41 = org.jfree.chart.ChartColor.LIGHT_RED;
        categoryPlot15.setBackgroundPaint((java.awt.Paint) color41);
        categoryPlot15.setDomainCrosshairColumnKey((java.lang.Comparable) (byte) 1, true);
        categoryPlot15.setNotify(false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(sortOrder39);
        org.junit.Assert.assertNotNull(color41);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        categoryPlot15.addChangeListener(plotChangeListener16);
        boolean boolean18 = categoryPlot15.isRangeZoomable();
        org.jfree.chart.axis.AxisSpace axisSpace19 = categoryPlot15.getFixedDomainAxisSpace();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        categoryPlot15.zoomRangeAxes(0.0d, plotRenderingInfo21, point2D22, false);
        int int25 = categoryPlot15.getDomainAxisCount();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(axisSpace19);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.lang.Comparable comparable16 = categoryPlot15.getDomainCrosshairColumnKey();
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        boolean boolean19 = plotOrientation17.equals((java.lang.Object) color18);
        categoryPlot15.setRangeZeroBaselinePaint((java.awt.Paint) color18);
        boolean boolean21 = categoryPlot15.isDomainCrosshairVisible();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNull(comparable16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor29 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor30 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor29, textAnchor30);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj34 = standardGradientPaintTransformer33.clone();
        boolean boolean35 = categoryAxis32.equals((java.lang.Object) standardGradientPaintTransformer33);
        boolean boolean36 = itemLabelPosition31.equals((java.lang.Object) boolean35);
        double double37 = itemLabelPosition31.getAngle();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor38 = itemLabelPosition31.getItemLabelAnchor();
        lineAndShapeRenderer2.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition31);
        org.jfree.chart.text.TextAnchor textAnchor40 = itemLabelPosition31.getRotationAnchor();
        double double41 = itemLabelPosition31.getAngle();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(itemLabelAnchor29);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor38);
        org.junit.Assert.assertNotNull(textAnchor40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMinorTickMarkInsideLength();
        boolean boolean2 = categoryAxis0.isMinorTickMarksVisible();
        java.lang.String str4 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) 1);
        java.awt.Font font5 = categoryAxis0.getTickLabelFont();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        boolean boolean2 = plotOrientation0.equals((java.lang.Object) color1);
        int int3 = color1.getRed();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 128 + "'", int3 == 128);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateTopInset((double) 10);
        double double4 = rectangleInsets0.calculateRightOutset(100.0d);
        double double5 = rectangleInsets0.getRight();
        double double7 = rectangleInsets0.extendHeight(4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.util.ObjectList objectList18 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        float float21 = categoryAxis20.getMinorTickMarkInsideLength();
        boolean boolean22 = categoryAxis20.isMinorTickMarksVisible();
        categoryAxis20.setLabelURL("hi!");
        objectList18.set((int) (short) 10, (java.lang.Object) categoryAxis20);
        org.jfree.chart.plot.Plot plot26 = null;
        categoryAxis20.setPlot(plot26);
        categoryAxis20.setCategoryMargin((double) (-1));
        categoryPlot15.setDomainAxis((int) '#', categoryAxis20);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double33 = rectangleInsets31.trimHeight(0.0d);
        double double35 = rectangleInsets31.trimWidth((double) 0);
        double double36 = rectangleInsets31.getLeft();
        double double38 = rectangleInsets31.calculateRightOutset((double) (-2));
        categoryAxis20.setLabelInsets(rectangleInsets31, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset41 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset42 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = null;
        double double51 = categoryAxis43.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D49, rectangleEdge50);
        int int52 = categoryAxis43.getCategoryLabelPositionOffset();
        categoryAxis43.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer56 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, valueAxis55, categoryItemRenderer56);
        java.awt.Paint paint58 = categoryPlot57.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker59 = null;
        org.jfree.chart.util.Layer layer60 = null;
        boolean boolean61 = categoryPlot57.removeDomainMarker(marker59, layer60);
        boolean boolean62 = categoryPlot57.isRangeMinorGridlinesVisible();
        boolean boolean63 = abstractCategoryDataset41.hasListener((java.util.EventListener) categoryPlot57);
        org.jfree.chart.util.Layer layer64 = null;
        java.util.Collection collection65 = categoryPlot57.getDomainMarkers(layer64);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder66 = categoryPlot57.getDatasetRenderingOrder();
        org.jfree.chart.axis.ValueAxis valueAxis67 = null;
        org.jfree.data.Range range68 = categoryPlot57.getDataRange(valueAxis67);
        double double69 = categoryPlot57.getRangeCrosshairValue();
        categoryAxis20.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot57);
        org.jfree.chart.axis.CategoryAxis categoryAxis71 = categoryPlot57.getDomainAxis();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 4 + "'", int52 == 4);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNull(collection65);
        org.junit.Assert.assertNotNull(datasetRenderingOrder66);
        org.junit.Assert.assertNull(range68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(categoryAxis71);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor29 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor30 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor29, textAnchor30);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj34 = standardGradientPaintTransformer33.clone();
        boolean boolean35 = categoryAxis32.equals((java.lang.Object) standardGradientPaintTransformer33);
        boolean boolean36 = itemLabelPosition31.equals((java.lang.Object) boolean35);
        double double37 = itemLabelPosition31.getAngle();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor38 = itemLabelPosition31.getItemLabelAnchor();
        lineAndShapeRenderer2.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition31);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator41 = null;
        lineAndShapeRenderer2.setSeriesURLGenerator(1, categoryURLGenerator41);
        java.awt.Paint paint44 = lineAndShapeRenderer2.getSeriesPaint((int) (byte) 1);
        boolean boolean46 = lineAndShapeRenderer2.isSeriesVisible((int) '4');
        org.jfree.data.KeyedObjects2D keyedObjects2D47 = new org.jfree.data.KeyedObjects2D();
        java.awt.Color color48 = java.awt.Color.BLACK;
        boolean boolean49 = keyedObjects2D47.equals((java.lang.Object) color48);
        lineAndShapeRenderer2.setBaseOutlinePaint((java.awt.Paint) color48);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator52 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        java.lang.Object obj53 = standardCategorySeriesLabelGenerator52.clone();
        lineAndShapeRenderer2.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator52);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator55 = lineAndShapeRenderer2.getLegendItemToolTipGenerator();
        double double56 = lineAndShapeRenderer2.getItemMargin();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(itemLabelAnchor29);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor38);
        org.junit.Assert.assertNull(paint44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(obj53);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis2.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D8, rectangleEdge9);
        int int11 = categoryAxis2.getCategoryLabelPositionOffset();
        categoryAxis2.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis14, categoryItemRenderer15);
        java.awt.Paint paint17 = categoryPlot16.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = categoryPlot16.removeDomainMarker(marker18, layer19);
        boolean boolean21 = categoryPlot16.isRangeMinorGridlinesVisible();
        boolean boolean22 = abstractCategoryDataset0.hasListener((java.util.EventListener) categoryPlot16);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot16.getDomainMarkers(layer23);
        boolean boolean25 = categoryPlot16.isDomainPannable();
        categoryPlot16.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryPlot16.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = categoryPlot16.getDatasetRenderingOrder();
        org.jfree.chart.plot.CategoryMarker categoryMarker31 = null;
        org.jfree.chart.util.Layer layer32 = null;
        try {
            categoryPlot16.addDomainMarker((-12566464), categoryMarker31, layer32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor29 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor30 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor29, textAnchor30);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj34 = standardGradientPaintTransformer33.clone();
        boolean boolean35 = categoryAxis32.equals((java.lang.Object) standardGradientPaintTransformer33);
        boolean boolean36 = itemLabelPosition31.equals((java.lang.Object) boolean35);
        double double37 = itemLabelPosition31.getAngle();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor38 = itemLabelPosition31.getItemLabelAnchor();
        lineAndShapeRenderer2.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition31);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator41 = null;
        lineAndShapeRenderer2.setSeriesURLGenerator(1, categoryURLGenerator41);
        lineAndShapeRenderer2.setUseOutlinePaint(true);
        int int45 = lineAndShapeRenderer2.getPassCount();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(itemLabelAnchor29);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor38);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 2 + "'", int45 == 2);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = keyedObjects2D0.clone();
        int int3 = keyedObjects2D0.getColumnIndex((java.lang.Comparable) 'a');
        int int4 = keyedObjects2D0.getColumnCount();
        java.awt.Paint[] paintArray5 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        boolean boolean6 = keyedObjects2D0.equals((java.lang.Object) paintArray5);
        java.util.List list7 = keyedObjects2D0.getColumnKeys();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) list7);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(paintArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(list7);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        int int17 = categoryPlot15.getWeight();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        categoryPlot15.setRenderer(categoryItemRenderer18);
        categoryPlot15.clearRangeMarkers((-255));
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot15.getRangeMarkers((int) '4', layer23);
        org.jfree.chart.axis.AxisSpace axisSpace25 = categoryPlot15.getFixedDomainAxisSpace();
        java.awt.Stroke stroke26 = categoryPlot15.getOutlineStroke();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertNull(axisSpace25);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextStroke();
        java.awt.Stroke stroke2 = defaultDrawingSupplier0.getNextStroke();
        java.awt.Paint paint3 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Stroke stroke4 = defaultDrawingSupplier0.getNextOutlineStroke();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabelURL("");
        categoryAxis0.setAxisLineVisible(true);
        java.lang.String str5 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setMinorTickMarkInsideLength((float) '4');
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = abstractCategoryDataset0.hasListener(eventListener1);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener3 = null;
        abstractCategoryDataset0.removeChangeListener(datasetChangeListener3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = categoryAxis6.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D12, rectangleEdge13);
        int int15 = categoryAxis6.getCategoryLabelPositionOffset();
        categoryAxis6.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis18, categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot20.getRangeCrosshairPaint();
        int int22 = categoryPlot20.getWeight();
        abstractCategoryDataset0.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot20);
        categoryPlot20.clearSelection();
        java.awt.Paint paint25 = categoryPlot20.getRangeMinorGridlinePaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint33 = renderAttributes31.getSeriesOutlinePaint((int) '4');
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes31.setDefaultStroke(stroke34);
        lineAndShapeRenderer2.setSeriesStroke(0, stroke34, false);
        java.awt.Paint paint39 = lineAndShapeRenderer2.getSeriesFillPaint(0);
        java.awt.Paint paint40 = null;
        try {
            lineAndShapeRenderer2.setBaseOutlinePaint(paint40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNull(paint39);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        java.awt.Font font28 = lineAndShapeRenderer2.getBaseItemLabelFont();
        boolean boolean29 = lineAndShapeRenderer2.getBaseCreateEntities();
        boolean boolean30 = lineAndShapeRenderer2.getAutoPopulateSeriesPaint();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.lang.Object obj1 = strokeList0.clone();
        java.awt.Stroke stroke3 = strokeList0.getStroke((int) (byte) 0);
        java.lang.Object obj4 = strokeList0.clone();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        java.awt.Color color2 = java.awt.Color.getColor("DatasetRenderingOrder.FORWARD", 5);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.jfree.chart.renderer.RenderAttributes renderAttributes31 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint33 = renderAttributes31.getSeriesOutlinePaint((int) '4');
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes31.setDefaultStroke(stroke34);
        lineAndShapeRenderer2.setSeriesStroke(0, stroke34, false);
        java.awt.Shape shape38 = lineAndShapeRenderer2.getBaseLegendShape();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation39 = null;
        boolean boolean40 = lineAndShapeRenderer2.removeAnnotation(categoryAnnotation39);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator44 = lineAndShapeRenderer2.getURLGenerator((int) (byte) 10, (int) (short) -1, false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNull(shape38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(categoryURLGenerator44);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        org.jfree.data.KeyedObjects2D keyedObjects2D18 = new org.jfree.data.KeyedObjects2D();
        java.awt.Color color19 = java.awt.Color.BLACK;
        boolean boolean20 = keyedObjects2D18.equals((java.lang.Object) color19);
        int int21 = color19.getTransparency();
        categoryPlot15.setRangeGridlinePaint((java.awt.Paint) color19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot15.zoomRangeAxes((double) 0L, plotRenderingInfo24, point2D25, true);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset29 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        double double39 = categoryAxis31.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D37, rectangleEdge38);
        int int40 = categoryAxis31.getCategoryLabelPositionOffset();
        categoryAxis31.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis43, categoryItemRenderer44);
        java.awt.Paint paint46 = categoryPlot45.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker47 = null;
        org.jfree.chart.util.Layer layer48 = null;
        boolean boolean49 = categoryPlot45.removeDomainMarker(marker47, layer48);
        boolean boolean50 = categoryPlot45.isRangeMinorGridlinesVisible();
        boolean boolean51 = abstractCategoryDataset29.hasListener((java.util.EventListener) categoryPlot45);
        org.jfree.chart.util.Layer layer52 = null;
        java.util.Collection collection53 = categoryPlot45.getDomainMarkers(layer52);
        boolean boolean54 = categoryPlot45.isDomainPannable();
        categoryPlot45.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = categoryPlot45.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder58 = categoryPlot45.getDatasetRenderingOrder();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer62 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer62.setBaseItemLabelsVisible(false);
        boolean boolean65 = lineAndShapeRenderer62.getBaseShapesFilled();
        categoryPlot45.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer62);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator67 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        java.lang.Object obj68 = standardCategorySeriesLabelGenerator67.clone();
        lineAndShapeRenderer62.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator67);
        lineAndShapeRenderer62.setSeriesVisible((int) (short) 0, (java.lang.Boolean) true, true);
        java.awt.Shape shape78 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity80 = new org.jfree.chart.entity.ChartEntity(shape78, "");
        java.awt.Shape shape81 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent82 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape81);
        chartEntity80.setArea(shape81);
        java.awt.Color color84 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem85 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape81, (java.awt.Paint) color84);
        int int86 = color84.getBlue();
        int int87 = color84.getBlue();
        lineAndShapeRenderer62.setBaseItemLabelPaint((java.awt.Paint) color84, false);
        categoryPlot15.setRenderer((int) (short) 0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer62);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 4 + "'", int40 == 4);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(collection53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertNotNull(datasetRenderingOrder58);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(obj68);
        org.junit.Assert.assertNotNull(shape78);
        org.junit.Assert.assertNotNull(shape81);
        org.junit.Assert.assertNotNull(color84);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 64 + "'", int86 == 64);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 64 + "'", int87 == 64);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "");
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape7);
        chartEntity6.setArea(shape7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape7, (java.awt.Paint) color10);
        legendItem11.setURLText("{0}");
        java.awt.Paint paint14 = legendItem11.getOutlinePaint();
        java.awt.Paint paint15 = legendItem11.getLinePaint();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity22 = new org.jfree.chart.entity.ChartEntity(shape20, "");
        java.awt.Shape shape23 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape23);
        chartEntity22.setArea(shape23);
        java.awt.Color color26 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape23, (java.awt.Paint) color26);
        legendItem11.setShape(shape23);
        legendItem11.setURLText("ItemLabelAnchor.INSIDE6");
        legendItem11.setDescription("");
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(color26);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = lineAndShapeRenderer2.getSeriesPositiveItemLabelPosition((int) 'a');
        lineAndShapeRenderer2.setAutoPopulateSeriesStroke(false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(itemLabelPosition29);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.util.ObjectList objectList18 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        float float21 = categoryAxis20.getMinorTickMarkInsideLength();
        boolean boolean22 = categoryAxis20.isMinorTickMarksVisible();
        categoryAxis20.setLabelURL("hi!");
        objectList18.set((int) (short) 10, (java.lang.Object) categoryAxis20);
        org.jfree.chart.plot.Plot plot26 = null;
        categoryAxis20.setPlot(plot26);
        categoryAxis20.setCategoryMargin((double) (-1));
        categoryPlot15.setDomainAxis((int) '#', categoryAxis20);
        categoryPlot15.configureRangeAxes();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder32 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str33 = datasetRenderingOrder32.toString();
        categoryPlot15.setDatasetRenderingOrder(datasetRenderingOrder32);
        org.jfree.chart.event.AnnotationChangeEvent annotationChangeEvent35 = null;
        categoryPlot15.annotationChanged(annotationChangeEvent35);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = categoryPlot15.getDomainAxisForDataset(64);
        org.jfree.chart.plot.Marker marker40 = null;
        org.jfree.chart.util.Layer layer41 = null;
        try {
            categoryPlot15.addRangeMarker(5, marker40, layer41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str33.equals("DatasetRenderingOrder.FORWARD"));
        org.junit.Assert.assertNotNull(categoryAxis38);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        double double13 = categoryAxis5.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D11, rectangleEdge12);
        int int14 = categoryAxis5.getCategoryLabelPositionOffset();
        categoryAxis5.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis17, categoryItemRenderer18);
        java.awt.Paint paint20 = categoryPlot19.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker21 = null;
        org.jfree.chart.util.Layer layer22 = null;
        boolean boolean23 = categoryPlot19.removeDomainMarker(marker21, layer22);
        boolean boolean24 = categoryPlot19.isRangeMinorGridlinesVisible();
        boolean boolean25 = abstractCategoryDataset3.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.util.Layer layer26 = null;
        java.util.Collection collection27 = categoryPlot19.getDomainMarkers(layer26);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder28 = categoryPlot19.getDatasetRenderingOrder();
        boolean boolean29 = categoryPlot19.isSubplot();
        java.awt.Stroke stroke30 = categoryPlot19.getRangeMinorGridlineStroke();
        lineAndShapeRenderer2.setBaseOutlineStroke(stroke30);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 4 + "'", int14 == 4);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(collection27);
        org.junit.Assert.assertNotNull(datasetRenderingOrder28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        categoryPlot15.addChangeListener(plotChangeListener16);
        boolean boolean18 = categoryPlot15.isRangeZoomable();
        org.jfree.chart.axis.AxisSpace axisSpace19 = categoryPlot15.getFixedDomainAxisSpace();
        boolean boolean20 = categoryPlot15.canSelectByRegion();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(axisSpace19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("-3,-3,3,3", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        java.awt.Paint paint18 = categoryPlot15.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        categoryPlot15.setDataset(categoryDataset19);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot15.getRangeAxisEdge();
        boolean boolean22 = categoryPlot15.isRangeGridlinesVisible();
        boolean boolean23 = categoryPlot15.isDomainPannable();
        org.jfree.chart.axis.ValueAxis valueAxis25 = categoryPlot15.getRangeAxis((-8323073));
        java.lang.String str26 = categoryPlot15.getPlotType();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Category Plot" + "'", str26.equals("Category Plot"));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((-32513), (int) '#', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "");
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape7);
        chartEntity6.setArea(shape7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape7, (java.awt.Paint) color10);
        legendItem11.setURLText("{0}");
        java.awt.Stroke stroke14 = legendItem11.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart15 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendItem11, jFreeChart15);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset17 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = categoryAxis19.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D25, rectangleEdge26);
        int int28 = categoryAxis19.getCategoryLabelPositionOffset();
        categoryAxis19.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis31, categoryItemRenderer32);
        java.awt.Paint paint34 = categoryPlot33.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker35 = null;
        org.jfree.chart.util.Layer layer36 = null;
        boolean boolean37 = categoryPlot33.removeDomainMarker(marker35, layer36);
        boolean boolean38 = categoryPlot33.isRangeMinorGridlinesVisible();
        boolean boolean39 = abstractCategoryDataset17.hasListener((java.util.EventListener) categoryPlot33);
        legendItem11.setDataset((org.jfree.data.general.Dataset) abstractCategoryDataset17);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset41 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list42 = defaultCategoryDataset41.getRowKeys();
        abstractCategoryDataset17.setSelectionState((org.jfree.data.category.CategoryDatasetSelectionState) defaultCategoryDataset41);
        int int45 = defaultCategoryDataset41.getColumnIndex((java.lang.Comparable) "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]");
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = null;
        double double55 = categoryAxis47.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D53, rectangleEdge54);
        int int56 = categoryAxis47.getCategoryLabelPositionOffset();
        categoryAxis47.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis59 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer60 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot61 = new org.jfree.chart.plot.CategoryPlot(categoryDataset46, categoryAxis47, valueAxis59, categoryItemRenderer60);
        org.jfree.chart.util.ObjectList objectList64 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis66 = new org.jfree.chart.axis.CategoryAxis();
        float float67 = categoryAxis66.getMinorTickMarkInsideLength();
        boolean boolean68 = categoryAxis66.isMinorTickMarksVisible();
        categoryAxis66.setLabelURL("hi!");
        objectList64.set((int) (short) 10, (java.lang.Object) categoryAxis66);
        org.jfree.chart.plot.Plot plot72 = null;
        categoryAxis66.setPlot(plot72);
        categoryAxis66.setCategoryMargin((double) (-1));
        categoryPlot61.setDomainAxis((int) '#', categoryAxis66);
        categoryPlot61.configureRangeAxes();
        org.jfree.chart.plot.Marker marker78 = null;
        boolean boolean79 = categoryPlot61.removeDomainMarker(marker78);
        boolean boolean80 = categoryPlot61.isRangeZoomable();
        defaultCategoryDataset41.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot61);
        try {
            java.lang.Comparable comparable83 = defaultCategoryDataset41.getColumnKey((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 4 + "'", int56 == 4);
        org.junit.Assert.assertTrue("'" + float67 + "' != '" + 0.0f + "'", float67 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "");
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape7);
        chartEntity6.setArea(shape7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape7, (java.awt.Paint) color10);
        legendItem11.setURLText("{0}");
        java.awt.Stroke stroke14 = legendItem11.getOutlineStroke();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke16 = defaultDrawingSupplier15.getNextStroke();
        legendItem11.setOutlineStroke(stroke16);
        java.awt.Paint paint18 = legendItem11.getOutlinePaint();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font11 = null;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 1, font11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double14 = rectangleInsets13.getRight();
        categoryAxis0.setLabelInsets(rectangleInsets13, true);
        org.jfree.chart.util.UnitType unitType17 = rectangleInsets13.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets(unitType17, 10.0d, (double) 0, (double) (-1L), (-1.0d));
        java.awt.Shape shape27 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity29 = new org.jfree.chart.entity.ChartEntity(shape27, "");
        java.awt.Shape shape30 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent31 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape30);
        chartEntity29.setArea(shape30);
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape30, (java.awt.Paint) color33);
        legendItem34.setURLText("");
        boolean boolean37 = unitType17.equals((java.lang.Object) legendItem34);
        java.lang.String str38 = legendItem34.getLabel();
        legendItem34.setShapeVisible(false);
        java.awt.Stroke stroke41 = legendItem34.getOutlineStroke();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(unitType17);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "GradientPaintTransformType.CENTER_HORIZONTAL" + "'", str38.equals("GradientPaintTransformType.CENTER_HORIZONTAL"));
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean19 = categoryPlot15.removeDomainMarker(marker17, layer18);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot15.getRangeMarkers(layer20);
        java.awt.Font font22 = categoryPlot15.getNoDataMessageFont();
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot15.getRangeMarkers(layer23);
        categoryPlot15.setBackgroundImageAlignment((-254));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNull(collection24);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        categoryPlot15.addChangeListener(plotChangeListener16);
        categoryPlot15.setDomainCrosshairColumnKey((java.lang.Comparable) 5, false);
        categoryPlot15.mapDatasetToRangeAxis(0, 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot15.getDomainAxisEdge();
        boolean boolean25 = categoryPlot15.isDomainPannable();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer28 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer28.setBaseItemLabelsVisible(false);
        boolean boolean31 = lineAndShapeRenderer28.getBaseShapesFilled();
        java.lang.Boolean boolean33 = lineAndShapeRenderer28.getSeriesLinesVisible(100);
        java.awt.Stroke stroke35 = lineAndShapeRenderer28.lookupSeriesOutlineStroke((int) (short) 1);
        categoryPlot15.setOutlineStroke(stroke35);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNull(boolean33);
        org.junit.Assert.assertNotNull(stroke35);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabelURL("");
        categoryAxis0.setAxisLineVisible(true);
        java.lang.String str5 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setUpperMargin((double) (byte) 10);
        org.jfree.chart.event.AxisChangeListener axisChangeListener8 = null;
        categoryAxis0.addChangeListener(axisChangeListener8);
        float float10 = categoryAxis0.getTickMarkOutsideLength();
        java.lang.Comparable comparable11 = null;
        try {
            categoryAxis0.removeCategoryLabelToolTip(comparable11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.util.ObjectList objectList18 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        float float21 = categoryAxis20.getMinorTickMarkInsideLength();
        boolean boolean22 = categoryAxis20.isMinorTickMarksVisible();
        categoryAxis20.setLabelURL("hi!");
        objectList18.set((int) (short) 10, (java.lang.Object) categoryAxis20);
        org.jfree.chart.plot.Plot plot26 = null;
        categoryAxis20.setPlot(plot26);
        categoryAxis20.setCategoryMargin((double) (-1));
        categoryPlot15.setDomainAxis((int) '#', categoryAxis20);
        categoryPlot15.setDomainCrosshairRowKey((java.lang.Comparable) 5, true);
        categoryPlot15.setRangeZeroBaselineVisible(false);
        org.jfree.chart.event.PlotChangeListener plotChangeListener36 = null;
        categoryPlot15.removeChangeListener(plotChangeListener36);
        org.jfree.chart.axis.AxisSpace axisSpace38 = categoryPlot15.getFixedRangeAxisSpace();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(axisSpace38);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.util.ObjectList objectList18 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        float float21 = categoryAxis20.getMinorTickMarkInsideLength();
        boolean boolean22 = categoryAxis20.isMinorTickMarksVisible();
        categoryAxis20.setLabelURL("hi!");
        objectList18.set((int) (short) 10, (java.lang.Object) categoryAxis20);
        org.jfree.chart.plot.Plot plot26 = null;
        categoryAxis20.setPlot(plot26);
        categoryAxis20.setCategoryMargin((double) (-1));
        categoryPlot15.setDomainAxis((int) '#', categoryAxis20);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = categoryAxis20.getLabelInsets();
        categoryAxis20.setLabelAngle((double) (-1));
        java.lang.Object obj34 = categoryAxis20.clone();
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = null;
        double double44 = categoryAxis36.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D42, rectangleEdge43);
        int int45 = categoryAxis36.getCategoryLabelPositionOffset();
        categoryAxis36.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, valueAxis48, categoryItemRenderer49);
        org.jfree.chart.event.PlotChangeListener plotChangeListener51 = null;
        categoryPlot50.addChangeListener(plotChangeListener51);
        categoryPlot50.setDomainCrosshairColumnKey((java.lang.Comparable) 5, false);
        categoryPlot50.mapDatasetToRangeAxis(0, 0);
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = categoryPlot50.getDomainAxisEdge();
        int int60 = categoryPlot50.getWeight();
        categoryAxis20.setPlot((org.jfree.chart.plot.Plot) categoryPlot50);
        org.jfree.chart.axis.AxisLocation axisLocation63 = categoryPlot50.getDomainAxisLocation((int) (short) 1);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 4 + "'", int45 == 4);
        org.junit.Assert.assertNotNull(rectangleEdge59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(axisLocation63);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        java.awt.Shape shape2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape2);
        java.lang.String str4 = chartChangeEvent3.toString();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = chartChangeEvent3.getType();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) itemLabelAnchor0, jFreeChart1, chartChangeEventType5);
        org.jfree.chart.JFreeChart jFreeChart7 = null;
        chartChangeEvent6.setChart(jFreeChart7);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]" + "'", str4.equals("org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]"));
        org.junit.Assert.assertNotNull(chartChangeEventType5);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        java.awt.Shape shape29 = lineAndShapeRenderer2.getBaseLegendShape();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier30 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke31 = defaultDrawingSupplier30.getNextStroke();
        java.awt.Paint paint32 = defaultDrawingSupplier30.getNextFillPaint();
        lineAndShapeRenderer2.setBaseFillPaint(paint32);
        java.awt.Font font34 = null;
        lineAndShapeRenderer2.setBaseItemLabelFont(font34, false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(shape29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        java.awt.Font font28 = lineAndShapeRenderer2.getBaseItemLabelFont();
        boolean boolean29 = lineAndShapeRenderer2.getBaseCreateEntities();
        boolean boolean30 = lineAndShapeRenderer2.getBaseLinesVisible();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator5, true);
        java.lang.Boolean boolean9 = lineAndShapeRenderer2.getSeriesVisible((int) (short) 100);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator10 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        lineAndShapeRenderer2.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator10);
        boolean boolean14 = lineAndShapeRenderer2.getItemShapeVisible((int) 'a', 10);
        boolean boolean18 = lineAndShapeRenderer2.isItemLabelVisible((-14336), 0, true);
        lineAndShapeRenderer2.setSeriesShapesVisible(0, (java.lang.Boolean) true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = lineAndShapeRenderer2.getSeriesNegativeItemLabelPosition(0);
        org.jfree.chart.text.TextAnchor textAnchor24 = itemLabelPosition23.getRotationAnchor();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        float float26 = categoryAxis25.getMinorTickMarkInsideLength();
        boolean boolean27 = categoryAxis25.isMinorTickMarksVisible();
        boolean boolean28 = categoryAxis25.isTickLabelsVisible();
        org.jfree.chart.plot.Plot plot29 = null;
        categoryAxis25.setPlot(plot29);
        java.awt.Paint paint31 = categoryAxis25.getTickMarkPaint();
        categoryAxis25.setLabelAngle((double) (short) 1);
        boolean boolean34 = textAnchor24.equals((java.lang.Object) categoryAxis25);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.0f + "'", float26 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = categoryAxis19.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D25, rectangleEdge26);
        int int28 = categoryAxis19.getCategoryLabelPositionOffset();
        categoryAxis19.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis31, categoryItemRenderer32);
        java.awt.Paint paint34 = categoryPlot33.getRangeCrosshairPaint();
        int int35 = categoryPlot33.getWeight();
        java.lang.Comparable comparable36 = null;
        categoryPlot33.setDomainCrosshairRowKey(comparable36, true);
        org.jfree.chart.util.SortOrder sortOrder39 = categoryPlot33.getRowRenderingOrder();
        categoryPlot15.setRowRenderingOrder(sortOrder39);
        java.awt.Color color41 = org.jfree.chart.ChartColor.LIGHT_RED;
        categoryPlot15.setBackgroundPaint((java.awt.Paint) color41);
        categoryPlot15.setDomainCrosshairColumnKey((java.lang.Comparable) (byte) 1, true);
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = null;
        double double55 = categoryAxis47.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D53, rectangleEdge54);
        int int56 = categoryAxis47.getCategoryLabelPositionOffset();
        categoryAxis47.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis59 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer60 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot61 = new org.jfree.chart.plot.CategoryPlot(categoryDataset46, categoryAxis47, valueAxis59, categoryItemRenderer60);
        java.awt.Paint paint62 = categoryPlot61.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker63 = null;
        org.jfree.chart.util.Layer layer64 = null;
        boolean boolean65 = categoryPlot61.removeDomainMarker(marker63, layer64);
        org.jfree.chart.util.Layer layer66 = null;
        java.util.Collection collection67 = categoryPlot61.getRangeMarkers(layer66);
        java.awt.Font font68 = categoryPlot61.getNoDataMessageFont();
        java.awt.Color color69 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        categoryPlot61.setRangeMinorGridlinePaint((java.awt.Paint) color69);
        double double71 = categoryPlot61.getRangeCrosshairValue();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer74 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer74.setBaseItemLabelsVisible(false);
        boolean boolean77 = lineAndShapeRenderer74.getBaseShapesFilled();
        java.lang.Boolean boolean79 = lineAndShapeRenderer74.getSeriesCreateEntities(2);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator80 = null;
        lineAndShapeRenderer74.setBaseToolTipGenerator(categoryToolTipGenerator80, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray83 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { lineAndShapeRenderer74 };
        categoryPlot61.setRenderers(categoryItemRendererArray83);
        categoryPlot15.setParent((org.jfree.chart.plot.Plot) categoryPlot61);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(sortOrder39);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 4 + "'", int56 == 4);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNull(collection67);
        org.junit.Assert.assertNotNull(font68);
        org.junit.Assert.assertNotNull(color69);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertNull(boolean79);
        org.junit.Assert.assertNotNull(categoryItemRendererArray83);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.util.ObjectList objectList18 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        float float21 = categoryAxis20.getMinorTickMarkInsideLength();
        boolean boolean22 = categoryAxis20.isMinorTickMarksVisible();
        categoryAxis20.setLabelURL("hi!");
        objectList18.set((int) (short) 10, (java.lang.Object) categoryAxis20);
        org.jfree.chart.plot.Plot plot26 = null;
        categoryAxis20.setPlot(plot26);
        categoryAxis20.setCategoryMargin((double) (-1));
        categoryPlot15.setDomainAxis((int) '#', categoryAxis20);
        categoryPlot15.configureRangeAxes();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder32 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str33 = datasetRenderingOrder32.toString();
        categoryPlot15.setDatasetRenderingOrder(datasetRenderingOrder32);
        org.jfree.chart.event.AnnotationChangeEvent annotationChangeEvent35 = null;
        categoryPlot15.annotationChanged(annotationChangeEvent35);
        boolean boolean37 = categoryPlot15.getDrawSharedDomainAxis();
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = null;
        double double47 = categoryAxis39.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D45, rectangleEdge46);
        int int48 = categoryAxis39.getCategoryLabelPositionOffset();
        categoryAxis39.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, categoryAxis39, valueAxis51, categoryItemRenderer52);
        java.awt.Paint paint54 = categoryPlot53.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker55 = null;
        org.jfree.chart.util.Layer layer56 = null;
        boolean boolean57 = categoryPlot53.removeDomainMarker(marker55, layer56);
        org.jfree.chart.util.Layer layer58 = null;
        java.util.Collection collection59 = categoryPlot53.getRangeMarkers(layer58);
        java.awt.Stroke stroke60 = categoryPlot53.getDomainCrosshairStroke();
        categoryPlot15.setRangeGridlineStroke(stroke60);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str33.equals("DatasetRenderingOrder.FORWARD"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 4 + "'", int48 == 4);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(collection59);
        org.junit.Assert.assertNotNull(stroke60);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "");
        java.awt.Shape shape3 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent4 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape3);
        chartEntity2.setArea(shape3);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = categoryAxis7.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D13, rectangleEdge14);
        int int16 = categoryAxis7.getCategoryLabelPositionOffset();
        categoryAxis7.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.util.ObjectList objectList24 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        float float27 = categoryAxis26.getMinorTickMarkInsideLength();
        boolean boolean28 = categoryAxis26.isMinorTickMarksVisible();
        categoryAxis26.setLabelURL("hi!");
        objectList24.set((int) (short) 10, (java.lang.Object) categoryAxis26);
        org.jfree.chart.plot.Plot plot32 = null;
        categoryAxis26.setPlot(plot32);
        categoryAxis26.setCategoryMargin((double) (-1));
        categoryPlot21.setDomainAxis((int) '#', categoryAxis26);
        categoryPlot21.configureRangeAxes();
        org.jfree.chart.entity.PlotEntity plotEntity38 = new org.jfree.chart.entity.PlotEntity(shape3, (org.jfree.chart.plot.Plot) categoryPlot21);
        boolean boolean39 = categoryPlot21.canSelectByPoint();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = categoryPlot21.getAxisOffset();
        java.awt.Color color43 = java.awt.Color.getColor("ItemLabelAnchor.INSIDE6", (int) (byte) -1);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset44 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.event.DatasetChangeListener datasetChangeListener45 = null;
        abstractCategoryDataset44.addChangeListener(datasetChangeListener45);
        java.lang.Object obj47 = abstractCategoryDataset44.clone();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo48 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent49 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) color43, (org.jfree.data.general.Dataset) abstractCategoryDataset44, datasetChangeInfo48);
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo50 = datasetChangeEvent49.getInfo();
        categoryPlot21.datasetChanged(datasetChangeEvent49);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 4 + "'", int16 == 4);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.0f + "'", float27 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertNotNull(datasetChangeInfo50);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor29 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor30 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor29, textAnchor30);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj34 = standardGradientPaintTransformer33.clone();
        boolean boolean35 = categoryAxis32.equals((java.lang.Object) standardGradientPaintTransformer33);
        boolean boolean36 = itemLabelPosition31.equals((java.lang.Object) boolean35);
        double double37 = itemLabelPosition31.getAngle();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor38 = itemLabelPosition31.getItemLabelAnchor();
        lineAndShapeRenderer2.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition31);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator41 = null;
        lineAndShapeRenderer2.setSeriesURLGenerator(1, categoryURLGenerator41);
        java.awt.Paint paint44 = lineAndShapeRenderer2.getSeriesPaint((int) (byte) 1);
        boolean boolean46 = lineAndShapeRenderer2.isSeriesVisible((int) '4');
        org.jfree.data.KeyedObjects2D keyedObjects2D47 = new org.jfree.data.KeyedObjects2D();
        java.awt.Color color48 = java.awt.Color.BLACK;
        boolean boolean49 = keyedObjects2D47.equals((java.lang.Object) color48);
        lineAndShapeRenderer2.setBaseOutlinePaint((java.awt.Paint) color48);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator52 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        java.lang.Object obj53 = standardCategorySeriesLabelGenerator52.clone();
        lineAndShapeRenderer2.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator52);
        java.awt.Paint paint56 = lineAndShapeRenderer2.getSeriesItemLabelPaint((int) '4');
        java.awt.Shape shape58 = null;
        lineAndShapeRenderer2.setLegendShape(3, shape58);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator60 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator60, true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(itemLabelAnchor29);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor38);
        org.junit.Assert.assertNull(paint44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(obj53);
        org.junit.Assert.assertNull(paint56);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        categoryPlot15.setRangeGridlinesVisible(false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Font font11 = null;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 1, font11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double14 = rectangleInsets13.getRight();
        categoryAxis0.setLabelInsets(rectangleInsets13, true);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
        double double26 = categoryAxis18.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D24, rectangleEdge25);
        int int27 = categoryAxis18.getCategoryLabelPositionOffset();
        categoryAxis18.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis30, categoryItemRenderer31);
        java.awt.Paint paint33 = categoryPlot32.getRangeCrosshairPaint();
        java.awt.Stroke stroke34 = categoryPlot32.getDomainGridlineStroke();
        boolean boolean35 = categoryAxis0.equals((java.lang.Object) stroke34);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        java.awt.Paint paint18 = categoryPlot15.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        categoryPlot15.setDataset(categoryDataset19);
        org.jfree.chart.LegendItemCollection legendItemCollection21 = categoryPlot15.getLegendItems();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = null;
        categoryPlot15.notifyListeners(plotChangeEvent22);
        categoryPlot15.setForegroundAlpha((float) (-1));
        categoryPlot15.setBackgroundImageAlignment((int) ' ');
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.RenderingSource renderingSource31 = null;
        categoryPlot15.select((double) (byte) 100, Double.NaN, rectangle2D30, renderingSource31);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(legendItemCollection21);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        double double10 = categoryAxis2.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D8, rectangleEdge9);
        int int11 = categoryAxis2.getCategoryLabelPositionOffset();
        categoryAxis2.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis14, categoryItemRenderer15);
        java.awt.Paint paint17 = categoryPlot16.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = categoryPlot16.removeDomainMarker(marker18, layer19);
        boolean boolean21 = categoryPlot16.isRangeMinorGridlinesVisible();
        boolean boolean22 = abstractCategoryDataset0.hasListener((java.util.EventListener) categoryPlot16);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot16.getDomainMarkers(layer23);
        boolean boolean25 = categoryPlot16.isDomainPannable();
        categoryPlot16.setRangeMinorGridlinesVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryPlot16.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = categoryPlot16.getDatasetRenderingOrder();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer33.setBaseItemLabelsVisible(false);
        boolean boolean36 = lineAndShapeRenderer33.getBaseShapesFilled();
        categoryPlot16.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer33);
        lineAndShapeRenderer33.setSeriesVisibleInLegend((int) '4', (java.lang.Boolean) false, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator45 = lineAndShapeRenderer33.getItemLabelGenerator(0, 2, false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 4 + "'", int11 == 4);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNull(categoryItemLabelGenerator45);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj2 = standardGradientPaintTransformer1.clone();
        boolean boolean3 = categoryAxis0.equals((java.lang.Object) standardGradientPaintTransformer1);
        categoryAxis0.setLabelToolTip("CategoryAnchor.START");
        categoryAxis0.configure();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryAxis0.getTickLabelInsets();
        float float8 = categoryAxis0.getTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 2.0f + "'", float8 == 2.0f);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        java.awt.Font font28 = lineAndShapeRenderer2.getBaseItemLabelFont();
        java.awt.Font font30 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        lineAndShapeRenderer2.setSeriesItemLabelFont((int) 'a', font30, false);
        java.awt.Paint paint36 = lineAndShapeRenderer2.getItemFillPaint(0, (int) 'a', false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMinorTickMarkInsideLength();
        boolean boolean2 = categoryAxis0.isMinorTickMarksVisible();
        boolean boolean3 = categoryAxis0.isTickLabelsVisible();
        java.awt.Paint paint4 = categoryAxis0.getTickMarkPaint();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = categoryAxis6.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D12, rectangleEdge13);
        int int15 = categoryAxis6.getCategoryLabelPositionOffset();
        categoryAxis6.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot20.addChangeListener(plotChangeListener21);
        categoryPlot20.setDomainCrosshairColumnKey((java.lang.Comparable) 5, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        int int27 = categoryPlot20.getIndexOf(categoryItemRenderer26);
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot20);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent29 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot20);
        boolean boolean30 = categoryPlot20.isRangeZoomable();
        org.jfree.chart.axis.AxisSpace axisSpace31 = categoryPlot20.getFixedDomainAxisSpace();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 4 + "'", int15 == 4);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNull(axisSpace31);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean19 = categoryPlot15.removeDomainMarker(marker17, layer18);
        boolean boolean20 = categoryPlot15.isRangeMinorGridlinesVisible();
        categoryPlot15.setCrosshairDatasetIndex((-16777216), false);
        categoryPlot15.configureRangeAxes();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset28 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener29 = null;
        boolean boolean30 = abstractCategoryDataset28.hasListener(eventListener29);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener31 = null;
        abstractCategoryDataset28.removeChangeListener(datasetChangeListener31);
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        double double42 = categoryAxis34.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D40, rectangleEdge41);
        int int43 = categoryAxis34.getCategoryLabelPositionOffset();
        categoryAxis34.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, valueAxis46, categoryItemRenderer47);
        java.awt.Paint paint49 = categoryPlot48.getRangeCrosshairPaint();
        int int50 = categoryPlot48.getWeight();
        abstractCategoryDataset28.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot48);
        lineAndShapeRenderer27.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot48);
        boolean boolean53 = lineAndShapeRenderer27.getBaseShapesFilled();
        org.jfree.chart.renderer.RenderAttributes renderAttributes56 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint58 = renderAttributes56.getSeriesOutlinePaint((int) '4');
        java.awt.Stroke stroke59 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes56.setDefaultStroke(stroke59);
        lineAndShapeRenderer27.setSeriesStroke(0, stroke59, false);
        categoryPlot15.setRangeCrosshairStroke(stroke59);
        org.jfree.chart.axis.CategoryAxis categoryAxis65 = categoryPlot15.getDomainAxis(0);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 4 + "'", int43 == 4);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNull(paint58);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(categoryAxis65);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            defaultCategoryDataset0.removeRow(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        boolean boolean28 = lineAndShapeRenderer2.getBaseShapesFilled();
        java.awt.Shape shape29 = lineAndShapeRenderer2.getBaseLegendShape();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator30 = null;
        lineAndShapeRenderer2.setBaseItemLabelGenerator(categoryItemLabelGenerator30);
        lineAndShapeRenderer2.setSeriesItemLabelsVisible(255, (java.lang.Boolean) true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNull(shape29);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer2 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj3 = standardGradientPaintTransformer2.clone();
        boolean boolean4 = categoryAxis1.equals((java.lang.Object) standardGradientPaintTransformer2);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset9 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener10 = null;
        boolean boolean11 = abstractCategoryDataset9.hasListener(eventListener10);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener12 = null;
        abstractCategoryDataset9.removeChangeListener(datasetChangeListener12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = categoryAxis15.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D21, rectangleEdge22);
        int int24 = categoryAxis15.getCategoryLabelPositionOffset();
        categoryAxis15.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis27, categoryItemRenderer28);
        java.awt.Paint paint30 = categoryPlot29.getRangeCrosshairPaint();
        int int31 = categoryPlot29.getWeight();
        abstractCategoryDataset9.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot29);
        lineAndShapeRenderer8.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot29);
        boolean boolean34 = lineAndShapeRenderer8.getBaseShapesFilled();
        org.jfree.chart.renderer.RenderAttributes renderAttributes37 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint39 = renderAttributes37.getSeriesOutlinePaint((int) '4');
        java.awt.Stroke stroke40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes37.setDefaultStroke(stroke40);
        lineAndShapeRenderer8.setSeriesStroke(0, stroke40, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation44 = null;
        boolean boolean45 = lineAndShapeRenderer8.removeAnnotation(categoryAnnotation44);
        java.awt.Paint paint47 = null;
        lineAndShapeRenderer8.setSeriesItemLabelPaint((int) (short) 100, paint47, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer8);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer53 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer53.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator56 = null;
        lineAndShapeRenderer53.setBaseURLGenerator(categoryURLGenerator56, true);
        java.awt.Font font60 = lineAndShapeRenderer53.lookupLegendTextFont((int) (byte) 0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer63 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer63.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator66 = null;
        lineAndShapeRenderer63.setBaseURLGenerator(categoryURLGenerator66, true);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator69 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        lineAndShapeRenderer63.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator69);
        lineAndShapeRenderer53.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator69);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition75 = lineAndShapeRenderer53.getNegativeItemLabelPosition(1, 0, false);
        lineAndShapeRenderer8.setBaseNegativeItemLabelPosition(itemLabelPosition75, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition81 = lineAndShapeRenderer8.getNegativeItemLabelPosition((-16776961), 0, true);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(font60);
        org.junit.Assert.assertNotNull(itemLabelPosition75);
        org.junit.Assert.assertNotNull(itemLabelPosition81);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getRight();
        double double3 = rectangleInsets0.extendHeight(0.05d);
        double double5 = rectangleInsets0.calculateTopInset((double) 10L);
        double double6 = rectangleInsets0.getTop();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D10 = rectangleInsets0.createInsetRectangle(rectangle2D7, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor29 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor30 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor29, textAnchor30);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj34 = standardGradientPaintTransformer33.clone();
        boolean boolean35 = categoryAxis32.equals((java.lang.Object) standardGradientPaintTransformer33);
        boolean boolean36 = itemLabelPosition31.equals((java.lang.Object) boolean35);
        double double37 = itemLabelPosition31.getAngle();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor38 = itemLabelPosition31.getItemLabelAnchor();
        lineAndShapeRenderer2.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition31);
        lineAndShapeRenderer2.setBaseCreateEntities(false);
        lineAndShapeRenderer2.setSeriesCreateEntities((int) 'a', (java.lang.Boolean) true);
        java.lang.Boolean boolean46 = lineAndShapeRenderer2.getSeriesShapesFilled((int) '4');
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(itemLabelAnchor29);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor38);
        org.junit.Assert.assertNull(boolean46);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        java.awt.Stroke stroke17 = categoryPlot15.getDomainGridlineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot15.zoomRangeAxes((double) (short) -1, plotRenderingInfo19, point2D20, false);
        org.jfree.chart.axis.AxisLocation axisLocation23 = categoryPlot15.getDomainAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = null;
        double double33 = categoryAxis25.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D31, rectangleEdge32);
        int int34 = categoryAxis25.getCategoryLabelPositionOffset();
        categoryAxis25.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis37, categoryItemRenderer38);
        org.jfree.chart.event.PlotChangeListener plotChangeListener40 = null;
        categoryPlot39.addChangeListener(plotChangeListener40);
        categoryPlot39.setDomainCrosshairColumnKey((java.lang.Comparable) 5, false);
        categoryPlot39.mapDatasetToRangeAxis(0, 0);
        org.jfree.chart.plot.PlotOrientation plotOrientation48 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.awt.Color color50 = java.awt.Color.blue;
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator54 = new org.jfree.chart.util.DefaultShadowGenerator(0, color50, 0.0f, (int) '4', 0.0d);
        boolean boolean55 = plotOrientation48.equals((java.lang.Object) 0.0d);
        categoryPlot39.setOrientation(plotOrientation48);
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation23, plotOrientation48);
        org.jfree.chart.axis.AxisLocation axisLocation58 = axisLocation23.getOpposite();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 4 + "'", int34 == 4);
        org.junit.Assert.assertNotNull(plotOrientation48);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(rectangleEdge57);
        org.junit.Assert.assertNotNull(axisLocation58);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabelURL("");
        java.awt.Paint paint3 = categoryAxis0.getAxisLinePaint();
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset4 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener5 = null;
        boolean boolean6 = abstractCategoryDataset4.hasListener(eventListener5);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener7 = null;
        abstractCategoryDataset4.removeChangeListener(datasetChangeListener7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis10.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D16, rectangleEdge17);
        int int19 = categoryAxis10.getCategoryLabelPositionOffset();
        categoryAxis10.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis22, categoryItemRenderer23);
        java.awt.Paint paint25 = categoryPlot24.getRangeCrosshairPaint();
        int int26 = categoryPlot24.getWeight();
        abstractCategoryDataset4.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot24);
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo28 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent29 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) categoryAxis0, (org.jfree.data.general.Dataset) abstractCategoryDataset4, datasetChangeInfo28);
        int int30 = categoryAxis0.getCategoryLabelPositionOffset();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 4 + "'", int19 == 4);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        java.awt.Color color0 = java.awt.Color.GREEN;
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        int int5 = color4.getBlue();
        float[] floatArray9 = new float[] { '#', (byte) 10, (short) 100 };
        float[] floatArray10 = color4.getColorComponents(floatArray9);
        float[] floatArray11 = java.awt.Color.RGBtoHSB((int) (byte) 0, (int) (byte) -1, (int) (short) 10, floatArray10);
        float[] floatArray12 = color0.getColorComponents(floatArray11);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        float float4 = categoryAxis3.getMinorTickMarkInsideLength();
        boolean boolean5 = categoryAxis3.isMinorTickMarksVisible();
        categoryAxis3.setLabelURL("hi!");
        objectList1.set((int) (short) 10, (java.lang.Object) categoryAxis3);
        java.awt.Color color9 = java.awt.Color.YELLOW;
        boolean boolean10 = objectList1.equals((java.lang.Object) color9);
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape11, "");
        java.awt.Shape shape14 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape14);
        chartEntity13.setArea(shape14);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
        double double26 = categoryAxis18.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D24, rectangleEdge25);
        int int27 = categoryAxis18.getCategoryLabelPositionOffset();
        categoryAxis18.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis30, categoryItemRenderer31);
        org.jfree.chart.util.ObjectList objectList35 = new org.jfree.chart.util.ObjectList((int) (byte) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis();
        float float38 = categoryAxis37.getMinorTickMarkInsideLength();
        boolean boolean39 = categoryAxis37.isMinorTickMarksVisible();
        categoryAxis37.setLabelURL("hi!");
        objectList35.set((int) (short) 10, (java.lang.Object) categoryAxis37);
        org.jfree.chart.plot.Plot plot43 = null;
        categoryAxis37.setPlot(plot43);
        categoryAxis37.setCategoryMargin((double) (-1));
        categoryPlot32.setDomainAxis((int) '#', categoryAxis37);
        categoryPlot32.configureRangeAxes();
        org.jfree.chart.entity.PlotEntity plotEntity49 = new org.jfree.chart.entity.PlotEntity(shape14, (org.jfree.chart.plot.Plot) categoryPlot32);
        int int50 = objectList1.indexOf((java.lang.Object) shape14);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 4 + "'", int27 == 4);
        org.junit.Assert.assertTrue("'" + float38 + "' != '" + 0.0f + "'", float38 == 0.0f);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Font font2 = renderAttributes1.getDefaultLabelFont();
        java.lang.Boolean boolean3 = renderAttributes1.getDefaultLabelVisible();
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity11 = new org.jfree.chart.entity.ChartEntity(shape9, "");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor12 = org.jfree.chart.axis.CategoryAnchor.START;
        java.lang.String str13 = categoryAnchor12.toString();
        java.awt.Color color16 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", 0);
        boolean boolean17 = categoryAnchor12.equals((java.lang.Object) color16);
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("ChartChangeEventType.GENERAL", "hi!", "org.jfree.chart.event.ChartChangeEvent[source=ItemLabelAnchor.OUTSIDE7]", "org.jfree.chart.event.ChartChangeEvent[source=ItemLabelAnchor.OUTSIDE7]", shape9, (java.awt.Paint) color16);
        renderAttributes1.setSeriesPaint(4, (java.awt.Paint) color16);
        org.junit.Assert.assertNull(font2);
        org.junit.Assert.assertNull(boolean3);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(categoryAnchor12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "CategoryAnchor.START" + "'", str13.equals("CategoryAnchor.START"));
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis0.getCategoryLabelPositionOffset();
        categoryAxis0.setMaximumCategoryLabelLines(4);
        categoryAxis0.setMaximumCategoryLabelWidthRatio(1.0f);
        categoryAxis0.setMaximumCategoryLabelLines((int) (byte) 10);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = categoryAxis17.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D23, rectangleEdge24);
        int int26 = categoryAxis17.getCategoryLabelPositionOffset();
        categoryAxis17.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis29, categoryItemRenderer30);
        java.awt.Paint paint32 = categoryPlot31.getRangeCrosshairPaint();
        int int33 = categoryPlot31.getWeight();
        java.lang.Comparable comparable34 = null;
        categoryPlot31.setDomainCrosshairRowKey(comparable34, true);
        org.jfree.chart.axis.AxisSpace axisSpace37 = categoryPlot31.getFixedRangeAxisSpace();
        org.jfree.chart.util.Layer layer39 = null;
        java.util.Collection collection40 = categoryPlot31.getRangeMarkers((-2), layer39);
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) categoryPlot31);
        categoryPlot31.clearRangeMarkers();
        org.jfree.chart.util.Layer layer43 = null;
        java.util.Collection collection44 = categoryPlot31.getRangeMarkers(layer43);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 4 + "'", int26 == 4);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNull(axisSpace37);
        org.junit.Assert.assertNull(collection40);
        org.junit.Assert.assertNull(collection44);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis0.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D6, rectangleEdge7);
        categoryAxis0.setTickMarkInsideLength((float) 100L);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        lineAndShapeRenderer2.setBaseURLGenerator(categoryURLGenerator5, true);
        java.lang.Boolean boolean9 = lineAndShapeRenderer2.getSeriesVisible((int) (short) 100);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator10 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        lineAndShapeRenderer2.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator10);
        boolean boolean14 = lineAndShapeRenderer2.getItemShapeVisible((int) 'a', 10);
        lineAndShapeRenderer2.setItemLabelAnchorOffset((double) 5);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        java.awt.Shape shape2 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape2);
        java.lang.String str4 = chartChangeEvent3.toString();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = chartChangeEvent3.getType();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) itemLabelAnchor0, jFreeChart1, chartChangeEventType5);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = chartChangeEvent6.getType();
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        chartChangeEvent6.setChart(jFreeChart8);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]" + "'", str4.equals("org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]"));
        org.junit.Assert.assertNotNull(chartChangeEventType5);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset3 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = abstractCategoryDataset3.hasListener(eventListener4);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener6 = null;
        abstractCategoryDataset3.removeChangeListener(datasetChangeListener6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = null;
        double double17 = categoryAxis9.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D15, rectangleEdge16);
        int int18 = categoryAxis9.getCategoryLabelPositionOffset();
        categoryAxis9.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis21, categoryItemRenderer22);
        java.awt.Paint paint24 = categoryPlot23.getRangeCrosshairPaint();
        int int25 = categoryPlot23.getWeight();
        abstractCategoryDataset3.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot23);
        lineAndShapeRenderer2.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot23);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor29 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.jfree.chart.text.TextAnchor textAnchor30 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor29, textAnchor30);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj34 = standardGradientPaintTransformer33.clone();
        boolean boolean35 = categoryAxis32.equals((java.lang.Object) standardGradientPaintTransformer33);
        boolean boolean36 = itemLabelPosition31.equals((java.lang.Object) boolean35);
        double double37 = itemLabelPosition31.getAngle();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor38 = itemLabelPosition31.getItemLabelAnchor();
        lineAndShapeRenderer2.setSeriesPositiveItemLabelPosition((int) ' ', itemLabelPosition31);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator41 = null;
        lineAndShapeRenderer2.setSeriesURLGenerator(1, categoryURLGenerator41);
        lineAndShapeRenderer2.setBaseSeriesVisibleInLegend(true, false);
        boolean boolean47 = lineAndShapeRenderer2.isSeriesVisible(5);
        java.awt.Paint paint48 = lineAndShapeRenderer2.getBaseFillPaint();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 4 + "'", int18 == 4);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(itemLabelAnchor29);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelAnchor38);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(paint48);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        org.jfree.data.KeyedObjects2D keyedObjects2D18 = new org.jfree.data.KeyedObjects2D();
        java.awt.Color color19 = java.awt.Color.BLACK;
        boolean boolean20 = keyedObjects2D18.equals((java.lang.Object) color19);
        int int21 = color19.getTransparency();
        categoryPlot15.setRangeGridlinePaint((java.awt.Paint) color19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot15.zoomRangeAxes((double) 0L, plotRenderingInfo24, point2D25, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        categoryPlot15.panRangeAxes(0.2d, plotRenderingInfo29, point2D30);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = categoryPlot15.getRenderer();
        org.jfree.data.category.CategoryDataset categoryDataset34 = categoryPlot15.getDataset((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNull(categoryItemRenderer32);
        org.junit.Assert.assertNull(categoryDataset34);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "");
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape7);
        chartEntity6.setArea(shape7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape7, (java.awt.Paint) color10);
        legendItem11.setURLText("{0}");
        java.awt.Stroke stroke14 = legendItem11.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart15 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendItem11, jFreeChart15);
        java.awt.Stroke stroke17 = legendItem11.getLineStroke();
        boolean boolean18 = legendItem11.isLineVisible();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer2 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj3 = standardGradientPaintTransformer2.clone();
        boolean boolean4 = categoryAxis1.equals((java.lang.Object) standardGradientPaintTransformer2);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset9 = new org.jfree.data.category.AbstractCategoryDataset();
        java.util.EventListener eventListener10 = null;
        boolean boolean11 = abstractCategoryDataset9.hasListener(eventListener10);
        org.jfree.data.event.DatasetChangeListener datasetChangeListener12 = null;
        abstractCategoryDataset9.removeChangeListener(datasetChangeListener12);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = categoryAxis15.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D21, rectangleEdge22);
        int int24 = categoryAxis15.getCategoryLabelPositionOffset();
        categoryAxis15.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis27, categoryItemRenderer28);
        java.awt.Paint paint30 = categoryPlot29.getRangeCrosshairPaint();
        int int31 = categoryPlot29.getWeight();
        abstractCategoryDataset9.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot29);
        lineAndShapeRenderer8.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot29);
        boolean boolean34 = lineAndShapeRenderer8.getBaseShapesFilled();
        org.jfree.chart.renderer.RenderAttributes renderAttributes37 = new org.jfree.chart.renderer.RenderAttributes(true);
        java.awt.Paint paint39 = renderAttributes37.getSeriesOutlinePaint((int) '4');
        java.awt.Stroke stroke40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes37.setDefaultStroke(stroke40);
        lineAndShapeRenderer8.setSeriesStroke(0, stroke40, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation44 = null;
        boolean boolean45 = lineAndShapeRenderer8.removeAnnotation(categoryAnnotation44);
        java.awt.Paint paint47 = null;
        lineAndShapeRenderer8.setSeriesItemLabelPaint((int) (short) 100, paint47, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer8);
        java.awt.Stroke stroke51 = lineAndShapeRenderer8.getBaseStroke();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 4 + "'", int24 == 4);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(stroke51);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        java.awt.Paint paint1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("ItemLabelAnchor.INSIDE10", paint1);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        double double9 = categoryAxis1.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D7, rectangleEdge8);
        int int10 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis13, categoryItemRenderer14);
        java.awt.Paint paint16 = categoryPlot15.getRangeCrosshairPaint();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = categoryPlot15.getDomainGridlinePosition();
        java.awt.Paint paint18 = categoryPlot15.getBackgroundPaint();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        categoryPlot15.setDataset(categoryDataset19);
        org.jfree.chart.LegendItemCollection legendItemCollection21 = categoryPlot15.getLegendItems();
        boolean boolean22 = categoryPlot15.canSelectByPoint();
        int int23 = categoryPlot15.getRangeAxisCount();
        categoryPlot15.clearRangeAxes();
        java.awt.Paint paint25 = categoryPlot15.getDomainCrosshairPaint();
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 4 + "'", int10 == 4);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(legendItemCollection21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "");
        java.awt.Shape shape7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape7);
        chartEntity6.setArea(shape7);
        java.awt.Color color10 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("GradientPaintTransformType.CENTER_HORIZONTAL", "ItemLabelAnchor.INSIDE6", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-3.0,y=-3.0,w=6.0,h=6.0]]", shape7, (java.awt.Paint) color10);
        legendItem11.setURLText("{0}");
        java.awt.Stroke stroke14 = legendItem11.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart15 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendItem11, jFreeChart15);
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset17 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = null;
        double double27 = categoryAxis19.getCategorySeriesMiddle(1, 0, 0, (int) '#', (double) (-1), rectangle2D25, rectangleEdge26);
        int int28 = categoryAxis19.getCategoryLabelPositionOffset();
        categoryAxis19.setMaximumCategoryLabelWidthRatio((float) 10L);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis31, categoryItemRenderer32);
        java.awt.Paint paint34 = categoryPlot33.getRangeCrosshairPaint();
        org.jfree.chart.plot.Marker marker35 = null;
        org.jfree.chart.util.Layer layer36 = null;
        boolean boolean37 = categoryPlot33.removeDomainMarker(marker35, layer36);
        boolean boolean38 = categoryPlot33.isRangeMinorGridlinesVisible();
        boolean boolean39 = abstractCategoryDataset17.hasListener((java.util.EventListener) categoryPlot33);
        legendItem11.setDataset((org.jfree.data.general.Dataset) abstractCategoryDataset17);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset41 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list42 = defaultCategoryDataset41.getRowKeys();
        abstractCategoryDataset17.setSelectionState((org.jfree.data.category.CategoryDatasetSelectionState) defaultCategoryDataset41);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer45 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        java.lang.Object obj46 = standardGradientPaintTransformer45.clone();
        boolean boolean47 = categoryAxis44.equals((java.lang.Object) standardGradientPaintTransformer45);
        java.awt.Color color49 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryAxis44.setTickLabelPaint((java.lang.Comparable) (short) 10, (java.awt.Paint) color49);
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset41, categoryAxis44, valueAxis51, categoryItemRenderer52);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 4 + "'", int28 == 4);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(color49);
    }
}

