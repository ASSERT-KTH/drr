import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        java.lang.Object obj4 = categoryPlot0.clone();
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot0.getFixedRangeAxisSpace();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot0.getLegendItems();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot8.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.data.Range range11 = categoryPlot8.getDataRange(valueAxis10);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray12 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot8.setRenderers(categoryItemRendererArray12);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray16 = new org.jfree.chart.axis.ValueAxis[] { dateAxis14, dateAxis15 };
        categoryPlot8.setRangeAxes(valueAxisArray16);
        java.awt.Font font18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryPlot8.setNoDataMessageFont(font18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot20.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        int int25 = categoryPlot20.getIndexOf(categoryItemRenderer24);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor26 = categoryPlot20.getDomainGridlinePosition();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        int int28 = categoryPlot20.getIndexOf(categoryItemRenderer27);
        java.awt.Paint paint29 = categoryPlot20.getOutlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation30 = categoryPlot20.getDomainAxisLocation();
        categoryPlot8.setDomainAxisLocation(axisLocation30, false);
        categoryPlot0.setDomainAxisLocation(axisLocation30, true);
        categoryPlot0.setWeight(10);
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray12);
        org.junit.Assert.assertNotNull(valueAxisArray16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(axisLocation30);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CategoryAnchor.MIDDLE");
        categoryAxis1.setMaximumCategoryLabelLines(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        dateAxis9.setLabelToolTip("hi!");
        int int12 = categoryPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis9);
        java.awt.Font font13 = dateAxis9.getTickLabelFont();
        boolean boolean14 = dateAxis9.isAxisLineVisible();
        java.awt.Font font15 = dateAxis9.getTickLabelFont();
        categoryAxis1.setTickLabelFont((java.lang.Comparable) 192, font15);
        java.awt.Font font18 = categoryAxis1.getTickLabelFont((java.lang.Comparable) (short) 0);
        categoryAxis1.setCategoryLabelPositionOffset(10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(font18);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        xYPlot21.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot21.getRendererForDataset(xYDataset27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        xYPlot21.setDomainGridlinePaint((java.awt.Paint) color29);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot21.setRangeTickBandPaint((java.awt.Paint) color31);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = xYPlot21.getRenderer((int) (byte) 10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier35 = xYPlot21.getDrawingSupplier();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(xYItemRenderer28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNull(xYItemRenderer34);
        org.junit.Assert.assertNotNull(drawingSupplier35);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder1 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot2.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.data.Range range5 = categoryPlot2.getDataRange(valueAxis4);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray6 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot2.setRenderers(categoryItemRendererArray6);
        boolean boolean8 = datasetRenderingOrder1.equals((java.lang.Object) categoryPlot2);
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot2.getRangeAxis(0);
        org.junit.Assert.assertNotNull(datasetRenderingOrder1);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNotNull(categoryItemRendererArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(valueAxis10);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        java.awt.Color color3 = java.awt.Color.getHSBColor(0.5f, (float) (short) 10, (float) 'a');
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        float[] floatArray8 = null;
        float[] floatArray9 = color7.getRGBComponents(floatArray8);
        float[] floatArray10 = java.awt.Color.RGBtoHSB((-14336), (-29046), 91, floatArray9);
        float[] floatArray11 = color3.getComponents(floatArray10);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CategoryAnchor.MIDDLE");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 255);
        categoryAxis1.setCategoryMargin((double) 1560409200000L);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        java.awt.Stroke stroke6 = categoryPlot0.getOutlineStroke();
        java.util.List list7 = categoryPlot0.getAnnotations();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot0.getRenderer();
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNull(categoryItemRenderer8);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        java.awt.Stroke stroke7 = null;
        categoryPlot0.setOutlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L, (java.awt.Paint) color13, stroke14);
        categoryMarker15.setDrawAsLine(false);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        dateAxis19.setLabel("");
        dateAxis19.setTickLabelsVisible(false);
        dateAxis19.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot26.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        dateAxis30.setLabel("");
        dateAxis30.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource35 = dateAxis30.getStandardTickUnits();
        boolean boolean36 = categoryPlot26.equals((java.lang.Object) dateAxis30);
        float float37 = dateAxis30.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis30, xYItemRenderer38);
        org.jfree.chart.plot.IntervalMarker intervalMarker42 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot39.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker42);
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset47 = null;
        xYPlot45.setDataset(10, xYDataset47);
        org.jfree.chart.util.Layer layer50 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection51 = xYPlot45.getDomainMarkers((-1), layer50);
        java.util.Collection collection52 = xYPlot39.getRangeMarkers(0, layer50);
        categoryPlot0.addDomainMarker(categoryMarker15, layer50);
        boolean boolean54 = categoryMarker15.getDrawAsLine();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor56 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset58 = categoryPlot57.getDataset();
        boolean boolean59 = rectangleAnchor56.equals((java.lang.Object) categoryPlot57);
        java.awt.Color color60 = org.jfree.chart.ChartColor.LIGHT_RED;
        categoryPlot57.setNoDataMessagePaint((java.awt.Paint) color60);
        java.awt.Color color62 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT", color60);
        int int63 = color60.getGreen();
        int int64 = color60.getRed();
        categoryMarker15.setLabelPaint((java.awt.Paint) color60);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(tickUnitSource35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 2.0f + "'", float37 == 2.0f);
        org.junit.Assert.assertNotNull(layer50);
        org.junit.Assert.assertNull(collection51);
        org.junit.Assert.assertNull(collection52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor56);
        org.junit.Assert.assertNull(categoryDataset58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 64 + "'", int63 == 64);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 255 + "'", int64 == 255);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, 0.0d, (double) (-1L), 100.0d);
        double double6 = rectangleInsets4.calculateRightOutset((double) (byte) 10);
        double double8 = rectangleInsets4.calculateRightInset((double) (-1.0f));
        double double9 = rectangleInsets4.getRight();
        double double11 = rectangleInsets4.trimHeight((double) (-1L));
        double double12 = rectangleInsets4.getBottom();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot13.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.data.Range range16 = categoryPlot13.getDataRange(valueAxis15);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray17 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot13.setRenderers(categoryItemRendererArray17);
        boolean boolean19 = rectangleInsets4.equals((java.lang.Object) categoryItemRendererArray17);
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        try {
            rectangleInsets4.trim(rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-10.0d) + "'", double11 == (-10.0d));
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12 == (-1.0d));
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(categoryItemRendererArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset2 = categoryPlot1.getDataset();
        boolean boolean3 = rectangleAnchor0.equals((java.lang.Object) categoryPlot1);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_RED;
        categoryPlot1.setNoDataMessagePaint((java.awt.Paint) color4);
        categoryPlot1.clearDomainMarkers(1);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        try {
            categoryPlot1.addAnnotation(categoryAnnotation8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 7, (double) ' ', (double) (short) 1, (double) (-192));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { dateAxis6, dateAxis7 };
        categoryPlot0.setRangeAxes(valueAxisArray8);
        java.util.List list10 = categoryPlot0.getCategories();
        java.awt.Image image11 = null;
        categoryPlot0.setBackgroundImage(image11);
        categoryPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace15 = categoryPlot0.getFixedDomainAxisSpace();
        java.awt.Color color19 = java.awt.Color.getHSBColor((float) '4', (float) 'a', (float) 0);
        java.awt.Color color20 = color19.brighter();
        int int21 = color19.getRed();
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color19);
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(list10);
        org.junit.Assert.assertNull(axisSpace15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot21.zoomRangeAxes((double) (short) 100, plotRenderingInfo25, point2D26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = null;
        xYPlot21.setDomainAxisLocation((int) (byte) 100, axisLocation29);
        java.awt.Paint paint31 = xYPlot21.getDomainTickBandPaint();
        boolean boolean32 = xYPlot21.isDomainZeroBaselineVisible();
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        xYPlot21.drawBackgroundImage(graphics2D33, rectangle2D34);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        categoryPlot0.setBackgroundImageAlpha((float) 0L);
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot0.getDataset();
        categoryPlot0.clearAnnotations();
        double double11 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation12);
        java.awt.Color color17 = java.awt.Color.getHSBColor((float) '4', (float) 'a', (float) 0);
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color17);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        dateAxis20.setLabel("");
        dateAxis20.setTickLabelsVisible(false);
        dateAxis20.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot27.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        dateAxis31.setLabel("");
        dateAxis31.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource36 = dateAxis31.getStandardTickUnits();
        boolean boolean37 = categoryPlot27.equals((java.lang.Object) dateAxis31);
        float float38 = dateAxis31.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis31, xYItemRenderer39);
        org.jfree.chart.axis.ValueAxis valueAxis42 = xYPlot40.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        java.awt.geom.Point2D point2D45 = null;
        xYPlot40.zoomRangeAxes((double) (short) 100, plotRenderingInfo44, point2D45);
        org.jfree.chart.axis.AxisLocation axisLocation48 = xYPlot40.getRangeAxisLocation((int) (byte) 10);
        org.jfree.chart.axis.AxisLocation axisLocation50 = xYPlot40.getRangeAxisLocation((-16646144));
        categoryPlot0.setDomainAxisLocation(axisLocation50);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(tickUnitSource36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + float38 + "' != '" + 2.0f + "'", float38 == 2.0f);
        org.junit.Assert.assertNull(valueAxis42);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertNotNull(axisLocation50);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Font font8 = dateAxis4.getTickLabelFont();
        boolean boolean9 = dateAxis4.isAxisLineVisible();
        java.awt.Font font10 = dateAxis4.getTickLabelFont();
        java.awt.Shape shape11 = dateAxis4.getLeftArrow();
        dateAxis4.setTickLabelsVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = dateAxis4.getLabelInsets();
        double double16 = rectangleInsets14.calculateTopOutset((double) 175);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 3.0d + "'", double16 == 3.0d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        boolean boolean10 = categoryPlot0.render(graphics2D6, rectangle2D7, (int) ' ', plotRenderingInfo9);
        int int11 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.plot.IntervalMarker intervalMarker15 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.awt.Stroke stroke16 = null;
        intervalMarker15.setOutlineStroke(stroke16);
        java.awt.Stroke stroke18 = intervalMarker15.getOutlineStroke();
        java.awt.Font font19 = intervalMarker15.getLabelFont();
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean22 = categoryPlot0.removeRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker15, layer20, true);
        intervalMarker15.setEndValue((double) 10);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertNull(stroke18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        xYPlot21.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot21.getRendererForDataset(xYDataset27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        xYPlot21.setDomainGridlinePaint((java.awt.Paint) color29);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot21.setRangeTickBandPaint((java.awt.Paint) color31);
        org.jfree.chart.axis.AxisLocation axisLocation33 = xYPlot21.getRangeAxisLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        xYPlot21.setAxisOffset(rectangleInsets34);
        boolean boolean36 = xYPlot21.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisSpace axisSpace37 = xYPlot21.getFixedRangeAxisSpace();
        xYPlot21.clearDomainAxes();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(xYItemRenderer28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(axisSpace37);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot1.getIndexOf(categoryItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        boolean boolean11 = categoryPlot1.render(graphics2D7, rectangle2D8, (int) ' ', plotRenderingInfo10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = null;
        categoryPlot1.axisChanged(axisChangeEvent12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot1);
        boolean boolean15 = textAnchor0.equals((java.lang.Object) categoryPlot1);
        int int16 = categoryPlot1.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot21.getRangeAxisEdge();
        java.awt.Image image27 = xYPlot21.getBackgroundImage();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNull(image27);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color1);
        boolean boolean3 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent4);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setVerticalTickLabels(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        java.text.NumberFormat numberFormat6 = null;
        numberAxis1.setNumberFormatOverride(numberFormat6);
        java.text.NumberFormat numberFormat8 = null;
        numberAxis1.setNumberFormatOverride(numberFormat8);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isVerticalTickLabels();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        dateAxis5.setLabelToolTip("hi!");
        int int8 = categoryPlot1.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis5);
        java.awt.Font font9 = dateAxis5.getTickLabelFont();
        java.awt.Paint paint10 = dateAxis5.getTickMarkPaint();
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape12 = dateAxis11.getUpArrow();
        dateAxis11.setLabelAngle((double) 0.0f);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer15);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset21 = categoryPlot20.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.data.Range range23 = categoryPlot20.getDataRange(valueAxis22);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray24 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot20.setRenderers(categoryItemRendererArray24);
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray28 = new org.jfree.chart.axis.ValueAxis[] { dateAxis26, dateAxis27 };
        categoryPlot20.setRangeAxes(valueAxisArray28);
        java.util.List list30 = categoryPlot20.getCategories();
        java.awt.Image image31 = null;
        categoryPlot20.setBackgroundImage(image31);
        categoryPlot20.setDomainGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot20.getRangeAxisEdge();
        try {
            java.util.List list36 = dateAxis5.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNull(categoryDataset21);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNotNull(categoryItemRendererArray24);
        org.junit.Assert.assertNotNull(valueAxisArray28);
        org.junit.Assert.assertNull(list30);
        org.junit.Assert.assertNotNull(rectangleEdge35);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, 0.0d, (double) (-1L), 100.0d);
        double double6 = rectangleInsets4.calculateRightOutset((double) (byte) 10);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets4.createInsetRectangle(rectangle2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        java.awt.Paint paint1 = xYPlot0.getRangeTickBandPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot2.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.data.Range range5 = categoryPlot2.getDataRange(valueAxis4);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray6 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot2.setRenderers(categoryItemRendererArray6);
        java.lang.Object obj8 = categoryPlot2.clone();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        dateAxis10.setLabelToolTip("hi!");
        categoryPlot2.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis10, false);
        categoryPlot2.setNoDataMessage("");
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot2.getRangeAxisEdge((int) (short) 1);
        org.jfree.chart.plot.IntervalMarker intervalMarker21 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.lang.Object obj22 = intervalMarker21.clone();
        categoryPlot2.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker21);
        org.jfree.chart.util.Layer layer24 = null;
        try {
            xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker21, layer24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNotNull(categoryItemRendererArray6);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        int int8 = categoryPlot0.getIndexOf(categoryItemRenderer7);
        java.awt.Paint paint9 = categoryPlot0.getOutlinePaint();
        boolean boolean10 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot0.getRangeAxisLocation(1);
        try {
            categoryPlot0.mapDatasetToRangeAxis((-14336), (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(axisLocation12);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        categoryPlot0.setRangeCrosshairValue((double) 0.0f);
        categoryPlot0.setBackgroundAlpha((float) (-14336));
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = null;
        java.awt.geom.Point2D point2D16 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D14, rectangleAnchor15);
        categoryPlot11.zoomRangeAxes((double) (-1), plotRenderingInfo13, point2D16);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot18.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        dateAxis22.setLabelToolTip("hi!");
        int int25 = categoryPlot18.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis22);
        java.awt.Font font26 = dateAxis22.getTickLabelFont();
        categoryPlot11.setNoDataMessageFont(font26);
        org.jfree.chart.plot.Plot plot28 = categoryPlot11.getRootPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("CategoryAnchor.MIDDLE");
        categoryAxis31.setMaximumCategoryLabelLines(0);
        categoryPlot11.setDomainAxis((int) '#', categoryAxis31);
        categoryPlot0.setDomainAxis(categoryAxis31);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNotNull(point2D16);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(plot28);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.CENTER_RIGHT" + "'", str1.equals("TextAnchor.CENTER_RIGHT"));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        categoryPlot0.setBackgroundImageAlpha((float) 0L);
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot0.getDataset();
        categoryPlot0.clearAnnotations();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        boolean boolean15 = categoryPlot0.render(graphics2D11, rectangle2D12, (int) (byte) -1, plotRenderingInfo14);
        org.jfree.chart.util.ObjectList objectList16 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        int int22 = categoryPlot17.getIndexOf(categoryItemRenderer21);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor23 = categoryPlot17.getDomainGridlinePosition();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        int int25 = categoryPlot17.getIndexOf(categoryItemRenderer24);
        boolean boolean26 = objectList16.equals((java.lang.Object) categoryPlot17);
        org.jfree.chart.axis.AxisLocation axisLocation28 = categoryPlot17.getDomainAxisLocation((-1));
        categoryPlot0.setDomainAxisLocation(axisLocation28);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset31 = categoryPlot30.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.data.Range range33 = categoryPlot30.getDataRange(valueAxis32);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray34 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot30.setRenderers(categoryItemRendererArray34);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray38 = new org.jfree.chart.axis.ValueAxis[] { dateAxis36, dateAxis37 };
        categoryPlot30.setRangeAxes(valueAxisArray38);
        java.awt.Font font40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryPlot30.setNoDataMessageFont(font40);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("CategoryAnchor.MIDDLE");
        categoryPlot30.setDomainAxis(categoryAxis43);
        categoryAxis43.clearCategoryLabelToolTips();
        java.lang.String str47 = categoryAxis43.getCategoryLabelToolTip((java.lang.Comparable) "java.awt.Color[r=0,g=128,b=128]");
        categoryPlot0.setDomainAxis(categoryAxis43);
        double double49 = categoryAxis43.getLabelAngle();
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertNull(categoryDataset31);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertNotNull(categoryItemRendererArray34);
        org.junit.Assert.assertNotNull(valueAxisArray38);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        boolean boolean10 = categoryPlot0.render(graphics2D6, rectangle2D7, (int) ' ', plotRenderingInfo9);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = null;
        categoryPlot0.axisChanged(axisChangeEvent11);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        dateAxis18.setLabelToolTip("hi!");
        int int21 = categoryPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis18);
        java.awt.Font font22 = dateAxis18.getTickLabelFont();
        boolean boolean23 = dateAxis18.isAxisLineVisible();
        java.awt.Font font24 = dateAxis18.getTickLabelFont();
        java.awt.Shape shape25 = dateAxis18.getLeftArrow();
        dateAxis18.setTickLabelsVisible(false);
        boolean boolean28 = dateAxis18.isPositiveArrowVisible();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis18);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { dateAxis6, dateAxis7 };
        categoryPlot0.setRangeAxes(valueAxisArray8);
        categoryPlot0.clearDomainMarkers(0);
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertNotNull(valueAxisArray8);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        xYPlot0.setDataset(10, xYDataset2);
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection6 = xYPlot0.getDomainMarkers((-1), layer5);
        boolean boolean7 = xYPlot0.isRangeGridlinesVisible();
        boolean boolean8 = xYPlot0.isDomainGridlinesVisible();
        java.awt.Stroke stroke9 = xYPlot0.getDomainZeroBaselineStroke();
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.lang.Class class3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.setLabelToolTip("hi!");
        int int11 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis8);
        java.awt.Font font12 = dateAxis8.getTickLabelFont();
        java.util.Date date13 = dateAxis8.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape15 = dateAxis14.getUpArrow();
        java.util.TimeZone timeZone16 = dateAxis14.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date13, timeZone16);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("ChartChangeEventType.NEW_DATASET", timeZone16);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=0,g=128,b=128]", timeZone16);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date0, timeZone16);
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(timeZone16);
        org.junit.Assert.assertNull(regularTimePeriod17);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        dateAxis0.setTickMarkPaint(paint1);
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 13, (double) '#', 0.0d, 1.0E-8d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.RangeType rangeType2 = numberAxis1.getRangeType();
        boolean boolean3 = numberAxis1.isVisible();
        numberAxis1.setPositiveArrowVisible(false);
        org.junit.Assert.assertNotNull(rangeType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.util.List list8 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxis(100);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        categoryPlot0.addChangeListener(plotChangeListener11);
        categoryPlot0.setBackgroundImageAlignment(0);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        try {
            categoryPlot0.drawBackground(graphics2D15, rectangle2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNull(categoryAxis10);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder1 = xYPlot0.getDatasetRenderingOrder();
        int int2 = xYPlot0.getDomainAxisCount();
        org.junit.Assert.assertNotNull(datasetRenderingOrder1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        dateAxis11.setLabelToolTip("hi!");
        int int14 = categoryPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Font font15 = dateAxis11.getTickLabelFont();
        categoryPlot0.setNoDataMessageFont(font15);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = categoryPlot0.getDomainMarkers(layer17);
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace19, false);
        java.awt.Stroke stroke22 = categoryPlot0.getRangeCrosshairStroke();
        categoryPlot0.setAnchorValue((double) 10.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset26 = categoryPlot25.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.data.Range range28 = categoryPlot25.getDataRange(valueAxis27);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray29 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot25.setRenderers(categoryItemRendererArray29);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray33 = new org.jfree.chart.axis.ValueAxis[] { dateAxis31, dateAxis32 };
        categoryPlot25.setRangeAxes(valueAxisArray33);
        java.awt.Font font35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryPlot25.setNoDataMessageFont(font35);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("CategoryAnchor.MIDDLE");
        categoryPlot25.setDomainAxis(categoryAxis38);
        java.util.List list40 = categoryPlot0.getCategoriesForAxis(categoryAxis38);
        org.jfree.chart.axis.AxisLocation axisLocation42 = categoryPlot0.getDomainAxisLocation(5);
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = new org.jfree.chart.axis.CategoryAxis("CategoryAnchor.MIDDLE");
        categoryAxis45.setMaximumCategoryLabelLines(0);
        double double48 = categoryAxis45.getUpperMargin();
        categoryAxis45.addCategoryLabelToolTip((java.lang.Comparable) (byte) -1, "");
        categoryPlot0.setDomainAxis(8, categoryAxis45);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(categoryDataset26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(categoryItemRendererArray29);
        org.junit.Assert.assertNotNull(valueAxisArray33);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(list40);
        org.junit.Assert.assertNotNull(axisLocation42);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.05d + "'", double48 == 0.05d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        xYPlot21.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot21.getRendererForDataset(xYDataset27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        xYPlot21.setDomainGridlinePaint((java.awt.Paint) color29);
        xYPlot21.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace32 = xYPlot21.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(xYItemRenderer28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNull(axisSpace32);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        xYPlot21.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot21.getRendererForDataset(xYDataset27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        xYPlot21.setDomainGridlinePaint((java.awt.Paint) color29);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot21.setRangeTickBandPaint((java.awt.Paint) color31);
        org.jfree.chart.axis.AxisLocation axisLocation33 = xYPlot21.getRangeAxisLocation();
        java.awt.Paint paint34 = xYPlot21.getNoDataMessagePaint();
        org.jfree.data.general.DatasetGroup datasetGroup35 = xYPlot21.getDatasetGroup();
        java.awt.Paint paint36 = xYPlot21.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(xYItemRenderer28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNull(datasetGroup35);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.TOP_RIGHT");
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot2.getDataset();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace4, true);
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot2);
        numberAxis1.setLabelURL("RectangleAnchor.TOP_LEFT");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = numberAxis1.getTickUnit();
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNotNull(numberTickUnit10);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        boolean boolean10 = categoryPlot0.render(graphics2D6, rectangle2D7, (int) ' ', plotRenderingInfo9);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = null;
        categoryPlot0.axisChanged(axisChangeEvent11);
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L, (java.awt.Paint) color14, stroke15);
        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        categoryMarker16.setLabelTextAnchor(textAnchor17);
        java.awt.Color color19 = java.awt.Color.PINK;
        int int20 = color19.getGreen();
        categoryMarker16.setOutlinePaint((java.awt.Paint) color19);
        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        categoryMarker16.setLabelTextAnchor(textAnchor22);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType24 = categoryMarker16.getLabelOffsetType();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot25.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        dateAxis29.setLabelToolTip("hi!");
        int int32 = categoryPlot25.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis29);
        java.util.List list33 = categoryPlot25.getAnnotations();
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = categoryPlot25.getRangeAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset37 = categoryPlot36.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.data.Range range39 = categoryPlot36.getDataRange(valueAxis38);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray40 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot36.setRenderers(categoryItemRendererArray40);
        org.jfree.chart.plot.IntervalMarker intervalMarker44 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.awt.Stroke stroke45 = null;
        intervalMarker44.setOutlineStroke(stroke45);
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot47.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis51 = new org.jfree.chart.axis.DateAxis();
        dateAxis51.setLabelToolTip("hi!");
        int int54 = categoryPlot47.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis51);
        java.util.List list55 = categoryPlot47.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = categoryPlot47.getDomainAxis(100);
        org.jfree.chart.event.PlotChangeListener plotChangeListener58 = null;
        categoryPlot47.addChangeListener(plotChangeListener58);
        categoryPlot47.setBackgroundImageAlignment(0);
        categoryPlot47.setOutlineVisible(false);
        categoryPlot47.setBackgroundImageAlpha((float) 0L);
        org.jfree.chart.util.Layer layer67 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection68 = categoryPlot47.getDomainMarkers(0, layer67);
        categoryPlot36.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker44, layer67);
        java.util.Collection collection70 = categoryPlot25.getRangeMarkers(1, layer67);
        boolean boolean71 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker16, layer67);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 175 + "'", int20 == 175);
        org.junit.Assert.assertNotNull(textAnchor22);
        org.junit.Assert.assertNotNull(lengthAdjustmentType24);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(list33);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertNull(categoryDataset37);
        org.junit.Assert.assertNull(range39);
        org.junit.Assert.assertNotNull(categoryItemRendererArray40);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertNotNull(list55);
        org.junit.Assert.assertNull(categoryAxis57);
        org.junit.Assert.assertNotNull(layer67);
        org.junit.Assert.assertNull(collection68);
        org.junit.Assert.assertNull(collection70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.setLabelToolTip("hi!");
        int int10 = categoryPlot3.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis7);
        java.awt.Font font11 = dateAxis7.getTickLabelFont();
        boolean boolean12 = dateAxis7.isAxisLineVisible();
        java.awt.Font font13 = dateAxis7.getTickLabelFont();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis7, xYItemRenderer14);
        numberAxis2.centerRange((double) (byte) 0);
        numberAxis2.setAutoRangeIncludesZero(false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        xYPlot21.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot21.getRendererForDataset(xYDataset27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        xYPlot21.setDomainGridlinePaint((java.awt.Paint) color29);
        org.jfree.chart.axis.ValueAxis valueAxis31 = xYPlot21.getRangeAxis();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(xYItemRenderer28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNull(valueAxis31);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        float[] floatArray11 = new float[] { (-1.0f), (short) 100, (byte) -1, (short) 0, (byte) -1 };
        float[] floatArray12 = java.awt.Color.RGBtoHSB((int) (short) 1, (int) (byte) 0, 0, floatArray11);
        float[] floatArray13 = java.awt.Color.RGBtoHSB((int) 'a', 0, (int) (byte) 10, floatArray12);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot21.zoomRangeAxes((double) (short) 100, plotRenderingInfo25, point2D26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = null;
        xYPlot21.setDomainAxisLocation((int) (byte) 100, axisLocation29);
        java.awt.Paint paint31 = xYPlot21.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.axis.ValueAxis valueAxis34 = xYPlot21.getDomainAxis();
        org.jfree.chart.plot.IntervalMarker intervalMarker38 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = intervalMarker38.getLabelAnchor();
        java.awt.Stroke stroke40 = intervalMarker38.getStroke();
        org.jfree.chart.util.Layer layer41 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean43 = xYPlot21.removeRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker38, layer41, false);
        java.awt.Stroke stroke44 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        xYPlot21.setDomainCrosshairStroke(stroke44);
        java.util.List list46 = xYPlot21.getAnnotations();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(valueAxis34);
        org.junit.Assert.assertNotNull(rectangleAnchor39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(layer41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(list46);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        float float26 = xYPlot21.getBackgroundAlpha();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot27.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        dateAxis31.setLabelToolTip("hi!");
        int int34 = categoryPlot27.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis31);
        categoryPlot27.clearRangeMarkers();
        org.jfree.chart.plot.IntervalMarker intervalMarker38 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.awt.Stroke stroke39 = null;
        intervalMarker38.setOutlineStroke(stroke39);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset42 = categoryPlot41.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.data.Range range44 = categoryPlot41.getDataRange(valueAxis43);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray45 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot41.setRenderers(categoryItemRendererArray45);
        java.lang.Object obj47 = categoryPlot41.clone();
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis();
        dateAxis49.setLabelToolTip("hi!");
        categoryPlot41.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis49, false);
        categoryPlot41.setNoDataMessage("");
        boolean boolean56 = categoryPlot41.isRangeGridlinesVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset58 = categoryPlot57.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis59 = null;
        org.jfree.data.Range range60 = categoryPlot57.getDataRange(valueAxis59);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray61 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot57.setRenderers(categoryItemRendererArray61);
        org.jfree.chart.axis.DateAxis dateAxis63 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis64 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray65 = new org.jfree.chart.axis.ValueAxis[] { dateAxis63, dateAxis64 };
        categoryPlot57.setRangeAxes(valueAxisArray65);
        java.awt.Font font67 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryPlot57.setNoDataMessageFont(font67);
        categoryPlot41.setNoDataMessageFont(font67);
        intervalMarker38.setLabelFont(font67);
        org.jfree.chart.util.Layer layer71 = org.jfree.chart.util.Layer.BACKGROUND;
        categoryPlot27.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker38, layer71);
        java.util.Collection collection73 = xYPlot21.getDomainMarkers(layer71);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNull(categoryDataset42);
        org.junit.Assert.assertNull(range44);
        org.junit.Assert.assertNotNull(categoryItemRendererArray45);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNull(categoryDataset58);
        org.junit.Assert.assertNull(range60);
        org.junit.Assert.assertNotNull(categoryItemRendererArray61);
        org.junit.Assert.assertNotNull(valueAxisArray65);
        org.junit.Assert.assertNotNull(font67);
        org.junit.Assert.assertNotNull(layer71);
        org.junit.Assert.assertNull(collection73);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.clearRangeMarkers();
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        java.lang.Object obj6 = categoryPlot0.clone();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.setLabelToolTip("hi!");
        categoryPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis8, false);
        categoryPlot0.setNoDataMessage("");
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot0.getRangeAxisEdge((int) (short) 1);
        org.jfree.chart.LegendItemCollection legendItemCollection17 = categoryPlot0.getFixedLegendItems();
        java.awt.Paint paint18 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((-10.0d));
        boolean boolean21 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) valueMarker20);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("CategoryAnchor.MIDDLE");
        categoryAxis23.setMaximumCategoryLabelLines(0);
        int int26 = categoryPlot0.getDomainAxisIndex(categoryAxis23);
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNull(legendItemCollection17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot21.zoomRangeAxes((double) (short) 100, plotRenderingInfo25, point2D26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = null;
        xYPlot21.setDomainAxisLocation((int) (byte) 100, axisLocation29);
        java.awt.Paint paint31 = xYPlot21.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.axis.ValueAxis valueAxis34 = xYPlot21.getDomainAxis();
        org.jfree.chart.plot.IntervalMarker intervalMarker38 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = intervalMarker38.getLabelAnchor();
        java.awt.Stroke stroke40 = intervalMarker38.getStroke();
        org.jfree.chart.util.Layer layer41 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean43 = xYPlot21.removeRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker38, layer41, false);
        java.awt.Stroke stroke44 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        xYPlot21.setDomainCrosshairStroke(stroke44);
        boolean boolean46 = xYPlot21.isOutlineVisible();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(valueAxis34);
        org.junit.Assert.assertNotNull(rectangleAnchor39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(layer41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        int int8 = categoryPlot0.getIndexOf(categoryItemRenderer7);
        java.awt.Paint paint9 = categoryPlot0.getOutlinePaint();
        java.awt.Color color10 = java.awt.Color.red;
        java.awt.Color color11 = java.awt.Color.BLUE;
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.color.ColorSpace colorSpace13 = color12.getColorSpace();
        float[] floatArray22 = new float[] { (-1.0f), (short) 100, (byte) -1, (short) 0, (byte) -1 };
        float[] floatArray23 = java.awt.Color.RGBtoHSB((int) (short) 1, (int) (byte) 0, 0, floatArray22);
        float[] floatArray24 = color11.getColorComponents(colorSpace13, floatArray23);
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.color.ColorSpace colorSpace26 = color25.getColorSpace();
        java.awt.Color color27 = java.awt.Color.BLUE;
        java.awt.Color color28 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.color.ColorSpace colorSpace29 = color28.getColorSpace();
        float[] floatArray38 = new float[] { (-1.0f), (short) 100, (byte) -1, (short) 0, (byte) -1 };
        float[] floatArray39 = java.awt.Color.RGBtoHSB((int) (short) 1, (int) (byte) 0, 0, floatArray38);
        float[] floatArray40 = color27.getColorComponents(colorSpace29, floatArray39);
        float[] floatArray41 = color11.getComponents(colorSpace26, floatArray40);
        float[] floatArray42 = color10.getRGBComponents(floatArray41);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color10);
        org.jfree.chart.plot.IntervalMarker intervalMarker47 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.lang.Object obj48 = intervalMarker47.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot49.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis();
        dateAxis53.setLabelToolTip("hi!");
        int int56 = categoryPlot49.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis53);
        java.util.List list57 = categoryPlot49.getAnnotations();
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = categoryPlot49.getRangeAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset61 = categoryPlot60.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis62 = null;
        org.jfree.data.Range range63 = categoryPlot60.getDataRange(valueAxis62);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray64 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot60.setRenderers(categoryItemRendererArray64);
        org.jfree.chart.plot.IntervalMarker intervalMarker68 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.awt.Stroke stroke69 = null;
        intervalMarker68.setOutlineStroke(stroke69);
        org.jfree.chart.plot.CategoryPlot categoryPlot71 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot71.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis75 = new org.jfree.chart.axis.DateAxis();
        dateAxis75.setLabelToolTip("hi!");
        int int78 = categoryPlot71.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis75);
        java.util.List list79 = categoryPlot71.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis81 = categoryPlot71.getDomainAxis(100);
        org.jfree.chart.event.PlotChangeListener plotChangeListener82 = null;
        categoryPlot71.addChangeListener(plotChangeListener82);
        categoryPlot71.setBackgroundImageAlignment(0);
        categoryPlot71.setOutlineVisible(false);
        categoryPlot71.setBackgroundImageAlpha((float) 0L);
        org.jfree.chart.util.Layer layer91 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection92 = categoryPlot71.getDomainMarkers(0, layer91);
        categoryPlot60.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker68, layer91);
        java.util.Collection collection94 = categoryPlot49.getRangeMarkers(1, layer91);
        boolean boolean96 = categoryPlot0.removeDomainMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) intervalMarker47, layer91, false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(colorSpace13);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(colorSpace26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(colorSpace29);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(obj48);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
        org.junit.Assert.assertNotNull(list57);
        org.junit.Assert.assertNotNull(rectangleEdge58);
        org.junit.Assert.assertNull(categoryDataset61);
        org.junit.Assert.assertNull(range63);
        org.junit.Assert.assertNotNull(categoryItemRendererArray64);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + (-1) + "'", int78 == (-1));
        org.junit.Assert.assertNotNull(list79);
        org.junit.Assert.assertNull(categoryAxis81);
        org.junit.Assert.assertNotNull(layer91);
        org.junit.Assert.assertNull(collection92);
        org.junit.Assert.assertNull(collection94);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        xYPlot21.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot21.getRendererForDataset(xYDataset27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        xYPlot21.setDomainGridlinePaint((java.awt.Paint) color29);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot21.setRangeTickBandPaint((java.awt.Paint) color31);
        org.jfree.chart.axis.AxisLocation axisLocation33 = xYPlot21.getRangeAxisLocation();
        java.awt.Paint paint34 = xYPlot21.getNoDataMessagePaint();
        org.jfree.data.general.DatasetGroup datasetGroup35 = xYPlot21.getDatasetGroup();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent36 = null;
        xYPlot21.axisChanged(axisChangeEvent36);
        java.awt.Paint paint38 = xYPlot21.getDomainZeroBaselinePaint();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation39 = null;
        try {
            boolean boolean41 = xYPlot21.removeAnnotation(xYAnnotation39, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(xYItemRenderer28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNull(datasetGroup35);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = xYPlot21.getDomainAxisEdge((int) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        xYPlot21.setRenderer((int) (short) 100, xYItemRenderer29, false);
        boolean boolean32 = xYPlot21.isOutlineVisible();
        org.jfree.data.xy.XYDataset xYDataset34 = xYPlot21.getDataset(0);
        org.jfree.chart.LegendItemCollection legendItemCollection35 = xYPlot21.getFixedLegendItems();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNull(xYDataset34);
        org.junit.Assert.assertNull(legendItemCollection35);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, 0.0d, (double) (-1L), 100.0d);
        double double5 = rectangleInsets4.getRight();
        double double7 = rectangleInsets4.trimWidth((double) (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot8.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.data.Range range11 = categoryPlot8.getDataRange(valueAxis10);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray12 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot8.setRenderers(categoryItemRendererArray12);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray16 = new org.jfree.chart.axis.ValueAxis[] { dateAxis14, dateAxis15 };
        categoryPlot8.setRangeAxes(valueAxisArray16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot8.zoomDomainAxes((double) 10L, (double) (byte) -1, plotRenderingInfo20, point2D21);
        boolean boolean23 = rectangleInsets4.equals((java.lang.Object) 10L);
        double double25 = rectangleInsets4.calculateTopOutset((double) (-14336));
        double double27 = rectangleInsets4.calculateRightOutset(0.05d);
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType29 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str30 = lengthAdjustmentType29.toString();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType31 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset33 = categoryPlot32.getDataset();
        boolean boolean34 = lengthAdjustmentType31.equals((java.lang.Object) categoryPlot32);
        try {
            java.awt.geom.Rectangle2D rectangle2D35 = rectangleInsets4.createAdjustedRectangle(rectangle2D28, lengthAdjustmentType29, lengthAdjustmentType31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-101.0d) + "'", double7 == (-101.0d));
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray12);
        org.junit.Assert.assertNotNull(valueAxisArray16);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 10.0d + "'", double25 == 10.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 100.0d + "'", double27 == 100.0d);
        org.junit.Assert.assertNotNull(lengthAdjustmentType29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "NO_CHANGE" + "'", str30.equals("NO_CHANGE"));
        org.junit.Assert.assertNotNull(lengthAdjustmentType31);
        org.junit.Assert.assertNull(categoryDataset33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot1.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor7 = categoryPlot1.getDomainGridlinePosition();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot1.getIndexOf(categoryItemRenderer8);
        boolean boolean10 = objectList0.equals((java.lang.Object) categoryPlot1);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.RangeType rangeType13 = numberAxis12.getRangeType();
        boolean boolean14 = objectList0.equals((java.lang.Object) rangeType13);
        java.lang.Object obj16 = objectList0.get((int) (byte) 100);
        java.lang.Object obj18 = null;
        try {
            objectList0.set((int) (byte) -1, obj18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rangeType13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(obj16);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        dateAxis11.setLabelToolTip("hi!");
        int int14 = categoryPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Font font15 = dateAxis11.getTickLabelFont();
        categoryPlot0.setNoDataMessageFont(font15);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = categoryPlot0.getDomainMarkers(layer17);
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace19, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker25 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.awt.Stroke stroke26 = null;
        intervalMarker25.setOutlineStroke(stroke26);
        intervalMarker25.setEndValue((double) ' ');
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset31 = categoryPlot30.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.data.Range range33 = categoryPlot30.getDataRange(valueAxis32);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray34 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot30.setRenderers(categoryItemRendererArray34);
        org.jfree.chart.plot.IntervalMarker intervalMarker38 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.awt.Stroke stroke39 = null;
        intervalMarker38.setOutlineStroke(stroke39);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot41.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis();
        dateAxis45.setLabelToolTip("hi!");
        int int48 = categoryPlot41.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis45);
        java.util.List list49 = categoryPlot41.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = categoryPlot41.getDomainAxis(100);
        org.jfree.chart.event.PlotChangeListener plotChangeListener52 = null;
        categoryPlot41.addChangeListener(plotChangeListener52);
        categoryPlot41.setBackgroundImageAlignment(0);
        categoryPlot41.setOutlineVisible(false);
        categoryPlot41.setBackgroundImageAlpha((float) 0L);
        org.jfree.chart.util.Layer layer61 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection62 = categoryPlot41.getDomainMarkers(0, layer61);
        categoryPlot30.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker38, layer61);
        categoryPlot0.addRangeMarker(6, (org.jfree.chart.plot.Marker) intervalMarker25, layer61);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNull(categoryDataset31);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertNotNull(categoryItemRendererArray34);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(list49);
        org.junit.Assert.assertNull(categoryAxis51);
        org.junit.Assert.assertNotNull(layer61);
        org.junit.Assert.assertNull(collection62);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = categoryPlot0.getDomainGridlinePosition();
        boolean boolean8 = categoryAnchor6.equals((java.lang.Object) (short) 100);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot1.getIndexOf(categoryItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        boolean boolean11 = categoryPlot1.render(graphics2D7, rectangle2D8, (int) ' ', plotRenderingInfo10);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = null;
        categoryPlot1.axisChanged(axisChangeEvent12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot1);
        boolean boolean15 = textAnchor0.equals((java.lang.Object) categoryPlot1);
        float float16 = categoryPlot1.getBackgroundAlpha();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 1.0f + "'", float16 == 1.0f);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        boolean boolean26 = xYPlot21.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = xYPlot21.getRangeAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace28 = null;
        xYPlot21.setFixedDomainAxisSpace(axisSpace28);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) '4', (float) 'a', (float) 0);
        java.awt.Color color4 = color3.brighter();
        int int5 = color3.getRed();
        int int6 = color3.getAlpha();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 255 + "'", int6 == 255);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextFillPaint();
        java.awt.Stroke stroke3 = defaultDrawingSupplier0.getNextOutlineStroke();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        xYPlot21.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot21.getRendererForDataset(xYDataset27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        xYPlot21.setDomainGridlinePaint((java.awt.Paint) color29);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot21.setRangeTickBandPaint((java.awt.Paint) color31);
        org.jfree.chart.axis.AxisLocation axisLocation33 = xYPlot21.getRangeAxisLocation();
        java.awt.Paint paint34 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        xYPlot21.setDomainZeroBaselinePaint(paint34);
        java.awt.geom.Point2D point2D36 = xYPlot21.getQuadrantOrigin();
        java.awt.Stroke stroke37 = xYPlot21.getDomainCrosshairStroke();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(xYItemRenderer28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(point2D36);
        org.junit.Assert.assertNotNull(stroke37);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = dateAxis0.getRange();
        dateAxis0.setUpperBound((double) '#');
        dateAxis0.centerRange((double) (byte) -1);
        double double6 = dateAxis0.getFixedAutoRange();
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.RangeType rangeType2 = numberAxis1.getRangeType();
        boolean boolean3 = numberAxis1.isVisible();
        numberAxis1.configure();
        java.text.NumberFormat numberFormat5 = numberAxis1.getNumberFormatOverride();
        org.junit.Assert.assertNotNull(rangeType2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(numberFormat5);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CategoryAnchor.MIDDLE");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 255);
        categoryAxis1.configure();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        int int13 = categoryPlot8.getIndexOf(categoryItemRenderer12);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor14 = categoryPlot8.getDomainGridlinePosition();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot8.getRendererForDataset(categoryDataset15);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        dateAxis18.setLabel("");
        dateAxis18.setTickLabelsVisible(false);
        dateAxis18.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot25.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis29 = new org.jfree.chart.axis.DateAxis();
        dateAxis29.setLabel("");
        dateAxis29.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource34 = dateAxis29.getStandardTickUnits();
        boolean boolean35 = categoryPlot25.equals((java.lang.Object) dateAxis29);
        float float36 = dateAxis29.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset17, (org.jfree.chart.axis.ValueAxis) dateAxis18, (org.jfree.chart.axis.ValueAxis) dateAxis29, xYItemRenderer37);
        org.jfree.chart.axis.ValueAxis valueAxis40 = xYPlot38.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        java.awt.geom.Point2D point2D43 = null;
        xYPlot38.zoomRangeAxes((double) (short) 100, plotRenderingInfo42, point2D43);
        org.jfree.chart.axis.AxisLocation axisLocation46 = xYPlot38.getRangeAxisLocation((int) (byte) 10);
        categoryPlot8.setRangeAxisLocation(axisLocation46);
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset49 = categoryPlot48.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.data.Range range51 = categoryPlot48.getDataRange(valueAxis50);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray52 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot48.setRenderers(categoryItemRendererArray52);
        org.jfree.chart.axis.DateAxis dateAxis54 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray56 = new org.jfree.chart.axis.ValueAxis[] { dateAxis54, dateAxis55 };
        categoryPlot48.setRangeAxes(valueAxisArray56);
        org.jfree.chart.plot.PlotOrientation plotOrientation58 = categoryPlot48.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation46, plotOrientation58);
        try {
            java.util.List list60 = categoryAxis1.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor14);
        org.junit.Assert.assertNull(categoryItemRenderer16);
        org.junit.Assert.assertNotNull(tickUnitSource34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 2.0f + "'", float36 == 2.0f);
        org.junit.Assert.assertNull(valueAxis40);
        org.junit.Assert.assertNotNull(axisLocation46);
        org.junit.Assert.assertNull(categoryDataset49);
        org.junit.Assert.assertNull(range51);
        org.junit.Assert.assertNotNull(categoryItemRendererArray52);
        org.junit.Assert.assertNotNull(valueAxisArray56);
        org.junit.Assert.assertNotNull(plotOrientation58);
        org.junit.Assert.assertNotNull(rectangleEdge59);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        org.jfree.chart.plot.IntervalMarker intervalMarker28 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.awt.Stroke stroke29 = null;
        intervalMarker28.setOutlineStroke(stroke29);
        boolean boolean31 = xYPlot21.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker28);
        org.jfree.chart.axis.AxisLocation axisLocation32 = xYPlot21.getRangeAxisLocation();
        java.awt.Stroke stroke33 = xYPlot21.getDomainCrosshairStroke();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        xYPlot21.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot21.getRendererForDataset(xYDataset27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        xYPlot21.setDomainGridlinePaint((java.awt.Paint) color29);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot21.setRangeTickBandPaint((java.awt.Paint) color31);
        org.jfree.chart.axis.AxisLocation axisLocation33 = xYPlot21.getRangeAxisLocation();
        java.awt.Paint paint34 = xYPlot21.getNoDataMessagePaint();
        org.jfree.data.general.DatasetGroup datasetGroup35 = xYPlot21.getDatasetGroup();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = xYPlot21.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis37 = xYPlot21.getRangeAxis();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(xYItemRenderer28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNull(datasetGroup35);
        org.junit.Assert.assertNull(xYItemRenderer36);
        org.junit.Assert.assertNull(valueAxis37);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        xYPlot21.setRenderer(xYItemRenderer22);
        xYPlot21.clearDomainMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset26 = categoryPlot25.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.data.Range range28 = categoryPlot25.getDataRange(valueAxis27);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray29 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot25.setRenderers(categoryItemRendererArray29);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray33 = new org.jfree.chart.axis.ValueAxis[] { dateAxis31, dateAxis32 };
        categoryPlot25.setRangeAxes(valueAxisArray33);
        org.jfree.chart.plot.PlotOrientation plotOrientation35 = categoryPlot25.getOrientation();
        xYPlot21.setOrientation(plotOrientation35);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(categoryDataset26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(categoryItemRendererArray29);
        org.junit.Assert.assertNotNull(valueAxisArray33);
        org.junit.Assert.assertNotNull(plotOrientation35);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder1 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        categoryPlot3.setDomainGridlinePaint((java.awt.Paint) color4);
        java.awt.Color color6 = java.awt.Color.getColor("TextAnchor.TOP_RIGHT", color4);
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color4);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot0.getRangeAxisEdge();
        org.junit.Assert.assertNotNull(datasetRenderingOrder1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        java.lang.String str1 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryAnchor.END" + "'", str1.equals("CategoryAnchor.END"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setLabelToolTip("hi!");
        java.lang.String str3 = dateAxis0.getLabel();
        dateAxis0.setPositiveArrowVisible(true);
        org.junit.Assert.assertNull(str3);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//        java.awt.Paint paint2 = defaultDrawingSupplier1.getNextPaint();
//        java.awt.Paint paint3 = defaultDrawingSupplier1.getNextFillPaint();
//        int int4 = day0.compareTo((java.lang.Object) paint3);
//        int int5 = day0.getMonth();
//        long long6 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.next();
//        java.util.Date date8 = regularTimePeriod7.getStart();
//        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
//        java.awt.geom.Rectangle2D rectangle2D12 = null;
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = null;
//        java.awt.geom.Point2D point2D14 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D12, rectangleAnchor13);
//        categoryPlot9.zoomRangeAxes((double) (-1), plotRenderingInfo11, point2D14);
//        categoryPlot9.setBackgroundImageAlpha((float) 0L);
//        org.jfree.data.category.CategoryDataset categoryDataset18 = categoryPlot9.getDataset();
//        categoryPlot9.clearAnnotations();
//        double double20 = categoryPlot9.getRangeCrosshairValue();
//        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
//        categoryPlot9.setRangeAxisLocation(axisLocation21);
//        java.awt.Color color26 = java.awt.Color.getHSBColor((float) '4', (float) 'a', (float) 0);
//        categoryPlot9.setRangeGridlinePaint((java.awt.Paint) color26);
//        java.awt.Color color28 = org.jfree.chart.ChartColor.DARK_RED;
//        java.awt.color.ColorSpace colorSpace29 = color28.getColorSpace();
//        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_GREEN;
//        float[] floatArray31 = null;
//        float[] floatArray32 = color30.getComponents(floatArray31);
//        float[] floatArray33 = color26.getColorComponents(colorSpace29, floatArray32);
//        org.jfree.data.xy.XYDataset xYDataset34 = null;
//        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
//        dateAxis35.setLabel("");
//        dateAxis35.setTickLabelsVisible(false);
//        dateAxis35.setAutoRange(false);
//        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
//        categoryPlot42.setAnchorValue(1.0d, false);
//        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis();
//        dateAxis46.setLabel("");
//        dateAxis46.setTickLabelsVisible(false);
//        org.jfree.chart.axis.TickUnitSource tickUnitSource51 = dateAxis46.getStandardTickUnits();
//        boolean boolean52 = categoryPlot42.equals((java.lang.Object) dateAxis46);
//        float float53 = dateAxis46.getTickMarkOutsideLength();
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer54 = null;
//        org.jfree.chart.plot.XYPlot xYPlot55 = new org.jfree.chart.plot.XYPlot(xYDataset34, (org.jfree.chart.axis.ValueAxis) dateAxis35, (org.jfree.chart.axis.ValueAxis) dateAxis46, xYItemRenderer54);
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer56 = null;
//        xYPlot55.setRenderer(xYItemRenderer56);
//        xYPlot55.clearDomainMarkers();
//        java.awt.Stroke stroke59 = xYPlot55.getRangeZeroBaselineStroke();
//        org.jfree.chart.plot.CategoryMarker categoryMarker60 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) date8, (java.awt.Paint) color26, stroke59);
//        org.junit.Assert.assertNotNull(paint2);
//        org.junit.Assert.assertNotNull(paint3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNotNull(point2D14);
//        org.junit.Assert.assertNull(categoryDataset18);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
//        org.junit.Assert.assertNotNull(axisLocation21);
//        org.junit.Assert.assertNotNull(color26);
//        org.junit.Assert.assertNotNull(color28);
//        org.junit.Assert.assertNotNull(colorSpace29);
//        org.junit.Assert.assertNotNull(color30);
//        org.junit.Assert.assertNotNull(floatArray32);
//        org.junit.Assert.assertNotNull(floatArray33);
//        org.junit.Assert.assertNotNull(tickUnitSource51);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
//        org.junit.Assert.assertTrue("'" + float53 + "' != '" + 2.0f + "'", float53 == 2.0f);
//        org.junit.Assert.assertNotNull(stroke59);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        xYPlot21.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot21.getRendererForDataset(xYDataset27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        xYPlot21.setDomainGridlinePaint((java.awt.Paint) color29);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot21.setRangeTickBandPaint((java.awt.Paint) color31);
        org.jfree.chart.axis.AxisLocation axisLocation33 = xYPlot21.getRangeAxisLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        xYPlot21.setAxisOffset(rectangleInsets34);
        org.jfree.chart.axis.AxisLocation axisLocation36 = xYPlot21.getRangeAxisLocation();
        boolean boolean37 = xYPlot21.isDomainCrosshairVisible();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(xYItemRenderer28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        java.lang.Object obj6 = categoryPlot0.clone();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.setLabelToolTip("hi!");
        categoryPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis8, false);
        categoryPlot0.setNoDataMessage("");
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot0.getRangeAxisEdge((int) (short) 1);
        org.jfree.chart.LegendItemCollection legendItemCollection17 = categoryPlot0.getFixedLegendItems();
        java.awt.Paint paint18 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = categoryPlot0.getDomainAxisForDataset(64);
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNull(legendItemCollection17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(categoryAxis20);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        org.jfree.chart.plot.IntervalMarker intervalMarker28 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.awt.Stroke stroke29 = null;
        intervalMarker28.setOutlineStroke(stroke29);
        boolean boolean31 = xYPlot21.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker28);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent32 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) boolean31);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset34 = categoryPlot33.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.data.Range range36 = categoryPlot33.getDataRange(valueAxis35);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray37 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot33.setRenderers(categoryItemRendererArray37);
        java.lang.Object obj39 = categoryPlot33.clone();
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis();
        dateAxis41.setLabelToolTip("hi!");
        categoryPlot33.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis41, false);
        categoryPlot33.setNoDataMessage("");
        org.jfree.data.category.CategoryDataset categoryDataset49 = categoryPlot33.getDataset((int) (short) 10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent50 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot33);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType51 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        plotChangeEvent50.setType(chartChangeEventType51);
        chartChangeEvent32.setType(chartChangeEventType51);
        java.lang.String str54 = chartChangeEventType51.toString();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(categoryDataset34);
        org.junit.Assert.assertNull(range36);
        org.junit.Assert.assertNotNull(categoryItemRendererArray37);
        org.junit.Assert.assertNotNull(obj39);
        org.junit.Assert.assertNull(categoryDataset49);
        org.junit.Assert.assertNotNull(chartChangeEventType51);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str54.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset2 = categoryPlot1.getDataset();
        boolean boolean3 = lengthAdjustmentType0.equals((java.lang.Object) categoryPlot1);
        boolean boolean4 = categoryPlot1.isSubplot();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("CategoryAnchor.MIDDLE");
        categoryPlot1.setDomainAxis(4, categoryAxis7);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        dateAxis11.setLabelToolTip("hi!");
        int int14 = categoryPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Font font15 = dateAxis11.getTickLabelFont();
        categoryPlot0.setNoDataMessageFont(font15);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = categoryPlot0.getDomainMarkers(layer17);
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace19, false);
        java.awt.Stroke stroke22 = categoryPlot0.getRangeCrosshairStroke();
        categoryPlot0.setAnchorValue((double) 10.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset26 = categoryPlot25.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.data.Range range28 = categoryPlot25.getDataRange(valueAxis27);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray29 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot25.setRenderers(categoryItemRendererArray29);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray33 = new org.jfree.chart.axis.ValueAxis[] { dateAxis31, dateAxis32 };
        categoryPlot25.setRangeAxes(valueAxisArray33);
        java.awt.Font font35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryPlot25.setNoDataMessageFont(font35);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("CategoryAnchor.MIDDLE");
        categoryPlot25.setDomainAxis(categoryAxis38);
        java.util.List list40 = categoryPlot0.getCategoriesForAxis(categoryAxis38);
        boolean boolean41 = categoryPlot0.getDrawSharedDomainAxis();
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(categoryDataset26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(categoryItemRendererArray29);
        org.junit.Assert.assertNotNull(valueAxisArray33);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(list40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L, (java.awt.Paint) color2, stroke3);
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        categoryMarker4.setLabelTextAnchor(textAnchor5);
        boolean boolean7 = datasetRenderingOrder0.equals((java.lang.Object) categoryMarker4);
        java.lang.String str8 = datasetRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str8.equals("DatasetRenderingOrder.FORWARD"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.util.List list8 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxis(100);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        categoryPlot0.addChangeListener(plotChangeListener11);
        org.jfree.chart.plot.IntervalMarker intervalMarker15 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.lang.Object obj16 = intervalMarker15.clone();
        java.awt.Paint paint17 = intervalMarker15.getLabelPaint();
        boolean boolean18 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker15);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer19 = null;
        intervalMarker15.setGradientPaintTransformer(gradientPaintTransformer19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        intervalMarker15.setOutlinePaint((java.awt.Paint) color21);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = intervalMarker15.getLabelOffset();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(rectangleInsets23);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setVerticalTickLabels(true);
        numberAxis1.setAutoRangeStickyZero(false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset2 = categoryPlot1.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.data.Range range4 = categoryPlot1.getDataRange(valueAxis3);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray5 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot1.setRenderers(categoryItemRendererArray5);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray9 = new org.jfree.chart.axis.ValueAxis[] { dateAxis7, dateAxis8 };
        categoryPlot1.setRangeAxes(valueAxisArray9);
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryPlot1.setNoDataMessageFont(font11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("CategoryAnchor.MIDDLE");
        categoryPlot1.setDomainAxis(categoryAxis14);
        categoryAxis14.setMaximumCategoryLabelLines(3);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        dateAxis19.setLabel("");
        dateAxis19.setTickLabelsVisible(false);
        dateAxis19.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot26.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        dateAxis30.setLabel("");
        dateAxis30.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource35 = dateAxis30.getStandardTickUnits();
        boolean boolean36 = categoryPlot26.equals((java.lang.Object) dateAxis30);
        float float37 = dateAxis30.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis30, xYItemRenderer38);
        org.jfree.chart.axis.ValueAxis valueAxis41 = xYPlot39.getRangeAxis((int) (short) -1);
        java.awt.Paint paint42 = xYPlot39.getDomainCrosshairPaint();
        java.awt.Paint paint43 = xYPlot39.getRangeGridlinePaint();
        xYPlot39.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset45 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = xYPlot39.getRendererForDataset(xYDataset45);
        xYPlot39.setRangeCrosshairValue(0.0d, false);
        boolean boolean50 = xYPlot39.isDomainCrosshairLockedOnData();
        boolean boolean51 = xYPlot39.isDomainGridlinesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis53 = xYPlot39.getDomainAxis((int) (short) 0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis14, valueAxis53, categoryItemRenderer54);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(categoryItemRendererArray5);
        org.junit.Assert.assertNotNull(valueAxisArray9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(tickUnitSource35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 2.0f + "'", float37 == 2.0f);
        org.junit.Assert.assertNull(valueAxis41);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNull(xYItemRenderer46);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(valueAxis53);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        java.lang.Object obj4 = categoryPlot0.clone();
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot0.getFixedRangeAxisSpace();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace7, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot0.setRenderer(categoryItemRenderer10, false);
        org.jfree.data.general.DatasetGroup datasetGroup13 = categoryPlot0.getDatasetGroup();
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNull(datasetGroup13);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        java.lang.Class class2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.setLabelToolTip("hi!");
        int int10 = categoryPlot3.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis7);
        java.awt.Font font11 = dateAxis7.getTickLabelFont();
        java.util.Date date12 = dateAxis7.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape14 = dateAxis13.getUpArrow();
        java.util.TimeZone timeZone15 = dateAxis13.getTimeZone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class2, date12, timeZone15);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis("ChartChangeEventType.NEW_DATASET", timeZone15);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=0,g=128,b=128]", timeZone15);
        boolean boolean19 = dateAxis18.isAxisLineVisible();
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        java.awt.Stroke stroke6 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("");
        java.util.List list9 = categoryPlot0.getCategoriesForAxis(categoryAxis8);
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=0,g=128,b=128]");
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder1 = xYPlot0.getDatasetRenderingOrder();
        xYPlot0.setDomainZeroBaselineVisible(false);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Color color5 = color4.brighter();
        int int6 = color5.getGreen();
        java.awt.Color color7 = color5.brighter();
        xYPlot0.setDomainTickBandPaint((java.awt.Paint) color5);
        org.junit.Assert.assertNotNull(datasetRenderingOrder1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 91 + "'", int6 == 91);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.trimHeight((-1.0d));
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-5.0d) + "'", double2 == (-5.0d));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Font font8 = dateAxis4.getTickLabelFont();
        float float9 = dateAxis4.getTickMarkOutsideLength();
        dateAxis4.setFixedDimension(1.0d);
        java.awt.Shape shape12 = dateAxis4.getRightArrow();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 2.0f + "'", float9 == 2.0f);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        boolean boolean10 = categoryPlot0.render(graphics2D6, rectangle2D7, (int) ' ', plotRenderingInfo9);
        categoryPlot0.clearDomainMarkers((-16646144));
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, 0.0d, (double) (-1L), 100.0d);
        double double18 = rectangleInsets17.getRight();
        categoryPlot0.setAxisOffset(rectangleInsets17);
        org.jfree.chart.util.UnitType unitType20 = rectangleInsets17.getUnitType();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 100.0d + "'", double18 == 100.0d);
        org.junit.Assert.assertNotNull(unitType20);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 100, (double) (-1L), (double) 13, 3.0d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabel("");
        dateAxis4.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = dateAxis4.getStandardTickUnits();
        boolean boolean10 = categoryPlot0.equals((java.lang.Object) dateAxis4);
        float float11 = dateAxis4.getTickMarkOutsideLength();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis4.setTickLabelPaint((java.awt.Paint) color12);
        boolean boolean14 = dateAxis4.isVerticalTickLabels();
        org.jfree.data.Range range15 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis4.setRangeWithMargins(range15, false, true);
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 2.0f + "'", float11 == 2.0f);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(range15);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.TOP_RIGHT");
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot2.getDataset();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace4, true);
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot2);
        float float8 = numberAxis1.getTickMarkOutsideLength();
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 2.0f + "'", float8 == 2.0f);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.RangeType rangeType2 = numberAxis1.getRangeType();
        org.jfree.chart.plot.Plot plot3 = numberAxis1.getPlot();
        org.junit.Assert.assertNotNull(rangeType2);
        org.junit.Assert.assertNull(plot3);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        int int8 = categoryPlot0.getIndexOf(categoryItemRenderer7);
        java.awt.Paint paint9 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getDomainAxisLocation();
        categoryPlot0.clearRangeMarkers(9);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(axisLocation10);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        dateAxis11.setLabelToolTip("hi!");
        int int14 = categoryPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Font font15 = dateAxis11.getTickLabelFont();
        categoryPlot0.setNoDataMessageFont(font15);
        org.jfree.chart.plot.Plot plot17 = categoryPlot0.getRootPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("CategoryAnchor.MIDDLE");
        categoryAxis20.setMaximumCategoryLabelLines(0);
        categoryPlot0.setDomainAxis((int) '#', categoryAxis20);
        java.lang.Object obj24 = categoryAxis20.clone();
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(plot17);
        org.junit.Assert.assertNotNull(obj24);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        xYPlot21.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot21.getRendererForDataset(xYDataset27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        xYPlot21.setDomainGridlinePaint((java.awt.Paint) color29);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot21.setRangeTickBandPaint((java.awt.Paint) color31);
        org.jfree.chart.axis.AxisLocation axisLocation33 = xYPlot21.getRangeAxisLocation();
        java.awt.Paint paint34 = xYPlot21.getNoDataMessagePaint();
        org.jfree.data.general.DatasetGroup datasetGroup35 = xYPlot21.getDatasetGroup();
        java.awt.geom.Point2D point2D36 = xYPlot21.getQuadrantOrigin();
        java.awt.Stroke stroke37 = xYPlot21.getDomainGridlineStroke();
        org.jfree.chart.plot.IntervalMarker intervalMarker40 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.awt.Stroke stroke41 = null;
        intervalMarker40.setOutlineStroke(stroke41);
        java.awt.Stroke stroke43 = intervalMarker40.getOutlineStroke();
        xYPlot21.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker40);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(xYItemRenderer28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNull(datasetGroup35);
        org.junit.Assert.assertNotNull(point2D36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNull(stroke43);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, 0.0d, (double) (-1L), 100.0d);
        double double7 = rectangleInsets6.getRight();
        double double9 = rectangleInsets6.trimWidth((double) (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset11 = categoryPlot10.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.data.Range range13 = categoryPlot10.getDataRange(valueAxis12);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot10.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray18 = new org.jfree.chart.axis.ValueAxis[] { dateAxis16, dateAxis17 };
        categoryPlot10.setRangeAxes(valueAxisArray18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot10.zoomDomainAxes((double) 10L, (double) (byte) -1, plotRenderingInfo22, point2D23);
        boolean boolean25 = rectangleInsets6.equals((java.lang.Object) 10L);
        double double27 = rectangleInsets6.calculateTopInset((double) 4);
        categoryPlot0.setAxisOffset(rectangleInsets6);
        double double30 = rectangleInsets6.calculateRightInset((-9.0d));
        double double32 = rectangleInsets6.extendHeight((double) (-1.0f));
        double double34 = rectangleInsets6.extendHeight((double) (-29046));
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-101.0d) + "'", double9 == (-101.0d));
        org.junit.Assert.assertNull(categoryDataset11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(valueAxisArray18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 10.0d + "'", double27 == 10.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 100.0d + "'", double30 == 100.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 8.0d + "'", double32 == 8.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + (-29037.0d) + "'", double34 == (-29037.0d));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = xYPlot21.getDomainAxisEdge((int) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        xYPlot21.setRenderer((int) (short) 100, xYItemRenderer29, false);
        boolean boolean32 = xYPlot21.isOutlineVisible();
        org.jfree.data.xy.XYDataset xYDataset34 = xYPlot21.getDataset(0);
        java.awt.Stroke stroke35 = xYPlot21.getRangeCrosshairStroke();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNull(xYDataset34);
        org.junit.Assert.assertNotNull(stroke35);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        categoryPlot0.setRangeCrosshairValue((double) 0.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = null;
        java.awt.geom.Point2D point2D17 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D15, rectangleAnchor16);
        categoryPlot12.zoomRangeAxes((double) (-1), plotRenderingInfo14, point2D17);
        categoryPlot0.zoomRangeAxes((double) ' ', (double) 6, plotRenderingInfo11, point2D17);
        categoryPlot0.clearRangeMarkers((int) (short) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, 0.0d, (double) (-1L), 100.0d);
        double double27 = rectangleInsets26.getRight();
        double double29 = rectangleInsets26.trimWidth((double) (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset31 = categoryPlot30.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.data.Range range33 = categoryPlot30.getDataRange(valueAxis32);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray34 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot30.setRenderers(categoryItemRendererArray34);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray38 = new org.jfree.chart.axis.ValueAxis[] { dateAxis36, dateAxis37 };
        categoryPlot30.setRangeAxes(valueAxisArray38);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        java.awt.geom.Point2D point2D43 = null;
        categoryPlot30.zoomDomainAxes((double) 10L, (double) (byte) -1, plotRenderingInfo42, point2D43);
        boolean boolean45 = rectangleInsets26.equals((java.lang.Object) 10L);
        double double47 = rectangleInsets26.calculateTopOutset((double) (-14336));
        double double49 = rectangleInsets26.trimHeight((double) 0.0f);
        double double51 = rectangleInsets26.calculateLeftOutset((double) 0.0f);
        categoryPlot0.setInsets(rectangleInsets26);
        org.jfree.chart.axis.AxisLocation axisLocation54 = categoryPlot0.getRangeAxisLocation(6);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNotNull(point2D17);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 100.0d + "'", double27 == 100.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + (-101.0d) + "'", double29 == (-101.0d));
        org.junit.Assert.assertNull(categoryDataset31);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertNotNull(categoryItemRendererArray34);
        org.junit.Assert.assertNotNull(valueAxisArray38);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 10.0d + "'", double47 == 10.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + (-9.0d) + "'", double49 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation54);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        boolean boolean10 = categoryPlot0.render(graphics2D6, rectangle2D7, (int) ' ', plotRenderingInfo9);
        int int11 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        dateAxis13.setLabel("");
        boolean boolean17 = dateAxis13.isHiddenValue((long) (byte) 0);
        categoryPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis13, false);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = categoryPlot0.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(drawingSupplier21);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        xYPlot21.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot21.getRendererForDataset(xYDataset27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        xYPlot21.setDomainGridlinePaint((java.awt.Paint) color29);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot21.setRangeTickBandPaint((java.awt.Paint) color31);
        org.jfree.chart.axis.AxisLocation axisLocation33 = xYPlot21.getRangeAxisLocation();
        java.awt.Paint paint34 = xYPlot21.getRangeTickBandPaint();
        java.awt.Paint paint35 = xYPlot21.getOutlinePaint();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(xYItemRenderer28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        xYPlot21.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot21.getRendererForDataset(xYDataset27);
        xYPlot21.setRangeCrosshairValue(0.0d, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = xYPlot21.getDomainAxis(100);
        org.jfree.chart.plot.IntervalMarker intervalMarker36 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = intervalMarker36.getLabelAnchor();
        intervalMarker36.setLabel("RectangleAnchor.BOTTOM_LEFT");
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker36);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer41 = intervalMarker36.getGradientPaintTransformer();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(xYItemRenderer28);
        org.junit.Assert.assertNull(valueAxis33);
        org.junit.Assert.assertNotNull(rectangleAnchor37);
        org.junit.Assert.assertNull(gradientPaintTransformer41);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot21.zoomRangeAxes((double) (short) 100, plotRenderingInfo25, point2D26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = null;
        xYPlot21.setDomainAxisLocation((int) (byte) 100, axisLocation29);
        java.awt.Paint paint31 = xYPlot21.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.axis.ValueAxis valueAxis34 = xYPlot21.getDomainAxis();
        org.jfree.chart.plot.IntervalMarker intervalMarker38 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = intervalMarker38.getLabelAnchor();
        java.awt.Stroke stroke40 = intervalMarker38.getStroke();
        org.jfree.chart.util.Layer layer41 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean43 = xYPlot21.removeRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker38, layer41, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = xYPlot21.getAxisOffset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = null;
        java.awt.geom.Point2D point2D48 = null;
        xYPlot21.zoomRangeAxes((-9.0d), (double) 0.0f, plotRenderingInfo47, point2D48);
        java.awt.Paint paint50 = xYPlot21.getNoDataMessagePaint();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(valueAxis34);
        org.junit.Assert.assertNotNull(rectangleAnchor39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(layer41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(paint50);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test112");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day0.previous();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560409200000L + "'", long1 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod2);
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.RangeType rangeType2 = numberAxis1.getRangeType();
        numberAxis1.centerRange(6.0d);
        org.junit.Assert.assertNotNull(rangeType2);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        boolean boolean10 = categoryPlot0.render(graphics2D6, rectangle2D7, (int) ' ', plotRenderingInfo9);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = null;
        categoryPlot0.axisChanged(axisChangeEvent11);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.JFreeChart jFreeChart14 = null;
        plotChangeEvent13.setChart(jFreeChart14);
        org.jfree.chart.plot.Plot plot16 = plotChangeEvent13.getPlot();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType17 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        plotChangeEvent13.setType(chartChangeEventType17);
        java.lang.String str19 = plotChangeEvent13.toString();
        org.jfree.chart.plot.Plot plot20 = plotChangeEvent13.getPlot();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(plot16);
        org.junit.Assert.assertNotNull(chartChangeEventType17);
        org.junit.Assert.assertNotNull(plot20);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        boolean boolean6 = categoryPlot0.isOutlineVisible();
        org.jfree.data.general.Dataset dataset7 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent8 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) boolean6, dataset7);
        org.jfree.data.general.Dataset dataset9 = datasetChangeEvent8.getDataset();
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(dataset9);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getUpArrow();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        dateAxis3.setLabel("");
        dateAxis3.setTickLabelsVisible(false);
        dateAxis3.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        dateAxis14.setLabel("");
        dateAxis14.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource19 = dateAxis14.getStandardTickUnits();
        boolean boolean20 = categoryPlot10.equals((java.lang.Object) dateAxis14);
        float float21 = dateAxis14.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) dateAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer22);
        java.awt.Paint paint24 = xYPlot23.getDomainCrosshairPaint();
        xYPlot23.setRangeCrosshairValue((double) (short) 0);
        dateAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot23);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        numberAxis29.setAutoTickUnitSelection(false);
        xYPlot23.setRangeAxis(2019, (org.jfree.chart.axis.ValueAxis) numberAxis29, false);
        boolean boolean34 = xYPlot23.isRangeZoomable();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(tickUnitSource19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 2.0f + "'", float21 == 2.0f);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        java.lang.Object obj4 = categoryPlot0.clone();
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot0.getFixedRangeAxisSpace();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace7, true);
        java.awt.Paint paint10 = categoryPlot0.getNoDataMessagePaint();
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        xYPlot21.clearRangeAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset28 = categoryPlot27.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.data.Range range30 = categoryPlot27.getDataRange(valueAxis29);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray31 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot27.setRenderers(categoryItemRendererArray31);
        boolean boolean33 = categoryPlot27.isOutlineVisible();
        org.jfree.data.general.Dataset dataset34 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent35 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) boolean33, dataset34);
        java.lang.Object obj36 = datasetChangeEvent35.getSource();
        xYPlot21.datasetChanged(datasetChangeEvent35);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(categoryDataset28);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertNotNull(categoryItemRendererArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + obj36 + "' != '" + true + "'", obj36.equals(true));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("");
        numberAxis2.setAutoRangeIncludesZero(true);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit7 = numberAxis6.getTickUnit();
        numberAxis2.setTickUnit(numberTickUnit7, false, true);
        numberAxis0.setTickUnit(numberTickUnit7);
        org.junit.Assert.assertNotNull(numberTickUnit7);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        java.awt.Stroke stroke7 = null;
        categoryPlot0.setOutlineStroke(stroke7);
        categoryPlot0.clearDomainMarkers();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        categoryPlot0.drawBackgroundImage(graphics2D10, rectangle2D11);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset15 = categoryPlot14.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.data.Range range17 = categoryPlot14.getDataRange(valueAxis16);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray18 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot14.setRenderers(categoryItemRendererArray18);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray22 = new org.jfree.chart.axis.ValueAxis[] { dateAxis20, dateAxis21 };
        categoryPlot14.setRangeAxes(valueAxisArray22);
        java.awt.Font font24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryPlot14.setNoDataMessageFont(font24);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("CategoryAnchor.MIDDLE");
        categoryPlot14.setDomainAxis(categoryAxis27);
        categoryAxis27.clearCategoryLabelToolTips();
        categoryPlot0.setDomainAxis(2, categoryAxis27, true);
        org.jfree.chart.axis.AxisLocation axisLocation32 = categoryPlot0.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(categoryDataset15);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(categoryItemRendererArray18);
        org.junit.Assert.assertNotNull(valueAxisArray22);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(axisLocation32);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.TOP_RIGHT");
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot2.getDataset();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace4, true);
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot2);
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot2.getRangeAxisLocation();
        java.awt.Color color9 = java.awt.Color.magenta;
        categoryPlot2.setRangeCrosshairPaint((java.awt.Paint) color9);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        xYPlot21.setRangeCrosshairLockedOnData(true);
        xYPlot21.setDomainCrosshairValue((double) (-16646144), false);
        java.lang.Object obj31 = xYPlot21.clone();
        xYPlot21.setDomainCrosshairVisible(true);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNotNull(obj31);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint2 = defaultDrawingSupplier1.getNextPaint();
        java.awt.Paint paint3 = defaultDrawingSupplier1.getNextFillPaint();
        int int4 = day0.compareTo((java.lang.Object) paint3);
        java.util.Calendar calendar5 = null;
        try {
            day0.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        java.awt.Stroke stroke7 = null;
        categoryPlot0.setOutlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L, (java.awt.Paint) color13, stroke14);
        categoryMarker15.setDrawAsLine(false);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        dateAxis19.setLabel("");
        dateAxis19.setTickLabelsVisible(false);
        dateAxis19.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot26.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        dateAxis30.setLabel("");
        dateAxis30.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource35 = dateAxis30.getStandardTickUnits();
        boolean boolean36 = categoryPlot26.equals((java.lang.Object) dateAxis30);
        float float37 = dateAxis30.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis30, xYItemRenderer38);
        org.jfree.chart.plot.IntervalMarker intervalMarker42 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot39.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker42);
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset47 = null;
        xYPlot45.setDataset(10, xYDataset47);
        org.jfree.chart.util.Layer layer50 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection51 = xYPlot45.getDomainMarkers((-1), layer50);
        java.util.Collection collection52 = xYPlot39.getRangeMarkers(0, layer50);
        categoryPlot0.addDomainMarker(categoryMarker15, layer50);
        categoryPlot0.mapDatasetToRangeAxis(0, 91);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(tickUnitSource35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 2.0f + "'", float37 == 2.0f);
        org.junit.Assert.assertNotNull(layer50);
        org.junit.Assert.assertNull(collection51);
        org.junit.Assert.assertNull(collection52);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot0.setDomainAxis(categoryAxis8);
        int int10 = categoryPlot0.getRangeAxisCount();
        float float11 = categoryPlot0.getForegroundAlpha();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.RangeType rangeType15 = numberAxis14.getRangeType();
        numberAxis12.setRangeType(rangeType15);
        numberAxis12.setAutoRangeStickyZero(true);
        int int19 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis12);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
        org.junit.Assert.assertNotNull(rangeType15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot21.zoomRangeAxes((double) (short) 100, plotRenderingInfo25, point2D26);
        int int28 = xYPlot21.getBackgroundImageAlignment();
        org.jfree.chart.plot.IntervalMarker intervalMarker31 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = intervalMarker31.getLabelAnchor();
        java.awt.Stroke stroke33 = intervalMarker31.getStroke();
        xYPlot21.setRangeGridlineStroke(stroke33);
        xYPlot21.mapDatasetToRangeAxis((int) 'a', 2019);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 15 + "'", int28 == 15);
        org.junit.Assert.assertNotNull(rectangleAnchor32);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        xYPlot21.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot21.getRendererForDataset(xYDataset27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        xYPlot21.setDomainGridlinePaint((java.awt.Paint) color29);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot21.setRangeTickBandPaint((java.awt.Paint) color31);
        org.jfree.chart.axis.AxisLocation axisLocation33 = xYPlot21.getRangeAxisLocation();
        java.awt.Paint paint34 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        xYPlot21.setDomainZeroBaselinePaint(paint34);
        boolean boolean36 = xYPlot21.isDomainZoomable();
        boolean boolean37 = xYPlot21.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(xYItemRenderer28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        categoryPlot0.setBackgroundImageAlpha((float) 0L);
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot0.getDataset();
        categoryPlot0.mapDatasetToDomainAxis(0, (int) (byte) 100);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        categoryPlot0.zoomDomainAxes((double) 1.0f, 0.05d, plotRenderingInfo15, point2D18);
        java.awt.Paint paint20 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        categoryPlot0.setDomainGridlinePaint(paint20);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset2 = categoryPlot1.getDataset();
        boolean boolean3 = lengthAdjustmentType0.equals((java.lang.Object) categoryPlot1);
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        xYPlot5.setDataset(10, xYDataset7);
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot5.getRangeAxisLocation();
        try {
            categoryPlot1.setDomainAxisLocation((-16646144), axisLocation9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        xYPlot21.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot21.getRendererForDataset(xYDataset27);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot21.getDomainAxisEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset32 = categoryPlot31.getDataset();
        boolean boolean33 = rectangleAnchor30.equals((java.lang.Object) categoryPlot31);
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_RED;
        categoryPlot31.setNoDataMessagePaint((java.awt.Paint) color34);
        xYPlot21.setDomainCrosshairPaint((java.awt.Paint) color34);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, 0.0d, (double) (-1L), 100.0d);
        xYPlot21.setAxisOffset(rectangleInsets41);
        double double43 = rectangleInsets41.getBottom();
        double double45 = rectangleInsets41.calculateBottomOutset((double) 9);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(xYItemRenderer28);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNull(categoryDataset32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + (-1.0d) + "'", double43 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + (-1.0d) + "'", double45 == (-1.0d));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        xYPlot21.setRangeCrosshairLockedOnData(true);
        java.lang.Object obj28 = xYPlot21.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = null;
        java.awt.geom.Point2D point2D34 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D32, rectangleAnchor33);
        categoryPlot29.zoomRangeAxes((double) (-1), plotRenderingInfo31, point2D34);
        xYPlot21.setQuadrantOrigin(point2D34);
        boolean boolean37 = xYPlot21.isDomainZeroBaselineVisible();
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        xYPlot21.setDomainCrosshairPaint((java.awt.Paint) color38);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(point2D34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(color38);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        int int26 = xYPlot21.getRangeAxisCount();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot21.getRenderer(0);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNull(xYItemRenderer28);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        java.lang.Object obj4 = categoryPlot0.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset7 = categoryPlot6.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.data.Range range9 = categoryPlot6.getDataRange(valueAxis8);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray10 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot6.setRenderers(categoryItemRendererArray10);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray14 = new org.jfree.chart.axis.ValueAxis[] { dateAxis12, dateAxis13 };
        categoryPlot6.setRangeAxes(valueAxisArray14);
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryPlot6.setNoDataMessageFont(font16);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis("CategoryAnchor.MIDDLE");
        categoryPlot6.setDomainAxis(categoryAxis19);
        categoryPlot0.setDomainAxis((int) ' ', categoryAxis19);
        categoryPlot0.setRangeGridlinesVisible(true);
        org.jfree.chart.axis.AxisSpace axisSpace24 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace24, false);
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(categoryDataset7);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(categoryItemRendererArray10);
        org.junit.Assert.assertNotNull(valueAxisArray14);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color2 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Stroke stroke3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L, (java.awt.Paint) color2, stroke3);
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        categoryMarker4.setLabelTextAnchor(textAnchor5);
        boolean boolean7 = datasetRenderingOrder0.equals((java.lang.Object) categoryMarker4);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        dateAxis15.setLabelToolTip("hi!");
        int int18 = categoryPlot11.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis15);
        java.awt.Font font19 = dateAxis15.getTickLabelFont();
        boolean boolean20 = dateAxis15.isAxisLineVisible();
        java.awt.Font font21 = dateAxis15.getTickLabelFont();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) numberAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer22);
        boolean boolean24 = datasetRenderingOrder0.equals((java.lang.Object) xYDataset8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        categoryPlot0.setBackgroundImageAlpha((float) 0L);
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot0.getDataset();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot0.setRenderer(0, categoryItemRenderer11, false);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range15 = dateAxis14.getRange();
        org.jfree.data.Range range16 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis14);
        java.util.List list17 = categoryPlot0.getCategories();
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot0.getRangeAxis();
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNull(list17);
        org.junit.Assert.assertNull(valueAxis18);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.AxisSpace axisSpace22 = xYPlot21.getFixedDomainAxisSpace();
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = xYPlot21.getOrientation();
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = xYPlot21.getDomainMarkers(layer24);
        float float26 = xYPlot21.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(axisSpace22);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.5f + "'", float26 == 0.5f);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset27 = categoryPlot26.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.data.Range range29 = categoryPlot26.getDataRange(valueAxis28);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray30 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot26.setRenderers(categoryItemRendererArray30);
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray34 = new org.jfree.chart.axis.ValueAxis[] { dateAxis32, dateAxis33 };
        categoryPlot26.setRangeAxes(valueAxisArray34);
        xYPlot21.setDomainAxes(valueAxisArray34);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(categoryDataset27);
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertNotNull(categoryItemRendererArray30);
        org.junit.Assert.assertNotNull(valueAxisArray34);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        java.lang.Object obj4 = categoryPlot0.clone();
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        int int12 = categoryPlot7.getIndexOf(categoryItemRenderer11);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor13 = categoryPlot7.getDomainGridlinePosition();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        dateAxis14.setLabelToolTip("hi!");
        categoryPlot7.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        dateAxis20.setLabel("");
        dateAxis20.setTickLabelsVisible(false);
        dateAxis20.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot27.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        dateAxis31.setLabel("");
        dateAxis31.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource36 = dateAxis31.getStandardTickUnits();
        boolean boolean37 = categoryPlot27.equals((java.lang.Object) dateAxis31);
        float float38 = dateAxis31.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) dateAxis20, (org.jfree.chart.axis.ValueAxis) dateAxis31, xYItemRenderer39);
        org.jfree.chart.axis.ValueAxis valueAxis42 = xYPlot40.getRangeAxis((int) (short) -1);
        java.awt.Paint paint43 = xYPlot40.getDomainCrosshairPaint();
        java.awt.Paint paint44 = xYPlot40.getRangeGridlinePaint();
        xYPlot40.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset46 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = xYPlot40.getRendererForDataset(xYDataset46);
        java.awt.Color color48 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        xYPlot40.setDomainGridlinePaint((java.awt.Paint) color48);
        java.awt.Color color50 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot40.setRangeTickBandPaint((java.awt.Paint) color50);
        org.jfree.chart.axis.AxisLocation axisLocation52 = xYPlot40.getRangeAxisLocation();
        categoryPlot7.setRangeAxisLocation(0, axisLocation52);
        org.jfree.chart.axis.AxisLocation axisLocation54 = axisLocation52.getOpposite();
        categoryPlot0.setDomainAxisLocation(12, axisLocation54);
        categoryPlot0.setRangeCrosshairValue((double) (short) -1, true);
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor13);
        org.junit.Assert.assertNotNull(tickUnitSource36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + float38 + "' != '" + 2.0f + "'", float38 == 2.0f);
        org.junit.Assert.assertNull(valueAxis42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNull(xYItemRenderer47);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(axisLocation52);
        org.junit.Assert.assertNotNull(axisLocation54);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        boolean boolean10 = categoryPlot0.render(graphics2D6, rectangle2D7, (int) ' ', plotRenderingInfo9);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = null;
        categoryPlot0.axisChanged(axisChangeEvent11);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot0.getDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("hi!");
        float float18 = categoryAxis17.getMaximumCategoryLabelWidthRatio();
        categoryPlot0.setDomainAxis(2, categoryAxis17, true);
        java.awt.Paint paint22 = categoryAxis17.getTickLabelPaint((java.lang.Comparable) 64);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 0.0f + "'", float18 == 0.0f);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getRangeAxisLocation((int) ' ');
        org.junit.Assert.assertNotNull(axisLocation5);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = numberAxis1.getTickUnit();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        dateAxis6.setLabel("");
        dateAxis6.setTickLabelsVisible(false);
        dateAxis6.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.setLabel("");
        dateAxis17.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource22 = dateAxis17.getStandardTickUnits();
        boolean boolean23 = categoryPlot13.equals((java.lang.Object) dateAxis17);
        float float24 = dateAxis17.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer25);
        org.jfree.chart.axis.ValueAxis valueAxis28 = xYPlot26.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        xYPlot26.zoomRangeAxes((double) (short) 100, plotRenderingInfo30, point2D31);
        org.jfree.chart.axis.AxisLocation axisLocation34 = null;
        xYPlot26.setDomainAxisLocation((int) (byte) 100, axisLocation34);
        java.awt.Paint paint36 = xYPlot26.getDomainTickBandPaint();
        boolean boolean37 = xYPlot26.isDomainZeroBaselineVisible();
        java.lang.String str38 = xYPlot26.getPlotType();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent39 = null;
        xYPlot26.rendererChanged(rendererChangeEvent39);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = xYPlot26.getDomainAxisEdge();
        try {
            double double42 = numberAxis1.java2DToValue((double) 13, rectangle2D4, rectangleEdge41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit2);
        org.junit.Assert.assertNotNull(tickUnitSource22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 2.0f + "'", float24 == 2.0f);
        org.junit.Assert.assertNull(valueAxis28);
        org.junit.Assert.assertNull(paint36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "XY Plot" + "'", str38.equals("XY Plot"));
        org.junit.Assert.assertNotNull(rectangleEdge41);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = xYPlot21.getDomainAxisEdge((int) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        xYPlot21.setRenderer((int) (short) 100, xYItemRenderer29, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = xYPlot21.getDomainAxisEdge((int) (byte) -1);
        org.jfree.chart.axis.AxisLocation axisLocation35 = xYPlot21.getDomainAxisLocation((int) (short) 0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray37 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer36 };
        xYPlot21.setRenderers(xYItemRendererArray37);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = xYPlot21.getAxisOffset();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(xYItemRendererArray37);
        org.junit.Assert.assertNotNull(rectangleInsets39);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setLabelToolTip("hi!");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = dateAxis0.getTickMarkPosition();
        double double4 = dateAxis0.getLabelAngle();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor11 = null;
        java.awt.geom.Point2D point2D12 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D10, rectangleAnchor11);
        categoryPlot7.zoomRangeAxes((double) (-1), plotRenderingInfo9, point2D12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        dateAxis18.setLabelToolTip("hi!");
        int int21 = categoryPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis18);
        java.awt.Font font22 = dateAxis18.getTickLabelFont();
        categoryPlot7.setNoDataMessageFont(font22);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = categoryPlot7.getDomainAxisEdge(4);
        try {
            double double26 = dateAxis0.valueToJava2D((double) 0L, rectangle2D6, rectangleEdge25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(point2D12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray4 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint6 = defaultDrawingSupplier5.getNextFillPaint();
        java.awt.Shape shape7 = defaultDrawingSupplier5.getNextShape();
        java.awt.Shape shape8 = defaultDrawingSupplier5.getNextShape();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        dateAxis10.setLabel("");
        dateAxis10.setTickLabelsVisible(false);
        dateAxis10.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        dateAxis21.setLabel("");
        dateAxis21.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource26 = dateAxis21.getStandardTickUnits();
        boolean boolean27 = categoryPlot17.equals((java.lang.Object) dateAxis21);
        float float28 = dateAxis21.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis21, xYItemRenderer29);
        float float31 = dateAxis21.getTickMarkOutsideLength();
        java.awt.Shape shape32 = dateAxis21.getRightArrow();
        java.awt.Shape[] shapeArray33 = new java.awt.Shape[] { shape8, shape32 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier34 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray3, strokeArray4, shapeArray33);
        java.awt.Paint[] paintArray35 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray36 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke stroke37 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke38 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke39 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot40.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis();
        dateAxis44.setLabelToolTip("hi!");
        int int47 = categoryPlot40.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis44);
        java.util.List list48 = categoryPlot40.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = categoryPlot40.getDomainAxis(100);
        org.jfree.chart.event.PlotChangeListener plotChangeListener51 = null;
        categoryPlot40.addChangeListener(plotChangeListener51);
        categoryPlot40.setBackgroundImageAlignment(0);
        categoryPlot40.setOutlineVisible(false);
        categoryPlot40.setBackgroundImageAlpha((float) 0L);
        java.awt.Stroke stroke59 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot40.setRangeCrosshairStroke(stroke59);
        java.awt.Stroke[] strokeArray61 = new java.awt.Stroke[] { stroke37, stroke38, stroke39, stroke59 };
        java.awt.Shape[] shapeArray62 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier63 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray1, paintArray35, strokeArray36, strokeArray61, shapeArray62);
        java.lang.Object obj64 = defaultDrawingSupplier63.clone();
        java.awt.Shape shape65 = defaultDrawingSupplier63.getNextShape();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertNotNull(strokeArray4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(tickUnitSource26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 2.0f + "'", float28 == 2.0f);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 2.0f + "'", float31 == 2.0f);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(shapeArray33);
        org.junit.Assert.assertNotNull(paintArray35);
        org.junit.Assert.assertNotNull(strokeArray36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertNotNull(list48);
        org.junit.Assert.assertNull(categoryAxis50);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertNotNull(strokeArray61);
        org.junit.Assert.assertNotNull(shapeArray62);
        org.junit.Assert.assertNotNull(obj64);
        org.junit.Assert.assertNotNull(shape65);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        xYPlot21.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot21.getRendererForDataset(xYDataset27);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot21.getDomainAxisEdge();
        java.awt.Stroke stroke30 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot21.setDomainGridlineStroke(stroke30);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(xYItemRenderer28);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        xYPlot21.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot21.getRendererForDataset(xYDataset27);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot21.getDomainAxisEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset32 = categoryPlot31.getDataset();
        boolean boolean33 = rectangleAnchor30.equals((java.lang.Object) categoryPlot31);
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_RED;
        categoryPlot31.setNoDataMessagePaint((java.awt.Paint) color34);
        xYPlot21.setDomainCrosshairPaint((java.awt.Paint) color34);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, 0.0d, (double) (-1L), 100.0d);
        xYPlot21.setAxisOffset(rectangleInsets41);
        java.awt.Paint paint43 = null;
        xYPlot21.setOutlinePaint(paint43);
        boolean boolean45 = xYPlot21.isRangeCrosshairVisible();
        java.awt.Font font46 = xYPlot21.getNoDataMessageFont();
        java.awt.Graphics2D graphics2D47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        xYPlot21.drawAnnotations(graphics2D47, rectangle2D48, plotRenderingInfo49);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(xYItemRenderer28);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNull(categoryDataset32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(font46);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.AxisSpace axisSpace2 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace2, true);
        categoryPlot0.clearDomainAxes();
        org.junit.Assert.assertNull(categoryDataset1);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        dateAxis11.setLabelToolTip("hi!");
        int int14 = categoryPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Font font15 = dateAxis11.getTickLabelFont();
        categoryPlot0.setNoDataMessageFont(font15);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = categoryPlot0.getDomainMarkers(layer17);
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace19, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        categoryPlot0.setRenderer(categoryItemRenderer22);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNull(collection18);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) (-1L), (double) (-29046));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getCategoryMargin();
        java.lang.Object obj3 = categoryAxis1.clone();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        int int1 = objectList0.size();
        java.lang.Object obj2 = objectList0.clone();
        int int3 = objectList0.size();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot4.getIndexOf(categoryItemRenderer8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        boolean boolean14 = categoryPlot4.render(graphics2D10, rectangle2D11, (int) ' ', plotRenderingInfo13);
        int int15 = categoryPlot4.getRangeAxisCount();
        org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.awt.Stroke stroke20 = null;
        intervalMarker19.setOutlineStroke(stroke20);
        java.awt.Stroke stroke22 = intervalMarker19.getOutlineStroke();
        java.awt.Font font23 = intervalMarker19.getLabelFont();
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean26 = categoryPlot4.removeRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker19, layer24, true);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer27 = intervalMarker19.getGradientPaintTransformer();
        boolean boolean28 = objectList0.equals((java.lang.Object) gradientPaintTransformer27);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertNull(stroke22);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(gradientPaintTransformer27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { dateAxis6, dateAxis7 };
        categoryPlot0.setRangeAxes(valueAxisArray8);
        java.util.List list10 = categoryPlot0.getCategories();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot0.zoomRangeAxes((-10.0d), plotRenderingInfo12, point2D13, false);
        org.jfree.chart.axis.AxisLocation axisLocation17 = null;
        categoryPlot0.setRangeAxisLocation((int) '#', axisLocation17, false);
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(list10);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(9, 4, 91);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        dateAxis11.setLabelToolTip("hi!");
        int int14 = categoryPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Font font15 = dateAxis11.getTickLabelFont();
        categoryPlot0.setNoDataMessageFont(font15);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = categoryPlot0.getDomainMarkers(layer17);
        java.awt.Paint paint19 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.RangeType rangeType22 = numberAxis21.getRangeType();
        boolean boolean23 = numberAxis21.isVisible();
        numberAxis21.configure();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis21);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rangeType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        java.awt.Color color0 = java.awt.Color.orange;
        java.awt.Color color1 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        java.lang.Object obj4 = categoryPlot0.clone();
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.setLabel("");
        dateAxis7.setTickLabelsVisible(false);
        dateAxis7.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        dateAxis18.setLabel("");
        dateAxis18.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource23 = dateAxis18.getStandardTickUnits();
        boolean boolean24 = categoryPlot14.equals((java.lang.Object) dateAxis18);
        float float25 = dateAxis18.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis18, xYItemRenderer26);
        org.jfree.chart.plot.IntervalMarker intervalMarker30 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot27.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker30);
        org.jfree.chart.plot.IntervalMarker intervalMarker34 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.awt.Stroke stroke35 = null;
        intervalMarker34.setOutlineStroke(stroke35);
        boolean boolean37 = xYPlot27.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker34);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, 0.0d, (double) (-1L), 100.0d);
        org.jfree.chart.text.TextAnchor textAnchor43 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        boolean boolean44 = rectangleInsets42.equals((java.lang.Object) textAnchor43);
        java.lang.String str45 = textAnchor43.toString();
        intervalMarker34.setLabelTextAnchor(textAnchor43);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent47 = null;
        intervalMarker34.notifyListeners(markerChangeEvent47);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker34);
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertNotNull(tickUnitSource23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 2.0f + "'", float25 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(textAnchor43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "TextAnchor.CENTER_LEFT" + "'", str45.equals("TextAnchor.CENTER_LEFT"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot21.zoomRangeAxes((double) (short) 100, plotRenderingInfo25, point2D26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = null;
        xYPlot21.setDomainAxisLocation((int) (byte) 100, axisLocation29);
        java.awt.Paint paint31 = xYPlot21.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.axis.ValueAxis valueAxis34 = xYPlot21.getDomainAxis();
        org.jfree.chart.plot.IntervalMarker intervalMarker38 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = intervalMarker38.getLabelAnchor();
        java.awt.Stroke stroke40 = intervalMarker38.getStroke();
        org.jfree.chart.util.Layer layer41 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean43 = xYPlot21.removeRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker38, layer41, false);
        java.awt.Stroke stroke44 = xYPlot21.getDomainGridlineStroke();
        boolean boolean45 = xYPlot21.isDomainCrosshairLockedOnData();
        boolean boolean46 = xYPlot21.isSubplot();
        xYPlot21.setDomainZeroBaselineVisible(true);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(valueAxis34);
        org.junit.Assert.assertNotNull(rectangleAnchor39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(layer41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        xYPlot21.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot21.getRendererForDataset(xYDataset27);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot21.getDomainAxisEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset32 = categoryPlot31.getDataset();
        boolean boolean33 = rectangleAnchor30.equals((java.lang.Object) categoryPlot31);
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_RED;
        categoryPlot31.setNoDataMessagePaint((java.awt.Paint) color34);
        xYPlot21.setDomainCrosshairPaint((java.awt.Paint) color34);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, 0.0d, (double) (-1L), 100.0d);
        xYPlot21.setAxisOffset(rectangleInsets41);
        java.awt.Paint paint43 = null;
        xYPlot21.setOutlinePaint(paint43);
        java.lang.String str45 = xYPlot21.getPlotType();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(xYItemRenderer28);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNull(categoryDataset32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "XY Plot" + "'", str45.equals("XY Plot"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.awt.Stroke stroke9 = null;
        intervalMarker8.setOutlineStroke(stroke9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        dateAxis15.setLabelToolTip("hi!");
        int int18 = categoryPlot11.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis15);
        java.util.List list19 = categoryPlot11.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = categoryPlot11.getDomainAxis(100);
        org.jfree.chart.event.PlotChangeListener plotChangeListener22 = null;
        categoryPlot11.addChangeListener(plotChangeListener22);
        categoryPlot11.setBackgroundImageAlignment(0);
        categoryPlot11.setOutlineVisible(false);
        categoryPlot11.setBackgroundImageAlpha((float) 0L);
        org.jfree.chart.util.Layer layer31 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection32 = categoryPlot11.getDomainMarkers(0, layer31);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker8, layer31);
        java.awt.Paint paint34 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        dateAxis35.setLabel("");
        dateAxis35.setTickLabelsVisible(false);
        dateAxis35.setAutoRange(false);
        dateAxis35.zoomRange((double) (short) -1, (double) (short) 10);
        org.jfree.data.time.DateRange dateRange45 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis35.setRangeWithMargins((org.jfree.data.Range) dateRange45);
        org.jfree.data.Range range47 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis35);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        int int50 = categoryPlot0.getWeight();
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNull(categoryAxis21);
        org.junit.Assert.assertNotNull(layer31);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(dateRange45);
        org.junit.Assert.assertNull(range47);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.util.List list8 = categoryPlot0.getAnnotations();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot0.getRangeAxisEdge();
        float float10 = categoryPlot0.getBackgroundImageAlpha();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = null;
        java.awt.geom.Point2D point2D17 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D15, rectangleAnchor16);
        categoryPlot12.zoomRangeAxes((double) (-1), plotRenderingInfo14, point2D17);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot19.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        dateAxis23.setLabelToolTip("hi!");
        int int26 = categoryPlot19.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis23);
        java.awt.Font font27 = dateAxis23.getTickLabelFont();
        categoryPlot12.setNoDataMessageFont(font27);
        org.jfree.chart.axis.AxisLocation axisLocation30 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot12.setDomainAxisLocation((int) (byte) 100, axisLocation30, true);
        categoryPlot0.setRangeAxisLocation((int) '#', axisLocation30, true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.5f + "'", float10 == 0.5f);
        org.junit.Assert.assertNotNull(point2D17);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(axisLocation30);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        categoryAxis1.setMaximumCategoryLabelLines((-29046));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.extendWidth((double) (byte) 100);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 116.0d + "'", double2 == 116.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint2 = defaultDrawingSupplier1.getNextPaint();
        java.awt.Paint paint3 = defaultDrawingSupplier1.getNextFillPaint();
        int int4 = day0.compareTo((java.lang.Object) paint3);
        int int5 = day0.getYear();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.setLabel("");
        dateAxis7.setTickLabelsVisible(false);
        dateAxis7.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        dateAxis18.setLabel("");
        dateAxis18.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource23 = dateAxis18.getStandardTickUnits();
        boolean boolean24 = categoryPlot14.equals((java.lang.Object) dateAxis18);
        float float25 = dateAxis18.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis18, xYItemRenderer26);
        float float28 = dateAxis18.getTickMarkOutsideLength();
        java.awt.Shape shape29 = dateAxis18.getRightArrow();
        dateAxis18.setUpperMargin(0.0d);
        org.jfree.data.Range range32 = dateAxis18.getDefaultAutoRange();
        boolean boolean33 = day0.equals((java.lang.Object) range32);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(tickUnitSource23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 2.0f + "'", float25 == 2.0f);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 2.0f + "'", float28 == 2.0f);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.lang.Object obj3 = intervalMarker2.clone();
        java.awt.Paint paint4 = intervalMarker2.getLabelPaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = intervalMarker2.getLabelOffsetType();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(lengthAdjustmentType5);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        xYPlot21.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot21.getRendererForDataset(xYDataset27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        xYPlot21.setDomainGridlinePaint((java.awt.Paint) color29);
        xYPlot21.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        xYPlot21.setDataset(xYDataset32);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(xYItemRenderer28);
        org.junit.Assert.assertNotNull(color29);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        dateAxis11.setLabelToolTip("hi!");
        int int14 = categoryPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Font font15 = dateAxis11.getTickLabelFont();
        categoryPlot0.setNoDataMessageFont(font15);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = categoryPlot0.getDomainMarkers(layer17);
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace19, false);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation22 = null;
        try {
            boolean boolean23 = categoryPlot0.removeAnnotation(categoryAnnotation22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNull(collection18);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.awt.Stroke stroke9 = null;
        intervalMarker8.setOutlineStroke(stroke9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        dateAxis15.setLabelToolTip("hi!");
        int int18 = categoryPlot11.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis15);
        java.util.List list19 = categoryPlot11.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = categoryPlot11.getDomainAxis(100);
        org.jfree.chart.event.PlotChangeListener plotChangeListener22 = null;
        categoryPlot11.addChangeListener(plotChangeListener22);
        categoryPlot11.setBackgroundImageAlignment(0);
        categoryPlot11.setOutlineVisible(false);
        categoryPlot11.setBackgroundImageAlpha((float) 0L);
        org.jfree.chart.util.Layer layer31 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection32 = categoryPlot11.getDomainMarkers(0, layer31);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker8, layer31);
        java.awt.Paint paint34 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        dateAxis35.setLabel("");
        dateAxis35.setTickLabelsVisible(false);
        dateAxis35.setAutoRange(false);
        dateAxis35.zoomRange((double) (short) -1, (double) (short) 10);
        org.jfree.data.time.DateRange dateRange45 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis35.setRangeWithMargins((org.jfree.data.Range) dateRange45);
        org.jfree.data.Range range47 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis35);
        categoryPlot0.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNull(categoryAxis21);
        org.junit.Assert.assertNotNull(layer31);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(dateRange45);
        org.junit.Assert.assertNull(range47);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.awt.Stroke stroke4 = null;
        intervalMarker3.setOutlineStroke(stroke4);
        java.awt.Stroke stroke6 = intervalMarker3.getOutlineStroke();
        org.jfree.chart.text.TextAnchor textAnchor7 = intervalMarker3.getLabelTextAnchor();
        boolean boolean8 = rectangleAnchor0.equals((java.lang.Object) textAnchor7);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNull(stroke6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        boolean boolean5 = dateAxis1.isHiddenValue((long) (byte) 0);
        boolean boolean6 = dateAxis1.isNegativeArrowVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        dateAxis11.setLabel("");
        dateAxis11.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = dateAxis11.getStandardTickUnits();
        boolean boolean17 = categoryPlot7.equals((java.lang.Object) dateAxis11);
        float float18 = dateAxis11.getTickMarkOutsideLength();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis11.setTickLabelPaint((java.awt.Paint) color19);
        boolean boolean21 = dateAxis11.isVerticalTickLabels();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis11, xYItemRenderer22);
        xYPlot23.setRangeCrosshairValue((double) 91, false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 2.0f + "'", float18 == 2.0f);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        java.awt.Stroke stroke7 = null;
        categoryPlot0.setOutlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace9, false);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Stroke stroke14 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L, (java.awt.Paint) color13, stroke14);
        categoryMarker15.setDrawAsLine(false);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        dateAxis19.setLabel("");
        dateAxis19.setTickLabelsVisible(false);
        dateAxis19.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot26.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis30 = new org.jfree.chart.axis.DateAxis();
        dateAxis30.setLabel("");
        dateAxis30.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource35 = dateAxis30.getStandardTickUnits();
        boolean boolean36 = categoryPlot26.equals((java.lang.Object) dateAxis30);
        float float37 = dateAxis30.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) dateAxis19, (org.jfree.chart.axis.ValueAxis) dateAxis30, xYItemRenderer38);
        org.jfree.chart.plot.IntervalMarker intervalMarker42 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot39.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker42);
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset47 = null;
        xYPlot45.setDataset(10, xYDataset47);
        org.jfree.chart.util.Layer layer50 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection51 = xYPlot45.getDomainMarkers((-1), layer50);
        java.util.Collection collection52 = xYPlot39.getRangeMarkers(0, layer50);
        categoryPlot0.addDomainMarker(categoryMarker15, layer50);
        categoryMarker15.setDrawAsLine(true);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(tickUnitSource35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 2.0f + "'", float37 == 2.0f);
        org.junit.Assert.assertNotNull(layer50);
        org.junit.Assert.assertNull(collection51);
        org.junit.Assert.assertNull(collection52);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        java.awt.Stroke stroke7 = null;
        categoryPlot0.setOutlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace9, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setLabelToolTip("hi!");
        int int19 = categoryPlot12.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis16);
        java.awt.Font font20 = dateAxis16.getTickLabelFont();
        boolean boolean21 = dateAxis16.isAxisLineVisible();
        dateAxis16.setAxisLineVisible(true);
        dateAxis16.setPositiveArrowVisible(true);
        float float26 = dateAxis16.getTickMarkOutsideLength();
        int int27 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis16);
        dateAxis16.setAutoTickUnitSelection(false);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 2.0f + "'", float26 == 2.0f);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        org.jfree.chart.plot.IntervalMarker intervalMarker28 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.awt.Stroke stroke29 = null;
        intervalMarker28.setOutlineStroke(stroke29);
        boolean boolean31 = xYPlot21.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker28);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, 0.0d, (double) (-1L), 100.0d);
        org.jfree.chart.text.TextAnchor textAnchor37 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        boolean boolean38 = rectangleInsets36.equals((java.lang.Object) textAnchor37);
        java.lang.String str39 = textAnchor37.toString();
        intervalMarker28.setLabelTextAnchor(textAnchor37);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = null;
        java.awt.geom.Point2D point2D46 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D44, rectangleAnchor45);
        categoryPlot41.zoomRangeAxes((double) (-1), plotRenderingInfo43, point2D46);
        categoryPlot41.setBackgroundImageAlpha((float) 0L);
        org.jfree.data.category.CategoryDataset categoryDataset50 = categoryPlot41.getDataset();
        categoryPlot41.clearAnnotations();
        java.awt.Graphics2D graphics2D52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo55 = null;
        boolean boolean56 = categoryPlot41.render(graphics2D52, rectangle2D53, (int) (byte) -1, plotRenderingInfo55);
        boolean boolean57 = intervalMarker28.equals((java.lang.Object) categoryPlot41);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(textAnchor37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "TextAnchor.CENTER_LEFT" + "'", str39.equals("TextAnchor.CENTER_LEFT"));
        org.junit.Assert.assertNotNull(point2D46);
        org.junit.Assert.assertNull(categoryDataset50);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getUpArrow();
        dateAxis0.setVisible(true);
        dateAxis0.setUpperBound((double) 8);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot21.zoomRangeAxes((double) (short) 100, plotRenderingInfo25, point2D26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = null;
        xYPlot21.setDomainAxisLocation((int) (byte) 100, axisLocation29);
        java.awt.Paint paint31 = xYPlot21.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.axis.ValueAxis valueAxis34 = xYPlot21.getDomainAxis();
        org.jfree.chart.plot.IntervalMarker intervalMarker38 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = intervalMarker38.getLabelAnchor();
        java.awt.Stroke stroke40 = intervalMarker38.getStroke();
        org.jfree.chart.util.Layer layer41 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean43 = xYPlot21.removeRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker38, layer41, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = xYPlot21.getAxisOffset();
        org.jfree.chart.axis.AxisSpace axisSpace45 = xYPlot21.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(valueAxis34);
        org.junit.Assert.assertNotNull(rectangleAnchor39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(layer41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNull(axisSpace45);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        boolean boolean10 = categoryPlot0.render(graphics2D6, rectangle2D7, (int) ' ', plotRenderingInfo9);
        categoryPlot0.clearDomainMarkers((-16646144));
        boolean boolean13 = categoryPlot0.isSubplot();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Font font8 = dateAxis4.getTickLabelFont();
        boolean boolean9 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAxisLineVisible(true);
        boolean boolean13 = dateAxis4.isHiddenValue((long) 5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        xYPlot21.clearDomainAxes();
        boolean boolean27 = xYPlot21.isDomainZeroBaselineVisible();
        boolean boolean28 = xYPlot21.isSubplot();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        java.awt.Color color2 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT", (int) (byte) 10);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, 0.0d, (double) (-1L), 100.0d);
        double double5 = rectangleInsets4.getRight();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D9 = rectangleInsets4.createOutsetRectangle(rectangle2D6, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        java.awt.Image image2 = null;
        categoryPlot0.setBackgroundImage(image2);
        try {
            categoryPlot0.zoom((double) 9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryDataset1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.setLabelToolTip("hi!");
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis7);
        java.awt.Font font11 = dateAxis7.getTickLabelFont();
        float float12 = dateAxis7.getTickMarkInsideLength();
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        dateAxis7.setAxisLineStroke(stroke13);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.0f + "'", float12 == 0.0f);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot21.zoomRangeAxes((double) (short) 100, plotRenderingInfo25, point2D26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = null;
        xYPlot21.setDomainAxisLocation((int) (byte) 100, axisLocation29);
        java.awt.Paint paint31 = xYPlot21.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        int int35 = xYPlot21.indexOf(xYDataset34);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder36 = xYPlot21.getDatasetRenderingOrder();
        boolean boolean37 = xYPlot21.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(datasetRenderingOrder36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        boolean boolean2 = textAnchor0.equals((java.lang.Object) (byte) -1);
        java.lang.String str3 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.TOP_RIGHT" + "'", str3.equals("TextAnchor.TOP_RIGHT"));
    }

//    @Test
//    public void test187() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test187");
//        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
//        categoryPlot0.setAnchorValue(1.0d, false);
//        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
//        dateAxis4.setLabelToolTip("hi!");
//        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
//        java.awt.Font font8 = dateAxis4.getTickLabelFont();
//        java.awt.Color color12 = java.awt.Color.getHSBColor((float) '4', (float) 'a', (float) 0);
//        dateAxis4.setTickMarkPaint((java.awt.Paint) color12);
//        org.jfree.data.Range range14 = dateAxis4.getDefaultAutoRange();
//        dateAxis4.setLabelToolTip("hi!");
//        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
//        java.awt.Color color18 = org.jfree.chart.ChartColor.DARK_MAGENTA;
//        categoryPlot17.setDomainGridlinePaint((java.awt.Paint) color18);
//        java.awt.Paint paint20 = categoryPlot17.getRangeCrosshairPaint();
//        dateAxis4.setPlot((org.jfree.chart.plot.Plot) categoryPlot17);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//        java.awt.Paint paint24 = defaultDrawingSupplier23.getNextPaint();
//        java.awt.Paint paint25 = defaultDrawingSupplier23.getNextFillPaint();
//        int int26 = day22.compareTo((java.lang.Object) paint25);
//        int int27 = day22.getMonth();
//        long long28 = day22.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = day22.next();
//        java.util.Date date30 = regularTimePeriod29.getStart();
//        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
//        org.jfree.chart.axis.DateTickUnit dateTickUnit32 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
//        dateAxis31.setTickUnit(dateTickUnit32);
//        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
//        java.awt.Shape shape35 = dateAxis34.getUpArrow();
//        dateAxis34.setLabelAngle((double) 0.0f);
//        dateAxis34.setUpperBound((double) (byte) 10);
//        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis();
//        dateAxis40.setLabel("");
//        dateAxis40.setTickLabelsVisible(false);
//        dateAxis40.setAutoRange(false);
//        dateAxis40.zoomRange((double) (short) -1, (double) (short) 10);
//        org.jfree.data.time.DateRange dateRange50 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
//        dateAxis40.setRangeWithMargins((org.jfree.data.Range) dateRange50);
//        dateAxis34.setRangeWithMargins((org.jfree.data.Range) dateRange50, false, true);
//        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot();
//        categoryPlot55.setAnchorValue(1.0d, false);
//        org.jfree.chart.axis.DateAxis dateAxis59 = new org.jfree.chart.axis.DateAxis();
//        dateAxis59.setLabelToolTip("hi!");
//        int int62 = categoryPlot55.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis59);
//        java.awt.Font font63 = dateAxis59.getTickLabelFont();
//        java.util.Date date64 = dateAxis59.getMinimumDate();
//        dateAxis34.setMaximumDate(date64);
//        java.util.Date date66 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        dateAxis31.setRange(date64, date66);
//        try {
//            dateAxis4.setRange(date30, date66);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNotNull(font8);
//        org.junit.Assert.assertNotNull(color12);
//        org.junit.Assert.assertNotNull(range14);
//        org.junit.Assert.assertNotNull(color18);
//        org.junit.Assert.assertNotNull(paint20);
//        org.junit.Assert.assertNotNull(paint24);
//        org.junit.Assert.assertNotNull(paint25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
//        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560409200000L + "'", long28 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(dateTickUnit32);
//        org.junit.Assert.assertNotNull(shape35);
//        org.junit.Assert.assertNotNull(dateRange50);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
//        org.junit.Assert.assertNotNull(font63);
//        org.junit.Assert.assertNotNull(date64);
//        org.junit.Assert.assertNotNull(date66);
//    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        java.lang.Object obj4 = categoryPlot0.clone();
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot0.getFixedRangeAxisSpace();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot0.getDomainAxisLocation((int) ' ');
        categoryPlot0.clearRangeMarkers((int) '#');
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation8);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.util.List list8 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxis(100);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        categoryPlot0.addChangeListener(plotChangeListener11);
        categoryPlot0.setBackgroundImageAlignment(0);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = categoryPlot0.getLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot0.getRenderer();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(legendItemCollection15);
        org.junit.Assert.assertNull(categoryItemRenderer16);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        dateAxis11.setLabelToolTip("hi!");
        int int14 = categoryPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Font font15 = dateAxis11.getTickLabelFont();
        categoryPlot0.setNoDataMessageFont(font15);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = categoryPlot0.getDomainMarkers(layer17);
        java.util.List list19 = categoryPlot0.getCategories();
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNull(list19);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        xYPlot21.clearRangeAxes();
        boolean boolean27 = xYPlot21.isDomainCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis28 = xYPlot21.getRangeAxis();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(valueAxis28);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        org.jfree.chart.plot.IntervalMarker intervalMarker28 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker28);
        java.lang.String str30 = intervalMarker28.getLabel();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(str30);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        boolean boolean10 = categoryPlot0.render(graphics2D6, rectangle2D7, (int) ' ', plotRenderingInfo9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot0.getDomainAxis();
        try {
            categoryPlot0.zoom((double) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(categoryAxis11);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        xYPlot21.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot21.getRendererForDataset(xYDataset27);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot21.getDomainAxisEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset32 = categoryPlot31.getDataset();
        boolean boolean33 = rectangleAnchor30.equals((java.lang.Object) categoryPlot31);
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_RED;
        categoryPlot31.setNoDataMessagePaint((java.awt.Paint) color34);
        xYPlot21.setDomainCrosshairPaint((java.awt.Paint) color34);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, 0.0d, (double) (-1L), 100.0d);
        xYPlot21.setAxisOffset(rectangleInsets41);
        double double43 = rectangleInsets41.getBottom();
        double double45 = rectangleInsets41.extendHeight((double) 500);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(xYItemRenderer28);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNull(categoryDataset32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + (-1.0d) + "'", double43 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 509.0d + "'", double45 == 509.0d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot21.zoomRangeAxes((double) (short) 100, plotRenderingInfo25, point2D26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = null;
        xYPlot21.setDomainAxisLocation((int) (byte) 100, axisLocation29);
        java.awt.Paint paint31 = xYPlot21.getDomainTickBandPaint();
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.util.List list34 = null;
        xYPlot21.drawRangeTickBands(graphics2D32, rectangle2D33, list34);
        xYPlot21.zoom((double) 100);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNull(paint31);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        xYPlot27.setDataset(10, xYDataset29);
        org.jfree.chart.util.Layer layer32 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection33 = xYPlot27.getDomainMarkers((-1), layer32);
        java.util.Collection collection34 = xYPlot21.getRangeMarkers(0, layer32);
        xYPlot21.setWeight(5);
        xYPlot21.setBackgroundImageAlpha(0.0f);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNotNull(layer32);
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertNull(collection34);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot21.getRangeAxisEdge();
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        org.jfree.chart.plot.CrosshairState crosshairState31 = null;
        boolean boolean32 = xYPlot21.render(graphics2D27, rectangle2D28, 175, plotRenderingInfo30, crosshairState31);
        org.jfree.chart.axis.AxisSpace axisSpace33 = null;
        xYPlot21.setFixedRangeAxisSpace(axisSpace33, false);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        java.awt.Stroke stroke6 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.util.SortOrder sortOrder7 = org.jfree.chart.util.SortOrder.DESCENDING;
        categoryPlot0.setColumnRenderingOrder(sortOrder7);
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(sortOrder7);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (byte) 10);
        int int2 = objectList1.size();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.05d, 1.0d);
        java.lang.Object obj3 = intervalMarker2.clone();
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        java.awt.Stroke stroke7 = null;
        categoryPlot0.setOutlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace9, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setLabelToolTip("hi!");
        int int19 = categoryPlot12.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis16);
        java.awt.Font font20 = dateAxis16.getTickLabelFont();
        boolean boolean21 = dateAxis16.isAxisLineVisible();
        dateAxis16.setAxisLineVisible(true);
        dateAxis16.setPositiveArrowVisible(true);
        float float26 = dateAxis16.getTickMarkOutsideLength();
        int int27 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis16);
        java.awt.Font font28 = dateAxis16.getLabelFont();
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.axis.AxisState axisState30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        dateAxis33.setLabel("");
        dateAxis33.setTickLabelsVisible(false);
        dateAxis33.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot40.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis();
        dateAxis44.setLabel("");
        dateAxis44.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource49 = dateAxis44.getStandardTickUnits();
        boolean boolean50 = categoryPlot40.equals((java.lang.Object) dateAxis44);
        float float51 = dateAxis44.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer52 = null;
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot(xYDataset32, (org.jfree.chart.axis.ValueAxis) dateAxis33, (org.jfree.chart.axis.ValueAxis) dateAxis44, xYItemRenderer52);
        org.jfree.chart.axis.ValueAxis valueAxis55 = xYPlot53.getRangeAxis((int) (short) -1);
        java.awt.Paint paint56 = xYPlot53.getDomainCrosshairPaint();
        java.awt.Paint paint57 = xYPlot53.getRangeGridlinePaint();
        xYPlot53.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset59 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer60 = xYPlot53.getRendererForDataset(xYDataset59);
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = xYPlot53.getDomainAxisEdge();
        try {
            java.util.List list62 = dateAxis16.refreshTicks(graphics2D29, axisState30, rectangle2D31, rectangleEdge61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 2.0f + "'", float26 == 2.0f);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(tickUnitSource49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + float51 + "' != '" + 2.0f + "'", float51 == 2.0f);
        org.junit.Assert.assertNull(valueAxis55);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNull(xYItemRenderer60);
        org.junit.Assert.assertNotNull(rectangleEdge61);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("CategoryAnchor.MIDDLE");
        java.lang.String str3 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        boolean boolean26 = xYPlot21.isRangeGridlinesVisible();
        xYPlot21.clearRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        xYPlot21.setRangeAxis(valueAxis28);
        org.jfree.chart.axis.AxisLocation axisLocation30 = xYPlot21.getRangeAxisLocation();
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        java.awt.Color color32 = color31.darker();
        xYPlot21.setRangeGridlinePaint((java.awt.Paint) color31);
        int int34 = color31.getAlpha();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 255 + "'", int34 == 255);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextFillPaint();
        java.lang.Class<?> wildcardClass3 = defaultDrawingSupplier0.getClass();
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis5.setTickUnit(dateTickUnit6);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape9 = dateAxis8.getUpArrow();
        dateAxis8.setLabelAngle((double) 0.0f);
        dateAxis8.setUpperBound((double) (byte) 10);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        dateAxis14.setLabel("");
        dateAxis14.setTickLabelsVisible(false);
        dateAxis14.setAutoRange(false);
        dateAxis14.zoomRange((double) (short) -1, (double) (short) 10);
        org.jfree.data.time.DateRange dateRange24 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis14.setRangeWithMargins((org.jfree.data.Range) dateRange24);
        dateAxis8.setRangeWithMargins((org.jfree.data.Range) dateRange24, false, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        dateAxis33.setLabelToolTip("hi!");
        int int36 = categoryPlot29.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis33);
        java.awt.Font font37 = dateAxis33.getTickLabelFont();
        java.util.Date date38 = dateAxis33.getMinimumDate();
        dateAxis8.setMaximumDate(date38);
        java.util.Date date40 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis5.setRange(date38, date40);
        java.util.TimeZone timeZone42 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date38, timeZone42);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(dateRange24);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNull(regularTimePeriod43);
    }
}

