import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke2 = null;
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Stroke stroke4 = null;
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker6 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1L, (java.awt.Paint) color1, stroke2, (java.awt.Paint) color3, stroke4, (float) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.awt.Color color0 = java.awt.Color.darkGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.Marker marker1 = null;
        try {
            categoryPlot0.addRangeMarker(marker1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation2 = null;
        try {
            boolean boolean3 = categoryPlot0.removeAnnotation(categoryAnnotation2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryDataset1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        try {
            categoryPlot0.zoom((double) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setLabel("");
        try {
            dateAxis0.setAutoRangeMinimumSize(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        java.lang.Object obj6 = categoryPlot0.clone();
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = null;
        org.jfree.chart.util.Layer layer9 = null;
        try {
            categoryPlot0.addDomainMarker(10, categoryMarker8, layer9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.0d, (double) '4', (double) (byte) -1, (double) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke1 = null;
        try {
            dateAxis0.setAxisLineStroke(stroke1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.awt.Color color0 = java.awt.Color.GRAY;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray7 = new float[] { ' ', (short) 100, 100, '#', '4' };
        try {
            float[] floatArray8 = color0.getColorComponents(colorSpace1, floatArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray7);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Stroke stroke1 = null;
        try {
            dateAxis0.setTickMarkStroke(stroke1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = null;
        org.jfree.chart.util.Layer layer9 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker8, layer9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        java.lang.Object obj4 = categoryPlot0.clone();
        java.awt.Stroke stroke5 = null;
        try {
            categoryPlot0.setDomainGridlineStroke(stroke5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Font font8 = dateAxis4.getTickLabelFont();
        org.jfree.data.Range range9 = null;
        try {
            dateAxis4.setRangeWithMargins(range9, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.BOTTOM_LEFT" + "'", str1.equals("RectangleAnchor.BOTTOM_LEFT"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        boolean boolean10 = categoryPlot0.render(graphics2D6, rectangle2D7, (int) ' ', plotRenderingInfo9);
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = null;
        try {
            categoryPlot0.setOrientation(plotOrientation11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.awt.Stroke stroke3 = null;
        intervalMarker2.setOutlineStroke(stroke3);
        java.lang.Class class5 = null;
        try {
            java.util.EventListener[] eventListenerArray6 = intervalMarker2.getListeners(class5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        try {
            categoryPlot0.handleClick(100, (int) (byte) 10, plotRenderingInfo4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryDataset1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.TOP_RIGHT" + "'", str1.equals("TextAnchor.TOP_RIGHT"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        java.lang.Object obj6 = categoryPlot0.clone();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = categoryPlot0.getDrawingSupplier();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = null;
        java.awt.geom.Point2D point2D15 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D13, rectangleAnchor14);
        categoryPlot10.zoomRangeAxes((double) (-1), plotRenderingInfo12, point2D15);
        categoryPlot10.setBackgroundImageAlpha((float) 0L);
        org.jfree.data.category.CategoryDataset categoryDataset19 = categoryPlot10.getDataset();
        categoryPlot10.mapDatasetToDomainAxis(0, (int) (byte) 100);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = null;
        java.awt.geom.Point2D point2D28 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D26, rectangleAnchor27);
        categoryPlot10.zoomDomainAxes((double) 1.0f, 0.05d, plotRenderingInfo25, point2D28);
        org.jfree.chart.plot.PlotState plotState30 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        try {
            categoryPlot0.draw(graphics2D8, rectangle2D9, point2D28, plotState30, plotRenderingInfo31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(drawingSupplier7);
        org.junit.Assert.assertNotNull(point2D15);
        org.junit.Assert.assertNull(categoryDataset19);
        org.junit.Assert.assertNotNull(point2D28);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        float[] floatArray2 = new float[] {};
        try {
            float[] floatArray3 = color0.getRGBComponents(floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setLabel("");
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot7.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.data.Range range10 = categoryPlot7.getDataRange(valueAxis9);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray11 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot7.setRenderers(categoryItemRendererArray11);
        java.lang.Object obj13 = categoryPlot7.clone();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        dateAxis15.setLabelToolTip("hi!");
        categoryPlot7.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis15, false);
        categoryPlot7.setNoDataMessage("");
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = categoryPlot7.getRangeAxisEdge((int) (short) 1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        try {
            org.jfree.chart.axis.AxisState axisState25 = dateAxis0.draw(graphics2D3, 0.0d, rectangle2D5, rectangle2D6, rectangleEdge23, plotRenderingInfo24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertNotNull(categoryItemRendererArray11);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Font font8 = dateAxis4.getTickLabelFont();
        java.awt.Color color12 = java.awt.Color.getHSBColor((float) '4', (float) 'a', (float) 0);
        dateAxis4.setTickMarkPaint((java.awt.Paint) color12);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType15 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset17 = categoryPlot16.getDataset();
        boolean boolean18 = lengthAdjustmentType15.equals((java.lang.Object) categoryPlot16);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset21 = categoryPlot20.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.data.Range range23 = categoryPlot20.getDataRange(valueAxis22);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray24 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot20.setRenderers(categoryItemRendererArray24);
        java.lang.Object obj26 = categoryPlot20.clone();
        org.jfree.chart.axis.DateAxis dateAxis28 = new org.jfree.chart.axis.DateAxis();
        dateAxis28.setLabelToolTip("hi!");
        categoryPlot20.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis28, false);
        categoryPlot20.setNoDataMessage("");
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot20.getRangeAxisEdge((int) (short) 1);
        org.jfree.chart.axis.AxisSpace axisSpace37 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace38 = dateAxis4.reserveSpace(graphics2D14, (org.jfree.chart.plot.Plot) categoryPlot16, rectangle2D19, rectangleEdge36, axisSpace37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(lengthAdjustmentType15);
        org.junit.Assert.assertNull(categoryDataset17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(categoryDataset21);
        org.junit.Assert.assertNull(range23);
        org.junit.Assert.assertNotNull(categoryItemRendererArray24);
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertNotNull(rectangleEdge36);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        try {
            java.awt.Paint paint23 = xYPlot21.getQuadrantPaint((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (-1) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxisForDataset(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 8 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabel("");
        dateAxis4.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = dateAxis4.getStandardTickUnits();
        boolean boolean10 = categoryPlot0.equals((java.lang.Object) dateAxis4);
        float float11 = dateAxis4.getTickMarkOutsideLength();
        java.lang.String str12 = dateAxis4.getLabelToolTip();
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 2.0f + "'", float11 == 2.0f);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = intervalMarker3.getLabelAnchor();
        try {
            java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor4);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        categoryPlot0.setBackgroundImageAlpha((float) 0L);
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot0.getDataset();
        try {
            categoryPlot0.zoom((-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(categoryDataset9);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.util.List list8 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxis(100);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot0.getRangeMarkers(layer11);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNull(collection12);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        java.awt.Stroke stroke6 = categoryPlot0.getOutlineStroke();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = null;
        java.awt.geom.Point2D point2D14 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D12, rectangleAnchor13);
        categoryPlot9.zoomRangeAxes((double) (-1), plotRenderingInfo11, point2D14);
        org.jfree.chart.plot.PlotState plotState16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        try {
            categoryPlot0.draw(graphics2D7, rectangle2D8, point2D14, plotState16, plotRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(point2D14);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        java.awt.Stroke stroke4 = null;
        categoryPlot0.setOutlineStroke(stroke4);
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = null;
        try {
            categoryPlot0.setOrientation(plotOrientation6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        java.awt.Font font0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.CENTER;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        try {
            java.awt.Color color1 = java.awt.Color.decode("RectangleAnchor.BOTTOM_LEFT");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"RectangleAnchor.BOTTOM_LEFT\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Font font8 = dateAxis4.getTickLabelFont();
        java.awt.Shape shape9 = null;
        try {
            dateAxis4.setRightArrow(shape9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot0.setDomainAxis(categoryAxis8);
        categoryPlot0.configureRangeAxes();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        java.awt.Stroke stroke6 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        categoryPlot0.addChangeListener(plotChangeListener7);
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getUpArrow();
        dateAxis0.setLabelAngle((double) 0.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.setLabelToolTip("hi!");
        int int11 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis8);
        java.awt.Font font12 = dateAxis8.getTickLabelFont();
        java.util.Date date13 = dateAxis8.getMinimumDate();
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset16 = categoryPlot15.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.data.Range range18 = categoryPlot15.getDataRange(valueAxis17);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray19 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot15.setRenderers(categoryItemRendererArray19);
        java.lang.Object obj21 = categoryPlot15.clone();
        org.jfree.chart.axis.DateAxis dateAxis23 = new org.jfree.chart.axis.DateAxis();
        dateAxis23.setLabelToolTip("hi!");
        categoryPlot15.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis23, false);
        categoryPlot15.setNoDataMessage("");
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot15.getRangeAxisEdge((int) (short) 1);
        try {
            double double32 = dateAxis0.dateToJava2D(date13, rectangle2D14, rectangleEdge31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNull(categoryDataset16);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertNotNull(categoryItemRendererArray19);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(rectangleEdge31);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setLabel("");
        dateAxis0.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = dateAxis0.getStandardTickUnits();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset11 = categoryPlot10.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.data.Range range13 = categoryPlot10.getDataRange(valueAxis12);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot10.setRenderers(categoryItemRendererArray14);
        java.lang.Object obj16 = categoryPlot10.clone();
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        dateAxis18.setLabelToolTip("hi!");
        categoryPlot10.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis18, false);
        categoryPlot10.setNoDataMessage("");
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot10.getRangeAxisEdge((int) (short) 1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        try {
            org.jfree.chart.axis.AxisState axisState28 = dateAxis0.draw(graphics2D6, (double) 1L, rectangle2D8, rectangle2D9, rectangleEdge26, plotRenderingInfo27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource5);
        org.junit.Assert.assertNull(categoryDataset11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot21.zoomRangeAxes((double) (short) 100, plotRenderingInfo25, point2D26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = null;
        xYPlot21.setDomainAxisLocation((int) (byte) 100, axisLocation29);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        try {
            xYPlot21.handleClick((int) '#', 2, plotRenderingInfo33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, 0.0d, (double) (-1L), 100.0d);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            rectangleInsets4.trim(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        java.awt.Stroke stroke4 = null;
        categoryPlot0.setOutlineStroke(stroke4);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        try {
            int int7 = categoryPlot0.getDomainAxisIndex(categoryAxis6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder24 = null;
        try {
            xYPlot21.setDatasetRenderingOrder(datasetRenderingOrder24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        dateAxis11.setLabelToolTip("hi!");
        int int14 = categoryPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Font font15 = dateAxis11.getTickLabelFont();
        boolean boolean16 = dateAxis11.isAxisLineVisible();
        dateAxis11.setAxisLineVisible(true);
        org.jfree.data.Range range19 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis11);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNull(range19);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        org.jfree.chart.plot.IntervalMarker intervalMarker28 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.awt.Stroke stroke29 = null;
        intervalMarker28.setOutlineStroke(stroke29);
        boolean boolean31 = xYPlot21.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker28);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation32 = null;
        try {
            boolean boolean33 = xYPlot21.removeAnnotation(xYAnnotation32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int int3 = java.awt.Color.HSBtoRGB((float) (byte) 100, (float) (byte) 100, (float) '#');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-29046) + "'", int3 == (-29046));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot21.zoomRangeAxes((double) (short) 100, plotRenderingInfo25, point2D26);
        java.awt.Paint paint28 = null;
        try {
            xYPlot21.setDomainCrosshairPaint(paint28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabel("");
        dateAxis4.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = dateAxis4.getStandardTickUnits();
        boolean boolean10 = categoryPlot0.equals((java.lang.Object) dateAxis4);
        dateAxis4.setUpperBound((double) 0.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.setLabelToolTip("hi!");
        int int20 = categoryPlot13.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis17);
        java.awt.Font font21 = dateAxis17.getTickLabelFont();
        java.util.Date date22 = dateAxis17.getMinimumDate();
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        dateAxis25.setLabel("");
        dateAxis25.setTickLabelsVisible(false);
        dateAxis25.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot32.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        dateAxis36.setLabel("");
        dateAxis36.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource41 = dateAxis36.getStandardTickUnits();
        boolean boolean42 = categoryPlot32.equals((java.lang.Object) dateAxis36);
        float float43 = dateAxis36.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer44 = null;
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) dateAxis25, (org.jfree.chart.axis.ValueAxis) dateAxis36, xYItemRenderer44);
        org.jfree.chart.axis.ValueAxis valueAxis47 = xYPlot45.getRangeAxis((int) (short) -1);
        java.awt.Paint paint48 = xYPlot45.getDomainCrosshairPaint();
        java.awt.Paint paint49 = xYPlot45.getRangeGridlinePaint();
        boolean boolean50 = xYPlot45.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = xYPlot45.getRangeAxisEdge();
        try {
            double double52 = dateAxis4.dateToJava2D(date22, rectangle2D23, rectangleEdge51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(tickUnitSource41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 2.0f + "'", float43 == 2.0f);
        org.junit.Assert.assertNull(valueAxis47);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(rectangleEdge51);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setLabel("");
        dateAxis0.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = dateAxis0.getStandardTickUnits();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = null;
        java.awt.geom.Point2D point2D11 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D9, rectangleAnchor10);
        categoryPlot6.zoomRangeAxes((double) (-1), plotRenderingInfo8, point2D11);
        java.awt.Stroke stroke13 = null;
        categoryPlot6.setOutlineStroke(stroke13);
        dateAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        java.awt.Font font16 = dateAxis0.getTickLabelFont();
        org.junit.Assert.assertNotNull(tickUnitSource5);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = null;
        try {
            dateAxis0.setRangeWithMargins(range1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        boolean boolean10 = categoryPlot0.render(graphics2D6, rectangle2D7, (int) ' ', plotRenderingInfo9);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = null;
        categoryPlot0.axisChanged(axisChangeEvent11);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.JFreeChart jFreeChart14 = null;
        plotChangeEvent13.setChart(jFreeChart14);
        org.jfree.chart.JFreeChart jFreeChart16 = null;
        plotChangeEvent13.setChart(jFreeChart16);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.RangeType rangeType2 = numberAxis1.getRangeType();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = null;
        try {
            numberAxis1.setTickUnit(numberTickUnit3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rangeType2);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        java.lang.Object obj6 = categoryPlot0.clone();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.setLabelToolTip("hi!");
        categoryPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis8, false);
        categoryPlot0.setNoDataMessage("");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        try {
            categoryPlot0.zoomRangeAxes((double) (short) 100, (double) (-1L), plotRenderingInfo17, point2D18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color1);
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.awt.Stroke stroke6 = null;
        intervalMarker5.setOutlineStroke(stroke6);
        org.jfree.chart.util.Layer layer8 = null;
        boolean boolean9 = categoryPlot0.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker5, layer8);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Font font8 = dateAxis4.getTickLabelFont();
        boolean boolean9 = dateAxis4.isAxisLineVisible();
        java.awt.Font font10 = dateAxis4.getTickLabelFont();
        java.awt.Shape shape11 = dateAxis4.getLeftArrow();
        java.util.TimeZone timeZone12 = null;
        try {
            dateAxis4.setTimeZone(timeZone12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        org.jfree.chart.plot.IntervalMarker intervalMarker28 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker28);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation30 = null;
        try {
            boolean boolean31 = xYPlot21.removeAnnotation(xYAnnotation30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.TOP;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.setLabelToolTip("hi!");
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis7);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot13.getDataset();
        boolean boolean15 = rectangleAnchor12.equals((java.lang.Object) categoryPlot13);
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_RED;
        categoryPlot13.setNoDataMessagePaint((java.awt.Paint) color16);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot18.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        dateAxis22.setLabelToolTip("hi!");
        int int25 = categoryPlot18.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis22);
        java.awt.Font font26 = dateAxis22.getTickLabelFont();
        java.awt.Color color30 = java.awt.Color.getHSBColor((float) '4', (float) 'a', (float) 0);
        dateAxis22.setTickMarkPaint((java.awt.Paint) color30);
        categoryPlot13.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis22);
        float float33 = categoryPlot13.getForegroundAlpha();
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        dateAxis36.setLabel("");
        dateAxis36.setTickLabelsVisible(false);
        dateAxis36.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot43.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis();
        dateAxis47.setLabel("");
        dateAxis47.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource52 = dateAxis47.getStandardTickUnits();
        boolean boolean53 = categoryPlot43.equals((java.lang.Object) dateAxis47);
        float float54 = dateAxis47.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer55 = null;
        org.jfree.chart.plot.XYPlot xYPlot56 = new org.jfree.chart.plot.XYPlot(xYDataset35, (org.jfree.chart.axis.ValueAxis) dateAxis36, (org.jfree.chart.axis.ValueAxis) dateAxis47, xYItemRenderer55);
        org.jfree.chart.axis.ValueAxis valueAxis58 = xYPlot56.getRangeAxis((int) (short) -1);
        java.awt.Paint paint59 = xYPlot56.getDomainCrosshairPaint();
        java.awt.Paint paint60 = xYPlot56.getRangeGridlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = xYPlot56.getRangeAxisEdge((-1));
        org.jfree.chart.axis.AxisSpace axisSpace63 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace64 = dateAxis7.reserveSpace(graphics2D11, (org.jfree.chart.plot.Plot) categoryPlot13, rectangle2D34, rectangleEdge62, axisSpace63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 1.0f + "'", float33 == 1.0f);
        org.junit.Assert.assertNotNull(tickUnitSource52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + float54 + "' != '" + 2.0f + "'", float54 == 2.0f);
        org.junit.Assert.assertNull(valueAxis58);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNotNull(rectangleEdge62);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        java.lang.Object obj6 = categoryPlot0.clone();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.setLabelToolTip("hi!");
        categoryPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis8, false);
        categoryPlot0.setNoDataMessage("");
        org.jfree.data.category.CategoryDataset categoryDataset16 = categoryPlot0.getDataset((int) (short) 10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = null;
        java.awt.geom.Point2D point2D26 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D24, rectangleAnchor25);
        categoryPlot21.zoomRangeAxes((double) (-1), plotRenderingInfo23, point2D26);
        categoryPlot21.setBackgroundImageAlpha((float) 0L);
        org.jfree.data.category.CategoryDataset categoryDataset30 = categoryPlot21.getDataset();
        categoryPlot21.mapDatasetToDomainAxis(0, (int) (byte) 100);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = null;
        java.awt.geom.Point2D point2D39 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D37, rectangleAnchor38);
        categoryPlot21.zoomDomainAxes((double) 1.0f, 0.05d, plotRenderingInfo36, point2D39);
        try {
            categoryPlot0.zoomRangeAxes(100.0d, 10.0d, plotRenderingInfo20, point2D39);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (10.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(categoryDataset16);
        org.junit.Assert.assertNotNull(point2D26);
        org.junit.Assert.assertNull(categoryDataset30);
        org.junit.Assert.assertNotNull(point2D39);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        java.lang.Object obj6 = categoryPlot0.clone();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.setLabelToolTip("hi!");
        categoryPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis8, false);
        categoryPlot0.setNoDataMessage("");
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot0.getRangeAxisEdge((int) (short) 1);
        org.jfree.chart.LegendItemCollection legendItemCollection17 = categoryPlot0.getFixedLegendItems();
        java.awt.Paint paint18 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNull(legendItemCollection17);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = null;
        java.awt.geom.Point2D point2D7 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D5, rectangleAnchor6);
        categoryPlot2.zoomRangeAxes((double) (-1), plotRenderingInfo4, point2D7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        dateAxis13.setLabelToolTip("hi!");
        int int16 = categoryPlot9.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis13);
        java.awt.Font font17 = dateAxis13.getTickLabelFont();
        categoryPlot2.setNoDataMessageFont(font17);
        boolean boolean19 = numberAxis1.equals((java.lang.Object) font17);
        org.jfree.data.RangeType rangeType20 = null;
        try {
            numberAxis1.setRangeType(rangeType20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        float float26 = xYPlot21.getBackgroundAlpha();
        java.awt.geom.Point2D point2D27 = null;
        try {
            xYPlot21.setQuadrantOrigin(point2D27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot21.zoomRangeAxes((double) (short) 100, plotRenderingInfo25, point2D26);
        xYPlot21.mapDatasetToRangeAxis(100, (-1));
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Font font8 = dateAxis4.getTickLabelFont();
        boolean boolean9 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAxisLineVisible(true);
        dateAxis4.setPositiveArrowVisible(true);
        float float14 = dateAxis4.getTickMarkOutsideLength();
        try {
            dateAxis4.setRange(0.0d, (double) (-14336));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 2.0f + "'", float14 == 2.0f);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        int int8 = categoryPlot0.getIndexOf(categoryItemRenderer7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        boolean boolean13 = categoryPlot0.render(graphics2D9, rectangle2D10, (int) '4', plotRenderingInfo12);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        org.jfree.chart.plot.IntervalMarker intervalMarker28 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        org.jfree.chart.util.Layer layer29 = null;
        xYPlot21.addRangeMarker((int) (byte) 10, (org.jfree.chart.plot.Marker) intervalMarker28, layer29);
        java.lang.Class class31 = null;
        try {
            java.util.EventListener[] eventListenerArray32 = intervalMarker28.getListeners(class31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Font font8 = dateAxis4.getTickLabelFont();
        java.awt.Color color12 = java.awt.Color.getHSBColor((float) '4', (float) 'a', (float) 0);
        dateAxis4.setTickMarkPaint((java.awt.Paint) color12);
        org.jfree.data.Range range14 = dateAxis4.getDefaultAutoRange();
        dateAxis4.setLabelToolTip("hi!");
        dateAxis4.centerRange((-1.0d));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(range14);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        dateAxis11.setLabelToolTip("hi!");
        int int14 = categoryPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Font font15 = dateAxis11.getTickLabelFont();
        categoryPlot0.setNoDataMessageFont(font15);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = categoryPlot0.getDomainMarkers(layer17);
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace19, false);
        java.awt.Stroke stroke22 = categoryPlot0.getRangeCrosshairStroke();
        categoryPlot0.clearRangeMarkers(1);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.setLabelToolTip("hi!");
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        dateAxis13.setLabel("");
        dateAxis13.setTickLabelsVisible(false);
        dateAxis13.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot20.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        dateAxis24.setLabel("");
        dateAxis24.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource29 = dateAxis24.getStandardTickUnits();
        boolean boolean30 = categoryPlot20.equals((java.lang.Object) dateAxis24);
        float float31 = dateAxis24.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis24, xYItemRenderer32);
        org.jfree.chart.axis.ValueAxis valueAxis35 = xYPlot33.getRangeAxis((int) (short) -1);
        java.awt.Paint paint36 = xYPlot33.getDomainCrosshairPaint();
        java.awt.Paint paint37 = xYPlot33.getRangeGridlinePaint();
        xYPlot33.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = xYPlot33.getRendererForDataset(xYDataset39);
        java.awt.Color color41 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        xYPlot33.setDomainGridlinePaint((java.awt.Paint) color41);
        java.awt.Color color43 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot33.setRangeTickBandPaint((java.awt.Paint) color43);
        org.jfree.chart.axis.AxisLocation axisLocation45 = xYPlot33.getRangeAxisLocation();
        categoryPlot0.setRangeAxisLocation(0, axisLocation45);
        org.jfree.chart.plot.CategoryMarker categoryMarker48 = null;
        org.jfree.chart.util.Layer layer49 = null;
        try {
            categoryPlot0.addDomainMarker((-1), categoryMarker48, layer49, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertNotNull(tickUnitSource29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 2.0f + "'", float31 == 2.0f);
        org.junit.Assert.assertNull(valueAxis35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNull(xYItemRenderer40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(axisLocation45);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        xYPlot21.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot21.getRendererForDataset(xYDataset27);
        xYPlot21.setRangeCrosshairValue(0.0d, false);
        org.jfree.chart.plot.Marker marker33 = null;
        org.jfree.chart.util.Layer layer34 = null;
        try {
            xYPlot21.addRangeMarker(255, marker33, layer34, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(xYItemRenderer28);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        xYPlot21.clearRangeAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker30 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.awt.Stroke stroke31 = null;
        intervalMarker30.setOutlineStroke(stroke31);
        java.awt.Stroke stroke33 = intervalMarker30.getOutlineStroke();
        org.jfree.chart.util.Layer layer34 = null;
        try {
            xYPlot21.addDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) intervalMarker30, layer34, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(stroke33);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        boolean boolean26 = xYPlot21.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = xYPlot21.getRangeAxisEdge();
        xYPlot21.setDomainCrosshairValue((double) (-1.0f));
        xYPlot21.mapDatasetToRangeAxis((-14336), (int) ' ');
        int int33 = xYPlot21.getSeriesCount();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setLabel("");
        java.awt.Paint paint3 = dateAxis0.getAxisLinePaint();
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        categoryPlot0.setRangeCrosshairValue((double) 0.0f);
        categoryPlot0.setBackgroundAlpha((float) (-14336));
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        categoryPlot13.zoomRangeAxes((double) (-1), plotRenderingInfo15, point2D18);
        org.jfree.chart.plot.PlotState plotState20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        try {
            categoryPlot0.draw(graphics2D11, rectangle2D12, point2D18, plotState20, plotRenderingInfo21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNotNull(point2D18);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        categoryPlot0.setDomainAxis(categoryAxis8);
        try {
            categoryPlot0.mapDatasetToDomainAxis((-14336), (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        boolean boolean26 = xYPlot21.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = xYPlot21.getRangeAxisEdge();
        xYPlot21.setDomainCrosshairValue((double) (-1.0f));
        xYPlot21.mapDatasetToRangeAxis((-14336), (int) ' ');
        java.awt.Color color33 = org.jfree.chart.ChartColor.DARK_BLUE;
        xYPlot21.setDomainGridlinePaint((java.awt.Paint) color33);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(color33);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = categoryPlot0.getDomainGridlinePosition();
        java.lang.String str7 = categoryAnchor6.toString();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str7.equals("CategoryAnchor.MIDDLE"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        categoryPlot0.mapDatasetToRangeAxis(2, (int) 'a');
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setLabel("");
        dateAxis0.resizeRange((double) (byte) 1, (double) (short) -1);
        try {
            dateAxis0.zoomRange(0.0d, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (-1.0) <= upper (-2.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setLabelToolTip("hi!");
        java.lang.String str3 = dateAxis0.getLabel();
        dateAxis0.setLabel("");
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        dateAxis6.setLabelToolTip("hi!");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition9 = dateAxis6.getTickMarkPosition();
        dateAxis0.setTickMarkPosition(dateTickMarkPosition9);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(dateTickMarkPosition9);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        xYPlot21.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot21.getRendererForDataset(xYDataset27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        xYPlot21.setDomainGridlinePaint((java.awt.Paint) color29);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot21.setRangeTickBandPaint((java.awt.Paint) color31);
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot35.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis39 = new org.jfree.chart.axis.DateAxis();
        dateAxis39.setLabelToolTip("hi!");
        int int42 = categoryPlot35.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis39);
        java.util.List list43 = categoryPlot35.getAnnotations();
        try {
            xYPlot21.drawRangeTickBands(graphics2D33, rectangle2D34, list43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(xYItemRenderer28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(list43);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Font font8 = dateAxis4.getTickLabelFont();
        boolean boolean9 = dateAxis4.isAxisLineVisible();
        java.awt.Font font10 = dateAxis4.getTickLabelFont();
        boolean boolean11 = dateAxis4.isAutoRange();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition12 = dateAxis4.getTickMarkPosition();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(dateTickMarkPosition12);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.lang.Object obj2 = defaultDrawingSupplier0.clone();
        java.awt.Paint paint3 = defaultDrawingSupplier0.getNextFillPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        java.lang.Object obj4 = categoryPlot0.clone();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot0.removeChangeListener(plotChangeListener5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        categoryPlot0.setDomainAxis(categoryAxis7);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent9 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace10);
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        java.awt.Color color1 = java.awt.Color.orange;
        boolean boolean2 = seriesRenderingOrder0.equals((java.lang.Object) color1);
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabel("");
        dateAxis4.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = dateAxis4.getStandardTickUnits();
        boolean boolean10 = categoryPlot0.equals((java.lang.Object) dateAxis4);
        float float11 = dateAxis4.getTickMarkOutsideLength();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        dateAxis4.setTickLabelPaint((java.awt.Paint) color12);
        boolean boolean14 = dateAxis4.isAxisLineVisible();
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 2.0f + "'", float11 == 2.0f);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        boolean boolean26 = xYPlot21.isRangeGridlinesVisible();
        int int27 = xYPlot21.getSeriesCount();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        try {
            numberAxis1.zoomRange((double) 10L, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (10.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            rectangleInsets0.trim(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        categoryPlot1.setDomainGridlinePaint((java.awt.Paint) color2);
        java.awt.Paint paint4 = categoryPlot1.getRangeCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        dateAxis6.setLabel("");
        dateAxis6.setTickLabelsVisible(false);
        dateAxis6.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.setLabel("");
        dateAxis17.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource22 = dateAxis17.getStandardTickUnits();
        boolean boolean23 = categoryPlot13.equals((java.lang.Object) dateAxis17);
        float float24 = dateAxis17.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) dateAxis6, (org.jfree.chart.axis.ValueAxis) dateAxis17, xYItemRenderer25);
        org.jfree.chart.axis.ValueAxis valueAxis28 = xYPlot26.getRangeAxis((int) (short) -1);
        java.awt.Paint paint29 = xYPlot26.getDomainCrosshairPaint();
        java.awt.Paint paint30 = xYPlot26.getRangeGridlinePaint();
        xYPlot26.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = xYPlot26.getRendererForDataset(xYDataset32);
        xYPlot26.setRangeCrosshairValue(0.0d, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset38 = categoryPlot37.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.data.Range range40 = categoryPlot37.getDataRange(valueAxis39);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray41 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot37.setRenderers(categoryItemRendererArray41);
        java.awt.Stroke stroke43 = categoryPlot37.getOutlineStroke();
        xYPlot26.setDomainZeroBaselineStroke(stroke43);
        java.awt.Color color45 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke46 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker48 = new org.jfree.chart.plot.ValueMarker((double) 0.0f, paint4, stroke43, (java.awt.Paint) color45, stroke46, (float) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(tickUnitSource22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + float24 + "' != '" + 2.0f + "'", float24 == 2.0f);
        org.junit.Assert.assertNull(valueAxis28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNull(xYItemRenderer33);
        org.junit.Assert.assertNull(categoryDataset38);
        org.junit.Assert.assertNull(range40);
        org.junit.Assert.assertNotNull(categoryItemRendererArray41);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(stroke46);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabel("");
        dateAxis4.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = dateAxis4.getStandardTickUnits();
        boolean boolean10 = categoryPlot0.equals((java.lang.Object) dateAxis4);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot0.setAxisOffset(rectangleInsets11);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D16 = rectangleInsets11.createOutsetRectangle(rectangle2D13, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabel("");
        dateAxis4.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = dateAxis4.getStandardTickUnits();
        boolean boolean10 = categoryPlot0.equals((java.lang.Object) dateAxis4);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot0.setAxisOffset(rectangleInsets11);
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D14 = rectangleInsets11.createOutsetRectangle(rectangle2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        float float26 = xYPlot21.getBackgroundAlpha();
        boolean boolean27 = xYPlot21.isDomainZoomable();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        boolean boolean6 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getDomainAxisEdge((-14336));
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot0.setRenderer(categoryItemRenderer9);
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setRangeGridlinesVisible(true);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        dateAxis5.setLabel("");
        dateAxis5.setTickLabelsVisible(false);
        dateAxis5.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setLabel("");
        dateAxis16.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource21 = dateAxis16.getStandardTickUnits();
        boolean boolean22 = categoryPlot12.equals((java.lang.Object) dateAxis16);
        float float23 = dateAxis16.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis16, xYItemRenderer24);
        float float26 = dateAxis16.getTickMarkOutsideLength();
        categoryPlot0.setRangeAxis((int) (byte) 10, (org.jfree.chart.axis.ValueAxis) dateAxis16);
        org.junit.Assert.assertNotNull(tickUnitSource21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 2.0f + "'", float23 == 2.0f);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 2.0f + "'", float26 == 2.0f);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        categoryPlot0.setForegroundAlpha((float) 4);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation8, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = categoryPlot0.getRenderer();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.setLabel("");
        dateAxis7.setTickLabelsVisible(false);
        dateAxis7.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        dateAxis18.setLabel("");
        dateAxis18.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource23 = dateAxis18.getStandardTickUnits();
        boolean boolean24 = categoryPlot14.equals((java.lang.Object) dateAxis18);
        float float25 = dateAxis18.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis18, xYItemRenderer26);
        org.jfree.chart.plot.IntervalMarker intervalMarker30 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot27.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker30);
        org.jfree.chart.plot.IntervalMarker intervalMarker34 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.awt.Stroke stroke35 = null;
        intervalMarker34.setOutlineStroke(stroke35);
        boolean boolean37 = xYPlot27.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker34);
        org.jfree.chart.util.Layer layer38 = null;
        categoryPlot0.addRangeMarker((int) 'a', (org.jfree.chart.plot.Marker) intervalMarker34, layer38, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot42.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        int int47 = categoryPlot42.getIndexOf(categoryItemRenderer46);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor48 = categoryPlot42.getDomainGridlinePosition();
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis();
        dateAxis49.setLabelToolTip("hi!");
        categoryPlot42.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis49);
        org.jfree.data.xy.XYDataset xYDataset54 = null;
        org.jfree.chart.axis.DateAxis dateAxis55 = new org.jfree.chart.axis.DateAxis();
        dateAxis55.setLabel("");
        dateAxis55.setTickLabelsVisible(false);
        dateAxis55.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot62.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis66 = new org.jfree.chart.axis.DateAxis();
        dateAxis66.setLabel("");
        dateAxis66.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource71 = dateAxis66.getStandardTickUnits();
        boolean boolean72 = categoryPlot62.equals((java.lang.Object) dateAxis66);
        float float73 = dateAxis66.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer74 = null;
        org.jfree.chart.plot.XYPlot xYPlot75 = new org.jfree.chart.plot.XYPlot(xYDataset54, (org.jfree.chart.axis.ValueAxis) dateAxis55, (org.jfree.chart.axis.ValueAxis) dateAxis66, xYItemRenderer74);
        org.jfree.chart.axis.ValueAxis valueAxis77 = xYPlot75.getRangeAxis((int) (short) -1);
        java.awt.Paint paint78 = xYPlot75.getDomainCrosshairPaint();
        java.awt.Paint paint79 = xYPlot75.getRangeGridlinePaint();
        xYPlot75.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset81 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer82 = xYPlot75.getRendererForDataset(xYDataset81);
        java.awt.Color color83 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        xYPlot75.setDomainGridlinePaint((java.awt.Paint) color83);
        java.awt.Color color85 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot75.setRangeTickBandPaint((java.awt.Paint) color85);
        org.jfree.chart.axis.AxisLocation axisLocation87 = xYPlot75.getRangeAxisLocation();
        categoryPlot42.setRangeAxisLocation(0, axisLocation87);
        try {
            categoryPlot0.setDomainAxisLocation((-14336), axisLocation87, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryItemRenderer4);
        org.junit.Assert.assertNotNull(tickUnitSource23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 2.0f + "'", float25 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor48);
        org.junit.Assert.assertNotNull(tickUnitSource71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + float73 + "' != '" + 2.0f + "'", float73 == 2.0f);
        org.junit.Assert.assertNull(valueAxis77);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertNotNull(paint79);
        org.junit.Assert.assertNull(xYItemRenderer82);
        org.junit.Assert.assertNotNull(color83);
        org.junit.Assert.assertNotNull(color85);
        org.junit.Assert.assertNotNull(axisLocation87);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        categoryPlot0.setRangeCrosshairValue((double) 0.0f);
        categoryPlot0.setBackgroundAlpha((float) (-14336));
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, 0.0d, (double) (-1L), 100.0d);
        double double16 = rectangleInsets15.getRight();
        double double18 = rectangleInsets15.trimWidth((double) (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset20 = categoryPlot19.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.data.Range range22 = categoryPlot19.getDataRange(valueAxis21);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray23 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot19.setRenderers(categoryItemRendererArray23);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray27 = new org.jfree.chart.axis.ValueAxis[] { dateAxis25, dateAxis26 };
        categoryPlot19.setRangeAxes(valueAxisArray27);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        categoryPlot19.zoomDomainAxes((double) 10L, (double) (byte) -1, plotRenderingInfo31, point2D32);
        boolean boolean34 = rectangleInsets15.equals((java.lang.Object) 10L);
        double double36 = rectangleInsets15.calculateTopOutset((double) (-14336));
        categoryPlot0.setInsets(rectangleInsets15, true);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.0d + "'", double16 == 100.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-101.0d) + "'", double18 == (-101.0d));
        org.junit.Assert.assertNull(categoryDataset20);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertNotNull(categoryItemRendererArray23);
        org.junit.Assert.assertNotNull(valueAxisArray27);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 10.0d + "'", double36 == 10.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        xYPlot21.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot21.getRendererForDataset(xYDataset27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        xYPlot21.setDomainGridlinePaint((java.awt.Paint) color29);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot21.setRangeTickBandPaint((java.awt.Paint) color31);
        org.jfree.chart.axis.AxisLocation axisLocation33 = xYPlot21.getRangeAxisLocation();
        java.awt.Paint paint34 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        xYPlot21.setDomainZeroBaselinePaint(paint34);
        org.jfree.chart.axis.AxisLocation axisLocation37 = null;
        try {
            xYPlot21.setRangeAxisLocation(0, axisLocation37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(xYItemRenderer28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        xYPlot21.clearRangeAxes();
        boolean boolean27 = xYPlot21.isDomainCrosshairVisible();
        org.jfree.chart.axis.AxisLocation axisLocation29 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        try {
            xYPlot21.setRangeAxisLocation((-29046), axisLocation29, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(axisLocation29);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Font font8 = dateAxis4.getTickLabelFont();
        boolean boolean9 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAxisLineVisible(true);
        dateAxis4.setPositiveArrowVisible(false);
        dateAxis4.setRange((double) (-1.0f), (double) 10.0f);
        dateAxis4.setUpperMargin(0.0d);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape20 = dateAxis19.getUpArrow();
        dateAxis4.setUpArrow(shape20);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(shape20);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset2 = categoryPlot1.getDataset();
        boolean boolean3 = rectangleAnchor0.equals((java.lang.Object) categoryPlot1);
        org.jfree.chart.util.SortOrder sortOrder4 = null;
        try {
            categoryPlot1.setRowRenderingOrder(sortOrder4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        int int3 = java.awt.Color.HSBtoRGB((float) 1L, (float) (byte) 1, (-1.0f));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16646144) + "'", int3 == (-16646144));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        dateAxis5.setLabel("");
        dateAxis5.setTickLabelsVisible(false);
        dateAxis5.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setLabel("");
        dateAxis16.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource21 = dateAxis16.getStandardTickUnits();
        boolean boolean22 = categoryPlot12.equals((java.lang.Object) dateAxis16);
        float float23 = dateAxis16.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) dateAxis5, (org.jfree.chart.axis.ValueAxis) dateAxis16, xYItemRenderer24);
        org.jfree.chart.plot.IntervalMarker intervalMarker28 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot25.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker28);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = xYPlot25.getRangeAxisEdge();
        try {
            double double31 = numberAxis1.java2DToValue((double) (short) 0, rectangle2D3, rectangleEdge30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 2.0f + "'", float23 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleEdge30);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        int int10 = categoryPlot0.getIndexOf(categoryItemRenderer9);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot1.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor7 = categoryPlot1.getDomainGridlinePosition();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot1.getIndexOf(categoryItemRenderer8);
        boolean boolean10 = objectList0.equals((java.lang.Object) categoryPlot1);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot1.getDomainAxisLocation((-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        int int19 = categoryPlot14.getIndexOf(categoryItemRenderer18);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor20 = categoryPlot14.getDomainGridlinePosition();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        dateAxis21.setLabelToolTip("hi!");
        categoryPlot14.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        dateAxis27.setLabel("");
        dateAxis27.setTickLabelsVisible(false);
        dateAxis27.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot34.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        dateAxis38.setLabel("");
        dateAxis38.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource43 = dateAxis38.getStandardTickUnits();
        boolean boolean44 = categoryPlot34.equals((java.lang.Object) dateAxis38);
        float float45 = dateAxis38.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot(xYDataset26, (org.jfree.chart.axis.ValueAxis) dateAxis27, (org.jfree.chart.axis.ValueAxis) dateAxis38, xYItemRenderer46);
        org.jfree.chart.axis.ValueAxis valueAxis49 = xYPlot47.getRangeAxis((int) (short) -1);
        java.awt.Paint paint50 = xYPlot47.getDomainCrosshairPaint();
        java.awt.Paint paint51 = xYPlot47.getRangeGridlinePaint();
        xYPlot47.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset53 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer54 = xYPlot47.getRendererForDataset(xYDataset53);
        java.awt.Color color55 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        xYPlot47.setDomainGridlinePaint((java.awt.Paint) color55);
        java.awt.Color color57 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot47.setRangeTickBandPaint((java.awt.Paint) color57);
        org.jfree.chart.axis.AxisLocation axisLocation59 = xYPlot47.getRangeAxisLocation();
        categoryPlot14.setRangeAxisLocation(0, axisLocation59);
        org.jfree.chart.axis.AxisLocation axisLocation61 = axisLocation59.getOpposite();
        categoryPlot1.setDomainAxisLocation(15, axisLocation61, false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor20);
        org.junit.Assert.assertNotNull(tickUnitSource43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + float45 + "' != '" + 2.0f + "'", float45 == 2.0f);
        org.junit.Assert.assertNull(valueAxis49);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNull(xYItemRenderer54);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(axisLocation59);
        org.junit.Assert.assertNotNull(axisLocation61);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 192 + "'", int1 == 192);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        xYPlot21.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot21.getRendererForDataset(xYDataset27);
        xYPlot21.setRangeCrosshairValue(0.0d, false);
        boolean boolean32 = xYPlot21.isDomainCrosshairLockedOnData();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation33 = null;
        try {
            xYPlot21.addAnnotation(xYAnnotation33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(xYItemRenderer28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = intervalMarker2.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = rectangleInsets3.createOutsetRectangle(rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Font font8 = dateAxis4.getTickLabelFont();
        boolean boolean9 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAxisLineVisible(true);
        dateAxis4.setPositiveArrowVisible(false);
        java.awt.Paint paint14 = null;
        try {
            dateAxis4.setTickMarkPaint(paint14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.awt.Color color0 = java.awt.Color.orange;
        int int1 = color0.getRGB();
        int int2 = color0.getAlpha();
        java.awt.Color color3 = color0.brighter();
        int int4 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-14336) + "'", int1 == (-14336));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, 0.0d, (double) (-1L), 100.0d);
        double double5 = rectangleInsets4.getRight();
        double double7 = rectangleInsets4.trimWidth((double) (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot8.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.data.Range range11 = categoryPlot8.getDataRange(valueAxis10);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray12 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot8.setRenderers(categoryItemRendererArray12);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray16 = new org.jfree.chart.axis.ValueAxis[] { dateAxis14, dateAxis15 };
        categoryPlot8.setRangeAxes(valueAxisArray16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot8.zoomDomainAxes((double) 10L, (double) (byte) -1, plotRenderingInfo20, point2D21);
        boolean boolean23 = rectangleInsets4.equals((java.lang.Object) 10L);
        double double25 = rectangleInsets4.calculateTopOutset((double) (-14336));
        double double27 = rectangleInsets4.trimHeight((double) 0.0f);
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D31 = rectangleInsets4.createInsetRectangle(rectangle2D28, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-101.0d) + "'", double7 == (-101.0d));
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray12);
        org.junit.Assert.assertNotNull(valueAxisArray16);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 10.0d + "'", double25 == 10.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + (-9.0d) + "'", double27 == (-9.0d));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        xYPlot21.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot21.getRendererForDataset(xYDataset27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        xYPlot21.setDomainGridlinePaint((java.awt.Paint) color29);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot21.setRangeTickBandPaint((java.awt.Paint) color31);
        org.jfree.chart.axis.AxisLocation axisLocation33 = xYPlot21.getRangeAxisLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        xYPlot21.setAxisOffset(rectangleInsets34);
        boolean boolean36 = xYPlot21.isDomainCrosshairVisible();
        java.awt.Stroke stroke37 = null;
        xYPlot21.setOutlineStroke(stroke37);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(xYItemRenderer28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        int int1 = objectList0.size();
        java.awt.Color color2 = java.awt.Color.BLUE;
        int int3 = objectList0.indexOf((java.lang.Object) color2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Font font8 = dateAxis4.getTickLabelFont();
        boolean boolean9 = dateAxis4.isAxisLineVisible();
        dateAxis4.resizeRange(0.2d, (double) 10L);
        java.util.TimeZone timeZone13 = null;
        try {
            dateAxis4.setTimeZone(timeZone13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) ' ', (double) 255, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        xYPlot21.setBackgroundAlpha((float) (byte) 10);
        java.awt.Paint paint27 = xYPlot21.getOutlinePaint();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset2 = categoryPlot1.getDataset();
        boolean boolean3 = rectangleAnchor0.equals((java.lang.Object) categoryPlot1);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_RED;
        categoryPlot1.setNoDataMessagePaint((java.awt.Paint) color4);
        int int6 = color4.getGreen();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 64 + "'", int6 == 64);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        org.jfree.chart.plot.IntervalMarker intervalMarker28 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        org.jfree.chart.util.Layer layer29 = null;
        xYPlot21.addRangeMarker((int) (byte) 10, (org.jfree.chart.plot.Marker) intervalMarker28, layer29);
        org.jfree.chart.text.TextAnchor textAnchor31 = intervalMarker28.getLabelTextAnchor();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = intervalMarker28.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D34 = rectangleInsets32.createInsetRectangle(rectangle2D33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(textAnchor31);
        org.junit.Assert.assertNotNull(rectangleInsets32);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.AxisSpace axisSpace22 = xYPlot21.getFixedDomainAxisSpace();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation23 = null;
        try {
            boolean boolean24 = xYPlot21.removeAnnotation(xYAnnotation23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(axisSpace22);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.AxisSpace axisSpace22 = xYPlot21.getFixedDomainAxisSpace();
        try {
            xYPlot21.setBackgroundImageAlpha((float) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(axisSpace22);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        java.awt.Stroke stroke7 = null;
        categoryPlot0.setOutlineStroke(stroke7);
        categoryPlot0.clearDomainMarkers();
        java.awt.Paint paint10 = categoryPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = xYPlot21.getDomainAxisEdge((int) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        xYPlot21.setRenderer((int) (short) 100, xYItemRenderer29, false);
        boolean boolean32 = xYPlot21.isOutlineVisible();
        org.jfree.data.xy.XYDataset xYDataset34 = xYPlot21.getDataset(0);
        xYPlot21.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNull(xYDataset34);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        java.awt.Stroke stroke7 = null;
        categoryPlot0.setOutlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace9, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setLabelToolTip("hi!");
        int int19 = categoryPlot12.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis16);
        java.awt.Font font20 = dateAxis16.getTickLabelFont();
        boolean boolean21 = dateAxis16.isAxisLineVisible();
        dateAxis16.setAxisLineVisible(true);
        dateAxis16.setPositiveArrowVisible(true);
        float float26 = dateAxis16.getTickMarkOutsideLength();
        int int27 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis16);
        org.jfree.data.Range range28 = dateAxis16.getDefaultAutoRange();
        dateAxis16.setTickMarkInsideLength(0.0f);
        double double31 = dateAxis16.getUpperMargin();
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 2.0f + "'", float26 == 2.0f);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.05d + "'", double31 == 0.05d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.setLabelToolTip("hi!");
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis7);
        dateAxis7.setLabelURL("RectangleAnchor.BOTTOM_LEFT");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType13 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        boolean boolean15 = lengthAdjustmentType13.equals((java.lang.Object) shape14);
        dateAxis7.setRightArrow(shape14);
        java.awt.Shape shape17 = dateAxis7.getLeftArrow();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertNotNull(lengthAdjustmentType13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(shape17);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("TextAnchor.TOP_RIGHT");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        java.lang.Object obj6 = categoryPlot0.clone();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.setLabelToolTip("hi!");
        categoryPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis8, false);
        categoryPlot0.setNoDataMessage("");
        org.jfree.data.category.CategoryDataset categoryDataset16 = categoryPlot0.getDataset((int) (short) 10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType18 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        plotChangeEvent17.setType(chartChangeEventType18);
        java.lang.String str20 = chartChangeEventType18.toString();
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(categoryDataset16);
        org.junit.Assert.assertNotNull(chartChangeEventType18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str20.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = intervalMarker2.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = rectangleInsets3.createInsetRectangle(rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = dateAxis0.getRange();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = null;
        try {
            dateAxis0.setLabelInsets(rectangleInsets2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        java.awt.Stroke stroke22 = xYPlot21.getDomainCrosshairStroke();
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        xYPlot21.setFixedRangeAxisSpace(axisSpace23, false);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        categoryPlot0.setBackgroundImageAlpha((float) 0L);
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot0.getDataset();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot0.setRenderer(0, categoryItemRenderer11, false);
        java.lang.String str14 = categoryPlot0.getPlotType();
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Category Plot" + "'", str14.equals("Category Plot"));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        xYPlot21.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot21.getRendererForDataset(xYDataset27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        xYPlot21.setDomainGridlinePaint((java.awt.Paint) color29);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot21.setRangeTickBandPaint((java.awt.Paint) color31);
        org.jfree.chart.axis.AxisLocation axisLocation33 = xYPlot21.getRangeAxisLocation();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation34 = null;
        try {
            boolean boolean36 = xYPlot21.removeAnnotation(xYAnnotation34, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(xYItemRenderer28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(axisLocation33);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        xYPlot21.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot21.getRendererForDataset(xYDataset27);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot21.getDomainAxisEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset32 = categoryPlot31.getDataset();
        boolean boolean33 = rectangleAnchor30.equals((java.lang.Object) categoryPlot31);
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_RED;
        categoryPlot31.setNoDataMessagePaint((java.awt.Paint) color34);
        xYPlot21.setDomainCrosshairPaint((java.awt.Paint) color34);
        java.awt.Stroke stroke37 = null;
        try {
            xYPlot21.setDomainCrosshairStroke(stroke37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(xYItemRenderer28);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNull(categoryDataset32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(color34);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 192 + "'", int1 == 192);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getUpArrow();
        dateAxis0.setLabelAngle((double) 0.0f);
        dateAxis0.setUpperBound((double) (byte) 10);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        dateAxis6.setLabel("");
        dateAxis6.setTickLabelsVisible(false);
        dateAxis6.setAutoRange(false);
        dateAxis6.zoomRange((double) (short) -1, (double) (short) 10);
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis6.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        dateAxis0.setRangeWithMargins((org.jfree.data.Range) dateRange16, false, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = null;
        java.awt.geom.Point2D point2D26 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D24, rectangleAnchor25);
        categoryPlot21.zoomRangeAxes((double) (-1), plotRenderingInfo23, point2D26);
        java.awt.Stroke stroke28 = null;
        categoryPlot21.setOutlineStroke(stroke28);
        org.jfree.chart.axis.AxisSpace axisSpace30 = null;
        categoryPlot21.setFixedRangeAxisSpace(axisSpace30, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot33.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        dateAxis37.setLabelToolTip("hi!");
        int int40 = categoryPlot33.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis37);
        java.awt.Font font41 = dateAxis37.getTickLabelFont();
        boolean boolean42 = dateAxis37.isAxisLineVisible();
        dateAxis37.setAxisLineVisible(true);
        dateAxis37.setPositiveArrowVisible(true);
        float float47 = dateAxis37.getTickMarkOutsideLength();
        int int48 = categoryPlot21.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis37);
        org.jfree.data.Range range49 = dateAxis37.getDefaultAutoRange();
        dateAxis0.setRangeWithMargins(range49);
        boolean boolean51 = dateAxis0.isAutoRange();
        org.jfree.chart.plot.Plot plot52 = dateAxis0.getPlot();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertNotNull(point2D26);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + float47 + "' != '" + 2.0f + "'", float47 == 2.0f);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(range49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(plot52);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = categoryPlot0.getDomainGridlinePosition();
        categoryPlot0.setRangeCrosshairValue((double) 100L, false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor6);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        categoryPlot0.setBackgroundImageAlpha((float) 0L);
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot0.getDataset();
        categoryPlot0.mapDatasetToDomainAxis(0, (int) (byte) 100);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        categoryPlot0.zoomDomainAxes((double) 1.0f, 0.05d, plotRenderingInfo15, point2D18);
        int int20 = categoryPlot0.getWeight();
        java.awt.Paint paint21 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot0.getDomainAxisForDataset((int) (short) 10);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(categoryAxis23);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        boolean boolean26 = xYPlot21.isRangeGridlinesVisible();
        xYPlot21.clearRangeAxes();
        xYPlot21.setRangeGridlinesVisible(true);
        float float30 = xYPlot21.getBackgroundImageAlpha();
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        try {
            xYPlot21.drawOutline(graphics2D31, rectangle2D32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.5f + "'", float30 == 0.5f);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getUpArrow();
        dateAxis0.setLabelAngle((double) 0.0f);
        dateAxis0.setUpperBound((double) (byte) 10);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint7 = defaultDrawingSupplier6.getNextPaint();
        java.awt.Paint paint8 = defaultDrawingSupplier6.getNextFillPaint();
        dateAxis0.setTickMarkPaint(paint8);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot21.getRangeAxisEdge();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot21.getRenderer((int) (byte) 0);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNull(xYItemRenderer28);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        org.jfree.chart.plot.IntervalMarker intervalMarker28 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker28);
        java.awt.Paint paint30 = null;
        try {
            xYPlot21.setDomainCrosshairPaint(paint30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        java.awt.Color color1 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        int int8 = categoryPlot0.getIndexOf(categoryItemRenderer7);
        java.awt.Paint paint9 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getDomainAxisLocation();
        java.awt.Paint paint11 = categoryPlot0.getNoDataMessagePaint();
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        float[] floatArray3 = null;
        float[] floatArray4 = java.awt.Color.RGBtoHSB(64, (int) (short) 100, 7, floatArray3);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = null;
        try {
            categoryPlot0.setColumnRenderingOrder(sortOrder1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextFillPaint();
        java.awt.Shape shape2 = defaultDrawingSupplier0.getNextShape();
        java.awt.Shape shape3 = defaultDrawingSupplier0.getNextShape();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { dateAxis6, dateAxis7 };
        categoryPlot0.setRangeAxes(valueAxisArray8);
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryPlot0.setNoDataMessageFont(font10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryPlot0.getAxisOffset();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        int int14 = categoryPlot0.getIndexOf(categoryItemRenderer13);
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.util.List list8 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxis(100);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        categoryPlot0.addChangeListener(plotChangeListener11);
        categoryPlot0.setBackgroundImageAlignment(0);
        categoryPlot0.setOutlineVisible(false);
        categoryPlot0.setBackgroundImageAlpha((float) 0L);
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection21 = categoryPlot0.getDomainMarkers(0, layer20);
        org.jfree.chart.plot.Marker marker22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot23.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        dateAxis27.setLabelToolTip("hi!");
        int int30 = categoryPlot23.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis27);
        java.util.List list31 = categoryPlot23.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = categoryPlot23.getDomainAxis(100);
        org.jfree.chart.event.PlotChangeListener plotChangeListener34 = null;
        categoryPlot23.addChangeListener(plotChangeListener34);
        categoryPlot23.setBackgroundImageAlignment(0);
        categoryPlot23.setOutlineVisible(false);
        categoryPlot23.setBackgroundImageAlpha((float) 0L);
        org.jfree.chart.util.Layer layer43 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection44 = categoryPlot23.getDomainMarkers(0, layer43);
        try {
            categoryPlot0.addRangeMarker(marker22, layer43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertNull(categoryAxis33);
        org.junit.Assert.assertNotNull(layer43);
        org.junit.Assert.assertNull(collection44);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Paint paint2 = defaultDrawingSupplier0.getNextPaint();
        java.awt.Paint paint3 = defaultDrawingSupplier0.getNextFillPaint();
        java.awt.Paint paint4 = defaultDrawingSupplier0.getNextFillPaint();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot1.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        int int6 = categoryPlot1.getIndexOf(categoryItemRenderer5);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor7 = categoryPlot1.getDomainGridlinePosition();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        int int9 = categoryPlot1.getIndexOf(categoryItemRenderer8);
        java.awt.Paint paint10 = categoryPlot1.getOutlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot1.getDomainAxisLocation();
        boolean boolean12 = datasetRenderingOrder0.equals((java.lang.Object) axisLocation11);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot21.zoomRangeAxes((double) (short) 100, plotRenderingInfo25, point2D26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = null;
        xYPlot21.setDomainAxisLocation((int) (byte) 100, axisLocation29);
        java.awt.Paint paint31 = xYPlot21.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.axis.ValueAxis valueAxis34 = xYPlot21.getDomainAxis();
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot36.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis();
        dateAxis40.setLabelToolTip("hi!");
        int int43 = categoryPlot36.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis40);
        java.util.List list44 = categoryPlot36.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = categoryPlot36.getDomainAxis(100);
        org.jfree.chart.event.PlotChangeListener plotChangeListener47 = null;
        categoryPlot36.addChangeListener(plotChangeListener47);
        categoryPlot36.setBackgroundImageAlignment(0);
        java.lang.String str51 = categoryPlot36.getPlotType();
        categoryPlot36.setAnchorValue((double) 1);
        org.jfree.data.xy.XYDataset xYDataset55 = null;
        org.jfree.chart.axis.DateAxis dateAxis56 = new org.jfree.chart.axis.DateAxis();
        dateAxis56.setLabel("");
        dateAxis56.setTickLabelsVisible(false);
        dateAxis56.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot63 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot63.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis67 = new org.jfree.chart.axis.DateAxis();
        dateAxis67.setLabel("");
        dateAxis67.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource72 = dateAxis67.getStandardTickUnits();
        boolean boolean73 = categoryPlot63.equals((java.lang.Object) dateAxis67);
        float float74 = dateAxis67.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer75 = null;
        org.jfree.chart.plot.XYPlot xYPlot76 = new org.jfree.chart.plot.XYPlot(xYDataset55, (org.jfree.chart.axis.ValueAxis) dateAxis56, (org.jfree.chart.axis.ValueAxis) dateAxis67, xYItemRenderer75);
        org.jfree.chart.axis.ValueAxis valueAxis78 = xYPlot76.getRangeAxis((int) (short) -1);
        java.awt.Paint paint79 = xYPlot76.getDomainCrosshairPaint();
        java.awt.Paint paint80 = xYPlot76.getRangeGridlinePaint();
        xYPlot76.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset82 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer83 = xYPlot76.getRendererForDataset(xYDataset82);
        java.awt.Color color84 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        xYPlot76.setDomainGridlinePaint((java.awt.Paint) color84);
        java.awt.Color color86 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot76.setRangeTickBandPaint((java.awt.Paint) color86);
        org.jfree.chart.axis.AxisLocation axisLocation88 = xYPlot76.getRangeAxisLocation();
        categoryPlot36.setRangeAxisLocation(100, axisLocation88);
        try {
            xYPlot21.setRangeAxisLocation((int) (byte) -1, axisLocation88, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(valueAxis34);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(list44);
        org.junit.Assert.assertNull(categoryAxis46);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "Category Plot" + "'", str51.equals("Category Plot"));
        org.junit.Assert.assertNotNull(tickUnitSource72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + float74 + "' != '" + 2.0f + "'", float74 == 2.0f);
        org.junit.Assert.assertNull(valueAxis78);
        org.junit.Assert.assertNotNull(paint79);
        org.junit.Assert.assertNotNull(paint80);
        org.junit.Assert.assertNull(xYItemRenderer83);
        org.junit.Assert.assertNotNull(color84);
        org.junit.Assert.assertNotNull(color86);
        org.junit.Assert.assertNotNull(axisLocation88);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Font font8 = dateAxis4.getTickLabelFont();
        boolean boolean9 = dateAxis4.isAxisLineVisible();
        dateAxis4.resizeRange(0.2d, (double) 10L);
        boolean boolean13 = dateAxis4.isNegativeArrowVisible();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        xYPlot21.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot21.getRendererForDataset(xYDataset27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        xYPlot21.setDomainGridlinePaint((java.awt.Paint) color29);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot21.setRangeTickBandPaint((java.awt.Paint) color31);
        org.jfree.chart.axis.AxisLocation axisLocation33 = xYPlot21.getRangeAxisLocation();
        org.jfree.chart.plot.PlotOrientation plotOrientation34 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge35 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation33, plotOrientation34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(xYItemRenderer28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(axisLocation33);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        xYPlot21.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot21.getRendererForDataset(xYDataset27);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot21.getDomainAxisEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset32 = categoryPlot31.getDataset();
        boolean boolean33 = rectangleAnchor30.equals((java.lang.Object) categoryPlot31);
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_RED;
        categoryPlot31.setNoDataMessagePaint((java.awt.Paint) color34);
        xYPlot21.setDomainCrosshairPaint((java.awt.Paint) color34);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, 0.0d, (double) (-1L), 100.0d);
        xYPlot21.setAxisOffset(rectangleInsets41);
        java.awt.Paint paint43 = xYPlot21.getDomainCrosshairPaint();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(xYItemRenderer28);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNull(categoryDataset32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(paint43);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        xYPlot21.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot21.getRendererForDataset(xYDataset27);
        xYPlot21.setRangeCrosshairValue(0.0d, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = xYPlot21.getDomainAxis(100);
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        try {
            xYPlot21.drawOutline(graphics2D34, rectangle2D35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(xYItemRenderer28);
        org.junit.Assert.assertNull(valueAxis33);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        boolean boolean26 = xYPlot21.isRangeGridlinesVisible();
        xYPlot21.clearRangeAxes();
        java.awt.Paint paint28 = xYPlot21.getRangeCrosshairPaint();
        java.lang.String str29 = xYPlot21.getPlotType();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "XY Plot" + "'", str29.equals("XY Plot"));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset2 = categoryPlot1.getDataset();
        boolean boolean3 = rectangleAnchor0.equals((java.lang.Object) categoryPlot1);
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_RED;
        categoryPlot1.setNoDataMessagePaint((java.awt.Paint) color4);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        dateAxis10.setLabelToolTip("hi!");
        int int13 = categoryPlot6.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis10);
        java.awt.Font font14 = dateAxis10.getTickLabelFont();
        java.awt.Color color18 = java.awt.Color.getHSBColor((float) '4', (float) 'a', (float) 0);
        dateAxis10.setTickMarkPaint((java.awt.Paint) color18);
        categoryPlot1.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis10);
        dateAxis10.setFixedAutoRange((double) (short) 100);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot21.zoomRangeAxes((double) (short) 100, plotRenderingInfo25, point2D26);
        int int28 = xYPlot21.getBackgroundImageAlignment();
        org.jfree.chart.plot.IntervalMarker intervalMarker31 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor32 = intervalMarker31.getLabelAnchor();
        java.awt.Stroke stroke33 = intervalMarker31.getStroke();
        xYPlot21.setRangeGridlineStroke(stroke33);
        org.jfree.data.xy.XYDataset xYDataset36 = xYPlot21.getDataset((-29046));
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 15 + "'", int28 == 15);
        org.junit.Assert.assertNotNull(rectangleAnchor32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNull(xYDataset36);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setLabelToolTip("hi!");
        java.lang.String str3 = dateAxis0.getLabel();
        dateAxis0.setAutoRangeMinimumSize((double) 1);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Font font8 = dateAxis4.getTickLabelFont();
        boolean boolean9 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAxisLineVisible(true);
        dateAxis4.setPositiveArrowVisible(false);
        dateAxis4.setRangeWithMargins((double) (-14336), (double) '#');
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        dateAxis17.setLabelToolTip("hi!");
        java.lang.String str20 = dateAxis17.getLabel();
        java.awt.Paint paint21 = dateAxis17.getTickLabelPaint();
        java.awt.Shape shape22 = dateAxis17.getRightArrow();
        dateAxis4.setUpArrow(shape22);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(shape22);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        dateAxis11.setLabelToolTip("hi!");
        int int14 = categoryPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Font font15 = dateAxis11.getTickLabelFont();
        categoryPlot0.setNoDataMessageFont(font15);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = categoryPlot0.getDomainMarkers(layer17);
        java.awt.Font font19 = categoryPlot0.getNoDataMessageFont();
        java.awt.Color color20 = java.awt.Color.YELLOW;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color20);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        java.awt.Color color3 = java.awt.Color.BLUE;
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.color.ColorSpace colorSpace5 = color4.getColorSpace();
        float[] floatArray14 = new float[] { (-1.0f), (short) 100, (byte) -1, (short) 0, (byte) -1 };
        float[] floatArray15 = java.awt.Color.RGBtoHSB((int) (short) 1, (int) (byte) 0, 0, floatArray14);
        float[] floatArray16 = color3.getColorComponents(colorSpace5, floatArray15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        java.awt.Color color19 = java.awt.Color.BLUE;
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.color.ColorSpace colorSpace21 = color20.getColorSpace();
        float[] floatArray30 = new float[] { (-1.0f), (short) 100, (byte) -1, (short) 0, (byte) -1 };
        float[] floatArray31 = java.awt.Color.RGBtoHSB((int) (short) 1, (int) (byte) 0, 0, floatArray30);
        float[] floatArray32 = color19.getColorComponents(colorSpace21, floatArray31);
        float[] floatArray33 = color3.getComponents(colorSpace18, floatArray32);
        float[] floatArray34 = java.awt.Color.RGBtoHSB(192, 0, 0, floatArray32);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(colorSpace21);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertNotNull(floatArray32);
        org.junit.Assert.assertNotNull(floatArray33);
        org.junit.Assert.assertNotNull(floatArray34);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        java.awt.Paint paint6 = categoryPlot0.getDomainGridlinePaint();
        boolean boolean7 = categoryPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        boolean boolean26 = xYPlot21.isRangeGridlinesVisible();
        xYPlot21.clearRangeAxes();
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        org.jfree.chart.plot.CrosshairState crosshairState32 = null;
        boolean boolean33 = xYPlot21.render(graphics2D28, rectangle2D29, 15, plotRenderingInfo31, crosshairState32);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        boolean boolean10 = categoryPlot0.render(graphics2D6, rectangle2D7, (int) ' ', plotRenderingInfo9);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = null;
        categoryPlot0.axisChanged(axisChangeEvent11);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.JFreeChart jFreeChart14 = null;
        plotChangeEvent13.setChart(jFreeChart14);
        org.jfree.chart.plot.Plot plot16 = plotChangeEvent13.getPlot();
        org.jfree.chart.JFreeChart jFreeChart17 = null;
        plotChangeEvent13.setChart(jFreeChart17);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(plot16);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Font font8 = dateAxis4.getTickLabelFont();
        boolean boolean9 = dateAxis4.isAxisLineVisible();
        java.awt.Font font10 = dateAxis4.getTickLabelFont();
        java.awt.Shape shape11 = dateAxis4.getLeftArrow();
        java.awt.Stroke stroke12 = dateAxis4.getAxisLineStroke();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabel("");
        dateAxis4.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = dateAxis4.getStandardTickUnits();
        boolean boolean10 = categoryPlot0.equals((java.lang.Object) dateAxis4);
        dateAxis4.setUpperBound((double) 0.0f);
        boolean boolean13 = dateAxis4.isTickMarksVisible();
        dateAxis4.setRangeAboutValue((double) 'a', (double) 64);
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = dateAxis0.getRange();
        dateAxis0.setUpperBound((double) '#');
        boolean boolean4 = dateAxis0.isAutoRange();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.setLabel("");
        dateAxis8.setTickLabelsVisible(false);
        dateAxis8.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        dateAxis19.setLabel("");
        dateAxis19.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource24 = dateAxis19.getStandardTickUnits();
        boolean boolean25 = categoryPlot15.equals((java.lang.Object) dateAxis19);
        float float26 = dateAxis19.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer27);
        org.jfree.chart.axis.ValueAxis valueAxis30 = xYPlot28.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        xYPlot28.zoomRangeAxes((double) (short) 100, plotRenderingInfo32, point2D33);
        org.jfree.chart.axis.AxisLocation axisLocation36 = null;
        xYPlot28.setDomainAxisLocation((int) (byte) 100, axisLocation36);
        java.awt.Paint paint38 = xYPlot28.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = xYPlot28.getRangeAxisEdge(0);
        try {
            double double41 = dateAxis0.lengthToJava2D(259.0d, rectangle2D6, rectangleEdge40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(tickUnitSource24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 2.0f + "'", float26 == 2.0f);
        org.junit.Assert.assertNull(valueAxis30);
        org.junit.Assert.assertNull(paint38);
        org.junit.Assert.assertNotNull(rectangleEdge40);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset5 = categoryPlot4.getDataset();
        boolean boolean6 = rectangleAnchor3.equals((java.lang.Object) categoryPlot4);
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 2.0f, 10.0d, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertNull(categoryDataset5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        java.awt.Stroke stroke6 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.JFreeChart jFreeChart7 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot0, jFreeChart7);
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        java.lang.String str1 = lengthAdjustmentType0.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CONTRACT" + "'", str1.equals("CONTRACT"));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot21.zoomRangeAxes((double) (short) 100, plotRenderingInfo25, point2D26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = null;
        xYPlot21.setDomainAxisLocation((int) (byte) 100, axisLocation29);
        java.awt.Paint paint31 = xYPlot21.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.axis.ValueAxis valueAxis34 = xYPlot21.getDomainAxis();
        valueAxis34.setTickLabelsVisible(false);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(valueAxis34);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset2 = categoryPlot1.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.data.Range range4 = categoryPlot1.getDataRange(valueAxis3);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray5 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot1.setRenderers(categoryItemRendererArray5);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray9 = new org.jfree.chart.axis.ValueAxis[] { dateAxis7, dateAxis8 };
        categoryPlot1.setRangeAxes(valueAxisArray9);
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryPlot1.setNoDataMessageFont(font11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("CategoryAnchor.MIDDLE");
        categoryPlot1.setDomainAxis(categoryAxis14);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        dateAxis20.setLabelToolTip("hi!");
        int int23 = categoryPlot16.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis20);
        java.awt.Font font24 = dateAxis20.getTickLabelFont();
        boolean boolean25 = dateAxis20.isAxisLineVisible();
        dateAxis20.setAxisLineVisible(true);
        dateAxis20.setPositiveArrowVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, categoryItemRenderer30);
        java.awt.Paint paint32 = null;
        try {
            categoryPlot31.setDomainGridlinePaint(paint32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(categoryItemRendererArray5);
        org.junit.Assert.assertNotNull(valueAxisArray9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        java.awt.Paint paint6 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        int int14 = categoryPlot9.getIndexOf(categoryItemRenderer13);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        boolean boolean19 = categoryPlot9.render(graphics2D15, rectangle2D16, (int) ' ', plotRenderingInfo18);
        int int20 = categoryPlot9.getRangeAxisCount();
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.awt.Stroke stroke25 = null;
        intervalMarker24.setOutlineStroke(stroke25);
        java.awt.Stroke stroke27 = intervalMarker24.getOutlineStroke();
        java.awt.Font font28 = intervalMarker24.getLabelFont();
        org.jfree.chart.util.Layer layer29 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean31 = categoryPlot9.removeRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker24, layer29, true);
        try {
            categoryPlot0.addDomainMarker((int) (byte) 0, categoryMarker8, layer29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNull(stroke27);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(layer29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-192) + "'", int1 == (-192));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.awt.Color color1 = java.awt.Color.orange;
        int int2 = color1.getRGB();
        int int3 = color1.getAlpha();
        java.awt.Color color4 = java.awt.Color.getColor("RectangleAnchor.BOTTOM_LEFT", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-14336) + "'", int2 == (-14336));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        org.jfree.chart.plot.IntervalMarker intervalMarker28 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.awt.Stroke stroke29 = null;
        intervalMarker28.setOutlineStroke(stroke29);
        boolean boolean31 = xYPlot21.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker28);
        java.awt.Stroke stroke32 = intervalMarker28.getOutlineStroke();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(stroke32);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, 0.0d, (double) (-1L), 100.0d);
        double double5 = rectangleInsets4.getRight();
        double double7 = rectangleInsets4.trimWidth((double) (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot8.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.data.Range range11 = categoryPlot8.getDataRange(valueAxis10);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray12 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot8.setRenderers(categoryItemRendererArray12);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray16 = new org.jfree.chart.axis.ValueAxis[] { dateAxis14, dateAxis15 };
        categoryPlot8.setRangeAxes(valueAxisArray16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot8.zoomDomainAxes((double) 10L, (double) (byte) -1, plotRenderingInfo20, point2D21);
        boolean boolean23 = rectangleInsets4.equals((java.lang.Object) 10L);
        double double25 = rectangleInsets4.calculateTopOutset((double) (-14336));
        double double26 = rectangleInsets4.getRight();
        double double28 = rectangleInsets4.calculateBottomOutset(0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-101.0d) + "'", double7 == (-101.0d));
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray12);
        org.junit.Assert.assertNotNull(valueAxisArray16);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 10.0d + "'", double25 == 10.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 100.0d + "'", double26 == 100.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + (-1.0d) + "'", double28 == (-1.0d));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.awt.Stroke stroke9 = null;
        intervalMarker8.setOutlineStroke(stroke9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        dateAxis15.setLabelToolTip("hi!");
        int int18 = categoryPlot11.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis15);
        java.util.List list19 = categoryPlot11.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = categoryPlot11.getDomainAxis(100);
        org.jfree.chart.event.PlotChangeListener plotChangeListener22 = null;
        categoryPlot11.addChangeListener(plotChangeListener22);
        categoryPlot11.setBackgroundImageAlignment(0);
        categoryPlot11.setOutlineVisible(false);
        categoryPlot11.setBackgroundImageAlpha((float) 0L);
        org.jfree.chart.util.Layer layer31 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection32 = categoryPlot11.getDomainMarkers(0, layer31);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker8, layer31);
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        dateAxis35.setLabel("");
        dateAxis35.setTickLabelsVisible(false);
        dateAxis35.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot42.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis46 = new org.jfree.chart.axis.DateAxis();
        dateAxis46.setLabel("");
        dateAxis46.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource51 = dateAxis46.getStandardTickUnits();
        boolean boolean52 = categoryPlot42.equals((java.lang.Object) dateAxis46);
        float float53 = dateAxis46.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer54 = null;
        org.jfree.chart.plot.XYPlot xYPlot55 = new org.jfree.chart.plot.XYPlot(xYDataset34, (org.jfree.chart.axis.ValueAxis) dateAxis35, (org.jfree.chart.axis.ValueAxis) dateAxis46, xYItemRenderer54);
        org.jfree.chart.axis.ValueAxis valueAxis57 = xYPlot55.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = null;
        java.awt.geom.Point2D point2D60 = null;
        xYPlot55.zoomRangeAxes((double) (short) 100, plotRenderingInfo59, point2D60);
        org.jfree.chart.axis.AxisLocation axisLocation63 = null;
        xYPlot55.setDomainAxisLocation((int) (byte) 100, axisLocation63);
        java.awt.Paint paint65 = xYPlot55.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge67 = xYPlot55.getRangeAxisEdge(0);
        org.jfree.chart.axis.ValueAxis valueAxis68 = xYPlot55.getDomainAxis();
        org.jfree.chart.plot.IntervalMarker intervalMarker72 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor73 = intervalMarker72.getLabelAnchor();
        java.awt.Stroke stroke74 = intervalMarker72.getStroke();
        org.jfree.chart.util.Layer layer75 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean77 = xYPlot55.removeRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker72, layer75, false);
        java.awt.Stroke stroke78 = xYPlot55.getDomainGridlineStroke();
        intervalMarker8.setOutlineStroke(stroke78);
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNull(categoryAxis21);
        org.junit.Assert.assertNotNull(layer31);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(tickUnitSource51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + float53 + "' != '" + 2.0f + "'", float53 == 2.0f);
        org.junit.Assert.assertNull(valueAxis57);
        org.junit.Assert.assertNull(paint65);
        org.junit.Assert.assertNotNull(rectangleEdge67);
        org.junit.Assert.assertNotNull(valueAxis68);
        org.junit.Assert.assertNotNull(rectangleAnchor73);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(layer75);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(stroke78);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        float[] floatArray14 = new float[] { (-1.0f), (short) 100, (byte) -1, (short) 0, (byte) -1 };
        float[] floatArray15 = java.awt.Color.RGBtoHSB((int) (short) 1, (int) (byte) 0, 0, floatArray14);
        float[] floatArray16 = java.awt.Color.RGBtoHSB(1, (int) (short) 1, 0, floatArray15);
        float[] floatArray17 = java.awt.Color.RGBtoHSB(100, 4, (-29046), floatArray15);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setLabelToolTip("hi!");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = dateAxis0.getTickMarkPosition();
        dateAxis0.setTickMarkOutsideLength((float) 64);
        org.jfree.chart.axis.Timeline timeline6 = null;
        dateAxis0.setTimeline(timeline6);
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, 0.0d, (double) (-1L), 100.0d);
        double double6 = rectangleInsets4.calculateRightOutset((double) (byte) 10);
        double double8 = rectangleInsets4.calculateRightInset((double) (-1.0f));
        double double9 = rectangleInsets4.getRight();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            rectangleInsets4.trim(rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot21.zoomRangeAxes((double) (short) 100, plotRenderingInfo25, point2D26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = null;
        xYPlot21.setDomainAxisLocation((int) (byte) 100, axisLocation29);
        java.awt.Paint paint31 = xYPlot21.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.axis.ValueAxis valueAxis34 = xYPlot21.getDomainAxis();
        org.jfree.chart.plot.IntervalMarker intervalMarker38 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = intervalMarker38.getLabelAnchor();
        java.awt.Stroke stroke40 = intervalMarker38.getStroke();
        org.jfree.chart.util.Layer layer41 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean43 = xYPlot21.removeRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker38, layer41, false);
        java.awt.Stroke stroke44 = xYPlot21.getDomainGridlineStroke();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        try {
            xYPlot21.setRenderer((-29046), xYItemRenderer46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(valueAxis34);
        org.junit.Assert.assertNotNull(rectangleAnchor39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(layer41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(stroke44);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.RangeType rangeType3 = numberAxis2.getRangeType();
        numberAxis0.setRangeType(rangeType3);
        numberAxis0.setAutoRangeIncludesZero(false);
        org.junit.Assert.assertNotNull(rangeType3);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        int int2 = color1.getTransparency();
        boolean boolean3 = datasetRenderingOrder0.equals((java.lang.Object) int2);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        java.awt.Stroke stroke4 = null;
        categoryPlot0.setOutlineStroke(stroke4);
        org.jfree.chart.util.SortOrder sortOrder6 = null;
        try {
            categoryPlot0.setRowRenderingOrder(sortOrder6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        boolean boolean10 = categoryPlot0.render(graphics2D6, rectangle2D7, (int) ' ', plotRenderingInfo9);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = null;
        categoryPlot0.axisChanged(axisChangeEvent11);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.JFreeChart jFreeChart14 = null;
        plotChangeEvent13.setChart(jFreeChart14);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = plotChangeEvent13.getType();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType16);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint2 = defaultDrawingSupplier1.getNextPaint();
        java.awt.Paint paint3 = defaultDrawingSupplier1.getNextFillPaint();
        int int4 = day0.compareTo((java.lang.Object) paint3);
        int int5 = day0.getMonth();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = day0.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.TOP_RIGHT");
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot2.getDataset();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace4, true);
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot2);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double10 = rectangleInsets8.extendHeight((double) 255);
        categoryPlot2.setInsets(rectangleInsets8, true);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 259.0d + "'", double10 == 259.0d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        dateAxis12.setAutoRangeMinimumSize((double) (byte) 10);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Font font8 = dateAxis4.getTickLabelFont();
        float float9 = dateAxis4.getTickMarkOutsideLength();
        java.awt.Paint paint10 = dateAxis4.getLabelPaint();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 2.0f + "'", float9 == 2.0f);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        org.jfree.chart.plot.IntervalMarker intervalMarker28 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.awt.Stroke stroke29 = null;
        intervalMarker28.setOutlineStroke(stroke29);
        boolean boolean31 = xYPlot21.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker28);
        java.awt.Paint paint32 = null;
        try {
            intervalMarker28.setPaint(paint32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        java.awt.Stroke stroke7 = null;
        categoryPlot0.setOutlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace9, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setLabelToolTip("hi!");
        int int19 = categoryPlot12.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis16);
        java.awt.Font font20 = dateAxis16.getTickLabelFont();
        boolean boolean21 = dateAxis16.isAxisLineVisible();
        dateAxis16.setAxisLineVisible(true);
        dateAxis16.setPositiveArrowVisible(true);
        float float26 = dateAxis16.getTickMarkOutsideLength();
        int int27 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis16);
        org.jfree.data.Range range28 = dateAxis16.getDefaultAutoRange();
        dateAxis16.setTickMarkInsideLength(0.0f);
        java.lang.String str31 = dateAxis16.getLabelToolTip();
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 2.0f + "'", float26 == 2.0f);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "hi!" + "'", str31.equals("hi!"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 100, (float) 10, (float) (short) 10);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.util.List list8 = categoryPlot0.getAnnotations();
        org.jfree.chart.util.SortOrder sortOrder9 = null;
        try {
            categoryPlot0.setColumnRenderingOrder(sortOrder9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        boolean boolean10 = categoryPlot0.render(graphics2D6, rectangle2D7, (int) ' ', plotRenderingInfo9);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = null;
        categoryPlot0.axisChanged(axisChangeEvent11);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.JFreeChart jFreeChart14 = null;
        plotChangeEvent13.setChart(jFreeChart14);
        org.jfree.chart.plot.Plot plot16 = plotChangeEvent13.getPlot();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType17 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        plotChangeEvent13.setType(chartChangeEventType17);
        java.lang.String str19 = chartChangeEventType17.toString();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(plot16);
        org.junit.Assert.assertNotNull(chartChangeEventType17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str19.equals("ChartChangeEventType.NEW_DATASET"));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        java.awt.Color color1 = java.awt.Color.getColor("java.awt.Color[r=0,g=128,b=128]");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray2 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        java.awt.Stroke[] strokeArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        java.awt.Stroke[] strokeArray4 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint6 = defaultDrawingSupplier5.getNextFillPaint();
        java.awt.Shape shape7 = defaultDrawingSupplier5.getNextShape();
        java.awt.Shape shape8 = defaultDrawingSupplier5.getNextShape();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        dateAxis10.setLabel("");
        dateAxis10.setTickLabelsVisible(false);
        dateAxis10.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        dateAxis21.setLabel("");
        dateAxis21.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource26 = dateAxis21.getStandardTickUnits();
        boolean boolean27 = categoryPlot17.equals((java.lang.Object) dateAxis21);
        float float28 = dateAxis21.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset9, (org.jfree.chart.axis.ValueAxis) dateAxis10, (org.jfree.chart.axis.ValueAxis) dateAxis21, xYItemRenderer29);
        float float31 = dateAxis21.getTickMarkOutsideLength();
        java.awt.Shape shape32 = dateAxis21.getRightArrow();
        java.awt.Shape[] shapeArray33 = new java.awt.Shape[] { shape8, shape32 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier34 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray3, strokeArray4, shapeArray33);
        java.awt.Shape shape35 = defaultDrawingSupplier34.getNextShape();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(strokeArray3);
        org.junit.Assert.assertNotNull(strokeArray4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(tickUnitSource26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 2.0f + "'", float28 == 2.0f);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 2.0f + "'", float31 == 2.0f);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(shapeArray33);
        org.junit.Assert.assertNotNull(shape35);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setLabel("");
        dateAxis0.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = dateAxis0.getStandardTickUnits();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = null;
        java.awt.geom.Point2D point2D11 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D9, rectangleAnchor10);
        categoryPlot6.zoomRangeAxes((double) (-1), plotRenderingInfo8, point2D11);
        java.awt.Stroke stroke13 = null;
        categoryPlot6.setOutlineStroke(stroke13);
        dateAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        org.jfree.chart.util.ObjectList objectList16 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        int int22 = categoryPlot17.getIndexOf(categoryItemRenderer21);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor23 = categoryPlot17.getDomainGridlinePosition();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        int int25 = categoryPlot17.getIndexOf(categoryItemRenderer24);
        boolean boolean26 = objectList16.equals((java.lang.Object) categoryPlot17);
        org.jfree.chart.axis.AxisLocation axisLocation28 = categoryPlot17.getDomainAxisLocation((-1));
        categoryPlot6.setDomainAxisLocation(axisLocation28, true);
        org.junit.Assert.assertNotNull(tickUnitSource5);
        org.junit.Assert.assertNotNull(point2D11);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(axisLocation28);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L, (java.awt.Paint) color1, stroke2);
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        categoryMarker3.setLabelTextAnchor(textAnchor4);
        categoryMarker3.setDrawAsLine(false);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        try {
            xYPlot21.drawBackground(graphics2D26, rectangle2D27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        java.lang.String str1 = seriesRenderingOrder0.toString();
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str1.equals("SeriesRenderingOrder.REVERSE"));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        categoryPlot0.setBackgroundImageAlpha((float) 0L);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier9 = categoryPlot0.getDrawingSupplier();
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNotNull(drawingSupplier9);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Font font8 = dateAxis4.getTickLabelFont();
        java.awt.Paint paint9 = dateAxis4.getTickMarkPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        dateAxis14.setLabelToolTip("hi!");
        int int17 = categoryPlot10.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis14);
        java.util.List list18 = categoryPlot10.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = categoryPlot10.getDomainAxis(100);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot10.addChangeListener(plotChangeListener21);
        categoryPlot10.setBackgroundImageAlignment(0);
        categoryPlot10.setOutlineVisible(false);
        categoryPlot10.setBackgroundImageAlpha((float) 0L);
        java.awt.Stroke stroke29 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot10.setRangeCrosshairStroke(stroke29);
        dateAxis4.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNull(categoryAxis20);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.util.List list8 = categoryPlot0.getAnnotations();
        java.awt.Paint paint9 = categoryPlot0.getDomainGridlinePaint();
        categoryPlot0.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        java.lang.Object obj6 = categoryPlot0.clone();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.setLabelToolTip("hi!");
        categoryPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis8, false);
        categoryPlot0.setNoDataMessage("");
        org.jfree.data.category.CategoryDataset categoryDataset16 = categoryPlot0.getDataset((int) (short) 10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType18 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        plotChangeEvent17.setType(chartChangeEventType18);
        org.jfree.chart.JFreeChart jFreeChart20 = plotChangeEvent17.getChart();
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(categoryDataset16);
        org.junit.Assert.assertNotNull(chartChangeEventType18);
        org.junit.Assert.assertNull(jFreeChart20);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        java.lang.Object obj6 = categoryPlot0.clone();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = categoryPlot0.getDrawingSupplier();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot0.getDomainAxis();
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(drawingSupplier7);
        org.junit.Assert.assertNull(categoryAxis8);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset2 = categoryPlot1.getDataset();
        boolean boolean3 = lengthAdjustmentType0.equals((java.lang.Object) categoryPlot1);
        boolean boolean4 = categoryPlot1.isSubplot();
        boolean boolean5 = categoryPlot1.isRangeZoomable();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = categoryPlot1.getDrawingSupplier();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(drawingSupplier6);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setLabel("");
        dateAxis0.resizeRange((double) (byte) 1, (double) (short) -1);
        dateAxis0.resizeRange(0.0d, (-1.0d));
        dateAxis0.setTickMarksVisible(false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        boolean boolean26 = xYPlot21.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, 0.0d, (double) (-1L), 100.0d);
        double double33 = rectangleInsets31.calculateRightOutset((double) (byte) 10);
        xYPlot21.setAxisOffset(rectangleInsets31);
        org.jfree.chart.util.Layer layer35 = null;
        java.util.Collection collection36 = xYPlot21.getDomainMarkers(layer35);
        xYPlot21.setDomainCrosshairVisible(false);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.0d + "'", double33 == 100.0d);
        org.junit.Assert.assertNull(collection36);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.TOP_RIGHT");
        numberAxis1.setVisible(false);
        numberAxis1.setAutoRangeIncludesZero(false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        java.awt.Color color1 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Font font8 = dateAxis4.getTickLabelFont();
        java.awt.Color color12 = java.awt.Color.getHSBColor((float) '4', (float) 'a', (float) 0);
        dateAxis4.setTickMarkPaint((java.awt.Paint) color12);
        org.jfree.data.Range range14 = dateAxis4.getDefaultAutoRange();
        dateAxis4.setLabelToolTip("hi!");
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color18 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        categoryPlot17.setDomainGridlinePaint((java.awt.Paint) color18);
        java.awt.Paint paint20 = categoryPlot17.getRangeCrosshairPaint();
        dateAxis4.setPlot((org.jfree.chart.plot.Plot) categoryPlot17);
        double double22 = dateAxis4.getLowerBound();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        int int8 = categoryPlot0.getIndexOf(categoryItemRenderer7);
        java.awt.Paint paint9 = categoryPlot0.getOutlinePaint();
        java.awt.Color color10 = java.awt.Color.red;
        java.awt.Color color11 = java.awt.Color.BLUE;
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.color.ColorSpace colorSpace13 = color12.getColorSpace();
        float[] floatArray22 = new float[] { (-1.0f), (short) 100, (byte) -1, (short) 0, (byte) -1 };
        float[] floatArray23 = java.awt.Color.RGBtoHSB((int) (short) 1, (int) (byte) 0, 0, floatArray22);
        float[] floatArray24 = color11.getColorComponents(colorSpace13, floatArray23);
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.color.ColorSpace colorSpace26 = color25.getColorSpace();
        java.awt.Color color27 = java.awt.Color.BLUE;
        java.awt.Color color28 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.color.ColorSpace colorSpace29 = color28.getColorSpace();
        float[] floatArray38 = new float[] { (-1.0f), (short) 100, (byte) -1, (short) 0, (byte) -1 };
        float[] floatArray39 = java.awt.Color.RGBtoHSB((int) (short) 1, (int) (byte) 0, 0, floatArray38);
        float[] floatArray40 = color27.getColorComponents(colorSpace29, floatArray39);
        float[] floatArray41 = color11.getComponents(colorSpace26, floatArray40);
        float[] floatArray42 = color10.getRGBComponents(floatArray41);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        categoryPlot0.setRenderer((int) (byte) 10, categoryItemRenderer45);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(colorSpace13);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(colorSpace26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(colorSpace29);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray42);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.String str1 = unitType0.toString();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L, (java.awt.Paint) color3, stroke4);
        boolean boolean6 = unitType0.equals((java.lang.Object) color3);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.ABSOLUTE" + "'", str1.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.util.List list8 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxis(100);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        categoryPlot0.addChangeListener(plotChangeListener11);
        categoryPlot0.setBackgroundImageAlignment(0);
        java.lang.String str15 = categoryPlot0.getPlotType();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        java.util.List list17 = categoryPlot0.getCategoriesForAxis(categoryAxis16);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Category Plot" + "'", str15.equals("Category Plot"));
        org.junit.Assert.assertNotNull(list17);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L, (java.awt.Paint) color1, stroke2);
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        categoryMarker3.setLabelTextAnchor(textAnchor4);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        categoryMarker3.setLabelAnchor(rectangleAnchor6);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        int int1 = objectList0.size();
        java.lang.Object obj2 = objectList0.clone();
        java.lang.Object obj3 = objectList0.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Font font8 = dateAxis4.getTickLabelFont();
        boolean boolean9 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAxisLineVisible(true);
        dateAxis4.setPositiveArrowVisible(false);
        org.jfree.data.Range range14 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis4.setRange(range14, false, false);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        dateAxis18.setLabel("");
        dateAxis18.setTickLabelsVisible(false);
        dateAxis18.setAutoRange(false);
        dateAxis18.zoomRange((double) (short) -1, (double) (short) 10);
        org.jfree.data.time.DateRange dateRange28 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis18.setRangeWithMargins((org.jfree.data.Range) dateRange28);
        dateAxis4.setDefaultAutoRange((org.jfree.data.Range) dateRange28);
        boolean boolean31 = dateAxis4.isVerticalTickLabels();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(dateRange28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = null;
        try {
            categoryPlot0.setInsets(rectangleInsets6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        java.lang.Object obj6 = categoryPlot0.clone();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.setLabelToolTip("hi!");
        categoryPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis8, false);
        categoryPlot0.setNoDataMessage("");
        boolean boolean15 = categoryPlot0.isRangeGridlinesVisible();
        categoryPlot0.setRangeGridlinesVisible(true);
        org.jfree.data.general.DatasetGroup datasetGroup18 = categoryPlot0.getDatasetGroup();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation19 = null;
        try {
            boolean boolean21 = categoryPlot0.removeAnnotation(categoryAnnotation19, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(datasetGroup18);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, 0.0d, (double) (-1L), 100.0d);
        double double5 = rectangleInsets4.getRight();
        java.lang.String str6 = rectangleInsets4.toString();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType8 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType9 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str10 = lengthAdjustmentType9.toString();
        try {
            java.awt.geom.Rectangle2D rectangle2D11 = rectangleInsets4.createAdjustedRectangle(rectangle2D7, lengthAdjustmentType8, lengthAdjustmentType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleInsets[t=10.0,l=0.0,b=-1.0,r=100.0]" + "'", str6.equals("RectangleInsets[t=10.0,l=0.0,b=-1.0,r=100.0]"));
        org.junit.Assert.assertNotNull(lengthAdjustmentType8);
        org.junit.Assert.assertNotNull(lengthAdjustmentType9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "NO_CHANGE" + "'", str10.equals("NO_CHANGE"));
    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test297");
//        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.data.category.CategoryDataset categoryDataset2 = categoryPlot1.getDataset();
//        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
//        org.jfree.data.Range range4 = categoryPlot1.getDataRange(valueAxis3);
//        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray5 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
//        categoryPlot1.setRenderers(categoryItemRendererArray5);
//        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
//        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
//        org.jfree.chart.axis.ValueAxis[] valueAxisArray9 = new org.jfree.chart.axis.ValueAxis[] { dateAxis7, dateAxis8 };
//        categoryPlot1.setRangeAxes(valueAxisArray9);
//        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
//        categoryPlot1.setNoDataMessageFont(font11);
//        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("CategoryAnchor.MIDDLE");
//        categoryPlot1.setDomainAxis(categoryAxis14);
//        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
//        categoryPlot16.setAnchorValue(1.0d, false);
//        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
//        dateAxis20.setLabelToolTip("hi!");
//        int int23 = categoryPlot16.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis20);
//        java.awt.Font font24 = dateAxis20.getTickLabelFont();
//        boolean boolean25 = dateAxis20.isAxisLineVisible();
//        dateAxis20.setAxisLineVisible(true);
//        dateAxis20.setPositiveArrowVisible(true);
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, categoryItemRenderer30);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier33 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//        java.awt.Paint paint34 = defaultDrawingSupplier33.getNextPaint();
//        java.awt.Paint paint35 = defaultDrawingSupplier33.getNextFillPaint();
//        int int36 = day32.compareTo((java.lang.Object) paint35);
//        int int37 = day32.getMonth();
//        long long38 = day32.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day32.next();
//        java.util.Date date40 = regularTimePeriod39.getStart();
//        java.lang.String str41 = categoryAxis14.getCategoryLabelToolTip((java.lang.Comparable) date40);
//        org.junit.Assert.assertNull(categoryDataset2);
//        org.junit.Assert.assertNull(range4);
//        org.junit.Assert.assertNotNull(categoryItemRendererArray5);
//        org.junit.Assert.assertNotNull(valueAxisArray9);
//        org.junit.Assert.assertNotNull(font11);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
//        org.junit.Assert.assertNotNull(font24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
//        org.junit.Assert.assertNotNull(paint34);
//        org.junit.Assert.assertNotNull(paint35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 6 + "'", int37 == 6);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560409200000L + "'", long38 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNull(str41);
//    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        boolean boolean22 = dateAxis1.isAutoTickUnitSelection();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot23.getDataset();
        categoryPlot23.clearDomainMarkers();
        dateAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot23);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(categoryDataset24);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setVerticalTickLabels(true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand4 = null;
        numberAxis1.setMarkerBand(markerAxisBand4);
        numberAxis1.configure();
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Font font8 = dateAxis4.getTickLabelFont();
        boolean boolean9 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAxisLineVisible(true);
        dateAxis4.setPositiveArrowVisible(false);
        dateAxis4.setRange((double) (-1.0f), (double) 10.0f);
        float float17 = dateAxis4.getTickMarkInsideLength();
        dateAxis4.setNegativeArrowVisible(false);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 0.0f + "'", float17 == 0.0f);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        xYPlot21.clearDomainAxes();
        double double27 = xYPlot21.getDomainCrosshairValue();
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        categoryPlot28.setDomainGridlinePaint((java.awt.Paint) color29);
        java.awt.Paint paint31 = categoryPlot28.getRangeCrosshairPaint();
        xYPlot21.setDomainZeroBaselinePaint(paint31);
        org.jfree.chart.plot.Plot plot33 = xYPlot21.getParent();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNull(plot33);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        float float26 = xYPlot21.getBackgroundAlpha();
        boolean boolean27 = xYPlot21.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        int int8 = categoryPlot0.getIndexOf(categoryItemRenderer7);
        java.awt.Paint paint9 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        try {
            categoryPlot0.handleClick((int) (short) 100, 9, plotRenderingInfo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(axisLocation10);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        categoryPlot0.setBackgroundImageAlpha((float) 0L);
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot0.getDataset();
        categoryPlot0.clearAnnotations();
        categoryPlot0.setDrawSharedDomainAxis(false);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(categoryDataset9);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.Plot plot2 = numberAxis1.getPlot();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.setLabel("");
        dateAxis8.setTickLabelsVisible(false);
        dateAxis8.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        dateAxis19.setLabel("");
        dateAxis19.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource24 = dateAxis19.getStandardTickUnits();
        boolean boolean25 = categoryPlot15.equals((java.lang.Object) dateAxis19);
        float float26 = dateAxis19.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset7, (org.jfree.chart.axis.ValueAxis) dateAxis8, (org.jfree.chart.axis.ValueAxis) dateAxis19, xYItemRenderer27);
        org.jfree.chart.axis.ValueAxis valueAxis30 = xYPlot28.getRangeAxis((int) (short) -1);
        java.awt.Paint paint31 = xYPlot28.getDomainCrosshairPaint();
        java.awt.Paint paint32 = xYPlot28.getRangeGridlinePaint();
        boolean boolean33 = xYPlot28.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = xYPlot28.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        try {
            org.jfree.chart.axis.AxisState axisState36 = numberAxis1.draw(graphics2D3, (double) (short) 100, rectangle2D5, rectangle2D6, rectangleEdge34, plotRenderingInfo35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(tickUnitSource24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 2.0f + "'", float26 == 2.0f);
        org.junit.Assert.assertNull(valueAxis30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(rectangleEdge34);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.util.List list8 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxis(100);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        categoryPlot0.addChangeListener(plotChangeListener11);
        categoryPlot0.setBackgroundImageAlignment(0);
        categoryPlot0.setOutlineVisible(false);
        categoryPlot0.setBackgroundImageAlpha((float) 0L);
        java.util.List list19 = categoryPlot0.getCategories();
        int int20 = categoryPlot0.getRangeAxisCount();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNull(list19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, 0.0d, (double) (-1L), 100.0d);
        double double12 = rectangleInsets11.getRight();
        double double14 = rectangleInsets11.trimWidth((double) (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset16 = categoryPlot15.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.data.Range range18 = categoryPlot15.getDataRange(valueAxis17);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray19 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot15.setRenderers(categoryItemRendererArray19);
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis22 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray23 = new org.jfree.chart.axis.ValueAxis[] { dateAxis21, dateAxis22 };
        categoryPlot15.setRangeAxes(valueAxisArray23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        java.awt.geom.Point2D point2D28 = null;
        categoryPlot15.zoomDomainAxes((double) 10L, (double) (byte) -1, plotRenderingInfo27, point2D28);
        boolean boolean30 = rectangleInsets11.equals((java.lang.Object) 10L);
        double double32 = rectangleInsets11.trimWidth(0.0d);
        boolean boolean33 = categoryAnchor6.equals((java.lang.Object) 0.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-101.0d) + "'", double14 == (-101.0d));
        org.junit.Assert.assertNull(categoryDataset16);
        org.junit.Assert.assertNull(range18);
        org.junit.Assert.assertNotNull(categoryItemRendererArray19);
        org.junit.Assert.assertNotNull(valueAxisArray23);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + (-100.0d) + "'", double32 == (-100.0d));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        java.awt.Stroke stroke7 = null;
        categoryPlot0.setOutlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace9, false);
        categoryPlot0.clearRangeMarkers(1);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        dateAxis18.setLabelToolTip("hi!");
        int int21 = categoryPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis18);
        java.util.List list22 = categoryPlot14.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot14.getDomainAxis(100);
        org.jfree.chart.event.PlotChangeListener plotChangeListener25 = null;
        categoryPlot14.addChangeListener(plotChangeListener25);
        categoryPlot14.setBackgroundImageAlignment(0);
        java.lang.String str29 = categoryPlot14.getPlotType();
        categoryPlot14.setAnchorValue((double) 1);
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        dateAxis34.setLabel("");
        dateAxis34.setTickLabelsVisible(false);
        dateAxis34.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot41.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis();
        dateAxis45.setLabel("");
        dateAxis45.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource50 = dateAxis45.getStandardTickUnits();
        boolean boolean51 = categoryPlot41.equals((java.lang.Object) dateAxis45);
        float float52 = dateAxis45.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer53 = null;
        org.jfree.chart.plot.XYPlot xYPlot54 = new org.jfree.chart.plot.XYPlot(xYDataset33, (org.jfree.chart.axis.ValueAxis) dateAxis34, (org.jfree.chart.axis.ValueAxis) dateAxis45, xYItemRenderer53);
        org.jfree.chart.axis.ValueAxis valueAxis56 = xYPlot54.getRangeAxis((int) (short) -1);
        java.awt.Paint paint57 = xYPlot54.getDomainCrosshairPaint();
        java.awt.Paint paint58 = xYPlot54.getRangeGridlinePaint();
        xYPlot54.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset60 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer61 = xYPlot54.getRendererForDataset(xYDataset60);
        java.awt.Color color62 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        xYPlot54.setDomainGridlinePaint((java.awt.Paint) color62);
        java.awt.Color color64 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot54.setRangeTickBandPaint((java.awt.Paint) color64);
        org.jfree.chart.axis.AxisLocation axisLocation66 = xYPlot54.getRangeAxisLocation();
        categoryPlot14.setRangeAxisLocation(100, axisLocation66);
        categoryPlot0.setRangeAxisLocation(axisLocation66);
        java.awt.Graphics2D graphics2D69 = null;
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        categoryPlot0.drawBackgroundImage(graphics2D69, rectangle2D70);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Category Plot" + "'", str29.equals("Category Plot"));
        org.junit.Assert.assertNotNull(tickUnitSource50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + float52 + "' != '" + 2.0f + "'", float52 == 2.0f);
        org.junit.Assert.assertNull(valueAxis56);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNull(xYItemRenderer61);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(axisLocation66);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        java.awt.Stroke stroke6 = categoryPlot0.getOutlineStroke();
        boolean boolean7 = categoryPlot0.isOutlineVisible();
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getUpArrow();
        dateAxis0.setLabelAngle((double) 0.0f);
        double double4 = dateAxis0.getFixedAutoRange();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = dateAxis0.getLabelInsets();
        double double7 = rectangleInsets5.calculateTopInset(0.0d);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Font font8 = dateAxis4.getTickLabelFont();
        boolean boolean9 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAxisLineVisible(true);
        dateAxis4.setFixedAutoRange((double) 9);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape1 = dateAxis0.getUpArrow();
        dateAxis0.setLabelAngle((double) 0.0f);
        dateAxis0.setUpperBound((double) (byte) 10);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        dateAxis6.setLabel("");
        dateAxis6.setTickLabelsVisible(false);
        dateAxis6.setAutoRange(false);
        dateAxis6.zoomRange((double) (short) -1, (double) (short) 10);
        org.jfree.data.time.DateRange dateRange16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis6.setRangeWithMargins((org.jfree.data.Range) dateRange16);
        dateAxis0.setRangeWithMargins((org.jfree.data.Range) dateRange16, false, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot21.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        dateAxis25.setLabelToolTip("hi!");
        int int28 = categoryPlot21.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis25);
        java.awt.Font font29 = dateAxis25.getTickLabelFont();
        java.util.Date date30 = dateAxis25.getMinimumDate();
        dateAxis0.setMaximumDate(date30);
        java.util.Date date32 = dateAxis0.getMaximumDate();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(dateRange16);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(date32);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, 0.0d, (double) (-1L), 100.0d);
        double double5 = rectangleInsets4.getRight();
        double double7 = rectangleInsets4.trimWidth((double) (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot8.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.data.Range range11 = categoryPlot8.getDataRange(valueAxis10);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray12 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot8.setRenderers(categoryItemRendererArray12);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray16 = new org.jfree.chart.axis.ValueAxis[] { dateAxis14, dateAxis15 };
        categoryPlot8.setRangeAxes(valueAxisArray16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot8.zoomDomainAxes((double) 10L, (double) (byte) -1, plotRenderingInfo20, point2D21);
        boolean boolean23 = rectangleInsets4.equals((java.lang.Object) 10L);
        double double25 = rectangleInsets4.calculateTopInset((double) 4);
        double double27 = rectangleInsets4.trimWidth((double) 8);
        java.lang.String str28 = rectangleInsets4.toString();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-101.0d) + "'", double7 == (-101.0d));
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray12);
        org.junit.Assert.assertNotNull(valueAxisArray16);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 10.0d + "'", double25 == 10.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + (-92.0d) + "'", double27 == (-92.0d));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleInsets[t=10.0,l=0.0,b=-1.0,r=100.0]" + "'", str28.equals("RectangleInsets[t=10.0,l=0.0,b=-1.0,r=100.0]"));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint2 = defaultDrawingSupplier1.getNextPaint();
        java.awt.Paint paint3 = defaultDrawingSupplier1.getNextFillPaint();
        int int4 = day0.compareTo((java.lang.Object) paint3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
        java.util.Date date6 = regularTimePeriod5.getStart();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { dateAxis6, dateAxis7 };
        categoryPlot0.setRangeAxes(valueAxisArray8);
        java.util.List list10 = categoryPlot0.getCategories();
        java.awt.Image image11 = null;
        categoryPlot0.setBackgroundImage(image11);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        int int19 = categoryPlot14.getIndexOf(categoryItemRenderer18);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor20 = categoryPlot14.getDomainGridlinePosition();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        dateAxis21.setLabelToolTip("hi!");
        categoryPlot14.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis21);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        dateAxis27.setLabel("");
        dateAxis27.setTickLabelsVisible(false);
        dateAxis27.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot34.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis38 = new org.jfree.chart.axis.DateAxis();
        dateAxis38.setLabel("");
        dateAxis38.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource43 = dateAxis38.getStandardTickUnits();
        boolean boolean44 = categoryPlot34.equals((java.lang.Object) dateAxis38);
        float float45 = dateAxis38.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot(xYDataset26, (org.jfree.chart.axis.ValueAxis) dateAxis27, (org.jfree.chart.axis.ValueAxis) dateAxis38, xYItemRenderer46);
        org.jfree.chart.axis.ValueAxis valueAxis49 = xYPlot47.getRangeAxis((int) (short) -1);
        java.awt.Paint paint50 = xYPlot47.getDomainCrosshairPaint();
        java.awt.Paint paint51 = xYPlot47.getRangeGridlinePaint();
        xYPlot47.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset53 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer54 = xYPlot47.getRendererForDataset(xYDataset53);
        java.awt.Color color55 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        xYPlot47.setDomainGridlinePaint((java.awt.Paint) color55);
        java.awt.Color color57 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot47.setRangeTickBandPaint((java.awt.Paint) color57);
        org.jfree.chart.axis.AxisLocation axisLocation59 = xYPlot47.getRangeAxisLocation();
        categoryPlot14.setRangeAxisLocation(0, axisLocation59);
        categoryPlot0.setDomainAxisLocation(12, axisLocation59);
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(list10);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor20);
        org.junit.Assert.assertNotNull(tickUnitSource43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + float45 + "' != '" + 2.0f + "'", float45 == 2.0f);
        org.junit.Assert.assertNull(valueAxis49);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertNull(xYItemRenderer54);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNotNull(axisLocation59);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        categoryPlot0.setForegroundAlpha((float) 4);
        categoryPlot0.setWeight(192);
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setLabel("");
        dateAxis0.setTickLabelsVisible(false);
        dateAxis0.setAutoRange(false);
        dateAxis0.zoomRange((double) (short) -1, (double) (short) 10);
        org.jfree.data.time.DateRange dateRange10 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis0.setRangeWithMargins((org.jfree.data.Range) dateRange10);
        dateAxis0.setRange((double) (-1.0f), (double) 'a');
        java.awt.Shape shape15 = dateAxis0.getLeftArrow();
        org.junit.Assert.assertNotNull(dateRange10);
        org.junit.Assert.assertNotNull(shape15);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setLabelToolTip("hi!");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = dateAxis0.getTickMarkPosition();
        double double4 = dateAxis0.getLabelAngle();
        java.awt.Font font5 = dateAxis0.getTickLabelFont();
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test321");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//        java.awt.Paint paint2 = defaultDrawingSupplier1.getNextPaint();
//        java.awt.Paint paint3 = defaultDrawingSupplier1.getNextFillPaint();
//        int int4 = day0.compareTo((java.lang.Object) paint3);
//        int int5 = day0.getMonth();
//        long long6 = day0.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day0.previous();
//        org.junit.Assert.assertNotNull(paint2);
//        org.junit.Assert.assertNotNull(paint3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        boolean boolean6 = categoryPlot0.isOutlineVisible();
        java.awt.Stroke stroke7 = null;
        try {
            categoryPlot0.setRangeCrosshairStroke(stroke7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        dateAxis11.setLabelToolTip("hi!");
        int int14 = categoryPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Font font15 = dateAxis11.getTickLabelFont();
        categoryPlot0.setNoDataMessageFont(font15);
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot0.setDomainAxisLocation((int) (byte) 100, axisLocation18, true);
        int int21 = categoryPlot0.getWeight();
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot21.getRangeAxisEdge();
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        org.jfree.chart.plot.CrosshairState crosshairState31 = null;
        boolean boolean32 = xYPlot21.render(graphics2D27, rectangle2D28, 175, plotRenderingInfo30, crosshairState31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        dateAxis37.setLabel("");
        dateAxis37.setTickLabelsVisible(false);
        dateAxis37.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot44.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis();
        dateAxis48.setLabel("");
        dateAxis48.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource53 = dateAxis48.getStandardTickUnits();
        boolean boolean54 = categoryPlot44.equals((java.lang.Object) dateAxis48);
        float float55 = dateAxis48.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer56 = null;
        org.jfree.chart.plot.XYPlot xYPlot57 = new org.jfree.chart.plot.XYPlot(xYDataset36, (org.jfree.chart.axis.ValueAxis) dateAxis37, (org.jfree.chart.axis.ValueAxis) dateAxis48, xYItemRenderer56);
        org.jfree.chart.plot.IntervalMarker intervalMarker60 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot57.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker60);
        java.awt.Paint paint62 = xYPlot57.getRangeCrosshairPaint();
        java.awt.geom.Point2D point2D63 = xYPlot57.getQuadrantOrigin();
        try {
            xYPlot21.zoomRangeAxes((double) 100.0f, (-92.0d), plotRenderingInfo35, point2D63);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (-92.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(tickUnitSource53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + float55 + "' != '" + 2.0f + "'", float55 == 2.0f);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNotNull(point2D63);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabel("");
        dateAxis4.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = dateAxis4.getStandardTickUnits();
        boolean boolean10 = categoryPlot0.equals((java.lang.Object) dateAxis4);
        dateAxis4.setUpperBound((double) 0.0f);
        boolean boolean13 = dateAxis4.isInverted();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis14.setTickUnit(dateTickUnit15);
        dateAxis4.setTickUnit(dateTickUnit15);
        try {
            dateAxis4.zoomRange((double) 3, (double) (-14336));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (2.0) <= upper (-14337.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTickUnit15);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.setLabel("");
        dateAxis7.setTickLabelsVisible(false);
        dateAxis7.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        dateAxis18.setLabel("");
        dateAxis18.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource23 = dateAxis18.getStandardTickUnits();
        boolean boolean24 = categoryPlot14.equals((java.lang.Object) dateAxis18);
        float float25 = dateAxis18.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis18, xYItemRenderer26);
        org.jfree.chart.axis.ValueAxis valueAxis29 = xYPlot27.getRangeAxis((int) (short) -1);
        java.awt.Paint paint30 = xYPlot27.getDomainCrosshairPaint();
        java.awt.Paint paint31 = xYPlot27.getRangeGridlinePaint();
        boolean boolean32 = xYPlot27.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = xYPlot27.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        try {
            org.jfree.chart.axis.AxisState axisState35 = numberAxis1.draw(graphics2D2, (double) 10, rectangle2D4, rectangle2D5, rectangleEdge33, plotRenderingInfo34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 2.0f + "'", float25 == 2.0f);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(rectangleEdge33);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        dateAxis11.setLabelToolTip("hi!");
        int int14 = categoryPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Font font15 = dateAxis11.getTickLabelFont();
        categoryPlot0.setNoDataMessageFont(font15);
        org.jfree.chart.util.SortOrder sortOrder17 = null;
        try {
            categoryPlot0.setRowRenderingOrder(sortOrder17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(font15);
    }

//    @Test
//    public void test328() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test328");
//        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
//        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
//        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
//        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
//        categoryPlot0.setRangeAxisLocation((int) ' ', axisLocation5, true);
//        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("CategoryAnchor.MIDDLE");
//        categoryAxis10.setMaximumCategoryLabelLines(0);
//        double double13 = categoryAxis10.getUpperMargin();
//        categoryAxis10.addCategoryLabelToolTip((java.lang.Comparable) (byte) -1, "");
//        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis10);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//        java.awt.Paint paint20 = defaultDrawingSupplier19.getNextPaint();
//        java.awt.Paint paint21 = defaultDrawingSupplier19.getNextFillPaint();
//        int int22 = day18.compareTo((java.lang.Object) paint21);
//        int int23 = day18.getMonth();
//        long long24 = day18.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = day18.next();
//        java.awt.Paint paint26 = categoryAxis10.getTickLabelPaint((java.lang.Comparable) day18);
//        org.junit.Assert.assertNull(categoryDataset1);
//        org.junit.Assert.assertNull(range3);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
//        org.junit.Assert.assertNotNull(paint20);
//        org.junit.Assert.assertNotNull(paint21);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560409200000L + "'", long24 == 1560409200000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertNotNull(paint26);
//    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot21.zoomRangeAxes((double) (short) 100, plotRenderingInfo25, point2D26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = null;
        xYPlot21.setDomainAxisLocation((int) (byte) 100, axisLocation29);
        java.awt.Paint paint31 = xYPlot21.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = null;
        java.awt.geom.Point2D point2D42 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D40, rectangleAnchor41);
        categoryPlot37.zoomRangeAxes((double) (-1), plotRenderingInfo39, point2D42);
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot44.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis48 = new org.jfree.chart.axis.DateAxis();
        dateAxis48.setLabelToolTip("hi!");
        int int51 = categoryPlot44.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis48);
        java.awt.Font font52 = dateAxis48.getTickLabelFont();
        categoryPlot37.setNoDataMessageFont(font52);
        boolean boolean54 = numberAxis36.equals((java.lang.Object) font52);
        try {
            xYPlot21.setRangeAxis((-1), (org.jfree.chart.axis.ValueAxis) numberAxis36, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(point2D42);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("java.awt.Color[r=0,g=128,b=128]");
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L, (java.awt.Paint) color1, stroke2);
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        categoryMarker3.setLabelTextAnchor(textAnchor4);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot7.getDataset();
        boolean boolean9 = lengthAdjustmentType6.equals((java.lang.Object) categoryPlot7);
        categoryMarker3.setLabelOffsetType(lengthAdjustmentType6);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setLabelToolTip("hi!");
        org.jfree.chart.axis.TickUnitSource tickUnitSource3 = dateAxis0.getStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource3);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { dateAxis6, dateAxis7 };
        categoryPlot0.setRangeAxes(valueAxisArray8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot0.zoomDomainAxes((double) 10L, (double) (byte) -1, plotRenderingInfo12, point2D13);
        java.awt.Paint paint15 = null;
        try {
            categoryPlot0.setNoDataMessagePaint(paint15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertNotNull(valueAxisArray8);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        xYPlot21.setRangeCrosshairLockedOnData(true);
        java.lang.Object obj28 = xYPlot21.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = null;
        java.awt.geom.Point2D point2D34 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D32, rectangleAnchor33);
        categoryPlot29.zoomRangeAxes((double) (-1), plotRenderingInfo31, point2D34);
        xYPlot21.setQuadrantOrigin(point2D34);
        java.awt.Paint paint37 = null;
        xYPlot21.setBackgroundPaint(paint37);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset42 = categoryPlot41.getDataset();
        boolean boolean43 = rectangleAnchor40.equals((java.lang.Object) categoryPlot41);
        java.awt.Color color44 = org.jfree.chart.ChartColor.LIGHT_RED;
        categoryPlot41.setNoDataMessagePaint((java.awt.Paint) color44);
        java.awt.Color color46 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT", color44);
        xYPlot21.setRangeCrosshairPaint((java.awt.Paint) color44);
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = xYPlot21.getAxisOffset();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(point2D34);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNull(categoryDataset42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(rectangleInsets48);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { dateAxis6, dateAxis7 };
        categoryPlot0.setRangeAxes(valueAxisArray8);
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryPlot0.setNoDataMessageFont(font10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("CategoryAnchor.MIDDLE");
        categoryPlot0.setDomainAxis(categoryAxis13);
        java.lang.Comparable comparable15 = null;
        try {
            java.awt.Font font16 = categoryAxis13.getTickLabelFont(comparable15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot21.zoomRangeAxes((double) (short) 100, plotRenderingInfo25, point2D26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = null;
        xYPlot21.setDomainAxisLocation((int) (byte) 100, axisLocation29);
        java.awt.Paint paint31 = xYPlot21.getDomainTickBandPaint();
        boolean boolean32 = xYPlot21.isDomainZeroBaselineVisible();
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        dateAxis36.setLabel("");
        dateAxis36.setTickLabelsVisible(false);
        dateAxis36.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot43.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis();
        dateAxis47.setLabel("");
        dateAxis47.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource52 = dateAxis47.getStandardTickUnits();
        boolean boolean53 = categoryPlot43.equals((java.lang.Object) dateAxis47);
        float float54 = dateAxis47.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer55 = null;
        org.jfree.chart.plot.XYPlot xYPlot56 = new org.jfree.chart.plot.XYPlot(xYDataset35, (org.jfree.chart.axis.ValueAxis) dateAxis36, (org.jfree.chart.axis.ValueAxis) dateAxis47, xYItemRenderer55);
        org.jfree.chart.plot.IntervalMarker intervalMarker59 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot56.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker59);
        xYPlot56.setRangeCrosshairLockedOnData(true);
        java.lang.Object obj63 = xYPlot56.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot64 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo66 = null;
        java.awt.geom.Rectangle2D rectangle2D67 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor68 = null;
        java.awt.geom.Point2D point2D69 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D67, rectangleAnchor68);
        categoryPlot64.zoomRangeAxes((double) (-1), plotRenderingInfo66, point2D69);
        xYPlot56.setQuadrantOrigin(point2D69);
        org.jfree.chart.plot.PlotState plotState72 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo73 = null;
        try {
            xYPlot21.draw(graphics2D33, rectangle2D34, point2D69, plotState72, plotRenderingInfo73);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(tickUnitSource52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + float54 + "' != '" + 2.0f + "'", float54 == 2.0f);
        org.junit.Assert.assertNotNull(obj63);
        org.junit.Assert.assertNotNull(point2D69);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        java.lang.Object obj6 = categoryPlot0.clone();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.setLabelToolTip("hi!");
        categoryPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis8, false);
        categoryPlot0.setNoDataMessage("");
        boolean boolean15 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot0.getRendererForDataset(categoryDataset16);
        java.awt.Stroke stroke18 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.util.SortOrder sortOrder19 = null;
        try {
            categoryPlot0.setColumnRenderingOrder(sortOrder19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(categoryItemRenderer17);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = xYPlot21.getDomainAxisEdge((int) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        xYPlot21.setRenderer((int) (short) 100, xYItemRenderer29, false);
        xYPlot21.setDomainCrosshairVisible(false);
        java.awt.Paint paint34 = null;
        try {
            xYPlot21.setRangeZeroBaselinePaint(paint34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Font font8 = dateAxis4.getTickLabelFont();
        java.util.Date date9 = dateAxis4.getMinimumDate();
        dateAxis4.resizeRange((double) 0.0f);
        java.awt.Paint paint12 = dateAxis4.getTickLabelPaint();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        boolean boolean10 = categoryPlot0.render(graphics2D6, rectangle2D7, (int) ' ', plotRenderingInfo9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot0.getDomainAxis();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent12);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(categoryAxis11);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabel("");
        dateAxis4.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = dateAxis4.getStandardTickUnits();
        boolean boolean10 = categoryPlot0.equals((java.lang.Object) dateAxis4);
        dateAxis4.setUpperBound((double) 0.0f);
        boolean boolean13 = dateAxis4.isInverted();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateTickUnit dateTickUnit15 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis14.setTickUnit(dateTickUnit15);
        dateAxis4.setTickUnit(dateTickUnit15);
        java.lang.String str18 = dateAxis4.getLabelURL();
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(dateTickUnit15);
        org.junit.Assert.assertNull(str18);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        categoryPlot0.setBackgroundImageAlpha((float) 0L);
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot0.getDataset();
        categoryPlot0.clearAnnotations();
        double double11 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation12);
        java.awt.Color color17 = java.awt.Color.getHSBColor((float) '4', (float) 'a', (float) 0);
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = null;
        try {
            categoryPlot0.setInsets(rectangleInsets19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.awt.Stroke stroke9 = null;
        intervalMarker8.setOutlineStroke(stroke9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        dateAxis15.setLabelToolTip("hi!");
        int int18 = categoryPlot11.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis15);
        java.util.List list19 = categoryPlot11.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = categoryPlot11.getDomainAxis(100);
        org.jfree.chart.event.PlotChangeListener plotChangeListener22 = null;
        categoryPlot11.addChangeListener(plotChangeListener22);
        categoryPlot11.setBackgroundImageAlignment(0);
        categoryPlot11.setOutlineVisible(false);
        categoryPlot11.setBackgroundImageAlpha((float) 0L);
        org.jfree.chart.util.Layer layer31 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection32 = categoryPlot11.getDomainMarkers(0, layer31);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker8, layer31);
        java.awt.Paint paint34 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder35 = null;
        try {
            categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNull(categoryAxis21);
        org.junit.Assert.assertNotNull(layer31);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        java.awt.Stroke stroke4 = null;
        categoryPlot0.setOutlineStroke(stroke4);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.setLabel("");
        dateAxis7.setTickLabelsVisible(false);
        dateAxis7.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        dateAxis18.setLabel("");
        dateAxis18.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource23 = dateAxis18.getStandardTickUnits();
        boolean boolean24 = categoryPlot14.equals((java.lang.Object) dateAxis18);
        float float25 = dateAxis18.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis18, xYItemRenderer26);
        org.jfree.chart.axis.ValueAxis valueAxis29 = xYPlot27.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        xYPlot27.zoomRangeAxes((double) (short) 100, plotRenderingInfo31, point2D32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = xYPlot27.getRangeAxisLocation((int) (byte) 10);
        categoryPlot0.setRangeAxisLocation(axisLocation35, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        categoryPlot0.setAxisOffset(rectangleInsets38);
        org.junit.Assert.assertNotNull(tickUnitSource23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 2.0f + "'", float25 == 2.0f);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(rectangleInsets38);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("NO_CHANGE");
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, 0.0d, (double) (-1L), 100.0d);
        double double5 = rectangleInsets4.getRight();
        double double7 = rectangleInsets4.trimWidth((double) (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot8.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.data.Range range11 = categoryPlot8.getDataRange(valueAxis10);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray12 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot8.setRenderers(categoryItemRendererArray12);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray16 = new org.jfree.chart.axis.ValueAxis[] { dateAxis14, dateAxis15 };
        categoryPlot8.setRangeAxes(valueAxisArray16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot8.zoomDomainAxes((double) 10L, (double) (byte) -1, plotRenderingInfo20, point2D21);
        boolean boolean23 = rectangleInsets4.equals((java.lang.Object) 10L);
        double double25 = rectangleInsets4.calculateTopOutset((double) (byte) 0);
        double double27 = rectangleInsets4.trimHeight((double) (-1));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-101.0d) + "'", double7 == (-101.0d));
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray12);
        org.junit.Assert.assertNotNull(valueAxisArray16);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 10.0d + "'", double25 == 10.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + (-10.0d) + "'", double27 == (-10.0d));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint1 = defaultDrawingSupplier0.getNextPaint();
        java.lang.Object obj2 = defaultDrawingSupplier0.clone();
        java.lang.Object obj3 = defaultDrawingSupplier0.clone();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        java.awt.Stroke stroke4 = null;
        categoryPlot0.setOutlineStroke(stroke4);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L, (java.awt.Paint) color9, stroke10);
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        categoryMarker11.setLabelTextAnchor(textAnchor12);
        boolean boolean14 = datasetRenderingOrder7.equals((java.lang.Object) categoryMarker11);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        xYPlot15.setDataset(10, xYDataset17);
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection21 = xYPlot15.getDomainMarkers((-1), layer20);
        categoryPlot0.addRangeMarker((int) (byte) 0, (org.jfree.chart.plot.Marker) categoryMarker11, layer20);
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertNull(collection21);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabel("");
        dateAxis4.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = dateAxis4.getStandardTickUnits();
        boolean boolean10 = categoryPlot0.equals((java.lang.Object) dateAxis4);
        float float11 = dateAxis4.getTickMarkOutsideLength();
        java.lang.String str12 = dateAxis4.getLabelURL();
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 2.0f + "'", float11 == 2.0f);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        xYPlot21.setRangeCrosshairLockedOnData(true);
        java.lang.Object obj28 = xYPlot21.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = null;
        java.awt.geom.Point2D point2D34 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D32, rectangleAnchor33);
        categoryPlot29.zoomRangeAxes((double) (-1), plotRenderingInfo31, point2D34);
        xYPlot21.setQuadrantOrigin(point2D34);
        java.awt.Paint paint37 = null;
        xYPlot21.setBackgroundPaint(paint37);
        org.jfree.chart.axis.ValueAxis valueAxis39 = xYPlot21.getDomainAxis();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(point2D34);
        org.junit.Assert.assertNotNull(valueAxis39);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        xYPlot21.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot21.getRendererForDataset(xYDataset27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        xYPlot21.setDomainGridlinePaint((java.awt.Paint) color29);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot21.setRangeTickBandPaint((java.awt.Paint) color31);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = xYPlot21.getDomainAxisEdge((int) (short) 1);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(xYItemRenderer28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(rectangleEdge34);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setLabelToolTip("hi!");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = dateAxis0.getTickMarkPosition();
        try {
            dateAxis0.zoomRange((double) (byte) 100, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = xYPlot21.getDomainAxisEdge((int) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        xYPlot21.setRenderer((int) (short) 100, xYItemRenderer29, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = xYPlot21.getDomainAxisEdge((int) (byte) -1);
        org.jfree.chart.axis.AxisLocation axisLocation35 = xYPlot21.getDomainAxisLocation((int) (short) 0);
        org.jfree.chart.axis.AxisLocation axisLocation36 = axisLocation35.getOpposite();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(axisLocation36);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        dateAxis11.setLabelToolTip("hi!");
        int int14 = categoryPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Font font15 = dateAxis11.getTickLabelFont();
        categoryPlot0.setNoDataMessageFont(font15);
        org.jfree.chart.plot.Plot plot17 = categoryPlot0.getRootPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("CategoryAnchor.MIDDLE");
        categoryAxis20.setMaximumCategoryLabelLines(0);
        categoryPlot0.setDomainAxis((int) '#', categoryAxis20);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions24 = null;
        try {
            categoryAxis20.setCategoryLabelPositions(categoryLabelPositions24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(plot17);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        java.lang.Object obj6 = categoryPlot0.clone();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.setLabelToolTip("hi!");
        categoryPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis8, false);
        categoryPlot0.setNoDataMessage("");
        boolean boolean15 = categoryPlot0.isRangeGridlinesVisible();
        categoryPlot0.setRangeGridlinesVisible(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = categoryPlot0.getDomainAxis();
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNull(categoryAxis18);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        xYPlot21.setRenderer(xYItemRenderer22);
        org.jfree.data.general.DatasetGroup datasetGroup24 = xYPlot21.getDatasetGroup();
        xYPlot21.setRangeCrosshairValue((double) (short) -1);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(datasetGroup24);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((-10.0d));
        java.lang.Object obj2 = null;
        boolean boolean3 = valueMarker1.equals(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean2 = numberAxis1.getAutoRangeIncludesZero();
        org.jfree.data.RangeType rangeType3 = numberAxis1.getRangeType();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(rangeType3);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        categoryPlot0.setBackgroundImageAlpha((float) 0L);
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot0.getDataset();
        categoryPlot0.clearAnnotations();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        boolean boolean15 = categoryPlot0.render(graphics2D11, rectangle2D12, (int) (byte) -1, plotRenderingInfo14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        categoryPlot0.setRenderer(categoryItemRenderer16);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, 0.0d, (double) (-1L), 100.0d);
        double double6 = rectangleInsets4.calculateRightOutset((double) (byte) 10);
        double double8 = rectangleInsets4.calculateTopOutset((double) 7);
        double double10 = rectangleInsets4.calculateLeftOutset((double) 10);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 10.0d + "'", double8 == 10.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color1);
        int int3 = categoryPlot0.getDomainAxisCount();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        java.lang.Object obj4 = categoryPlot0.clone();
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot0.getFixedRangeAxisSpace();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        try {
            categoryPlot0.zoom((double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        boolean boolean10 = categoryPlot0.render(graphics2D6, rectangle2D7, (int) ' ', plotRenderingInfo9);
        categoryPlot0.clearDomainMarkers((-16646144));
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot13.getDataset();
        categoryPlot13.clearDomainMarkers();
        java.awt.Stroke stroke16 = categoryPlot13.getDomainGridlineStroke();
        categoryPlot0.setRangeGridlineStroke(stroke16);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.lang.String str8 = dateAxis4.getLabelToolTip();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double1 = rectangleInsets0.getTop();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, 0.0d, (double) (-1L), 100.0d);
        double double7 = rectangleInsets6.getRight();
        double double9 = rectangleInsets6.trimWidth((double) (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset11 = categoryPlot10.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.data.Range range13 = categoryPlot10.getDataRange(valueAxis12);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot10.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray18 = new org.jfree.chart.axis.ValueAxis[] { dateAxis16, dateAxis17 };
        categoryPlot10.setRangeAxes(valueAxisArray18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot10.zoomDomainAxes((double) 10L, (double) (byte) -1, plotRenderingInfo22, point2D23);
        boolean boolean25 = rectangleInsets6.equals((java.lang.Object) 10L);
        double double27 = rectangleInsets6.calculateTopInset((double) 4);
        categoryPlot0.setAxisOffset(rectangleInsets6);
        categoryPlot0.configureDomainAxes();
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-101.0d) + "'", double9 == (-101.0d));
        org.junit.Assert.assertNull(categoryDataset11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(valueAxisArray18);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 10.0d + "'", double27 == 10.0d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        xYPlot0.setDataset(10, xYDataset2);
        org.jfree.chart.util.Layer layer5 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection6 = xYPlot0.getDomainMarkers((-1), layer5);
        boolean boolean7 = xYPlot0.isRangeGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = null;
        java.awt.geom.Point2D point2D15 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D13, rectangleAnchor14);
        categoryPlot10.zoomRangeAxes((double) (-1), plotRenderingInfo12, point2D15);
        categoryPlot10.setBackgroundImageAlpha((float) 0L);
        org.jfree.data.category.CategoryDataset categoryDataset19 = categoryPlot10.getDataset();
        categoryPlot10.mapDatasetToDomainAxis(0, (int) (byte) 100);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor27 = null;
        java.awt.geom.Point2D point2D28 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D26, rectangleAnchor27);
        categoryPlot10.zoomDomainAxes((double) 1.0f, 0.05d, plotRenderingInfo25, point2D28);
        xYPlot0.zoomRangeAxes((double) 7, plotRenderingInfo9, point2D28);
        org.junit.Assert.assertNotNull(layer5);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(point2D15);
        org.junit.Assert.assertNull(categoryDataset19);
        org.junit.Assert.assertNotNull(point2D28);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, 0.0d, (double) (-1L), 100.0d);
        double double5 = rectangleInsets4.getRight();
        double double7 = rectangleInsets4.trimWidth((double) (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot8.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.data.Range range11 = categoryPlot8.getDataRange(valueAxis10);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray12 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot8.setRenderers(categoryItemRendererArray12);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray16 = new org.jfree.chart.axis.ValueAxis[] { dateAxis14, dateAxis15 };
        categoryPlot8.setRangeAxes(valueAxisArray16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot8.zoomDomainAxes((double) 10L, (double) (byte) -1, plotRenderingInfo20, point2D21);
        boolean boolean23 = rectangleInsets4.equals((java.lang.Object) 10L);
        double double25 = rectangleInsets4.calculateTopOutset((double) (-14336));
        double double27 = rectangleInsets4.trimHeight((double) 0.0f);
        java.lang.String str28 = rectangleInsets4.toString();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-101.0d) + "'", double7 == (-101.0d));
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray12);
        org.junit.Assert.assertNotNull(valueAxisArray16);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 10.0d + "'", double25 == 10.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + (-9.0d) + "'", double27 == (-9.0d));
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "RectangleInsets[t=10.0,l=0.0,b=-1.0,r=100.0]" + "'", str28.equals("RectangleInsets[t=10.0,l=0.0,b=-1.0,r=100.0]"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.RangeType rangeType2 = numberAxis1.getRangeType();
        numberAxis1.setUpperBound((double) 0.5f);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        dateAxis9.setLabel("");
        dateAxis9.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource14 = dateAxis9.getStandardTickUnits();
        boolean boolean15 = categoryPlot5.equals((java.lang.Object) dateAxis9);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setLabel("");
        dateAxis16.setTickLabelsVisible(false);
        dateAxis16.setAutoRange(false);
        dateAxis16.zoomRange((double) (short) -1, (double) (short) 10);
        org.jfree.data.time.DateRange dateRange26 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis16.setRangeWithMargins((org.jfree.data.Range) dateRange26);
        dateAxis9.setRange((org.jfree.data.Range) dateRange26);
        numberAxis1.setRangeWithMargins((org.jfree.data.Range) dateRange26, false, false);
        org.junit.Assert.assertNotNull(rangeType2);
        org.junit.Assert.assertNotNull(tickUnitSource14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(dateRange26);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        dateAxis11.setLabelToolTip("hi!");
        int int14 = categoryPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Font font15 = dateAxis11.getTickLabelFont();
        categoryPlot0.setNoDataMessageFont(font15);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = categoryPlot0.getDomainMarkers(layer17);
        org.jfree.chart.axis.AxisSpace axisSpace19 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace19, false);
        java.awt.Stroke stroke22 = categoryPlot0.getRangeCrosshairStroke();
        categoryPlot0.setAnchorValue((double) 10.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset26 = categoryPlot25.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.data.Range range28 = categoryPlot25.getDataRange(valueAxis27);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray29 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot25.setRenderers(categoryItemRendererArray29);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray33 = new org.jfree.chart.axis.ValueAxis[] { dateAxis31, dateAxis32 };
        categoryPlot25.setRangeAxes(valueAxisArray33);
        java.awt.Font font35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryPlot25.setNoDataMessageFont(font35);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("CategoryAnchor.MIDDLE");
        categoryPlot25.setDomainAxis(categoryAxis38);
        java.util.List list40 = categoryPlot0.getCategoriesForAxis(categoryAxis38);
        categoryAxis38.setLowerMargin((double) 64);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(categoryDataset26);
        org.junit.Assert.assertNull(range28);
        org.junit.Assert.assertNotNull(categoryItemRendererArray29);
        org.junit.Assert.assertNotNull(valueAxisArray33);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(list40);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { dateAxis6, dateAxis7 };
        categoryPlot0.setRangeAxes(valueAxisArray8);
        java.util.List list10 = categoryPlot0.getCategories();
        java.awt.Image image11 = null;
        categoryPlot0.setBackgroundImage(image11);
        categoryPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.AxisSpace axisSpace15 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.zoom(259.0d);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        int int19 = categoryPlot0.getIndexOf(categoryItemRenderer18);
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(list10);
        org.junit.Assert.assertNull(axisSpace15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        org.jfree.chart.plot.Plot plot2 = numberAxis1.getPlot();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = numberAxis1.getTickUnit();
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        xYPlot4.setDataset(10, xYDataset6);
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection10 = xYPlot4.getDomainMarkers((-1), layer9);
        boolean boolean11 = numberAxis1.equals((java.lang.Object) layer9);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setLabelToolTip("hi!");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = dateAxis0.getTickMarkPosition();
        dateAxis0.setPositiveArrowVisible(true);
        org.junit.Assert.assertNotNull(dateTickMarkPosition3);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, 0.0d, (double) (-1L), 100.0d);
        double double6 = rectangleInsets4.calculateRightOutset((double) (byte) 10);
        double double8 = rectangleInsets4.calculateLeftInset((double) (byte) 100);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D10 = rectangleInsets4.createOutsetRectangle(rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot21.zoomRangeAxes((double) (short) 100, plotRenderingInfo25, point2D26);
        int int28 = xYPlot21.getBackgroundImageAlignment();
        java.awt.Paint paint29 = xYPlot21.getOutlinePaint();
        boolean boolean30 = xYPlot21.isRangeCrosshairLockedOnData();
        xYPlot21.clearRangeMarkers();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 15 + "'", int28 == 15);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        java.awt.Stroke stroke22 = xYPlot21.getDomainCrosshairStroke();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        int int24 = xYPlot21.getIndexOf(xYItemRenderer23);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean2 = numberAxis1.getAutoRangeIncludesZero();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.setLabelToolTip("hi!");
        int int10 = categoryPlot3.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis7);
        java.awt.Font font11 = dateAxis7.getTickLabelFont();
        java.awt.Paint paint12 = dateAxis7.getTickMarkPaint();
        numberAxis1.setTickLabelPaint(paint12);
        java.text.NumberFormat numberFormat14 = numberAxis1.getNumberFormatOverride();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(numberFormat14);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        boolean boolean10 = categoryPlot0.render(graphics2D6, rectangle2D7, (int) ' ', plotRenderingInfo9);
        categoryPlot0.clearDomainMarkers((-16646144));
        categoryPlot0.setAnchorValue((double) 1L, false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.awt.Stroke stroke9 = null;
        intervalMarker8.setOutlineStroke(stroke9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        dateAxis15.setLabelToolTip("hi!");
        int int18 = categoryPlot11.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis15);
        java.util.List list19 = categoryPlot11.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = categoryPlot11.getDomainAxis(100);
        org.jfree.chart.event.PlotChangeListener plotChangeListener22 = null;
        categoryPlot11.addChangeListener(plotChangeListener22);
        categoryPlot11.setBackgroundImageAlignment(0);
        categoryPlot11.setOutlineVisible(false);
        categoryPlot11.setBackgroundImageAlpha((float) 0L);
        org.jfree.chart.util.Layer layer31 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection32 = categoryPlot11.getDomainMarkers(0, layer31);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker8, layer31);
        java.awt.Paint paint34 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation36 = categoryPlot0.getDomainAxisLocation(175);
        boolean boolean37 = categoryPlot0.isDomainZoomable();
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNull(categoryAxis21);
        org.junit.Assert.assertNotNull(layer31);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        xYPlot21.setRangeCrosshairLockedOnData(true);
        java.lang.Object obj28 = xYPlot21.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor33 = null;
        java.awt.geom.Point2D point2D34 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D32, rectangleAnchor33);
        categoryPlot29.zoomRangeAxes((double) (-1), plotRenderingInfo31, point2D34);
        xYPlot21.setQuadrantOrigin(point2D34);
        java.awt.Paint paint37 = null;
        xYPlot21.setBackgroundPaint(paint37);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset42 = categoryPlot41.getDataset();
        boolean boolean43 = rectangleAnchor40.equals((java.lang.Object) categoryPlot41);
        java.awt.Color color44 = org.jfree.chart.ChartColor.LIGHT_RED;
        categoryPlot41.setNoDataMessagePaint((java.awt.Paint) color44);
        java.awt.Color color46 = java.awt.Color.getColor("RectangleAnchor.TOP_LEFT", color44);
        xYPlot21.setRangeCrosshairPaint((java.awt.Paint) color44);
        java.awt.Color color48 = color44.brighter();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNotNull(obj28);
        org.junit.Assert.assertNotNull(point2D34);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNull(categoryDataset42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(color48);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabel("");
        dateAxis4.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = dateAxis4.getStandardTickUnits();
        boolean boolean10 = categoryPlot0.equals((java.lang.Object) dateAxis4);
        dateAxis4.setUpperBound((double) 0.0f);
        org.jfree.data.time.DateRange dateRange13 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        dateAxis4.setRangeWithMargins((org.jfree.data.Range) dateRange13);
        java.awt.Paint paint15 = null;
        try {
            dateAxis4.setTickMarkPaint(paint15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(dateRange13);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot21.zoomRangeAxes((double) (short) 100, plotRenderingInfo25, point2D26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = null;
        xYPlot21.setDomainAxisLocation((int) (byte) 100, axisLocation29);
        java.awt.Paint paint31 = xYPlot21.getRangeTickBandPaint();
        try {
            java.awt.Paint paint33 = xYPlot21.getQuadrantPaint(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (10) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNull(paint31);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.plot.IntervalMarker intervalMarker3 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = intervalMarker3.getLabelAnchor();
        java.lang.String str5 = rectangleAnchor4.toString();
        try {
            java.awt.geom.Point2D point2D6 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleAnchor.TOP_LEFT" + "'", str5.equals("RectangleAnchor.TOP_LEFT"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
        boolean boolean2 = numberAxis1.getAutoRangeIncludesZero();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.setLabelToolTip("hi!");
        int int10 = categoryPlot3.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis7);
        java.awt.Font font11 = dateAxis7.getTickLabelFont();
        java.awt.Paint paint12 = dateAxis7.getTickMarkPaint();
        numberAxis1.setTickLabelPaint(paint12);
        numberAxis1.setLabelURL("RectangleAnchor.TOP_LEFT");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setLabelToolTip("hi!");
        java.lang.String str3 = dateAxis0.getLabel();
        dateAxis0.setTickMarksVisible(true);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Font font8 = dateAxis4.getTickLabelFont();
        java.awt.Color color12 = java.awt.Color.getHSBColor((float) '4', (float) 'a', (float) 0);
        dateAxis4.setTickMarkPaint((java.awt.Paint) color12);
        org.jfree.data.Range range14 = dateAxis4.getDefaultAutoRange();
        dateAxis4.setLabelToolTip("hi!");
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color18 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        categoryPlot17.setDomainGridlinePaint((java.awt.Paint) color18);
        java.awt.Paint paint20 = categoryPlot17.getRangeCrosshairPaint();
        dateAxis4.setPlot((org.jfree.chart.plot.Plot) categoryPlot17);
        java.awt.Shape shape22 = dateAxis4.getLeftArrow();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(shape22);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.RangeType rangeType3 = numberAxis2.getRangeType();
        numberAxis0.setRangeType(rangeType3);
        java.awt.Paint paint5 = numberAxis0.getTickMarkPaint();
        org.junit.Assert.assertNotNull(rangeType3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot21.zoomRangeAxes((double) (short) 100, plotRenderingInfo25, point2D26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = null;
        xYPlot21.setDomainAxisLocation((int) (byte) 100, axisLocation29);
        java.awt.Paint paint31 = xYPlot21.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.axis.ValueAxis valueAxis34 = xYPlot21.getDomainAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Point2D point2D37 = null;
        xYPlot21.zoomRangeAxes(100.0d, plotRenderingInfo36, point2D37);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(valueAxis34);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabel("");
        dateAxis4.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = dateAxis4.getStandardTickUnits();
        boolean boolean10 = categoryPlot0.equals((java.lang.Object) dateAxis4);
        float float11 = dateAxis4.getTickMarkOutsideLength();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = null;
        java.awt.geom.Point2D point2D17 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D15, rectangleAnchor16);
        categoryPlot12.zoomRangeAxes((double) (-1), plotRenderingInfo14, point2D17);
        categoryPlot12.setBackgroundImageAlpha((float) 0L);
        boolean boolean21 = dateAxis4.equals((java.lang.Object) 0L);
        double double22 = dateAxis4.getAutoRangeMinimumSize();
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 2.0f + "'", float11 == 2.0f);
        org.junit.Assert.assertNotNull(point2D17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        xYPlot21.setRenderer(xYItemRenderer22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.lang.String str25 = color24.toString();
        xYPlot21.setDomainCrosshairPaint((java.awt.Paint) color24);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        try {
            xYPlot21.setRenderer((-1), xYItemRenderer28, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "java.awt.Color[r=0,g=128,b=128]" + "'", str25.equals("java.awt.Color[r=0,g=128,b=128]"));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        xYPlot27.setDataset(10, xYDataset29);
        org.jfree.chart.util.Layer layer32 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection33 = xYPlot27.getDomainMarkers((-1), layer32);
        java.util.Collection collection34 = xYPlot21.getRangeMarkers(0, layer32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = null;
        java.awt.geom.Point2D point2D39 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D37, rectangleAnchor38);
        xYPlot21.zoomRangeAxes((double) 0, plotRenderingInfo36, point2D39);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNotNull(layer32);
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertNotNull(point2D39);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Font font8 = dateAxis4.getTickLabelFont();
        boolean boolean9 = dateAxis4.isAxisLineVisible();
        dateAxis4.resizeRange(0.2d, (double) 10L);
        dateAxis4.setFixedAutoRange((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.awt.Stroke stroke9 = null;
        intervalMarker8.setOutlineStroke(stroke9);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        dateAxis15.setLabelToolTip("hi!");
        int int18 = categoryPlot11.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis15);
        java.util.List list19 = categoryPlot11.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = categoryPlot11.getDomainAxis(100);
        org.jfree.chart.event.PlotChangeListener plotChangeListener22 = null;
        categoryPlot11.addChangeListener(plotChangeListener22);
        categoryPlot11.setBackgroundImageAlignment(0);
        categoryPlot11.setOutlineVisible(false);
        categoryPlot11.setBackgroundImageAlpha((float) 0L);
        org.jfree.chart.util.Layer layer31 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection32 = categoryPlot11.getDomainMarkers(0, layer31);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker8, layer31);
        java.awt.Paint paint34 = categoryPlot0.getDomainGridlinePaint();
        try {
            categoryPlot0.zoom(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNull(categoryAxis21);
        org.junit.Assert.assertNotNull(layer31);
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        categoryPlot0.setRangeAxisLocation((int) ' ', axisLocation5, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("CategoryAnchor.MIDDLE");
        categoryAxis10.setMaximumCategoryLabelLines(0);
        double double13 = categoryAxis10.getUpperMargin();
        categoryAxis10.addCategoryLabelToolTip((java.lang.Comparable) (byte) -1, "");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        categoryPlot0.setRenderer(categoryItemRenderer18, false);
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot21.zoomRangeAxes((double) (short) 100, plotRenderingInfo25, point2D26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = null;
        xYPlot21.setDomainAxisLocation((int) (byte) 100, axisLocation29);
        int int31 = xYPlot21.getBackgroundImageAlignment();
        org.jfree.chart.plot.Marker marker32 = null;
        org.jfree.chart.util.Layer layer33 = null;
        try {
            xYPlot21.addDomainMarker(marker32, layer33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 15 + "'", int31 == 15);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color1);
        java.awt.Paint paint3 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryPlot0.getAxisOffset();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        java.lang.Object obj6 = categoryPlot0.clone();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.setLabelToolTip("hi!");
        categoryPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis8, false);
        categoryPlot0.setNoDataMessage("");
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot0.getRangeAxisEdge((int) (short) 1);
        org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.lang.Object obj20 = intervalMarker19.clone();
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker19);
        double double22 = intervalMarker19.getStartValue();
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent6);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        java.lang.Object obj6 = categoryPlot0.clone();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.setLabelToolTip("hi!");
        categoryPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis8, false);
        categoryPlot0.setNoDataMessage("");
        org.jfree.data.category.CategoryDataset categoryDataset16 = categoryPlot0.getDataset((int) (short) 10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.data.category.CategoryDataset categoryDataset18 = categoryPlot0.getDataset();
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNull(categoryDataset16);
        org.junit.Assert.assertNull(categoryDataset18);
    }

//    @Test
//    public void test408() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test408");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//        java.awt.Paint paint2 = defaultDrawingSupplier1.getNextPaint();
//        java.awt.Paint paint3 = defaultDrawingSupplier1.getNextFillPaint();
//        int int4 = day0.compareTo((java.lang.Object) paint3);
//        int int5 = day0.getMonth();
//        long long6 = day0.getFirstMillisecond();
//        int int7 = day0.getDayOfMonth();
//        org.junit.Assert.assertNotNull(paint2);
//        org.junit.Assert.assertNotNull(paint3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560409200000L + "'", long6 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13 + "'", int7 == 13);
//    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        java.lang.Object obj6 = categoryPlot0.clone();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier7 = categoryPlot0.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = null;
        java.awt.geom.Point2D point2D13 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D11, rectangleAnchor12);
        categoryPlot8.zoomRangeAxes((double) (-1), plotRenderingInfo10, point2D13);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        dateAxis19.setLabelToolTip("hi!");
        int int22 = categoryPlot15.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis19);
        java.awt.Font font23 = dateAxis19.getTickLabelFont();
        categoryPlot8.setNoDataMessageFont(font23);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = categoryPlot8.getDomainMarkers(layer25);
        org.jfree.chart.axis.AxisSpace axisSpace27 = null;
        categoryPlot8.setFixedRangeAxisSpace(axisSpace27, false);
        java.awt.Stroke stroke30 = categoryPlot8.getRangeCrosshairStroke();
        categoryPlot0.setDomainGridlineStroke(stroke30);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = categoryPlot0.getDomainAxisForDataset(175);
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(drawingSupplier7);
        org.junit.Assert.assertNotNull(point2D13);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNull(categoryAxis33);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        boolean boolean10 = categoryPlot0.render(graphics2D6, rectangle2D7, (int) ' ', plotRenderingInfo9);
        int int11 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        dateAxis13.setLabel("");
        boolean boolean17 = dateAxis13.isHiddenValue((long) (byte) 0);
        categoryPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis13, false);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        dateAxis20.setLabel("");
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        categoryPlot0.setRenderer(0, categoryItemRenderer25, false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.lang.Object obj3 = intervalMarker2.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = intervalMarker2.getLabelAnchor();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer5 = intervalMarker2.getGradientPaintTransformer();
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNull(gradientPaintTransformer5);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        categoryPlot0.setBackgroundImageAlpha((float) 0L);
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot0.getDataset();
        categoryPlot0.clearAnnotations();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier12 = categoryPlot0.getDrawingSupplier();
        categoryPlot0.setRangeGridlinesVisible(true);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(drawingSupplier12);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.setLabelToolTip("hi!");
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        dateAxis13.setLabel("");
        dateAxis13.setTickLabelsVisible(false);
        dateAxis13.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot20.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        dateAxis24.setLabel("");
        dateAxis24.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource29 = dateAxis24.getStandardTickUnits();
        boolean boolean30 = categoryPlot20.equals((java.lang.Object) dateAxis24);
        float float31 = dateAxis24.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis24, xYItemRenderer32);
        org.jfree.chart.axis.ValueAxis valueAxis35 = xYPlot33.getRangeAxis((int) (short) -1);
        java.awt.Paint paint36 = xYPlot33.getDomainCrosshairPaint();
        java.awt.Paint paint37 = xYPlot33.getRangeGridlinePaint();
        xYPlot33.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = xYPlot33.getRendererForDataset(xYDataset39);
        java.awt.Color color41 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        xYPlot33.setDomainGridlinePaint((java.awt.Paint) color41);
        java.awt.Color color43 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot33.setRangeTickBandPaint((java.awt.Paint) color43);
        org.jfree.chart.axis.AxisLocation axisLocation45 = xYPlot33.getRangeAxisLocation();
        categoryPlot0.setRangeAxisLocation(0, axisLocation45);
        org.jfree.chart.LegendItemCollection legendItemCollection47 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis48 = categoryPlot0.getRangeAxis();
        valueAxis48.resizeRange((double) 10.0f);
        double double51 = valueAxis48.getLowerMargin();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertNotNull(tickUnitSource29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 2.0f + "'", float31 == 2.0f);
        org.junit.Assert.assertNull(valueAxis35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNull(xYItemRenderer40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(axisLocation45);
        org.junit.Assert.assertNull(legendItemCollection47);
        org.junit.Assert.assertNotNull(valueAxis48);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.05d + "'", double51 == 0.05d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setLabel("");
        dateAxis0.resizeRange((double) (byte) 1, (double) (short) -1);
        dateAxis0.resizeRange(0.0d, (-1.0d));
        boolean boolean9 = dateAxis0.isVerticalTickLabels();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        boolean boolean26 = xYPlot21.isRangeGridlinesVisible();
        xYPlot21.clearRangeAxes();
        xYPlot21.setRangeGridlinesVisible(true);
        float float30 = xYPlot21.getBackgroundImageAlpha();
        org.jfree.chart.axis.AxisSpace axisSpace31 = null;
        xYPlot21.setFixedRangeAxisSpace(axisSpace31);
        int int33 = xYPlot21.getSeriesCount();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.5f + "'", float30 == 0.5f);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset2 = categoryPlot1.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.data.Range range4 = categoryPlot1.getDataRange(valueAxis3);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray5 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot1.setRenderers(categoryItemRendererArray5);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray9 = new org.jfree.chart.axis.ValueAxis[] { dateAxis7, dateAxis8 };
        categoryPlot1.setRangeAxes(valueAxisArray9);
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryPlot1.setNoDataMessageFont(font11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("CategoryAnchor.MIDDLE");
        categoryPlot1.setDomainAxis(categoryAxis14);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        dateAxis20.setLabelToolTip("hi!");
        int int23 = categoryPlot16.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis20);
        java.awt.Font font24 = dateAxis20.getTickLabelFont();
        boolean boolean25 = dateAxis20.isAxisLineVisible();
        dateAxis20.setAxisLineVisible(true);
        dateAxis20.setPositiveArrowVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis20, categoryItemRenderer30);
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        dateAxis36.setLabel("");
        dateAxis36.setTickLabelsVisible(false);
        dateAxis36.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot43.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis47 = new org.jfree.chart.axis.DateAxis();
        dateAxis47.setLabel("");
        dateAxis47.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource52 = dateAxis47.getStandardTickUnits();
        boolean boolean53 = categoryPlot43.equals((java.lang.Object) dateAxis47);
        float float54 = dateAxis47.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer55 = null;
        org.jfree.chart.plot.XYPlot xYPlot56 = new org.jfree.chart.plot.XYPlot(xYDataset35, (org.jfree.chart.axis.ValueAxis) dateAxis36, (org.jfree.chart.axis.ValueAxis) dateAxis47, xYItemRenderer55);
        org.jfree.chart.axis.ValueAxis valueAxis58 = xYPlot56.getRangeAxis((int) (short) -1);
        java.awt.Paint paint59 = xYPlot56.getDomainCrosshairPaint();
        java.awt.Paint paint60 = xYPlot56.getRangeGridlinePaint();
        xYPlot56.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset62 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer63 = xYPlot56.getRendererForDataset(xYDataset62);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = xYPlot56.getDomainAxisEdge();
        try {
            double double65 = categoryAxis14.getCategoryEnd((-192), 0, rectangle2D34, rectangleEdge64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(categoryItemRendererArray5);
        org.junit.Assert.assertNotNull(valueAxisArray9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(tickUnitSource52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + float54 + "' != '" + 2.0f + "'", float54 == 2.0f);
        org.junit.Assert.assertNull(valueAxis58);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNull(xYItemRenderer63);
        org.junit.Assert.assertNotNull(rectangleEdge64);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot21.getRangeAxisEdge();
        java.awt.Stroke stroke27 = xYPlot21.getOutlineStroke();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { dateAxis6, dateAxis7 };
        categoryPlot0.setRangeAxes(valueAxisArray8);
        java.util.List list10 = categoryPlot0.getCategories();
        java.lang.String str11 = categoryPlot0.getNoDataMessage();
        categoryPlot0.setRangeCrosshairValue((double) 6, true);
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(list10);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("ChartChangeEventType.NEW_DATASET");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.util.List list8 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxis(100);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        categoryPlot0.addChangeListener(plotChangeListener11);
        categoryPlot0.setBackgroundImageAlignment(0);
        categoryPlot0.setOutlineVisible(false);
        categoryPlot0.setBackgroundImageAlpha((float) 0L);
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection21 = categoryPlot0.getDomainMarkers(0, layer20);
        categoryPlot0.clearRangeAxes();
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.DateAxis dateAxis26 = new org.jfree.chart.axis.DateAxis();
        dateAxis26.setLabel("");
        dateAxis26.setTickLabelsVisible(false);
        dateAxis26.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot33.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis37 = new org.jfree.chart.axis.DateAxis();
        dateAxis37.setLabel("");
        dateAxis37.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource42 = dateAxis37.getStandardTickUnits();
        boolean boolean43 = categoryPlot33.equals((java.lang.Object) dateAxis37);
        float float44 = dateAxis37.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) dateAxis26, (org.jfree.chart.axis.ValueAxis) dateAxis37, xYItemRenderer45);
        org.jfree.chart.axis.ValueAxis valueAxis48 = xYPlot46.getRangeAxis((int) (short) -1);
        java.awt.Paint paint49 = xYPlot46.getDomainCrosshairPaint();
        java.awt.Paint paint50 = xYPlot46.getRangeGridlinePaint();
        xYPlot46.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset52 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer53 = xYPlot46.getRendererForDataset(xYDataset52);
        java.awt.Color color54 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        xYPlot46.setDomainGridlinePaint((java.awt.Paint) color54);
        java.awt.Color color56 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot46.setRangeTickBandPaint((java.awt.Paint) color56);
        org.jfree.chart.axis.AxisLocation axisLocation58 = xYPlot46.getRangeAxisLocation();
        java.awt.Paint paint59 = xYPlot46.getNoDataMessagePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = xYPlot46.getDomainAxisEdge((-14336));
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = null;
        java.awt.geom.Rectangle2D rectangle2D65 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor66 = null;
        java.awt.geom.Point2D point2D67 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D65, rectangleAnchor66);
        categoryPlot62.zoomRangeAxes((double) (-1), plotRenderingInfo64, point2D67);
        categoryPlot62.setBackgroundImageAlpha((float) 0L);
        org.jfree.data.category.CategoryDataset categoryDataset71 = categoryPlot62.getDataset();
        categoryPlot62.mapDatasetToDomainAxis(0, (int) (byte) 100);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo77 = null;
        java.awt.geom.Rectangle2D rectangle2D78 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor79 = null;
        java.awt.geom.Point2D point2D80 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D78, rectangleAnchor79);
        categoryPlot62.zoomDomainAxes((double) 1.0f, 0.05d, plotRenderingInfo77, point2D80);
        xYPlot46.setQuadrantOrigin(point2D80);
        org.jfree.chart.plot.PlotState plotState83 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo84 = null;
        try {
            categoryPlot0.draw(graphics2D23, rectangle2D24, point2D80, plotState83, plotRenderingInfo84);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertNotNull(tickUnitSource42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 2.0f + "'", float44 == 2.0f);
        org.junit.Assert.assertNull(valueAxis48);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNull(xYItemRenderer53);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(axisLocation58);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(rectangleEdge61);
        org.junit.Assert.assertNotNull(point2D67);
        org.junit.Assert.assertNull(categoryDataset71);
        org.junit.Assert.assertNotNull(point2D80);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        java.awt.Stroke stroke4 = null;
        categoryPlot0.setOutlineStroke(stroke4);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.setLabel("");
        dateAxis7.setTickLabelsVisible(false);
        dateAxis7.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        dateAxis18.setLabel("");
        dateAxis18.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource23 = dateAxis18.getStandardTickUnits();
        boolean boolean24 = categoryPlot14.equals((java.lang.Object) dateAxis18);
        float float25 = dateAxis18.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis18, xYItemRenderer26);
        org.jfree.chart.axis.ValueAxis valueAxis29 = xYPlot27.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        xYPlot27.zoomRangeAxes((double) (short) 100, plotRenderingInfo31, point2D32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = xYPlot27.getRangeAxisLocation((int) (byte) 10);
        categoryPlot0.setRangeAxisLocation(axisLocation35, false);
        categoryPlot0.mapDatasetToRangeAxis(91, (int) (byte) 100);
        org.junit.Assert.assertNotNull(tickUnitSource23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 2.0f + "'", float25 == 2.0f);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNotNull(axisLocation35);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        boolean boolean10 = categoryPlot0.render(graphics2D6, rectangle2D7, (int) ' ', plotRenderingInfo9);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = null;
        categoryPlot0.axisChanged(axisChangeEvent11);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent13 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot0.getDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = categoryPlot0.getDomainAxis(10);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNull(categoryAxis16);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot();
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        xYPlot27.setDataset(10, xYDataset29);
        org.jfree.chart.util.Layer layer32 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection33 = xYPlot27.getDomainMarkers((-1), layer32);
        java.util.Collection collection34 = xYPlot21.getRangeMarkers(0, layer32);
        int int35 = xYPlot21.getDomainAxisCount();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNotNull(layer32);
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        xYPlot21.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot21.getRendererForDataset(xYDataset27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        xYPlot21.setDomainGridlinePaint((java.awt.Paint) color29);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot21.setRangeTickBandPaint((java.awt.Paint) color31);
        java.awt.Color color33 = java.awt.Color.BLUE;
        java.awt.Color color34 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.color.ColorSpace colorSpace35 = color34.getColorSpace();
        float[] floatArray44 = new float[] { (-1.0f), (short) 100, (byte) -1, (short) 0, (byte) -1 };
        float[] floatArray45 = java.awt.Color.RGBtoHSB((int) (short) 1, (int) (byte) 0, 0, floatArray44);
        float[] floatArray46 = color33.getColorComponents(colorSpace35, floatArray45);
        org.jfree.chart.plot.IntervalMarker intervalMarker49 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor50 = intervalMarker49.getLabelAnchor();
        java.awt.Color color51 = java.awt.Color.red;
        java.awt.Color color52 = java.awt.Color.BLUE;
        java.awt.Color color53 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.color.ColorSpace colorSpace54 = color53.getColorSpace();
        float[] floatArray63 = new float[] { (-1.0f), (short) 100, (byte) -1, (short) 0, (byte) -1 };
        float[] floatArray64 = java.awt.Color.RGBtoHSB((int) (short) 1, (int) (byte) 0, 0, floatArray63);
        float[] floatArray65 = color52.getColorComponents(colorSpace54, floatArray64);
        java.awt.Color color66 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.color.ColorSpace colorSpace67 = color66.getColorSpace();
        java.awt.Color color68 = java.awt.Color.BLUE;
        java.awt.Color color69 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.color.ColorSpace colorSpace70 = color69.getColorSpace();
        float[] floatArray79 = new float[] { (-1.0f), (short) 100, (byte) -1, (short) 0, (byte) -1 };
        float[] floatArray80 = java.awt.Color.RGBtoHSB((int) (short) 1, (int) (byte) 0, 0, floatArray79);
        float[] floatArray81 = color68.getColorComponents(colorSpace70, floatArray80);
        float[] floatArray82 = color52.getComponents(colorSpace67, floatArray81);
        float[] floatArray83 = color51.getRGBComponents(floatArray82);
        boolean boolean84 = rectangleAnchor50.equals((java.lang.Object) floatArray82);
        float[] floatArray85 = color31.getColorComponents(colorSpace35, floatArray82);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(xYItemRenderer28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(colorSpace35);
        org.junit.Assert.assertNotNull(floatArray44);
        org.junit.Assert.assertNotNull(floatArray45);
        org.junit.Assert.assertNotNull(floatArray46);
        org.junit.Assert.assertNotNull(rectangleAnchor50);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(colorSpace54);
        org.junit.Assert.assertNotNull(floatArray63);
        org.junit.Assert.assertNotNull(floatArray64);
        org.junit.Assert.assertNotNull(floatArray65);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNotNull(colorSpace67);
        org.junit.Assert.assertNotNull(color68);
        org.junit.Assert.assertNotNull(color69);
        org.junit.Assert.assertNotNull(colorSpace70);
        org.junit.Assert.assertNotNull(floatArray79);
        org.junit.Assert.assertNotNull(floatArray80);
        org.junit.Assert.assertNotNull(floatArray81);
        org.junit.Assert.assertNotNull(floatArray82);
        org.junit.Assert.assertNotNull(floatArray83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(floatArray85);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint2 = defaultDrawingSupplier1.getNextPaint();
        java.awt.Paint paint3 = defaultDrawingSupplier1.getNextFillPaint();
        int int4 = day0.compareTo((java.lang.Object) paint3);
        int int5 = day0.getMonth();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.RangeType rangeType8 = numberAxis7.getRangeType();
        int int9 = day0.compareTo((java.lang.Object) numberAxis7);
        java.awt.Color color10 = java.awt.Color.magenta;
        int int11 = color10.getAlpha();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset13 = categoryPlot12.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.data.Range range15 = categoryPlot12.getDataRange(valueAxis14);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray16 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot12.setRenderers(categoryItemRendererArray16);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis19 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray20 = new org.jfree.chart.axis.ValueAxis[] { dateAxis18, dateAxis19 };
        categoryPlot12.setRangeAxes(valueAxisArray20);
        java.awt.Stroke stroke22 = categoryPlot12.getDomainGridlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day0, (java.awt.Paint) color10, stroke22);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(rangeType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 255 + "'", int11 == 255);
        org.junit.Assert.assertNull(categoryDataset13);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(categoryItemRendererArray16);
        org.junit.Assert.assertNotNull(valueAxisArray20);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot21.zoomRangeAxes((double) (short) 100, plotRenderingInfo25, point2D26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = null;
        xYPlot21.setDomainAxisLocation((int) (byte) 100, axisLocation29);
        java.awt.Paint paint31 = xYPlot21.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.axis.ValueAxis valueAxis34 = xYPlot21.getDomainAxis();
        org.jfree.chart.plot.IntervalMarker intervalMarker38 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = intervalMarker38.getLabelAnchor();
        java.awt.Stroke stroke40 = intervalMarker38.getStroke();
        org.jfree.chart.util.Layer layer41 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean43 = xYPlot21.removeRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker38, layer41, false);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent44 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) layer41);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(valueAxis34);
        org.junit.Assert.assertNotNull(rectangleAnchor39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(layer41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.setLabelToolTip("hi!");
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis7);
        java.awt.Font font11 = dateAxis7.getTickLabelFont();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        dateAxis14.setLabel("");
        dateAxis14.setTickLabelsVisible(false);
        dateAxis14.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot21.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        dateAxis25.setLabel("");
        dateAxis25.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource30 = dateAxis25.getStandardTickUnits();
        boolean boolean31 = categoryPlot21.equals((java.lang.Object) dateAxis25);
        float float32 = dateAxis25.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis25, xYItemRenderer33);
        org.jfree.chart.axis.ValueAxis valueAxis36 = xYPlot34.getRangeAxis((int) (short) -1);
        java.awt.Paint paint37 = xYPlot34.getDomainCrosshairPaint();
        java.awt.Paint paint38 = xYPlot34.getRangeGridlinePaint();
        xYPlot34.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = xYPlot34.getRendererForDataset(xYDataset40);
        xYPlot34.setRangeCrosshairValue(0.0d, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset46 = categoryPlot45.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.data.Range range48 = categoryPlot45.getDataRange(valueAxis47);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray49 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot45.setRenderers(categoryItemRendererArray49);
        java.awt.Stroke stroke51 = categoryPlot45.getOutlineStroke();
        xYPlot34.setDomainZeroBaselineStroke(stroke51);
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot54.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis58 = new org.jfree.chart.axis.DateAxis();
        dateAxis58.setLabelToolTip("hi!");
        int int61 = categoryPlot54.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis58);
        java.util.List list62 = categoryPlot54.getAnnotations();
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = categoryPlot54.getRangeAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace64 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace65 = dateAxis7.reserveSpace(graphics2D12, (org.jfree.chart.plot.Plot) xYPlot34, rectangle2D53, rectangleEdge63, axisSpace64);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(tickUnitSource30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 2.0f + "'", float32 == 2.0f);
        org.junit.Assert.assertNull(valueAxis36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNull(xYItemRenderer41);
        org.junit.Assert.assertNull(categoryDataset46);
        org.junit.Assert.assertNull(range48);
        org.junit.Assert.assertNotNull(categoryItemRendererArray49);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(list62);
        org.junit.Assert.assertNotNull(rectangleEdge63);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot21.getRangeAxisEdge();
        xYPlot21.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.TOP_RIGHT");
        org.jfree.chart.util.ObjectList objectList2 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        int int8 = categoryPlot3.getIndexOf(categoryItemRenderer7);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot3.getDomainGridlinePosition();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        int int11 = categoryPlot3.getIndexOf(categoryItemRenderer10);
        boolean boolean12 = objectList2.equals((java.lang.Object) categoryPlot3);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier13 = categoryPlot3.getDrawingSupplier();
        boolean boolean14 = numberAxis1.equals((java.lang.Object) drawingSupplier13);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(drawingSupplier13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot21.zoomRangeAxes((double) (short) 100, plotRenderingInfo25, point2D26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = null;
        xYPlot21.setDomainAxisLocation((int) (byte) 100, axisLocation29);
        java.awt.Paint paint31 = xYPlot21.getDomainTickBandPaint();
        xYPlot21.mapDatasetToRangeAxis((int) '4', 15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = null;
        java.awt.geom.Point2D point2D42 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D40, rectangleAnchor41);
        categoryPlot37.zoomRangeAxes((double) (-1), plotRenderingInfo39, point2D42);
        try {
            xYPlot21.zoomDomainAxes(0.0d, plotRenderingInfo36, point2D42, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertNotNull(point2D42);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        boolean boolean26 = xYPlot21.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, 0.0d, (double) (-1L), 100.0d);
        double double33 = rectangleInsets31.calculateRightOutset((double) (byte) 10);
        xYPlot21.setAxisOffset(rectangleInsets31);
        xYPlot21.clearDomainMarkers(7);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 100.0d + "'", double33 == 100.0d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot21.zoomRangeAxes((double) (short) 100, plotRenderingInfo25, point2D26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = null;
        xYPlot21.setDomainAxisLocation((int) (byte) 100, axisLocation29);
        java.awt.Paint paint31 = xYPlot21.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.chart.axis.ValueAxis valueAxis34 = xYPlot21.getDomainAxis();
        org.jfree.chart.plot.IntervalMarker intervalMarker38 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = intervalMarker38.getLabelAnchor();
        java.awt.Stroke stroke40 = intervalMarker38.getStroke();
        org.jfree.chart.util.Layer layer41 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean43 = xYPlot21.removeRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker38, layer41, false);
        java.awt.Stroke stroke44 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        xYPlot21.setDomainCrosshairStroke(stroke44);
        xYPlot21.clearDomainAxes();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(valueAxis34);
        org.junit.Assert.assertNotNull(rectangleAnchor39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(layer41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(stroke44);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        xYPlot21.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot21.getRendererForDataset(xYDataset27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        xYPlot21.setDomainGridlinePaint((java.awt.Paint) color29);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot21.setRangeTickBandPaint((java.awt.Paint) color31);
        org.jfree.chart.axis.AxisLocation axisLocation33 = xYPlot21.getRangeAxisLocation();
        java.awt.Paint paint34 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        xYPlot21.setDomainZeroBaselinePaint(paint34);
        xYPlot21.setRangeCrosshairVisible(false);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(xYItemRenderer28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        int int1 = objectList0.size();
        java.lang.Object obj3 = objectList0.get((int) (short) 1);
        objectList0.clear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        int int1 = objectList0.size();
        java.lang.Object obj2 = objectList0.clone();
        int int3 = objectList0.size();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.setLabelToolTip("hi!");
        int int11 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis8);
        java.awt.Font font12 = dateAxis8.getTickLabelFont();
        boolean boolean13 = dateAxis8.isAxisLineVisible();
        boolean boolean14 = objectList0.equals((java.lang.Object) boolean13);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Paint paint2 = defaultDrawingSupplier1.getNextPaint();
        java.awt.Paint paint3 = defaultDrawingSupplier1.getNextFillPaint();
        int int4 = day0.compareTo((java.lang.Object) paint3);
        int int5 = day0.getMonth();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.RangeType rangeType8 = numberAxis7.getRangeType();
        int int9 = day0.compareTo((java.lang.Object) numberAxis7);
        boolean boolean10 = numberAxis7.isInverted();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        dateAxis14.setLabel("");
        dateAxis14.setTickLabelsVisible(false);
        dateAxis14.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot21.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        dateAxis25.setLabel("");
        dateAxis25.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource30 = dateAxis25.getStandardTickUnits();
        boolean boolean31 = categoryPlot21.equals((java.lang.Object) dateAxis25);
        float float32 = dateAxis25.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = null;
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) dateAxis14, (org.jfree.chart.axis.ValueAxis) dateAxis25, xYItemRenderer33);
        org.jfree.chart.plot.IntervalMarker intervalMarker37 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot34.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker37);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = xYPlot34.getDomainAxisEdge((int) ' ');
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        xYPlot34.setRenderer((int) (short) 100, xYItemRenderer42, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = xYPlot34.getDomainAxisEdge((int) (byte) -1);
        try {
            double double47 = numberAxis7.java2DToValue((double) (byte) -1, rectangle2D12, rectangleEdge46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(rangeType8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(tickUnitSource30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + float32 + "' != '" + 2.0f + "'", float32 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertNotNull(rectangleEdge46);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot21.zoomRangeAxes((double) (short) 100, plotRenderingInfo25, point2D26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = null;
        xYPlot21.setDomainAxisLocation((int) (byte) 100, axisLocation29);
        java.awt.Paint paint31 = xYPlot21.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        int int35 = xYPlot21.indexOf(xYDataset34);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder36 = xYPlot21.getDatasetRenderingOrder();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        try {
            xYPlot21.handleClick((int) 'a', 255, plotRenderingInfo39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(datasetRenderingOrder36);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        boolean boolean10 = categoryPlot0.render(graphics2D6, rectangle2D7, (int) ' ', plotRenderingInfo9);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot0.getDomainAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setLabel("");
        dateAxis16.setTickLabelsVisible(false);
        dateAxis16.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot23.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis27 = new org.jfree.chart.axis.DateAxis();
        dateAxis27.setLabel("");
        dateAxis27.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource32 = dateAxis27.getStandardTickUnits();
        boolean boolean33 = categoryPlot23.equals((java.lang.Object) dateAxis27);
        float float34 = dateAxis27.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) dateAxis16, (org.jfree.chart.axis.ValueAxis) dateAxis27, xYItemRenderer35);
        org.jfree.chart.axis.ValueAxis valueAxis38 = xYPlot36.getRangeAxis((int) (short) -1);
        java.awt.Paint paint39 = xYPlot36.getDomainCrosshairPaint();
        java.awt.Paint paint40 = xYPlot36.getRangeGridlinePaint();
        xYPlot36.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = xYPlot36.getRendererForDataset(xYDataset42);
        java.awt.Color color44 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        xYPlot36.setDomainGridlinePaint((java.awt.Paint) color44);
        java.awt.Color color46 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot36.setRangeTickBandPaint((java.awt.Paint) color46);
        org.jfree.chart.axis.AxisLocation axisLocation48 = xYPlot36.getRangeAxisLocation();
        java.awt.Paint paint49 = xYPlot36.getNoDataMessagePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = xYPlot36.getDomainAxisEdge((-14336));
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor56 = null;
        java.awt.geom.Point2D point2D57 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D55, rectangleAnchor56);
        categoryPlot52.zoomRangeAxes((double) (-1), plotRenderingInfo54, point2D57);
        categoryPlot52.setBackgroundImageAlpha((float) 0L);
        org.jfree.data.category.CategoryDataset categoryDataset61 = categoryPlot52.getDataset();
        categoryPlot52.mapDatasetToDomainAxis(0, (int) (byte) 100);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo67 = null;
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor69 = null;
        java.awt.geom.Point2D point2D70 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D68, rectangleAnchor69);
        categoryPlot52.zoomDomainAxes((double) 1.0f, 0.05d, plotRenderingInfo67, point2D70);
        xYPlot36.setQuadrantOrigin(point2D70);
        categoryPlot0.zoomRangeAxes((double) 1.0f, (double) 10, plotRenderingInfo14, point2D70);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(categoryAxis11);
        org.junit.Assert.assertNotNull(tickUnitSource32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 2.0f + "'", float34 == 2.0f);
        org.junit.Assert.assertNull(valueAxis38);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNull(xYItemRenderer43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(axisLocation48);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(rectangleEdge51);
        org.junit.Assert.assertNotNull(point2D57);
        org.junit.Assert.assertNull(categoryDataset61);
        org.junit.Assert.assertNotNull(point2D70);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (-101.0d), jFreeChart1, chartChangeEventType2);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.util.List list8 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxis(100);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        categoryPlot0.addChangeListener(plotChangeListener11);
        org.jfree.chart.plot.IntervalMarker intervalMarker15 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.lang.Object obj16 = intervalMarker15.clone();
        java.awt.Paint paint17 = intervalMarker15.getLabelPaint();
        boolean boolean18 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker15);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = intervalMarker15.getLabelAnchor();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.extendHeight((double) 255);
        double double4 = rectangleInsets0.calculateRightOutset(100.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 259.0d + "'", double2 == 259.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        java.awt.Stroke stroke7 = null;
        categoryPlot0.setOutlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace9, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setLabelToolTip("hi!");
        int int19 = categoryPlot12.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis16);
        java.awt.Font font20 = dateAxis16.getTickLabelFont();
        boolean boolean21 = dateAxis16.isAxisLineVisible();
        dateAxis16.setAxisLineVisible(true);
        dateAxis16.setPositiveArrowVisible(true);
        float float26 = dateAxis16.getTickMarkOutsideLength();
        int int27 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis16);
        org.jfree.data.Range range28 = dateAxis16.getDefaultAutoRange();
        dateAxis16.setTickMarkInsideLength(0.0f);
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_RED;
        dateAxis16.setLabelPaint((java.awt.Paint) color31);
        java.lang.String str33 = color31.toString();
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 2.0f + "'", float26 == 2.0f);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "java.awt.Color[r=255,g=64,b=64]" + "'", str33.equals("java.awt.Color[r=255,g=64,b=64]"));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.setLabelToolTip("hi!");
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis7);
        dateAxis7.setLabelURL("RectangleAnchor.BOTTOM_LEFT");
        java.util.TimeZone timeZone13 = dateAxis7.getTimeZone();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertNotNull(timeZone13);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        java.lang.Object obj4 = categoryPlot0.clone();
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot0.getFixedRangeAxisSpace();
        double double6 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot0.getLegendItems();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot8.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.data.Range range11 = categoryPlot8.getDataRange(valueAxis10);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray12 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot8.setRenderers(categoryItemRendererArray12);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray16 = new org.jfree.chart.axis.ValueAxis[] { dateAxis14, dateAxis15 };
        categoryPlot8.setRangeAxes(valueAxisArray16);
        java.awt.Font font18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryPlot8.setNoDataMessageFont(font18);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot20.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        int int25 = categoryPlot20.getIndexOf(categoryItemRenderer24);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor26 = categoryPlot20.getDomainGridlinePosition();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        int int28 = categoryPlot20.getIndexOf(categoryItemRenderer27);
        java.awt.Paint paint29 = categoryPlot20.getOutlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation30 = categoryPlot20.getDomainAxisLocation();
        categoryPlot8.setDomainAxisLocation(axisLocation30, false);
        categoryPlot0.setDomainAxisLocation(axisLocation30, true);
        org.jfree.chart.axis.DateAxis dateAxis36 = new org.jfree.chart.axis.DateAxis();
        dateAxis36.setLabel("");
        dateAxis36.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource41 = dateAxis36.getStandardTickUnits();
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor46 = null;
        java.awt.geom.Point2D point2D47 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D45, rectangleAnchor46);
        categoryPlot42.zoomRangeAxes((double) (-1), plotRenderingInfo44, point2D47);
        java.awt.Stroke stroke49 = null;
        categoryPlot42.setOutlineStroke(stroke49);
        dateAxis36.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot42);
        categoryPlot0.setRangeAxis((int) (short) 10, (org.jfree.chart.axis.ValueAxis) dateAxis36);
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray12);
        org.junit.Assert.assertNotNull(valueAxisArray16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(tickUnitSource41);
        org.junit.Assert.assertNotNull(point2D47);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        categoryPlot0.setRangeAxisLocation((int) ' ', axisLocation5, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("CategoryAnchor.MIDDLE");
        categoryAxis10.setMaximumCategoryLabelLines(0);
        double double13 = categoryAxis10.getUpperMargin();
        categoryAxis10.addCategoryLabelToolTip((java.lang.Comparable) (byte) -1, "");
        categoryPlot0.setDomainAxis((int) (byte) 0, categoryAxis10);
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = null;
        java.awt.geom.Point2D point2D24 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D22, rectangleAnchor23);
        categoryPlot19.zoomRangeAxes((double) (-1), plotRenderingInfo21, point2D24);
        categoryPlot19.setBackgroundImageAlpha((float) 0L);
        org.jfree.data.category.CategoryDataset categoryDataset28 = categoryPlot19.getDataset();
        java.awt.Font font29 = categoryPlot19.getNoDataMessageFont();
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        dateAxis32.setLabel("");
        dateAxis32.setTickLabelsVisible(false);
        dateAxis32.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot39.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis43 = new org.jfree.chart.axis.DateAxis();
        dateAxis43.setLabel("");
        dateAxis43.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource48 = dateAxis43.getStandardTickUnits();
        boolean boolean49 = categoryPlot39.equals((java.lang.Object) dateAxis43);
        float float50 = dateAxis43.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = null;
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot(xYDataset31, (org.jfree.chart.axis.ValueAxis) dateAxis32, (org.jfree.chart.axis.ValueAxis) dateAxis43, xYItemRenderer51);
        org.jfree.chart.axis.ValueAxis valueAxis54 = xYPlot52.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = null;
        java.awt.geom.Point2D point2D57 = null;
        xYPlot52.zoomRangeAxes((double) (short) 100, plotRenderingInfo56, point2D57);
        org.jfree.chart.axis.AxisLocation axisLocation60 = null;
        xYPlot52.setDomainAxisLocation((int) (byte) 100, axisLocation60);
        java.awt.Paint paint62 = xYPlot52.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = xYPlot52.getRangeAxisEdge(0);
        org.jfree.chart.axis.AxisSpace axisSpace65 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace66 = categoryAxis10.reserveSpace(graphics2D18, (org.jfree.chart.plot.Plot) categoryPlot19, rectangle2D30, rectangleEdge64, axisSpace65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
        org.junit.Assert.assertNotNull(point2D24);
        org.junit.Assert.assertNull(categoryDataset28);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(tickUnitSource48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + float50 + "' != '" + 2.0f + "'", float50 == 2.0f);
        org.junit.Assert.assertNull(valueAxis54);
        org.junit.Assert.assertNull(paint62);
        org.junit.Assert.assertNotNull(rectangleEdge64);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.junit.Assert.assertNotNull(numberTickUnit0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        categoryPlot0.setBackgroundImageAlpha((float) 0L);
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot0.getDataset();
        categoryPlot0.clearAnnotations();
        double double11 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation12);
        java.lang.String str14 = axisLocation12.toString();
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str14.equals("AxisLocation.BOTTOM_OR_RIGHT"));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        int int27 = xYPlot21.getIndexOf(xYItemRenderer26);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot21.zoomRangeAxes((double) (short) 100, plotRenderingInfo25, point2D26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = null;
        xYPlot21.setDomainAxisLocation((int) (byte) 100, axisLocation29);
        java.awt.Paint paint31 = xYPlot21.getDomainTickBandPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = xYPlot21.getRangeAxisEdge(0);
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        int int35 = xYPlot21.indexOf(xYDataset34);
        org.jfree.data.xy.XYDataset xYDataset37 = xYPlot21.getDataset((int) '4');
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNull(xYDataset37);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.setLabelToolTip("hi!");
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis7);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        dateAxis13.setLabel("");
        dateAxis13.setTickLabelsVisible(false);
        dateAxis13.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot20.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis24 = new org.jfree.chart.axis.DateAxis();
        dateAxis24.setLabel("");
        dateAxis24.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource29 = dateAxis24.getStandardTickUnits();
        boolean boolean30 = categoryPlot20.equals((java.lang.Object) dateAxis24);
        float float31 = dateAxis24.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) dateAxis13, (org.jfree.chart.axis.ValueAxis) dateAxis24, xYItemRenderer32);
        org.jfree.chart.axis.ValueAxis valueAxis35 = xYPlot33.getRangeAxis((int) (short) -1);
        java.awt.Paint paint36 = xYPlot33.getDomainCrosshairPaint();
        java.awt.Paint paint37 = xYPlot33.getRangeGridlinePaint();
        xYPlot33.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = xYPlot33.getRendererForDataset(xYDataset39);
        java.awt.Color color41 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        xYPlot33.setDomainGridlinePaint((java.awt.Paint) color41);
        java.awt.Color color43 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot33.setRangeTickBandPaint((java.awt.Paint) color43);
        org.jfree.chart.axis.AxisLocation axisLocation45 = xYPlot33.getRangeAxisLocation();
        categoryPlot0.setRangeAxisLocation(0, axisLocation45);
        org.jfree.chart.LegendItemCollection legendItemCollection47 = categoryPlot0.getFixedLegendItems();
        org.jfree.data.general.DatasetGroup datasetGroup48 = categoryPlot0.getDatasetGroup();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor6);
        org.junit.Assert.assertNotNull(tickUnitSource29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 2.0f + "'", float31 == 2.0f);
        org.junit.Assert.assertNull(valueAxis35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNull(xYItemRenderer40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(axisLocation45);
        org.junit.Assert.assertNull(legendItemCollection47);
        org.junit.Assert.assertNull(datasetGroup48);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        java.awt.Color color2 = java.awt.Color.getColor("TextAnchor.CENTER_LEFT", 100);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        java.lang.Object obj4 = categoryPlot0.clone();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot0.removeChangeListener(plotChangeListener5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        dateAxis11.setLabelToolTip("hi!");
        int int14 = categoryPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.util.List list15 = categoryPlot7.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = categoryPlot7.getDomainAxis(100);
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        categoryPlot7.addChangeListener(plotChangeListener18);
        java.lang.String str20 = categoryPlot7.getNoDataMessage();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot21.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis25 = new org.jfree.chart.axis.DateAxis();
        dateAxis25.setLabelToolTip("hi!");
        int int28 = categoryPlot21.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis25);
        java.util.List list29 = categoryPlot21.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = categoryPlot21.getDomainAxis(100);
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        categoryPlot21.addChangeListener(plotChangeListener32);
        categoryPlot21.setBackgroundImageAlignment(0);
        categoryPlot21.setOutlineVisible(false);
        categoryPlot21.setBackgroundImageAlpha((float) 0L);
        java.awt.Stroke stroke40 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryPlot21.setRangeCrosshairStroke(stroke40);
        categoryPlot7.setDomainGridlineStroke(stroke40);
        categoryPlot0.setRangeGridlineStroke(stroke40);
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNull(categoryAxis17);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNull(categoryAxis31);
        org.junit.Assert.assertNotNull(stroke40);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        int int2 = categoryPlot0.getDatasetCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge();
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis11 = new org.jfree.chart.axis.DateAxis();
        dateAxis11.setLabelToolTip("hi!");
        int int14 = categoryPlot7.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis11);
        java.awt.Font font15 = dateAxis11.getTickLabelFont();
        categoryPlot0.setNoDataMessageFont(font15);
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot0.setDomainAxisLocation((int) (byte) 100, axisLocation18, true);
        categoryPlot0.setNoDataMessage("SeriesRenderingOrder.REVERSE");
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(axisLocation18);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabel("");
        dateAxis4.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource9 = dateAxis4.getStandardTickUnits();
        boolean boolean10 = categoryPlot0.equals((java.lang.Object) dateAxis4);
        int int11 = categoryPlot0.getDomainAxisCount();
        org.junit.Assert.assertNotNull(tickUnitSource9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        xYPlot21.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot21.getRendererForDataset(xYDataset27);
        xYPlot21.setRangeCrosshairValue(0.0d, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = xYPlot21.getDomainAxis(100);
        org.jfree.chart.plot.IntervalMarker intervalMarker36 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = intervalMarker36.getLabelAnchor();
        intervalMarker36.setLabel("RectangleAnchor.BOTTOM_LEFT");
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker36);
        java.awt.Graphics2D graphics2D41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        try {
            xYPlot21.drawBackground(graphics2D41, rectangle2D42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(xYItemRenderer28);
        org.junit.Assert.assertNull(valueAxis33);
        org.junit.Assert.assertNotNull(rectangleAnchor37);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        java.awt.Color color0 = java.awt.Color.blue;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        categoryPlot0.setBackgroundImageAlpha((float) 0L);
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot0.getDataset();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot0.setRenderer(0, categoryItemRenderer11, false);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range15 = dateAxis14.getRange();
        org.jfree.data.Range range16 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.chart.axis.Timeline timeline17 = dateAxis14.getTimeline();
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(timeline17);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        java.lang.Object obj6 = categoryPlot0.clone();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.setLabelToolTip("hi!");
        categoryPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis8, false);
        categoryPlot0.setNoDataMessage("");
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot0.getRangeAxisEdge((int) (short) 1);
        org.jfree.chart.LegendItemCollection legendItemCollection17 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = categoryPlot0.getDomainMarkers(layer18);
        int int20 = categoryPlot0.getWeight();
        java.lang.Object obj21 = categoryPlot0.clone();
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNull(legendItemCollection17);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        xYPlot21.setRangeCrosshairLockedOnData(true);
        xYPlot21.setDomainCrosshairValue((double) (-16646144), false);
        java.lang.Object obj31 = xYPlot21.clone();
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        xYPlot21.setFixedRangeAxisSpace(axisSpace32, false);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNotNull(obj31);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        categoryPlot0.setBackgroundImageAlpha((float) 0L);
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot0.getDataset();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset11 = categoryPlot10.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.data.Range range13 = categoryPlot10.getDataRange(valueAxis12);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot10.setRenderers(categoryItemRendererArray14);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray18 = new org.jfree.chart.axis.ValueAxis[] { dateAxis16, dateAxis17 };
        categoryPlot10.setRangeAxes(valueAxisArray18);
        java.util.List list20 = categoryPlot10.getCategories();
        java.lang.String str21 = categoryPlot10.getNoDataMessage();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot10);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNull(categoryDataset11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
        org.junit.Assert.assertNotNull(valueAxisArray18);
        org.junit.Assert.assertNull(list20);
        org.junit.Assert.assertNull(str21);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        java.awt.Stroke stroke4 = null;
        categoryPlot0.setOutlineStroke(stroke4);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.setLabel("");
        dateAxis7.setTickLabelsVisible(false);
        dateAxis7.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        dateAxis18.setLabel("");
        dateAxis18.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource23 = dateAxis18.getStandardTickUnits();
        boolean boolean24 = categoryPlot14.equals((java.lang.Object) dateAxis18);
        float float25 = dateAxis18.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis18, xYItemRenderer26);
        org.jfree.chart.axis.ValueAxis valueAxis29 = xYPlot27.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        xYPlot27.zoomRangeAxes((double) (short) 100, plotRenderingInfo31, point2D32);
        org.jfree.chart.axis.AxisLocation axisLocation35 = xYPlot27.getRangeAxisLocation((int) (byte) 10);
        categoryPlot0.setRangeAxisLocation(axisLocation35, false);
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder39 = xYPlot38.getDatasetRenderingOrder();
        xYPlot38.setDomainZeroBaselineVisible(false);
        xYPlot38.setNoDataMessage("ChartChangeEventType.NEW_DATASET");
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) xYPlot38);
        org.junit.Assert.assertNotNull(tickUnitSource23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 2.0f + "'", float25 == 2.0f);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(datasetRenderingOrder39);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.awt.Font font8 = dateAxis4.getTickLabelFont();
        boolean boolean9 = dateAxis4.isAxisLineVisible();
        dateAxis4.setAxisLineVisible(true);
        dateAxis4.setPositiveArrowVisible(false);
        org.jfree.data.Range range14 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis4.setRange(range14, false, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = null;
        java.awt.geom.Point2D point2D23 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D21, rectangleAnchor22);
        categoryPlot18.zoomRangeAxes((double) (-1), plotRenderingInfo20, point2D23);
        java.awt.Stroke stroke25 = null;
        categoryPlot18.setOutlineStroke(stroke25);
        dateAxis4.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot18);
        java.awt.Image image28 = categoryPlot18.getBackgroundImage();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertNotNull(point2D23);
        org.junit.Assert.assertNull(image28);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        dateAxis2.setLabel("");
        dateAxis2.setTickLabelsVisible(false);
        dateAxis2.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        dateAxis13.setLabel("");
        dateAxis13.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = dateAxis13.getStandardTickUnits();
        boolean boolean19 = categoryPlot9.equals((java.lang.Object) dateAxis13);
        float float20 = dateAxis13.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) dateAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis13, xYItemRenderer21);
        org.jfree.chart.plot.IntervalMarker intervalMarker25 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot22.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker25);
        org.jfree.chart.plot.IntervalMarker intervalMarker29 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.awt.Stroke stroke30 = null;
        intervalMarker29.setOutlineStroke(stroke30);
        boolean boolean32 = xYPlot22.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker29);
        intervalMarker29.setLabel("hi!");
        boolean boolean35 = datasetRenderingOrder0.equals((java.lang.Object) "hi!");
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 2.0f + "'", float20 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        org.jfree.chart.plot.IntervalMarker intervalMarker28 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.awt.Stroke stroke29 = null;
        intervalMarker28.setOutlineStroke(stroke29);
        boolean boolean31 = xYPlot21.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker28);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent32 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) boolean31);
        org.jfree.chart.JFreeChart jFreeChart33 = null;
        chartChangeEvent32.setChart(jFreeChart33);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        categoryPlot0.setBackgroundImageAlpha((float) 0L);
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot0.getDataset();
        categoryPlot0.clearAnnotations();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        org.jfree.chart.util.ObjectList objectList15 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        int int21 = categoryPlot16.getIndexOf(categoryItemRenderer20);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor22 = categoryPlot16.getDomainGridlinePosition();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        int int24 = categoryPlot16.getIndexOf(categoryItemRenderer23);
        boolean boolean25 = objectList15.equals((java.lang.Object) categoryPlot16);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier26 = categoryPlot16.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot27.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis31 = new org.jfree.chart.axis.DateAxis();
        dateAxis31.setLabelToolTip("hi!");
        int int34 = categoryPlot27.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis31);
        java.util.List list35 = categoryPlot27.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = categoryPlot27.getDomainAxis(100);
        org.jfree.chart.event.PlotChangeListener plotChangeListener38 = null;
        categoryPlot27.addChangeListener(plotChangeListener38);
        categoryPlot27.setBackgroundImageAlignment(0);
        categoryPlot27.setOutlineVisible(false);
        categoryPlot27.setBackgroundImageAlpha((float) 0L);
        org.jfree.chart.util.Layer layer47 = org.jfree.chart.util.Layer.BACKGROUND;
        java.util.Collection collection48 = categoryPlot27.getDomainMarkers(0, layer47);
        java.util.Collection collection49 = categoryPlot16.getRangeMarkers(layer47);
        boolean boolean50 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker14, layer47);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(drawingSupplier26);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertNull(categoryAxis37);
        org.junit.Assert.assertNotNull(layer47);
        org.junit.Assert.assertNull(collection48);
        org.junit.Assert.assertNotNull(collection49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.util.List list8 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxis(100);
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        categoryPlot0.addChangeListener(plotChangeListener11);
        org.jfree.chart.plot.IntervalMarker intervalMarker15 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.lang.Object obj16 = intervalMarker15.clone();
        java.awt.Paint paint17 = intervalMarker15.getLabelPaint();
        boolean boolean18 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker15);
        java.lang.String str19 = intervalMarker15.getLabel();
        float float20 = intervalMarker15.getAlpha();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(str19);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.8f + "'", float20 == 0.8f);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("TextAnchor.TOP_RIGHT");
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot2.getDataset();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace4, true);
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot2);
        numberAxis1.setLowerMargin(0.0d);
        boolean boolean10 = numberAxis1.getAutoRangeStickyZero();
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        java.awt.Stroke stroke7 = null;
        categoryPlot0.setOutlineStroke(stroke7);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace9, false);
        categoryPlot0.clearRangeMarkers(1);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        dateAxis18.setLabelToolTip("hi!");
        int int21 = categoryPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis18);
        java.util.List list22 = categoryPlot14.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = categoryPlot14.getDomainAxis(100);
        org.jfree.chart.event.PlotChangeListener plotChangeListener25 = null;
        categoryPlot14.addChangeListener(plotChangeListener25);
        categoryPlot14.setBackgroundImageAlignment(0);
        java.lang.String str29 = categoryPlot14.getPlotType();
        categoryPlot14.setAnchorValue((double) 1);
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.axis.DateAxis dateAxis34 = new org.jfree.chart.axis.DateAxis();
        dateAxis34.setLabel("");
        dateAxis34.setTickLabelsVisible(false);
        dateAxis34.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot41.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis45 = new org.jfree.chart.axis.DateAxis();
        dateAxis45.setLabel("");
        dateAxis45.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource50 = dateAxis45.getStandardTickUnits();
        boolean boolean51 = categoryPlot41.equals((java.lang.Object) dateAxis45);
        float float52 = dateAxis45.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer53 = null;
        org.jfree.chart.plot.XYPlot xYPlot54 = new org.jfree.chart.plot.XYPlot(xYDataset33, (org.jfree.chart.axis.ValueAxis) dateAxis34, (org.jfree.chart.axis.ValueAxis) dateAxis45, xYItemRenderer53);
        org.jfree.chart.axis.ValueAxis valueAxis56 = xYPlot54.getRangeAxis((int) (short) -1);
        java.awt.Paint paint57 = xYPlot54.getDomainCrosshairPaint();
        java.awt.Paint paint58 = xYPlot54.getRangeGridlinePaint();
        xYPlot54.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset60 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer61 = xYPlot54.getRendererForDataset(xYDataset60);
        java.awt.Color color62 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        xYPlot54.setDomainGridlinePaint((java.awt.Paint) color62);
        java.awt.Color color64 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot54.setRangeTickBandPaint((java.awt.Paint) color64);
        org.jfree.chart.axis.AxisLocation axisLocation66 = xYPlot54.getRangeAxisLocation();
        categoryPlot14.setRangeAxisLocation(100, axisLocation66);
        categoryPlot0.setRangeAxisLocation(axisLocation66);
        categoryPlot0.setOutlineVisible(false);
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNull(categoryAxis24);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Category Plot" + "'", str29.equals("Category Plot"));
        org.junit.Assert.assertNotNull(tickUnitSource50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + float52 + "' != '" + 2.0f + "'", float52 == 2.0f);
        org.junit.Assert.assertNull(valueAxis56);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNull(xYItemRenderer61);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(axisLocation66);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str1 = plotOrientation0.toString();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str1.equals("PlotOrientation.HORIZONTAL"));
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        int int1 = objectList0.size();
        java.lang.Object obj3 = objectList0.get((int) (short) 1);
        int int4 = objectList0.size();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot21.getRangeAxisEdge();
        java.lang.Object obj27 = xYPlot21.clone();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(obj27);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L, (java.awt.Paint) color1, stroke2);
        org.jfree.chart.util.ObjectList objectList4 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        int int10 = categoryPlot5.getIndexOf(categoryItemRenderer9);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor11 = categoryPlot5.getDomainGridlinePosition();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        int int13 = categoryPlot5.getIndexOf(categoryItemRenderer12);
        boolean boolean14 = objectList4.equals((java.lang.Object) categoryPlot5);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = categoryPlot5.getDrawingSupplier();
        java.lang.Class<?> wildcardClass16 = drawingSupplier15.getClass();
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
        try {
            java.util.EventListener[] eventListenerArray18 = categoryMarker3.getListeners((java.lang.Class) wildcardClass16);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [Lorg.jfree.chart.plot.DefaultDrawingSupplier; cannot be cast to [Ljava.util.EventListener;");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(drawingSupplier15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(class17);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabelToolTip("hi!");
        int int7 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis4);
        java.util.List list8 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxis(100);
        categoryPlot0.setDomainGridlinesVisible(true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNull(categoryAxis10);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.setLabelToolTip("hi!");
        java.lang.String str3 = dateAxis0.getLabel();
        java.awt.Paint paint4 = dateAxis0.getTickLabelPaint();
        java.awt.Shape shape5 = dateAxis0.getRightArrow();
        boolean boolean6 = dateAxis0.isPositiveArrowVisible();
        dateAxis0.setRangeWithMargins(0.0d, (double) 91);
        dateAxis0.setAutoRangeMinimumSize((double) 4, false);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        xYPlot21.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot21.getRendererForDataset(xYDataset27);
        xYPlot21.setRangeCrosshairValue(0.0d, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = xYPlot21.getDomainAxis(100);
        java.awt.Paint paint34 = xYPlot21.getRangeGridlinePaint();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(xYItemRenderer28);
        org.junit.Assert.assertNull(valueAxis33);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        xYPlot21.clearDomainAxes();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = xYPlot21.getRangeAxisEdge();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        java.lang.Object obj6 = categoryPlot0.clone();
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        dateAxis8.setLabelToolTip("hi!");
        categoryPlot0.setRangeAxis((int) '#', (org.jfree.chart.axis.ValueAxis) dateAxis8, false);
        categoryPlot0.clearAnnotations();
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = null;
        java.awt.geom.Point2D point2D5 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D3, rectangleAnchor4);
        categoryPlot0.zoomRangeAxes((double) (-1), plotRenderingInfo2, point2D5);
        categoryPlot0.setBackgroundImageAlpha((float) 0L);
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot0.getDataset();
        categoryPlot0.clearDomainAxes();
        org.junit.Assert.assertNotNull(point2D5);
        org.junit.Assert.assertNull(categoryDataset9);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        xYPlot21.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = xYPlot21.getRendererForDataset(xYDataset27);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot21.getDomainAxisEdge();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset32 = categoryPlot31.getDataset();
        boolean boolean33 = rectangleAnchor30.equals((java.lang.Object) categoryPlot31);
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_RED;
        categoryPlot31.setNoDataMessagePaint((java.awt.Paint) color34);
        xYPlot21.setDomainCrosshairPaint((java.awt.Paint) color34);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = new org.jfree.chart.util.RectangleInsets((double) (short) 10, 0.0d, (double) (-1L), 100.0d);
        xYPlot21.setAxisOffset(rectangleInsets41);
        java.awt.Paint paint43 = null;
        xYPlot21.setOutlinePaint(paint43);
        boolean boolean45 = xYPlot21.isRangeCrosshairVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot46.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
        int int51 = categoryPlot46.getIndexOf(categoryItemRenderer50);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor52 = categoryPlot46.getDomainGridlinePosition();
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis();
        dateAxis53.setLabelToolTip("hi!");
        categoryPlot46.setRangeAxis((org.jfree.chart.axis.ValueAxis) dateAxis53);
        dateAxis53.setLabelURL("RectangleAnchor.BOTTOM_LEFT");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType59 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.awt.Shape shape60 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        boolean boolean61 = lengthAdjustmentType59.equals((java.lang.Object) shape60);
        dateAxis53.setRightArrow(shape60);
        int int63 = xYPlot21.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis53);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(xYItemRenderer28);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(rectangleAnchor30);
        org.junit.Assert.assertNull(categoryDataset32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor52);
        org.junit.Assert.assertNotNull(lengthAdjustmentType59);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        boolean boolean10 = categoryPlot0.render(graphics2D6, rectangle2D7, (int) ' ', plotRenderingInfo9);
        int int11 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        dateAxis13.setLabel("");
        boolean boolean17 = dateAxis13.isHiddenValue((long) (byte) 0);
        categoryPlot0.setRangeAxis(0, (org.jfree.chart.axis.ValueAxis) dateAxis13, false);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        java.awt.Shape shape21 = dateAxis20.getUpArrow();
        dateAxis20.setVisible(true);
        org.jfree.chart.axis.Timeline timeline24 = null;
        dateAxis20.setTimeline(timeline24);
        java.awt.Shape shape26 = dateAxis20.getUpArrow();
        dateAxis13.setRightArrow(shape26);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(shape26);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.RangeType rangeType3 = numberAxis2.getRangeType();
        numberAxis0.setRangeType(rangeType3);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = null;
        try {
            numberAxis0.setTickUnit(numberTickUnit5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rangeType3);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        java.awt.Paint paint24 = xYPlot21.getDomainCrosshairPaint();
        java.awt.Paint paint25 = xYPlot21.getRangeGridlinePaint();
        boolean boolean26 = xYPlot21.isRangeGridlinesVisible();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis28 = xYPlot21.getDomainAxisForDataset(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 4 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot21.zoomRangeAxes((double) (short) 100, plotRenderingInfo25, point2D26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = xYPlot21.getRangeAxisLocation((int) (byte) 10);
        int int30 = xYPlot21.getBackgroundImageAlignment();
        int int31 = xYPlot21.getSeriesCount();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 15 + "'", int30 == 15);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.plot.IntervalMarker intervalMarker24 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot21.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker24);
        org.jfree.chart.plot.IntervalMarker intervalMarker28 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.awt.Stroke stroke29 = null;
        intervalMarker28.setOutlineStroke(stroke29);
        boolean boolean31 = xYPlot21.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker28);
        org.jfree.chart.axis.AxisLocation axisLocation32 = xYPlot21.getRangeAxisLocation();
        float float33 = xYPlot21.getForegroundAlpha();
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertTrue("'" + float33 + "' != '" + 1.0f + "'", float33 == 1.0f);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.IntervalMarker intervalMarker4 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.lang.Object obj5 = intervalMarker4.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = intervalMarker4.getLabelAnchor();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        int int12 = categoryPlot7.getIndexOf(categoryItemRenderer11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        boolean boolean17 = categoryPlot7.render(graphics2D13, rectangle2D14, (int) ' ', plotRenderingInfo16);
        int int18 = categoryPlot7.getRangeAxisCount();
        org.jfree.chart.plot.IntervalMarker intervalMarker22 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.awt.Stroke stroke23 = null;
        intervalMarker22.setOutlineStroke(stroke23);
        java.awt.Stroke stroke25 = intervalMarker22.getOutlineStroke();
        java.awt.Font font26 = intervalMarker22.getLabelFont();
        org.jfree.chart.util.Layer layer27 = org.jfree.chart.util.Layer.BACKGROUND;
        boolean boolean29 = categoryPlot7.removeRangeMarker(0, (org.jfree.chart.plot.Marker) intervalMarker22, layer27, true);
        xYPlot0.addRangeMarker(10, (org.jfree.chart.plot.Marker) intervalMarker4, layer27);
        java.awt.Stroke stroke31 = intervalMarker4.getStroke();
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertNull(stroke25);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(layer27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(stroke31);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset2 = categoryPlot1.getDataset();
        boolean boolean3 = lengthAdjustmentType0.equals((java.lang.Object) categoryPlot1);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryPlot1.getInsets();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertNull(categoryDataset2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.awt.Color color1 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        java.awt.Stroke stroke2 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 10L, (java.awt.Paint) color1, stroke2);
        categoryMarker3.setDrawAsLine(false);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        dateAxis7.setLabel("");
        dateAxis7.setTickLabelsVisible(false);
        dateAxis7.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis18 = new org.jfree.chart.axis.DateAxis();
        dateAxis18.setLabel("");
        dateAxis18.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource23 = dateAxis18.getStandardTickUnits();
        boolean boolean24 = categoryPlot14.equals((java.lang.Object) dateAxis18);
        float float25 = dateAxis18.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) dateAxis7, (org.jfree.chart.axis.ValueAxis) dateAxis18, xYItemRenderer26);
        org.jfree.chart.plot.IntervalMarker intervalMarker30 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        xYPlot27.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker30);
        org.jfree.chart.plot.IntervalMarker intervalMarker34 = new org.jfree.chart.plot.IntervalMarker((double) 0, 1.0d);
        java.awt.Stroke stroke35 = null;
        intervalMarker34.setOutlineStroke(stroke35);
        boolean boolean37 = xYPlot27.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker34);
        java.awt.Paint paint38 = intervalMarker34.getPaint();
        org.jfree.chart.text.TextAnchor textAnchor39 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        intervalMarker34.setLabelTextAnchor(textAnchor39);
        categoryMarker3.setLabelTextAnchor(textAnchor39);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(tickUnitSource23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 2.0f + "'", float25 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(textAnchor39);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        java.lang.String str1 = unitType0.toString();
        java.lang.String str2 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.ABSOLUTE" + "'", str1.equals("UnitType.ABSOLUTE"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "UnitType.ABSOLUTE" + "'", str2.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        categoryPlot1.setDomainGridlinePaint((java.awt.Paint) color2);
        java.awt.Paint paint4 = categoryPlot1.getRangeCrosshairPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = null;
        java.awt.geom.Point2D point2D10 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D8, rectangleAnchor9);
        categoryPlot5.zoomRangeAxes((double) (-1), plotRenderingInfo7, point2D10);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis16 = new org.jfree.chart.axis.DateAxis();
        dateAxis16.setLabelToolTip("hi!");
        int int19 = categoryPlot12.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) dateAxis16);
        java.awt.Font font20 = dateAxis16.getTickLabelFont();
        categoryPlot5.setNoDataMessageFont(font20);
        org.jfree.chart.util.Layer layer22 = null;
        java.util.Collection collection23 = categoryPlot5.getDomainMarkers(layer22);
        org.jfree.chart.axis.AxisSpace axisSpace24 = null;
        categoryPlot5.setFixedRangeAxisSpace(axisSpace24, false);
        java.awt.Stroke stroke27 = categoryPlot5.getRangeCrosshairStroke();
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker(10.0d, paint4, stroke27);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(point2D10);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        boolean boolean6 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getDomainAxisEdge((-14336));
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = null;
        java.awt.geom.Point2D point2D17 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D15, rectangleAnchor16);
        categoryPlot12.zoomRangeAxes((double) (-1), plotRenderingInfo14, point2D17);
        categoryPlot0.zoomRangeAxes((double) ' ', 3.0d, plotRenderingInfo11, point2D17);
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(point2D17);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        dateAxis4.setLabel("");
        dateAxis4.setTickLabelsVisible(false);
        dateAxis4.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        dateAxis15.setLabel("");
        dateAxis15.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource20 = dateAxis15.getStandardTickUnits();
        boolean boolean21 = categoryPlot11.equals((java.lang.Object) dateAxis15);
        float float22 = dateAxis15.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) dateAxis4, (org.jfree.chart.axis.ValueAxis) dateAxis15, xYItemRenderer23);
        org.jfree.chart.axis.ValueAxis valueAxis26 = xYPlot24.getRangeAxis((int) (short) -1);
        java.awt.Paint paint27 = xYPlot24.getDomainCrosshairPaint();
        java.awt.Paint paint28 = xYPlot24.getRangeGridlinePaint();
        xYPlot24.clearRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = xYPlot24.getRendererForDataset(xYDataset30);
        java.awt.Color color32 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        xYPlot24.setDomainGridlinePaint((java.awt.Paint) color32);
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot24.setRangeTickBandPaint((java.awt.Paint) color34);
        java.awt.Color color36 = java.awt.Color.BLUE;
        java.awt.Color color37 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.color.ColorSpace colorSpace38 = color37.getColorSpace();
        float[] floatArray47 = new float[] { (-1.0f), (short) 100, (byte) -1, (short) 0, (byte) -1 };
        float[] floatArray48 = java.awt.Color.RGBtoHSB((int) (short) 1, (int) (byte) 0, 0, floatArray47);
        float[] floatArray49 = color36.getColorComponents(colorSpace38, floatArray48);
        float[] floatArray50 = color34.getRGBColorComponents(floatArray49);
        float[] floatArray51 = java.awt.Color.RGBtoHSB((int) ' ', 0, 255, floatArray50);
        org.junit.Assert.assertNotNull(tickUnitSource20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 2.0f + "'", float22 == 2.0f);
        org.junit.Assert.assertNull(valueAxis26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(xYItemRenderer31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(colorSpace38);
        org.junit.Assert.assertNotNull(floatArray47);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertNotNull(floatArray49);
        org.junit.Assert.assertNotNull(floatArray50);
        org.junit.Assert.assertNotNull(floatArray51);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        dateAxis12.setAxisLineVisible(false);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue(1.0d, false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        int int5 = categoryPlot0.getIndexOf(categoryItemRenderer4);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace7, false);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor6);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.data.category.CategoryDataset categoryDataset1 = categoryPlot0.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = categoryPlot0.getDataRange(valueAxis2);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] { dateAxis6, dateAxis7 };
        categoryPlot0.setRangeAxes(valueAxisArray8);
        java.util.List list10 = categoryPlot0.getCategories();
        java.awt.Image image11 = null;
        categoryPlot0.setBackgroundImage(image11);
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = null;
        try {
            categoryPlot0.setOrientation(plotOrientation13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryDataset1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertNotNull(valueAxisArray8);
        org.junit.Assert.assertNull(list10);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        dateAxis1.setLabel("");
        dateAxis1.setTickLabelsVisible(false);
        dateAxis1.setAutoRange(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setAnchorValue(1.0d, false);
        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
        dateAxis12.setLabel("");
        dateAxis12.setTickLabelsVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = dateAxis12.getStandardTickUnits();
        boolean boolean18 = categoryPlot8.equals((java.lang.Object) dateAxis12);
        float float19 = dateAxis12.getTickMarkOutsideLength();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) dateAxis1, (org.jfree.chart.axis.ValueAxis) dateAxis12, xYItemRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis23 = xYPlot21.getRangeAxis((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        xYPlot21.zoomRangeAxes((double) (short) 100, plotRenderingInfo25, point2D26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = null;
        xYPlot21.setDomainAxisLocation((int) (byte) 100, axisLocation29);
        xYPlot21.setRangeCrosshairValue((double) (byte) 100, true);
        org.junit.Assert.assertNotNull(tickUnitSource17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNull(valueAxis23);
    }
}

