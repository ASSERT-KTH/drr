import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test002");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries7.removeAgedItems(false);
//        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
//        timeSeries7.setMaximumItemCount(0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
//        java.util.Date date17 = fixedMillisecond14.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
//        int int20 = day19.getMonth();
//        int int21 = day19.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
//        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
//        long long24 = month23.getLastMillisecond();
//        long long25 = month23.getSerialIndex();
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
//        long long27 = month26.getLastMillisecond();
//        long long28 = month26.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month23, (org.jfree.data.time.RegularTimePeriod) month26);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month23, (java.lang.Number) (short) 10);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day();
//        long long33 = day32.getLastMillisecond();
//        long long34 = day32.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day32, (double) (-1.0f));
//        java.util.Date date37 = day32.getStart();
//        java.lang.String str38 = day32.toString();
//        java.lang.String str39 = day32.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar42 = null;
//        long long43 = fixedMillisecond41.getFirstMillisecond(calendar42);
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries47.removeAgedItems(false);
//        boolean boolean50 = fixedMillisecond41.equals((java.lang.Object) timeSeries47);
//        timeSeries47.setMaximumItemCount(0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar55 = null;
//        long long56 = fixedMillisecond54.getFirstMillisecond(calendar55);
//        java.util.Date date57 = fixedMillisecond54.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond58 = new org.jfree.data.time.FixedMillisecond(date57);
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date57);
//        int int60 = day59.getMonth();
//        int int61 = day59.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries47.getDataItem((org.jfree.data.time.RegularTimePeriod) day59);
//        org.jfree.data.time.Month month63 = new org.jfree.data.time.Month();
//        long long64 = month63.getLastMillisecond();
//        long long65 = month63.getSerialIndex();
//        org.jfree.data.time.Month month66 = new org.jfree.data.time.Month();
//        long long67 = month66.getLastMillisecond();
//        long long68 = month66.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries69 = timeSeries47.createCopy((org.jfree.data.time.RegularTimePeriod) month63, (org.jfree.data.time.RegularTimePeriod) month66);
//        int int70 = day32.compareTo((java.lang.Object) timeSeries47);
//        java.lang.String str71 = day32.toString();
//        int int72 = timeSeriesDataItem31.compareTo((java.lang.Object) str71);
//        org.jfree.data.time.TimeSeries timeSeries76 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year((int) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = year78.next();
//        timeSeries76.add(regularTimePeriod79, (double) 3);
//        boolean boolean82 = timeSeriesDataItem31.equals((java.lang.Object) regularTimePeriod79);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24234L + "'", long25 == 24234L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 24234L + "'", long28 == 24234L);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560236399999L + "'", long33 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560236399999L + "'", long34 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "10-June-2019" + "'", str38.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "10-June-2019" + "'", str39.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
//        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
//        org.junit.Assert.assertNotNull(date57);
//        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 12 + "'", int60 == 12);
//        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1969 + "'", int61 == 1969);
//        org.junit.Assert.assertNull(timeSeriesDataItem62);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1561964399999L + "'", long64 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 24234L + "'", long65 == 24234L);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1561964399999L + "'", long67 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 24234L + "'", long68 == 24234L);
//        org.junit.Assert.assertNotNull(timeSeries69);
//        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 1 + "'", int70 == 1);
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "10-June-2019" + "'", str71.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 1 + "'", int72 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod79);
//        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
        int int5 = fixedMillisecond3.compareTo((java.lang.Object) (-1.0f));
        java.util.Date date6 = fixedMillisecond3.getTime();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date6);
        long long10 = month9.getFirstMillisecond();
        java.util.Calendar calendar11 = null;
        try {
            long long12 = month9.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2649600000L) + "'", long10 == (-2649600000L));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(false);
        timeSeries3.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection14 = timeSeries13.getTimePeriods();
        java.lang.String str15 = timeSeries13.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(0L);
        int int19 = fixedMillisecond17.compareTo((java.lang.Object) (-1.0f));
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        long long21 = fixedMillisecond17.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        boolean boolean23 = timeSeries3.isEmpty();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection10 = timeSeries9.getTimePeriods();
        timeSeries9.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries9.addChangeListener(seriesChangeListener13);
        java.lang.String str15 = timeSeries9.getRangeDescription();
        java.util.Collection collection16 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        java.lang.String str17 = timeSeries3.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getFirstMillisecond(calendar20);
        java.util.Date date22 = fixedMillisecond19.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond(date22);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22);
        int int25 = day24.getMonth();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day24);
        java.util.List list27 = timeSeries3.getItems();
        try {
            timeSeries3.delete(0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 12 + "'", int25 == 12);
        org.junit.Assert.assertNotNull(list27);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond9);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.next();
        java.lang.Number number18 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) year16);
        java.util.Collection collection19 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month20.next();
        java.util.Date date22 = month20.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) month20);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond3.getFirstMillisecond(calendar4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries9.removeAgedItems(false);
        boolean boolean12 = fixedMillisecond3.equals((java.lang.Object) timeSeries9);
        timeSeries9.setMaximumItemCount(0);
        java.lang.String str15 = timeSeries9.getDomainDescription();
        int int16 = year1.compareTo((java.lang.Object) str15);
        long long17 = year1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year1.previous();
        java.lang.Class<?> wildcardClass19 = year1.getClass();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection24 = timeSeries23.getTimePeriods();
        timeSeries23.setNotify(false);
        java.util.List list27 = timeSeries23.getItems();
        int int28 = timeSeries23.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar31 = null;
        long long32 = fixedMillisecond30.getFirstMillisecond(calendar31);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries36.removeAgedItems(false);
        boolean boolean39 = fixedMillisecond30.equals((java.lang.Object) timeSeries36);
        timeSeries36.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar44 = null;
        long long45 = fixedMillisecond43.getFirstMillisecond(calendar44);
        java.util.Date date46 = fixedMillisecond43.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(date46);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date46);
        int int49 = day48.getMonth();
        int int50 = day48.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries36.getDataItem((org.jfree.data.time.RegularTimePeriod) day48);
        org.jfree.data.time.Month month52 = new org.jfree.data.time.Month();
        long long53 = month52.getLastMillisecond();
        long long54 = month52.getSerialIndex();
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
        long long56 = month55.getLastMillisecond();
        long long57 = month55.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries58 = timeSeries36.createCopy((org.jfree.data.time.RegularTimePeriod) month52, (org.jfree.data.time.RegularTimePeriod) month55);
        int int59 = timeSeries23.getIndex((org.jfree.data.time.RegularTimePeriod) month52);
        int int60 = year1.compareTo((java.lang.Object) int59);
        boolean boolean62 = year1.equals((java.lang.Object) "31-December-1969");
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61157520000000L) + "'", long17 == (-61157520000000L));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 0L + "'", long45 == 0L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 12 + "'", int49 == 12);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1969 + "'", int50 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem51);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1561964399999L + "'", long53 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 24234L + "'", long54 == 24234L);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 1561964399999L + "'", long56 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 24234L + "'", long57 == 24234L);
        org.junit.Assert.assertNotNull(timeSeries58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(false);
        timeSeries3.setDomainDescription("");
        int int10 = timeSeries3.getMaximumItemCount();
        java.lang.String str11 = timeSeries3.getDescription();
        boolean boolean12 = timeSeries3.isEmpty();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setNotify(false);
        java.util.List list7 = timeSeries3.getItems();
        boolean boolean8 = timeSeries3.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection13 = timeSeries12.getTimePeriods();
        java.lang.String str14 = timeSeries12.getDescription();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection19 = timeSeries18.getTimePeriods();
        timeSeries18.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries18.addChangeListener(seriesChangeListener22);
        java.lang.String str24 = timeSeries18.getRangeDescription();
        java.util.Collection collection25 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond27.getFirstMillisecond(calendar28);
        java.util.Date date30 = fixedMillisecond27.getStart();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection37 = timeSeries36.getTimePeriods();
        java.lang.String str38 = timeSeries36.getDescription();
        timeSeries36.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar43 = null;
        long long44 = fixedMillisecond42.getFirstMillisecond(calendar43);
        timeSeries36.setKey((java.lang.Comparable) fixedMillisecond42);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (double) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries48 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond42);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42);
        double double50 = timeSeries3.getMinY();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(collection13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(collection37);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 0L + "'", long44 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem47);
        org.junit.Assert.assertNotNull(timeSeries48);
        org.junit.Assert.assertNull(timeSeriesDataItem49);
        org.junit.Assert.assertEquals((double) double50, Double.NaN, 0);
    }

//    @Test
//    public void test010() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test010");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        java.util.Date date5 = day0.getStart();
//        java.lang.String str6 = day0.toString();
//        java.lang.String str7 = day0.toString();
//        long long8 = day0.getMiddleMillisecond();
//        java.util.Calendar calendar9 = null;
//        try {
//            day0.peg(calendar9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560193199999L + "'", long8 == 1560193199999L);
//    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.lang.String str2 = fixedMillisecond1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str2.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L, "", "June 2019");
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond7.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries5.addOrUpdate(regularTimePeriod8, (java.lang.Number) 2147483647);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries5.removePropertyChangeListener(propertyChangeListener11);
        timeSeries5.setMaximumItemCount(1969);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeries5.getNextTimePeriod();
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries3.addAndOrUpdate(timeSeries5);
        timeSeries5.setMaximumItemAge(1560185376261L);
        timeSeries5.setDescription("10-June-2019");
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(timeSeries16);
    }

//    @Test
//    public void test013() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test013");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        boolean boolean2 = timeSeries1.isEmpty();
//        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy(7, (int) 'a');
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getLastMillisecond();
//        long long8 = day6.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day6, (double) (-1.0f));
//        java.util.Date date11 = day6.getStart();
//        java.lang.String str12 = day6.toString();
//        java.lang.String str13 = day6.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond15.getFirstMillisecond(calendar16);
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries21.removeAgedItems(false);
//        boolean boolean24 = fixedMillisecond15.equals((java.lang.Object) timeSeries21);
//        timeSeries21.setMaximumItemCount(0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar29 = null;
//        long long30 = fixedMillisecond28.getFirstMillisecond(calendar29);
//        java.util.Date date31 = fixedMillisecond28.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond32 = new org.jfree.data.time.FixedMillisecond(date31);
//        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date31);
//        int int34 = day33.getMonth();
//        int int35 = day33.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = timeSeries21.getDataItem((org.jfree.data.time.RegularTimePeriod) day33);
//        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
//        long long38 = month37.getLastMillisecond();
//        long long39 = month37.getSerialIndex();
//        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
//        long long41 = month40.getLastMillisecond();
//        long long42 = month40.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries21.createCopy((org.jfree.data.time.RegularTimePeriod) month37, (org.jfree.data.time.RegularTimePeriod) month40);
//        int int44 = day6.compareTo((java.lang.Object) timeSeries21);
//        int int45 = day6.getDayOfMonth();
//        java.lang.String str46 = day6.toString();
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
//        long long48 = month47.getLastMillisecond();
//        long long49 = month47.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries50 = timeSeries5.createCopy((org.jfree.data.time.RegularTimePeriod) day6, (org.jfree.data.time.RegularTimePeriod) month47);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(timeSeries5);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560236399999L + "'", long8 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10-June-2019" + "'", str12.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "10-June-2019" + "'", str13.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 12 + "'", int34 == 12);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1969 + "'", int35 == 1969);
//        org.junit.Assert.assertNull(timeSeriesDataItem36);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1561964399999L + "'", long38 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 24234L + "'", long39 == 24234L);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1561964399999L + "'", long41 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 24234L + "'", long42 == 24234L);
//        org.junit.Assert.assertNotNull(timeSeries43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
//        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 10 + "'", int45 == 10);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "10-June-2019" + "'", str46.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1561964399999L + "'", long48 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1561964399999L + "'", long49 == 1561964399999L);
//        org.junit.Assert.assertNotNull(timeSeries50);
//    }

//    @Test
//    public void test014() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test014");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        java.lang.String str5 = timeSeries3.getDescription();
//        timeSeries3.removeAgedItems(false);
//        timeSeries3.setDomainDescription("");
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        long long11 = day10.getLastMillisecond();
//        long long12 = day10.getLastMillisecond();
//        int int13 = day10.getMonth();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day10, (double) 10L, true);
//        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = month17.next();
//        int int19 = month17.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month17.next();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) month17);
//        java.lang.String str22 = month17.toString();
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertNull(str5);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560236399999L + "'", long11 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560236399999L + "'", long12 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "June 2019" + "'", str22.equals("June 2019"));
//    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.previous();
        java.util.Date date4 = year1.getStart();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date4);
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month5.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection6 = timeSeries5.getTimePeriods();
        timeSeries5.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries5.addChangeListener(seriesChangeListener9);
        int int11 = month0.compareTo((java.lang.Object) timeSeries5);
        boolean boolean12 = timeSeries5.getNotify();
        java.lang.String str13 = timeSeries5.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timeSeries5.addPropertyChangeListener(propertyChangeListener14);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNull(str13);
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test017");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries8.removeAgedItems(false);
//        timeSeries8.setRangeDescription("10");
//        boolean boolean13 = timeSeriesDataItem4.equals((java.lang.Object) "10");
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass15 = month14.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int19 = fixedMillisecond17.compareTo((java.lang.Object) (-1.0f));
//        java.util.Date date20 = fixedMillisecond17.getTime();
//        java.util.TimeZone timeZone21 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date20, timeZone21);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        long long24 = day23.getLastMillisecond();
//        long long25 = day23.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day23, (double) (-1.0f));
//        java.util.Date date28 = day23.getStart();
//        java.util.TimeZone timeZone29 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date28, timeZone29);
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date28);
//        int int32 = timeSeriesDataItem4.compareTo((java.lang.Object) date28);
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = month33.next();
//        long long35 = month33.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month33.next();
//        org.jfree.data.time.Year year37 = month33.getYear();
//        org.jfree.data.time.Year year38 = month33.getYear();
//        int int39 = timeSeriesDataItem4.compareTo((java.lang.Object) year38);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(wildcardClass15);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
//        org.junit.Assert.assertNotNull(date20);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560236399999L + "'", long24 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560236399999L + "'", long25 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date28);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1561964399999L + "'", long35 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(year37);
//        org.junit.Assert.assertNotNull(year38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.next();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        long long3 = month2.getLastMillisecond();
        java.lang.String str4 = month2.toString();
        java.lang.String str5 = month2.toString();
        boolean boolean6 = year0.equals((java.lang.Object) str5);
        long long7 = year0.getSerialIndex();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1561964399999L + "'", long3 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "June 2019" + "'", str5.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 2019L + "'", long7 == 2019L);
    }

//    @Test
//    public void test019() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test019");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.lang.Comparable comparable4 = timeSeries3.getKey();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
//        long long6 = day5.getLastMillisecond();
//        long long7 = day5.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection14 = timeSeries13.getTimePeriods();
//        boolean boolean15 = timeSeriesDataItem9.equals((java.lang.Object) timeSeries13);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries3.addOrUpdate(timeSeriesDataItem9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeries3.getNextTimePeriod();
//        int int18 = timeSeries3.getMaximumItemCount();
//        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 10.0d + "'", comparable4.equals(10.0d));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1560236399999L + "'", long6 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertNull(timeSeriesDataItem16);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2147483647 + "'", int18 == 2147483647);
//    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(false);
        timeSeries3.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection14 = timeSeries13.getTimePeriods();
        java.lang.String str15 = timeSeries13.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(0L);
        int int19 = fixedMillisecond17.compareTo((java.lang.Object) (-1.0f));
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        long long21 = fixedMillisecond17.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        timeSeries3.setMaximumItemAge((long) 8);
        boolean boolean26 = timeSeries3.equals((java.lang.Object) (-1.0d));
        timeSeries3.removeAgedItems(true);
        timeSeries3.fireSeriesChanged();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(false);
        timeSeries3.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection14 = timeSeries13.getTimePeriods();
        java.lang.String str15 = timeSeries13.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(0L);
        int int19 = fixedMillisecond17.compareTo((java.lang.Object) (-1.0f));
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        long long21 = fixedMillisecond17.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        timeSeries3.setMaximumItemAge((long) 8);
        boolean boolean26 = timeSeries3.equals((java.lang.Object) (-1.0d));
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = month29.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries28.getDataItem((org.jfree.data.time.RegularTimePeriod) month29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = month29.next();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month29, (java.lang.Number) 1560185363360L, false);
        boolean boolean36 = timeSeries3.isEmpty();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = null;
        try {
            timeSeries3.delete(regularTimePeriod37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.jfree.data.time.Year year1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(7, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getFirstMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond8.getStart();
        int int12 = day6.compareTo((java.lang.Object) date11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date11);
        java.util.TimeZone timeZone14 = null;
        try {
            org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date11, timeZone14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test024");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        java.lang.String str5 = timeSeries3.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection10 = timeSeries9.getTimePeriods();
//        timeSeries9.setMaximumItemAge((long) '#');
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries9.addChangeListener(seriesChangeListener13);
//        java.lang.String str15 = timeSeries9.getRangeDescription();
//        java.util.Collection collection16 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries9);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        long long18 = day17.getLastMillisecond();
//        long long19 = day17.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day17, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection26 = timeSeries25.getTimePeriods();
//        boolean boolean27 = timeSeriesDataItem21.equals((java.lang.Object) timeSeries25);
//        timeSeriesDataItem21.setValue((java.lang.Number) 1560185357630L);
//        timeSeries9.add(timeSeriesDataItem21, true);
//        java.lang.Object obj32 = null;
//        int int33 = timeSeriesDataItem21.compareTo(obj32);
//        java.lang.Object obj34 = null;
//        int int35 = timeSeriesDataItem21.compareTo(obj34);
//        java.lang.Number number36 = timeSeriesDataItem21.getValue();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo37 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent38 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem21, seriesChangeInfo37);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo39 = null;
//        seriesChangeEvent38.setSummary(seriesChangeInfo39);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo41 = null;
//        seriesChangeEvent38.setSummary(seriesChangeInfo41);
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertNull(str5);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
//        org.junit.Assert.assertNotNull(collection16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560236399999L + "'", long19 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
//        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
//        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 1560185357630L + "'", number36.equals(1560185357630L));
//    }

//    @Test
//    public void test025() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test025");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries7.removeAgedItems(false);
//        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
//        timeSeries7.setMaximumItemCount(0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
//        java.util.Date date17 = fixedMillisecond14.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
//        int int20 = day19.getMonth();
//        int int21 = day19.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
//        java.util.List list23 = timeSeries7.getItems();
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getFirstMillisecond(calendar28);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries33.removeAgedItems(false);
//        boolean boolean36 = fixedMillisecond27.equals((java.lang.Object) timeSeries33);
//        timeSeries33.setMaximumItemCount(0);
//        java.lang.String str39 = timeSeries33.getDomainDescription();
//        int int40 = year25.compareTo((java.lang.Object) str39);
//        long long41 = year25.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year25.previous();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        long long44 = day43.getLastMillisecond();
//        long long45 = day43.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries7.createCopy(regularTimePeriod42, (org.jfree.data.time.RegularTimePeriod) day43);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar49 = null;
//        long long50 = fixedMillisecond48.getFirstMillisecond(calendar49);
//        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries54.removeAgedItems(false);
//        boolean boolean57 = fixedMillisecond48.equals((java.lang.Object) timeSeries54);
//        long long58 = fixedMillisecond48.getSerialIndex();
//        java.util.Date date59 = fixedMillisecond48.getStart();
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond48);
//        java.lang.Object obj61 = timeSeries60.clone();
//        java.util.Collection collection62 = timeSeries46.getTimePeriodsUniqueToOtherSeries(timeSeries60);
//        java.lang.Class<?> wildcardClass63 = collection62.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond65 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar66 = null;
//        long long67 = fixedMillisecond65.getFirstMillisecond(calendar66);
//        java.util.Date date68 = fixedMillisecond65.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond(date68);
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date68);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond72 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar73 = null;
//        long long74 = fixedMillisecond72.getFirstMillisecond(calendar73);
//        java.util.Date date75 = fixedMillisecond72.getStart();
//        int int76 = day70.compareTo((java.lang.Object) date75);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond77 = new org.jfree.data.time.FixedMillisecond(date75);
//        java.util.TimeZone timeZone78 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass63, date75, timeZone78);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertNotNull(list23);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "" + "'", str39.equals(""));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-61157520000000L) + "'", long41 == (-61157520000000L));
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560236399999L + "'", long44 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560236399999L + "'", long45 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 0L + "'", long58 == 0L);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(obj61);
//        org.junit.Assert.assertNotNull(collection62);
//        org.junit.Assert.assertNotNull(wildcardClass63);
//        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 0L + "'", long67 == 0L);
//        org.junit.Assert.assertNotNull(date68);
//        org.junit.Assert.assertTrue("'" + long74 + "' != '" + 0L + "'", long74 == 0L);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
//        org.junit.Assert.assertNull(regularTimePeriod79);
//    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setNotify(false);
        java.util.List list7 = timeSeries3.getItems();
        double double8 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        java.lang.String str11 = timeSeries10.getRangeDescription();
        java.util.Collection collection12 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        timeSeries3.setMaximumItemCount((int) (byte) 1);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries3.removeChangeListener(seriesChangeListener15);
        org.jfree.data.time.TimeSeries timeSeries19 = timeSeries3.createCopy(31, (int) 'a');
        long long20 = timeSeries3.getMaximumItemAge();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertNotNull(timeSeries19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 9223372036854775807L + "'", long20 == 9223372036854775807L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setNotify(false);
        boolean boolean7 = timeSeries3.isEmpty();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(6);
        int int2 = year1.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.previous();
        java.util.Date date4 = regularTimePeriod3.getEnd();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) (-1.0f));
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond1.getStart();
        long long7 = fixedMillisecond1.getMiddleMillisecond();
        long long8 = fixedMillisecond1.getFirstMillisecond();
        long long9 = fixedMillisecond1.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond1.next();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        int int3 = fixedMillisecond1.compareTo((java.lang.Object) (-1.0f));
        java.util.Date date4 = fixedMillisecond1.getTime();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        int int7 = day6.getMonth();
        int int8 = day6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day6.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day6.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = day6.next();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test033");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        java.lang.String str5 = timeSeries3.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection10 = timeSeries9.getTimePeriods();
//        timeSeries9.setMaximumItemAge((long) '#');
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries9.addChangeListener(seriesChangeListener13);
//        java.lang.String str15 = timeSeries9.getRangeDescription();
//        java.util.Collection collection16 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries9);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        long long18 = day17.getLastMillisecond();
//        long long19 = day17.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day17, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection26 = timeSeries25.getTimePeriods();
//        boolean boolean27 = timeSeriesDataItem21.equals((java.lang.Object) timeSeries25);
//        timeSeriesDataItem21.setValue((java.lang.Number) 1560185357630L);
//        timeSeries9.add(timeSeriesDataItem21, true);
//        timeSeries9.removeAgedItems(true);
//        timeSeries9.clear();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar37 = null;
//        long long38 = fixedMillisecond36.getFirstMillisecond(calendar37);
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries42.removeAgedItems(false);
//        boolean boolean45 = fixedMillisecond36.equals((java.lang.Object) timeSeries42);
//        long long46 = fixedMillisecond36.getSerialIndex();
//        java.util.Date date47 = fixedMillisecond36.getStart();
//        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond36);
//        int int49 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond36);
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertNull(str5);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
//        org.junit.Assert.assertNotNull(collection16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560236399999L + "'", long19 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 0L + "'", long38 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "10", "10");
        timeSeries5.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getFirstMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond8.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 25568L);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.next();
        java.lang.Number number18 = timeSeries5.getValue((org.jfree.data.time.RegularTimePeriod) year16);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.lang.Comparable comparable23 = timeSeries22.getKey();
        int int24 = year16.compareTo((java.lang.Object) timeSeries22);
        java.lang.Class class25 = timeSeries22.getTimePeriodClass();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener26 = null;
        timeSeries22.removeChangeListener(seriesChangeListener26);
        timeSeries22.removeAgedItems(true);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + 10.0d + "'", comparable23.equals(10.0d));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNull(class25);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        java.lang.Class class0 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection5 = timeSeries4.getTimePeriods();
        timeSeries4.setNotify(false);
        java.util.List list8 = timeSeries4.getItems();
        boolean boolean9 = timeSeries4.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
        java.lang.Number number15 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) year13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year13.next();
        java.lang.String str17 = year13.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (double) 25568L);
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) year13, (double) 1560185364794L);
        java.util.Date date22 = year13.getEnd();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        java.util.TimeZone timeZone24 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date22, timeZone24);
        org.junit.Assert.assertNotNull(collection5);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "10" + "'", str17.equals("10"));
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNull(regularTimePeriod25);
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test036");
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(6, (int) (short) 10);
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day();
//        long long4 = day3.getLastMillisecond();
//        long long5 = day3.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) (-1.0f));
//        java.lang.Object obj8 = timeSeriesDataItem7.clone();
//        timeSeriesDataItem7.setValue((java.lang.Number) 1L);
//        boolean boolean11 = month2.equals((java.lang.Object) 1L);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getFirstMillisecond(calendar14);
//        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries19.removeAgedItems(false);
//        boolean boolean22 = fixedMillisecond13.equals((java.lang.Object) timeSeries19);
//        timeSeries19.setMaximumItemCount(0);
//        java.lang.String str25 = timeSeries19.getDomainDescription();
//        java.lang.Object obj26 = null;
//        boolean boolean27 = timeSeries19.equals(obj26);
//        boolean boolean28 = month2.equals((java.lang.Object) timeSeries19);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener29 = null;
//        timeSeries19.addChangeListener(seriesChangeListener29);
//        try {
//            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries19.getDataItem((int) '4');
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1560236399999L + "'", long4 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560236399999L + "'", long5 == 1560236399999L);
//        org.junit.Assert.assertNotNull(obj8);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("Value");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("10-June-2019");
        java.lang.String str4 = timePeriodFormatException3.toString();
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException7 = new org.jfree.data.time.TimePeriodFormatException("10-June-2019");
        java.lang.Throwable[] throwableArray8 = timePeriodFormatException7.getSuppressed();
        timePeriodFormatException3.addSuppressed((java.lang.Throwable) timePeriodFormatException7);
        java.lang.String str10 = timePeriodFormatException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 10-June-2019" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: 10-June-2019"));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 10-June-2019" + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: 10-June-2019"));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        java.lang.Number number6 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) year4);
        long long7 = year4.getFirstMillisecond();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(4, year4);
        java.util.Date date9 = month8.getEnd();
        java.util.Date date10 = month8.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month8.next();
        org.jfree.data.time.Year year12 = month8.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61851744000000L) + "'", long7 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(year12);
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test039");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        java.util.Date date5 = day0.getStart();
//        java.lang.String str6 = day0.toString();
//        java.lang.String str7 = day0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries15.removeAgedItems(false);
//        boolean boolean18 = fixedMillisecond9.equals((java.lang.Object) timeSeries15);
//        timeSeries15.setMaximumItemCount(0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getFirstMillisecond(calendar23);
//        java.util.Date date25 = fixedMillisecond22.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(date25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date25);
//        int int28 = day27.getMonth();
//        int int29 = day27.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries15.getDataItem((org.jfree.data.time.RegularTimePeriod) day27);
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
//        long long32 = month31.getLastMillisecond();
//        long long33 = month31.getSerialIndex();
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
//        long long35 = month34.getLastMillisecond();
//        long long36 = month34.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) month31, (org.jfree.data.time.RegularTimePeriod) month34);
//        int int38 = day0.compareTo((java.lang.Object) timeSeries15);
//        int int39 = day0.getDayOfMonth();
//        java.lang.String str40 = day0.toString();
//        int int41 = day0.getMonth();
//        int int42 = day0.getMonth();
//        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection47 = timeSeries46.getTimePeriods();
//        java.lang.String str48 = timeSeries46.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries52 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection53 = timeSeries52.getTimePeriods();
//        timeSeries52.setMaximumItemAge((long) '#');
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener56 = null;
//        timeSeries52.addChangeListener(seriesChangeListener56);
//        java.lang.String str58 = timeSeries52.getRangeDescription();
//        java.util.Collection collection59 = timeSeries46.getTimePeriodsUniqueToOtherSeries(timeSeries52);
//        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day();
//        long long61 = day60.getLastMillisecond();
//        long long62 = day60.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem64 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day60, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection69 = timeSeries68.getTimePeriods();
//        boolean boolean70 = timeSeriesDataItem64.equals((java.lang.Object) timeSeries68);
//        timeSeriesDataItem64.setValue((java.lang.Number) 1560185357630L);
//        timeSeries52.add(timeSeriesDataItem64, true);
//        boolean boolean75 = day0.equals((java.lang.Object) true);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 12 + "'", int28 == 12);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1969 + "'", int29 == 1969);
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1561964399999L + "'", long32 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 24234L + "'", long33 == 24234L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1561964399999L + "'", long35 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 24234L + "'", long36 == 24234L);
//        org.junit.Assert.assertNotNull(timeSeries37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "10-June-2019" + "'", str40.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 6 + "'", int41 == 6);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
//        org.junit.Assert.assertNotNull(collection47);
//        org.junit.Assert.assertNull(str48);
//        org.junit.Assert.assertNotNull(collection53);
//        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "" + "'", str58.equals(""));
//        org.junit.Assert.assertNotNull(collection59);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560236399999L + "'", long61 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1560236399999L + "'", long62 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection69);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
//        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(1560185394883L);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) 'a', 31, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test042");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate2);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
//        java.util.Calendar calendar6 = null;
//        try {
//            long long7 = day4.getFirstMillisecond(calendar6);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        int int10 = fixedMillisecond8.compareTo((java.lang.Object) (-1.0f));
        int int11 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries3.addChangeListener(seriesChangeListener12);
        timeSeries3.removeAgedItems(true);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test044");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries7.removeAgedItems(false);
//        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
//        timeSeries7.setMaximumItemCount(0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
//        java.util.Date date17 = fixedMillisecond14.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
//        int int20 = day19.getMonth();
//        int int21 = day19.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
//        java.util.List list23 = timeSeries7.getItems();
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getFirstMillisecond(calendar28);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries33.removeAgedItems(false);
//        boolean boolean36 = fixedMillisecond27.equals((java.lang.Object) timeSeries33);
//        timeSeries33.setMaximumItemCount(0);
//        java.lang.String str39 = timeSeries33.getDomainDescription();
//        int int40 = year25.compareTo((java.lang.Object) str39);
//        long long41 = year25.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year25.previous();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        long long44 = day43.getLastMillisecond();
//        long long45 = day43.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries7.createCopy(regularTimePeriod42, (org.jfree.data.time.RegularTimePeriod) day43);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar49 = null;
//        long long50 = fixedMillisecond48.getFirstMillisecond(calendar49);
//        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries54.removeAgedItems(false);
//        boolean boolean57 = fixedMillisecond48.equals((java.lang.Object) timeSeries54);
//        long long58 = fixedMillisecond48.getSerialIndex();
//        java.util.Date date59 = fixedMillisecond48.getStart();
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond48);
//        java.lang.Object obj61 = timeSeries60.clone();
//        java.util.Collection collection62 = timeSeries46.getTimePeriodsUniqueToOtherSeries(timeSeries60);
//        java.lang.String str63 = timeSeries46.getDomainDescription();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertNotNull(list23);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "" + "'", str39.equals(""));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-61157520000000L) + "'", long41 == (-61157520000000L));
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560236399999L + "'", long44 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560236399999L + "'", long45 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 0L + "'", long58 == 0L);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(obj61);
//        org.junit.Assert.assertNotNull(collection62);
//        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "" + "'", str63.equals(""));
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(2, year2);
        int int5 = month4.getMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond7.getFirstMillisecond(calendar8);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries13.removeAgedItems(false);
        boolean boolean16 = fixedMillisecond7.equals((java.lang.Object) timeSeries13);
        timeSeries13.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar21 = null;
        long long22 = fixedMillisecond20.getFirstMillisecond(calendar21);
        java.util.Date date23 = fixedMillisecond20.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date23);
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date23);
        int int26 = day25.getMonth();
        int int27 = day25.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries13.getDataItem((org.jfree.data.time.RegularTimePeriod) day25);
        java.util.List list29 = timeSeries13.getItems();
        java.lang.Class class30 = timeSeries13.getTimePeriodClass();
        java.lang.String str31 = timeSeries13.getDescription();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener32 = null;
        timeSeries13.removeChangeListener(seriesChangeListener32);
        boolean boolean34 = month4.equals((java.lang.Object) timeSeries13);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) boolean34);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 0L + "'", long9 == 0L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 0L + "'", long22 == 0L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 12 + "'", int26 == 12);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1969 + "'", int27 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertNotNull(list29);
        org.junit.Assert.assertNull(class30);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getFirstMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond8.getStart();
        int int12 = day6.compareTo((java.lang.Object) date11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod14, (double) 25568L);
        boolean boolean18 = timeSeriesDataItem16.equals((java.lang.Object) 1560185357792L);
        boolean boolean19 = timeSeriesDataItem16.isSelected();
        java.lang.Number number20 = timeSeriesDataItem16.getValue();
        boolean boolean21 = day6.equals((java.lang.Object) number20);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 25568.0d + "'", number20.equals(25568.0d));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod1, (double) 25568L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = timeSeriesDataItem3.getPeriod();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year((int) (short) 10);
        int int9 = year8.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries6.getDataItem((org.jfree.data.time.RegularTimePeriod) year8);
        boolean boolean11 = timeSeriesDataItem3.equals((java.lang.Object) year8);
        java.lang.String str12 = year8.toString();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "10" + "'", str12.equals("10"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(false);
        timeSeries3.setDomainDescription("");
        timeSeries3.setMaximumItemAge((long) 9);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(0L);
        int int17 = fixedMillisecond15.compareTo((java.lang.Object) (-1.0f));
        java.util.Date date18 = fixedMillisecond15.getTime();
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date18, timeZone19);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date18);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) 0.0d);
        timeSeries3.setMaximumItemAge(32L);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(regularTimePeriod20);
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test049");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection9 = timeSeries8.getTimePeriods();
//        boolean boolean10 = timeSeriesDataItem4.equals((java.lang.Object) timeSeries8);
//        java.lang.Class<?> wildcardClass11 = timeSeries8.getClass();
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
//        int int14 = month12.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month12.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month12.previous();
//        long long17 = month12.getLastMillisecond();
//        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) (-1.0f));
//        java.lang.String str20 = month12.toString();
//        int int21 = month12.getMonth();
//        java.util.Date date22 = month12.getStart();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "June 2019" + "'", str20.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
//        org.junit.Assert.assertNotNull(date22);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        int int20 = day19.getMonth();
        int int21 = day19.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        long long24 = month23.getLastMillisecond();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) month23, 0.0d);
        long long27 = month23.getFirstMillisecond();
        long long28 = month23.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1559372400000L + "'", long27 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 24234L + "'", long28 == 24234L);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        java.lang.String str2 = month0.toString();
        java.lang.String str3 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month0.next();
        int int5 = month0.getYearValue();
        java.util.Date date6 = month0.getEnd();
        long long7 = month0.getLastMillisecond();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = month0.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        int int20 = day19.getMonth();
        int int21 = day19.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        long long24 = month23.getLastMillisecond();
        long long25 = month23.getSerialIndex();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        long long27 = month26.getLastMillisecond();
        long long28 = month26.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month23, (org.jfree.data.time.RegularTimePeriod) month26);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year((int) ' ');
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar34 = null;
        long long35 = fixedMillisecond33.getFirstMillisecond(calendar34);
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries39.removeAgedItems(false);
        boolean boolean42 = fixedMillisecond33.equals((java.lang.Object) timeSeries39);
        timeSeries39.setMaximumItemCount(0);
        java.lang.String str45 = timeSeries39.getDomainDescription();
        int int46 = year31.compareTo((java.lang.Object) str45);
        long long47 = year31.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year31.previous();
        java.lang.Class<?> wildcardClass49 = year31.getClass();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year31.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = year31.previous();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24234L + "'", long25 == 24234L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 24234L + "'", long28 == 24234L);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "" + "'", str45.equals(""));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-61157520000000L) + "'", long47 == (-61157520000000L));
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = fixedMillisecond1.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod4, (java.lang.Number) 1560185360394L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test054");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        java.util.Date date5 = day0.getStart();
//        java.lang.String str6 = day0.toString();
//        java.lang.String str7 = day0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries15.removeAgedItems(false);
//        boolean boolean18 = fixedMillisecond9.equals((java.lang.Object) timeSeries15);
//        timeSeries15.setMaximumItemCount(0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getFirstMillisecond(calendar23);
//        java.util.Date date25 = fixedMillisecond22.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(date25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date25);
//        int int28 = day27.getMonth();
//        int int29 = day27.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries15.getDataItem((org.jfree.data.time.RegularTimePeriod) day27);
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
//        long long32 = month31.getLastMillisecond();
//        long long33 = month31.getSerialIndex();
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
//        long long35 = month34.getLastMillisecond();
//        long long36 = month34.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) month31, (org.jfree.data.time.RegularTimePeriod) month34);
//        int int38 = day0.compareTo((java.lang.Object) timeSeries15);
//        int int39 = day0.getDayOfMonth();
//        java.lang.String str40 = day0.toString();
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo41 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent42 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) str40, seriesChangeInfo41);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo43 = seriesChangeEvent42.getSummary();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 12 + "'", int28 == 12);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1969 + "'", int29 == 1969);
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1561964399999L + "'", long32 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 24234L + "'", long33 == 24234L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1561964399999L + "'", long35 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 24234L + "'", long36 == 24234L);
//        org.junit.Assert.assertNotNull(timeSeries37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "10-June-2019" + "'", str40.equals("10-June-2019"));
//        org.junit.Assert.assertNull(seriesChangeInfo43);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(6);
        int int2 = year1.getYear();
        long long3 = year1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 6L + "'", long3 == 6L);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        int int7 = day6.getMonth();
        int int8 = day6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day6.next();
        org.jfree.data.time.SerialDate serialDate10 = day6.getSerialDate();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(serialDate10);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("10");
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year1.getMiddleMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond3.getFirstMillisecond(calendar4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries9.removeAgedItems(false);
        boolean boolean12 = fixedMillisecond3.equals((java.lang.Object) timeSeries9);
        java.util.Date date13 = fixedMillisecond3.getTime();
        int int14 = year1.compareTo((java.lang.Object) date13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year1.next();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries7.createCopy(3, (int) ' ');
        timeSeries15.fireSeriesChanged();
        int int17 = timeSeries15.getItemCount();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries15.removeChangeListener(seriesChangeListener18);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection24 = timeSeries23.getTimePeriods();
        java.lang.String str25 = timeSeries23.getDescription();
        timeSeries23.removeAgedItems(false);
        timeSeries23.setDomainDescription("");
        timeSeries23.setMaximumItemAge((long) 9);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass33 = month32.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(0L);
        int int37 = fixedMillisecond35.compareTo((java.lang.Object) (-1.0f));
        java.util.Date date38 = fixedMillisecond35.getTime();
        java.util.TimeZone timeZone39 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass33, date38, timeZone39);
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month(date38);
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) month41, (java.lang.Number) 0.0d);
        org.jfree.data.time.Year year44 = month41.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year44, (java.lang.Number) 1560185359807L);
        boolean boolean47 = timeSeriesDataItem46.isSelected();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = timeSeriesDataItem46.getPeriod();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries15.addOrUpdate(timeSeriesDataItem46);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(year44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNull(timeSeriesDataItem49);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        int int5 = month2.getYearValue();
        java.util.Date date6 = month2.getEnd();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        org.jfree.data.time.Year year4 = month0.getYear();
        java.util.Date date5 = year4.getEnd();
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
        org.junit.Assert.assertNotNull(date5);
    }

//    @Test
//    public void test062() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test062");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        timeSeries3.setMaximumItemAge((long) '#');
//        timeSeries3.fireSeriesChanged();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener8 = null;
//        timeSeries3.removeChangeListener(seriesChangeListener8);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        long long11 = day10.getLastMillisecond();
//        long long12 = day10.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day10, (double) (-1.0f));
//        long long15 = day10.getLastMillisecond();
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day10, (double) 11, true);
//        double double19 = timeSeries3.getMinY();
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560236399999L + "'", long11 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560236399999L + "'", long12 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560236399999L + "'", long15 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 11.0d + "'", double19 == 11.0d);
//    }

//    @Test
//    public void test063() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test063");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        java.util.Date date5 = day0.getStart();
//        java.lang.String str6 = day0.toString();
//        java.lang.String str7 = day0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries15.removeAgedItems(false);
//        boolean boolean18 = fixedMillisecond9.equals((java.lang.Object) timeSeries15);
//        timeSeries15.setMaximumItemCount(0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getFirstMillisecond(calendar23);
//        java.util.Date date25 = fixedMillisecond22.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(date25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date25);
//        int int28 = day27.getMonth();
//        int int29 = day27.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries15.getDataItem((org.jfree.data.time.RegularTimePeriod) day27);
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
//        long long32 = month31.getLastMillisecond();
//        long long33 = month31.getSerialIndex();
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
//        long long35 = month34.getLastMillisecond();
//        long long36 = month34.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) month31, (org.jfree.data.time.RegularTimePeriod) month34);
//        int int38 = day0.compareTo((java.lang.Object) timeSeries15);
//        int int39 = day0.getDayOfMonth();
//        java.lang.String str40 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate41 = day0.getSerialDate();
//        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(serialDate41);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 12 + "'", int28 == 12);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1969 + "'", int29 == 1969);
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1561964399999L + "'", long32 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 24234L + "'", long33 == 24234L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1561964399999L + "'", long35 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 24234L + "'", long36 == 24234L);
//        org.junit.Assert.assertNotNull(timeSeries37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 10 + "'", int39 == 10);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "10-June-2019" + "'", str40.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate41);
//    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("10");
        org.junit.Assert.assertNull(day1);
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test065");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        java.lang.String str5 = timeSeries3.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection10 = timeSeries9.getTimePeriods();
//        timeSeries9.setMaximumItemAge((long) '#');
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries9.addChangeListener(seriesChangeListener13);
//        java.lang.String str15 = timeSeries9.getRangeDescription();
//        java.util.Collection collection16 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries9);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        long long18 = day17.getLastMillisecond();
//        long long19 = day17.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day17, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection26 = timeSeries25.getTimePeriods();
//        boolean boolean27 = timeSeriesDataItem21.equals((java.lang.Object) timeSeries25);
//        timeSeriesDataItem21.setValue((java.lang.Number) 1560185357630L);
//        timeSeries9.add(timeSeriesDataItem21, true);
//        timeSeries9.setNotify(true);
//        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year((int) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year38.next();
//        java.lang.Number number40 = timeSeries36.getValue((org.jfree.data.time.RegularTimePeriod) year38);
//        long long41 = year38.getFirstMillisecond();
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(4, year38);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries9.getDataItem((org.jfree.data.time.RegularTimePeriod) year38);
//        java.lang.Object obj44 = timeSeriesDataItem43.clone();
//        timeSeriesDataItem43.setSelected(false);
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertNull(str5);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
//        org.junit.Assert.assertNotNull(collection16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560236399999L + "'", long19 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNull(number40);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-61851744000000L) + "'", long41 == (-61851744000000L));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem43);
//        org.junit.Assert.assertNotNull(obj44);
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond9);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.next();
        java.lang.Number number18 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) year16);
        java.util.Collection collection19 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        java.lang.String str20 = timeSeries14.getDescription();
        java.beans.PropertyChangeListener propertyChangeListener21 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener21);
        java.lang.String str23 = timeSeries14.getRangeDescription();
        java.util.List list24 = timeSeries14.getItems();
        double double25 = timeSeries14.getMinY();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertNull(str20);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "Value" + "'", str23.equals("Value"));
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test067");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        java.util.Date date5 = day0.getStart();
//        java.lang.String str6 = day0.toString();
//        java.lang.String str7 = day0.toString();
//        long long8 = day0.getLastMillisecond();
//        int int9 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560236399999L + "'", long8 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        java.lang.Comparable comparable0 = null;
        try {
            org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries(comparable0, "Value", "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getFirstMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond8.getStart();
        int int12 = day6.compareTo((java.lang.Object) date11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(date11);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        int int5 = month2.getYearValue();
        int int6 = month2.getMonth();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getFirstMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond8.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11);
        int int14 = day13.getMonth();
        int int15 = day13.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day13.next();
        int int17 = month2.compareTo((java.lang.Object) day13);
        int int18 = day13.getYear();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1969 + "'", int15 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1969 + "'", int18 == 1969);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) -1);
        long long2 = fixedMillisecond1.getSerialIndex();
        java.util.Calendar calendar3 = null;
        fixedMillisecond1.peg(calendar3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection6 = timeSeries5.getTimePeriods();
        java.lang.String str7 = timeSeries5.getDescription();
        timeSeries5.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond11.getFirstMillisecond(calendar12);
        timeSeries5.setKey((java.lang.Comparable) fixedMillisecond11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (double) (short) 100);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getFirstMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond18.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.next();
        java.lang.Number number29 = timeSeries25.getValue((org.jfree.data.time.RegularTimePeriod) year27);
        boolean boolean30 = day23.equals((java.lang.Object) number29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day23.next();
        int int32 = fixedMillisecond11.compareTo((java.lang.Object) regularTimePeriod31);
        java.util.Date date33 = fixedMillisecond11.getStart();
        java.util.TimeZone timeZone34 = null;
        java.util.Locale locale35 = null;
        try {
            org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date33, timeZone34, locale35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection6);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNull(number29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(date33);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(false);
        timeSeries3.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection14 = timeSeries13.getTimePeriods();
        java.lang.String str15 = timeSeries13.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(0L);
        int int19 = fixedMillisecond17.compareTo((java.lang.Object) (-1.0f));
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        long long21 = fixedMillisecond17.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond17.getFirstMillisecond(calendar23);
        long long25 = fixedMillisecond17.getMiddleMillisecond();
        long long26 = fixedMillisecond17.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 0L + "'", long26 == 0L);
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test074");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        java.util.Date date5 = day0.getStart();
//        java.lang.String str6 = day0.toString();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection11 = timeSeries10.getTimePeriods();
//        timeSeries10.setMaximumItemAge((long) '#');
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
//        timeSeries10.addChangeListener(seriesChangeListener14);
//        timeSeries10.removeAgedItems((long) '#', false);
//        timeSeries10.fireSeriesChanged();
//        timeSeries10.setMaximumItemAge(1L);
//        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day();
//        long long23 = day22.getLastMillisecond();
//        long long24 = day22.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day22, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection31 = timeSeries30.getTimePeriods();
//        boolean boolean32 = timeSeriesDataItem26.equals((java.lang.Object) timeSeries30);
//        java.lang.Class<?> wildcardClass33 = timeSeries30.getClass();
//        java.util.Collection collection34 = timeSeries10.getTimePeriodsUniqueToOtherSeries(timeSeries30);
//        boolean boolean35 = day0.equals((java.lang.Object) collection34);
//        long long36 = day0.getSerialIndex();
//        java.util.Calendar calendar37 = null;
//        try {
//            day0.peg(calendar37);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(collection11);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560236399999L + "'", long23 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560236399999L + "'", long24 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection31);
//        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
//        org.junit.Assert.assertNotNull(wildcardClass33);
//        org.junit.Assert.assertNotNull(collection34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 43626L + "'", long36 == 43626L);
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        int int20 = day19.getMonth();
        int int21 = day19.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
        java.util.List list23 = timeSeries7.getItems();
        java.lang.Class class24 = timeSeries7.getTimePeriodClass();
        timeSeries7.clear();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertNull(class24);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
        int int5 = fixedMillisecond3.compareTo((java.lang.Object) (-1.0f));
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
        java.util.Date date8 = fixedMillisecond3.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, 100.0d);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (java.lang.Number) 1560185373284L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = timeSeriesDataItem12.getPeriod();
        java.lang.Object obj14 = timeSeriesDataItem12.clone();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(obj14);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test077");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        java.util.Date date5 = day0.getStart();
//        java.lang.String str6 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate7 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day0.next();
//        java.lang.Object obj9 = null;
//        int int10 = day0.compareTo(obj9);
//        java.lang.String str11 = day0.toString();
//        int int12 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = day0.previous();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test078");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int5 = fixedMillisecond3.compareTo((java.lang.Object) (-1.0f));
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, 100.0d);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (java.lang.Number) 1560185373284L);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        long long14 = day13.getLastMillisecond();
//        long long15 = day13.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection22 = timeSeries21.getTimePeriods();
//        boolean boolean23 = timeSeriesDataItem17.equals((java.lang.Object) timeSeries21);
//        java.lang.Class<?> wildcardClass24 = timeSeries21.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar27 = null;
//        long long28 = fixedMillisecond26.getFirstMillisecond(calendar27);
//        java.util.Date date29 = fixedMillisecond26.getStart();
//        java.util.TimeZone timeZone30 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date29, timeZone30);
//        java.lang.Class class32 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass24);
//        boolean boolean33 = timeSeriesDataItem12.equals((java.lang.Object) wildcardClass24);
//        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass24);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Date date37 = fixedMillisecond36.getTime();
//        java.util.TimeZone timeZone38 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance(class34, date37, timeZone38);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560236399999L + "'", long14 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560236399999L + "'", long15 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(class32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(class34);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.addChangeListener(seriesChangeListener7);
        java.lang.String str9 = timeSeries3.getRangeDescription();
        timeSeries3.setNotify(false);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection18 = timeSeries17.getTimePeriods();
        timeSeries17.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries17.addChangeListener(seriesChangeListener21);
        int int23 = month12.compareTo((java.lang.Object) timeSeries17);
        boolean boolean24 = timeSeries17.getNotify();
        java.lang.String str25 = timeSeries17.getDescription();
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries3.addAndOrUpdate(timeSeries17);
        timeSeries26.removeAgedItems(true);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year((int) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year30.previous();
        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) year30, (java.lang.Number) 1560185381782L);
        java.lang.String str34 = timeSeries26.getDomainDescription();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "Time" + "'", str34.equals("Time"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond3.getFirstMillisecond(calendar4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries9.removeAgedItems(false);
        boolean boolean12 = fixedMillisecond3.equals((java.lang.Object) timeSeries9);
        java.util.Date date13 = fixedMillisecond3.getTime();
        int int14 = year1.compareTo((java.lang.Object) date13);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) int14);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test081");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries7.removeAgedItems(false);
//        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
//        timeSeries7.setMaximumItemCount(0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
//        java.util.Date date17 = fixedMillisecond14.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
//        int int20 = day19.getMonth();
//        int int21 = day19.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
//        java.util.List list23 = timeSeries7.getItems();
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getFirstMillisecond(calendar28);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries33.removeAgedItems(false);
//        boolean boolean36 = fixedMillisecond27.equals((java.lang.Object) timeSeries33);
//        timeSeries33.setMaximumItemCount(0);
//        java.lang.String str39 = timeSeries33.getDomainDescription();
//        int int40 = year25.compareTo((java.lang.Object) str39);
//        long long41 = year25.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year25.previous();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        long long44 = day43.getLastMillisecond();
//        long long45 = day43.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries7.createCopy(regularTimePeriod42, (org.jfree.data.time.RegularTimePeriod) day43);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond48 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar49 = null;
//        long long50 = fixedMillisecond48.getFirstMillisecond(calendar49);
//        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries54.removeAgedItems(false);
//        boolean boolean57 = fixedMillisecond48.equals((java.lang.Object) timeSeries54);
//        long long58 = fixedMillisecond48.getSerialIndex();
//        java.util.Date date59 = fixedMillisecond48.getStart();
//        org.jfree.data.time.TimeSeries timeSeries60 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond48);
//        java.lang.Object obj61 = timeSeries60.clone();
//        java.util.Collection collection62 = timeSeries46.getTimePeriodsUniqueToOtherSeries(timeSeries60);
//        java.lang.String str63 = timeSeries46.getDescription();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertNotNull(list23);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "" + "'", str39.equals(""));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-61157520000000L) + "'", long41 == (-61157520000000L));
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560236399999L + "'", long44 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560236399999L + "'", long45 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 0L + "'", long50 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 0L + "'", long58 == 0L);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertNotNull(obj61);
//        org.junit.Assert.assertNotNull(collection62);
//        org.junit.Assert.assertNull(str63);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        java.lang.Number number6 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) year4);
        long long7 = year4.getFirstMillisecond();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(4, year4);
        java.util.Date date9 = month8.getEnd();
        java.util.Date date10 = month8.getEnd();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61851744000000L) + "'", long7 == (-61851744000000L));
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        timeSeries3.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries9 = timeSeries3.createCopy((int) (short) 0, 32);
        int int10 = timeSeries3.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 10.0d + "'", comparable4.equals(10.0d));
        org.junit.Assert.assertNotNull(timeSeries9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2147483647 + "'", int10 == 2147483647);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        java.lang.String str13 = timeSeries7.getDomainDescription();
        java.lang.Object obj14 = null;
        boolean boolean15 = timeSeries7.equals(obj14);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = timeSeries7.getTimePeriod((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year5.next();
        timeSeries3.add(regularTimePeriod6, (double) 3);
        timeSeries3.setRangeDescription("");
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond18.next();
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond18.getLastMillisecond(calendar20);
        timeSeries3.update((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (java.lang.Number) (-61847856000001L));
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getSerialIndex();
        long long3 = month0.getFirstMillisecond();
        java.lang.Object obj4 = null;
        boolean boolean5 = month0.equals(obj4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = month0.previous();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        int int10 = fixedMillisecond8.compareTo((java.lang.Object) (-1.0f));
        int int11 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries3.addChangeListener(seriesChangeListener12);
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.next();
        int int18 = month16.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month16.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month16.previous();
        int int21 = month16.getYearValue();
        java.lang.String str22 = month16.toString();
        int int23 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month16.next();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "June 2019" + "'", str22.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod24);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond3.getFirstMillisecond(calendar4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries9.removeAgedItems(false);
        boolean boolean12 = fixedMillisecond3.equals((java.lang.Object) timeSeries9);
        timeSeries9.setMaximumItemCount(0);
        java.lang.String str15 = timeSeries9.getDomainDescription();
        int int16 = year1.compareTo((java.lang.Object) str15);
        long long17 = year1.getFirstMillisecond();
        java.util.Calendar calendar18 = null;
        try {
            long long19 = year1.getFirstMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61157520000000L) + "'", long17 == (-61157520000000L));
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test089");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection9 = timeSeries8.getTimePeriods();
//        boolean boolean10 = timeSeriesDataItem4.equals((java.lang.Object) timeSeries8);
//        java.lang.Class<?> wildcardClass11 = timeSeries8.getClass();
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
//        int int14 = month12.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month12.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month12.previous();
//        long long17 = month12.getLastMillisecond();
//        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) (-1.0f));
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month20.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod21, (double) 25568L);
//        boolean boolean25 = timeSeriesDataItem23.equals((java.lang.Object) 1560185357792L);
//        boolean boolean26 = timeSeriesDataItem23.isSelected();
//        timeSeries8.add(timeSeriesDataItem23);
//        timeSeriesDataItem23.setSelected(false);
//        timeSeriesDataItem23.setValue((java.lang.Number) 12);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod21);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        int int20 = day19.getMonth();
        int int21 = day19.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
        timeSeries7.setDescription("Value");
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar27 = null;
        long long28 = fixedMillisecond26.getFirstMillisecond(calendar27);
        java.util.Date date29 = fixedMillisecond26.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond(date29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = fixedMillisecond30.next();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) 2019);
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries7.addPropertyChangeListener(propertyChangeListener34);
        java.util.List list36 = timeSeries7.getItems();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(list36);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) ' ');
        long long3 = year2.getLastMillisecond();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(2, year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + (-61125897600001L) + "'", long3 == (-61125897600001L));
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test092");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        int int5 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
//    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test093");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection9 = timeSeries8.getTimePeriods();
//        boolean boolean10 = timeSeriesDataItem4.equals((java.lang.Object) timeSeries8);
//        java.lang.Class<?> wildcardClass11 = timeSeries8.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getFirstMillisecond(calendar14);
//        java.util.Date date16 = fixedMillisecond13.getStart();
//        java.util.TimeZone timeZone17 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date16, timeZone17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date16);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test094");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        java.lang.String str1 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate2 = day0.getSerialDate();
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
//        int int4 = day3.getDayOfMonth();
//        org.jfree.data.time.SerialDate serialDate5 = day3.getSerialDate();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection10 = timeSeries9.getTimePeriods();
//        timeSeries9.setMaximumItemAge((long) '#');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int16 = fixedMillisecond14.compareTo((java.lang.Object) (-1.0f));
//        int int17 = timeSeries9.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond14);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond();
//        long long19 = fixedMillisecond18.getLastMillisecond();
//        long long20 = fixedMillisecond18.getLastMillisecond();
//        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
//        timeSeries9.addChangeListener(seriesChangeListener22);
//        java.util.Collection collection24 = timeSeries9.getTimePeriods();
//        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day();
//        long long26 = day25.getLastMillisecond();
//        long long27 = day25.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day25, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries33.removeAgedItems(false);
//        timeSeries33.setRangeDescription("10");
//        boolean boolean38 = timeSeriesDataItem29.equals((java.lang.Object) "10");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = timeSeriesDataItem29.getPeriod();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = timeSeriesDataItem29.getPeriod();
//        timeSeries9.add(timeSeriesDataItem29, false);
//        int int43 = day3.compareTo((java.lang.Object) timeSeriesDataItem29);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "10-June-2019" + "'", str1.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560185451429L + "'", long19 == 1560185451429L);
//        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1560185451429L + "'", long20 == 1560185451429L);
//        org.junit.Assert.assertNotNull(collection24);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560236399999L + "'", long26 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560236399999L + "'", long27 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        int int10 = fixedMillisecond8.compareTo((java.lang.Object) (-1.0f));
        int int11 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod13, (double) 25568L);
        boolean boolean17 = timeSeriesDataItem15.equals((java.lang.Object) 1560185357792L);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection22 = timeSeries21.getTimePeriods();
        timeSeries21.setMaximumItemAge((long) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(0L);
        int int28 = fixedMillisecond26.compareTo((java.lang.Object) (-1.0f));
        int int29 = timeSeries21.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener30 = null;
        timeSeries21.addChangeListener(seriesChangeListener30);
        timeSeries21.setDescription("10-June-2019");
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = month34.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod35, (double) 25568L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries21.addOrUpdate(timeSeriesDataItem37);
        int int39 = timeSeriesDataItem15.compareTo((java.lang.Object) timeSeries21);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = timeSeries3.addOrUpdate(timeSeriesDataItem15);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem40);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 132L, "Value", "Wed Dec 31 16:00:00 PST 1969");
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test097");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int5 = fixedMillisecond3.compareTo((java.lang.Object) (-1.0f));
//        java.util.Calendar calendar6 = null;
//        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
//        java.util.Date date8 = fixedMillisecond3.getStart();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, 100.0d);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, (java.lang.Number) 1560185373284L);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        long long14 = day13.getLastMillisecond();
//        long long15 = day13.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection22 = timeSeries21.getTimePeriods();
//        boolean boolean23 = timeSeriesDataItem17.equals((java.lang.Object) timeSeries21);
//        java.lang.Class<?> wildcardClass24 = timeSeries21.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar27 = null;
//        long long28 = fixedMillisecond26.getFirstMillisecond(calendar27);
//        java.util.Date date29 = fixedMillisecond26.getStart();
//        java.util.TimeZone timeZone30 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass24, date29, timeZone30);
//        java.lang.Class class32 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass24);
//        boolean boolean33 = timeSeriesDataItem12.equals((java.lang.Object) wildcardClass24);
//        java.lang.Class class34 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass24);
//        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo35 = null;
//        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent36 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) class34, seriesChangeInfo35);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
//        org.junit.Assert.assertNotNull(date8);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560236399999L + "'", long14 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560236399999L + "'", long15 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertNotNull(wildcardClass24);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 0L + "'", long28 == 0L);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(class32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(class34);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getSerialIndex();
        long long3 = month0.getFirstMillisecond();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getFirstMillisecond(calendar6);
        java.util.Date date8 = fixedMillisecond5.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(date8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date8);
        long long11 = day10.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection16 = timeSeries15.getTimePeriods();
        java.lang.String str17 = timeSeries15.getDescription();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection22 = timeSeries21.getTimePeriods();
        timeSeries21.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries21.addChangeListener(seriesChangeListener25);
        java.lang.String str27 = timeSeries21.getRangeDescription();
        java.util.Collection collection28 = timeSeries15.getTimePeriodsUniqueToOtherSeries(timeSeries21);
        int int29 = day10.compareTo((java.lang.Object) timeSeries15);
        java.util.Date date30 = day10.getEnd();
        boolean boolean31 = month0.equals((java.lang.Object) date30);
        java.lang.String str32 = month0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 25568L + "'", long11 == 25568L);
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertNotNull(collection22);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
        org.junit.Assert.assertNotNull(collection28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "June 2019" + "'", str32.equals("June 2019"));
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test099");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries7.removeAgedItems(false);
//        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
//        timeSeries7.setMaximumItemCount(0);
//        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries7.createCopy(3, (int) ' ');
//        timeSeries15.fireSeriesChanged();
//        int int17 = timeSeries15.getItemCount();
//        long long18 = timeSeries15.getMaximumItemAge();
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
//        int int21 = month19.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month19.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = month19.previous();
//        long long24 = month19.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month19.next();
//        int int26 = month19.getYearValue();
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.next();
//        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) month19, (org.jfree.data.time.RegularTimePeriod) year27);
//        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day();
//        long long31 = day30.getLastMillisecond();
//        long long32 = day30.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day30, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection39 = timeSeries38.getTimePeriods();
//        boolean boolean40 = timeSeriesDataItem34.equals((java.lang.Object) timeSeries38);
//        java.lang.Class<?> wildcardClass41 = timeSeries38.getClass();
//        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = month42.next();
//        int int44 = month42.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = month42.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = month42.previous();
//        long long47 = month42.getLastMillisecond();
//        timeSeries38.add((org.jfree.data.time.RegularTimePeriod) month42, (java.lang.Number) (-1.0f));
//        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = month50.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod51, (double) 25568L);
//        boolean boolean55 = timeSeriesDataItem53.equals((java.lang.Object) 1560185357792L);
//        boolean boolean56 = timeSeriesDataItem53.isSelected();
//        timeSeries38.add(timeSeriesDataItem53);
//        timeSeries15.add(timeSeriesDataItem53, false);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(timeSeries15);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 9223372036854775807L + "'", long18 == 9223372036854775807L);
//        org.junit.Assert.assertNotNull(regularTimePeriod20);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod25);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(timeSeries29);
//        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1560236399999L + "'", long31 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1560236399999L + "'", long32 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(wildcardClass41);
//        org.junit.Assert.assertNotNull(regularTimePeriod43);
//        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 6 + "'", int44 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod45);
//        org.junit.Assert.assertNotNull(regularTimePeriod46);
//        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1561964399999L + "'", long47 == 1561964399999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod51);
//        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.next();
        java.lang.Number number5 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year3);
        long long6 = year3.getFirstMillisecond();
        java.lang.String str7 = year3.toString();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries11.fireSeriesChanged();
        boolean boolean13 = year3.equals((java.lang.Object) timeSeries11);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-61851744000000L) + "'", long6 == (-61851744000000L));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10" + "'", str7.equals("10"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setNotify(false);
        java.util.List list7 = timeSeries3.getItems();
        int int8 = timeSeries3.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getFirstMillisecond(calendar11);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries16.removeAgedItems(false);
        boolean boolean19 = fixedMillisecond10.equals((java.lang.Object) timeSeries16);
        timeSeries16.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond23.getFirstMillisecond(calendar24);
        java.util.Date date26 = fixedMillisecond23.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(date26);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date26);
        int int29 = day28.getMonth();
        int int30 = day28.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) day28);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year36.next();
        java.lang.Number number38 = timeSeries34.getValue((org.jfree.data.time.RegularTimePeriod) year36);
        long long39 = year36.getFirstMillisecond();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(4, year36);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) month40);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) month40);
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = month43.next();
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection49 = timeSeries48.getTimePeriods();
        timeSeries48.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener52 = null;
        timeSeries48.addChangeListener(seriesChangeListener52);
        int int54 = month43.compareTo((java.lang.Object) timeSeries48);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month43, (double) (-1L), false);
        timeSeries3.setDescription("hi!");
        timeSeries3.fireSeriesChanged();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 12 + "'", int29 == 12);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1969 + "'", int30 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNull(number38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-61851744000000L) + "'", long39 == (-61851744000000L));
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(collection49);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
    }

//    @Test
//    public void test102() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test102");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        timeSeries3.setMaximumItemAge((long) '#');
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
//        timeSeries3.addChangeListener(seriesChangeListener7);
//        java.lang.String str9 = timeSeries3.getRangeDescription();
//        timeSeries3.setNotify(false);
//        org.jfree.data.time.TimeSeries timeSeries14 = timeSeries3.createCopy(2, 2019);
//        timeSeries14.removeAgedItems(false);
//        timeSeries14.removeAgedItems(true);
//        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries14.createCopy(2, 1969);
//        boolean boolean22 = timeSeries14.isEmpty();
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        long long24 = day23.getLastMillisecond();
//        long long25 = day23.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day23, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection32 = timeSeries31.getTimePeriods();
//        boolean boolean33 = timeSeriesDataItem27.equals((java.lang.Object) timeSeries31);
//        java.lang.Object obj34 = timeSeriesDataItem27.clone();
//        boolean boolean35 = timeSeriesDataItem27.isSelected();
//        timeSeriesDataItem27.setSelected(false);
//        timeSeries14.add(timeSeriesDataItem27);
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
//        org.junit.Assert.assertNotNull(timeSeries14);
//        org.junit.Assert.assertNotNull(timeSeries21);
//        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1560236399999L + "'", long24 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560236399999L + "'", long25 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection32);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNotNull(obj34);
//        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
//    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setNotify(false);
        java.util.List list7 = timeSeries3.getItems();
        java.lang.String str8 = timeSeries3.getDescription();
        try {
            timeSeries3.delete(1, 2, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNull(str8);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test104");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection9 = timeSeries8.getTimePeriods();
//        boolean boolean10 = timeSeriesDataItem4.equals((java.lang.Object) timeSeries8);
//        java.lang.Class<?> wildcardClass11 = timeSeries8.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar14 = null;
//        long long15 = fixedMillisecond13.getFirstMillisecond(calendar14);
//        java.util.Date date16 = fixedMillisecond13.getStart();
//        java.util.TimeZone timeZone17 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date16, timeZone17);
//        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass20 = month19.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int24 = fixedMillisecond22.compareTo((java.lang.Object) (-1.0f));
//        java.util.Date date25 = fixedMillisecond22.getTime();
//        java.util.TimeZone timeZone26 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date25, timeZone26);
//        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month(date25);
//        java.util.TimeZone timeZone29 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date25, timeZone29);
//        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year((int) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year32.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year32.previous();
//        java.util.Date date35 = year32.getStart();
//        java.util.TimeZone timeZone36 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date35, timeZone36);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar40 = null;
//        long long41 = fixedMillisecond39.getFirstMillisecond(calendar40);
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries45.removeAgedItems(false);
//        boolean boolean48 = fixedMillisecond39.equals((java.lang.Object) timeSeries45);
//        timeSeries45.setMaximumItemCount(0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar53 = null;
//        long long54 = fixedMillisecond52.getFirstMillisecond(calendar53);
//        java.util.Date date55 = fixedMillisecond52.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond56 = new org.jfree.data.time.FixedMillisecond(date55);
//        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date55);
//        int int58 = day57.getMonth();
//        int int59 = day57.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem60 = timeSeries45.getDataItem((org.jfree.data.time.RegularTimePeriod) day57);
//        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month();
//        long long62 = month61.getLastMillisecond();
//        long long63 = month61.getSerialIndex();
//        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month();
//        long long65 = month64.getLastMillisecond();
//        long long66 = month64.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries67 = timeSeries45.createCopy((org.jfree.data.time.RegularTimePeriod) month61, (org.jfree.data.time.RegularTimePeriod) month64);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = month64.next();
//        java.util.Date date69 = month64.getEnd();
//        java.util.TimeZone timeZone70 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod71 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date69, timeZone70);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar74 = null;
//        long long75 = fixedMillisecond73.getFirstMillisecond(calendar74);
//        java.util.Date date76 = fixedMillisecond73.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond77 = new org.jfree.data.time.FixedMillisecond(date76);
//        org.jfree.data.time.Month month78 = new org.jfree.data.time.Month(date76);
//        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day(date76);
//        java.util.TimeZone timeZone80 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass11, date76, timeZone80);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 0L + "'", long15 == 0L);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertNotNull(wildcardClass20);
//        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNull(regularTimePeriod30);
//        org.junit.Assert.assertNotNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(regularTimePeriod34);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNull(regularTimePeriod37);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 0L + "'", long41 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 0L + "'", long54 == 0L);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 12 + "'", int58 == 12);
//        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1969 + "'", int59 == 1969);
//        org.junit.Assert.assertNull(timeSeriesDataItem60);
//        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1561964399999L + "'", long62 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 24234L + "'", long63 == 24234L);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1561964399999L + "'", long65 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 24234L + "'", long66 == 24234L);
//        org.junit.Assert.assertNotNull(timeSeries67);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertNotNull(date69);
//        org.junit.Assert.assertNull(regularTimePeriod71);
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 0L + "'", long75 == 0L);
//        org.junit.Assert.assertNotNull(date76);
//        org.junit.Assert.assertNull(regularTimePeriod81);
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setNotify(false);
        java.util.List list7 = timeSeries3.getItems();
        int int8 = timeSeries3.getItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar11 = null;
        long long12 = fixedMillisecond10.getFirstMillisecond(calendar11);
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries16.removeAgedItems(false);
        boolean boolean19 = fixedMillisecond10.equals((java.lang.Object) timeSeries16);
        timeSeries16.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond23.getFirstMillisecond(calendar24);
        java.util.Date date26 = fixedMillisecond23.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(date26);
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date26);
        int int29 = day28.getMonth();
        int int30 = day28.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) day28);
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year36.next();
        java.lang.Number number38 = timeSeries34.getValue((org.jfree.data.time.RegularTimePeriod) year36);
        long long39 = year36.getFirstMillisecond();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(4, year36);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries16.getDataItem((org.jfree.data.time.RegularTimePeriod) month40);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) month40);
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = month43.next();
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection49 = timeSeries48.getTimePeriods();
        timeSeries48.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener52 = null;
        timeSeries48.addChangeListener(seriesChangeListener52);
        int int54 = month43.compareTo((java.lang.Object) timeSeries48);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month43, (double) (-1L), false);
        long long58 = month43.getFirstMillisecond();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 0L + "'", long12 == 0L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 12 + "'", int29 == 12);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1969 + "'", int30 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNull(number38);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + (-61851744000000L) + "'", long39 == (-61851744000000L));
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(collection49);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 1 + "'", int54 == 1);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1559372400000L + "'", long58 == 1559372400000L);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond9);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.next();
        java.lang.Number number18 = timeSeries14.getValue((org.jfree.data.time.RegularTimePeriod) year16);
        java.util.Collection collection19 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = null;
        try {
            timeSeries3.add(timeSeriesDataItem20, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertNotNull(collection19);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond5.previous();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
        int int5 = fixedMillisecond3.compareTo((java.lang.Object) (-1.0f));
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond3.getFirstMillisecond(calendar6);
        java.util.Date date8 = fixedMillisecond3.getStart();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond3, 100.0d);
        java.util.Collection collection11 = timeSeries1.getTimePeriods();
        timeSeries1.setDescription("10-June-2019");
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNull(timeSeriesDataItem10);
        org.junit.Assert.assertNotNull(collection11);
    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test109");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.lang.Comparable comparable4 = timeSeries3.getKey();
//        double double5 = timeSeries3.getMinY();
//        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day();
//        long long7 = day6.getLastMillisecond();
//        long long8 = day6.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day6, (double) (-1.0f));
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day6, (double) 1561964399999L);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day6, (double) (-2), false);
//        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 10.0d + "'", comparable4.equals(10.0d));
//        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1560236399999L + "'", long7 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560236399999L + "'", long8 == 1560236399999L);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "10", "10");
        timeSeries5.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getFirstMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond8.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 25568L);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.next();
        java.lang.Number number18 = timeSeries5.getValue((org.jfree.data.time.RegularTimePeriod) year16);
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.lang.Comparable comparable23 = timeSeries22.getKey();
        int int24 = year16.compareTo((java.lang.Object) timeSeries22);
        java.lang.String str25 = timeSeries22.getDomainDescription();
        timeSeries22.setDomainDescription("31-December-1969");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(number18);
        org.junit.Assert.assertTrue("'" + comparable23 + "' != '" + 10.0d + "'", comparable23.equals(10.0d));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) long2, "10", "10");
        timeSeries5.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getFirstMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond8.getStart();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries5.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year12, (java.lang.Number) 25568L);
        boolean boolean15 = timeSeries5.isEmpty();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries5.removeChangeListener(seriesChangeListener16);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test112");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection9 = timeSeries8.getTimePeriods();
//        boolean boolean10 = timeSeriesDataItem4.equals((java.lang.Object) timeSeries8);
//        java.lang.Number number11 = timeSeriesDataItem4.getValue();
//        java.lang.Object obj12 = timeSeriesDataItem4.clone();
//        java.lang.Number number13 = timeSeriesDataItem4.getValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeriesDataItem4.getPeriod();
//        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass16 = month15.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int20 = fixedMillisecond18.compareTo((java.lang.Object) (-1.0f));
//        java.util.Date date21 = fixedMillisecond18.getTime();
//        java.util.TimeZone timeZone22 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date21, timeZone22);
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
//        long long25 = day24.getLastMillisecond();
//        long long26 = day24.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day24, (double) (-1.0f));
//        java.util.Date date29 = day24.getStart();
//        java.util.TimeZone timeZone30 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date29, timeZone30);
//        java.lang.Class class32 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
//        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year((int) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year34.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year34.previous();
//        java.util.Date date37 = year34.getStart();
//        java.util.TimeZone timeZone38 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date37, timeZone38);
//        int int40 = timeSeriesDataItem4.compareTo((java.lang.Object) date37);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (-1.0d) + "'", number11.equals((-1.0d)));
//        org.junit.Assert.assertNotNull(obj12);
//        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-1.0d) + "'", number13.equals((-1.0d)));
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertNotNull(wildcardClass16);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
//        org.junit.Assert.assertNotNull(date21);
//        org.junit.Assert.assertNull(regularTimePeriod23);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1560236399999L + "'", long25 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1560236399999L + "'", long26 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertNotNull(class32);
//        org.junit.Assert.assertNotNull(regularTimePeriod35);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.String str5 = seriesException3.toString();
        org.jfree.data.general.SeriesException seriesException7 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException9 = new org.jfree.data.general.SeriesException("");
        seriesException7.addSuppressed((java.lang.Throwable) seriesException9);
        seriesException3.addSuppressed((java.lang.Throwable) seriesException9);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str5.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        long long5 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getLastMillisecond(calendar6);
        long long8 = fixedMillisecond1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 0L + "'", long8 == 0L);
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test115");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        timeSeries3.setMaximumItemAge((long) '#');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int10 = fixedMillisecond8.compareTo((java.lang.Object) (-1.0f));
//        int int11 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        long long13 = fixedMillisecond12.getLastMillisecond();
//        long long14 = fixedMillisecond12.getLastMillisecond();
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12);
//        java.util.Calendar calendar16 = null;
//        long long17 = fixedMillisecond12.getFirstMillisecond(calendar16);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) 1560185394883L);
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560185453536L + "'", long13 == 1560185453536L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560185453536L + "'", long14 == 1560185453536L);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560185453536L + "'", long17 == 1560185453536L);
//    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        int int10 = fixedMillisecond8.compareTo((java.lang.Object) (-1.0f));
        int int11 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond8);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries3.addChangeListener(seriesChangeListener12);
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month16.next();
        int int18 = month16.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = month16.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month16.previous();
        int int21 = month16.getYearValue();
        java.lang.String str22 = month16.toString();
        int int23 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month16);
        org.jfree.data.time.Year year24 = month16.getYear();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "June 2019" + "'", str22.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(year24);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(6);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, (java.lang.Number) 1560185439127L);
        java.lang.String str4 = year1.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "6" + "'", str4.equals("6"));
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test118");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        java.lang.String str5 = timeSeries3.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int9 = fixedMillisecond7.compareTo((java.lang.Object) (-1.0f));
//        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7);
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener11);
//        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day();
//        long long14 = day13.getLastMillisecond();
//        long long15 = day13.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day13, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries21.removeAgedItems(false);
//        timeSeries21.setRangeDescription("10");
//        boolean boolean26 = timeSeriesDataItem17.equals((java.lang.Object) "10");
//        timeSeries3.add(timeSeriesDataItem17);
//        timeSeriesDataItem17.setValue((java.lang.Number) 1560185360394L);
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertNull(str5);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560236399999L + "'", long14 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560236399999L + "'", long15 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
//    }

//    @Test
//    public void test119() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test119");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        timeSeries3.setNotify(false);
//        java.util.List list7 = timeSeries3.getItems();
//        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
//        java.lang.Class<?> wildcardClass9 = month8.getClass();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int13 = fixedMillisecond11.compareTo((java.lang.Object) (-1.0f));
//        java.util.Date date14 = fixedMillisecond11.getTime();
//        java.util.TimeZone timeZone15 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date14, timeZone15);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        long long18 = day17.getLastMillisecond();
//        long long19 = day17.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day17, (double) (-1.0f));
//        java.util.Date date22 = day17.getStart();
//        java.util.TimeZone timeZone23 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date22, timeZone23);
//        java.lang.Class class25 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
//        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year((int) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year27.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year27.previous();
//        java.util.Date date30 = year27.getStart();
//        java.util.TimeZone timeZone31 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass9, date30, timeZone31);
//        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date30);
//        int int34 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month33);
//        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
//        long long36 = month35.getLastMillisecond();
//        java.lang.String str37 = month35.toString();
//        java.lang.String str38 = month35.toString();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month35.next();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month35, (java.lang.Number) 1560185382439L);
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertNotNull(list7);
//        org.junit.Assert.assertNotNull(wildcardClass9);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560236399999L + "'", long19 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNull(regularTimePeriod24);
//        org.junit.Assert.assertNotNull(class25);
//        org.junit.Assert.assertNotNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(regularTimePeriod29);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1561964399999L + "'", long36 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "June 2019" + "'", str37.equals("June 2019"));
//        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "June 2019" + "'", str38.equals("June 2019"));
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertNull(timeSeriesDataItem41);
//    }

//    @Test
//    public void test120() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test120");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        java.util.Date date5 = day0.getStart();
//        java.lang.String str6 = day0.toString();
//        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries10.removeAgedItems(false);
//        java.util.List list13 = timeSeries10.getItems();
//        java.lang.String str14 = timeSeries10.getDescription();
//        int int15 = day0.compareTo((java.lang.Object) timeSeries10);
//        long long16 = day0.getLastMillisecond();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(list13);
//        org.junit.Assert.assertNull(str14);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560236399999L + "'", long16 == 1560236399999L);
//    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setNotify(false);
        java.util.List list7 = timeSeries3.getItems();
        double double8 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        java.lang.String str11 = timeSeries10.getRangeDescription();
        java.util.Collection collection12 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries10);
        timeSeries3.setMaximumItemCount((int) (byte) 1);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries3.removeChangeListener(seriesChangeListener15);
        int int17 = timeSeries3.getItemCount();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Value" + "'", str11.equals("Value"));
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test122");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        timeSeries3.setMaximumItemAge((long) '#');
//        timeSeries3.fireSeriesChanged();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries15.removeAgedItems(false);
//        boolean boolean18 = fixedMillisecond9.equals((java.lang.Object) timeSeries15);
//        int int19 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection24 = timeSeries23.getTimePeriods();
//        java.lang.String str25 = timeSeries23.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection30 = timeSeries29.getTimePeriods();
//        timeSeries29.setMaximumItemAge((long) '#');
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener33 = null;
//        timeSeries29.addChangeListener(seriesChangeListener33);
//        java.lang.String str35 = timeSeries29.getRangeDescription();
//        java.util.Collection collection36 = timeSeries23.getTimePeriodsUniqueToOtherSeries(timeSeries29);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        long long38 = day37.getLastMillisecond();
//        long long39 = day37.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day37, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection46 = timeSeries45.getTimePeriods();
//        boolean boolean47 = timeSeriesDataItem41.equals((java.lang.Object) timeSeries45);
//        timeSeriesDataItem41.setValue((java.lang.Number) 1560185357630L);
//        timeSeries29.add(timeSeriesDataItem41, true);
//        java.lang.Object obj52 = null;
//        int int53 = timeSeriesDataItem41.compareTo(obj52);
//        timeSeries3.add(timeSeriesDataItem41, false);
//        int int56 = timeSeries3.getMaximumItemCount();
//        timeSeries3.removeAgedItems(true);
//        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day();
//        long long60 = day59.getLastMillisecond();
//        long long61 = day59.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day59, (double) (-1.0f));
//        long long64 = day59.getLastMillisecond();
//        long long65 = day59.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem67 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day59, (double) 1560185428488L);
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
//        org.junit.Assert.assertNotNull(collection24);
//        org.junit.Assert.assertNull(str25);
//        org.junit.Assert.assertNotNull(collection30);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
//        org.junit.Assert.assertNotNull(collection36);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560236399999L + "'", long38 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560236399999L + "'", long39 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 2147483647 + "'", int56 == 2147483647);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + 1560236399999L + "'", long60 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1560236399999L + "'", long61 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1560236399999L + "'", long64 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1560150000000L + "'", long65 == 1560150000000L);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem67);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.next();
        java.lang.Number number5 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year3);
        int int7 = year3.compareTo((java.lang.Object) 1560185357792L);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(0L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond11.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries9.addOrUpdate(regularTimePeriod12, (java.lang.Number) 2147483647);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener15);
        java.lang.Class class17 = timeSeries9.getTimePeriodClass();
        boolean boolean18 = year3.equals((java.lang.Object) timeSeries9);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo19 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) boolean18, seriesChangeInfo19);
        java.lang.String str21 = seriesChangeEvent20.toString();
        java.lang.Object obj22 = seriesChangeEvent20.getSource();
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.jfree.data.event.SeriesChangeEvent[source=false]" + "'", str21.equals("org.jfree.data.event.SeriesChangeEvent[source=false]"));
        org.junit.Assert.assertTrue("'" + obj22 + "' != '" + false + "'", obj22.equals(false));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(11, year1);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month2.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond9);
        timeSeries3.setMaximumItemCount(6);
        timeSeries3.removeAgedItems(1561964399999L, false);
        timeSeries3.setKey((java.lang.Comparable) (short) 10);
        java.lang.String str20 = timeSeries3.getDomainDescription();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) ' ');
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond3.getFirstMillisecond(calendar4);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries9.removeAgedItems(false);
        boolean boolean12 = fixedMillisecond3.equals((java.lang.Object) timeSeries9);
        timeSeries9.setMaximumItemCount(0);
        java.lang.String str15 = timeSeries9.getDomainDescription();
        int int16 = year1.compareTo((java.lang.Object) str15);
        long long17 = year1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year1.previous();
        java.lang.Class<?> wildcardClass19 = year1.getClass();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year1, "June 2019", "June 2019");
        double double23 = timeSeries22.getMaxY();
        double double24 = timeSeries22.getMinY();
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + (-61157520000000L) + "'", long17 == (-61157520000000L));
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month2.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) month2);
        int int5 = month2.getYearValue();
        long long6 = month2.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month2, "org.jfree.data.time.TimePeriodFormatException: Value", "");
        java.lang.String str10 = timeSeries9.getDomainDescription();
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNull(timeSeriesDataItem4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 24234L + "'", long6 == 24234L);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: Value" + "'", str10.equals("org.jfree.data.time.TimePeriodFormatException: Value"));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        int int20 = day19.getMonth();
        int int21 = day19.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
        java.util.List list23 = timeSeries7.getItems();
        java.lang.Class class24 = timeSeries7.getTimePeriodClass();
        java.lang.String str25 = timeSeries7.getDescription();
        timeSeries7.setMaximumItemAge((long) '4');
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = timeSeries7.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(list23);
        org.junit.Assert.assertNull(class24);
        org.junit.Assert.assertNull(str25);
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test129");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection9 = timeSeries8.getTimePeriods();
//        boolean boolean10 = timeSeriesDataItem4.equals((java.lang.Object) timeSeries8);
//        java.lang.Number number11 = timeSeriesDataItem4.getValue();
//        java.lang.Object obj12 = timeSeriesDataItem4.clone();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries20.removeAgedItems(false);
//        boolean boolean23 = fixedMillisecond14.equals((java.lang.Object) timeSeries20);
//        timeSeries20.setMaximumItemCount(0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getFirstMillisecond(calendar28);
//        java.util.Date date30 = fixedMillisecond27.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond31 = new org.jfree.data.time.FixedMillisecond(date30);
//        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date30);
//        int int33 = day32.getMonth();
//        int int34 = day32.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries20.getDataItem((org.jfree.data.time.RegularTimePeriod) day32);
//        timeSeries20.setRangeDescription("June 2019");
//        java.lang.Object obj38 = timeSeries20.clone();
//        int int39 = timeSeriesDataItem4.compareTo((java.lang.Object) timeSeries20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = timeSeriesDataItem4.getPeriod();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + number11 + "' != '" + (-1.0d) + "'", number11.equals((-1.0d)));
//        org.junit.Assert.assertNotNull(obj12);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 12 + "'", int33 == 12);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1969 + "'", int34 == 1969);
//        org.junit.Assert.assertNull(timeSeriesDataItem35);
//        org.junit.Assert.assertNotNull(obj38);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod40);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 10);
        int int2 = year1.getYear();
        java.lang.String str3 = year1.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year1, 25568.0d);
        java.lang.String str6 = year1.toString();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "10" + "'", str3.equals("10"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10" + "'", str6.equals("10"));
    }

//    @Test
//    public void test131() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test131");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries7.removeAgedItems(false);
//        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
//        timeSeries7.setMaximumItemCount(0);
//        java.lang.String str13 = timeSeries7.getDomainDescription();
//        java.lang.Object obj14 = null;
//        boolean boolean15 = timeSeries7.equals(obj14);
//        boolean boolean16 = timeSeries7.isEmpty();
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        java.lang.String str18 = day17.toString();
//        org.jfree.data.time.SerialDate serialDate19 = day17.getSerialDate();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day17);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "10-June-2019" + "'", str18.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNull(timeSeriesDataItem20);
//    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        double double2 = timeSeries1.getMinY();
        timeSeries1.removeAgedItems((-61851744000000L), false);
        timeSeries1.clear();
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

//    @Test
//    public void test133() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test133");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        java.lang.String str5 = timeSeries3.getDescription();
//        timeSeries3.removeAgedItems(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
//        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond9);
//        timeSeries3.setMaximumItemCount(6);
//        timeSeries3.removeAgedItems(1561964399999L, false);
//        timeSeries3.setKey((java.lang.Comparable) (short) 10);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection24 = timeSeries23.getTimePeriods();
//        java.lang.String str25 = timeSeries23.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection30 = timeSeries29.getTimePeriods();
//        timeSeries29.setMaximumItemAge((long) '#');
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener33 = null;
//        timeSeries29.addChangeListener(seriesChangeListener33);
//        java.lang.String str35 = timeSeries29.getRangeDescription();
//        java.util.Collection collection36 = timeSeries23.getTimePeriodsUniqueToOtherSeries(timeSeries29);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        long long38 = day37.getLastMillisecond();
//        long long39 = day37.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day37, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection46 = timeSeries45.getTimePeriods();
//        boolean boolean47 = timeSeriesDataItem41.equals((java.lang.Object) timeSeries45);
//        timeSeriesDataItem41.setValue((java.lang.Number) 1560185357630L);
//        timeSeries29.add(timeSeriesDataItem41, true);
//        java.lang.Object obj52 = null;
//        int int53 = timeSeriesDataItem41.compareTo(obj52);
//        java.lang.Object obj54 = null;
//        int int55 = timeSeriesDataItem41.compareTo(obj54);
//        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection60 = timeSeries59.getTimePeriods();
//        timeSeries59.setMaximumItemAge((long) '#');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int66 = fixedMillisecond64.compareTo((java.lang.Object) (-1.0f));
//        int int67 = timeSeries59.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond64);
//        long long68 = fixedMillisecond64.getMiddleMillisecond();
//        boolean boolean69 = timeSeriesDataItem41.equals((java.lang.Object) long68);
//        java.lang.Number number70 = timeSeriesDataItem41.getValue();
//        timeSeries3.add(timeSeriesDataItem41);
//        timeSeries3.setRangeDescription("31-December-1969");
//        timeSeries3.setMaximumItemAge(1560185435523L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = timeSeries3.getNextTimePeriod();
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertNull(str5);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertNotNull(collection24);
//        org.junit.Assert.assertNull(str25);
//        org.junit.Assert.assertNotNull(collection30);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
//        org.junit.Assert.assertNotNull(collection36);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560236399999L + "'", long38 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560236399999L + "'", long39 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
//        org.junit.Assert.assertNotNull(collection60);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertTrue("'" + number70 + "' != '" + 1560185357630L + "'", number70.equals(1560185357630L));
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass1 = month0.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(0L);
        int int5 = fixedMillisecond3.compareTo((java.lang.Object) (-1.0f));
        java.util.Date date6 = fixedMillisecond3.getTime();
        java.util.TimeZone timeZone7 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date6, timeZone7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date6);
        long long10 = month9.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) (short) 1);
        org.jfree.data.time.Year year13 = month9.getYear();
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + (-2649600000L) + "'", long10 == (-2649600000L));
        org.junit.Assert.assertNotNull(year13);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(false);
        timeSeries3.setDomainDescription("");
        timeSeries3.setMaximumItemAge((long) 9);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass13 = month12.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond(0L);
        int int17 = fixedMillisecond15.compareTo((java.lang.Object) (-1.0f));
        java.util.Date date18 = fixedMillisecond15.getTime();
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass13, date18, timeZone19);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date18);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month21, (java.lang.Number) 0.0d);
        double double24 = timeSeries3.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection29 = timeSeries28.getTimePeriods();
        java.lang.String str30 = timeSeries28.getDescription();
        timeSeries28.removeAgedItems(false);
        timeSeries28.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection39 = timeSeries38.getTimePeriods();
        java.lang.String str40 = timeSeries38.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond(0L);
        int int44 = fixedMillisecond42.compareTo((java.lang.Object) (-1.0f));
        timeSeries38.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42);
        long long46 = fixedMillisecond42.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem47 = timeSeries28.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42);
        timeSeries28.setMaximumItemAge((long) 8);
        boolean boolean51 = timeSeries28.equals((java.lang.Object) (-1.0d));
        java.util.Collection collection52 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries28);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(collection29);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNotNull(collection39);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 0L + "'", long46 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem47);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(collection52);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries15.removeAgedItems(false);
        boolean boolean18 = fixedMillisecond9.equals((java.lang.Object) timeSeries15);
        int int19 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond9.getMiddleMillisecond(calendar20);
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond9.getLastMillisecond(calendar22);
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond9.getFirstMillisecond(calendar24);
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond9.getLastMillisecond(calendar26);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 0L + "'", long27 == 0L);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond9);
        timeSeries3.setMaximumItemCount(6);
        timeSeries3.removeAgedItems(1561964399999L, false);
        timeSeries3.setKey((java.lang.Comparable) (short) 10);
        timeSeries3.setNotify(true);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries5.removeAgedItems(false);
        timeSeries5.setRangeDescription("Value");
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.next();
        java.lang.Number number15 = timeSeries11.getValue((org.jfree.data.time.RegularTimePeriod) year13);
        int int17 = year13.compareTo((java.lang.Object) 1560185357792L);
        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) 4, false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.getDataItem((org.jfree.data.time.RegularTimePeriod) year13);
        timeSeries1.setNotify(false);
        java.beans.PropertyChangeListener propertyChangeListener24 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener24);
        try {
            timeSeries1.delete((int) (short) -1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNull(number15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem21);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        long long5 = fixedMillisecond1.getMiddleMillisecond();
        java.util.Date date6 = fixedMillisecond1.getStart();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) fixedMillisecond1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
        org.junit.Assert.assertNotNull(date6);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        org.jfree.data.time.Year year4 = month0.getYear();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(year4);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.next();
        java.lang.Number number5 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) year3);
        int int6 = timeSeries1.getMaximumItemCount();
        org.jfree.data.time.FixedMillisecond fixedMillisecond8 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond8.getFirstMillisecond(calendar9);
        java.util.Date date11 = fixedMillisecond8.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11);
        int int14 = day13.getMonth();
        int int15 = day13.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = day13.next();
        long long17 = day13.getSerialIndex();
        long long18 = day13.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection23 = timeSeries22.getTimePeriods();
        java.lang.String str24 = timeSeries22.getDescription();
        timeSeries22.removeAgedItems(false);
        timeSeries22.setDomainDescription("");
        timeSeries22.setMaximumItemAge((long) 9);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        java.lang.Class<?> wildcardClass32 = month31.getClass();
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(0L);
        int int36 = fixedMillisecond34.compareTo((java.lang.Object) (-1.0f));
        java.util.Date date37 = fixedMillisecond34.getTime();
        java.util.TimeZone timeZone38 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass32, date37, timeZone38);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date37);
        timeSeries22.add((org.jfree.data.time.RegularTimePeriod) month40, (java.lang.Number) 0.0d);
        org.jfree.data.time.Year year43 = month40.getYear();
        int int44 = day13.compareTo((java.lang.Object) month40);
        int int45 = month40.getYearValue();
        org.jfree.data.time.Year year46 = month40.getYear();
        try {
            timeSeries1.update((org.jfree.data.time.RegularTimePeriod) month40, (java.lang.Number) 1560185435523L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNull(number5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2147483647 + "'", int6 == 2147483647);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 0L + "'", long10 == 0L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 12 + "'", int14 == 12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1969 + "'", int15 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 25568L + "'", long17 == 25568L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + (-57600000L) + "'", long18 == (-57600000L));
        org.junit.Assert.assertNotNull(collection23);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(year43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1969 + "'", int45 == 1969);
        org.junit.Assert.assertNotNull(year46);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        java.lang.Number number6 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) year4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year4.next();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(6, year4);
        java.lang.Object obj9 = null;
        boolean boolean10 = month8.equals(obj9);
        int int11 = month8.getMonth();
        java.util.Calendar calendar12 = null;
        try {
            month8.peg(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        java.util.Date date2 = regularTimePeriod1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond3 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection8 = timeSeries7.getTimePeriods();
        java.lang.String str9 = timeSeries7.getDescription();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection14 = timeSeries13.getTimePeriods();
        timeSeries13.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries13.addChangeListener(seriesChangeListener17);
        java.lang.String str19 = timeSeries13.getRangeDescription();
        java.util.Collection collection20 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection25 = timeSeries24.getTimePeriods();
        java.lang.String str26 = timeSeries24.getDescription();
        timeSeries24.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar31 = null;
        long long32 = fixedMillisecond30.getFirstMillisecond(calendar31);
        timeSeries24.setKey((java.lang.Comparable) fixedMillisecond30);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries13.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) (short) 0);
        boolean boolean36 = fixedMillisecond3.equals((java.lang.Object) timeSeries13);
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year41.next();
        java.lang.Number number43 = timeSeries39.getValue((org.jfree.data.time.RegularTimePeriod) year41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = year41.next();
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(6, year41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year41.previous();
        try {
            timeSeries13.add((org.jfree.data.time.RegularTimePeriod) year41, (java.lang.Number) 1.0f, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(collection8);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(collection20);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 0L + "'", long32 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNull(number43);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        int int7 = day6.getMonth();
        int int8 = day6.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day6.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = day6.next();
        int int11 = day6.getYear();
        java.lang.String str12 = day6.toString();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 12 + "'", int7 == 12);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1969 + "'", int8 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1969 + "'", int11 == 1969);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "31-December-1969" + "'", str12.equals("31-December-1969"));
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test145");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries7.removeAgedItems(false);
//        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
//        timeSeries7.setMaximumItemCount(0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar15 = null;
//        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
//        java.util.Date date17 = fixedMillisecond14.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
//        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
//        int int20 = day19.getMonth();
//        int int21 = day19.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
//        java.util.List list23 = timeSeries7.getItems();
//        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year((int) ' ');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar28 = null;
//        long long29 = fixedMillisecond27.getFirstMillisecond(calendar28);
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries33.removeAgedItems(false);
//        boolean boolean36 = fixedMillisecond27.equals((java.lang.Object) timeSeries33);
//        timeSeries33.setMaximumItemCount(0);
//        java.lang.String str39 = timeSeries33.getDomainDescription();
//        int int40 = year25.compareTo((java.lang.Object) str39);
//        long long41 = year25.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year25.previous();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day();
//        long long44 = day43.getLastMillisecond();
//        long long45 = day43.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries46 = timeSeries7.createCopy(regularTimePeriod42, (org.jfree.data.time.RegularTimePeriod) day43);
//        timeSeries7.setMaximumItemAge(1560185381582L);
//        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month(6, (int) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = month51.next();
//        timeSeries7.add(regularTimePeriod52, (java.lang.Number) 9999, true);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertNotNull(list23);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 0L + "'", long29 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "" + "'", str39.equals(""));
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
//        org.junit.Assert.assertTrue("'" + long41 + "' != '" + (-61157520000000L) + "'", long41 == (-61157520000000L));
//        org.junit.Assert.assertNotNull(regularTimePeriod42);
//        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1560236399999L + "'", long44 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1560236399999L + "'", long45 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries46);
//        org.junit.Assert.assertNotNull(regularTimePeriod52);
//    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test146");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        java.lang.String str5 = timeSeries3.getDescription();
//        timeSeries3.removeAgedItems(false);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
//        timeSeries3.setKey((java.lang.Comparable) fixedMillisecond9);
//        timeSeries3.setMaximumItemCount(6);
//        timeSeries3.removeAgedItems(1561964399999L, false);
//        timeSeries3.setKey((java.lang.Comparable) (short) 10);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection24 = timeSeries23.getTimePeriods();
//        java.lang.String str25 = timeSeries23.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection30 = timeSeries29.getTimePeriods();
//        timeSeries29.setMaximumItemAge((long) '#');
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener33 = null;
//        timeSeries29.addChangeListener(seriesChangeListener33);
//        java.lang.String str35 = timeSeries29.getRangeDescription();
//        java.util.Collection collection36 = timeSeries23.getTimePeriodsUniqueToOtherSeries(timeSeries29);
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day();
//        long long38 = day37.getLastMillisecond();
//        long long39 = day37.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day37, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection46 = timeSeries45.getTimePeriods();
//        boolean boolean47 = timeSeriesDataItem41.equals((java.lang.Object) timeSeries45);
//        timeSeriesDataItem41.setValue((java.lang.Number) 1560185357630L);
//        timeSeries29.add(timeSeriesDataItem41, true);
//        java.lang.Object obj52 = null;
//        int int53 = timeSeriesDataItem41.compareTo(obj52);
//        java.lang.Object obj54 = null;
//        int int55 = timeSeriesDataItem41.compareTo(obj54);
//        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection60 = timeSeries59.getTimePeriods();
//        timeSeries59.setMaximumItemAge((long) '#');
//        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int66 = fixedMillisecond64.compareTo((java.lang.Object) (-1.0f));
//        int int67 = timeSeries59.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond64);
//        long long68 = fixedMillisecond64.getMiddleMillisecond();
//        boolean boolean69 = timeSeriesDataItem41.equals((java.lang.Object) long68);
//        java.lang.Number number70 = timeSeriesDataItem41.getValue();
//        timeSeries3.add(timeSeriesDataItem41);
//        timeSeries3.setRangeDescription("31-December-1969");
//        org.jfree.data.time.Month month74 = new org.jfree.data.time.Month();
//        long long75 = month74.getLastMillisecond();
//        long long76 = month74.getSerialIndex();
//        timeSeries3.update((org.jfree.data.time.RegularTimePeriod) month74, (java.lang.Number) (-61835976000001L));
//        timeSeries3.setNotify(false);
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertNull(str5);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertNotNull(collection24);
//        org.junit.Assert.assertNull(str25);
//        org.junit.Assert.assertNotNull(collection30);
//        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
//        org.junit.Assert.assertNotNull(collection36);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560236399999L + "'", long38 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560236399999L + "'", long39 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection46);
//        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
//        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 1 + "'", int55 == 1);
//        org.junit.Assert.assertNotNull(collection60);
//        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
//        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1) + "'", int67 == (-1));
//        org.junit.Assert.assertTrue("'" + long68 + "' != '" + 0L + "'", long68 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
//        org.junit.Assert.assertTrue("'" + number70 + "' != '" + 1560185357630L + "'", number70.equals(1560185357630L));
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 1561964399999L + "'", long75 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long76 + "' != '" + 24234L + "'", long76 == 24234L);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        long long11 = fixedMillisecond1.getSerialIndex();
        java.util.Date date12 = fixedMillisecond1.getStart();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond1);
        java.lang.Class<?> wildcardClass14 = fixedMillisecond1.getClass();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3, seriesChangeInfo7);
        java.lang.Class class9 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.getDataItem(regularTimePeriod10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(class9);
    }

//    @Test
//    public void test149() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test149");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        java.util.Date date5 = day0.getStart();
//        java.lang.String str6 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate7 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day0.next();
//        java.lang.Object obj9 = null;
//        int int10 = day0.compareTo(obj9);
//        java.lang.String str11 = day0.toString();
//        int int12 = day0.getMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, 0.0d);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "10-June-2019" + "'", str11.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
//    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test150");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0, "July 10", "");
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection8 = timeSeries7.getTimePeriods();
//        java.lang.String str9 = timeSeries7.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection14 = timeSeries13.getTimePeriods();
//        timeSeries13.setMaximumItemAge((long) '#');
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
//        timeSeries13.addChangeListener(seriesChangeListener17);
//        java.lang.String str19 = timeSeries13.getRangeDescription();
//        java.util.Collection collection20 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries13);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day();
//        long long22 = day21.getLastMillisecond();
//        long long23 = day21.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day21, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection30 = timeSeries29.getTimePeriods();
//        boolean boolean31 = timeSeriesDataItem25.equals((java.lang.Object) timeSeries29);
//        timeSeriesDataItem25.setValue((java.lang.Number) 1560185357630L);
//        timeSeries13.add(timeSeriesDataItem25, true);
//        java.lang.Object obj36 = null;
//        int int37 = timeSeriesDataItem25.compareTo(obj36);
//        java.lang.Object obj38 = null;
//        int int39 = timeSeriesDataItem25.compareTo(obj38);
//        java.lang.Number number40 = timeSeriesDataItem25.getValue();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = timeSeriesDataItem25.getPeriod();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries3.getDataItem(regularTimePeriod41);
//        org.junit.Assert.assertNotNull(collection8);
//        org.junit.Assert.assertNull(str9);
//        org.junit.Assert.assertNotNull(collection14);
//        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
//        org.junit.Assert.assertNotNull(collection20);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1560236399999L + "'", long22 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1560236399999L + "'", long23 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection30);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
//        org.junit.Assert.assertTrue("'" + number40 + "' != '" + 1560185357630L + "'", number40.equals(1560185357630L));
//        org.junit.Assert.assertNotNull(regularTimePeriod41);
//        org.junit.Assert.assertNull(timeSeriesDataItem42);
//    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(2, year2);
        int int5 = month4.getYearValue();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.next();
        java.util.Date date9 = year7.getStart();
        int int10 = month4.compareTo((java.lang.Object) date9);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = month4.getLastMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test152");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 0L, "", "June 2019");
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(0L);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond7.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem10 = timeSeries5.addOrUpdate(regularTimePeriod8, (java.lang.Number) 2147483647);
//        java.beans.PropertyChangeListener propertyChangeListener11 = null;
//        timeSeries5.removePropertyChangeListener(propertyChangeListener11);
//        timeSeries5.setMaximumItemCount(1969);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = timeSeries5.getNextTimePeriod();
//        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries3.addAndOrUpdate(timeSeries5);
//        timeSeries5.setMaximumItemAge(1560185376261L);
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection23 = timeSeries22.getTimePeriods();
//        java.lang.String str24 = timeSeries22.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection29 = timeSeries28.getTimePeriods();
//        timeSeries28.setMaximumItemAge((long) '#');
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener32 = null;
//        timeSeries28.addChangeListener(seriesChangeListener32);
//        java.lang.String str34 = timeSeries28.getRangeDescription();
//        java.util.Collection collection35 = timeSeries22.getTimePeriodsUniqueToOtherSeries(timeSeries28);
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day();
//        long long37 = day36.getLastMillisecond();
//        long long38 = day36.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day36, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection45 = timeSeries44.getTimePeriods();
//        boolean boolean46 = timeSeriesDataItem40.equals((java.lang.Object) timeSeries44);
//        timeSeriesDataItem40.setValue((java.lang.Number) 1560185357630L);
//        timeSeries28.add(timeSeriesDataItem40, true);
//        timeSeries28.setNotify(true);
//        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
//        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year((int) (short) 10);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = year57.next();
//        java.lang.Number number59 = timeSeries55.getValue((org.jfree.data.time.RegularTimePeriod) year57);
//        long long60 = year57.getFirstMillisecond();
//        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month(4, year57);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries28.getDataItem((org.jfree.data.time.RegularTimePeriod) year57);
//        timeSeries5.setKey((java.lang.Comparable) timeSeriesDataItem62);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertNull(timeSeriesDataItem10);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(timeSeries16);
//        org.junit.Assert.assertNotNull(collection23);
//        org.junit.Assert.assertNull(str24);
//        org.junit.Assert.assertNotNull(collection29);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "" + "'", str34.equals(""));
//        org.junit.Assert.assertNotNull(collection35);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560236399999L + "'", long37 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560236399999L + "'", long38 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection45);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod58);
//        org.junit.Assert.assertNull(number59);
//        org.junit.Assert.assertTrue("'" + long60 + "' != '" + (-61851744000000L) + "'", long60 == (-61851744000000L));
//        org.junit.Assert.assertNotNull(timeSeriesDataItem62);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        long long1 = month0.getLastMillisecond();
        long long2 = month0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        long long4 = month0.getFirstMillisecond();
        int int5 = month0.getYearValue();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1561964399999L + "'", long1 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1559372400000L + "'", long4 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond(date4);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Date date4 = fixedMillisecond1.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date4);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date4);
        java.util.TimeZone timeZone8 = null;
        try {
            org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date4, timeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond14.getFirstMillisecond(calendar15);
        java.util.Date date17 = fixedMillisecond14.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        int int20 = day19.getMonth();
        int int21 = day19.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries7.getDataItem((org.jfree.data.time.RegularTimePeriod) day19);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        long long24 = month23.getLastMillisecond();
        long long25 = month23.getSerialIndex();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        long long27 = month26.getLastMillisecond();
        long long28 = month26.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries7.createCopy((org.jfree.data.time.RegularTimePeriod) month23, (org.jfree.data.time.RegularTimePeriod) month26);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year((int) ' ');
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar34 = null;
        long long35 = fixedMillisecond33.getFirstMillisecond(calendar34);
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries39.removeAgedItems(false);
        boolean boolean42 = fixedMillisecond33.equals((java.lang.Object) timeSeries39);
        timeSeries39.setMaximumItemCount(0);
        java.lang.String str45 = timeSeries39.getDomainDescription();
        int int46 = year31.compareTo((java.lang.Object) str45);
        long long47 = year31.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year31.previous();
        java.lang.Class<?> wildcardClass49 = year31.getClass();
        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) (-9999));
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem54 = timeSeries7.addOrUpdate(regularTimePeriod52, (java.lang.Number) 1560185360394L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 0L + "'", long16 == 0L);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1969 + "'", int21 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 24234L + "'", long25 == 24234L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 24234L + "'", long28 == 24234L);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "" + "'", str45.equals(""));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + (-61157520000000L) + "'", long47 == (-61157520000000L));
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(wildcardClass49);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        try {
            timeSeries3.delete((int) (byte) -1, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar10 = null;
        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries15.removeAgedItems(false);
        boolean boolean18 = fixedMillisecond9.equals((java.lang.Object) timeSeries15);
        int int19 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9);
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond9.getMiddleMillisecond(calendar20);
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond9.getLastMillisecond(calendar22);
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond9.getFirstMillisecond(calendar24);
        java.util.Date date26 = fixedMillisecond9.getTime();
        java.util.Date date27 = fixedMillisecond9.getTime();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 0L + "'", long23 == 0L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 0L + "'", long25 == 0L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date27);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection10 = timeSeries9.getTimePeriods();
        timeSeries9.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries9.addChangeListener(seriesChangeListener13);
        java.lang.String str15 = timeSeries9.getRangeDescription();
        java.util.Collection collection16 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getFirstMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond18.getStart();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection28 = timeSeries27.getTimePeriods();
        java.lang.String str29 = timeSeries27.getDescription();
        timeSeries27.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar34 = null;
        long long35 = fixedMillisecond33.getFirstMillisecond(calendar34);
        timeSeries27.setKey((java.lang.Comparable) fixedMillisecond33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (double) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond33);
        java.util.Date date40 = fixedMillisecond18.getTime();
        java.util.TimeZone timeZone41 = null;
        java.util.Locale locale42 = null;
        try {
            org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date40, timeZone41, locale42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(collection28);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertNotNull(date40);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test160");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar2 = null;
//        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
//        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries7.removeAgedItems(false);
//        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
//        timeSeries7.setMaximumItemCount(0);
//        java.lang.String str13 = timeSeries7.getDomainDescription();
//        java.lang.Object obj14 = null;
//        boolean boolean15 = timeSeries7.equals(obj14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        long long17 = day16.getLastMillisecond();
//        long long18 = day16.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day16, (double) (-1.0f));
//        long long21 = day16.getLastMillisecond();
//        timeSeries7.add((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) (byte) 1);
//        timeSeries7.setNotify(false);
//        int int26 = timeSeries7.getItemCount();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar29 = null;
//        long long30 = fixedMillisecond28.getFirstMillisecond(calendar29);
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries34.removeAgedItems(false);
//        boolean boolean37 = fixedMillisecond28.equals((java.lang.Object) timeSeries34);
//        timeSeries34.setMaximumItemCount(0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar42 = null;
//        long long43 = fixedMillisecond41.getFirstMillisecond(calendar42);
//        java.util.Date date44 = fixedMillisecond41.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond45 = new org.jfree.data.time.FixedMillisecond(date44);
//        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date44);
//        int int47 = day46.getMonth();
//        int int48 = day46.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries34.getDataItem((org.jfree.data.time.RegularTimePeriod) day46);
//        java.util.List list50 = timeSeries34.getItems();
//        java.lang.Class class51 = timeSeries34.getTimePeriodClass();
//        java.lang.String str52 = timeSeries34.getDescription();
//        timeSeries34.setMaximumItemAge((long) '4');
//        java.util.Collection collection55 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries34);
//        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection60 = timeSeries59.getTimePeriods();
//        java.lang.String str61 = timeSeries59.getDescription();
//        timeSeries59.removeAgedItems(false);
//        timeSeries59.setDomainDescription("");
//        org.jfree.data.time.TimeSeries timeSeries69 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection70 = timeSeries69.getTimePeriods();
//        java.lang.String str71 = timeSeries69.getDescription();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond73 = new org.jfree.data.time.FixedMillisecond(0L);
//        int int75 = fixedMillisecond73.compareTo((java.lang.Object) (-1.0f));
//        timeSeries69.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond73);
//        long long77 = fixedMillisecond73.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem78 = timeSeries59.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond73);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = fixedMillisecond73.previous();
//        java.util.Calendar calendar80 = null;
//        fixedMillisecond73.peg(calendar80);
//        long long82 = fixedMillisecond73.getFirstMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem84 = timeSeries34.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond73, (java.lang.Number) (-61820208000001L));
//        java.util.Calendar calendar85 = null;
//        fixedMillisecond73.peg(calendar85);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560236399999L + "'", long17 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560236399999L + "'", long21 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
//        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 0L + "'", long30 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 0L + "'", long43 == 0L);
//        org.junit.Assert.assertNotNull(date44);
//        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 12 + "'", int47 == 12);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1969 + "'", int48 == 1969);
//        org.junit.Assert.assertNull(timeSeriesDataItem49);
//        org.junit.Assert.assertNotNull(list50);
//        org.junit.Assert.assertNull(class51);
//        org.junit.Assert.assertNull(str52);
//        org.junit.Assert.assertNotNull(collection55);
//        org.junit.Assert.assertNotNull(collection60);
//        org.junit.Assert.assertNull(str61);
//        org.junit.Assert.assertNotNull(collection70);
//        org.junit.Assert.assertNull(str71);
//        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1 + "'", int75 == 1);
//        org.junit.Assert.assertTrue("'" + long77 + "' != '" + 0L + "'", long77 == 0L);
//        org.junit.Assert.assertNull(timeSeriesDataItem78);
//        org.junit.Assert.assertNotNull(regularTimePeriod79);
//        org.junit.Assert.assertTrue("'" + long82 + "' != '" + 0L + "'", long82 == 0L);
//        org.junit.Assert.assertNull(timeSeriesDataItem84);
//    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test161");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection4 = timeSeries3.getTimePeriods();
//        java.lang.String str5 = timeSeries3.getDescription();
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection10 = timeSeries9.getTimePeriods();
//        timeSeries9.setMaximumItemAge((long) '#');
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
//        timeSeries9.addChangeListener(seriesChangeListener13);
//        java.lang.String str15 = timeSeries9.getRangeDescription();
//        java.util.Collection collection16 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries9);
//        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day();
//        long long18 = day17.getLastMillisecond();
//        long long19 = day17.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day17, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection26 = timeSeries25.getTimePeriods();
//        boolean boolean27 = timeSeriesDataItem21.equals((java.lang.Object) timeSeries25);
//        timeSeriesDataItem21.setValue((java.lang.Number) 1560185357630L);
//        timeSeries9.add(timeSeriesDataItem21, true);
//        timeSeries9.removeAgedItems(true);
//        timeSeries9.clear();
//        java.util.Collection collection35 = timeSeries9.getTimePeriods();
//        org.junit.Assert.assertNotNull(collection4);
//        org.junit.Assert.assertNull(str5);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
//        org.junit.Assert.assertNotNull(collection16);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1560236399999L + "'", long19 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection26);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertNotNull(collection35);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Wed Dec 31 16:00:00 PST 1969");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: ");
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
    }

//    @Test
//    public void test163() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test163");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection9 = timeSeries8.getTimePeriods();
//        boolean boolean10 = timeSeriesDataItem4.equals((java.lang.Object) timeSeries8);
//        java.lang.Class<?> wildcardClass11 = timeSeries8.getClass();
//        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod13 = month12.next();
//        int int14 = month12.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month12.next();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month12.previous();
//        long long17 = month12.getLastMillisecond();
//        timeSeries8.add((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) (-1.0f));
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) 1560185418009L);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(collection9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(wildcardClass11);
//        org.junit.Assert.assertNotNull(regularTimePeriod13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertNotNull(regularTimePeriod16);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
//    }

//    @Test
//    public void test164() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test164");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries8.removeAgedItems(false);
//        timeSeries8.setRangeDescription("10");
//        boolean boolean13 = timeSeriesDataItem4.equals((java.lang.Object) "10");
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = timeSeriesDataItem4.getPeriod();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar17 = null;
//        long long18 = fixedMillisecond16.getFirstMillisecond(calendar17);
//        java.util.Date date19 = fixedMillisecond16.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(date19);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date19);
//        int int22 = day21.getMonth();
//        int int23 = day21.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day21.next();
//        long long25 = day21.getSerialIndex();
//        long long26 = day21.getLastMillisecond();
//        boolean boolean27 = timeSeriesDataItem4.equals((java.lang.Object) day21);
//        java.lang.String str28 = day21.toString();
//        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) day21, "", "Wed Dec 31 16:00:00 PST 1969");
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//        org.junit.Assert.assertNotNull(regularTimePeriod14);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 0L + "'", long18 == 0L);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 12 + "'", int22 == 12);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1969 + "'", int23 == 1969);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 25568L + "'", long25 == 25568L);
//        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 28799999L + "'", long26 == 28799999L);
//        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "31-December-1969" + "'", str28.equals("31-December-1969"));
//    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(false);
        timeSeries3.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection14 = timeSeries13.getTimePeriods();
        java.lang.String str15 = timeSeries13.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(0L);
        int int19 = fixedMillisecond17.compareTo((java.lang.Object) (-1.0f));
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        long long21 = fixedMillisecond17.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        timeSeries3.setMaximumItemAge((long) 8);
        timeSeries3.clear();
        timeSeries3.setMaximumItemCount(10);
        timeSeries3.fireSeriesChanged();
        timeSeries3.setMaximumItemCount((int) (byte) 100);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        timeSeries3.setMaximumItemAge((long) '#');
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo7 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent8 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3, seriesChangeInfo7);
        timeSeries3.setMaximumItemAge((long) (byte) 100);
        int int11 = timeSeries3.getMaximumItemCount();
        int int12 = timeSeries3.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection17 = timeSeries16.getTimePeriods();
        timeSeries16.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries16.addChangeListener(seriesChangeListener20);
        java.lang.String str22 = timeSeries16.getRangeDescription();
        timeSeries16.setNotify(false);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month25.next();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection31 = timeSeries30.getTimePeriods();
        timeSeries30.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener34 = null;
        timeSeries30.addChangeListener(seriesChangeListener34);
        int int36 = month25.compareTo((java.lang.Object) timeSeries30);
        boolean boolean37 = timeSeries30.getNotify();
        java.lang.String str38 = timeSeries30.getDescription();
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries16.addAndOrUpdate(timeSeries30);
        timeSeries39.removeAgedItems(true);
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year((int) ' ');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = year43.previous();
        timeSeries39.add((org.jfree.data.time.RegularTimePeriod) year43, (java.lang.Number) 1560185381782L);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year43, (java.lang.Number) 31, false);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 2147483647 + "'", int11 == 2147483647);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2147483647 + "'", int12 == 2147483647);
        org.junit.Assert.assertNotNull(collection17);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNull(str38);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test167");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
//        boolean boolean2 = timeSeries1.isEmpty();
//        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy(7, (int) 'a');
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        java.util.Collection collection10 = timeSeries9.getTimePeriods();
//        timeSeries9.setMaximumItemAge((long) '#');
//        timeSeries9.fireSeriesChanged();
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener14 = null;
//        timeSeries9.removeChangeListener(seriesChangeListener14);
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        long long17 = day16.getLastMillisecond();
//        long long18 = day16.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day16, (double) (-1.0f));
//        long long21 = day16.getLastMillisecond();
//        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) day16, (double) 11, true);
//        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries5.addAndOrUpdate(timeSeries9);
//        try {
//            timeSeries9.delete(4, 0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertNotNull(timeSeries5);
//        org.junit.Assert.assertNotNull(collection10);
//        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1560236399999L + "'", long17 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1560236399999L + "'", long18 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1560236399999L + "'", long21 == 1560236399999L);
//        org.junit.Assert.assertNotNull(timeSeries25);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getLastMillisecond();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1577865599999L + "'", long1 == 1577865599999L);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        long long2 = month0.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.next();
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond5.getFirstMillisecond(calendar6);
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries11.removeAgedItems(false);
        boolean boolean14 = fixedMillisecond5.equals((java.lang.Object) timeSeries11);
        timeSeries11.setMaximumItemCount(0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getFirstMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond18.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(date21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21);
        int int24 = day23.getMonth();
        int int25 = day23.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries11.getDataItem((org.jfree.data.time.RegularTimePeriod) day23);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        long long28 = month27.getLastMillisecond();
        long long29 = month27.getSerialIndex();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        long long31 = month30.getLastMillisecond();
        long long32 = month30.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries11.createCopy((org.jfree.data.time.RegularTimePeriod) month27, (org.jfree.data.time.RegularTimePeriod) month30);
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 100.0f);
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year((int) (short) 10);
        int int38 = year37.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries35.getDataItem((org.jfree.data.time.RegularTimePeriod) year37);
        int int40 = month27.compareTo((java.lang.Object) timeSeries35);
        int int41 = month0.compareTo((java.lang.Object) month27);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 0L + "'", long7 == 0L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 12 + "'", int24 == 12);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1969 + "'", int25 == 1969);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1561964399999L + "'", long28 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 24234L + "'", long29 == 24234L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1561964399999L + "'", long31 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 24234L + "'", long32 == 24234L);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 10 + "'", int38 == 10);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        timeSeries7.removeAgedItems(false);
        boolean boolean10 = fixedMillisecond1.equals((java.lang.Object) timeSeries7);
        timeSeries7.setMaximumItemCount(0);
        java.lang.String str13 = timeSeries7.getRangeDescription();
        timeSeries7.clear();
        long long15 = timeSeries7.getMaximumItemAge();
        java.util.List list16 = timeSeries7.getItems();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9223372036854775807L + "'", long15 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(list16);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        long long2 = month1.getLastMillisecond();
        java.lang.String str3 = month1.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month1.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month1, (java.lang.Number) 1560185359807L);
        boolean boolean7 = year0.equals((java.lang.Object) timeSeriesDataItem6);
        timeSeriesDataItem6.setValue((java.lang.Number) 1560185406185L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1561964399999L + "'", long2 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "June 2019" + "'", str3.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(2, year2);
        int int5 = month4.getYearValue();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month4.getFirstMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 10 + "'", int5 == 10);
    }

//    @Test
//    public void test173() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test173");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        java.util.Date date5 = day0.getStart();
//        java.lang.String str6 = day0.toString();
//        java.lang.String str7 = day0.toString();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond9.getFirstMillisecond(calendar10);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
//        timeSeries15.removeAgedItems(false);
//        boolean boolean18 = fixedMillisecond9.equals((java.lang.Object) timeSeries15);
//        timeSeries15.setMaximumItemCount(0);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond(0L);
//        java.util.Calendar calendar23 = null;
//        long long24 = fixedMillisecond22.getFirstMillisecond(calendar23);
//        java.util.Date date25 = fixedMillisecond22.getStart();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond(date25);
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date25);
//        int int28 = day27.getMonth();
//        int int29 = day27.getYear();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries15.getDataItem((org.jfree.data.time.RegularTimePeriod) day27);
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
//        long long32 = month31.getLastMillisecond();
//        long long33 = month31.getSerialIndex();
//        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
//        long long35 = month34.getLastMillisecond();
//        long long36 = month34.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries15.createCopy((org.jfree.data.time.RegularTimePeriod) month31, (org.jfree.data.time.RegularTimePeriod) month34);
//        int int38 = day0.compareTo((java.lang.Object) timeSeries15);
//        org.jfree.data.time.SerialDate serialDate39 = day0.getSerialDate();
//        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(serialDate39);
//        int int41 = day40.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "10-June-2019" + "'", str7.equals("10-June-2019"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 0L + "'", long24 == 0L);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 12 + "'", int28 == 12);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1969 + "'", int29 == 1969);
//        org.junit.Assert.assertNull(timeSeriesDataItem30);
//        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1561964399999L + "'", long32 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 24234L + "'", long33 == 24234L);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1561964399999L + "'", long35 == 1561964399999L);
//        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 24234L + "'", long36 == 24234L);
//        org.junit.Assert.assertNotNull(timeSeries37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
//        org.junit.Assert.assertNotNull(serialDate39);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 10 + "'", int41 == 10);
//    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1.0f);
        boolean boolean2 = timeSeries1.isEmpty();
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy(7, (int) 'a');
        timeSeries5.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(timeSeries5);
    }

//    @Test
//    public void test175() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test175");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getLastMillisecond();
//        long long2 = day0.getLastMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day0, (double) (-1.0f));
//        java.util.Date date5 = day0.getStart();
//        java.lang.String str6 = day0.toString();
//        org.jfree.data.time.SerialDate serialDate7 = day0.getSerialDate();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = day0.next();
//        java.lang.Object obj9 = null;
//        int int10 = day0.compareTo(obj9);
//        org.jfree.data.time.SerialDate serialDate11 = day0.getSerialDate();
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) serialDate11);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1560236399999L + "'", long1 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560236399999L + "'", long2 == 1560236399999L);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "10-June-2019" + "'", str6.equals("10-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate7);
//        org.junit.Assert.assertNotNull(regularTimePeriod8);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//        org.junit.Assert.assertNotNull(serialDate11);
//    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        timeSeries3.removeAgedItems(false);
        timeSeries3.setDomainDescription("");
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection14 = timeSeries13.getTimePeriods();
        java.lang.String str15 = timeSeries13.getDescription();
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(0L);
        int int19 = fixedMillisecond17.compareTo((java.lang.Object) (-1.0f));
        timeSeries13.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        long long21 = fixedMillisecond17.getFirstMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond17);
        timeSeries3.setMaximumItemAge((long) 8);
        boolean boolean26 = timeSeries3.equals((java.lang.Object) (-1.0d));
        java.util.Collection collection27 = timeSeries3.getTimePeriods();
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar30 = null;
        long long31 = fixedMillisecond29.getFirstMillisecond(calendar30);
        java.util.Date date32 = fixedMillisecond29.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(date32);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32);
        int int35 = day34.getMonth();
        int int36 = day34.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day34.next();
        long long38 = day34.getSerialIndex();
        long long39 = day34.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = year43.next();
        java.lang.Number number45 = timeSeries41.getValue((org.jfree.data.time.RegularTimePeriod) year43);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year43.next();
        java.lang.String str47 = year43.toString();
        boolean boolean48 = day34.equals((java.lang.Object) year43);
        java.lang.Number number49 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) year43);
        java.util.List list50 = timeSeries3.getItems();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener51 = null;
        timeSeries3.removeChangeListener(seriesChangeListener51);
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(collection14);
        org.junit.Assert.assertNull(str15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 0L + "'", long21 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(collection27);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 0L + "'", long31 == 0L);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 12 + "'", int35 == 12);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1969 + "'", int36 == 1969);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 25568L + "'", long38 == 25568L);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 28799999L + "'", long39 == 28799999L);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertNull(number45);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "10" + "'", str47.equals("10"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(number49);
        org.junit.Assert.assertNotNull(list50);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year((int) (short) 10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        java.lang.Number number6 = timeSeries2.getValue((org.jfree.data.time.RegularTimePeriod) year4);
        long long7 = year4.getFirstMillisecond();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month(4, year4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = month8.next();
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-61851744000000L) + "'", long7 == (-61851744000000L));
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection4 = timeSeries3.getTimePeriods();
        java.lang.String str5 = timeSeries3.getDescription();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection10 = timeSeries9.getTimePeriods();
        timeSeries9.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries9.addChangeListener(seriesChangeListener13);
        java.lang.String str15 = timeSeries9.getRangeDescription();
        java.util.Collection collection16 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar19 = null;
        long long20 = fixedMillisecond18.getFirstMillisecond(calendar19);
        java.util.Date date21 = fixedMillisecond18.getStart();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection28 = timeSeries27.getTimePeriods();
        java.lang.String str29 = timeSeries27.getDescription();
        timeSeries27.removeAgedItems(false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond33 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar34 = null;
        long long35 = fixedMillisecond33.getFirstMillisecond(calendar34);
        timeSeries27.setKey((java.lang.Comparable) fixedMillisecond33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond33, (double) (short) 100);
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond33);
        java.util.Date date40 = fixedMillisecond18.getTime();
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 10.0d, "", "");
        java.util.Collection collection45 = timeSeries44.getTimePeriods();
        timeSeries44.setMaximumItemAge((long) '#');
        org.jfree.data.event.SeriesChangeListener seriesChangeListener48 = null;
        timeSeries44.addChangeListener(seriesChangeListener48);
        timeSeries44.removeAgedItems((long) '#', false);
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar55 = null;
        long long56 = fixedMillisecond54.getFirstMillisecond(calendar55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = fixedMillisecond54.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries44.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond54, (double) '#');
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = fixedMillisecond54.next();
        boolean boolean61 = fixedMillisecond18.equals((java.lang.Object) regularTimePeriod60);
        long long62 = fixedMillisecond18.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(collection4);
        org.junit.Assert.assertNull(str5);
        org.junit.Assert.assertNotNull(collection10);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertNotNull(collection16);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 0L + "'", long20 == 0L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(collection28);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 0L + "'", long35 == 0L);
        org.junit.Assert.assertNull(timeSeriesDataItem38);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(collection45);
        org.junit.Assert.assertTrue("'" + long56 + "' != '" + 0L + "'", long56 == 0L);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertNull(timeSeriesDataItem59);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 0L + "'", long62 == 0L);
    }
}

