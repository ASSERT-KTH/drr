import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.util.Date date0 = null;
        java.util.Date date1 = null;
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(date0, date1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.lang.Object obj0 = null;
        try {
            org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (short) 1, (int) (byte) 100, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) 'a', 100, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        try {
            timePeriodValues3.update(0, (java.lang.Number) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        long long9 = simpleTimePeriod8.getEndMillis();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.previous();
        java.util.Date date13 = year10.getEnd();
        try {
            int int14 = simpleTimePeriod8.compareTo((java.lang.Object) date13);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.util.Date cannot be cast to org.jfree.data.time.TimePeriod");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMaxStartIndex();
        java.lang.String str5 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        java.util.TimeZone timeZone9 = null;
        try {
            org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date7, timeZone9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        try {
            java.lang.Number number6 = timePeriodValues3.getValue((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        try {
            timePeriodValues3.delete((int) (short) 0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(1577865599999L, 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        java.util.TimeZone timeZone9 = null;
        try {
            org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date7, timeZone9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Object obj1 = null;
        boolean boolean2 = year0.equals(obj1);
        java.util.Calendar calendar3 = null;
        try {
            year0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Comparable comparable5 = timePeriodValues3.getKey();
        java.lang.Comparable comparable6 = null;
        try {
            timePeriodValues3.setKey(comparable6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 10.0f + "'", comparable5.equals(10.0f));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(8, 10, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        java.lang.Comparable comparable7 = timePeriodValues3.getKey();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue9 = timePeriodValues3.getDataItem((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 10.0f + "'", comparable7.equals(10.0f));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) '4', "hi!", "hi!");
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.String str5 = timePeriodValues3.getRangeDescription();
        try {
            org.jfree.data.time.TimePeriod timePeriod7 = timePeriodValues3.getTimePeriod((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.String str8 = timePeriodValues3.getDomainDescription();
        try {
            timePeriodValues3.update(2019, (java.lang.Number) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2019, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        java.lang.Object obj7 = timePeriodValues3.clone();
        timePeriodValues3.setRangeDescription("");
        int int10 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1), "", "hi!");
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue5 = timePeriodValues3.getDataItem((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        long long9 = simpleTimePeriod8.getEndMillis();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) long9);
        java.lang.String str11 = seriesChangeEvent10.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1577865599999]" + "'", str11.equals("org.jfree.data.general.SeriesChangeEvent[source=1577865599999]"));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        java.lang.Class<?> wildcardClass4 = date3.getClass();
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date3, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        java.lang.Object obj7 = timePeriodValues3.clone();
        timePeriodValues3.setRangeDescription("");
        timePeriodValues3.setDomainDescription("hi!");
        try {
            org.jfree.data.time.TimePeriod timePeriod13 = timePeriodValues3.getTimePeriod(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.String str8 = timePeriodValues3.getDomainDescription();
        boolean boolean9 = timePeriodValues3.getNotify();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=1577865599999]");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        long long9 = simpleTimePeriod8.getEndMillis();
        boolean boolean11 = simpleTimePeriod8.equals((java.lang.Object) '4');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        java.lang.Object obj7 = timePeriodValues3.clone();
        timePeriodValues3.delete(7, 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getFirstMillisecond();
        long long3 = year0.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        java.util.Calendar calendar4 = null;
        try {
            year0.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date15, timeZone18);
        java.util.Calendar calendar20 = null;
        try {
            long long21 = day19.getFirstMillisecond(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeZone18);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.String str8 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setRangeDescription("TimePeriodValue[2019,0]");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Object obj8 = timePeriodValues3.clone();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener10);
        java.lang.String str12 = timePeriodValues3.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "hi!" + "'", str12.equals("hi!"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Object obj1 = null;
        boolean boolean2 = year0.equals(obj1);
        long long3 = year0.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        java.lang.Object obj7 = timePeriodValues3.clone();
        timePeriodValues3.setRangeDescription("");
        org.jfree.data.time.TimePeriod timePeriod10 = null;
        try {
            timePeriodValues3.add(timePeriod10, (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.String str8 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        java.lang.Object obj10 = timePeriodValues3.clone();
        timePeriodValues3.setDescription("");
        int int13 = timePeriodValues3.getMaxEndIndex();
        int int14 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (0) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date15, timeZone18);
        int int20 = day19.getMonth();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 12 + "'", int20 == 12);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.String str5 = timePeriodValues3.getRangeDescription();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.previous();
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year11, (double) 4);
        java.util.Calendar calendar14 = null;
        try {
            year11.peg(calendar14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        timePeriodValues3.setRangeDescription("hi!");
        timePeriodValues3.fireSeriesChanged();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue11 = timePeriodValues3.getDataItem((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.String str5 = timePeriodValues3.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener6);
        int int8 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        timePeriodValues3.setRangeDescription("hi!");
        timePeriodValues3.fireSeriesChanged();
        try {
            timePeriodValues3.update((int) (short) 10, (java.lang.Number) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            day0.peg(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(31, 12, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        try {
            java.lang.Number number5 = timePeriodValues3.getValue(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 11, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        java.util.Calendar calendar18 = null;
        try {
            long long19 = year17.getFirstMillisecond(calendar18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) ' ', 12, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        java.lang.Object obj7 = timePeriodValues3.clone();
        timePeriodValues3.delete(6, (int) (byte) 1);
        timePeriodValues3.setNotify(true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (11) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date15, timeZone18);
        java.util.Calendar calendar20 = null;
        try {
            long long21 = day19.getLastMillisecond(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeZone18);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("TimePeriodValue[2019,null]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str5 = seriesException1.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.general.SeriesException: TimePeriodValue[2019,null]" + "'", str5.equals("org.jfree.data.general.SeriesException: TimePeriodValue[2019,null]"));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date15, timeZone18);
        int int20 = day19.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = day19.previous();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 31 + "'", int20 == 31);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.general.SeriesChangeEvent[source=1577865599999]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 10, (long) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) (-1L));
        long long3 = year0.getLastMillisecond();
        java.util.Date date4 = year0.getStart();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getLastMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.String str5 = timePeriodValues3.getRangeDescription();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.previous();
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year11, (double) 4);
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 2);
        java.lang.Number number16 = null;
        timePeriodValue15.setValue(number16);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.setKey((java.lang.Comparable) 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date15, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.next();
        java.util.Calendar calendar21 = null;
        try {
            long long22 = day19.getFirstMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (31) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test078");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        int int2 = day0.getDayOfMonth();
//        int int3 = day0.getYear();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 13 + "'", int2 == 13);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        java.lang.Class<?> wildcardClass4 = date3.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.previous();
        java.util.Date date9 = year6.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str15 = timePeriodValues14.getDomainDescription();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.previous();
        java.util.Date date19 = year16.getEnd();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year20.previous();
        java.util.Date date23 = year20.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod(date19, date23);
        long long25 = simpleTimePeriod24.getEndMillis();
        java.util.Date date26 = simpleTimePeriod24.getStart();
        boolean boolean27 = timePeriodValues14.equals((java.lang.Object) date26);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date26);
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str33 = timePeriodValues32.getDomainDescription();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        long long35 = year34.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year34.previous();
        java.util.Date date37 = year34.getEnd();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        long long39 = year38.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year38.previous();
        java.util.Date date41 = year38.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod(date37, date41);
        long long43 = simpleTimePeriod42.getEndMillis();
        java.util.Date date44 = simpleTimePeriod42.getStart();
        boolean boolean45 = timePeriodValues32.equals((java.lang.Object) date44);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date44);
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date44, timeZone47);
        org.jfree.data.time.Day day49 = new org.jfree.data.time.Day(date26, timeZone47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date9, timeZone47);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1546329600000L + "'", long35 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1546329600000L + "'", long39 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1577865599999L + "'", long43 == 1577865599999L);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) ' ', (int) (byte) 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("TimePeriodValue[2019,0]");
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("hi!");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("TimePeriodValue[2019,null]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int5 = timePeriodValues4.getMinMiddleIndex();
        timePeriodValues4.setDescription("hi!");
        int int8 = day0.compareTo((java.lang.Object) timePeriodValues4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        boolean boolean3 = year0.equals((java.lang.Object) 1577865599999L);
        java.lang.Number number4 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, number4);
        long long6 = year0.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getItemCount();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getFirstMillisecond();
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.String str8 = timePeriodValues3.getDomainDescription();
        int int9 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener10);
        try {
            java.lang.Number number13 = timePeriodValues3.getValue((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        timePeriodValues3.setDomainDescription("org.jfree.data.general.SeriesException: TimePeriodValue[2019,null]");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.String str8 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesException: TimePeriodValue[2019,null]");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1.0d);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener2 = null;
        timePeriodValues1.removeChangeListener(seriesChangeListener2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getSerialIndex();
        long long6 = year4.getFirstMillisecond();
        long long7 = year4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year4.next();
        timePeriodValues1.setKey((java.lang.Comparable) regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2019L + "'", long5 == 2019L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        boolean boolean3 = year0.equals((java.lang.Object) 1577865599999L);
        java.lang.Number number4 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, number4);
        java.lang.Number number6 = timePeriodValue5.getValue();
        java.lang.String str7 = timePeriodValue5.toString();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year8.previous();
        java.util.Date date11 = year8.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.previous();
        java.util.Date date15 = year12.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(date11, date15);
        long long17 = simpleTimePeriod16.getEndMillis();
        java.util.Date date18 = simpleTimePeriod16.getStart();
        boolean boolean19 = timePeriodValue5.equals((java.lang.Object) date18);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TimePeriodValue[2019,null]" + "'", str7.equals("TimePeriodValue[2019,null]"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        boolean boolean3 = year0.equals((java.lang.Object) 1577865599999L);
        java.lang.Number number4 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, number4);
        timePeriodValue5.setValue((java.lang.Number) 1L);
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str12 = timePeriodValues11.getDomainDescription();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.previous();
        java.util.Date date16 = year13.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year17.previous();
        java.util.Date date20 = year17.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date16, date20);
        long long22 = simpleTimePeriod21.getEndMillis();
        java.util.Date date23 = simpleTimePeriod21.getStart();
        boolean boolean24 = timePeriodValues11.equals((java.lang.Object) date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date23, timeZone26);
        long long28 = day27.getFirstMillisecond();
        boolean boolean29 = timePeriodValue5.equals((java.lang.Object) day27);
        java.lang.String str30 = timePeriodValue5.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577779200000L + "'", long28 == 1577779200000L);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "TimePeriodValue[2019,1]" + "'", str30.equals("TimePeriodValue[2019,1]"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("TimePeriodValue[2019,0]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMaxStartIndex();
        java.lang.String str5 = timePeriodValues3.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str12 = timePeriodValues11.getDomainDescription();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.previous();
        java.util.Date date16 = year13.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year17.previous();
        java.util.Date date20 = year17.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date16, date20);
        long long22 = simpleTimePeriod21.getEndMillis();
        java.util.Date date23 = simpleTimePeriod21.getStart();
        boolean boolean24 = timePeriodValues11.equals((java.lang.Object) date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year25, (java.lang.Number) 100.0f);
        java.lang.String str28 = timePeriodValues3.getDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(str28);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Comparable comparable5 = timePeriodValues3.getKey();
        int int6 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = null;
        try {
            timePeriodValues3.add(timePeriodValue7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null item not allowed.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 10.0f + "'", comparable5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        boolean boolean3 = year0.equals((java.lang.Object) 1577865599999L);
        boolean boolean5 = year0.equals((java.lang.Object) 2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1.0d);
        timePeriodValues1.setNotify(false);
        boolean boolean4 = timePeriodValues1.getNotify();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str8 = timePeriodValues7.getDomainDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.previous();
        java.util.Date date16 = year13.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod(date12, date16);
        long long18 = simpleTimePeriod17.getEndMillis();
        java.util.Date date19 = simpleTimePeriod17.getStart();
        boolean boolean20 = timePeriodValues7.equals((java.lang.Object) date19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date19);
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date19, timeZone22);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod(date3, date19);
        boolean boolean26 = simpleTimePeriod24.equals((java.lang.Object) 3);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1.0d);
        timePeriodValues1.setNotify(false);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = null;
        try {
            timePeriodValues1.add(timePeriodValue4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null item not allowed.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        java.util.Date date18 = year17.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues22 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1), "", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timePeriodValues22.removeChangeListener(seriesChangeListener23);
        org.jfree.data.time.TimePeriodValues timePeriodValues27 = timePeriodValues22.createCopy((int) (short) -1, (int) (byte) -1);
        boolean boolean28 = timePeriodValues22.isEmpty();
        boolean boolean29 = year17.equals((java.lang.Object) timePeriodValues22);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(timePeriodValues27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        timePeriodValues3.fireSeriesChanged();
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("org.jfree.data.general.SeriesChangeEvent[source=1577865599999]");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.String str5 = timePeriodValues3.getRangeDescription();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str11 = timePeriodValues10.getDomainDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.previous();
        java.util.Date date15 = year12.getEnd();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.previous();
        java.util.Date date19 = year16.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date15, date19);
        long long21 = simpleTimePeriod20.getEndMillis();
        java.util.Date date22 = simpleTimePeriod20.getStart();
        boolean boolean23 = timePeriodValues10.equals((java.lang.Object) date22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date22);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date22, timeZone25);
        int int27 = day26.getDayOfMonth();
        int int28 = day26.getMonth();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day26, (double) 1.0f);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        java.lang.Object obj32 = null;
        boolean boolean33 = year31.equals(obj32);
        java.util.Date date34 = year31.getStart();
        java.lang.Class<?> wildcardClass35 = year31.getClass();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        int int38 = year36.compareTo((java.lang.Object) (-1L));
        long long39 = year36.getLastMillisecond();
        java.util.Date date40 = year36.getStart();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        long long42 = year41.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year41.previous();
        java.util.Date date44 = year41.getEnd();
        java.lang.Class<?> wildcardClass45 = date44.getClass();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        long long47 = year46.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year46.previous();
        java.util.Date date49 = year46.getEnd();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        long long51 = year50.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year50.previous();
        java.util.Date date53 = year50.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod54 = new org.jfree.data.time.SimpleTimePeriod(date49, date53);
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date49, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date40, timeZone55);
        boolean boolean58 = day26.equals((java.lang.Object) wildcardClass35);
        java.util.Calendar calendar59 = null;
        try {
            long long60 = day26.getLastMillisecond(calendar59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 31 + "'", int27 == 31);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 12 + "'", int28 == 12);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1577865599999L + "'", long39 == 1577865599999L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1546329600000L + "'", long42 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1546329600000L + "'", long47 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1546329600000L + "'", long51 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException4 = new org.jfree.data.time.TimePeriodFormatException("");
        timePeriodFormatException1.addSuppressed((java.lang.Throwable) timePeriodFormatException4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date15, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.next();
        java.util.Calendar calendar21 = null;
        try {
            long long22 = day19.getLastMillisecond(calendar21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Object obj8 = timePeriodValues3.clone();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setKey((java.lang.Comparable) (-1));
        timePeriodValues3.setRangeDescription("2019");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("2019");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.previous();
        java.util.Date date4 = year1.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str9 = timePeriodValues8.getDomainDescription();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.previous();
        java.util.Date date13 = year10.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year14.previous();
        java.util.Date date17 = year14.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(date13, date17);
        long long19 = simpleTimePeriod18.getEndMillis();
        java.util.Date date20 = simpleTimePeriod18.getStart();
        boolean boolean21 = timePeriodValues8.equals((java.lang.Object) date20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date20);
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date20, timeZone23);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod(date4, date20);
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str30 = timePeriodValues29.getDomainDescription();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        long long32 = year31.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year31.previous();
        java.util.Date date34 = year31.getEnd();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        long long36 = year35.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year35.previous();
        java.util.Date date38 = year35.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date34, date38);
        long long40 = simpleTimePeriod39.getEndMillis();
        java.util.Date date41 = simpleTimePeriod39.getStart();
        boolean boolean42 = timePeriodValues29.equals((java.lang.Object) date41);
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date41);
        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str48 = timePeriodValues47.getDomainDescription();
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
        long long50 = year49.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year49.previous();
        java.util.Date date52 = year49.getEnd();
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
        long long54 = year53.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = year53.previous();
        java.util.Date date56 = year53.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod57 = new org.jfree.data.time.SimpleTimePeriod(date52, date56);
        long long58 = simpleTimePeriod57.getEndMillis();
        java.util.Date date59 = simpleTimePeriod57.getStart();
        boolean boolean60 = timePeriodValues47.equals((java.lang.Object) date59);
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date59);
        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date59, timeZone62);
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date41, timeZone62);
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year(date4, timeZone62);
        int int66 = year0.compareTo((java.lang.Object) timeZone62);
        java.util.Calendar calendar67 = null;
        try {
            year0.peg(calendar67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1546329600000L + "'", long32 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1546329600000L + "'", long36 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "" + "'", str48.equals(""));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1546329600000L + "'", long50 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1546329600000L + "'", long54 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1577865599999L + "'", long58 == 1577865599999L);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.String str8 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        java.lang.Object obj10 = timePeriodValues3.clone();
        int int11 = timePeriodValues3.getMaxEndIndex();
        try {
            timePeriodValues3.delete((int) '4', (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) (-1L));
        java.util.Calendar calendar3 = null;
        try {
            year0.peg(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Object obj1 = null;
        boolean boolean2 = year0.equals(obj1);
        java.util.Date date3 = year0.getStart();
        java.lang.Class<?> wildcardClass4 = year0.getClass();
        org.jfree.data.time.TimePeriodValue timePeriodValue6 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (double) 1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.String str8 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        timePeriodValues3.setKey((java.lang.Comparable) 'a');
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getFirstMillisecond();
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) long14);
        boolean boolean16 = year0.equals((java.lang.Object) seriesChangeEvent15);
        java.lang.Object obj17 = seriesChangeEvent15.getSource();
        java.lang.String str18 = seriesChangeEvent15.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + obj17 + "' != '" + 1577865599999L + "'", obj17.equals(1577865599999L));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1577865599999]" + "'", str18.equals("org.jfree.data.general.SeriesChangeEvent[source=1577865599999]"));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        java.lang.Object obj7 = timePeriodValues3.clone();
        timePeriodValues3.setRangeDescription("");
        int int10 = timePeriodValues3.getMaxEndIndex();
        int int11 = timePeriodValues3.getMaxMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener12);
        timePeriodValues3.setDomainDescription("TimePeriodValue[2019,0]");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        boolean boolean3 = year0.equals((java.lang.Object) 1577865599999L);
        java.lang.Number number4 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, number4);
        timePeriodValue5.setValue((java.lang.Number) 1L);
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str12 = timePeriodValues11.getDomainDescription();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.previous();
        java.util.Date date16 = year13.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year17.previous();
        java.util.Date date20 = year17.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date16, date20);
        long long22 = simpleTimePeriod21.getEndMillis();
        java.util.Date date23 = simpleTimePeriod21.getStart();
        boolean boolean24 = timePeriodValues11.equals((java.lang.Object) date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date23, timeZone26);
        long long28 = day27.getFirstMillisecond();
        boolean boolean29 = timePeriodValue5.equals((java.lang.Object) day27);
        java.util.Calendar calendar30 = null;
        try {
            long long31 = day27.getFirstMillisecond(calendar30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1577779200000L + "'", long28 == 1577779200000L);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date15, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.next();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        long long22 = year21.getFirstMillisecond();
        boolean boolean24 = year21.equals((java.lang.Object) 1577865599999L);
        java.lang.Number number25 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year21, number25);
        java.lang.Number number27 = timePeriodValue26.getValue();
        boolean boolean28 = day19.equals((java.lang.Object) timePeriodValue26);
        java.util.Date date29 = day19.getStart();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(number27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(date29);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.time.TimePeriodValues timePeriodValues1 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 0L);
        timePeriodValues1.setDomainDescription("2019");
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date15, timeZone18);
        long long20 = day19.getFirstMillisecond();
        long long21 = day19.getSerialIndex();
        java.util.Calendar calendar22 = null;
        try {
            day19.peg(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577779200000L + "'", long20 == 1577779200000L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43830L + "'", long21 == 43830L);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.String str8 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        java.lang.Object obj10 = timePeriodValues3.clone();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 0.0f);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year11.previous();
        java.util.Calendar calendar15 = null;
        try {
            long long16 = year11.getLastMillisecond(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.String str8 = timePeriodValues3.getDomainDescription();
        int int9 = timePeriodValues3.getMinEndIndex();
        int int10 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date15, timeZone18);
        long long20 = day19.getFirstMillisecond();
        java.lang.String str21 = day19.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577779200000L + "'", long20 == 1577779200000L);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "31-December-2019" + "'", str21.equals("31-December-2019"));
    }

//    @Test
//    public void test123() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test123");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        long long2 = day0.getFirstMillisecond();
//        java.lang.String str3 = day0.toString();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "13-June-2019" + "'", str3.equals("13-June-2019"));
//    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        try {
            org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValues3.getTimePeriod((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.String str8 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        java.lang.Object obj10 = timePeriodValues3.clone();
        timePeriodValues3.setDescription("");
        timePeriodValues3.setDescription("TimePeriodValue[2019,1]");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener15);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(0L, (long) 11);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.lang.Class class0 = null;
        org.jfree.data.time.TimePeriodValues timePeriodValues4 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str5 = timePeriodValues4.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.previous();
        java.util.Date date9 = year6.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.previous();
        java.util.Date date13 = year10.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date9, date13);
        long long15 = simpleTimePeriod14.getEndMillis();
        java.util.Date date16 = simpleTimePeriod14.getStart();
        boolean boolean17 = timePeriodValues4.equals((java.lang.Object) date16);
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.previous();
        java.util.Date date21 = year18.getEnd();
        java.lang.Class<?> wildcardClass22 = date21.getClass();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        long long24 = year23.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year23.previous();
        java.util.Date date26 = year23.getEnd();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year27.previous();
        java.util.Date date30 = year27.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod(date26, date30);
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date26, timeZone32);
        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str38 = timePeriodValues37.getDomainDescription();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        long long40 = year39.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year39.previous();
        java.util.Date date42 = year39.getEnd();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        long long44 = year43.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year43.previous();
        java.util.Date date46 = year43.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod(date42, date46);
        long long48 = simpleTimePeriod47.getEndMillis();
        java.util.Date date49 = simpleTimePeriod47.getStart();
        boolean boolean50 = timePeriodValues37.equals((java.lang.Object) date49);
        org.jfree.data.time.TimePeriodValues timePeriodValues54 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int55 = timePeriodValues54.getMinMiddleIndex();
        timePeriodValues54.setDescription("hi!");
        boolean boolean58 = timePeriodValues54.isEmpty();
        java.lang.Object obj59 = timePeriodValues54.clone();
        int int60 = timePeriodValues54.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass61 = timePeriodValues54.getClass();
        java.util.Date date62 = null;
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year();
        long long64 = year63.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = year63.previous();
        java.util.Date date66 = year63.getEnd();
        java.lang.Class<?> wildcardClass67 = date66.getClass();
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year();
        long long69 = year68.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = year68.previous();
        java.util.Date date71 = year68.getEnd();
        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year();
        long long73 = year72.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = year72.previous();
        java.util.Date date75 = year72.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod76 = new org.jfree.data.time.SimpleTimePeriod(date71, date75);
        java.util.TimeZone timeZone77 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod78 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass67, date71, timeZone77);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod79 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass61, date62, timeZone77);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass22, date49, timeZone77);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod81 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date16, timeZone77);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1546329600000L + "'", long28 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1546329600000L + "'", long40 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1546329600000L + "'", long44 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1577865599999L + "'", long48 == 1577865599999L);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(obj59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 1546329600000L + "'", long64 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertNotNull(wildcardClass67);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1546329600000L + "'", long69 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertTrue("'" + long73 + "' != '" + 1546329600000L + "'", long73 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod74);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNotNull(timeZone77);
        org.junit.Assert.assertNull(regularTimePeriod78);
        org.junit.Assert.assertNull(regularTimePeriod79);
        org.junit.Assert.assertNull(regularTimePeriod80);
        org.junit.Assert.assertNull(regularTimePeriod81);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMaxStartIndex();
        java.lang.Object obj6 = timePeriodValues3.clone();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Object obj8 = timePeriodValues3.clone();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setKey((java.lang.Comparable) (-1));
        java.lang.String str12 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        java.lang.Object obj7 = timePeriodValues3.clone();
        timePeriodValues3.setRangeDescription("");
        timePeriodValues3.setDomainDescription("hi!");
        int int12 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener13);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date15, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.next();
        int int21 = day19.getYear();
        int int22 = day19.getYear();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2019 + "'", int22 == 2019);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.String str8 = timePeriodValues3.getDomainDescription();
        int int9 = timePeriodValues3.getMinEndIndex();
        int int10 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener11);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue14 = timePeriodValues3.getDataItem((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("TimePeriodValue[2019,null]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.String str5 = timePeriodFormatException3.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str5.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Object obj8 = timePeriodValues3.clone();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = timePeriodValues3.createCopy(7, (-1));
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues12);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(11, (int) (short) -1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        java.lang.Object obj7 = timePeriodValues3.clone();
        timePeriodValues3.setRangeDescription("");
        int int10 = timePeriodValues3.getMaxEndIndex();
        int int11 = timePeriodValues3.getMaxMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener12);
        java.lang.String str14 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getFirstMillisecond();
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) long14);
        boolean boolean16 = year0.equals((java.lang.Object) seriesChangeEvent15);
        java.lang.Object obj17 = seriesChangeEvent15.getSource();
        java.lang.Object obj18 = seriesChangeEvent15.getSource();
        java.lang.String str19 = seriesChangeEvent15.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + obj17 + "' != '" + 1577865599999L + "'", obj17.equals(1577865599999L));
        org.junit.Assert.assertTrue("'" + obj18 + "' != '" + 1577865599999L + "'", obj18.equals(1577865599999L));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1577865599999]" + "'", str19.equals("org.jfree.data.general.SeriesChangeEvent[source=1577865599999]"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str22 = timePeriodValues21.getDomainDescription();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        long long24 = year23.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year23.previous();
        java.util.Date date26 = year23.getEnd();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year27.previous();
        java.util.Date date30 = year27.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod(date26, date30);
        long long32 = simpleTimePeriod31.getEndMillis();
        java.util.Date date33 = simpleTimePeriod31.getStart();
        boolean boolean34 = timePeriodValues21.equals((java.lang.Object) date33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date33);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date33, timeZone36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date15, timeZone36);
        org.jfree.data.time.SerialDate serialDate39 = day38.getSerialDate();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(serialDate39);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1546329600000L + "'", long28 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(serialDate39);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        long long9 = simpleTimePeriod8.getEndMillis();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) long9);
        java.lang.Object obj11 = seriesChangeEvent10.getSource();
        java.lang.Object obj12 = seriesChangeEvent10.getSource();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + obj11 + "' != '" + 1577865599999L + "'", obj11.equals(1577865599999L));
        org.junit.Assert.assertTrue("'" + obj12 + "' != '" + 1577865599999L + "'", obj12.equals(1577865599999L));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str22 = timePeriodValues21.getDomainDescription();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        long long24 = year23.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year23.previous();
        java.util.Date date26 = year23.getEnd();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year27.previous();
        java.util.Date date30 = year27.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod(date26, date30);
        long long32 = simpleTimePeriod31.getEndMillis();
        java.util.Date date33 = simpleTimePeriod31.getStart();
        boolean boolean34 = timePeriodValues21.equals((java.lang.Object) date33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date33);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date33, timeZone36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date15, timeZone36);
        org.jfree.data.time.SerialDate serialDate39 = day38.getSerialDate();
        long long40 = day38.getLastMillisecond();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        java.lang.Object obj42 = null;
        boolean boolean43 = year41.equals(obj42);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = year41.previous();
        boolean boolean45 = day38.equals((java.lang.Object) regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1546329600000L + "'", long28 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Object obj1 = null;
        boolean boolean2 = year0.equals(obj1);
        java.util.Date date3 = year0.getStart();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str8 = timePeriodValues7.getDomainDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.previous();
        java.util.Date date16 = year13.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod(date12, date16);
        long long18 = simpleTimePeriod17.getEndMillis();
        java.util.Date date19 = simpleTimePeriod17.getStart();
        boolean boolean20 = timePeriodValues7.equals((java.lang.Object) date19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date19);
        org.jfree.data.time.TimePeriodValue timePeriodValue23 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year21, (java.lang.Number) (short) 0);
        int int24 = year21.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year21.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = year21.previous();
        int int27 = year0.compareTo((java.lang.Object) regularTimePeriod26);
        int int28 = year0.getYear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 2019 + "'", int24 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 2019 + "'", int28 == 2019);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        java.lang.Object obj7 = timePeriodValues3.clone();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener8);
        java.lang.Object obj10 = timePeriodValues3.clone();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        java.lang.Object obj7 = timePeriodValues3.clone();
        timePeriodValues3.delete(6, (int) (byte) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int15 = timePeriodValues14.getMinMiddleIndex();
        timePeriodValues14.setDescription("hi!");
        boolean boolean18 = timePeriodValues14.isEmpty();
        java.lang.String str19 = timePeriodValues14.getDomainDescription();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getFirstMillisecond();
        boolean boolean23 = year20.equals((java.lang.Object) 1577865599999L);
        java.lang.Number number24 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue25 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year20, number24);
        timePeriodValue25.setValue((java.lang.Number) 1L);
        timePeriodValues14.add(timePeriodValue25);
        timePeriodValues3.add(timePeriodValue25);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = year0.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMaxStartIndex();
        boolean boolean5 = timePeriodValues3.getNotify();
        int int6 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) (short) 0);
        java.util.Date date20 = year17.getEnd();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date20);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.time.TimePeriodFormatException: hi!");
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getFirstMillisecond();
        boolean boolean10 = year7.equals((java.lang.Object) 1577865599999L);
        java.lang.Number number11 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, number11);
        timePeriodValue12.setValue((java.lang.Number) 1L);
        timePeriodValues3.add(timePeriodValue12);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str20 = timePeriodValues19.getDomainDescription();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        long long22 = year21.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year21.previous();
        java.util.Date date24 = year21.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year25.previous();
        java.util.Date date28 = year25.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod(date24, date28);
        long long30 = simpleTimePeriod29.getEndMillis();
        java.util.Date date31 = simpleTimePeriod29.getStart();
        boolean boolean32 = timePeriodValues19.equals((java.lang.Object) date31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date31);
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date31, timeZone34);
        long long36 = day35.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day35, (java.lang.Number) 1.0d);
        java.util.Calendar calendar39 = null;
        try {
            long long40 = day35.getLastMillisecond(calendar39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1577865599999L + "'", long30 == 1577865599999L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 43830L + "'", long36 == 43830L);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str8 = timePeriodValues7.getDomainDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.previous();
        java.util.Date date16 = year13.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod(date12, date16);
        long long18 = simpleTimePeriod17.getEndMillis();
        java.util.Date date19 = simpleTimePeriod17.getStart();
        boolean boolean20 = timePeriodValues7.equals((java.lang.Object) date19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date19);
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date19, timeZone22);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod(date3, date19);
        java.util.Date date25 = simpleTimePeriod24.getEnd();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date25, timeZone26);
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int32 = timePeriodValues31.getMinMiddleIndex();
        timePeriodValues31.setDescription("hi!");
        boolean boolean35 = timePeriodValues31.isEmpty();
        java.lang.Object obj36 = timePeriodValues31.clone();
        int int37 = timePeriodValues31.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass38 = timePeriodValues31.getClass();
        java.util.Date date39 = null;
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        long long41 = year40.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year40.previous();
        java.util.Date date43 = year40.getEnd();
        java.lang.Class<?> wildcardClass44 = date43.getClass();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        long long46 = year45.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year45.previous();
        java.util.Date date48 = year45.getEnd();
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
        long long50 = year49.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year49.previous();
        java.util.Date date52 = year49.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod(date48, date52);
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass44, date48, timeZone54);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date39, timeZone54);
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date25, timeZone54);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = year57.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1546329600000L + "'", long41 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1546329600000L + "'", long46 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1546329600000L + "'", long50 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        long long9 = simpleTimePeriod8.getEndMillis();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent10 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) long9);
        java.lang.Object obj11 = seriesChangeEvent10.getSource();
        java.lang.String str12 = seriesChangeEvent10.toString();
        java.lang.String str13 = seriesChangeEvent10.toString();
        java.lang.Object obj14 = seriesChangeEvent10.getSource();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + obj11 + "' != '" + 1577865599999L + "'", obj11.equals(1577865599999L));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1577865599999]" + "'", str12.equals("org.jfree.data.general.SeriesChangeEvent[source=1577865599999]"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1577865599999]" + "'", str13.equals("org.jfree.data.general.SeriesChangeEvent[source=1577865599999]"));
        org.junit.Assert.assertTrue("'" + obj14 + "' != '" + 1577865599999L + "'", obj14.equals(1577865599999L));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        java.lang.Object obj7 = timePeriodValues3.clone();
        timePeriodValues3.setRangeDescription("");
        int int10 = timePeriodValues3.getMaxEndIndex();
        int int11 = timePeriodValues3.getMaxMiddleIndex();
        int int12 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) "org.jfree.data.time.TimePeriodFormatException: hi!");
        java.lang.Object obj2 = seriesChangeEvent1.getSource();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", obj2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        java.lang.Class<?> wildcardClass4 = date3.getClass();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str13 = timePeriodValues12.getDomainDescription();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year14.previous();
        java.util.Date date17 = year14.getEnd();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.previous();
        java.util.Date date21 = year18.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date17, date21);
        long long23 = simpleTimePeriod22.getEndMillis();
        java.util.Date date24 = simpleTimePeriod22.getStart();
        boolean boolean25 = timePeriodValues12.equals((java.lang.Object) date24);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date24);
        java.util.TimeZone timeZone27 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date24, timeZone27);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod(date8, date24);
        java.util.Date date30 = simpleTimePeriod29.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str35 = timePeriodValues34.getDomainDescription();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        long long37 = year36.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year36.previous();
        java.util.Date date39 = year36.getEnd();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        long long41 = year40.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year40.previous();
        java.util.Date date43 = year40.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod(date39, date43);
        long long45 = simpleTimePeriod44.getEndMillis();
        java.util.Date date46 = simpleTimePeriod44.getStart();
        boolean boolean47 = timePeriodValues34.equals((java.lang.Object) date46);
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date46);
        java.util.TimeZone timeZone49 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date46, timeZone49);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date30, timeZone49);
        java.lang.Class class52 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(timeZone27);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "" + "'", str35.equals(""));
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1546329600000L + "'", long37 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1546329600000L + "'", long41 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1577865599999L + "'", long45 == 1577865599999L);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(timeZone49);
        org.junit.Assert.assertNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(class52);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        boolean boolean3 = year0.equals((java.lang.Object) 1577865599999L);
        java.lang.Number number4 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, number4);
        long long6 = year0.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1577865599999L + "'", long6 == 1577865599999L);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        boolean boolean3 = year0.equals((java.lang.Object) 1577865599999L);
        boolean boolean5 = year0.equals((java.lang.Object) 2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        long long9 = simpleTimePeriod8.getEndMillis();
        long long10 = simpleTimePeriod8.getStartMillis();
        long long11 = simpleTimePeriod8.getStartMillis();
        java.util.Date date12 = simpleTimePeriod8.getStart();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date12, timeZone13);
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year14, (java.lang.Number) 1.0f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone13);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.Class<?> wildcardClass2 = year0.getClass();
        java.util.Date date3 = year0.getEnd();
        int int4 = year0.getYear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("2019");
        java.lang.String str2 = timePeriodFormatException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: 2019" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: 2019"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        java.lang.Object obj7 = timePeriodValues3.clone();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener8);
        try {
            org.jfree.data.time.TimePeriod timePeriod11 = timePeriodValues3.getTimePeriod((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str8 = timePeriodValues7.getDomainDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.previous();
        java.util.Date date16 = year13.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod(date12, date16);
        long long18 = simpleTimePeriod17.getEndMillis();
        java.util.Date date19 = simpleTimePeriod17.getStart();
        boolean boolean20 = timePeriodValues7.equals((java.lang.Object) date19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date19);
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date19, timeZone22);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod(date3, date19);
        java.util.Date date25 = simpleTimePeriod24.getEnd();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date25, timeZone26);
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int32 = timePeriodValues31.getMinMiddleIndex();
        timePeriodValues31.setDescription("hi!");
        boolean boolean35 = timePeriodValues31.isEmpty();
        java.lang.Object obj36 = timePeriodValues31.clone();
        int int37 = timePeriodValues31.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass38 = timePeriodValues31.getClass();
        java.util.Date date39 = null;
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        long long41 = year40.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year40.previous();
        java.util.Date date43 = year40.getEnd();
        java.lang.Class<?> wildcardClass44 = date43.getClass();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        long long46 = year45.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year45.previous();
        java.util.Date date48 = year45.getEnd();
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
        long long50 = year49.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year49.previous();
        java.util.Date date52 = year49.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod(date48, date52);
        java.util.TimeZone timeZone54 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass44, date48, timeZone54);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass38, date39, timeZone54);
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date25, timeZone54);
        java.util.Calendar calendar58 = null;
        try {
            year57.peg(calendar58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass38);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1546329600000L + "'", long41 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1546329600000L + "'", long46 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1546329600000L + "'", long50 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(timeZone54);
        org.junit.Assert.assertNull(regularTimePeriod55);
        org.junit.Assert.assertNull(regularTimePeriod56);
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test161");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        long long2 = day0.getFirstMillisecond();
//        java.util.Calendar calendar3 = null;
//        try {
//            long long4 = day0.getLastMillisecond(calendar3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        boolean boolean3 = year0.equals((java.lang.Object) 1577865599999L);
        java.lang.Number number4 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, number4);
        java.lang.Number number6 = timePeriodValue5.getValue();
        java.lang.Object obj7 = timePeriodValue5.clone();
        java.lang.Class<?> wildcardClass8 = timePeriodValue5.getClass();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.String str5 = timePeriodValues3.getRangeDescription();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str11 = timePeriodValues10.getDomainDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.previous();
        java.util.Date date15 = year12.getEnd();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.previous();
        java.util.Date date19 = year16.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date15, date19);
        long long21 = simpleTimePeriod20.getEndMillis();
        java.util.Date date22 = simpleTimePeriod20.getStart();
        boolean boolean23 = timePeriodValues10.equals((java.lang.Object) date22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date22);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date22, timeZone25);
        int int27 = day26.getDayOfMonth();
        int int28 = day26.getMonth();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day26, (double) 1.0f);
        timePeriodValues3.setDescription("TimePeriodValue[2019,null]");
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 31 + "'", int27 == 31);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 12 + "'", int28 == 12);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 1, (long) 11);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year3.previous();
        java.util.Date date6 = year3.getEnd();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.previous();
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(date6, date10);
        long long12 = simpleTimePeriod11.getEndMillis();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) long12);
        boolean boolean14 = simpleTimePeriod2.equals((java.lang.Object) long12);
        boolean boolean16 = simpleTimePeriod2.equals((java.lang.Object) 1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        long long5 = year4.getMiddleMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year4.getMiddleMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        java.lang.Object obj7 = timePeriodValues3.clone();
        timePeriodValues3.delete(6, (int) (byte) 1);
        timePeriodValues3.setDescription("org.jfree.data.general.SeriesChangeEvent[source=1577865599999]");
        int int13 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setDescription("");
        boolean boolean7 = timePeriodValues3.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues3.createCopy(0, (int) (byte) 100);
        boolean boolean11 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str8 = timePeriodValues7.getDomainDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.previous();
        java.util.Date date16 = year13.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod(date12, date16);
        long long18 = simpleTimePeriod17.getEndMillis();
        java.util.Date date19 = simpleTimePeriod17.getStart();
        boolean boolean20 = timePeriodValues7.equals((java.lang.Object) date19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date19);
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date19, timeZone22);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod(date3, date19);
        java.util.Date date25 = simpleTimePeriod24.getEnd();
        java.util.Date date26 = simpleTimePeriod24.getStart();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(date26);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getFirstMillisecond();
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) long14);
        boolean boolean16 = year0.equals((java.lang.Object) seriesChangeEvent15);
        java.lang.String str17 = seriesChangeEvent15.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=1577865599999]" + "'", str17.equals("org.jfree.data.general.SeriesChangeEvent[source=1577865599999]"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Object obj8 = timePeriodValues3.clone();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass10 = timePeriodValues3.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = timePeriodValues3.createCopy(2019, 8);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(timePeriodValues13);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        timePeriodValues3.setRangeDescription("hi!");
        timePeriodValues3.fireSeriesChanged();
        try {
            java.lang.Number number11 = timePeriodValues3.getValue(13);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 13, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year4.next();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.Class<?> wildcardClass2 = year0.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertNotNull(class4);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        java.lang.Class<?> wildcardClass4 = date3.getClass();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date8, timeZone14);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str20 = timePeriodValues19.getDomainDescription();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        long long22 = year21.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year21.previous();
        java.util.Date date24 = year21.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year25.previous();
        java.util.Date date28 = year25.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod(date24, date28);
        long long30 = simpleTimePeriod29.getEndMillis();
        java.util.Date date31 = simpleTimePeriod29.getStart();
        boolean boolean32 = timePeriodValues19.equals((java.lang.Object) date31);
        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int37 = timePeriodValues36.getMinMiddleIndex();
        timePeriodValues36.setDescription("hi!");
        boolean boolean40 = timePeriodValues36.isEmpty();
        java.lang.Object obj41 = timePeriodValues36.clone();
        int int42 = timePeriodValues36.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass43 = timePeriodValues36.getClass();
        java.util.Date date44 = null;
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        long long46 = year45.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year45.previous();
        java.util.Date date48 = year45.getEnd();
        java.lang.Class<?> wildcardClass49 = date48.getClass();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        long long51 = year50.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year50.previous();
        java.util.Date date53 = year50.getEnd();
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        long long55 = year54.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = year54.previous();
        java.util.Date date57 = year54.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod58 = new org.jfree.data.time.SimpleTimePeriod(date53, date57);
        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date53, timeZone59);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date44, timeZone59);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date31, timeZone59);
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date31);
        long long64 = day63.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1577865599999L + "'", long30 == 1577865599999L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1546329600000L + "'", long46 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1546329600000L + "'", long51 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1546329600000L + "'", long55 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(timeZone59);
        org.junit.Assert.assertNull(regularTimePeriod60);
        org.junit.Assert.assertNull(regularTimePeriod61);
        org.junit.Assert.assertNull(regularTimePeriod62);
        org.junit.Assert.assertTrue("'" + long64 + "' != '" + 43830L + "'", long64 == 43830L);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMaxStartIndex();
        java.lang.String str5 = timePeriodValues3.getDomainDescription();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener6);
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str12 = timePeriodValues11.getDomainDescription();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.previous();
        java.util.Date date16 = year13.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year17.previous();
        java.util.Date date20 = year17.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date16, date20);
        long long22 = simpleTimePeriod21.getEndMillis();
        java.util.Date date23 = simpleTimePeriod21.getStart();
        boolean boolean24 = timePeriodValues11.equals((java.lang.Object) date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year25, (java.lang.Number) 100.0f);
        int int28 = timePeriodValues3.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.String str8 = timePeriodValues3.getDomainDescription();
        int int9 = timePeriodValues3.getMinEndIndex();
        int int10 = timePeriodValues3.getMaxStartIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener11 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener11);
        try {
            java.lang.Number number14 = timePeriodValues3.getValue((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.String str8 = timePeriodValues3.getDomainDescription();
        int int9 = timePeriodValues3.getMinEndIndex();
        int int10 = timePeriodValues3.getMaxStartIndex();
        int int11 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date15, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.next();
        long long21 = day19.getLastMillisecond();
        org.jfree.data.time.TimePeriodValues timePeriodValues25 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int26 = timePeriodValues25.getMaxStartIndex();
        int int27 = day19.compareTo((java.lang.Object) int26);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        int int12 = simpleTimePeriod8.compareTo((java.lang.Object) year9);
        java.util.Calendar calendar13 = null;
        try {
            long long14 = year9.getFirstMillisecond(calendar13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.Comparable comparable5 = timePeriodValues3.getKey();
        int int6 = timePeriodValues3.getMaxStartIndex();
        int int7 = timePeriodValues3.getMaxMiddleIndex();
        java.lang.Object obj8 = timePeriodValues3.clone();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + 10.0f + "'", comparable5.equals(10.0f));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.String str8 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        java.lang.Object obj10 = timePeriodValues3.clone();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 0.0f);
        int int14 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.delete(2, 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        boolean boolean3 = year0.equals((java.lang.Object) 1577865599999L);
        java.lang.Number number4 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, number4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.previous();
        java.util.Date date9 = year6.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.previous();
        java.util.Date date13 = year10.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod14 = new org.jfree.data.time.SimpleTimePeriod(date9, date13);
        long long15 = simpleTimePeriod14.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues18 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long15, "TimePeriodValue[2019,0]", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener19 = null;
        timePeriodValues18.removeChangeListener(seriesChangeListener19);
        boolean boolean21 = timePeriodValue5.equals((java.lang.Object) seriesChangeListener19);
        java.lang.String str22 = timePeriodValue5.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1577865599999L + "'", long15 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "TimePeriodValue[2019,null]" + "'", str22.equals("TimePeriodValue[2019,null]"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        java.lang.Object obj7 = timePeriodValues3.clone();
        timePeriodValues3.setRangeDescription("");
        timePeriodValues3.setDomainDescription("hi!");
        int int12 = timePeriodValues3.getMaxStartIndex();
        try {
            java.lang.Number number14 = timePeriodValues3.getValue((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) year17, "hi!", "org.jfree.data.general.SeriesException: TimePeriodValue[2019,null]");
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) (-1L));
        java.lang.String str3 = year0.toString();
        java.util.Date date4 = year0.getEnd();
        java.util.Calendar calendar5 = null;
        try {
            year0.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Object obj8 = timePeriodValues3.clone();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass10 = timePeriodValues3.getClass();
        try {
            java.lang.Number number12 = timePeriodValues3.getValue(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        java.lang.Class<?> wildcardClass4 = date3.getClass();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int9 = timePeriodValues8.getMinMiddleIndex();
        timePeriodValues8.setDescription("hi!");
        boolean boolean12 = timePeriodValues8.isEmpty();
        java.lang.Object obj13 = timePeriodValues8.clone();
        int int14 = timePeriodValues8.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass15 = timePeriodValues8.getClass();
        java.util.Date date16 = null;
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year17.previous();
        java.util.Date date20 = year17.getEnd();
        java.lang.Class<?> wildcardClass21 = date20.getClass();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        long long23 = year22.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year22.previous();
        java.util.Date date25 = year22.getEnd();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        long long27 = year26.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year26.previous();
        java.util.Date date29 = year26.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod(date25, date29);
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date25, timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass15, date16, timeZone31);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date3, timeZone31);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1546329600000L + "'", long27 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNull(regularTimePeriod33);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesChangeEvent[source=1577865599999]");
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        java.lang.Class<?> wildcardClass4 = date3.getClass();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date8, timeZone14);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str20 = timePeriodValues19.getDomainDescription();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        long long22 = year21.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year21.previous();
        java.util.Date date24 = year21.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year25.previous();
        java.util.Date date28 = year25.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod(date24, date28);
        long long30 = simpleTimePeriod29.getEndMillis();
        java.util.Date date31 = simpleTimePeriod29.getStart();
        boolean boolean32 = timePeriodValues19.equals((java.lang.Object) date31);
        org.jfree.data.time.TimePeriodValues timePeriodValues36 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int37 = timePeriodValues36.getMinMiddleIndex();
        timePeriodValues36.setDescription("hi!");
        boolean boolean40 = timePeriodValues36.isEmpty();
        java.lang.Object obj41 = timePeriodValues36.clone();
        int int42 = timePeriodValues36.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass43 = timePeriodValues36.getClass();
        java.util.Date date44 = null;
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        long long46 = year45.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year45.previous();
        java.util.Date date48 = year45.getEnd();
        java.lang.Class<?> wildcardClass49 = date48.getClass();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        long long51 = year50.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year50.previous();
        java.util.Date date53 = year50.getEnd();
        org.jfree.data.time.Year year54 = new org.jfree.data.time.Year();
        long long55 = year54.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = year54.previous();
        java.util.Date date57 = year54.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod58 = new org.jfree.data.time.SimpleTimePeriod(date53, date57);
        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass49, date53, timeZone59);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass43, date44, timeZone59);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date31, timeZone59);
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date31);
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(date31);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1577865599999L + "'", long30 == 1577865599999L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass43);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1546329600000L + "'", long46 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1546329600000L + "'", long51 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1546329600000L + "'", long55 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(timeZone59);
        org.junit.Assert.assertNull(regularTimePeriod60);
        org.junit.Assert.assertNull(regularTimePeriod61);
        org.junit.Assert.assertNull(regularTimePeriod62);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date15, timeZone18);
        long long20 = day19.getFirstMillisecond();
        long long21 = day19.getLastMillisecond();
        java.util.Calendar calendar22 = null;
        try {
            long long23 = day19.getLastMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577779200000L + "'", long20 == 1577779200000L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        java.lang.String str2 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray3 = timePeriodFormatException1.getSuppressed();
        java.lang.String str4 = timePeriodFormatException1.toString();
        java.lang.Throwable[] throwableArray5 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str2.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.time.TimePeriodFormatException: hi!" + "'", str4.equals("org.jfree.data.time.TimePeriodFormatException: hi!"));
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 1, (long) 11);
        long long3 = simpleTimePeriod2.getStartMillis();
        long long4 = simpleTimePeriod2.getStartMillis();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.String str5 = timePeriodValues3.getRangeDescription();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str11 = timePeriodValues10.getDomainDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.previous();
        java.util.Date date15 = year12.getEnd();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.previous();
        java.util.Date date19 = year16.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date15, date19);
        long long21 = simpleTimePeriod20.getEndMillis();
        java.util.Date date22 = simpleTimePeriod20.getStart();
        boolean boolean23 = timePeriodValues10.equals((java.lang.Object) date22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date22);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date22, timeZone25);
        int int27 = day26.getDayOfMonth();
        int int28 = day26.getMonth();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day26, (double) 1.0f);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        java.lang.Object obj32 = null;
        boolean boolean33 = year31.equals(obj32);
        java.util.Date date34 = year31.getStart();
        java.lang.Class<?> wildcardClass35 = year31.getClass();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        int int38 = year36.compareTo((java.lang.Object) (-1L));
        long long39 = year36.getLastMillisecond();
        java.util.Date date40 = year36.getStart();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        long long42 = year41.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year41.previous();
        java.util.Date date44 = year41.getEnd();
        java.lang.Class<?> wildcardClass45 = date44.getClass();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        long long47 = year46.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year46.previous();
        java.util.Date date49 = year46.getEnd();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        long long51 = year50.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year50.previous();
        java.util.Date date53 = year50.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod54 = new org.jfree.data.time.SimpleTimePeriod(date49, date53);
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date49, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date40, timeZone55);
        boolean boolean58 = day26.equals((java.lang.Object) wildcardClass35);
        java.lang.Class class59 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass35);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 31 + "'", int27 == 31);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 12 + "'", int28 == 12);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1577865599999L + "'", long39 == 1577865599999L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1546329600000L + "'", long42 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1546329600000L + "'", long47 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1546329600000L + "'", long51 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(class59);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) (short) 0);
        java.lang.String str20 = timePeriodValue19.toString();
        timePeriodValue19.setValue((java.lang.Number) (short) 100);
        java.lang.Object obj23 = timePeriodValue19.clone();
        java.lang.Number number24 = timePeriodValue19.getValue();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "TimePeriodValue[2019,0]" + "'", str20.equals("TimePeriodValue[2019,0]"));
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (short) 100 + "'", number24.equals((short) 100));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Object obj8 = timePeriodValues3.clone();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass10 = timePeriodValues3.getClass();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getFirstMillisecond();
        boolean boolean14 = year11.equals((java.lang.Object) 1577865599999L);
        java.lang.Number number15 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue16 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, number15);
        timePeriodValue16.setValue((java.lang.Number) 1L);
        timePeriodValues3.add(timePeriodValue16);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1), "", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues3.createCopy((int) (short) -1, (int) (byte) -1);
        int int9 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        java.lang.Object obj7 = timePeriodValues3.clone();
        timePeriodValues3.delete(6, (int) (byte) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str15 = timePeriodValues14.getDomainDescription();
        java.lang.String str16 = timePeriodValues14.getRangeDescription();
        java.lang.String str17 = timePeriodValues14.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str22 = timePeriodValues21.getDomainDescription();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        long long24 = year23.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year23.previous();
        java.util.Date date26 = year23.getEnd();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year27.previous();
        java.util.Date date30 = year27.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod(date26, date30);
        long long32 = simpleTimePeriod31.getEndMillis();
        java.util.Date date33 = simpleTimePeriod31.getStart();
        boolean boolean34 = timePeriodValues21.equals((java.lang.Object) date33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date33);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date33, timeZone36);
        int int38 = day37.getDayOfMonth();
        int int39 = day37.getMonth();
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) day37, (double) 1.0f);
        long long42 = day37.getFirstMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day37, (java.lang.Number) 10L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = day37.next();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1546329600000L + "'", long28 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 31 + "'", int38 == 31);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 12 + "'", int39 == 12);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1577779200000L + "'", long42 == 1577779200000L);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str8 = timePeriodValues7.getDomainDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.previous();
        java.util.Date date16 = year13.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod(date12, date16);
        long long18 = simpleTimePeriod17.getEndMillis();
        java.util.Date date19 = simpleTimePeriod17.getStart();
        boolean boolean20 = timePeriodValues7.equals((java.lang.Object) date19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date19);
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date19, timeZone22);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod(date3, date19);
        java.util.Date date25 = simpleTimePeriod24.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date25);
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date25, "2019", "");
        timePeriodValues29.setNotify(false);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(date25);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.delete((int) '4', (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        boolean boolean7 = timePeriodValues3.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues3.createCopy(9, 100);
        timePeriodValues10.setDescription("31-December-2019");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timePeriodValues10);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str8 = timePeriodValues7.getDomainDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.previous();
        java.util.Date date16 = year13.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod(date12, date16);
        long long18 = simpleTimePeriod17.getEndMillis();
        java.util.Date date19 = simpleTimePeriod17.getStart();
        boolean boolean20 = timePeriodValues7.equals((java.lang.Object) date19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date19);
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date19, timeZone22);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod(date3, date19);
        java.util.Date date25 = simpleTimePeriod24.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date25);
        timePeriodValues26.setDescription("TimePeriodValue[2019,null]");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(date25);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 9, (long) 9);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int7 = timePeriodValues6.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues6.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getFirstMillisecond();
        boolean boolean13 = year10.equals((java.lang.Object) 1577865599999L);
        java.lang.Number number14 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, number14);
        timePeriodValue15.setValue((java.lang.Number) 1L);
        timePeriodValues6.add(timePeriodValue15);
        boolean boolean19 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues6);
        boolean boolean21 = simpleTimePeriod2.equals((java.lang.Object) "org.jfree.data.general.SeriesException: TimePeriodValue[2019,null]");
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Object obj1 = null;
        boolean boolean2 = year0.equals(obj1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        java.util.Date date4 = regularTimePeriod3.getEnd();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (4) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.lang.Class class0 = null;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.previous();
        java.util.Date date4 = year1.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date4, timeZone6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year8.previous();
        java.util.Date date11 = year8.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str16 = timePeriodValues15.getDomainDescription();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year17.previous();
        java.util.Date date20 = year17.getEnd();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        long long22 = year21.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year21.previous();
        java.util.Date date24 = year21.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod(date20, date24);
        long long26 = simpleTimePeriod25.getEndMillis();
        java.util.Date date27 = simpleTimePeriod25.getStart();
        boolean boolean28 = timePeriodValues15.equals((java.lang.Object) date27);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date27);
        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date27, timeZone30);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod32 = new org.jfree.data.time.SimpleTimePeriod(date11, date27);
        java.util.Date date33 = simpleTimePeriod32.getEnd();
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date33, timeZone34);
        org.jfree.data.time.TimePeriodValues timePeriodValues39 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int40 = timePeriodValues39.getMinMiddleIndex();
        timePeriodValues39.setDescription("hi!");
        boolean boolean43 = timePeriodValues39.isEmpty();
        java.lang.Object obj44 = timePeriodValues39.clone();
        int int45 = timePeriodValues39.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass46 = timePeriodValues39.getClass();
        java.util.Date date47 = null;
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        long long49 = year48.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = year48.previous();
        java.util.Date date51 = year48.getEnd();
        java.lang.Class<?> wildcardClass52 = date51.getClass();
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
        long long54 = year53.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = year53.previous();
        java.util.Date date56 = year53.getEnd();
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
        long long58 = year57.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = year57.previous();
        java.util.Date date60 = year57.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod61 = new org.jfree.data.time.SimpleTimePeriod(date56, date60);
        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass52, date56, timeZone62);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass46, date47, timeZone62);
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year(date33, timeZone62);
        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date4, timeZone62);
        int int67 = day66.getYear();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1577865599999L + "'", long26 == 1577865599999L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(timeZone30);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(obj44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass46);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1546329600000L + "'", long49 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1546329600000L + "'", long54 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1546329600000L + "'", long58 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertNull(regularTimePeriod63);
        org.junit.Assert.assertNull(regularTimePeriod64);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 2019 + "'", int67 == 2019);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) (-1L));
        long long3 = year0.getLastMillisecond();
        java.util.Date date4 = year0.getStart();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod7 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 1, (long) 11);
        java.util.Date date8 = simpleTimePeriod7.getEnd();
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod9 = new org.jfree.data.time.SimpleTimePeriod(date4, date8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertNotNull(date8);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str13 = timePeriodValues12.getDomainDescription();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year14.previous();
        java.util.Date date17 = year14.getEnd();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.previous();
        java.util.Date date21 = year18.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date17, date21);
        long long23 = simpleTimePeriod22.getEndMillis();
        java.util.Date date24 = simpleTimePeriod22.getStart();
        boolean boolean25 = timePeriodValues12.equals((java.lang.Object) date24);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date24);
        org.jfree.data.time.TimePeriodValues timePeriodValues30 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str31 = timePeriodValues30.getDomainDescription();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        long long33 = year32.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year32.previous();
        java.util.Date date35 = year32.getEnd();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        long long37 = year36.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year36.previous();
        java.util.Date date39 = year36.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod40 = new org.jfree.data.time.SimpleTimePeriod(date35, date39);
        long long41 = simpleTimePeriod40.getEndMillis();
        java.util.Date date42 = simpleTimePeriod40.getStart();
        boolean boolean43 = timePeriodValues30.equals((java.lang.Object) date42);
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date42);
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date42, timeZone45);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date24, timeZone45);
        org.jfree.data.time.SerialDate serialDate48 = day47.getSerialDate();
        long long49 = day47.getLastMillisecond();
        java.util.Date date50 = day47.getEnd();
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year();
        long long52 = year51.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = year51.previous();
        java.util.Date date54 = year51.getEnd();
        java.lang.Class<?> wildcardClass55 = date54.getClass();
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
        long long57 = year56.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = year56.previous();
        java.util.Date date59 = year56.getEnd();
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
        long long61 = year60.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = year60.previous();
        java.util.Date date63 = year60.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod64 = new org.jfree.data.time.SimpleTimePeriod(date59, date63);
        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass55, date59, timeZone65);
        int int67 = day47.compareTo((java.lang.Object) timeZone65);
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year(date3, timeZone65);
        java.util.Date date69 = year68.getEnd();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1577865599999L + "'", long23 == 1577865599999L);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "" + "'", str31.equals(""));
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1546329600000L + "'", long37 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1577865599999L + "'", long41 == 1577865599999L);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertNotNull(serialDate48);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1577865599999L + "'", long49 == 1577865599999L);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1546329600000L + "'", long52 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1546329600000L + "'", long57 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1546329600000L + "'", long61 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(timeZone65);
        org.junit.Assert.assertNull(regularTimePeriod66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 1 + "'", int67 == 1);
        org.junit.Assert.assertNotNull(date69);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 100.0d, "", "org.jfree.data.general.SeriesException: TimePeriodValue[2019,null]");
        java.beans.PropertyChangeListener propertyChangeListener4 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener4);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) (short) 0);
        java.util.Calendar calendar20 = null;
        try {
            long long21 = year17.getFirstMillisecond(calendar20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Object obj1 = null;
        boolean boolean2 = year0.equals(obj1);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (byte) 100);
        long long5 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 8);
        java.lang.Number number8 = null;
        timePeriodValue7.setValue(number8);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setDescription("");
        boolean boolean7 = timePeriodValues3.isEmpty();
        int int8 = timePeriodValues3.getMinStartIndex();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues16 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str17 = timePeriodValues16.getDomainDescription();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.previous();
        java.util.Date date21 = year18.getEnd();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        long long23 = year22.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year22.previous();
        java.util.Date date25 = year22.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod26 = new org.jfree.data.time.SimpleTimePeriod(date21, date25);
        long long27 = simpleTimePeriod26.getEndMillis();
        java.util.Date date28 = simpleTimePeriod26.getStart();
        boolean boolean29 = timePeriodValues16.equals((java.lang.Object) date28);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date28);
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date28, timeZone31);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod33 = new org.jfree.data.time.SimpleTimePeriod(date12, date28);
        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str38 = timePeriodValues37.getDomainDescription();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        long long40 = year39.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year39.previous();
        java.util.Date date42 = year39.getEnd();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        long long44 = year43.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year43.previous();
        java.util.Date date46 = year43.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod(date42, date46);
        long long48 = simpleTimePeriod47.getEndMillis();
        java.util.Date date49 = simpleTimePeriod47.getStart();
        boolean boolean50 = timePeriodValues37.equals((java.lang.Object) date49);
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date49);
        org.jfree.data.time.TimePeriodValues timePeriodValues55 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str56 = timePeriodValues55.getDomainDescription();
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year();
        long long58 = year57.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = year57.previous();
        java.util.Date date60 = year57.getEnd();
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year();
        long long62 = year61.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod63 = year61.previous();
        java.util.Date date64 = year61.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod65 = new org.jfree.data.time.SimpleTimePeriod(date60, date64);
        long long66 = simpleTimePeriod65.getEndMillis();
        java.util.Date date67 = simpleTimePeriod65.getStart();
        boolean boolean68 = timePeriodValues55.equals((java.lang.Object) date67);
        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year(date67);
        java.util.TimeZone timeZone70 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day(date67, timeZone70);
        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day(date49, timeZone70);
        org.jfree.data.time.Year year73 = new org.jfree.data.time.Year(date12, timeZone70);
        boolean boolean74 = timePeriodValues3.equals((java.lang.Object) date12);
        int int75 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577865599999L + "'", long27 == 1577865599999L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1546329600000L + "'", long40 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1546329600000L + "'", long44 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1577865599999L + "'", long48 == 1577865599999L);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "" + "'", str56.equals(""));
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1546329600000L + "'", long58 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertTrue("'" + long62 + "' != '" + 1546329600000L + "'", long62 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod63);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1577865599999L + "'", long66 == 1577865599999L);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(timeZone70);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1) + "'", int75 == (-1));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.previous();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 1.0d);
        timePeriodValues3.setNotify(false);
        int int6 = day0.compareTo((java.lang.Object) timePeriodValues3);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 9, (long) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.String str5 = timePeriodValues3.getRangeDescription();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str11 = timePeriodValues10.getDomainDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.previous();
        java.util.Date date15 = year12.getEnd();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.previous();
        java.util.Date date19 = year16.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date15, date19);
        long long21 = simpleTimePeriod20.getEndMillis();
        java.util.Date date22 = simpleTimePeriod20.getStart();
        boolean boolean23 = timePeriodValues10.equals((java.lang.Object) date22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date22);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date22, timeZone25);
        int int27 = day26.getDayOfMonth();
        int int28 = day26.getMonth();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day26, (double) 1.0f);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        java.lang.Object obj32 = null;
        boolean boolean33 = year31.equals(obj32);
        java.util.Date date34 = year31.getStart();
        java.lang.Class<?> wildcardClass35 = year31.getClass();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        int int38 = year36.compareTo((java.lang.Object) (-1L));
        long long39 = year36.getLastMillisecond();
        java.util.Date date40 = year36.getStart();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        long long42 = year41.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year41.previous();
        java.util.Date date44 = year41.getEnd();
        java.lang.Class<?> wildcardClass45 = date44.getClass();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        long long47 = year46.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year46.previous();
        java.util.Date date49 = year46.getEnd();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        long long51 = year50.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year50.previous();
        java.util.Date date53 = year50.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod54 = new org.jfree.data.time.SimpleTimePeriod(date49, date53);
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date49, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date40, timeZone55);
        boolean boolean58 = day26.equals((java.lang.Object) wildcardClass35);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = day26.next();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 31 + "'", int27 == 31);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 12 + "'", int28 == 12);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1577865599999L + "'", long39 == 1577865599999L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1546329600000L + "'", long42 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1546329600000L + "'", long47 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1546329600000L + "'", long51 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.String str2 = year0.toString();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "2019" + "'", str2.equals("2019"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        long long9 = simpleTimePeriod8.getEndMillis();
        long long10 = simpleTimePeriod8.getStartMillis();
        long long11 = simpleTimePeriod8.getStartMillis();
        long long12 = simpleTimePeriod8.getStartMillis();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        long long9 = simpleTimePeriod8.getEndMillis();
        java.util.Date date10 = simpleTimePeriod8.getStart();
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        long long12 = simpleTimePeriod8.getStartMillis();
        long long13 = simpleTimePeriod8.getStartMillis();
        java.util.Date date14 = simpleTimePeriod8.getEnd();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1577865599999L + "'", long13 == 1577865599999L);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) date15);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date15, "TimePeriodValue[2019,1]", "13-June-2019");
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.String str8 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        java.lang.Object obj10 = timePeriodValues3.clone();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 0.0f);
        long long14 = year11.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setDescription("");
        boolean boolean7 = timePeriodValues3.isEmpty();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = timePeriodValues3.createCopy(0, (int) (byte) 100);
        java.lang.Comparable comparable11 = timePeriodValues10.getKey();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues10.removePropertyChangeListener(propertyChangeListener12);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(timePeriodValues10);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 10.0f + "'", comparable11.equals(10.0f));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Object obj1 = null;
        boolean boolean2 = year0.equals(obj1);
        org.jfree.data.time.TimePeriodValue timePeriodValue4 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) (byte) 100);
        long long5 = year0.getLastMillisecond();
        org.jfree.data.time.TimePeriodValue timePeriodValue7 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, (java.lang.Number) 8);
        java.lang.Object obj8 = timePeriodValue7.clone();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.util.Date date2 = year0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day4.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.String str8 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        java.lang.Object obj10 = timePeriodValues3.clone();
        int int11 = timePeriodValues3.getItemCount();
        timePeriodValues3.setNotify(false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str22 = timePeriodValues21.getDomainDescription();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        long long24 = year23.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year23.previous();
        java.util.Date date26 = year23.getEnd();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year27.previous();
        java.util.Date date30 = year27.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod(date26, date30);
        long long32 = simpleTimePeriod31.getEndMillis();
        java.util.Date date33 = simpleTimePeriod31.getStart();
        boolean boolean34 = timePeriodValues21.equals((java.lang.Object) date33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date33);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date33, timeZone36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date15, timeZone36);
        org.jfree.data.time.SerialDate serialDate39 = day38.getSerialDate();
        long long40 = day38.getLastMillisecond();
        int int41 = day38.getMonth();
        org.jfree.data.time.SerialDate serialDate42 = day38.getSerialDate();
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(serialDate42);
        int int44 = day43.getMonth();
        org.jfree.data.time.TimePeriodValue timePeriodValue46 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day43, (double) '#');
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1546329600000L + "'", long28 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 12 + "'", int41 == 12);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 12 + "'", int44 == 12);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        long long9 = simpleTimePeriod8.getEndMillis();
        java.util.Date date10 = simpleTimePeriod8.getStart();
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod8);
        java.util.Date date13 = simpleTimePeriod8.getStart();
        long long14 = simpleTimePeriod8.getEndMillis();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str8 = timePeriodValues7.getDomainDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.previous();
        java.util.Date date16 = year13.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod(date12, date16);
        long long18 = simpleTimePeriod17.getEndMillis();
        java.util.Date date19 = simpleTimePeriod17.getStart();
        boolean boolean20 = timePeriodValues7.equals((java.lang.Object) date19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date19);
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date19, timeZone22);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod(date3, date19);
        java.util.Date date25 = simpleTimePeriod24.getEnd();
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date25, timeZone26);
        java.util.Date date28 = day27.getEnd();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNotNull(date28);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.String str8 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        java.lang.Object obj10 = timePeriodValues3.clone();
        int int11 = timePeriodValues3.getItemCount();
        int int12 = timePeriodValues3.getMaxStartIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        timePeriodValues3.setRangeDescription("hi!");
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.time.TimePeriodValues timePeriodValues13 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str14 = timePeriodValues13.getDomainDescription();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        long long16 = year15.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year15.previous();
        java.util.Date date18 = year15.getEnd();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year();
        long long20 = year19.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year19.previous();
        java.util.Date date22 = year19.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod23 = new org.jfree.data.time.SimpleTimePeriod(date18, date22);
        long long24 = simpleTimePeriod23.getEndMillis();
        java.util.Date date25 = simpleTimePeriod23.getStart();
        boolean boolean26 = timePeriodValues13.equals((java.lang.Object) date25);
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year(date25);
        org.jfree.data.time.TimePeriodValues timePeriodValues31 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str32 = timePeriodValues31.getDomainDescription();
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year();
        long long34 = year33.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod35 = year33.previous();
        java.util.Date date36 = year33.getEnd();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        long long38 = year37.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year37.previous();
        java.util.Date date40 = year37.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod41 = new org.jfree.data.time.SimpleTimePeriod(date36, date40);
        long long42 = simpleTimePeriod41.getEndMillis();
        java.util.Date date43 = simpleTimePeriod41.getStart();
        boolean boolean44 = timePeriodValues31.equals((java.lang.Object) date43);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date43);
        java.util.TimeZone timeZone46 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date43, timeZone46);
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date25, timeZone46);
        org.jfree.data.time.SerialDate serialDate49 = day48.getSerialDate();
        long long50 = day48.getLastMillisecond();
        java.util.Date date51 = day48.getEnd();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day48, (java.lang.Number) 1546329600000L);
        java.util.Calendar calendar54 = null;
        try {
            day48.peg(calendar54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1546329600000L + "'", long16 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1546329600000L + "'", long20 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1577865599999L + "'", long24 == 1577865599999L);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "" + "'", str32.equals(""));
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1546329600000L + "'", long34 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod35);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1546329600000L + "'", long38 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1577865599999L + "'", long42 == 1577865599999L);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(timeZone46);
        org.junit.Assert.assertNotNull(serialDate49);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1577865599999L + "'", long50 == 1577865599999L);
        org.junit.Assert.assertNotNull(date51);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 8, 43629L);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        timePeriodValues3.setRangeDescription("hi!");
        boolean boolean9 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        java.lang.Class<?> wildcardClass4 = date3.getClass();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        java.util.TimeZone timeZone14 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass4, date8, timeZone14);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.previous();
        java.util.Date date19 = year16.getEnd();
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year();
        long long21 = year20.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year20.previous();
        java.util.Date date23 = year20.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod(date19, date23);
        long long25 = simpleTimePeriod24.getEndMillis();
        long long26 = simpleTimePeriod24.getStartMillis();
        long long27 = simpleTimePeriod24.getStartMillis();
        java.util.Date date28 = simpleTimePeriod24.getStart();
        java.util.TimeZone timeZone29 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(date28, timeZone29);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date8, timeZone29);
        java.util.Calendar calendar32 = null;
        try {
            long long33 = year31.getFirstMillisecond(calendar32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1546329600000L + "'", long21 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1577865599999L + "'", long25 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1577865599999L + "'", long26 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1577865599999L + "'", long27 == 1577865599999L);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(timeZone29);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getFirstMillisecond();
        boolean boolean10 = year7.equals((java.lang.Object) 1577865599999L);
        java.lang.Number number11 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, number11);
        timePeriodValue12.setValue((java.lang.Number) 1L);
        timePeriodValues3.add(timePeriodValue12);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str20 = timePeriodValues19.getDomainDescription();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        long long22 = year21.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year21.previous();
        java.util.Date date24 = year21.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year25.previous();
        java.util.Date date28 = year25.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod(date24, date28);
        long long30 = simpleTimePeriod29.getEndMillis();
        java.util.Date date31 = simpleTimePeriod29.getStart();
        boolean boolean32 = timePeriodValues19.equals((java.lang.Object) date31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date31);
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date31, timeZone34);
        long long36 = day35.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day35, (java.lang.Number) 1.0d);
        int int39 = timePeriodValues3.getMaxEndIndex();
        int int40 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1577865599999L + "'", long30 == 1577865599999L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 43830L + "'", long36 == 43830L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date15, timeZone18);
        long long20 = day19.getFirstMillisecond();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        long long22 = year21.getFirstMillisecond();
        boolean boolean24 = year21.equals((java.lang.Object) 1577865599999L);
        java.lang.Number number25 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year21, number25);
        timePeriodValue26.setValue((java.lang.Number) 1L);
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str33 = timePeriodValues32.getDomainDescription();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        long long35 = year34.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year34.previous();
        java.util.Date date37 = year34.getEnd();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        long long39 = year38.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year38.previous();
        java.util.Date date41 = year38.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod(date37, date41);
        long long43 = simpleTimePeriod42.getEndMillis();
        java.util.Date date44 = simpleTimePeriod42.getStart();
        boolean boolean45 = timePeriodValues32.equals((java.lang.Object) date44);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date44);
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date44, timeZone47);
        long long49 = day48.getFirstMillisecond();
        boolean boolean50 = timePeriodValue26.equals((java.lang.Object) day48);
        boolean boolean51 = day19.equals((java.lang.Object) timePeriodValue26);
        java.lang.String str52 = timePeriodValue26.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577779200000L + "'", long20 == 1577779200000L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1546329600000L + "'", long35 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1546329600000L + "'", long39 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1577865599999L + "'", long43 == 1577865599999L);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1577779200000L + "'", long49 == 1577779200000L);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "TimePeriodValue[2019,1]" + "'", str52.equals("TimePeriodValue[2019,1]"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        java.lang.Object obj7 = timePeriodValues3.clone();
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 10.0f + "'", comparable8.equals(10.0f));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.lang.Object obj1 = null;
        boolean boolean2 = year0.equals(obj1);
        java.util.Date date3 = year0.getStart();
        java.lang.Class<?> wildcardClass4 = year0.getClass();
        java.lang.Class class5 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(class5);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) (-1L));
        long long3 = year0.getLastMillisecond();
        java.util.Date date4 = year0.getStart();
        long long5 = year0.getMiddleMillisecond();
        long long6 = year0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year0.previous();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1562097599999L + "'", long5 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1562097599999L + "'", long6 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener6 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener6);
        java.lang.Comparable comparable8 = timePeriodValues3.getKey();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + 10.0f + "'", comparable8.equals(10.0f));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date15, timeZone18);
        long long20 = day19.getFirstMillisecond();
        long long21 = day19.getSerialIndex();
        long long22 = day19.getSerialIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577779200000L + "'", long20 == 1577779200000L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43830L + "'", long21 == 43830L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 43830L + "'", long22 == 43830L);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getMiddleMillisecond();
        java.lang.Object obj2 = null;
        boolean boolean3 = year0.equals(obj2);
        long long4 = year0.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1562097599999L + "'", long1 == 1562097599999L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 2019L + "'", long4 == 2019L);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) (-1L));
        long long3 = year0.getLastMillisecond();
        java.lang.Object obj4 = null;
        int int5 = year0.compareTo(obj4);
        int int6 = year0.getYear();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year0.getFirstMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test242");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        java.util.Calendar calendar2 = null;
//        try {
//            long long3 = day0.getFirstMillisecond(calendar2);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setDescription("");
        timePeriodValues3.setRangeDescription("TimePeriodValue[2019,1]");
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int2 = year0.compareTo((java.lang.Object) (-1L));
        java.lang.String str3 = year0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod4);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.util.Date date2 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue5 = timePeriodValues3.getDataItem((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMaxStartIndex();
        java.lang.String str5 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 1, (long) 11);
        long long9 = simpleTimePeriod8.getStartMillis();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        java.lang.Object obj11 = null;
        boolean boolean12 = year10.equals(obj11);
        java.util.Date date13 = year10.getStart();
        int int14 = simpleTimePeriod8.compareTo((java.lang.Object) year10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) simpleTimePeriod8, (java.lang.Number) (short) 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Object obj8 = timePeriodValues3.clone();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setKey((java.lang.Comparable) (-1));
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.previous();
        java.util.Date date15 = year12.getEnd();
        java.lang.Class<?> wildcardClass16 = date15.getClass();
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass16);
        boolean boolean18 = timePeriodValues3.equals((java.lang.Object) class17);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMaxStartIndex();
        int int5 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(4, 10, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.String str8 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        java.lang.Object obj10 = timePeriodValues3.clone();
        timePeriodValues3.setDescription("");
        timePeriodValues3.setDescription("TimePeriodValue[2019,1]");
        timePeriodValues3.setKey((java.lang.Comparable) 1560409200000L);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.String str8 = timePeriodValues3.getDomainDescription();
        boolean boolean9 = timePeriodValues3.getNotify();
        try {
            org.jfree.data.time.TimePeriodValue timePeriodValue11 = timePeriodValues3.getDataItem(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str8 = timePeriodValues7.getDomainDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.previous();
        java.util.Date date16 = year13.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod(date12, date16);
        long long18 = simpleTimePeriod17.getEndMillis();
        java.util.Date date19 = simpleTimePeriod17.getStart();
        boolean boolean20 = timePeriodValues7.equals((java.lang.Object) date19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date19);
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date19, timeZone22);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod(date3, date19);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str29 = timePeriodValues28.getDomainDescription();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        long long31 = year30.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year30.previous();
        java.util.Date date33 = year30.getEnd();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        long long35 = year34.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year34.previous();
        java.util.Date date37 = year34.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(date33, date37);
        long long39 = simpleTimePeriod38.getEndMillis();
        java.util.Date date40 = simpleTimePeriod38.getStart();
        boolean boolean41 = timePeriodValues28.equals((java.lang.Object) date40);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date40);
        org.jfree.data.time.TimePeriodValues timePeriodValues46 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str47 = timePeriodValues46.getDomainDescription();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        long long49 = year48.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = year48.previous();
        java.util.Date date51 = year48.getEnd();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
        long long53 = year52.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = year52.previous();
        java.util.Date date55 = year52.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod56 = new org.jfree.data.time.SimpleTimePeriod(date51, date55);
        long long57 = simpleTimePeriod56.getEndMillis();
        java.util.Date date58 = simpleTimePeriod56.getStart();
        boolean boolean59 = timePeriodValues46.equals((java.lang.Object) date58);
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year(date58);
        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(date58, timeZone61);
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date40, timeZone61);
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(date3, timeZone61);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod65 = year64.previous();
        long long66 = regularTimePeriod65.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1546329600000L + "'", long31 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1546329600000L + "'", long35 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1577865599999L + "'", long39 == 1577865599999L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1546329600000L + "'", long49 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1546329600000L + "'", long53 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1577865599999L + "'", long57 == 1577865599999L);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(timeZone61);
        org.junit.Assert.assertNotNull(regularTimePeriod65);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1530561599999L + "'", long66 == 1530561599999L);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.String str5 = timePeriodValues3.getRangeDescription();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.previous();
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year11, (double) 4);
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 2);
        java.lang.Number number16 = timePeriodValue15.getValue();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 2 + "'", number16.equals(2));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod(43830L, 43629L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        boolean boolean5 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date3);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        long long2 = year1.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year1.previous();
        java.util.Date date4 = year1.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str9 = timePeriodValues8.getDomainDescription();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year10.previous();
        java.util.Date date13 = year10.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year14.previous();
        java.util.Date date17 = year14.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod18 = new org.jfree.data.time.SimpleTimePeriod(date13, date17);
        long long19 = simpleTimePeriod18.getEndMillis();
        java.util.Date date20 = simpleTimePeriod18.getStart();
        boolean boolean21 = timePeriodValues8.equals((java.lang.Object) date20);
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date20);
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date20, timeZone23);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod(date4, date20);
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str30 = timePeriodValues29.getDomainDescription();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        long long32 = year31.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year31.previous();
        java.util.Date date34 = year31.getEnd();
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year();
        long long36 = year35.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year35.previous();
        java.util.Date date38 = year35.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date34, date38);
        long long40 = simpleTimePeriod39.getEndMillis();
        java.util.Date date41 = simpleTimePeriod39.getStart();
        boolean boolean42 = timePeriodValues29.equals((java.lang.Object) date41);
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year(date41);
        org.jfree.data.time.TimePeriodValues timePeriodValues47 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str48 = timePeriodValues47.getDomainDescription();
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
        long long50 = year49.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year49.previous();
        java.util.Date date52 = year49.getEnd();
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
        long long54 = year53.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = year53.previous();
        java.util.Date date56 = year53.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod57 = new org.jfree.data.time.SimpleTimePeriod(date52, date56);
        long long58 = simpleTimePeriod57.getEndMillis();
        java.util.Date date59 = simpleTimePeriod57.getStart();
        boolean boolean60 = timePeriodValues47.equals((java.lang.Object) date59);
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date59);
        java.util.TimeZone timeZone62 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date59, timeZone62);
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date41, timeZone62);
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year(date4, timeZone62);
        int int66 = year0.compareTo((java.lang.Object) timeZone62);
        int int67 = year0.getYear();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1577865599999L + "'", long19 == 1577865599999L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1546329600000L + "'", long32 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1546329600000L + "'", long36 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "" + "'", str48.equals(""));
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1546329600000L + "'", long50 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1546329600000L + "'", long54 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1577865599999L + "'", long58 == 1577865599999L);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(timeZone62);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 1 + "'", int66 == 1);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 2019 + "'", int67 == 2019);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1), "", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues3.createCopy((int) (short) -1, (int) (byte) -1);
        boolean boolean9 = timePeriodValues3.isEmpty();
        java.lang.Comparable comparable10 = timePeriodValues3.getKey();
        int int11 = timePeriodValues3.getMinStartIndex();
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + (-1) + "'", comparable10.equals((-1)));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        int int5 = timePeriodValues3.getMaxStartIndex();
        int int6 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getFirstMillisecond();
        boolean boolean10 = year7.equals((java.lang.Object) 1577865599999L);
        java.lang.Number number11 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, number11);
        timePeriodValue12.setValue((java.lang.Number) 1L);
        timePeriodValues3.add(timePeriodValue12);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str20 = timePeriodValues19.getDomainDescription();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        long long22 = year21.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year21.previous();
        java.util.Date date24 = year21.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year25.previous();
        java.util.Date date28 = year25.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod(date24, date28);
        long long30 = simpleTimePeriod29.getEndMillis();
        java.util.Date date31 = simpleTimePeriod29.getStart();
        boolean boolean32 = timePeriodValues19.equals((java.lang.Object) date31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date31);
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date31, timeZone34);
        long long36 = day35.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day35, (java.lang.Number) 1.0d);
        int int39 = timePeriodValues3.getItemCount();
        boolean boolean40 = timePeriodValues3.isEmpty();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1577865599999L + "'", long30 == 1577865599999L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 43830L + "'", long36 == 43830L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2 + "'", int39 == 2);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("TimePeriodValue[2019,null]");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException3 = new org.jfree.data.time.TimePeriodFormatException("hi!");
        seriesException1.addSuppressed((java.lang.Throwable) timePeriodFormatException3);
        java.lang.Throwable[] throwableArray5 = seriesException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str8 = timePeriodValues7.getDomainDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.previous();
        java.util.Date date16 = year13.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod(date12, date16);
        long long18 = simpleTimePeriod17.getEndMillis();
        java.util.Date date19 = simpleTimePeriod17.getStart();
        boolean boolean20 = timePeriodValues7.equals((java.lang.Object) date19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date19);
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date19, timeZone22);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod(date3, date19);
        java.util.Date date25 = simpleTimePeriod24.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date25);
        int int27 = timePeriodValues26.getMinMiddleIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("13-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("");
        java.lang.Throwable[] throwableArray2 = timePeriodFormatException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.util.Date date2 = year0.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues11 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str12 = timePeriodValues11.getDomainDescription();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.previous();
        java.util.Date date16 = year13.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year17.previous();
        java.util.Date date20 = year17.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod21 = new org.jfree.data.time.SimpleTimePeriod(date16, date20);
        long long22 = simpleTimePeriod21.getEndMillis();
        java.util.Date date23 = simpleTimePeriod21.getStart();
        boolean boolean24 = timePeriodValues11.equals((java.lang.Object) date23);
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date23);
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date23, timeZone26);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod28 = new org.jfree.data.time.SimpleTimePeriod(date7, date23);
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str33 = timePeriodValues32.getDomainDescription();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        long long35 = year34.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year34.previous();
        java.util.Date date37 = year34.getEnd();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        long long39 = year38.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year38.previous();
        java.util.Date date41 = year38.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod(date37, date41);
        long long43 = simpleTimePeriod42.getEndMillis();
        java.util.Date date44 = simpleTimePeriod42.getStart();
        boolean boolean45 = timePeriodValues32.equals((java.lang.Object) date44);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date44);
        org.jfree.data.time.TimePeriodValues timePeriodValues50 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str51 = timePeriodValues50.getDomainDescription();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
        long long53 = year52.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = year52.previous();
        java.util.Date date55 = year52.getEnd();
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year();
        long long57 = year56.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = year56.previous();
        java.util.Date date59 = year56.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod60 = new org.jfree.data.time.SimpleTimePeriod(date55, date59);
        long long61 = simpleTimePeriod60.getEndMillis();
        java.util.Date date62 = simpleTimePeriod60.getStart();
        boolean boolean63 = timePeriodValues50.equals((java.lang.Object) date62);
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(date62);
        java.util.TimeZone timeZone65 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date62, timeZone65);
        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day(date44, timeZone65);
        org.jfree.data.time.Year year68 = new org.jfree.data.time.Year(date7, timeZone65);
        int int69 = year3.compareTo((java.lang.Object) timeZone65);
        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date2, timeZone65);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1546329600000L + "'", long35 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1546329600000L + "'", long39 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1577865599999L + "'", long43 == 1577865599999L);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "" + "'", str51.equals(""));
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1546329600000L + "'", long53 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1546329600000L + "'", long57 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1577865599999L + "'", long61 == 1577865599999L);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(timeZone65);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str8 = timePeriodValues7.getDomainDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.previous();
        java.util.Date date16 = year13.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod(date12, date16);
        long long18 = simpleTimePeriod17.getEndMillis();
        java.util.Date date19 = simpleTimePeriod17.getStart();
        boolean boolean20 = timePeriodValues7.equals((java.lang.Object) date19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date19);
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date19, timeZone22);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod(date3, date19);
        org.jfree.data.time.TimePeriodValues timePeriodValues28 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str29 = timePeriodValues28.getDomainDescription();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        long long31 = year30.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year30.previous();
        java.util.Date date33 = year30.getEnd();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        long long35 = year34.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year34.previous();
        java.util.Date date37 = year34.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(date33, date37);
        long long39 = simpleTimePeriod38.getEndMillis();
        java.util.Date date40 = simpleTimePeriod38.getStart();
        boolean boolean41 = timePeriodValues28.equals((java.lang.Object) date40);
        org.jfree.data.time.Year year42 = new org.jfree.data.time.Year(date40);
        org.jfree.data.time.TimePeriodValues timePeriodValues46 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str47 = timePeriodValues46.getDomainDescription();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        long long49 = year48.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = year48.previous();
        java.util.Date date51 = year48.getEnd();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year();
        long long53 = year52.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = year52.previous();
        java.util.Date date55 = year52.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod56 = new org.jfree.data.time.SimpleTimePeriod(date51, date55);
        long long57 = simpleTimePeriod56.getEndMillis();
        java.util.Date date58 = simpleTimePeriod56.getStart();
        boolean boolean59 = timePeriodValues46.equals((java.lang.Object) date58);
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year(date58);
        java.util.TimeZone timeZone61 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(date58, timeZone61);
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date40, timeZone61);
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year(date3, timeZone61);
        java.util.TimeZone timeZone65 = null;
        try {
            org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date3, timeZone65);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1546329600000L + "'", long31 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1546329600000L + "'", long35 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1577865599999L + "'", long39 == 1577865599999L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1546329600000L + "'", long49 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1546329600000L + "'", long53 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1577865599999L + "'", long57 == 1577865599999L);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(timeZone61);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (short) 1, (long) 11);
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year();
        long long4 = year3.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year3.previous();
        java.util.Date date6 = year3.getEnd();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.previous();
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod11 = new org.jfree.data.time.SimpleTimePeriod(date6, date10);
        long long12 = simpleTimePeriod11.getEndMillis();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent13 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) long12);
        boolean boolean14 = simpleTimePeriod2.equals((java.lang.Object) long12);
        long long15 = simpleTimePeriod2.getEndMillis();
        java.util.Date date16 = simpleTimePeriod2.getEnd();
        long long17 = simpleTimePeriod2.getEndMillis();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 11L + "'", long15 == 11L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 11L + "'", long17 == 11L);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues7 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str8 = timePeriodValues7.getDomainDescription();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.previous();
        java.util.Date date16 = year13.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod17 = new org.jfree.data.time.SimpleTimePeriod(date12, date16);
        long long18 = simpleTimePeriod17.getEndMillis();
        java.util.Date date19 = simpleTimePeriod17.getStart();
        boolean boolean20 = timePeriodValues7.equals((java.lang.Object) date19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date19);
        java.util.TimeZone timeZone22 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date19, timeZone22);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod24 = new org.jfree.data.time.SimpleTimePeriod(date3, date19);
        java.util.Date date25 = simpleTimePeriod24.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date25);
        org.jfree.data.time.TimePeriodValues timePeriodValues29 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date25, "2019", "");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener30 = null;
        timePeriodValues29.removeChangeListener(seriesChangeListener30);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(timeZone22);
        org.junit.Assert.assertNotNull(date25);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        boolean boolean3 = year0.equals((java.lang.Object) 1577865599999L);
        java.lang.Number number4 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, number4);
        timePeriodValue5.setValue((java.lang.Number) 1L);
        java.lang.Number number8 = timePeriodValue5.getValue();
        java.lang.String str9 = timePeriodValue5.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1L + "'", number8.equals(1L));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TimePeriodValue[2019,1]" + "'", str9.equals("TimePeriodValue[2019,1]"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        long long9 = simpleTimePeriod8.getEndMillis();
        long long10 = simpleTimePeriod8.getStartMillis();
        long long11 = simpleTimePeriod8.getStartMillis();
        java.util.Date date12 = simpleTimePeriod8.getStart();
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date12, timeZone13);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeZone13);
        java.lang.String str16 = seriesChangeEvent15.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1577865599999L + "'", long10 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1577865599999L + "'", long11 == 1577865599999L);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.jfree.data.general.SeriesChangeEvent[source=sun.util.calendar.ZoneInfo[id=\"America/Los_Angeles\",offset=-28800000,dstSavings=3600000,useDaylight=true,transitions=185,lastRule=java.util.SimpleTimeZone[id=America/Los_Angeles,offset=-28800000,dstSavings=3600000,useDaylight=true,startYear=0,startMode=3,startMonth=2,startDay=8,startDayOfWeek=1,startTime=7200000,startTimeMode=0,endMode=3,endMonth=10,endDay=1,endDayOfWeek=1,endTime=7200000,endTimeMode=0]]]" + "'", str16.equals("org.jfree.data.general.SeriesChangeEvent[source=sun.util.calendar.ZoneInfo[id=\"America/Los_Angeles\",offset=-28800000,dstSavings=3600000,useDaylight=true,transitions=185,lastRule=java.util.SimpleTimeZone[id=America/Los_Angeles,offset=-28800000,dstSavings=3600000,useDaylight=true,startYear=0,startMode=3,startMonth=2,startDay=8,startDayOfWeek=1,startTime=7200000,startTimeMode=0,endMode=3,endMonth=10,endDay=1,endDayOfWeek=1,endTime=7200000,endTimeMode=0]]]"));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        try {
            org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (-1) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.beans.PropertyChangeListener propertyChangeListener8 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener8);
        timePeriodValues3.setRangeDescription("13-June-2019");
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setDescription("");
        boolean boolean7 = timePeriodValues3.isEmpty();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener8);
        java.lang.String str10 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.setRangeDescription("org.jfree.data.time.TimePeriodFormatException: 2019");
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.String str8 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        java.lang.Object obj10 = timePeriodValues3.clone();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year11, (java.lang.Number) 0.0f);
        int int14 = timePeriodValues3.getMinStartIndex();
        timePeriodValues3.setRangeDescription("13-June-2019");
        java.lang.String str17 = timePeriodValues3.getRangeDescription();
        int int18 = timePeriodValues3.getMaxMiddleIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "13-June-2019" + "'", str17.equals("13-June-2019"));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 9, (long) 9);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int7 = timePeriodValues6.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues6.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getFirstMillisecond();
        boolean boolean13 = year10.equals((java.lang.Object) 1577865599999L);
        java.lang.Number number14 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, number14);
        timePeriodValue15.setValue((java.lang.Number) 1L);
        timePeriodValues6.add(timePeriodValue15);
        boolean boolean19 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues6);
        java.lang.Comparable comparable20 = timePeriodValues6.getKey();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + 10.0f + "'", comparable20.equals(10.0f));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.String str8 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        java.lang.Object obj10 = timePeriodValues3.clone();
        timePeriodValues3.setDescription("");
        timePeriodValues3.setDescription("TimePeriodValue[2019,1]");
        java.lang.Object obj15 = timePeriodValues3.clone();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        timePeriodValues3.setRangeDescription("hi!");
        java.lang.String str9 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.delete((int) ' ', 9);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date15, timeZone18);
        long long20 = day19.getFirstMillisecond();
        long long21 = day19.getSerialIndex();
        int int22 = day19.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day19.next();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577779200000L + "'", long20 == 1577779200000L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43830L + "'", long21 == 43830L);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 31 + "'", int22 == 31);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        java.util.Date date18 = year17.getStart();
        int int19 = year17.getYear();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2019 + "'", int19 == 2019);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        long long9 = simpleTimePeriod8.getEndMillis();
        java.util.Date date10 = simpleTimePeriod8.getStart();
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        long long12 = simpleTimePeriod8.getEndMillis();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) long12, "", "org.jfree.data.general.SeriesException: TimePeriodValue[2019,null]");
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1577865599999L + "'", long12 == 1577865599999L);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent3 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) seriesException1);
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.String str8 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        java.lang.Object obj10 = timePeriodValues3.clone();
        int int11 = timePeriodValues3.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener12);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener14);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str20 = timePeriodValues19.getDomainDescription();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        long long22 = year21.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year21.previous();
        java.util.Date date24 = year21.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year25.previous();
        java.util.Date date28 = year25.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod(date24, date28);
        long long30 = simpleTimePeriod29.getEndMillis();
        java.util.Date date31 = simpleTimePeriod29.getStart();
        boolean boolean32 = timePeriodValues19.equals((java.lang.Object) date31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date31);
        org.jfree.data.time.TimePeriodValue timePeriodValue35 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year33, (java.lang.Number) (short) 0);
        java.lang.String str36 = timePeriodValue35.toString();
        timePeriodValue35.setValue((java.lang.Number) (short) 100);
        timePeriodValues3.add(timePeriodValue35);
        timePeriodValue35.setValue((java.lang.Number) 9);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1577865599999L + "'", long30 == 1577865599999L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "TimePeriodValue[2019,0]" + "'", str36.equals("TimePeriodValue[2019,0]"));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.util.Date date2 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str7 = timePeriodValues6.getDomainDescription();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year8.previous();
        java.util.Date date11 = year8.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.previous();
        java.util.Date date15 = year12.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(date11, date15);
        long long17 = simpleTimePeriod16.getEndMillis();
        java.util.Date date18 = simpleTimePeriod16.getStart();
        boolean boolean19 = timePeriodValues6.equals((java.lang.Object) date18);
        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date18);
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str25 = timePeriodValues24.getDomainDescription();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        long long27 = year26.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year26.previous();
        java.util.Date date29 = year26.getEnd();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        long long31 = year30.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year30.previous();
        java.util.Date date33 = year30.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod34 = new org.jfree.data.time.SimpleTimePeriod(date29, date33);
        long long35 = simpleTimePeriod34.getEndMillis();
        java.util.Date date36 = simpleTimePeriod34.getStart();
        boolean boolean37 = timePeriodValues24.equals((java.lang.Object) date36);
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date36);
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date36, timeZone39);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date18, timeZone39);
        org.jfree.data.time.SerialDate serialDate42 = day41.getSerialDate();
        long long43 = day41.getLastMillisecond();
        java.util.Date date44 = day41.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod45 = new org.jfree.data.time.SimpleTimePeriod(date2, date44);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1546329600000L + "'", long27 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1546329600000L + "'", long31 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1577865599999L + "'", long35 == 1577865599999L);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertNotNull(serialDate42);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1577865599999L + "'", long43 == 1577865599999L);
        org.junit.Assert.assertNotNull(date44);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Object obj8 = timePeriodValues3.clone();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        java.lang.Comparable comparable10 = timePeriodValues3.getKey();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + 10.0f + "'", comparable10.equals(10.0f));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date15, timeZone18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = day19.next();
        int int21 = day19.getYear();
        java.util.Calendar calendar22 = null;
        try {
            day19.peg(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str22 = timePeriodValues21.getDomainDescription();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        long long24 = year23.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year23.previous();
        java.util.Date date26 = year23.getEnd();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year27.previous();
        java.util.Date date30 = year27.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod(date26, date30);
        long long32 = simpleTimePeriod31.getEndMillis();
        java.util.Date date33 = simpleTimePeriod31.getStart();
        boolean boolean34 = timePeriodValues21.equals((java.lang.Object) date33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date33);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date33, timeZone36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date15, timeZone36);
        org.jfree.data.time.SerialDate serialDate39 = day38.getSerialDate();
        long long40 = day38.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate41 = day38.getSerialDate();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent42 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day38);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1546329600000L + "'", long28 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate41);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) (short) 0);
        int int20 = year17.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year17.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year17.previous();
        java.lang.String str23 = year17.toString();
        boolean boolean25 = year17.equals((java.lang.Object) 1546329600000L);
        java.util.Calendar calendar26 = null;
        try {
            long long27 = year17.getFirstMillisecond(calendar26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "2019" + "'", str23.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1), "", "hi!");
        int int4 = timePeriodValues3.getMaxEndIndex();
        java.lang.Class class5 = null;
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year6.previous();
        java.util.Date date9 = year6.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date9, timeZone11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.previous();
        java.util.Date date16 = year13.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str21 = timePeriodValues20.getDomainDescription();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        long long23 = year22.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year22.previous();
        java.util.Date date25 = year22.getEnd();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        long long27 = year26.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year26.previous();
        java.util.Date date29 = year26.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod(date25, date29);
        long long31 = simpleTimePeriod30.getEndMillis();
        java.util.Date date32 = simpleTimePeriod30.getStart();
        boolean boolean33 = timePeriodValues20.equals((java.lang.Object) date32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date32);
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date32, timeZone35);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod(date16, date32);
        java.util.Date date38 = simpleTimePeriod37.getEnd();
        java.util.TimeZone timeZone39 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date38, timeZone39);
        org.jfree.data.time.TimePeriodValues timePeriodValues44 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int45 = timePeriodValues44.getMinMiddleIndex();
        timePeriodValues44.setDescription("hi!");
        boolean boolean48 = timePeriodValues44.isEmpty();
        java.lang.Object obj49 = timePeriodValues44.clone();
        int int50 = timePeriodValues44.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass51 = timePeriodValues44.getClass();
        java.util.Date date52 = null;
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year();
        long long54 = year53.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = year53.previous();
        java.util.Date date56 = year53.getEnd();
        java.lang.Class<?> wildcardClass57 = date56.getClass();
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year();
        long long59 = year58.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = year58.previous();
        java.util.Date date61 = year58.getEnd();
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        long long63 = year62.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = year62.previous();
        java.util.Date date65 = year62.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod66 = new org.jfree.data.time.SimpleTimePeriod(date61, date65);
        java.util.TimeZone timeZone67 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass57, date61, timeZone67);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass51, date52, timeZone67);
        org.jfree.data.time.Year year70 = new org.jfree.data.time.Year(date38, timeZone67);
        org.jfree.data.time.Day day71 = new org.jfree.data.time.Day(date9, timeZone67);
        boolean boolean72 = timePeriodValues3.equals((java.lang.Object) date9);
        timePeriodValues3.setNotify(false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1546329600000L + "'", long27 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1577865599999L + "'", long31 == 1577865599999L);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertNotNull(timeZone39);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(obj49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass51);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1546329600000L + "'", long54 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertTrue("'" + long59 + "' != '" + 1546329600000L + "'", long59 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1546329600000L + "'", long63 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(timeZone67);
        org.junit.Assert.assertNull(regularTimePeriod68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str22 = timePeriodValues21.getDomainDescription();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        long long24 = year23.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year23.previous();
        java.util.Date date26 = year23.getEnd();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year27.previous();
        java.util.Date date30 = year27.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod(date26, date30);
        long long32 = simpleTimePeriod31.getEndMillis();
        java.util.Date date33 = simpleTimePeriod31.getStart();
        boolean boolean34 = timePeriodValues21.equals((java.lang.Object) date33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date33);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date33, timeZone36);
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date15, timeZone36);
        org.jfree.data.time.SerialDate serialDate39 = day38.getSerialDate();
        long long40 = day38.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate41 = day38.getSerialDate();
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(serialDate41);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1546329600000L + "'", long28 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertNotNull(serialDate39);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1577865599999L + "'", long40 == 1577865599999L);
        org.junit.Assert.assertNotNull(serialDate41);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date15, timeZone18);
        long long20 = day19.getFirstMillisecond();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        long long22 = year21.getFirstMillisecond();
        boolean boolean24 = year21.equals((java.lang.Object) 1577865599999L);
        java.lang.Number number25 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue26 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year21, number25);
        timePeriodValue26.setValue((java.lang.Number) 1L);
        org.jfree.data.time.TimePeriodValues timePeriodValues32 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str33 = timePeriodValues32.getDomainDescription();
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        long long35 = year34.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = year34.previous();
        java.util.Date date37 = year34.getEnd();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year();
        long long39 = year38.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year38.previous();
        java.util.Date date41 = year38.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod42 = new org.jfree.data.time.SimpleTimePeriod(date37, date41);
        long long43 = simpleTimePeriod42.getEndMillis();
        java.util.Date date44 = simpleTimePeriod42.getStart();
        boolean boolean45 = timePeriodValues32.equals((java.lang.Object) date44);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(date44);
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day48 = new org.jfree.data.time.Day(date44, timeZone47);
        long long49 = day48.getFirstMillisecond();
        boolean boolean50 = timePeriodValue26.equals((java.lang.Object) day48);
        boolean boolean51 = day19.equals((java.lang.Object) timePeriodValue26);
        java.lang.Object obj52 = timePeriodValue26.clone();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577779200000L + "'", long20 == 1577779200000L);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1546329600000L + "'", long35 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1546329600000L + "'", long39 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1577865599999L + "'", long43 == 1577865599999L);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1577779200000L + "'", long49 == 1577779200000L);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(obj52);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        java.util.Date date0 = null;
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        int int2 = year1.getYear();
        java.lang.Class<?> wildcardClass3 = year1.getClass();
        java.lang.Class class4 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass3);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year14.previous();
        java.util.Date date17 = year14.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str22 = timePeriodValues21.getDomainDescription();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        long long24 = year23.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year23.previous();
        java.util.Date date26 = year23.getEnd();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year27.previous();
        java.util.Date date30 = year27.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod(date26, date30);
        long long32 = simpleTimePeriod31.getEndMillis();
        java.util.Date date33 = simpleTimePeriod31.getStart();
        boolean boolean34 = timePeriodValues21.equals((java.lang.Object) date33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date33);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date33, timeZone36);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(date17, date33);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod39 = new org.jfree.data.time.SimpleTimePeriod(date8, date33);
        org.jfree.data.time.TimePeriodValues timePeriodValues43 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str44 = timePeriodValues43.getDomainDescription();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year();
        long long46 = year45.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year45.previous();
        java.util.Date date48 = year45.getEnd();
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year();
        long long50 = year49.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod51 = year49.previous();
        java.util.Date date52 = year49.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod53 = new org.jfree.data.time.SimpleTimePeriod(date48, date52);
        long long54 = simpleTimePeriod53.getEndMillis();
        java.util.Date date55 = simpleTimePeriod53.getStart();
        boolean boolean56 = timePeriodValues43.equals((java.lang.Object) date55);
        org.jfree.data.time.Year year57 = new org.jfree.data.time.Year(date55);
        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date55, timeZone58);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date33, timeZone58);
        try {
            org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date0, timeZone58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(class4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1546329600000L + "'", long28 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "" + "'", str44.equals(""));
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1546329600000L + "'", long46 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(date48);
        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1546329600000L + "'", long50 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod51);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1577865599999L + "'", long54 == 1577865599999L);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(timeZone58);
        org.junit.Assert.assertNotNull(regularTimePeriod60);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getFirstMillisecond();
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        java.util.Date date5 = year0.getStart();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date15, timeZone18);
        long long20 = day19.getFirstMillisecond();
        long long21 = day19.getLastMillisecond();
        java.util.Date date22 = day19.getStart();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1577779200000L + "'", long20 == 1577779200000L);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(date22);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.String str5 = timePeriodValues3.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener6);
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year8.previous();
        java.util.Date date11 = year8.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.previous();
        java.util.Date date15 = year12.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod16 = new org.jfree.data.time.SimpleTimePeriod(date11, date15);
        long long17 = simpleTimePeriod16.getEndMillis();
        long long18 = simpleTimePeriod16.getStartMillis();
        java.lang.Object obj19 = null;
        boolean boolean20 = simpleTimePeriod16.equals(obj19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        java.lang.Object obj22 = null;
        boolean boolean23 = year21.equals(obj22);
        java.util.Date date24 = year21.getStart();
        java.lang.Class<?> wildcardClass25 = year21.getClass();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        int int28 = year26.compareTo((java.lang.Object) (-1L));
        long long29 = year26.getLastMillisecond();
        java.util.Date date30 = year26.getStart();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        long long32 = year31.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year31.previous();
        java.util.Date date34 = year31.getEnd();
        java.lang.Class<?> wildcardClass35 = date34.getClass();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        long long37 = year36.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = year36.previous();
        java.util.Date date39 = year36.getEnd();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        long long41 = year40.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = year40.previous();
        java.util.Date date43 = year40.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod44 = new org.jfree.data.time.SimpleTimePeriod(date39, date43);
        java.util.TimeZone timeZone45 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date39, timeZone45);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date30, timeZone45);
        boolean boolean48 = simpleTimePeriod16.equals((java.lang.Object) wildcardClass25);
        java.util.Date date49 = simpleTimePeriod16.getStart();
        timePeriodValues3.setKey((java.lang.Comparable) date49);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1577865599999L + "'", long17 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1577865599999L + "'", long18 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1577865599999L + "'", long29 == 1577865599999L);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1546329600000L + "'", long32 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1546329600000L + "'", long37 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1546329600000L + "'", long41 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(timeZone45);
        org.junit.Assert.assertNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(date49);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener5 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener5);
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getFirstMillisecond();
        boolean boolean10 = year7.equals((java.lang.Object) 1577865599999L);
        java.lang.Number number11 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue12 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year7, number11);
        timePeriodValue12.setValue((java.lang.Number) 1L);
        timePeriodValues3.add(timePeriodValue12);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str20 = timePeriodValues19.getDomainDescription();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        long long22 = year21.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year21.previous();
        java.util.Date date24 = year21.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year();
        long long26 = year25.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year25.previous();
        java.util.Date date28 = year25.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod29 = new org.jfree.data.time.SimpleTimePeriod(date24, date28);
        long long30 = simpleTimePeriod29.getEndMillis();
        java.util.Date date31 = simpleTimePeriod29.getStart();
        boolean boolean32 = timePeriodValues19.equals((java.lang.Object) date31);
        org.jfree.data.time.Year year33 = new org.jfree.data.time.Year(date31);
        java.util.TimeZone timeZone34 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date31, timeZone34);
        long long36 = day35.getSerialIndex();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day35, (java.lang.Number) 1.0d);
        int int39 = timePeriodValues3.getMaxEndIndex();
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year();
        long long41 = year40.getFirstMillisecond();
        boolean boolean43 = year40.equals((java.lang.Object) 1577865599999L);
        java.lang.Number number44 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue45 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year40, number44);
        java.lang.Number number46 = timePeriodValue45.getValue();
        java.lang.Object obj47 = timePeriodValue45.clone();
        org.jfree.data.time.TimePeriod timePeriod48 = timePeriodValue45.getPeriod();
        org.jfree.data.time.TimePeriodValues timePeriodValues52 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1), "", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener53 = null;
        timePeriodValues52.removeChangeListener(seriesChangeListener53);
        org.jfree.data.time.TimePeriodValues timePeriodValues57 = timePeriodValues52.createCopy((int) (short) -1, (int) (byte) -1);
        boolean boolean58 = timePeriodValue45.equals((java.lang.Object) timePeriodValues57);
        timePeriodValues3.add(timePeriodValue45);
        timePeriodValues3.setNotify(false);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "" + "'", str20.equals(""));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1546329600000L + "'", long26 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 1577865599999L + "'", long30 == 1577865599999L);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(timeZone34);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 43830L + "'", long36 == 43830L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1546329600000L + "'", long41 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNull(number46);
        org.junit.Assert.assertNotNull(obj47);
        org.junit.Assert.assertNotNull(timePeriod48);
        org.junit.Assert.assertNotNull(timePeriodValues57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.String str8 = timePeriodValues3.getDomainDescription();
        int int9 = timePeriodValues3.getMinEndIndex();
        int int10 = timePeriodValues3.getMaxStartIndex();
        timePeriodValues3.delete(2019, (int) (short) 1);
        boolean boolean14 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        boolean boolean3 = year0.equals((java.lang.Object) 1577865599999L);
        java.lang.Number number4 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue5 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year0, number4);
        java.lang.Number number6 = timePeriodValue5.getValue();
        java.lang.Object obj7 = timePeriodValue5.clone();
        org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValue5.getPeriod();
        org.jfree.data.time.TimePeriodValues timePeriodValues12 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1), "", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener13 = null;
        timePeriodValues12.removeChangeListener(seriesChangeListener13);
        org.jfree.data.time.TimePeriodValues timePeriodValues17 = timePeriodValues12.createCopy((int) (short) -1, (int) (byte) -1);
        boolean boolean18 = timePeriodValue5.equals((java.lang.Object) timePeriodValues17);
        int int19 = timePeriodValues17.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(timePeriod8);
        org.junit.Assert.assertNotNull(timePeriodValues17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date15, timeZone18);
        int int20 = day19.getYear();
        java.lang.String str21 = day19.toString();
        long long22 = day19.getMiddleMillisecond();
        java.lang.String str23 = day19.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "31-December-2019" + "'", str21.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577822399999L + "'", long22 == 1577822399999L);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "31-December-2019" + "'", str23.equals("31-December-2019"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.String str5 = timePeriodValues3.getRangeDescription();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str11 = timePeriodValues10.getDomainDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.previous();
        java.util.Date date15 = year12.getEnd();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.previous();
        java.util.Date date19 = year16.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date15, date19);
        long long21 = simpleTimePeriod20.getEndMillis();
        java.util.Date date22 = simpleTimePeriod20.getStart();
        boolean boolean23 = timePeriodValues10.equals((java.lang.Object) date22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date22);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date22, timeZone25);
        int int27 = day26.getDayOfMonth();
        int int28 = day26.getMonth();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day26, (double) 1.0f);
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1), "", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener35 = null;
        timePeriodValues34.removeChangeListener(seriesChangeListener35);
        org.jfree.data.time.TimePeriodValues timePeriodValues39 = timePeriodValues34.createCopy((int) (short) -1, (int) (byte) -1);
        int int40 = day26.compareTo((java.lang.Object) (byte) -1);
        int int41 = day26.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day26.next();
        org.jfree.data.time.TimePeriodValue timePeriodValue44 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) day26, (java.lang.Number) (short) -1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 31 + "'", int27 == 31);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 12 + "'", int28 == 12);
        org.junit.Assert.assertNotNull(timePeriodValues39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 31 + "'", int41 == 31);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.String str8 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        java.lang.Object obj10 = timePeriodValues3.clone();
        int int11 = timePeriodValues3.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener12);
        java.beans.PropertyChangeListener propertyChangeListener14 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener14);
        boolean boolean16 = timePeriodValues3.isEmpty();
        int int17 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.String str5 = timePeriodValues3.getRangeDescription();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.previous();
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year11, (double) 4);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year14.previous();
        java.util.Date date17 = year14.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str22 = timePeriodValues21.getDomainDescription();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        long long24 = year23.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year23.previous();
        java.util.Date date26 = year23.getEnd();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year27.previous();
        java.util.Date date30 = year27.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod(date26, date30);
        long long32 = simpleTimePeriod31.getEndMillis();
        java.util.Date date33 = simpleTimePeriod31.getStart();
        boolean boolean34 = timePeriodValues21.equals((java.lang.Object) date33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date33);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date33, timeZone36);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(date17, date33);
        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str43 = timePeriodValues42.getDomainDescription();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        long long45 = year44.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year44.previous();
        java.util.Date date47 = year44.getEnd();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        long long49 = year48.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = year48.previous();
        java.util.Date date51 = year48.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod52 = new org.jfree.data.time.SimpleTimePeriod(date47, date51);
        long long53 = simpleTimePeriod52.getEndMillis();
        java.util.Date date54 = simpleTimePeriod52.getStart();
        boolean boolean55 = timePeriodValues42.equals((java.lang.Object) date54);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(date54);
        org.jfree.data.time.TimePeriodValues timePeriodValues60 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str61 = timePeriodValues60.getDomainDescription();
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year();
        long long63 = year62.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = year62.previous();
        java.util.Date date65 = year62.getEnd();
        org.jfree.data.time.Year year66 = new org.jfree.data.time.Year();
        long long67 = year66.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = year66.previous();
        java.util.Date date69 = year66.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod70 = new org.jfree.data.time.SimpleTimePeriod(date65, date69);
        long long71 = simpleTimePeriod70.getEndMillis();
        java.util.Date date72 = simpleTimePeriod70.getStart();
        boolean boolean73 = timePeriodValues60.equals((java.lang.Object) date72);
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year(date72);
        java.util.TimeZone timeZone75 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day76 = new org.jfree.data.time.Day(date72, timeZone75);
        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day(date54, timeZone75);
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year(date17, timeZone75);
        timePeriodValues3.setKey((java.lang.Comparable) date17);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1546329600000L + "'", long28 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "" + "'", str43.equals(""));
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1546329600000L + "'", long45 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1546329600000L + "'", long49 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1577865599999L + "'", long53 == 1577865599999L);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "" + "'", str61.equals(""));
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1546329600000L + "'", long63 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertTrue("'" + long67 + "' != '" + 1546329600000L + "'", long67 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod68);
        org.junit.Assert.assertNotNull(date69);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1577865599999L + "'", long71 == 1577865599999L);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(timeZone75);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.util.Date date2 = year0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        java.util.Calendar calendar5 = null;
        try {
            day4.peg(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) (short) 0);
        int int20 = year17.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year17.next();
        long long22 = year17.getLastMillisecond();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent23 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) year17);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.String str5 = timePeriodValues3.getRangeDescription();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str11 = timePeriodValues10.getDomainDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.previous();
        java.util.Date date15 = year12.getEnd();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.previous();
        java.util.Date date19 = year16.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date15, date19);
        long long21 = simpleTimePeriod20.getEndMillis();
        java.util.Date date22 = simpleTimePeriod20.getStart();
        boolean boolean23 = timePeriodValues10.equals((java.lang.Object) date22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date22);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date22, timeZone25);
        int int27 = day26.getDayOfMonth();
        int int28 = day26.getMonth();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day26, (double) 1.0f);
        org.jfree.data.time.TimePeriodValues timePeriodValues34 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1), "", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener35 = null;
        timePeriodValues34.removeChangeListener(seriesChangeListener35);
        org.jfree.data.time.TimePeriodValues timePeriodValues39 = timePeriodValues34.createCopy((int) (short) -1, (int) (byte) -1);
        int int40 = day26.compareTo((java.lang.Object) (byte) -1);
        int int41 = day26.getDayOfMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day26.next();
        long long43 = day26.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 31 + "'", int27 == 31);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 12 + "'", int28 == 12);
        org.junit.Assert.assertNotNull(timePeriodValues39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 31 + "'", int41 == 31);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1577865599999L + "'", long43 == 1577865599999L);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMaxStartIndex();
        java.lang.String str5 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getFirstMillisecond();
        boolean boolean9 = year6.equals((java.lang.Object) 1577865599999L);
        java.lang.Number number10 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, number10);
        timePeriodValue11.setValue((java.lang.Number) 1L);
        timePeriodValues3.add(timePeriodValue11);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener15);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) (byte) 10, 5, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.String str5 = timePeriodValues3.getRangeDescription();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str11 = timePeriodValues10.getDomainDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.previous();
        java.util.Date date15 = year12.getEnd();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.previous();
        java.util.Date date19 = year16.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date15, date19);
        long long21 = simpleTimePeriod20.getEndMillis();
        java.util.Date date22 = simpleTimePeriod20.getStart();
        boolean boolean23 = timePeriodValues10.equals((java.lang.Object) date22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date22);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date22, timeZone25);
        int int27 = day26.getDayOfMonth();
        int int28 = day26.getMonth();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day26, (double) 1.0f);
        timePeriodValues3.setDomainDescription("TimePeriodValue[2019,null]");
        int int33 = timePeriodValues3.getMaxMiddleIndex();
        java.lang.String str34 = timePeriodValues3.getDomainDescription();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 31 + "'", int27 == 31);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 12 + "'", int28 == 12);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "TimePeriodValue[2019,null]" + "'", str34.equals("TimePeriodValue[2019,null]"));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMaxStartIndex();
        java.lang.String str5 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        long long7 = year6.getFirstMillisecond();
        boolean boolean9 = year6.equals((java.lang.Object) 1577865599999L);
        java.lang.Number number10 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue11 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year6, number10);
        timePeriodValue11.setValue((java.lang.Number) 1L);
        timePeriodValues3.add(timePeriodValue11);
        java.lang.Object obj15 = null;
        boolean boolean16 = timePeriodValue11.equals(obj15);
        java.lang.String str17 = timePeriodValue11.toString();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1546329600000L + "'", long7 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "TimePeriodValue[2019,1]" + "'", str17.equals("TimePeriodValue[2019,1]"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.lang.Class<?> wildcardClass2 = year0.getClass();
        java.lang.Class class3 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year();
        long long9 = year8.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year8.previous();
        java.util.Date date11 = year8.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod12 = new org.jfree.data.time.SimpleTimePeriod(date7, date11);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        long long14 = year13.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = year13.previous();
        java.util.Date date16 = year13.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues20 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str21 = timePeriodValues20.getDomainDescription();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year();
        long long23 = year22.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = year22.previous();
        java.util.Date date25 = year22.getEnd();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        long long27 = year26.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = year26.previous();
        java.util.Date date29 = year26.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod30 = new org.jfree.data.time.SimpleTimePeriod(date25, date29);
        long long31 = simpleTimePeriod30.getEndMillis();
        java.util.Date date32 = simpleTimePeriod30.getStart();
        boolean boolean33 = timePeriodValues20.equals((java.lang.Object) date32);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year(date32);
        java.util.TimeZone timeZone35 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date32, timeZone35);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod37 = new org.jfree.data.time.SimpleTimePeriod(date16, date32);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod38 = new org.jfree.data.time.SimpleTimePeriod(date7, date32);
        org.jfree.data.time.TimePeriodValues timePeriodValues42 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str43 = timePeriodValues42.getDomainDescription();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year();
        long long45 = year44.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year44.previous();
        java.util.Date date47 = year44.getEnd();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year();
        long long49 = year48.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = year48.previous();
        java.util.Date date51 = year48.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod52 = new org.jfree.data.time.SimpleTimePeriod(date47, date51);
        long long53 = simpleTimePeriod52.getEndMillis();
        java.util.Date date54 = simpleTimePeriod52.getStart();
        boolean boolean55 = timePeriodValues42.equals((java.lang.Object) date54);
        org.jfree.data.time.Year year56 = new org.jfree.data.time.Year(date54);
        java.util.TimeZone timeZone57 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day58 = new org.jfree.data.time.Day(date54, timeZone57);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance(class3, date32, timeZone57);
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
        long long61 = year60.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = year60.previous();
        java.util.Date date63 = year60.getEnd();
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year();
        long long65 = year64.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = year64.previous();
        java.util.Date date67 = year64.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod68 = new org.jfree.data.time.SimpleTimePeriod(date63, date67);
        long long69 = simpleTimePeriod68.getEndMillis();
        long long70 = simpleTimePeriod68.getStartMillis();
        long long71 = simpleTimePeriod68.getStartMillis();
        java.util.Date date72 = simpleTimePeriod68.getStart();
        java.util.TimeZone timeZone73 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year(date72, timeZone73);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent75 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) timeZone73);
        org.jfree.data.time.Year year76 = new org.jfree.data.time.Year(date32, timeZone73);
        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day(date32);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(class3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1546329600000L + "'", long14 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1546329600000L + "'", long23 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1546329600000L + "'", long27 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1577865599999L + "'", long31 == 1577865599999L);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(timeZone35);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "" + "'", str43.equals(""));
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1546329600000L + "'", long45 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 1546329600000L + "'", long49 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1577865599999L + "'", long53 == 1577865599999L);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(timeZone57);
        org.junit.Assert.assertNotNull(regularTimePeriod59);
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1546329600000L + "'", long61 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1546329600000L + "'", long65 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1577865599999L + "'", long69 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1577865599999L + "'", long70 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1577865599999L + "'", long71 == 1577865599999L);
        org.junit.Assert.assertNotNull(date72);
        org.junit.Assert.assertNotNull(timeZone73);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        long long9 = simpleTimePeriod8.getEndMillis();
        java.util.Date date10 = simpleTimePeriod8.getStart();
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str16 = timePeriodValues15.getDomainDescription();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        long long18 = year17.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year17.previous();
        java.util.Date date20 = year17.getEnd();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year();
        long long22 = year21.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = year21.previous();
        java.util.Date date24 = year21.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod25 = new org.jfree.data.time.SimpleTimePeriod(date20, date24);
        long long26 = simpleTimePeriod25.getEndMillis();
        java.util.Date date27 = simpleTimePeriod25.getStart();
        boolean boolean28 = timePeriodValues15.equals((java.lang.Object) date27);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date27);
        org.jfree.data.time.TimePeriodValue timePeriodValue31 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year29, (java.lang.Number) (short) 0);
        int int32 = year29.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = year29.next();
        boolean boolean34 = simpleTimePeriod8.equals((java.lang.Object) year29);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "" + "'", str16.equals(""));
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1546329600000L + "'", long18 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1546329600000L + "'", long22 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1577865599999L + "'", long26 == 1577865599999L);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        int int1 = year0.getYear();
        java.util.Date date2 = year0.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) date2);
        int int4 = timePeriodValues3.getMaxEndIndex();
        java.lang.Number number6 = null;
        try {
            timePeriodValues3.update(2, number6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.String str5 = timePeriodValues3.getRangeDescription();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        long long8 = year7.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year7.previous();
        java.util.Date date10 = year7.getEnd();
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year(date10);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year11, (double) 4);
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getSerialIndex();
        long long16 = year14.getFirstMillisecond();
        long long17 = year14.getFirstMillisecond();
        int int18 = year14.getYear();
        boolean boolean19 = year11.equals((java.lang.Object) int18);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1546329600000L + "'", long8 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 2019L + "'", long15 == 2019L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1546329600000L + "'", long16 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        long long9 = simpleTimePeriod8.getEndMillis();
        java.util.Date date10 = simpleTimePeriod8.getStart();
        java.util.Date date11 = simpleTimePeriod8.getEnd();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) simpleTimePeriod8);
        java.util.Date date13 = simpleTimePeriod8.getStart();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year();
        long long15 = year14.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year14.previous();
        java.util.Date date17 = year14.getEnd();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year();
        long long19 = year18.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.previous();
        java.util.Date date21 = year18.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod22 = new org.jfree.data.time.SimpleTimePeriod(date17, date21);
        org.jfree.data.time.TimePeriodValues timePeriodValues26 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str27 = timePeriodValues26.getDomainDescription();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        long long29 = year28.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year28.previous();
        java.util.Date date31 = year28.getEnd();
        org.jfree.data.time.Year year32 = new org.jfree.data.time.Year();
        long long33 = year32.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = year32.previous();
        java.util.Date date35 = year32.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod36 = new org.jfree.data.time.SimpleTimePeriod(date31, date35);
        long long37 = simpleTimePeriod36.getEndMillis();
        java.util.Date date38 = simpleTimePeriod36.getStart();
        boolean boolean39 = timePeriodValues26.equals((java.lang.Object) date38);
        org.jfree.data.time.Year year40 = new org.jfree.data.time.Year(date38);
        org.jfree.data.time.TimePeriodValues timePeriodValues44 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str45 = timePeriodValues44.getDomainDescription();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        long long47 = year46.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year46.previous();
        java.util.Date date49 = year46.getEnd();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        long long51 = year50.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year50.previous();
        java.util.Date date53 = year50.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod54 = new org.jfree.data.time.SimpleTimePeriod(date49, date53);
        long long55 = simpleTimePeriod54.getEndMillis();
        java.util.Date date56 = simpleTimePeriod54.getStart();
        boolean boolean57 = timePeriodValues44.equals((java.lang.Object) date56);
        org.jfree.data.time.Year year58 = new org.jfree.data.time.Year(date56);
        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day60 = new org.jfree.data.time.Day(date56, timeZone59);
        org.jfree.data.time.Day day61 = new org.jfree.data.time.Day(date38, timeZone59);
        org.jfree.data.time.SerialDate serialDate62 = day61.getSerialDate();
        long long63 = day61.getLastMillisecond();
        java.util.Date date64 = day61.getEnd();
        org.jfree.data.time.Year year65 = new org.jfree.data.time.Year();
        long long66 = year65.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = year65.previous();
        java.util.Date date68 = year65.getEnd();
        java.lang.Class<?> wildcardClass69 = date68.getClass();
        org.jfree.data.time.Year year70 = new org.jfree.data.time.Year();
        long long71 = year70.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod72 = year70.previous();
        java.util.Date date73 = year70.getEnd();
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year();
        long long75 = year74.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = year74.previous();
        java.util.Date date77 = year74.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod78 = new org.jfree.data.time.SimpleTimePeriod(date73, date77);
        java.util.TimeZone timeZone79 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass69, date73, timeZone79);
        int int81 = day61.compareTo((java.lang.Object) timeZone79);
        org.jfree.data.time.Year year82 = new org.jfree.data.time.Year(date17, timeZone79);
        org.jfree.data.time.Day day83 = new org.jfree.data.time.Day(date13, timeZone79);
        org.jfree.data.time.TimePeriodValues timePeriodValues87 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int88 = timePeriodValues87.getMinMiddleIndex();
        timePeriodValues87.setDescription("hi!");
        boolean boolean91 = timePeriodValues87.isEmpty();
        java.lang.Object obj92 = timePeriodValues87.clone();
        java.lang.Class<?> wildcardClass93 = timePeriodValues87.getClass();
        int int94 = day83.compareTo((java.lang.Object) wildcardClass93);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1577865599999L + "'", long9 == 1577865599999L);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1546329600000L + "'", long15 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1546329600000L + "'", long29 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1577865599999L + "'", long37 == 1577865599999L);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "" + "'", str45.equals(""));
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1546329600000L + "'", long47 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1546329600000L + "'", long51 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1577865599999L + "'", long55 == 1577865599999L);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(timeZone59);
        org.junit.Assert.assertNotNull(serialDate62);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1577865599999L + "'", long63 == 1577865599999L);
        org.junit.Assert.assertNotNull(date64);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1546329600000L + "'", long66 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod67);
        org.junit.Assert.assertNotNull(date68);
        org.junit.Assert.assertNotNull(wildcardClass69);
        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1546329600000L + "'", long71 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod72);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 1546329600000L + "'", long75 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod76);
        org.junit.Assert.assertNotNull(date77);
        org.junit.Assert.assertNotNull(timeZone79);
        org.junit.Assert.assertNull(regularTimePeriod80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 1 + "'", int81 == 1);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + (-1) + "'", int88 == (-1));
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
        org.junit.Assert.assertNotNull(obj92);
        org.junit.Assert.assertNotNull(wildcardClass93);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 1 + "'", int94 == 1);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        java.lang.Object obj7 = timePeriodValues3.clone();
        timePeriodValues3.delete(6, (int) (byte) 1);
        org.jfree.data.time.TimePeriodValues timePeriodValues14 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str15 = timePeriodValues14.getDomainDescription();
        java.lang.String str16 = timePeriodValues14.getRangeDescription();
        java.lang.String str17 = timePeriodValues14.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues21 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str22 = timePeriodValues21.getDomainDescription();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year();
        long long24 = year23.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = year23.previous();
        java.util.Date date26 = year23.getEnd();
        org.jfree.data.time.Year year27 = new org.jfree.data.time.Year();
        long long28 = year27.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year27.previous();
        java.util.Date date30 = year27.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod31 = new org.jfree.data.time.SimpleTimePeriod(date26, date30);
        long long32 = simpleTimePeriod31.getEndMillis();
        java.util.Date date33 = simpleTimePeriod31.getStart();
        boolean boolean34 = timePeriodValues21.equals((java.lang.Object) date33);
        org.jfree.data.time.Year year35 = new org.jfree.data.time.Year(date33);
        java.util.TimeZone timeZone36 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date33, timeZone36);
        int int38 = day37.getDayOfMonth();
        int int39 = day37.getMonth();
        timePeriodValues14.add((org.jfree.data.time.TimePeriod) day37, (double) 1.0f);
        long long42 = day37.getFirstMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day37, (java.lang.Number) 10L);
        java.util.Calendar calendar45 = null;
        try {
            long long46 = day37.getFirstMillisecond(calendar45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "" + "'", str15.equals(""));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "hi!" + "'", str16.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1546329600000L + "'", long24 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1546329600000L + "'", long28 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + long32 + "' != '" + 1577865599999L + "'", long32 == 1577865599999L);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(timeZone36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 31 + "'", int38 == 31);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 12 + "'", int39 == 12);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1577779200000L + "'", long42 == 1577779200000L);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (short) 100, "TimePeriodValue[2019,1]", "org.jfree.data.general.SeriesException: TimePeriodValue[2019,null]");
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = timePeriodValues3.createCopy(31, 9);
        try {
            org.jfree.data.time.TimePeriod timePeriod8 = timePeriodValues6.getTimePeriod((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodValues6);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Object obj8 = timePeriodValues3.clone();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener10);
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener12);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getSerialIndex();
        long long2 = year0.getFirstMillisecond();
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.next();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent15 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) long14);
        boolean boolean16 = year0.equals((java.lang.Object) seriesChangeEvent15);
        long long17 = year0.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2019L + "'", long1 == 2019L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1562097599999L + "'", long17 == 1562097599999L);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 9, (long) 9);
        org.jfree.data.time.TimePeriodValues timePeriodValues6 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int7 = timePeriodValues6.getMinMiddleIndex();
        org.jfree.data.general.SeriesChangeListener seriesChangeListener8 = null;
        timePeriodValues6.addChangeListener(seriesChangeListener8);
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year();
        long long11 = year10.getFirstMillisecond();
        boolean boolean13 = year10.equals((java.lang.Object) 1577865599999L);
        java.lang.Number number14 = null;
        org.jfree.data.time.TimePeriodValue timePeriodValue15 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year10, number14);
        timePeriodValue15.setValue((java.lang.Number) 1L);
        timePeriodValues6.add(timePeriodValue15);
        boolean boolean19 = simpleTimePeriod2.equals((java.lang.Object) timePeriodValues6);
        int int20 = timePeriodValues6.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.String str8 = timePeriodValues3.getDomainDescription();
        timePeriodValues3.fireSeriesChanged();
        java.lang.Object obj10 = timePeriodValues3.clone();
        int int11 = timePeriodValues3.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues3.addPropertyChangeListener(propertyChangeListener12);
        timePeriodValues3.setRangeDescription("2019");
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        java.lang.Object obj17 = null;
        boolean boolean18 = year16.equals(obj17);
        org.jfree.data.time.TimePeriodValue timePeriodValue20 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year16, (java.lang.Number) (byte) 100);
        long long21 = year16.getLastMillisecond();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year16, (double) 100L);
        int int24 = timePeriodValues3.getMaxEndIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.util.Date date3 = year0.getEnd();
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year();
        long long5 = year4.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year4.previous();
        java.util.Date date7 = year4.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod8 = new org.jfree.data.time.SimpleTimePeriod(date3, date7);
        java.util.Date date9 = simpleTimePeriod8.getEnd();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1546329600000L + "'", long5 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.String str5 = timePeriodValues3.getRangeDescription();
        java.lang.String str6 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.TimePeriodValues timePeriodValues10 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str11 = timePeriodValues10.getDomainDescription();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        long long13 = year12.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.previous();
        java.util.Date date15 = year12.getEnd();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        long long17 = year16.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year16.previous();
        java.util.Date date19 = year16.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod20 = new org.jfree.data.time.SimpleTimePeriod(date15, date19);
        long long21 = simpleTimePeriod20.getEndMillis();
        java.util.Date date22 = simpleTimePeriod20.getStart();
        boolean boolean23 = timePeriodValues10.equals((java.lang.Object) date22);
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date22);
        java.util.TimeZone timeZone25 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date22, timeZone25);
        int int27 = day26.getDayOfMonth();
        int int28 = day26.getMonth();
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) day26, (double) 1.0f);
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        java.lang.Object obj32 = null;
        boolean boolean33 = year31.equals(obj32);
        java.util.Date date34 = year31.getStart();
        java.lang.Class<?> wildcardClass35 = year31.getClass();
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        int int38 = year36.compareTo((java.lang.Object) (-1L));
        long long39 = year36.getLastMillisecond();
        java.util.Date date40 = year36.getStart();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        long long42 = year41.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year41.previous();
        java.util.Date date44 = year41.getEnd();
        java.lang.Class<?> wildcardClass45 = date44.getClass();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        long long47 = year46.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year46.previous();
        java.util.Date date49 = year46.getEnd();
        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year();
        long long51 = year50.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod52 = year50.previous();
        java.util.Date date53 = year50.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod54 = new org.jfree.data.time.SimpleTimePeriod(date49, date53);
        java.util.TimeZone timeZone55 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod56 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass45, date49, timeZone55);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass35, date40, timeZone55);
        boolean boolean58 = day26.equals((java.lang.Object) wildcardClass35);
        java.lang.String str59 = day26.toString();
        boolean boolean61 = day26.equals((java.lang.Object) '4');
        java.util.Calendar calendar62 = null;
        try {
            long long63 = day26.getFirstMillisecond(calendar62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1546329600000L + "'", long13 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(timeZone25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 31 + "'", int27 == 31);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 12 + "'", int28 == 12);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1 + "'", int38 == 1);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1577865599999L + "'", long39 == 1577865599999L);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1546329600000L + "'", long42 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1546329600000L + "'", long47 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1546329600000L + "'", long51 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod52);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertNotNull(timeZone55);
        org.junit.Assert.assertNull(regularTimePeriod56);
        org.junit.Assert.assertNotNull(regularTimePeriod57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "31-December-2019" + "'", str59.equals("31-December-2019"));
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        try {
            org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) 11, (long) 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date15, timeZone18);
        int int20 = day19.getDayOfMonth();
        int int21 = day19.getMonth();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = day19.next();
        org.jfree.data.time.TimePeriodValues timePeriodValues23 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 31 + "'", int20 == 31);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 12 + "'", int21 == 12);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        java.lang.Object obj7 = timePeriodValues3.clone();
        timePeriodValues3.setRangeDescription("");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener10 = null;
        timePeriodValues3.addChangeListener(seriesChangeListener10);
        int int12 = timePeriodValues3.getMinMiddleIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues3.createCopy((int) '#', (int) (short) 100);
        org.jfree.data.time.TimePeriodValues timePeriodValues19 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int20 = timePeriodValues19.getMinMiddleIndex();
        timePeriodValues19.setDescription("hi!");
        boolean boolean23 = timePeriodValues19.isEmpty();
        java.lang.String str24 = timePeriodValues19.getDomainDescription();
        timePeriodValues19.fireSeriesChanged();
        java.lang.Object obj26 = timePeriodValues19.clone();
        int int27 = timePeriodValues19.getItemCount();
        java.beans.PropertyChangeListener propertyChangeListener28 = null;
        timePeriodValues19.addPropertyChangeListener(propertyChangeListener28);
        java.beans.PropertyChangeListener propertyChangeListener30 = null;
        timePeriodValues19.removePropertyChangeListener(propertyChangeListener30);
        org.jfree.data.time.TimePeriodValues timePeriodValues35 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str36 = timePeriodValues35.getDomainDescription();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        long long38 = year37.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = year37.previous();
        java.util.Date date40 = year37.getEnd();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year();
        long long42 = year41.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = year41.previous();
        java.util.Date date44 = year41.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod45 = new org.jfree.data.time.SimpleTimePeriod(date40, date44);
        long long46 = simpleTimePeriod45.getEndMillis();
        java.util.Date date47 = simpleTimePeriod45.getStart();
        boolean boolean48 = timePeriodValues35.equals((java.lang.Object) date47);
        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date47);
        org.jfree.data.time.TimePeriodValue timePeriodValue51 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year49, (java.lang.Number) (short) 0);
        java.lang.String str52 = timePeriodValue51.toString();
        timePeriodValue51.setValue((java.lang.Number) (short) 100);
        timePeriodValues19.add(timePeriodValue51);
        java.lang.Object obj56 = timePeriodValue51.clone();
        timePeriodValues15.add(timePeriodValue51);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertNotNull(obj26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1546329600000L + "'", long38 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1546329600000L + "'", long42 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1577865599999L + "'", long46 == 1577865599999L);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "TimePeriodValue[2019,0]" + "'", str52.equals("TimePeriodValue[2019,0]"));
        org.junit.Assert.assertNotNull(obj56);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) date15);
        timePeriodValues3.fireSeriesChanged();
        timePeriodValues3.setDescription("org.jfree.data.time.TimePeriodFormatException: hi!");
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        org.jfree.data.time.TimePeriodValue timePeriodValue19 = new org.jfree.data.time.TimePeriodValue((org.jfree.data.time.TimePeriod) year17, (java.lang.Number) (short) 0);
        int int20 = year17.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year17.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year17.previous();
        java.util.Calendar calendar23 = null;
        try {
            year17.peg(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        java.lang.String str5 = timePeriodValues3.getRangeDescription();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener6);
        timePeriodValues3.setKey((java.lang.Comparable) 31);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "hi!" + "'", str5.equals("hi!"));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        java.lang.Object obj7 = timePeriodValues3.clone();
        timePeriodValues3.setRangeDescription("");
        int int10 = timePeriodValues3.getMaxEndIndex();
        int int11 = timePeriodValues3.getMaxMiddleIndex();
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timePeriodValues3.removePropertyChangeListener(propertyChangeListener12);
        boolean boolean14 = timePeriodValues3.getNotify();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        java.util.TimeZone timeZone18 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date15, timeZone18);
        int int20 = day19.getYear();
        int int21 = day19.getYear();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(timeZone18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2019 + "'", int21 == 2019);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        int int4 = timePeriodValues3.getMinMiddleIndex();
        timePeriodValues3.setDescription("hi!");
        boolean boolean7 = timePeriodValues3.isEmpty();
        java.lang.Object obj8 = timePeriodValues3.clone();
        int int9 = timePeriodValues3.getMinMiddleIndex();
        java.lang.Class<?> wildcardClass10 = timePeriodValues3.getClass();
        java.lang.Comparable comparable11 = timePeriodValues3.getKey();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year();
        java.lang.Object obj13 = null;
        boolean boolean14 = year12.equals(obj13);
        timePeriodValues3.add((org.jfree.data.time.TimePeriod) year12, (java.lang.Number) 100.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 10.0f + "'", comparable11.equals(10.0f));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) (-1), "", "hi!");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener4 = null;
        timePeriodValues3.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.TimePeriodValues timePeriodValues8 = timePeriodValues3.createCopy((int) (short) -1, (int) (byte) -1);
        boolean boolean9 = timePeriodValues3.isEmpty();
        timePeriodValues3.setDomainDescription("");
        int int12 = timePeriodValues3.getMinEndIndex();
        org.jfree.data.time.TimePeriodValues timePeriodValues15 = timePeriodValues3.createCopy(31, 7);
        org.junit.Assert.assertNotNull(timePeriodValues8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(timePeriodValues15);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.time.TimePeriodValues timePeriodValues3 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str4 = timePeriodValues3.getDomainDescription();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        long long6 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year5.previous();
        java.util.Date date8 = year5.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        long long10 = year9.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = year9.previous();
        java.util.Date date12 = year9.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod13 = new org.jfree.data.time.SimpleTimePeriod(date8, date12);
        long long14 = simpleTimePeriod13.getEndMillis();
        java.util.Date date15 = simpleTimePeriod13.getStart();
        boolean boolean16 = timePeriodValues3.equals((java.lang.Object) date15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date15);
        java.util.Date date18 = year17.getStart();
        java.lang.Object obj19 = null;
        boolean boolean20 = year17.equals(obj19);
        org.jfree.data.time.TimePeriodValues timePeriodValues24 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str25 = timePeriodValues24.getDomainDescription();
        timePeriodValues24.setDescription("");
        boolean boolean28 = timePeriodValues24.isEmpty();
        int int29 = timePeriodValues24.getMinStartIndex();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        long long31 = year30.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year30.previous();
        java.util.Date date33 = year30.getEnd();
        org.jfree.data.time.TimePeriodValues timePeriodValues37 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str38 = timePeriodValues37.getDomainDescription();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        long long40 = year39.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = year39.previous();
        java.util.Date date42 = year39.getEnd();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        long long44 = year43.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year43.previous();
        java.util.Date date46 = year43.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod(date42, date46);
        long long48 = simpleTimePeriod47.getEndMillis();
        java.util.Date date49 = simpleTimePeriod47.getStart();
        boolean boolean50 = timePeriodValues37.equals((java.lang.Object) date49);
        org.jfree.data.time.Year year51 = new org.jfree.data.time.Year(date49);
        java.util.TimeZone timeZone52 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date49, timeZone52);
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod54 = new org.jfree.data.time.SimpleTimePeriod(date33, date49);
        org.jfree.data.time.TimePeriodValues timePeriodValues58 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str59 = timePeriodValues58.getDomainDescription();
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year();
        long long61 = year60.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = year60.previous();
        java.util.Date date63 = year60.getEnd();
        org.jfree.data.time.Year year64 = new org.jfree.data.time.Year();
        long long65 = year64.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = year64.previous();
        java.util.Date date67 = year64.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod68 = new org.jfree.data.time.SimpleTimePeriod(date63, date67);
        long long69 = simpleTimePeriod68.getEndMillis();
        java.util.Date date70 = simpleTimePeriod68.getStart();
        boolean boolean71 = timePeriodValues58.equals((java.lang.Object) date70);
        org.jfree.data.time.Year year72 = new org.jfree.data.time.Year(date70);
        org.jfree.data.time.TimePeriodValues timePeriodValues76 = new org.jfree.data.time.TimePeriodValues((java.lang.Comparable) 10.0f, "", "hi!");
        java.lang.String str77 = timePeriodValues76.getDomainDescription();
        org.jfree.data.time.Year year78 = new org.jfree.data.time.Year();
        long long79 = year78.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod80 = year78.previous();
        java.util.Date date81 = year78.getEnd();
        org.jfree.data.time.Year year82 = new org.jfree.data.time.Year();
        long long83 = year82.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = year82.previous();
        java.util.Date date85 = year82.getEnd();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod86 = new org.jfree.data.time.SimpleTimePeriod(date81, date85);
        long long87 = simpleTimePeriod86.getEndMillis();
        java.util.Date date88 = simpleTimePeriod86.getStart();
        boolean boolean89 = timePeriodValues76.equals((java.lang.Object) date88);
        org.jfree.data.time.Year year90 = new org.jfree.data.time.Year(date88);
        java.util.TimeZone timeZone91 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Day day92 = new org.jfree.data.time.Day(date88, timeZone91);
        org.jfree.data.time.Day day93 = new org.jfree.data.time.Day(date70, timeZone91);
        org.jfree.data.time.Year year94 = new org.jfree.data.time.Year(date33, timeZone91);
        boolean boolean95 = timePeriodValues24.equals((java.lang.Object) date33);
        boolean boolean96 = year17.equals((java.lang.Object) date33);
        org.jfree.data.time.Year year97 = new org.jfree.data.time.Year(date33);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1546329600000L + "'", long6 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1577865599999L + "'", long14 == 1577865599999L);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 1546329600000L + "'", long31 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "" + "'", str38.equals(""));
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1546329600000L + "'", long40 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1546329600000L + "'", long44 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1577865599999L + "'", long48 == 1577865599999L);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(timeZone52);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "" + "'", str59.equals(""));
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 1546329600000L + "'", long61 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1546329600000L + "'", long65 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
        org.junit.Assert.assertNotNull(date67);
        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 1577865599999L + "'", long69 == 1577865599999L);
        org.junit.Assert.assertNotNull(date70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "" + "'", str77.equals(""));
        org.junit.Assert.assertTrue("'" + long79 + "' != '" + 1546329600000L + "'", long79 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod80);
        org.junit.Assert.assertNotNull(date81);
        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 1546329600000L + "'", long83 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod84);
        org.junit.Assert.assertNotNull(date85);
        org.junit.Assert.assertTrue("'" + long87 + "' != '" + 1577865599999L + "'", long87 == 1577865599999L);
        org.junit.Assert.assertNotNull(date88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertNotNull(timeZone91);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
    }
}

