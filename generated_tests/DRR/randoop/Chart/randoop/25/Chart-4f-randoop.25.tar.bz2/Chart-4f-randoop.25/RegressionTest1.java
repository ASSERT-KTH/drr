import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        int int0 = org.jfree.data.time.Year.MINIMUM_YEAR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-9999) + "'", int0 == (-9999));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D2.setUpperMargin((double) (short) 0);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        numberAxis3D2.setTickLabelPaint((java.awt.Paint) color5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis7);
        int int9 = combinedDomainXYPlot8.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot8.rendererChanged(rendererChangeEvent11);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier13 = null;
        combinedDomainXYPlot8.setDrawingSupplier(drawingSupplier13, false);
        numberAxis3D2.removeChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot8);
        org.jfree.chart.entity.AxisEntity axisEntity18 = new org.jfree.chart.entity.AxisEntity(shape1, (org.jfree.chart.axis.Axis) numberAxis3D2, "series");
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setUpperMargin((double) (short) 0);
        numberAxis3D0.resizeRange2((double) 10L, (double) 12);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = numberAxis3D0.getMarkerBand();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis9);
        int int11 = combinedDomainXYPlot10.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot10.rendererChanged(rendererChangeEvent13);
        combinedDomainXYPlot8.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot10);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = combinedDomainXYPlot10.getDomainAxisEdge((int) (byte) 1);
        numberAxis3D0.setPlot((org.jfree.chart.plot.Plot) combinedDomainXYPlot10);
        java.awt.Paint paint19 = combinedDomainXYPlot10.getDomainMinorGridlinePaint();
        combinedDomainXYPlot10.setForegroundAlpha(0.5f);
        org.junit.Assert.assertNull(markerAxisBand6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator2 = null;
        xYAreaRenderer0.setLegendItemToolTipGenerator(xYSeriesLabelGenerator2);
        java.awt.Paint paint5 = xYAreaRenderer0.getSeriesPaint(2);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator7 = xYAreaRenderer0.getSeriesItemLabelGenerator(10);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator8 = xYAreaRenderer0.getLegendItemURLGenerator();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator9 = xYAreaRenderer0.getLegendItemURLGenerator();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNull(xYItemLabelGenerator7);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator8);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator9);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.START;
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor1 = org.jfree.data.time.TimePeriodAnchor.END;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint4 = categoryAxis3D3.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D3, jFreeChart5, (int) (short) 1, (int) (short) 10);
        boolean boolean9 = timePeriodAnchor1.equals((java.lang.Object) (short) 10);
        timeSeriesCollection0.setXPosition(timePeriodAnchor1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate11 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        intervalXYDelegate11.datasetChanged(datasetChangeEvent12);
        try {
            java.lang.Number number16 = intervalXYDelegate11.getStartX(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodAnchor1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer3D2.setSeriesURLGenerator(2, categoryURLGenerator5, true);
        java.awt.Font font9 = barRenderer3D2.lookupLegendTextFont((int) (short) 100);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNull(font9);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        java.awt.Shape shape2 = xYAreaRenderer0.getBaseShape();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        legendGraphic4.setWidth((double) 8);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D11 = legendGraphic4.arrange(graphics2D7, rectangleConstraint10);
        double double12 = legendGraphic4.getHeight();
        boolean boolean13 = legendGraphic4.isShapeVisible();
        java.awt.Shape shape16 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (-1), (float) (-460));
        org.jfree.chart.plot.PiePlot3D piePlot3D17 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator18 = null;
        piePlot3D17.setLabelGenerator(pieSectionLabelGenerator18);
        piePlot3D17.setShadowXOffset(0.0d);
        piePlot3D17.setIgnoreZeroValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = piePlot3D17.getSimpleLabelOffset();
        org.jfree.chart.entity.PlotEntity plotEntity27 = new org.jfree.chart.entity.PlotEntity(shape16, (org.jfree.chart.plot.Plot) piePlot3D17, "RangeType.FULL", "35");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection28 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries32.clear();
        timeSeries32.setDescription("series");
        int int36 = timeSeriesCollection28.indexOf(timeSeries32);
        boolean boolean37 = plotEntity27.equals((java.lang.Object) int36);
        boolean boolean38 = legendGraphic4.equals((java.lang.Object) boolean37);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(size2D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray3 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray3);
        categoryPlot0.setWeight(2147483647);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation7 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(categoryAxisArray3);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("[8.0, 100.0]");
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        crosshairState0.setAnchorY((double) (-460));
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        crosshairState0.updateCrosshairPoint(10.0d, (double) 0.0f, 3, (int) (short) 1, (double) (byte) 1, (double) 10.0f, plotOrientation9);
        double double11 = crosshairState0.getAnchorX();
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getNumberInstance();
        java.lang.String str3 = numberFormat1.format(0.0d);
        java.text.NumberFormat numberFormat4 = java.text.NumberFormat.getNumberInstance();
        java.lang.String str6 = numberFormat4.format((long) 1);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator7 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Combined Range XYPlot", numberFormat1, numberFormat4);
        java.text.ParsePosition parsePosition9 = null;
        try {
            java.lang.Object obj10 = numberFormat1.parseObject("", parsePosition9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1" + "'", str6.equals("1"));
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        int int4 = combinedDomainXYPlot3.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot3.rendererChanged(rendererChangeEvent6);
        combinedDomainXYPlot1.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot3);
        java.lang.String str9 = combinedDomainXYPlot3.getPlotType();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Combined_Domain_XYPlot" + "'", str9.equals("Combined_Domain_XYPlot"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator("RectangleAnchor.CENTER");
        java.lang.Object obj2 = standardPieToolTipGenerator1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setUpperMargin((double) (short) 0);
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        numberAxis3D0.setTickLabelPaint((java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis5);
        int int7 = combinedDomainXYPlot6.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot6.rendererChanged(rendererChangeEvent9);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = null;
        combinedDomainXYPlot6.setDrawingSupplier(drawingSupplier11, false);
        numberAxis3D0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot6);
        java.awt.Shape shape15 = numberAxis3D0.getDownArrow();
        numberAxis3D0.setLabel("Combined_Domain_XYPlot");
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertNotNull(shape15);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor1 = org.jfree.data.time.TimePeriodAnchor.END;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint4 = categoryAxis3D3.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D3, jFreeChart5, (int) (short) 1, (int) (short) 10);
        boolean boolean9 = timePeriodAnchor1.equals((java.lang.Object) (short) 10);
        timeSeriesCollection0.setXPosition(timePeriodAnchor1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate11 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        double double13 = intervalXYDelegate11.getDomainUpperBound(false);
        intervalXYDelegate11.setIntervalPositionFactor(0.0d);
        org.junit.Assert.assertNotNull(timePeriodAnchor1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = combinedDomainXYPlot1.getDataRange(valueAxis2);
        java.lang.Object obj4 = null;
        boolean boolean5 = combinedDomainXYPlot1.equals(obj4);
        combinedDomainXYPlot1.setDomainCrosshairVisible(false);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        piePlot3D9.setSimpleLabelOffset(rectangleInsets10);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection12 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries16.clear();
        timeSeries16.setDescription("series");
        int int20 = timeSeriesCollection12.indexOf(timeSeries16);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer22 = null;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection12, (org.jfree.chart.axis.ValueAxis) numberAxis21, polarItemRenderer22);
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = polarPlot23.getOrientation();
        java.awt.Paint paint25 = polarPlot23.getRadiusGridlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer29 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean30 = xYAreaRenderer29.isOutline();
        java.awt.Shape shape31 = xYAreaRenderer29.getBaseShape();
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic33 = new org.jfree.chart.title.LegendGraphic(shape31, (java.awt.Paint) color32);
        legendGraphic33.setWidth((double) 8);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D40 = legendGraphic33.arrange(graphics2D36, rectangleConstraint39);
        double double41 = legendGraphic33.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor42 = legendGraphic33.getShapeLocation();
        java.awt.geom.Rectangle2D rectangle2D43 = legendGraphic33.getBounds();
        rectangleInsets28.trim(rectangle2D43);
        java.awt.Point point45 = polarPlot23.translateValueThetaRadiusToJava2D((double) (-1.0f), (double) (short) 100, rectangle2D43);
        java.awt.geom.Rectangle2D rectangle2D46 = rectangleInsets10.createInsetRectangle(rectangle2D43);
        try {
            combinedDomainXYPlot1.drawOutline(graphics2D8, rectangle2D43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(size2D40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor42);
        org.junit.Assert.assertNotNull(rectangle2D43);
        org.junit.Assert.assertNotNull(point45);
        org.junit.Assert.assertNotNull(rectangle2D46);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator2 = null;
        xYAreaRenderer0.setLegendItemToolTipGenerator(xYSeriesLabelGenerator2);
        java.awt.Paint paint5 = xYAreaRenderer0.getSeriesPaint(2);
        java.awt.Stroke stroke7 = xYAreaRenderer0.getSeriesOutlineStroke((int) (byte) 1);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer9 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        xYAreaRenderer9.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition11);
        boolean boolean13 = xYAreaRenderer9.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Paint paint15 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYAreaRenderer9.setSeriesItemLabelPaint((int) '#', paint15, false);
        xYAreaRenderer0.setSeriesPaint(6, paint15, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint3 = categoryAxis3D2.getLabelPaint();
        categoryAxis3D2.setTickMarkInsideLength((float) 0);
        java.awt.Font font6 = categoryAxis3D2.getLabelFont();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.lang.Class<?> wildcardClass12 = stroke11.getClass();
        boolean boolean13 = verticalAlignment10.equals((java.lang.Object) stroke11);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double16 = rectangleInsets14.calculateTopInset(10.0d);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font6, (java.awt.Paint) color7, rectangleEdge8, horizontalAlignment9, verticalAlignment10, rectangleInsets14);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D20 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint21 = categoryAxis3D20.getLabelPaint();
        categoryAxis3D20.setTickMarkInsideLength((float) 0);
        java.awt.Font font24 = categoryAxis3D20.getLabelFont();
        java.awt.Color color25 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment27 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment28 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke29 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.lang.Class<?> wildcardClass30 = stroke29.getClass();
        boolean boolean31 = verticalAlignment28.equals((java.lang.Object) stroke29);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double34 = rectangleInsets32.calculateTopInset(10.0d);
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font24, (java.awt.Paint) color25, rectangleEdge26, horizontalAlignment27, verticalAlignment28, rectangleInsets32);
        textTitle17.setHorizontalAlignment(horizontalAlignment27);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection37 = new org.jfree.data.xy.XYSeriesCollection();
        xYSeriesCollection37.removeAllSeries();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent39 = null;
        xYSeriesCollection37.seriesChanged(seriesChangeEvent39);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState41 = xYSeriesCollection37.getSelectionState();
        xYSeriesCollection37.removeAllSeries();
        boolean boolean43 = horizontalAlignment27.equals((java.lang.Object) xYSeriesCollection37);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(horizontalAlignment27);
        org.junit.Assert.assertNotNull(verticalAlignment28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0.0f);
        java.lang.Object obj2 = valueMarker1.clone();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        valueMarker1.setLabelOffsetType(lengthAdjustmentType3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis5);
        int int7 = combinedDomainXYPlot6.getBackgroundImageAlignment();
        combinedDomainXYPlot6.setForegroundAlpha((float) (-1));
        java.awt.Stroke stroke10 = combinedDomainXYPlot6.getDomainMinorGridlineStroke();
        valueMarker1.setStroke(stroke10);
        java.io.ObjectOutputStream objectOutputStream12 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke10, objectOutputStream12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(lengthAdjustmentType3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint2 = categoryAxis3D1.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent6 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D1, jFreeChart3, (int) (short) 1, (int) (short) 10);
        categoryAxis3D1.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer9 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint10 = xYAreaRenderer9.getBaseLegendTextPaint();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator11 = null;
        xYAreaRenderer9.setBaseItemLabelGenerator(xYItemLabelGenerator11, true);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot15 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis14);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.data.Range range17 = combinedDomainXYPlot15.getDataRange(valueAxis16);
        java.lang.Object obj18 = null;
        boolean boolean19 = combinedDomainXYPlot15.equals(obj18);
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        combinedDomainXYPlot15.setRangeGridlineStroke(stroke20);
        xYAreaRenderer9.setBaseOutlineStroke(stroke20);
        boolean boolean23 = categoryAxis3D1.equals((java.lang.Object) xYAreaRenderer9);
        boolean boolean24 = xYAreaRenderer9.getBaseItemLabelsVisible();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(10);
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord2 = null;
        try {
            pieLabelDistributor1.addPieLabelRecord(pieLabelRecord2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.trimWidth((double) 1560495599999L);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint4 = xYAreaRenderer3.getBaseLegendTextPaint();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator5 = null;
        xYAreaRenderer3.setBaseItemLabelGenerator(xYItemLabelGenerator5, true);
        java.awt.Shape shape8 = xYAreaRenderer3.getBaseShape();
        boolean boolean9 = rectangleInsets0.equals((java.lang.Object) shape8);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.560495599991E12d + "'", double2 == 1.560495599991E12d);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator2 = null;
        xYAreaRenderer0.setLegendItemToolTipGenerator(xYSeriesLabelGenerator2);
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYAreaRenderer0.setSeriesStroke(3, stroke5);
        boolean boolean10 = xYAreaRenderer0.isItemLabelVisible((int) (short) 1, (int) (byte) 100, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range12 = xYAreaRenderer0.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState13 = xYSeriesCollection11.getSelectionState();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState13);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer3D2.setSeriesURLGenerator(2, categoryURLGenerator5, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = barRenderer3D2.getSeriesItemLabelGenerator((int) (short) 10);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator9);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint3 = categoryAxis3D2.getLabelPaint();
        categoryAxis3D2.setTickMarkInsideLength((float) 0);
        java.awt.Font font6 = categoryAxis3D2.getLabelFont();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.lang.Class<?> wildcardClass12 = stroke11.getClass();
        boolean boolean13 = verticalAlignment10.equals((java.lang.Object) stroke11);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double16 = rectangleInsets14.calculateTopInset(10.0d);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font6, (java.awt.Paint) color7, rectangleEdge8, horizontalAlignment9, verticalAlignment10, rectangleInsets14);
        boolean boolean18 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge8);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot3D0.setLabelGenerator(pieSectionLabelGenerator1);
        piePlot3D0.setShadowXOffset(0.0d);
        piePlot3D0.setIgnoreZeroValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot3D0.getSimpleLabelOffset();
        boolean boolean8 = piePlot3D0.getIgnoreZeroValues();
        java.lang.Object obj9 = piePlot3D0.clone();
        piePlot3D0.clearSectionOutlineStrokes(false);
        java.awt.Paint paint13 = piePlot3D0.getSectionOutlinePaint((java.lang.Comparable) "ClassContext");
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(paint13);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        double double4 = barRenderer3D2.getXOffset();
        int int5 = barRenderer3D2.getColumnCount();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer7 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean8 = xYAreaRenderer7.isOutline();
        java.awt.Shape shape9 = xYAreaRenderer7.getBaseShape();
        try {
            barRenderer3D2.setSeriesShape((-1), shape9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.099412556013E12d + "'", double4 == 1.099412556013E12d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 5");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.data.DomainOrder domainOrder2 = org.jfree.data.DomainOrder.ASCENDING;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D3.centerRange((-1.0d));
        java.awt.Paint paint6 = numberAxis3D3.getTickLabelPaint();
        boolean boolean7 = domainOrder2.equals((java.lang.Object) paint6);
        org.jfree.chart.text.TextBlock textBlock8 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint6);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(domainOrder2);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(textBlock8);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor1 = org.jfree.data.time.TimePeriodAnchor.END;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint4 = categoryAxis3D3.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D3, jFreeChart5, (int) (short) 1, (int) (short) 10);
        boolean boolean9 = timePeriodAnchor1.equals((java.lang.Object) (short) 10);
        timeSeriesCollection0.setXPosition(timePeriodAnchor1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate11 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        java.lang.Object obj12 = timeSeriesCollection0.clone();
        org.junit.Assert.assertNotNull(timePeriodAnchor1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment(date2);
        java.util.Date date4 = segment3.getDate();
        boolean boolean7 = segment3.contains((long) '#', 86400000L);
        boolean boolean10 = segment3.contains((long) (short) 0, 0L);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(segment3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        try {
            double double3 = timeSeriesCollection0.getXValue(100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState();
        crosshairState1.setAnchorY((double) (-460));
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        crosshairState1.updateCrosshairPoint(10.0d, (double) 0.0f, 3, (int) (short) 1, (double) (byte) 1, (double) 10.0f, plotOrientation10);
        categoryPlot0.setOrientation(plotOrientation10);
        org.junit.Assert.assertNotNull(plotOrientation10);
    }

//    @Test
//    public void test041() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test041");
//        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
//        try {
//            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNull(timeZone0);
//    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) ' ');
        pieLabelDistributor1.sort();
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        java.awt.Color color2 = java.awt.Color.getColor("", (int) (byte) 10);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.QUAD_CURVE;
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Line2D line2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(line2D0, line2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline2 = segmentedTimeline0.getBaseTimeline();
        segmentedTimeline0.setAdjustForDaylightSaving(false);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertNotNull(segmentedTimeline2);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setBaseSeriesVisible(false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = xYAreaRenderer0.getGradientTransformer();
        org.junit.Assert.assertNotNull(gradientPaintTransformer3);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Image image1 = org.jfree.chart.util.SerialUtilities.readImage(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        int int4 = combinedDomainXYPlot3.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot3.rendererChanged(rendererChangeEvent6);
        combinedDomainXYPlot1.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries14.clear();
        timeSeries14.setDescription("series");
        int int18 = timeSeriesCollection10.indexOf(timeSeries14);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer20 = null;
        org.jfree.chart.plot.PolarPlot polarPlot21 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection10, (org.jfree.chart.axis.ValueAxis) numberAxis19, polarItemRenderer20);
        org.jfree.chart.plot.PlotOrientation plotOrientation22 = polarPlot21.getOrientation();
        java.awt.Paint paint23 = polarPlot21.getRadiusGridlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer27 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean28 = xYAreaRenderer27.isOutline();
        java.awt.Shape shape29 = xYAreaRenderer27.getBaseShape();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic31 = new org.jfree.chart.title.LegendGraphic(shape29, (java.awt.Paint) color30);
        legendGraphic31.setWidth((double) 8);
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint37 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D38 = legendGraphic31.arrange(graphics2D34, rectangleConstraint37);
        double double39 = legendGraphic31.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = legendGraphic31.getShapeLocation();
        java.awt.geom.Rectangle2D rectangle2D41 = legendGraphic31.getBounds();
        rectangleInsets26.trim(rectangle2D41);
        java.awt.Point point43 = polarPlot21.translateValueThetaRadiusToJava2D((double) (-1.0f), (double) (short) 100, rectangle2D41);
        try {
            org.jfree.chart.plot.XYPlot xYPlot44 = combinedDomainXYPlot3.findSubplot(plotRenderingInfo9, (java.awt.geom.Point2D) point43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(size2D38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(point43);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("RangeType.FULL");
        java.lang.String str3 = legendItem2.getURLText();
        java.lang.String str4 = legendItem2.getURLText();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis5);
        double double7 = combinedRangeXYPlot6.getGap();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis8);
        java.awt.Paint paint10 = combinedDomainXYPlot9.getBackgroundPaint();
        combinedRangeXYPlot6.addChangeListener((org.jfree.chart.event.PlotChangeListener) combinedDomainXYPlot9);
        boolean boolean12 = legendItem2.equals((java.lang.Object) combinedRangeXYPlot6);
        legendItemCollection0.add(legendItem2);
        legendItem2.setShapeVisible(true);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 5.0d + "'", double7 == 5.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries4.clear();
        timeSeries4.setDescription("series");
        int int8 = timeSeriesCollection0.indexOf(timeSeries4);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection0, (org.jfree.chart.axis.ValueAxis) numberAxis9, polarItemRenderer10);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = polarPlot11.getOrientation();
        java.awt.Paint paint13 = polarPlot11.getRadiusGridlinePaint();
        java.awt.Stroke stroke14 = polarPlot11.getRadiusGridlineStroke();
        polarPlot11.setRadiusGridlinesVisible(false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Color color4 = color3.brighter();
        float[] floatArray11 = new float[] { (short) -1, (byte) 1, 172800000L, (short) 10, ' ', 10 };
        float[] floatArray12 = color4.getComponents(floatArray11);
        float[] floatArray13 = java.awt.Color.RGBtoHSB((int) '#', 8, (-1), floatArray11);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeMinorGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer(10);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint6 = categoryAxis3D5.getLabelPaint();
        categoryAxis3D5.setTickMarkInsideLength((float) 0);
        categoryAxis3D5.addCategoryLabelToolTip((java.lang.Comparable) 1, "series");
        int int12 = categoryPlot0.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D5);
        double[] doubleArray19 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray24 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray25 = new double[][] { doubleArray19, doubleArray24 };
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray25);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot27 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset26);
        org.jfree.data.category.CategoryDataset categoryDataset28 = multiplePiePlot27.getDataset();
        boolean boolean29 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset28);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = categoryPlot0.getRendererForDataset(categoryDataset28);
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker((double) 0.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent33 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker32);
        org.jfree.chart.util.Layer layer34 = null;
        boolean boolean35 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker32, layer34);
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace36, true);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(categoryItemRenderer30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        java.awt.Shape shape2 = xYAreaRenderer0.getBaseShape();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        legendGraphic4.setWidth((double) 8);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D11 = legendGraphic4.arrange(graphics2D7, rectangleConstraint10);
        double double12 = legendGraphic4.getHeight();
        java.lang.Object obj13 = legendGraphic4.clone();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection15 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries19.clear();
        timeSeries19.setDescription("series");
        int int23 = timeSeriesCollection15.indexOf(timeSeries19);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer25 = null;
        org.jfree.chart.plot.PolarPlot polarPlot26 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection15, (org.jfree.chart.axis.ValueAxis) numberAxis24, polarItemRenderer25);
        org.jfree.chart.plot.PlotOrientation plotOrientation27 = polarPlot26.getOrientation();
        java.awt.Paint paint28 = polarPlot26.getRadiusGridlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer32 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean33 = xYAreaRenderer32.isOutline();
        java.awt.Shape shape34 = xYAreaRenderer32.getBaseShape();
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic36 = new org.jfree.chart.title.LegendGraphic(shape34, (java.awt.Paint) color35);
        legendGraphic36.setWidth((double) 8);
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D43 = legendGraphic36.arrange(graphics2D39, rectangleConstraint42);
        double double44 = legendGraphic36.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = legendGraphic36.getShapeLocation();
        java.awt.geom.Rectangle2D rectangle2D46 = legendGraphic36.getBounds();
        rectangleInsets31.trim(rectangle2D46);
        java.awt.Point point48 = polarPlot26.translateValueThetaRadiusToJava2D((double) (-1.0f), (double) (short) 100, rectangle2D46);
        try {
            legendGraphic4.draw(graphics2D14, rectangle2D46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(size2D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(size2D43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(point48);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setDrawSeriesLineAsPath(true);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) month0, false);
        xYSeries3.add((double) 10.0f, (java.lang.Number) 0.5d);
        xYSeries3.add((double) 2, (java.lang.Number) 12, true);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.centerRange((-1.0d));
        java.awt.Paint paint3 = numberAxis3D0.getTickLabelPaint();
        float float4 = numberAxis3D0.getTickMarkInsideLength();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D5.centerRange((-1.0d));
        java.awt.Paint paint8 = numberAxis3D5.getTickLabelPaint();
        org.jfree.data.Range range9 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double10 = range9.getLength();
        numberAxis3D5.setRangeWithMargins(range9, false, false);
        double double15 = range9.constrain(0.0d);
        numberAxis3D0.setRangeWithMargins(range9, true, false);
        org.jfree.data.Range range20 = org.jfree.data.Range.expandToInclude(range9, 8.19260189995275E11d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(range20);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0.0f);
        java.lang.Object obj2 = valueMarker1.clone();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean4 = xYAreaRenderer3.isOutline();
        java.awt.Shape shape5 = xYAreaRenderer3.getBaseShape();
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        xYAreaRenderer3.setBaseItemLabelPaint((java.awt.Paint) color6, false);
        valueMarker1.setLabelPaint((java.awt.Paint) color6);
        java.awt.Paint paint10 = valueMarker1.getLabelPaint();
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator("RectangleAnchor.CENTER");
        org.jfree.data.general.PieDataset pieDataset2 = null;
        java.lang.String str4 = standardPieToolTipGenerator1.generateToolTip(pieDataset2, (java.lang.Comparable) (-9999));
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray3 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray3);
        boolean boolean6 = categoryPlot0.equals((java.lang.Object) "hi!");
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer8 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean9 = xYLineAndShapeRenderer8.getBaseShapesVisible();
        xYLineAndShapeRenderer8.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer13 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean14 = xYAreaRenderer13.isOutline();
        java.awt.Shape shape15 = xYAreaRenderer13.getBaseShape();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic17 = new org.jfree.chart.title.LegendGraphic(shape15, (java.awt.Paint) color16);
        legendGraphic17.setWidth((double) 8);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D24 = legendGraphic17.arrange(graphics2D20, rectangleConstraint23);
        double double25 = legendGraphic17.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = legendGraphic17.getShapeLocation();
        java.awt.geom.Rectangle2D rectangle2D27 = legendGraphic17.getBounds();
        rectangleInsets12.trim(rectangle2D27);
        xYLineAndShapeRenderer8.setLegendLine((java.awt.Shape) rectangle2D27);
        try {
            categoryPlot0.drawBackground(graphics2D7, rectangle2D27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(categoryAxisArray3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(size2D24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNotNull(rectangle2D27);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor1 = org.jfree.data.time.TimePeriodAnchor.END;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint4 = categoryAxis3D3.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D3, jFreeChart5, (int) (short) 1, (int) (short) 10);
        boolean boolean9 = timePeriodAnchor1.equals((java.lang.Object) (short) 10);
        timeSeriesCollection0.setXPosition(timePeriodAnchor1);
        try {
            timeSeriesCollection0.setSelected((int) (short) 100, (int) (byte) 1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (100).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodAnchor1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        double[] doubleArray6 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray11 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray12 = new double[][] { doubleArray6, doubleArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        org.jfree.data.category.CategoryDataset categoryDataset15 = multiplePiePlot14.getDataset();
        org.jfree.chart.util.TableOrder tableOrder16 = multiplePiePlot14.getDataExtractOrder();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertNotNull(tableOrder16);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer2 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer(false, false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangePannable(true);
        double double4 = combinedDomainXYPlot1.getGap();
        java.lang.Object obj5 = combinedDomainXYPlot1.clone();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            combinedDomainXYPlot1.handleClick(3, (-460), plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5.0d + "'", double4 == 5.0d);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        combinedDomainXYPlot1.setForegroundAlpha((float) (-1));
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        combinedDomainXYPlot1.setDomainAxisLocation((int) (short) 1, axisLocation6);
        combinedDomainXYPlot1.setWeight(1);
        java.awt.Paint paint10 = combinedDomainXYPlot1.getOutlinePaint();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateTopInset(10.0d);
        double double4 = rectangleInsets0.trimHeight((double) 8);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("[size=0]");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo1);
        org.jfree.chart.ui.ProjectInfo projectInfo3 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Image image4 = null;
        projectInfo3.setLogo(image4);
        projectInfo1.addLibrary((org.jfree.chart.ui.Library) projectInfo3);
        projectInfo1.setInfo("");
        org.junit.Assert.assertNotNull(projectInfo1);
    }

//    @Test
//    public void test074() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test074");
//        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
//        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
//        try {
//            java.lang.Number number4 = timeSeriesCollection1.getStartY(10, (-460));
//            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
//        } catch (java.lang.IndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNull(timeZone0);
//    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection1, true);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean7 = xYAreaRenderer6.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator8 = null;
        xYAreaRenderer6.setLegendItemToolTipGenerator(xYSeriesLabelGenerator8);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection1, valueAxis4, valueAxis5, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer6);
        boolean boolean11 = xYAreaRenderer6.isOutline();
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYAreaRenderer6.setSeriesItemLabelFont(100, font13);
        piePlot3D0.setLabelFont(font13);
        double double16 = piePlot3D0.getMaximumExplodePercent();
        piePlot3D0.setLabelLinksVisible(true);
        piePlot3D0.clearSectionOutlinePaints(true);
        double double21 = piePlot3D0.getMaximumExplodePercent();
        piePlot3D0.setIgnoreNullValues(true);
        piePlot3D0.setPieIndex(2147483647);
        piePlot3D0.setSimpleLabels(true);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(96, (int) (byte) -1, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Green");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        int int4 = combinedDomainXYPlot3.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot3.rendererChanged(rendererChangeEvent6);
        combinedDomainXYPlot1.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot3);
        combinedDomainXYPlot3.setDomainMinorGridlinesVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection13 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries17.clear();
        timeSeries17.setDescription("series");
        int int21 = timeSeriesCollection13.indexOf(timeSeries17);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer23 = null;
        org.jfree.chart.plot.PolarPlot polarPlot24 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection13, (org.jfree.chart.axis.ValueAxis) numberAxis22, polarItemRenderer23);
        org.jfree.chart.plot.PlotOrientation plotOrientation25 = polarPlot24.getOrientation();
        java.awt.Paint paint26 = polarPlot24.getRadiusGridlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer30 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean31 = xYAreaRenderer30.isOutline();
        java.awt.Shape shape32 = xYAreaRenderer30.getBaseShape();
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic34 = new org.jfree.chart.title.LegendGraphic(shape32, (java.awt.Paint) color33);
        legendGraphic34.setWidth((double) 8);
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint40 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D41 = legendGraphic34.arrange(graphics2D37, rectangleConstraint40);
        double double42 = legendGraphic34.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor43 = legendGraphic34.getShapeLocation();
        java.awt.geom.Rectangle2D rectangle2D44 = legendGraphic34.getBounds();
        rectangleInsets29.trim(rectangle2D44);
        java.awt.Point point46 = polarPlot24.translateValueThetaRadiusToJava2D((double) (-1.0f), (double) (short) 100, rectangle2D44);
        try {
            combinedDomainXYPlot3.zoomRangeAxes(0.18d, plotRenderingInfo12, (java.awt.geom.Point2D) point46, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1) + "'", int21 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(size2D41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor43);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertNotNull(point46);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_NONE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setUpperMargin((double) (short) 0);
        numberAxis3D0.resizeRange2((double) 10L, (double) 12);
        numberAxis3D0.setAutoTickUnitSelection(false);
        numberAxis3D0.centerRange(5.0d);
        org.jfree.chart.event.AxisChangeListener axisChangeListener10 = null;
        numberAxis3D0.addChangeListener(axisChangeListener10);
        org.jfree.chart.plot.PiePlot3D piePlot3D12 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection13 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection13, true);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer18 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean19 = xYAreaRenderer18.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator20 = null;
        xYAreaRenderer18.setLegendItemToolTipGenerator(xYSeriesLabelGenerator20);
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection13, valueAxis16, valueAxis17, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer18);
        boolean boolean23 = xYAreaRenderer18.isOutline();
        java.awt.Font font25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYAreaRenderer18.setSeriesItemLabelFont(100, font25);
        piePlot3D12.setLabelFont(font25);
        numberAxis3D0.setLabelFont(font25);
        java.awt.Shape shape29 = numberAxis3D0.getRightArrow();
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.axis.AxisState axisState31 = new org.jfree.chart.axis.AxisState();
        double double32 = axisState31.getMax();
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D35 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint36 = categoryAxis3D35.getLabelPaint();
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D39 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        piePlot3D39.setSimpleLabelOffset(rectangleInsets40);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection42 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries46.clear();
        timeSeries46.setDescription("series");
        int int50 = timeSeriesCollection42.indexOf(timeSeries46);
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer52 = null;
        org.jfree.chart.plot.PolarPlot polarPlot53 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection42, (org.jfree.chart.axis.ValueAxis) numberAxis51, polarItemRenderer52);
        org.jfree.chart.plot.PlotOrientation plotOrientation54 = polarPlot53.getOrientation();
        java.awt.Paint paint55 = polarPlot53.getRadiusGridlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer59 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean60 = xYAreaRenderer59.isOutline();
        java.awt.Shape shape61 = xYAreaRenderer59.getBaseShape();
        java.awt.Color color62 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic63 = new org.jfree.chart.title.LegendGraphic(shape61, (java.awt.Paint) color62);
        legendGraphic63.setWidth((double) 8);
        java.awt.Graphics2D graphics2D66 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint69 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D70 = legendGraphic63.arrange(graphics2D66, rectangleConstraint69);
        double double71 = legendGraphic63.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor72 = legendGraphic63.getShapeLocation();
        java.awt.geom.Rectangle2D rectangle2D73 = legendGraphic63.getBounds();
        rectangleInsets58.trim(rectangle2D73);
        java.awt.Point point75 = polarPlot53.translateValueThetaRadiusToJava2D((double) (-1.0f), (double) (short) 100, rectangle2D73);
        java.awt.geom.Rectangle2D rectangle2D76 = rectangleInsets40.createInsetRectangle(rectangle2D73);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D79 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint80 = categoryAxis3D79.getLabelPaint();
        categoryAxis3D79.setTickMarkInsideLength((float) 0);
        java.awt.Font font83 = categoryAxis3D79.getLabelFont();
        java.awt.Color color84 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge85 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment86 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment87 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke88 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.lang.Class<?> wildcardClass89 = stroke88.getClass();
        boolean boolean90 = verticalAlignment87.equals((java.lang.Object) stroke88);
        org.jfree.chart.util.RectangleInsets rectangleInsets91 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double93 = rectangleInsets91.calculateTopInset(10.0d);
        org.jfree.chart.title.TextTitle textTitle94 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font83, (java.awt.Paint) color84, rectangleEdge85, horizontalAlignment86, verticalAlignment87, rectangleInsets91);
        org.jfree.chart.axis.AxisState axisState95 = new org.jfree.chart.axis.AxisState();
        categoryAxis3D35.drawTickMarks(graphics2D37, (double) (byte) 0, rectangle2D76, rectangleEdge85, axisState95);
        try {
            java.util.List list97 = numberAxis3D0.refreshTicks(graphics2D30, axisState31, rectangle2D33, rectangleEdge85);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation54);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(shape61);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(size2D70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor72);
        org.junit.Assert.assertNotNull(rectangle2D73);
        org.junit.Assert.assertNotNull(point75);
        org.junit.Assert.assertNotNull(rectangle2D76);
        org.junit.Assert.assertNotNull(paint80);
        org.junit.Assert.assertNotNull(font83);
        org.junit.Assert.assertNotNull(color84);
        org.junit.Assert.assertNotNull(rectangleEdge85);
        org.junit.Assert.assertNotNull(horizontalAlignment86);
        org.junit.Assert.assertNotNull(verticalAlignment87);
        org.junit.Assert.assertNotNull(stroke88);
        org.junit.Assert.assertNotNull(wildcardClass89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNotNull(rectangleInsets91);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 0.0d + "'", double93 == 0.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        java.awt.Shape shape2 = xYAreaRenderer0.getBaseShape();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        legendGraphic4.setWidth((double) 8);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D11 = legendGraphic4.arrange(graphics2D7, rectangleConstraint10);
        double double12 = legendGraphic4.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor13 = legendGraphic4.getShapeLocation();
        java.awt.Shape shape14 = null;
        legendGraphic4.setLine(shape14);
        legendGraphic4.setWidth((double) 4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(size2D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor13);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangePannable(true);
        combinedDomainXYPlot1.setRangePannable(true);
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection8 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection8, true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer13 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean14 = xYAreaRenderer13.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator15 = null;
        xYAreaRenderer13.setLegendItemToolTipGenerator(xYSeriesLabelGenerator15);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection8, valueAxis11, valueAxis12, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer13);
        boolean boolean18 = xYAreaRenderer13.isOutline();
        java.awt.Font font20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYAreaRenderer13.setSeriesItemLabelFont(100, font20);
        piePlot3D7.setLabelFont(font20);
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer25 = null;
        org.jfree.chart.text.TextBlock textBlock26 = org.jfree.chart.text.TextUtilities.createTextBlock("", font20, (java.awt.Paint) color23, (float) 100L, textMeasurer25);
        combinedDomainXYPlot1.setBackgroundPaint((java.awt.Paint) color23);
        java.awt.Stroke stroke28 = combinedDomainXYPlot1.getRangeGridlineStroke();
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(textBlock26);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries4.clear();
        timeSeries4.setDescription("series");
        int int8 = timeSeriesCollection0.indexOf(timeSeries4);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection0, (org.jfree.chart.axis.ValueAxis) numberAxis9, polarItemRenderer10);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
        java.lang.String str14 = numberTickUnit13.toString();
        polarPlot11.setAngleTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit13);
        int int16 = polarPlot11.getBackgroundImageAlignment();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "[size=0]" + "'", str14.equals("[size=0]"));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("");
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor1 = org.jfree.data.time.TimePeriodAnchor.END;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint4 = categoryAxis3D3.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D3, jFreeChart5, (int) (short) 1, (int) (short) 10);
        boolean boolean9 = timePeriodAnchor1.equals((java.lang.Object) (short) 10);
        timeSeriesCollection0.setXPosition(timePeriodAnchor1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate11 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        boolean boolean12 = intervalXYDelegate11.isAutoWidth();
        intervalXYDelegate11.setIntervalPositionFactor((double) 0L);
        double double15 = intervalXYDelegate11.getIntervalWidth();
        try {
            java.lang.Number number18 = intervalXYDelegate11.getStartX(6, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodAnchor1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot1.rendererChanged(rendererChangeEvent4);
        boolean boolean6 = combinedDomainXYPlot1.canSelectByRegion();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint6 = xYAreaRenderer5.getBaseLegendTextPaint();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator7 = null;
        xYAreaRenderer5.setBaseItemLabelGenerator(xYItemLabelGenerator7, true);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot11 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis10);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.data.Range range13 = combinedDomainXYPlot11.getDataRange(valueAxis12);
        java.lang.Object obj14 = null;
        boolean boolean15 = combinedDomainXYPlot11.equals(obj14);
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        combinedDomainXYPlot11.setRangeGridlineStroke(stroke16);
        xYAreaRenderer5.setBaseOutlineStroke(stroke16);
        java.awt.Font font22 = xYAreaRenderer5.getItemLabelFont((int) (short) 100, 12, false);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.block.LabelBlock labelBlock24 = new org.jfree.chart.block.LabelBlock("35", font22, (java.awt.Paint) color23);
        java.lang.String str25 = labelBlock24.getToolTipText();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor26 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.jfree.chart.block.CenterArrangement centerArrangement27 = new org.jfree.chart.block.CenterArrangement();
        boolean boolean28 = textBlockAnchor26.equals((java.lang.Object) centerArrangement27);
        labelBlock24.setContentAlignmentPoint(textBlockAnchor26);
        textBlock0.draw(graphics2D1, (float) (byte) -1, 0.0f, textBlockAnchor26);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(textBlockAnchor26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        xYAreaRenderer0.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition2);
        boolean boolean4 = xYAreaRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D5.centerRange((-1.0d));
        java.awt.Paint paint8 = numberAxis3D5.getTickLabelPaint();
        xYAreaRenderer0.setBaseFillPaint(paint8, true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer11 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean12 = xYAreaRenderer11.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator13 = null;
        xYAreaRenderer11.setLegendItemToolTipGenerator(xYSeriesLabelGenerator13);
        boolean boolean15 = xYAreaRenderer11.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator17 = null;
        xYAreaRenderer11.setSeriesToolTipGenerator((int) (short) 100, xYToolTipGenerator17);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = xYAreaRenderer11.getNegativeItemLabelPosition(100, (int) (byte) -1, false);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor23 = itemLabelPosition22.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor24 = itemLabelPosition22.getTextAnchor();
        xYAreaRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition22, false);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator27 = null;
        xYAreaRenderer0.setBaseItemLabelGenerator(xYItemLabelGenerator27);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(itemLabelAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        java.awt.Shape shape2 = xYAreaRenderer0.getBaseShape();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(0.0d, (double) (-1L));
        org.jfree.chart.util.Size2D size2D9 = legendGraphic4.arrange(graphics2D5, rectangleConstraint8);
        size2D9.setHeight((double) 1.0f);
        double double12 = size2D9.height;
        java.lang.Object obj13 = size2D9.clone();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean6 = xYAreaRenderer5.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator7 = null;
        xYAreaRenderer5.setLegendItemToolTipGenerator(xYSeriesLabelGenerator7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis3, valueAxis4, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer5);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        xYPlot9.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) numberAxis3D11);
        boolean boolean13 = numberAxis3D11.isTickMarksVisible();
        java.lang.String str14 = numberAxis3D11.getLabel();
        double[] doubleArray21 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray26 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray27 = new double[][] { doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray27);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot29 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.data.category.CategoryDataset categoryDataset30 = multiplePiePlot29.getDataset();
        org.jfree.data.Range range32 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset30, false);
        numberAxis3D11.setDefaultAutoRange(range32);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(categoryDataset30);
        org.junit.Assert.assertNotNull(range32);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        xYAreaRenderer0.setBaseSeriesVisible(false);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator4 = xYAreaRenderer0.getSeriesItemLabelGenerator((-9999));
        org.junit.Assert.assertNull(xYItemLabelGenerator4);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.plot.PieLabelLinkStyle pieLabelLinkStyle0 = org.jfree.chart.plot.PieLabelLinkStyle.STANDARD;
        org.junit.Assert.assertNotNull(pieLabelLinkStyle0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        java.awt.Paint paint1 = combinedRangeXYPlot0.getDomainZeroBaselinePaint();
        org.junit.Assert.assertNotNull(paint1);
    }

//    @Test
//    public void test098() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test098");
//        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
//        boolean boolean1 = xYAreaRenderer0.isOutline();
//        java.awt.Shape shape2 = xYAreaRenderer0.getBaseShape();
//        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
//        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
//        legendGraphic4.setWidth((double) 8);
//        java.lang.Object obj7 = legendGraphic4.clone();
//        java.util.TimeZone timeZone8 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
//        boolean boolean9 = legendGraphic4.equals((java.lang.Object) timeZone8);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertNotNull(shape2);
//        org.junit.Assert.assertNotNull(color3);
//        org.junit.Assert.assertNotNull(obj7);
//        org.junit.Assert.assertNull(timeZone8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeMinorGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer(10);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint6 = categoryAxis3D5.getLabelPaint();
        categoryAxis3D5.setTickMarkInsideLength((float) 0);
        categoryAxis3D5.addCategoryLabelToolTip((java.lang.Comparable) 1, "series");
        int int12 = categoryPlot0.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D5);
        double[] doubleArray19 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray24 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray25 = new double[][] { doubleArray19, doubleArray24 };
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray25);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot27 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset26);
        org.jfree.data.category.CategoryDataset categoryDataset28 = multiplePiePlot27.getDataset();
        boolean boolean29 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset28);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = categoryPlot0.getRendererForDataset(categoryDataset28);
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker((double) 0.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent33 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker32);
        org.jfree.chart.util.Layer layer34 = null;
        boolean boolean35 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker32, layer34);
        double double36 = categoryPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(categoryItemRenderer30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("index.html", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries4.clear();
        timeSeries4.setDescription("series");
        int int8 = timeSeriesCollection0.indexOf(timeSeries4);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day9, (java.lang.Number) 12, false);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries4.addPropertyChangeListener(propertyChangeListener13);
        java.lang.String str15 = timeSeries4.getRangeDescription();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "0" + "'", str15.equals("0"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint3 = categoryAxis3D2.getLabelPaint();
        categoryAxis3D2.setTickMarkInsideLength((float) 0);
        java.awt.Font font6 = categoryAxis3D2.getLabelFont();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.lang.Class<?> wildcardClass12 = stroke11.getClass();
        boolean boolean13 = verticalAlignment10.equals((java.lang.Object) stroke11);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double16 = rectangleInsets14.calculateTopInset(10.0d);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font6, (java.awt.Paint) color7, rectangleEdge8, horizontalAlignment9, verticalAlignment10, rectangleInsets14);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        textTitle17.setPaint((java.awt.Paint) color18);
        java.lang.String str20 = textTitle17.getToolTipText();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("35");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2, false, false);
        org.jfree.chart.axis.Timeline timeline6 = dateAxis1.getTimeline();
        java.text.DateFormat dateFormat7 = null;
        dateAxis1.setDateFormatOverride(dateFormat7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double11 = rectangleInsets9.trimWidth((double) 1560495599999L);
        dateAxis1.setLabelInsets(rectangleInsets9);
        org.junit.Assert.assertNotNull(timeline6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.560495599991E12d + "'", double11 == 1.560495599991E12d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        try {
            org.jfree.chart.axis.TickUnit tickUnit2 = tickUnits0.get(68);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 68, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        java.awt.Paint paint4 = combinedDomainXYPlot3.getBackgroundPaint();
        xYAreaRenderer0.setSeriesPaint(2, paint4);
        boolean boolean6 = xYAreaRenderer0.getAutoPopulateSeriesShape();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearAnnotations();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getRangeAxisLocation();
        categoryPlot0.setForegroundAlpha((float) 3);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(axisLocation4);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.NumberTick numberTick9 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (short) 10, "series", textAnchor6, textAnchor7, (double) (short) 10);
        org.jfree.chart.text.TextAnchor textAnchor10 = numberTick9.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor11 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.NumberTick numberTick13 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0.2d, "NO_CHANGE", textAnchor10, textAnchor11, (double) '4');
        org.jfree.chart.text.TextAnchor textAnchor14 = null;
        try {
            org.jfree.chart.axis.NumberTick numberTick16 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (byte) 10, "0", textAnchor11, textAnchor14, (double) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertNotNull(textAnchor11);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        double double2 = logAxis0.calculateLog((double) 6);
        logAxis0.configure();
        logAxis0.pan((double) (short) 100);
        logAxis0.pan(0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7781512503836435d + "'", double2 == 0.7781512503836435d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint2 = categoryAxis3D1.getLabelPaint();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D5 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        piePlot3D5.setSimpleLabelOffset(rectangleInsets6);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries12.clear();
        timeSeries12.setDescription("series");
        int int16 = timeSeriesCollection8.indexOf(timeSeries12);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection8, (org.jfree.chart.axis.ValueAxis) numberAxis17, polarItemRenderer18);
        org.jfree.chart.plot.PlotOrientation plotOrientation20 = polarPlot19.getOrientation();
        java.awt.Paint paint21 = polarPlot19.getRadiusGridlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean26 = xYAreaRenderer25.isOutline();
        java.awt.Shape shape27 = xYAreaRenderer25.getBaseShape();
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic29 = new org.jfree.chart.title.LegendGraphic(shape27, (java.awt.Paint) color28);
        legendGraphic29.setWidth((double) 8);
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint35 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D36 = legendGraphic29.arrange(graphics2D32, rectangleConstraint35);
        double double37 = legendGraphic29.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = legendGraphic29.getShapeLocation();
        java.awt.geom.Rectangle2D rectangle2D39 = legendGraphic29.getBounds();
        rectangleInsets24.trim(rectangle2D39);
        java.awt.Point point41 = polarPlot19.translateValueThetaRadiusToJava2D((double) (-1.0f), (double) (short) 100, rectangle2D39);
        java.awt.geom.Rectangle2D rectangle2D42 = rectangleInsets6.createInsetRectangle(rectangle2D39);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D45 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint46 = categoryAxis3D45.getLabelPaint();
        categoryAxis3D45.setTickMarkInsideLength((float) 0);
        java.awt.Font font49 = categoryAxis3D45.getLabelFont();
        java.awt.Color color50 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment52 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment53 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke54 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.lang.Class<?> wildcardClass55 = stroke54.getClass();
        boolean boolean56 = verticalAlignment53.equals((java.lang.Object) stroke54);
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double59 = rectangleInsets57.calculateTopInset(10.0d);
        org.jfree.chart.title.TextTitle textTitle60 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font49, (java.awt.Paint) color50, rectangleEdge51, horizontalAlignment52, verticalAlignment53, rectangleInsets57);
        org.jfree.chart.axis.AxisState axisState61 = new org.jfree.chart.axis.AxisState();
        categoryAxis3D1.drawTickMarks(graphics2D3, (double) (byte) 0, rectangle2D42, rectangleEdge51, axisState61);
        double double63 = axisState61.getCursor();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(size2D36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor38);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(point41);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(rectangleEdge51);
        org.junit.Assert.assertNotNull(horizontalAlignment52);
        org.junit.Assert.assertNotNull(verticalAlignment53);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(wildcardClass55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(rectangleInsets57);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = null;
        piePlot3D1.setLabelGenerator(pieSectionLabelGenerator2);
        piePlot3D1.setShadowXOffset(0.0d);
        piePlot3D1.setCircular(true);
        java.awt.Font font8 = piePlot3D1.getLabelFont();
        java.awt.Paint paint9 = null;
        org.jfree.chart.text.TextMeasurer textMeasurer11 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock12 = org.jfree.chart.text.TextUtilities.createTextBlock("-3,-3,3,3", font8, paint9, (float) 2454364L, textMeasurer11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        double[] doubleArray6 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray11 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray12 = new double[][] { doubleArray6, doubleArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        org.jfree.data.category.CategoryDataset categoryDataset15 = multiplePiePlot14.getDataset();
        java.lang.Number number16 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset15);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0.0d + "'", number16.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 2.0d + "'", number17.equals(2.0d));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor1 = org.jfree.data.time.TimePeriodAnchor.END;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint4 = categoryAxis3D3.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D3, jFreeChart5, (int) (short) 1, (int) (short) 10);
        boolean boolean9 = timePeriodAnchor1.equals((java.lang.Object) (short) 10);
        timeSeriesCollection0.setXPosition(timePeriodAnchor1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate11 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        try {
            java.lang.Number number14 = intervalXYDelegate11.getStartX(8, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodAnchor1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer1 = null;
        waferMapPlot0.setRenderer(waferMapRenderer1);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        boolean boolean2 = xYAreaRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYAreaRenderer0.setAutoPopulateSeriesPaint(true);
        xYAreaRenderer0.setUseFillPaint(false);
        java.text.DateFormat dateFormat10 = null;
        java.text.NumberFormat numberFormat11 = java.text.NumberFormat.getNumberInstance();
        java.lang.String str13 = numberFormat11.format(0.0d);
        java.math.RoundingMode roundingMode14 = numberFormat11.getRoundingMode();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator15 = new org.jfree.chart.labels.StandardXYToolTipGenerator("ClassContext", dateFormat10, numberFormat11);
        java.lang.Object obj16 = standardXYToolTipGenerator15.clone();
        java.text.NumberFormat numberFormat17 = standardXYToolTipGenerator15.getXFormat();
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator18 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer19 = new org.jfree.chart.renderer.xy.XYAreaRenderer(10, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator15, xYURLGenerator18);
        xYAreaRenderer0.setSeriesToolTipGenerator(6, (org.jfree.chart.labels.XYToolTipGenerator) standardXYToolTipGenerator15);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(numberFormat11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "0" + "'", str13.equals("0"));
        org.junit.Assert.assertTrue("'" + roundingMode14 + "' != '" + java.math.RoundingMode.HALF_EVEN + "'", roundingMode14.equals(java.math.RoundingMode.HALF_EVEN));
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(numberFormat17);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo1);
        java.lang.String str3 = projectInfo0.getLicenceText();
        java.lang.String str4 = projectInfo0.getLicenceName();
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str4);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (short) 10, "series", textAnchor2, textAnchor3, (double) (short) 10);
        org.jfree.chart.text.TextAnchor textAnchor6 = numberTick5.getRotationAnchor();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer7 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint8 = xYAreaRenderer7.getBaseLegendTextPaint();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator9 = null;
        xYAreaRenderer7.setBaseItemLabelGenerator(xYItemLabelGenerator9, true);
        java.awt.Shape shape12 = xYAreaRenderer7.getBaseShape();
        java.awt.Paint paint13 = xYAreaRenderer7.getBasePaint();
        boolean boolean14 = numberTick5.equals((java.lang.Object) xYAreaRenderer7);
        xYAreaRenderer7.setDefaultEntityRadius(0);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot3D0.setLabelGenerator(pieSectionLabelGenerator1);
        piePlot3D0.setShadowXOffset(0.0d);
        piePlot3D0.setIgnoreZeroValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot3D0.getSimpleLabelOffset();
        boolean boolean8 = piePlot3D0.getIgnoreZeroValues();
        java.text.NumberFormat numberFormat10 = java.text.NumberFormat.getNumberInstance();
        java.lang.String str12 = numberFormat10.format(0.0d);
        java.text.NumberFormat numberFormat13 = java.text.NumberFormat.getNumberInstance();
        java.lang.String str15 = numberFormat13.format((long) 1);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator16 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Combined Range XYPlot", numberFormat10, numberFormat13);
        org.jfree.data.general.PieDataset pieDataset17 = null;
        java.lang.String str19 = standardPieSectionLabelGenerator16.generateSectionLabel(pieDataset17, (java.lang.Comparable) 900000L);
        piePlot3D0.setLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator16);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(numberFormat10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "0" + "'", str12.equals("0"));
        org.junit.Assert.assertNotNull(numberFormat13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "1" + "'", str15.equals("1"));
        org.junit.Assert.assertNull(str19);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("TextBlockAnchor.CENTER");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection2 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection2, true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer7 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean8 = xYAreaRenderer7.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator9 = null;
        xYAreaRenderer7.setLegendItemToolTipGenerator(xYSeriesLabelGenerator9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection2, valueAxis5, valueAxis6, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer7);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D();
        xYPlot11.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) numberAxis3D13);
        boolean boolean15 = numberAxis3D13.isTickMarksVisible();
        java.awt.Font font16 = numberAxis3D13.getTickLabelFont();
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_GREEN;
        numberAxis3D13.setTickMarkPaint((java.awt.Paint) color17);
        standardChartTheme1.setLegendBackgroundPaint((java.awt.Paint) color17);
        boolean boolean20 = standardChartTheme1.isShadowVisible();
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        combinedDomainXYPlot1.setForegroundAlpha((float) (-1));
        combinedDomainXYPlot1.setOutlineVisible(false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 1, (double) 100.0f);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = null;
        piePlot3D6.setLabelGenerator(pieSectionLabelGenerator7);
        piePlot3D6.setShadowXOffset(0.0d);
        piePlot3D6.setIgnoreZeroValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = piePlot3D6.getSimpleLabelOffset();
        blockContainer5.setPadding(rectangleInsets13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint(0.0d, (double) (-1L));
        org.jfree.chart.util.Size2D size2D19 = blockContainer5.arrange(graphics2D15, rectangleConstraint18);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer20 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean21 = xYAreaRenderer20.isOutline();
        java.awt.Shape shape22 = xYAreaRenderer20.getBaseShape();
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic24 = new org.jfree.chart.title.LegendGraphic(shape22, (java.awt.Paint) color23);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = new org.jfree.chart.block.RectangleConstraint(0.0d, (double) (-1L));
        org.jfree.chart.util.Size2D size2D29 = legendGraphic24.arrange(graphics2D25, rectangleConstraint28);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D31 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint32 = categoryAxis3D31.getLabelPaint();
        categoryAxis3D31.setTickMarkInsideLength((float) 0);
        java.awt.Font font35 = categoryAxis3D31.getLabelFont();
        boolean boolean36 = legendGraphic24.equals((java.lang.Object) categoryAxis3D31);
        java.awt.Stroke stroke37 = legendGraphic24.getOutlineStroke();
        org.jfree.chart.block.BlockBorder blockBorder42 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) '4', (double) 10L, (double) 100L);
        java.awt.Paint paint43 = blockBorder42.getPaint();
        legendGraphic24.setFrame((org.jfree.chart.block.BlockFrame) blockBorder42);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection45 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries49.clear();
        timeSeries49.setDescription("series");
        int int53 = timeSeriesCollection45.indexOf(timeSeries49);
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer55 = null;
        org.jfree.chart.plot.PolarPlot polarPlot56 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection45, (org.jfree.chart.axis.ValueAxis) numberAxis54, polarItemRenderer55);
        org.jfree.chart.plot.PlotOrientation plotOrientation57 = polarPlot56.getOrientation();
        java.awt.Paint paint58 = polarPlot56.getRadiusGridlinePaint();
        blockContainer5.add((org.jfree.chart.block.Block) legendGraphic24, (java.lang.Object) polarPlot56);
        polarPlot56.zoom((double) 3600000L);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(size2D19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(size2D29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(stroke37);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation57);
        org.junit.Assert.assertNotNull(paint58);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.LegendItemCollection legendItemCollection2 = combinedDomainXYPlot1.getFixedLegendItems();
        org.jfree.chart.LegendItemCollection legendItemCollection3 = combinedDomainXYPlot1.getLegendItems();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = combinedDomainXYPlot1.getDomainMarkers(layer4);
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertNotNull(legendItemCollection3);
        org.junit.Assert.assertNull(collection5);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        java.text.DateFormat dateFormat1 = null;
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getNumberInstance();
        java.lang.String str4 = numberFormat2.format(0.0d);
        java.math.RoundingMode roundingMode5 = numberFormat2.getRoundingMode();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator6 = new org.jfree.chart.labels.StandardXYToolTipGenerator("ClassContext", dateFormat1, numberFormat2);
        java.lang.Object obj7 = standardXYToolTipGenerator6.clone();
        java.text.NumberFormat numberFormat8 = standardXYToolTipGenerator6.getXFormat();
        java.text.DateFormat dateFormat9 = standardXYToolTipGenerator6.getXDateFormat();
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + java.math.RoundingMode.HALF_EVEN + "'", roundingMode5.equals(java.math.RoundingMode.HALF_EVEN));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(numberFormat8);
        org.junit.Assert.assertNull(dateFormat9);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths(false);
        org.junit.Assert.assertNotNull(strArray1);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        java.awt.Shape shape2 = xYAreaRenderer0.getBaseShape();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(0.0d, (double) (-1L));
        org.jfree.chart.util.Size2D size2D9 = legendGraphic4.arrange(graphics2D5, rectangleConstraint8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = legendGraphic4.getPadding();
        boolean boolean11 = legendGraphic4.isLineVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        double double1 = crosshairState0.getAnchorX();
        crosshairState0.setCrosshairX((double) (-1));
        double double4 = crosshairState0.getCrosshairX();
        int int5 = crosshairState0.getDomainAxisIndex();
        crosshairState0.setAnchorY(1.0d);
        crosshairState0.updateCrosshairX((double) 86400000L, 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        java.util.List list3 = xYSeriesCollection0.getSeries();
        xYSeriesCollection0.validateObject();
        try {
            double double7 = xYSeriesCollection0.getYValue(10, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Locale locale1 = null;
        org.jfree.chart.axis.TickUnitSource tickUnitSource2 = org.jfree.chart.axis.LogAxis.createLogTickUnits(locale1);
        dateAxis0.setStandardTickUnits(tickUnitSource2);
        java.lang.Object obj4 = dateAxis0.clone();
        org.junit.Assert.assertNotNull(tickUnitSource2);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("-3,-3,3,3", "35", "item", "1");
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        combinedDomainXYPlot1.setForegroundAlpha((float) (-1));
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        combinedDomainXYPlot1.setDomainAxisLocation((int) (short) 1, axisLocation6);
        combinedDomainXYPlot1.setWeight(1);
        java.awt.Color color10 = java.awt.Color.darkGray;
        combinedDomainXYPlot1.setDomainCrosshairPaint((java.awt.Paint) color10);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = combinedDomainXYPlot1.getRangeMarkers(layer12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNull(collection13);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("RangeType.FULL");
        java.lang.String str2 = legendItem1.getURLText();
        java.lang.String str3 = legendItem1.getURLText();
        legendItem1.setShapeVisible(false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = legendItem1.getFillPaintTransformer();
        java.awt.Stroke stroke7 = legendItem1.getOutlineStroke();
        boolean boolean8 = legendItem1.isShapeOutlineVisible();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot3D0.setLabelGenerator(pieSectionLabelGenerator1);
        piePlot3D0.setShadowXOffset(0.0d);
        piePlot3D0.setIgnoreZeroValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot3D0.getSimpleLabelOffset();
        boolean boolean8 = piePlot3D0.getIgnoreZeroValues();
        java.lang.Object obj9 = piePlot3D0.clone();
        piePlot3D0.clearSectionOutlineStrokes(false);
        piePlot3D0.setSimpleLabels(false);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.centerRange((-1.0d));
        java.awt.Paint paint3 = numberAxis3D0.getTickLabelPaint();
        float float4 = numberAxis3D0.getTickMarkInsideLength();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D5.centerRange((-1.0d));
        java.awt.Paint paint8 = numberAxis3D5.getTickLabelPaint();
        org.jfree.data.Range range9 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double10 = range9.getLength();
        numberAxis3D5.setRangeWithMargins(range9, false, false);
        double double15 = range9.constrain(0.0d);
        numberAxis3D0.setRangeWithMargins(range9, true, false);
        org.jfree.data.Range range20 = org.jfree.data.Range.shift(range9, 5.0d);
        org.jfree.data.Range range22 = org.jfree.data.Range.scale(range9, (double) 0L);
        org.jfree.data.Range range25 = org.jfree.data.Range.shift(range9, 0.025d, true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertNotNull(range25);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean2 = range0.contains(0.0d);
        org.jfree.data.Range range5 = org.jfree.data.Range.expand(range0, (double) ' ', (double) 2.0f);
        org.jfree.data.Range range7 = org.jfree.data.Range.shift(range0, (double) (short) 0);
        org.jfree.data.Range range10 = org.jfree.data.Range.expand(range0, (double) 1099412556013L, 3.0d);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D11.centerRange((-1.0d));
        java.awt.Paint paint14 = numberAxis3D11.getTickLabelPaint();
        float float15 = numberAxis3D11.getTickMarkInsideLength();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D16 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D16.centerRange((-1.0d));
        java.awt.Paint paint19 = numberAxis3D16.getTickLabelPaint();
        org.jfree.data.Range range20 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double21 = range20.getLength();
        numberAxis3D16.setRangeWithMargins(range20, false, false);
        double double26 = range20.constrain(0.0d);
        numberAxis3D11.setRangeWithMargins(range20, true, false);
        org.jfree.data.Range range31 = org.jfree.data.Range.shift(range20, 5.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = new org.jfree.chart.block.RectangleConstraint(range10, range20);
        org.jfree.chart.util.Size2D size2D33 = null;
        try {
            org.jfree.chart.util.Size2D size2D34 = rectangleConstraint32.calculateConstrainedSize(size2D33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(range31);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        double double4 = barRenderer3D2.getXOffset();
        barRenderer3D2.setBase((double) (short) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke8 = categoryPlot7.getRangeMinorGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot7.getRenderer(10);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D12 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint13 = categoryAxis3D12.getLabelPaint();
        categoryAxis3D12.setTickMarkInsideLength((float) 0);
        categoryAxis3D12.addCategoryLabelToolTip((java.lang.Comparable) 1, "series");
        int int19 = categoryPlot7.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D12);
        double[] doubleArray26 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray31 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray32 = new double[][] { doubleArray26, doubleArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray32);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot34 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset33);
        org.jfree.data.category.CategoryDataset categoryDataset35 = multiplePiePlot34.getDataset();
        boolean boolean36 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset35);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = categoryPlot7.getRendererForDataset(categoryDataset35);
        barRenderer3D2.setPlot(categoryPlot7);
        java.lang.Comparable comparable39 = categoryPlot7.getDomainCrosshairColumnKey();
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.099412556013E12d + "'", double4 == 1.099412556013E12d);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(categoryItemRenderer37);
        org.junit.Assert.assertNull(comparable39);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        combinedDomainXYPlot1.select(generalPath3, rectangle2D4, renderingSource5);
        java.awt.Paint paint8 = combinedDomainXYPlot1.getQuadrantPaint((int) (short) 0);
        combinedDomainXYPlot1.clearAnnotations();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = combinedDomainXYPlot1.getDrawingSupplier();
        java.awt.geom.GeneralPath generalPath11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.RenderingSource renderingSource13 = null;
        combinedDomainXYPlot1.select(generalPath11, rectangle2D12, renderingSource13);
        double double15 = combinedDomainXYPlot1.getRangeCrosshairValue();
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = combinedDomainXYPlot1.getRangeMarkers(layer16);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNull(collection17);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) ' ');
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord3 = pieLabelDistributor1.getPieLabelRecord(15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        double double2 = combinedRangeXYPlot1.getGap();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint5 = xYAreaRenderer4.getBaseLegendTextPaint();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator6 = null;
        xYAreaRenderer4.setBaseItemLabelGenerator(xYItemLabelGenerator6, true);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis9);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.data.Range range12 = combinedDomainXYPlot10.getDataRange(valueAxis11);
        java.lang.Object obj13 = null;
        boolean boolean14 = combinedDomainXYPlot10.equals(obj13);
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        combinedDomainXYPlot10.setRangeGridlineStroke(stroke15);
        xYAreaRenderer4.setBaseOutlineStroke(stroke15);
        java.awt.Font font21 = xYAreaRenderer4.getItemLabelFont((int) (short) 100, 12, false);
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.block.LabelBlock labelBlock23 = new org.jfree.chart.block.LabelBlock("35", font21, (java.awt.Paint) color22);
        java.lang.String str24 = labelBlock23.getToolTipText();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        labelBlock23.setPaint((java.awt.Paint) color25);
        combinedRangeXYPlot1.setRangeTickBandPaint((java.awt.Paint) color25);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.0d + "'", double2 == 5.0d);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(color25);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) '4', 10.0d);
        java.lang.String str3 = intervalMarker2.getLabel();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint6 = categoryAxis3D5.getLabelPaint();
        categoryAxis3D5.setTickMarkInsideLength((float) 0);
        java.awt.Font font9 = categoryAxis3D5.getLabelFont();
        categoryAxis3D5.setCategoryMargin((double) 1L);
        java.awt.Paint paint12 = categoryAxis3D5.getLabelPaint();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer13 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYAreaRenderer13.setBaseOutlineStroke(stroke14);
        categoryAxis3D5.setAxisLineStroke(stroke14);
        intervalMarker2.setOutlineStroke(stroke14);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        org.jfree.chart.LegendItem legendItem6 = barRenderer3D2.getLegendItem((int) (byte) 1, 1);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        java.lang.String str11 = timeSeries10.getDomainDescription();
        java.lang.Class class12 = timeSeries10.getTimePeriodClass();
        boolean boolean13 = barRenderer3D2.equals((java.lang.Object) class12);
        barRenderer3D2.setBase(8.0d);
        java.awt.Paint paint16 = barRenderer3D2.getBaseOutlinePaint();
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNull(legendItem6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "series" + "'", str11.equals("series"));
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        java.util.Date date1 = null;
        try {
            long long2 = segmentedTimeline0.toTimelineValue(date1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        java.awt.Paint paint4 = combinedDomainXYPlot3.getBackgroundPaint();
        xYAreaRenderer0.setSeriesPaint(2, paint4);
        java.awt.Stroke stroke7 = null;
        xYAreaRenderer0.setSeriesStroke((int) '#', stroke7, true);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection10 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection10, true);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer15 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean16 = xYAreaRenderer15.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator17 = null;
        xYAreaRenderer15.setLegendItemToolTipGenerator(xYSeriesLabelGenerator17);
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection10, valueAxis13, valueAxis14, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer15);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
        xYPlot19.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) numberAxis3D21);
        xYAreaRenderer0.setPlot(xYPlot19);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("ClassContext", font1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D6 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint7 = categoryAxis3D6.getLabelPaint();
        categoryAxis3D6.setTickMarkInsideLength((float) 0);
        java.awt.Font font10 = categoryAxis3D6.getLabelFont();
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment14 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.lang.Class<?> wildcardClass16 = stroke15.getClass();
        boolean boolean17 = verticalAlignment14.equals((java.lang.Object) stroke15);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double20 = rectangleInsets18.calculateTopInset(10.0d);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font10, (java.awt.Paint) color11, rectangleEdge12, horizontalAlignment13, verticalAlignment14, rectangleInsets18);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D24 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint25 = categoryAxis3D24.getLabelPaint();
        categoryAxis3D24.setTickMarkInsideLength((float) 0);
        java.awt.Font font28 = categoryAxis3D24.getLabelFont();
        java.awt.Color color29 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment31 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment32 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.lang.Class<?> wildcardClass34 = stroke33.getClass();
        boolean boolean35 = verticalAlignment32.equals((java.lang.Object) stroke33);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double38 = rectangleInsets36.calculateTopInset(10.0d);
        org.jfree.chart.title.TextTitle textTitle39 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font28, (java.awt.Paint) color29, rectangleEdge30, horizontalAlignment31, verticalAlignment32, rectangleInsets36);
        textTitle21.setHorizontalAlignment(horizontalAlignment31);
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection42 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries46.clear();
        timeSeries46.setDescription("series");
        int int50 = timeSeriesCollection42.indexOf(timeSeries46);
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer52 = null;
        org.jfree.chart.plot.PolarPlot polarPlot53 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection42, (org.jfree.chart.axis.ValueAxis) numberAxis51, polarItemRenderer52);
        org.jfree.chart.plot.PlotOrientation plotOrientation54 = polarPlot53.getOrientation();
        java.awt.Paint paint55 = polarPlot53.getRadiusGridlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer59 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean60 = xYAreaRenderer59.isOutline();
        java.awt.Shape shape61 = xYAreaRenderer59.getBaseShape();
        java.awt.Color color62 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic63 = new org.jfree.chart.title.LegendGraphic(shape61, (java.awt.Paint) color62);
        legendGraphic63.setWidth((double) 8);
        java.awt.Graphics2D graphics2D66 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint69 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D70 = legendGraphic63.arrange(graphics2D66, rectangleConstraint69);
        double double71 = legendGraphic63.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor72 = legendGraphic63.getShapeLocation();
        java.awt.geom.Rectangle2D rectangle2D73 = legendGraphic63.getBounds();
        rectangleInsets58.trim(rectangle2D73);
        java.awt.Point point75 = polarPlot53.translateValueThetaRadiusToJava2D((double) (-1.0f), (double) (short) 100, rectangle2D73);
        java.lang.Object obj76 = null;
        java.lang.Object obj77 = textTitle21.draw(graphics2D41, rectangle2D73, obj76);
        try {
            labelBlock2.draw(graphics2D3, rectangle2D73);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
        org.junit.Assert.assertNotNull(verticalAlignment14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNotNull(horizontalAlignment31);
        org.junit.Assert.assertNotNull(verticalAlignment32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation54);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(shape61);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNotNull(size2D70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor72);
        org.junit.Assert.assertNotNull(rectangle2D73);
        org.junit.Assert.assertNotNull(point75);
        org.junit.Assert.assertNull(obj77);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        int int4 = combinedDomainXYPlot3.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot3.rendererChanged(rendererChangeEvent6);
        combinedDomainXYPlot1.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot3);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = combinedDomainXYPlot3.getDomainAxisEdge((int) (byte) 1);
        java.awt.Stroke stroke11 = combinedDomainXYPlot3.getRangeGridlineStroke();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray12 = null;
        try {
            combinedDomainXYPlot3.setRangeAxes(valueAxisArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.lang.Object obj1 = xYLineAndShapeRenderer0.clone();
        boolean boolean2 = xYLineAndShapeRenderer0.getBaseShapesVisible();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        xYSeriesCollection3.removeAllSeries();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = null;
        xYSeriesCollection3.seriesChanged(seriesChangeEvent5);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState7 = xYSeriesCollection3.getSelectionState();
        java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        xYSeriesCollection3.clearSelection();
        boolean boolean10 = xYLineAndShapeRenderer0.equals((java.lang.Object) xYSeriesCollection3);
        boolean boolean11 = xYLineAndShapeRenderer0.getUseFillPaint();
        java.awt.Paint paint13 = xYLineAndShapeRenderer0.getSeriesPaint((int) '#');
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState7);
        org.junit.Assert.assertEquals((double) number8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(paint13);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint2 = categoryAxis3D1.getLabelPaint();
        categoryAxis3D1.setTickMarkInsideLength((float) 0);
        java.awt.Font font5 = categoryAxis3D1.getLabelFont();
        categoryAxis3D1.setCategoryMargin((double) 1L);
        java.awt.Paint paint8 = categoryAxis3D1.getLabelPaint();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer9 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYAreaRenderer9.setBaseOutlineStroke(stroke10);
        categoryAxis3D1.setAxisLineStroke(stroke10);
        float float13 = categoryAxis3D1.getMinorTickMarkOutsideLength();
        java.lang.String str15 = categoryAxis3D1.getCategoryLabelToolTip((java.lang.Comparable) "java.awt.Color[r=0,g=192,b=192]");
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 2.0f + "'", float13 == 2.0f);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("RangeType.FULL");
        java.lang.String str2 = legendItem1.getURLText();
        java.lang.String str3 = legendItem1.getURLText();
        legendItem1.setShapeVisible(false);
        java.awt.Shape shape6 = legendItem1.getShape();
        java.lang.String str7 = legendItem1.getDescription();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(str7);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        java.util.List list2 = combinedRangeXYPlot1.getSubplots();
        java.util.List list3 = combinedRangeXYPlot1.getSubplots();
        combinedRangeXYPlot1.configureRangeAxes();
        combinedRangeXYPlot1.setRangeCrosshairValue((double) 1, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = combinedRangeXYPlot1.getOrientation();
        combinedRangeXYPlot1.clearDomainAxes();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer10 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean11 = xYAreaRenderer10.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator12 = null;
        xYAreaRenderer10.setLegendItemToolTipGenerator(xYSeriesLabelGenerator12);
        boolean boolean14 = xYAreaRenderer10.getAutoPopulateSeriesStroke();
        boolean boolean15 = combinedRangeXYPlot1.equals((java.lang.Object) xYAreaRenderer10);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = combinedRangeXYPlot1.getDomainAxisEdge(0);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("[8.0, 100.0]", "35");
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setUpperMargin((double) (short) 0);
        numberAxis3D0.resizeRange2((double) 10L, (double) 12);
        numberAxis3D0.setAutoTickUnitSelection(false);
        numberAxis3D0.centerRange(5.0d);
        org.jfree.chart.event.AxisChangeListener axisChangeListener10 = null;
        numberAxis3D0.addChangeListener(axisChangeListener10);
        org.jfree.chart.plot.PiePlot3D piePlot3D12 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection13 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection13, true);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer18 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean19 = xYAreaRenderer18.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator20 = null;
        xYAreaRenderer18.setLegendItemToolTipGenerator(xYSeriesLabelGenerator20);
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection13, valueAxis16, valueAxis17, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer18);
        boolean boolean23 = xYAreaRenderer18.isOutline();
        java.awt.Font font25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYAreaRenderer18.setSeriesItemLabelFont(100, font25);
        piePlot3D12.setLabelFont(font25);
        numberAxis3D0.setLabelFont(font25);
        org.jfree.chart.axis.TickUnitSource tickUnitSource29 = numberAxis3D0.getStandardTickUnits();
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(tickUnitSource29);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor1 = org.jfree.data.time.TimePeriodAnchor.END;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint4 = categoryAxis3D3.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D3, jFreeChart5, (int) (short) 1, (int) (short) 10);
        boolean boolean9 = timePeriodAnchor1.equals((java.lang.Object) (short) 10);
        timeSeriesCollection0.setXPosition(timePeriodAnchor1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate11 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = null;
        intervalXYDelegate11.datasetChanged(datasetChangeEvent12);
        double double15 = intervalXYDelegate11.getDomainUpperBound(true);
        org.junit.Assert.assertNotNull(timePeriodAnchor1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.ChartTheme chartTheme0 = org.jfree.chart.StandardChartTheme.createLegacyTheme();
        org.junit.Assert.assertNotNull(chartTheme0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setUpperMargin((double) (short) 0);
        numberAxis3D0.resizeRange2((double) 10L, (double) 12);
        numberAxis3D0.setAutoTickUnitSelection(false);
        numberAxis3D0.centerRange(5.0d);
        org.jfree.chart.event.AxisChangeListener axisChangeListener10 = null;
        numberAxis3D0.addChangeListener(axisChangeListener10);
        org.jfree.chart.plot.PiePlot3D piePlot3D12 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection13 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection13, true);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer18 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean19 = xYAreaRenderer18.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator20 = null;
        xYAreaRenderer18.setLegendItemToolTipGenerator(xYSeriesLabelGenerator20);
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection13, valueAxis16, valueAxis17, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer18);
        boolean boolean23 = xYAreaRenderer18.isOutline();
        java.awt.Font font25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYAreaRenderer18.setSeriesItemLabelFont(100, font25);
        piePlot3D12.setLabelFont(font25);
        numberAxis3D0.setLabelFont(font25);
        java.awt.Shape shape29 = numberAxis3D0.getRightArrow();
        numberAxis3D0.setLabelToolTip("");
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(shape29);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        double double4 = barRenderer3D2.getXOffset();
        barRenderer3D2.setBase((double) (short) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke8 = categoryPlot7.getRangeMinorGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot7.getRenderer(10);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D12 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint13 = categoryAxis3D12.getLabelPaint();
        categoryAxis3D12.setTickMarkInsideLength((float) 0);
        categoryAxis3D12.addCategoryLabelToolTip((java.lang.Comparable) 1, "series");
        int int19 = categoryPlot7.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D12);
        double[] doubleArray26 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray31 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray32 = new double[][] { doubleArray26, doubleArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray32);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot34 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset33);
        org.jfree.data.category.CategoryDataset categoryDataset35 = multiplePiePlot34.getDataset();
        boolean boolean36 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset35);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = categoryPlot7.getRendererForDataset(categoryDataset35);
        barRenderer3D2.setPlot(categoryPlot7);
        org.jfree.chart.axis.AxisSpace axisSpace39 = null;
        categoryPlot7.setFixedDomainAxisSpace(axisSpace39, false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.099412556013E12d + "'", double4 == 1.099412556013E12d);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(categoryItemRenderer37);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, false);
        int int5 = xYSeriesCollection0.getSeriesCount();
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D7.centerRange((-1.0d));
        java.awt.Paint paint10 = numberAxis3D7.getTickLabelPaint();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D11.setUpperMargin((double) (short) 0);
        numberAxis3D11.resizeRange2((double) 10L, (double) 12);
        numberAxis3D11.setAutoTickUnitSelection(false);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer19 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = null;
        xYAreaRenderer19.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition21);
        boolean boolean23 = xYAreaRenderer19.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D24.centerRange((-1.0d));
        java.awt.Paint paint27 = numberAxis3D24.getTickLabelPaint();
        xYAreaRenderer19.setBaseFillPaint(paint27, true);
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) numberAxis3D7, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer19);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D31.centerRange((-1.0d));
        java.awt.Paint paint34 = numberAxis3D31.getTickLabelPaint();
        float float35 = numberAxis3D31.getTickMarkInsideLength();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D36 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D36.centerRange((-1.0d));
        java.awt.Paint paint39 = numberAxis3D36.getTickLabelPaint();
        org.jfree.data.Range range40 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double41 = range40.getLength();
        numberAxis3D36.setRangeWithMargins(range40, false, false);
        double double46 = range40.constrain(0.0d);
        numberAxis3D31.setRangeWithMargins(range40, true, false);
        org.jfree.data.Range range51 = org.jfree.data.Range.shift(range40, 5.0d);
        numberAxis3D11.setRange(range51);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 0.0f + "'", float35 == 0.0f);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(range51);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = null;
        xYAreaRenderer0.setBaseItemLabelGenerator(xYItemLabelGenerator2, true);
        java.awt.Shape shape5 = xYAreaRenderer0.getBaseShape();
        xYAreaRenderer0.setBaseSeriesVisible(true, true);
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearAnnotations();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot0.getFixedRangeAxisSpace();
        categoryPlot0.setAnchorValue(Double.NaN);
        boolean boolean6 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.lang.String str1 = month0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "June 2019" + "'", str1.equals("June 2019"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        piePlot3D0.setSimpleLabelOffset(rectangleInsets1);
        piePlot3D0.setLabelLinksVisible(true);
        boolean boolean5 = piePlot3D0.getAutoPopulateSectionOutlineStroke();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor1 = org.jfree.data.time.TimePeriodAnchor.END;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint4 = categoryAxis3D3.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D3, jFreeChart5, (int) (short) 1, (int) (short) 10);
        boolean boolean9 = timePeriodAnchor1.equals((java.lang.Object) (short) 10);
        timeSeriesCollection0.setXPosition(timePeriodAnchor1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate11 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        java.util.List list12 = timeSeriesCollection0.getSeries();
        try {
            int[] intArray16 = org.jfree.chart.renderer.RendererUtilities.findLiveItems((org.jfree.data.xy.XYDataset) timeSeriesCollection0, 3, (double) (byte) 10, 5.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires xLow < xHigh.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodAnchor1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("RangeType.FULL");
        java.lang.String str2 = legendItem1.getURLText();
        java.lang.String str3 = legendItem1.getURLText();
        legendItem1.setShapeVisible(false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = legendItem1.getFillPaintTransformer();
        boolean boolean7 = legendItem1.isLineVisible();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 1, (double) 100.0f);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = null;
        piePlot3D6.setLabelGenerator(pieSectionLabelGenerator7);
        piePlot3D6.setShadowXOffset(0.0d);
        piePlot3D6.setIgnoreZeroValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = piePlot3D6.getSimpleLabelOffset();
        blockContainer5.setPadding(rectangleInsets13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint(0.0d, (double) (-1L));
        org.jfree.chart.util.Size2D size2D19 = blockContainer5.arrange(graphics2D15, rectangleConstraint18);
        double double20 = blockContainer5.getContentXOffset();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection22 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries26.clear();
        timeSeries26.setDescription("series");
        int int30 = timeSeriesCollection22.indexOf(timeSeries26);
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer32 = null;
        org.jfree.chart.plot.PolarPlot polarPlot33 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection22, (org.jfree.chart.axis.ValueAxis) numberAxis31, polarItemRenderer32);
        org.jfree.chart.plot.PlotOrientation plotOrientation34 = polarPlot33.getOrientation();
        java.awt.Paint paint35 = polarPlot33.getRadiusGridlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer39 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean40 = xYAreaRenderer39.isOutline();
        java.awt.Shape shape41 = xYAreaRenderer39.getBaseShape();
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic43 = new org.jfree.chart.title.LegendGraphic(shape41, (java.awt.Paint) color42);
        legendGraphic43.setWidth((double) 8);
        java.awt.Graphics2D graphics2D46 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint49 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D50 = legendGraphic43.arrange(graphics2D46, rectangleConstraint49);
        double double51 = legendGraphic43.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = legendGraphic43.getShapeLocation();
        java.awt.geom.Rectangle2D rectangle2D53 = legendGraphic43.getBounds();
        rectangleInsets38.trim(rectangle2D53);
        java.awt.Point point55 = polarPlot33.translateValueThetaRadiusToJava2D((double) (-1.0f), (double) (short) 100, rectangle2D53);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D58 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint59 = categoryAxis3D58.getLabelPaint();
        categoryAxis3D58.setTickMarkInsideLength((float) 0);
        java.awt.Font font62 = categoryAxis3D58.getLabelFont();
        java.awt.Color color63 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment65 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment66 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke67 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.lang.Class<?> wildcardClass68 = stroke67.getClass();
        boolean boolean69 = verticalAlignment66.equals((java.lang.Object) stroke67);
        org.jfree.chart.util.RectangleInsets rectangleInsets70 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double72 = rectangleInsets70.calculateTopInset(10.0d);
        org.jfree.chart.title.TextTitle textTitle73 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font62, (java.awt.Paint) color63, rectangleEdge64, horizontalAlignment65, verticalAlignment66, rectangleInsets70);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent74 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle73);
        try {
            java.lang.Object obj75 = blockContainer5.draw(graphics2D21, rectangle2D53, (java.lang.Object) titleChangeEvent74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(size2D19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.18d + "'", double20 == 0.18d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(size2D50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor52);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(point55);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(font62);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertNotNull(horizontalAlignment65);
        org.junit.Assert.assertNotNull(verticalAlignment66);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNotNull(wildcardClass68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(rectangleInsets70);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeMinorGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer(10);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint6 = categoryAxis3D5.getLabelPaint();
        categoryAxis3D5.setTickMarkInsideLength((float) 0);
        categoryAxis3D5.addCategoryLabelToolTip((java.lang.Comparable) 1, "series");
        int int12 = categoryPlot0.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D5);
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = null;
        org.jfree.chart.util.Layer layer15 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker14, layer15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries4.clear();
        timeSeries4.setDescription("series");
        int int8 = timeSeriesCollection0.indexOf(timeSeries4);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection0, (org.jfree.chart.axis.ValueAxis) numberAxis9, polarItemRenderer10);
        polarPlot11.setAngleLabelsVisible(false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint2 = categoryAxis3D1.getLabelPaint();
        categoryAxis3D1.setTickMarkInsideLength((float) 0);
        java.awt.Font font5 = categoryAxis3D1.getLabelFont();
        categoryAxis3D1.setCategoryMargin((double) 1L);
        double double8 = categoryAxis3D1.getFixedDimension();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("TextBlockAnchor.CENTER");
        double[] doubleArray8 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray13 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray14 = new double[][] { doubleArray8, doubleArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray14);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot16 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset15);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer17 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = null;
        xYAreaRenderer17.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition19);
        boolean boolean21 = xYAreaRenderer17.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D22 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D22.centerRange((-1.0d));
        java.awt.Paint paint25 = numberAxis3D22.getTickLabelPaint();
        xYAreaRenderer17.setBaseFillPaint(paint25, true);
        multiplePiePlot16.setOutlinePaint(paint25);
        standardChartTheme1.setWallPaint(paint25);
        java.awt.Paint paint30 = null;
        try {
            standardChartTheme1.setPlotOutlinePaint(paint30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator0 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator();
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MILLISECOND;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType2 = null;
        java.text.DateFormat dateFormat4 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) (short) -1, dateTickUnitType2, 8, dateFormat4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeMinorGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer(10);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint6 = categoryAxis3D5.getLabelPaint();
        categoryAxis3D5.setTickMarkInsideLength((float) 0);
        categoryAxis3D5.addCategoryLabelToolTip((java.lang.Comparable) 1, "series");
        int int12 = categoryPlot0.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D5);
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        try {
            categoryPlot0.handleClick((int) (byte) -1, 0, plotRenderingInfo16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        boolean boolean2 = xYAreaRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        boolean boolean5 = rendererChangeEvent4.getSeriesVisibilityChanged();
        xYAreaRenderer0.notifyListeners(rendererChangeEvent4);
        org.jfree.chart.LegendItem legendItem9 = xYAreaRenderer0.getLegendItem((int) (short) 100, 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(legendItem9);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator("item");
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("Polar Plot", font1, (java.awt.Paint) color2);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("TextBlockAnchor.CENTER");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection2 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection2, true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer7 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean8 = xYAreaRenderer7.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator9 = null;
        xYAreaRenderer7.setLegendItemToolTipGenerator(xYSeriesLabelGenerator9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection2, valueAxis5, valueAxis6, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer7);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D();
        xYPlot11.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) numberAxis3D13);
        boolean boolean15 = numberAxis3D13.isTickMarksVisible();
        java.awt.Font font16 = numberAxis3D13.getTickLabelFont();
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_GREEN;
        numberAxis3D13.setTickMarkPaint((java.awt.Paint) color17);
        standardChartTheme1.setLegendBackgroundPaint((java.awt.Paint) color17);
        java.awt.Paint paint20 = standardChartTheme1.getTitlePaint();
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot22 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis21);
        int int23 = combinedDomainXYPlot22.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        combinedDomainXYPlot22.select(generalPath24, rectangle2D25, renderingSource26);
        java.awt.Paint paint29 = combinedDomainXYPlot22.getQuadrantPaint((int) (short) 0);
        combinedDomainXYPlot22.setBackgroundAlpha(0.0f);
        java.awt.Paint paint32 = combinedDomainXYPlot22.getRangeGridlinePaint();
        standardChartTheme1.setPlotBackgroundPaint(paint32);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D34.centerRange((-1.0d));
        java.awt.Paint paint37 = numberAxis3D34.getTickLabelPaint();
        float float38 = numberAxis3D34.getTickMarkInsideLength();
        org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker((double) 0.0f);
        java.lang.Object obj41 = valueMarker40.clone();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer42 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean43 = xYAreaRenderer42.isOutline();
        java.awt.Shape shape44 = xYAreaRenderer42.getBaseShape();
        java.awt.Color color45 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        xYAreaRenderer42.setBaseItemLabelPaint((java.awt.Paint) color45, false);
        valueMarker40.setLabelPaint((java.awt.Paint) color45);
        numberAxis3D34.setTickLabelPaint((java.awt.Paint) color45);
        standardChartTheme1.setPlotOutlinePaint((java.awt.Paint) color45);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 15 + "'", int23 == 15);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + float38 + "' != '" + 0.0f + "'", float38 == 0.0f);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertNotNull(color45);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries3.clear();
        timeSeries3.setDescription("series");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries11.clear();
        timeSeries11.setDescription("series");
        int int15 = timeSeriesCollection7.indexOf(timeSeries11);
        java.lang.String str16 = timeSeries11.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.addAndOrUpdate(timeSeries11);
        org.jfree.data.xy.XYDataItem xYDataItem20 = new org.jfree.data.xy.XYDataItem((double) 8, 100.0d);
        timeSeries17.setKey((java.lang.Comparable) 8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
        org.junit.Assert.assertNotNull(timeSeries17);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) month0, false);
        xYSeries3.add((double) 10.0f, (java.lang.Number) 0.5d);
        xYSeries3.setMaximumItemCount((int) '#');
        org.jfree.data.xy.XYDataItem xYDataItem11 = new org.jfree.data.xy.XYDataItem((double) 8, 100.0d);
        java.lang.Number number12 = xYDataItem11.getY();
        xYSeries3.add(xYDataItem11);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 100.0d + "'", number12.equals(100.0d));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(2147483647, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) month0, false);
        xYSeries3.add((double) 10.0f, (java.lang.Number) 0.5d);
        xYSeries3.setMaximumItemCount((int) '#');
        org.jfree.data.xy.XYDataItem xYDataItem11 = new org.jfree.data.xy.XYDataItem((double) 8, 100.0d);
        double double12 = xYDataItem11.getYValue();
        java.lang.String str13 = xYDataItem11.toString();
        xYSeries3.add(xYDataItem11);
        try {
            xYSeries3.setMaximumItemCount((-9999));
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: toIndex = 10001");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "[8.0, 100.0]" + "'", str13.equals("[8.0, 100.0]"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection1, true);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean7 = xYAreaRenderer6.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator8 = null;
        xYAreaRenderer6.setLegendItemToolTipGenerator(xYSeriesLabelGenerator8);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection1, valueAxis4, valueAxis5, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer6);
        boolean boolean11 = xYAreaRenderer6.isOutline();
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYAreaRenderer6.setSeriesItemLabelFont(100, font13);
        piePlot3D0.setLabelFont(font13);
        double double16 = piePlot3D0.getMaximumExplodePercent();
        piePlot3D0.setLabelLinksVisible(true);
        piePlot3D0.clearSectionOutlinePaints(true);
        double double21 = piePlot3D0.getMaximumExplodePercent();
        java.awt.Font font25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock26 = new org.jfree.chart.block.LabelBlock("ClassContext", font25);
        java.awt.Paint paint27 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        org.jfree.chart.text.TextFragment textFragment29 = new org.jfree.chart.text.TextFragment("java.awt.Color[r=255,g=128,b=128]", font25, paint27, (float) 43629L);
        org.jfree.chart.text.TextFragment textFragment30 = new org.jfree.chart.text.TextFragment("java.awt.Color[r=0,g=192,b=192]", font25);
        java.lang.String str31 = textFragment30.getText();
        boolean boolean32 = piePlot3D0.equals((java.lang.Object) str31);
        org.jfree.data.general.DatasetGroup datasetGroup33 = piePlot3D0.getDatasetGroup();
        piePlot3D0.setAutoPopulateSectionOutlineStroke(false);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "java.awt.Color[r=0,g=192,b=192]" + "'", str31.equals("java.awt.Color[r=0,g=192,b=192]"));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(datasetGroup33);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator2 = null;
        xYAreaRenderer0.setLegendItemToolTipGenerator(xYSeriesLabelGenerator2);
        boolean boolean4 = xYAreaRenderer0.getAutoPopulateSeriesStroke();
        xYAreaRenderer0.setBaseSeriesVisibleInLegend(true, true);
        xYAreaRenderer0.setSeriesItemLabelsVisible(8, (java.lang.Boolean) false);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator12 = xYAreaRenderer0.getSeriesItemLabelGenerator((int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(xYItemLabelGenerator12);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        org.jfree.data.xy.XYDataItem xYDataItem5 = new org.jfree.data.xy.XYDataItem((double) 8, 100.0d);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 100.0d, true);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis8);
        int int10 = combinedDomainXYPlot9.getBackgroundImageAlignment();
        combinedDomainXYPlot9.setForegroundAlpha((float) (-1));
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot14 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis13);
        int int15 = combinedDomainXYPlot14.getBackgroundImageAlignment();
        combinedDomainXYPlot14.setForegroundAlpha((float) (-1));
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        combinedDomainXYPlot14.setDomainAxisLocation((int) (short) 1, axisLocation19);
        combinedDomainXYPlot9.setDomainAxisLocation(axisLocation19);
        categoryPlot0.setRangeAxisLocation(axisLocation19, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection25 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range27 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection25, true);
        org.jfree.data.Range range29 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection25, false);
        int int30 = xYSeriesCollection25.getSeriesCount();
        org.jfree.data.Range range31 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection25);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D32.centerRange((-1.0d));
        java.awt.Paint paint35 = numberAxis3D32.getTickLabelPaint();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D36 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D36.setUpperMargin((double) (short) 0);
        numberAxis3D36.resizeRange2((double) 10L, (double) 12);
        numberAxis3D36.setAutoTickUnitSelection(false);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer44 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition46 = null;
        xYAreaRenderer44.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition46);
        boolean boolean48 = xYAreaRenderer44.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D49 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D49.centerRange((-1.0d));
        java.awt.Paint paint52 = numberAxis3D49.getTickLabelPaint();
        xYAreaRenderer44.setBaseFillPaint(paint52, true);
        org.jfree.chart.plot.XYPlot xYPlot55 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection25, (org.jfree.chart.axis.ValueAxis) numberAxis3D32, (org.jfree.chart.axis.ValueAxis) numberAxis3D36, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer44);
        try {
            categoryPlot0.setRangeAxis((int) (byte) -1, (org.jfree.chart.axis.ValueAxis) numberAxis3D32, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNull(range27);
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNull(range31);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(paint52);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.util.LogFormat logFormat0 = new org.jfree.chart.util.LogFormat();
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getNumberInstance();
        java.lang.String str3 = numberFormat1.format(0.0d);
        java.math.RoundingMode roundingMode4 = numberFormat1.getRoundingMode();
        try {
            logFormat0.setRoundingMode(roundingMode4);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + java.math.RoundingMode.HALF_EVEN + "'", roundingMode4.equals(java.math.RoundingMode.HALF_EVEN));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        java.text.DateFormat dateFormat1 = null;
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getNumberInstance();
        java.lang.String str4 = numberFormat2.format(0.0d);
        java.math.RoundingMode roundingMode5 = numberFormat2.getRoundingMode();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator6 = new org.jfree.chart.labels.StandardXYToolTipGenerator("ClassContext", dateFormat1, numberFormat2);
        java.lang.Object obj7 = standardXYToolTipGenerator6.clone();
        java.text.NumberFormat numberFormat8 = standardXYToolTipGenerator6.getXFormat();
        java.math.RoundingMode roundingMode9 = numberFormat8.getRoundingMode();
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + java.math.RoundingMode.HALF_EVEN + "'", roundingMode5.equals(java.math.RoundingMode.HALF_EVEN));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(numberFormat8);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + java.math.RoundingMode.HALF_EVEN + "'", roundingMode9.equals(java.math.RoundingMode.HALF_EVEN));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setUpperMargin((double) (short) 0);
        numberAxis3D0.resizeRange2((double) 10L, (double) 12);
        numberAxis3D0.setAutoTickUnitSelection(false);
        java.lang.Object obj8 = numberAxis3D0.clone();
        boolean boolean9 = numberAxis3D0.isTickLabelsVisible();
        numberAxis3D0.setAutoRangeStickyZero(false);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D4.setUpperMargin((double) (short) 0);
        numberAxis3D4.resizeRange2((double) 10L, (double) 12);
        combinedDomainXYPlot1.setRangeAxis(8, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, true);
        numberAxis3D4.setMinorTickMarkInsideLength((float) (byte) 1);
        java.awt.Stroke stroke14 = numberAxis3D4.getAxisLineStroke();
        double double15 = numberAxis3D4.getUpperBound();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-98.0d) + "'", double15 == (-98.0d));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor1 = org.jfree.data.time.TimePeriodAnchor.END;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint4 = categoryAxis3D3.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D3, jFreeChart5, (int) (short) 1, (int) (short) 10);
        boolean boolean9 = timePeriodAnchor1.equals((java.lang.Object) (short) 10);
        timeSeriesCollection0.setXPosition(timePeriodAnchor1);
        org.jfree.data.DomainOrder domainOrder11 = timeSeriesCollection0.getDomainOrder();
        double double13 = timeSeriesCollection0.getDomainUpperBound(true);
        org.junit.Assert.assertNotNull(timePeriodAnchor1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(domainOrder11);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        xYAreaRenderer0.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition2);
        boolean boolean4 = xYAreaRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Paint paint6 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYAreaRenderer0.setSeriesItemLabelPaint((int) '#', paint6, false);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer10 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYAreaRenderer10.setBaseOutlineStroke(stroke11);
        xYAreaRenderer0.setSeriesStroke(6, stroke11);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        xYAreaRenderer0.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition2);
        boolean boolean4 = xYAreaRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D5.centerRange((-1.0d));
        java.awt.Paint paint8 = numberAxis3D5.getTickLabelPaint();
        xYAreaRenderer0.setBaseFillPaint(paint8, true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer11 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean12 = xYAreaRenderer11.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator13 = null;
        xYAreaRenderer11.setLegendItemToolTipGenerator(xYSeriesLabelGenerator13);
        boolean boolean15 = xYAreaRenderer11.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator17 = null;
        xYAreaRenderer11.setSeriesToolTipGenerator((int) (short) 100, xYToolTipGenerator17);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = xYAreaRenderer11.getNegativeItemLabelPosition(100, (int) (byte) -1, false);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor23 = itemLabelPosition22.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor24 = itemLabelPosition22.getTextAnchor();
        xYAreaRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition22, false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent28 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        boolean boolean29 = rendererChangeEvent28.getSeriesVisibilityChanged();
        xYAreaRenderer0.notifyListeners(rendererChangeEvent28);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer33 = null;
        java.util.Collection collection34 = categoryPlot32.getDomainMarkers(layer33);
        java.awt.Paint paint35 = categoryPlot32.getDomainCrosshairPaint();
        org.jfree.chart.StandardChartTheme standardChartTheme37 = new org.jfree.chart.StandardChartTheme("TextBlockAnchor.CENTER");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection38 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range40 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection38, true);
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer43 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean44 = xYAreaRenderer43.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator45 = null;
        xYAreaRenderer43.setLegendItemToolTipGenerator(xYSeriesLabelGenerator45);
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection38, valueAxis41, valueAxis42, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer43);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D49 = new org.jfree.chart.axis.NumberAxis3D();
        xYPlot47.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) numberAxis3D49);
        boolean boolean51 = numberAxis3D49.isTickMarksVisible();
        java.awt.Font font52 = numberAxis3D49.getTickLabelFont();
        java.awt.Color color53 = org.jfree.chart.ChartColor.DARK_GREEN;
        numberAxis3D49.setTickMarkPaint((java.awt.Paint) color53);
        standardChartTheme37.setLegendBackgroundPaint((java.awt.Paint) color53);
        java.awt.Paint paint56 = standardChartTheme37.getTitlePaint();
        org.jfree.chart.axis.ValueAxis valueAxis57 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot58 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis57);
        int int59 = combinedDomainXYPlot58.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath60 = null;
        java.awt.geom.Rectangle2D rectangle2D61 = null;
        org.jfree.chart.RenderingSource renderingSource62 = null;
        combinedDomainXYPlot58.select(generalPath60, rectangle2D61, renderingSource62);
        java.awt.Paint paint65 = combinedDomainXYPlot58.getQuadrantPaint((int) (short) 0);
        combinedDomainXYPlot58.setBackgroundAlpha(0.0f);
        java.awt.Paint paint68 = combinedDomainXYPlot58.getRangeGridlinePaint();
        standardChartTheme37.setPlotBackgroundPaint(paint68);
        categoryPlot32.setDomainGridlinePaint(paint68);
        try {
            xYAreaRenderer0.setLegendTextPaint(2147483647, paint68);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(itemLabelAnchor23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNull(range40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 15 + "'", int59 == 15);
        org.junit.Assert.assertNull(paint65);
        org.junit.Assert.assertNotNull(paint68);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        java.awt.Shape shape2 = xYAreaRenderer0.getBaseShape();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis5);
        int int7 = combinedDomainXYPlot6.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.RenderingSource renderingSource10 = null;
        combinedDomainXYPlot6.select(generalPath8, rectangle2D9, renderingSource10);
        java.awt.Paint paint13 = combinedDomainXYPlot6.getQuadrantPaint((int) (short) 0);
        boolean boolean14 = combinedDomainXYPlot6.canSelectByRegion();
        org.jfree.chart.entity.PlotEntity plotEntity16 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) combinedDomainXYPlot6, "");
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.ChartColor chartColor5 = new org.jfree.chart.ChartColor(1, 3, (int) (short) 100);
        org.jfree.chart.plot.IntervalMarker intervalMarker6 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (double) 68, (java.awt.Paint) chartColor5);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str8 = lengthAdjustmentType7.toString();
        intervalMarker6.setLabelOffsetType(lengthAdjustmentType7);
        org.junit.Assert.assertNotNull(lengthAdjustmentType7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "NO_CHANGE" + "'", str8.equals("NO_CHANGE"));
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo1);
        java.lang.String str3 = projectInfo1.getInfo();
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot3D0.setLabelGenerator(pieSectionLabelGenerator1);
        piePlot3D0.setShadowXOffset(0.0d);
        double double6 = piePlot3D0.getExplodePercent((java.lang.Comparable) 100L);
        double double7 = piePlot3D0.getMaximumExplodePercent();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType1 = standardGradientPaintTransformer0.getType();
        org.junit.Assert.assertNotNull(gradientPaintTransformType1);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("ClassContext", font1);
        labelBlock2.setURLText("RangeType.FULL");
        java.lang.String str5 = labelBlock2.getToolTipText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator2 = null;
        xYAreaRenderer0.setLegendItemToolTipGenerator(xYSeriesLabelGenerator2);
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYAreaRenderer0.setSeriesStroke(3, stroke5);
        boolean boolean10 = xYAreaRenderer0.isItemLabelVisible((int) (short) 1, (int) (byte) 100, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range12 = xYAreaRenderer0.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        xYAreaRenderer0.setBaseItemLabelsVisible(true);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator16 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("series");
        xYAreaRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator16);
        java.lang.Boolean boolean19 = xYAreaRenderer0.getSeriesItemLabelsVisible(2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNull(boolean19);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint2 = categoryAxis3D1.getLabelPaint();
        java.text.NumberFormat numberFormat4 = java.text.NumberFormat.getNumberInstance();
        java.lang.String str6 = numberFormat4.format(0.0d);
        java.lang.String str8 = numberFormat4.format((long) '#');
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = new org.jfree.chart.axis.NumberTickUnit((double) 86400000L, numberFormat4, 4);
        java.lang.String str11 = categoryAxis3D1.getCategoryLabelToolTip((java.lang.Comparable) 86400000L);
        float float12 = categoryAxis3D1.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "35" + "'", str8.equals("35"));
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.0f + "'", float12 == 0.0f);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        combinedDomainXYPlot1.select(generalPath3, rectangle2D4, renderingSource5);
        java.awt.Paint paint8 = combinedDomainXYPlot1.getQuadrantPaint((int) (short) 0);
        combinedDomainXYPlot1.clearAnnotations();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = combinedDomainXYPlot1.getDrawingSupplier();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot12 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis11);
        int int13 = combinedDomainXYPlot12.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.RenderingSource renderingSource16 = null;
        combinedDomainXYPlot12.select(generalPath14, rectangle2D15, renderingSource16);
        java.awt.Paint paint19 = combinedDomainXYPlot12.getQuadrantPaint((int) (short) 0);
        combinedDomainXYPlot12.setBackgroundAlpha(0.0f);
        org.jfree.chart.plot.Marker marker23 = null;
        org.jfree.chart.util.Layer layer24 = null;
        boolean boolean26 = combinedDomainXYPlot12.removeDomainMarker((-1), marker23, layer24, true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer28 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot31 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis30);
        java.awt.Paint paint32 = combinedDomainXYPlot31.getBackgroundPaint();
        xYAreaRenderer28.setSeriesPaint(2, paint32);
        xYAreaRenderer28.setAutoPopulateSeriesPaint(false);
        combinedDomainXYPlot12.setRenderer(0, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer28, true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator39 = xYAreaRenderer28.getSeriesItemLabelGenerator((int) (short) 10);
        combinedDomainXYPlot1.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer28);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot45 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis44);
        java.util.List list46 = combinedRangeXYPlot45.getSubplots();
        java.util.List list47 = combinedRangeXYPlot45.getSubplots();
        combinedRangeXYPlot45.clearRangeAxes();
        int int49 = combinedRangeXYPlot45.getRangeAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection53 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries57.clear();
        timeSeries57.setDescription("series");
        int int61 = timeSeriesCollection53.indexOf(timeSeries57);
        org.jfree.chart.axis.NumberAxis numberAxis62 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer63 = null;
        org.jfree.chart.plot.PolarPlot polarPlot64 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection53, (org.jfree.chart.axis.ValueAxis) numberAxis62, polarItemRenderer63);
        org.jfree.chart.plot.PlotOrientation plotOrientation65 = polarPlot64.getOrientation();
        java.awt.Paint paint66 = polarPlot64.getRadiusGridlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets69 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer70 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean71 = xYAreaRenderer70.isOutline();
        java.awt.Shape shape72 = xYAreaRenderer70.getBaseShape();
        java.awt.Color color73 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic74 = new org.jfree.chart.title.LegendGraphic(shape72, (java.awt.Paint) color73);
        legendGraphic74.setWidth((double) 8);
        java.awt.Graphics2D graphics2D77 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint80 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D81 = legendGraphic74.arrange(graphics2D77, rectangleConstraint80);
        double double82 = legendGraphic74.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor83 = legendGraphic74.getShapeLocation();
        java.awt.geom.Rectangle2D rectangle2D84 = legendGraphic74.getBounds();
        rectangleInsets69.trim(rectangle2D84);
        java.awt.Point point86 = polarPlot64.translateValueThetaRadiusToJava2D((double) (-1.0f), (double) (short) 100, rectangle2D84);
        combinedRangeXYPlot45.zoomRangeAxes(0.0d, (double) 1.0f, plotRenderingInfo52, (java.awt.geom.Point2D) point86);
        try {
            combinedDomainXYPlot1.zoomRangeAxes(5.0d, 100.0d, plotRenderingInfo43, (java.awt.geom.Point2D) point86);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNull(xYItemLabelGenerator39);
        org.junit.Assert.assertNotNull(list46);
        org.junit.Assert.assertNotNull(list47);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1) + "'", int61 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation65);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertNotNull(rectangleInsets69);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(shape72);
        org.junit.Assert.assertNotNull(color73);
        org.junit.Assert.assertNotNull(size2D81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor83);
        org.junit.Assert.assertNotNull(rectangle2D84);
        org.junit.Assert.assertNotNull(point86);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = categoryPlot3.getDomainMarkers(layer4);
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot3.getFixedDomainAxisSpace();
        barRenderer3D2.setPlot(categoryPlot3);
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = null;
        org.jfree.chart.util.Layer layer10 = null;
        try {
            categoryPlot3.addDomainMarker((int) (short) -1, categoryMarker9, layer10, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNull(axisSpace6);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        combinedDomainXYPlot1.setForegroundAlpha((float) (-1));
        java.awt.Stroke stroke5 = combinedDomainXYPlot1.getDomainMinorGridlineStroke();
        combinedDomainXYPlot1.setDomainMinorGridlinesVisible(false);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer8 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean9 = xYAreaRenderer8.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator10 = null;
        xYAreaRenderer8.setLegendItemToolTipGenerator(xYSeriesLabelGenerator10);
        java.awt.Paint paint13 = xYAreaRenderer8.getSeriesPaint(2);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator15 = xYAreaRenderer8.getSeriesItemLabelGenerator(10);
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer16 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean17 = xYLineAndShapeRenderer16.getBaseShapesVisible();
        xYLineAndShapeRenderer16.setBaseSeriesVisibleInLegend(true);
        xYLineAndShapeRenderer16.setDrawOutlines(false);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer22 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint23 = xYAreaRenderer22.getBaseLegendTextPaint();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator24 = null;
        xYAreaRenderer22.setBaseItemLabelGenerator(xYItemLabelGenerator24, true);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot28 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.data.Range range30 = combinedDomainXYPlot28.getDataRange(valueAxis29);
        java.lang.Object obj31 = null;
        boolean boolean32 = combinedDomainXYPlot28.equals(obj31);
        java.awt.Stroke stroke33 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        combinedDomainXYPlot28.setRangeGridlineStroke(stroke33);
        xYAreaRenderer22.setBaseOutlineStroke(stroke33);
        java.awt.Font font39 = xYAreaRenderer22.getItemLabelFont((int) (short) 100, 12, false);
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray40 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYAreaRenderer8, xYLineAndShapeRenderer16, xYAreaRenderer22 };
        combinedDomainXYPlot1.setRenderers(xYItemRendererArray40);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNull(xYItemLabelGenerator15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertNull(range30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(xYItemRendererArray40);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.axis.PeriodAxis periodAxis1 = new org.jfree.chart.axis.PeriodAxis("0");
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries4.clear();
        timeSeries4.setDescription("series");
        int int8 = timeSeriesCollection0.indexOf(timeSeries4);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection0, (org.jfree.chart.axis.ValueAxis) numberAxis9, polarItemRenderer10);
        polarPlot11.removeCornerTextItem("NO_CHANGE");
        polarPlot11.setAngleLabelsVisible(false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setUpperMargin((double) (short) 0);
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        numberAxis3D0.setTickLabelPaint((java.awt.Paint) color3);
        numberAxis3D0.setLowerMargin(0.0d);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Stroke stroke1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYAreaRenderer0.setBaseOutlineStroke(stroke1);
        java.lang.Object obj3 = xYAreaRenderer0.clone();
        java.awt.Shape shape7 = xYAreaRenderer0.getItemShape((int) (byte) 1, (int) (byte) 100, false);
        java.awt.Font font11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("ClassContext", font11);
        java.awt.Paint paint13 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("java.awt.Color[r=255,g=128,b=128]", font11, paint13, (float) 43629L);
        xYAreaRenderer0.setLegendTextFont(2, font11);
        java.awt.Paint paint18 = xYAreaRenderer0.lookupSeriesFillPaint((int) '#');
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis19);
        combinedDomainXYPlot20.setRangePannable(true);
        double double23 = combinedDomainXYPlot20.getGap();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer24 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean25 = xYAreaRenderer24.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator26 = null;
        xYAreaRenderer24.setLegendItemToolTipGenerator(xYSeriesLabelGenerator26);
        java.awt.Paint paint29 = xYAreaRenderer24.getSeriesPaint(2);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator31 = xYAreaRenderer24.getSeriesItemLabelGenerator(10);
        boolean boolean32 = xYAreaRenderer24.getBaseItemLabelsVisible();
        combinedDomainXYPlot20.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer24);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer35 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean36 = xYAreaRenderer35.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator37 = null;
        xYAreaRenderer35.setLegendItemToolTipGenerator(xYSeriesLabelGenerator37);
        boolean boolean39 = xYAreaRenderer35.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator41 = null;
        xYAreaRenderer35.setSeriesToolTipGenerator((int) (short) 100, xYToolTipGenerator41);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition46 = xYAreaRenderer35.getNegativeItemLabelPosition(100, (int) (byte) -1, false);
        xYAreaRenderer24.setSeriesNegativeItemLabelPosition(12, itemLabelPosition46);
        xYAreaRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition46);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 5.0d + "'", double23 == 5.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertNull(xYItemLabelGenerator31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition46);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint2 = xYAreaRenderer1.getBaseLegendTextPaint();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator3 = null;
        xYAreaRenderer1.setBaseItemLabelGenerator(xYItemLabelGenerator3, true);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.data.Range range9 = combinedDomainXYPlot7.getDataRange(valueAxis8);
        java.lang.Object obj10 = null;
        boolean boolean11 = combinedDomainXYPlot7.equals(obj10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        combinedDomainXYPlot7.setRangeGridlineStroke(stroke12);
        xYAreaRenderer1.setBaseOutlineStroke(stroke12);
        java.awt.Font font18 = xYAreaRenderer1.getItemLabelFont((int) (short) 100, 12, false);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.block.LabelBlock labelBlock20 = new org.jfree.chart.block.LabelBlock("35", font18, (java.awt.Paint) color19);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection21 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries25.clear();
        timeSeries25.setDescription("series");
        int int29 = timeSeriesCollection21.indexOf(timeSeries25);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer31 = null;
        org.jfree.chart.plot.PolarPlot polarPlot32 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection21, (org.jfree.chart.axis.ValueAxis) numberAxis30, polarItemRenderer31);
        org.jfree.chart.plot.PlotOrientation plotOrientation33 = polarPlot32.getOrientation();
        java.awt.Paint paint34 = polarPlot32.getRadiusGridlinePaint();
        labelBlock20.setPaint(paint34);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline36 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long39 = segmentedTimeline36.getExceptionSegmentCount((long) (short) 10, (long) 100);
        long long40 = segmentedTimeline36.getSegmentsGroupSize();
        long long41 = segmentedTimeline36.getSegmentsGroupSize();
        boolean boolean42 = labelBlock20.equals((java.lang.Object) segmentedTimeline36);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(segmentedTimeline36);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 0L + "'", long39 == 0L);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 86400000L + "'", long40 == 86400000L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 86400000L + "'", long41 == 86400000L);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection2 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection2, true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer7 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean8 = xYAreaRenderer7.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator9 = null;
        xYAreaRenderer7.setLegendItemToolTipGenerator(xYSeriesLabelGenerator9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection2, valueAxis5, valueAxis6, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer7);
        boolean boolean12 = xYAreaRenderer7.isOutline();
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYAreaRenderer7.setSeriesItemLabelFont(100, font14);
        piePlot3D1.setLabelFont(font14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer19 = null;
        org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("", font14, (java.awt.Paint) color17, (float) 100L, textMeasurer19);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment21 = textBlock20.getLineAlignment();
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(textBlock20);
        org.junit.Assert.assertNotNull(horizontalAlignment21);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean2 = xYAreaRenderer1.isOutline();
        java.awt.Shape shape3 = xYAreaRenderer1.getBaseShape();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape3, (java.awt.Paint) color4);
        legendGraphic5.setWidth((double) 8);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D12 = legendGraphic5.arrange(graphics2D8, rectangleConstraint11);
        double double13 = legendGraphic5.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = legendGraphic5.getShapeLocation();
        java.awt.geom.Rectangle2D rectangle2D15 = legendGraphic5.getBounds();
        rectangleInsets0.trim(rectangle2D15);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection17 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection17, true);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer22 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean23 = xYAreaRenderer22.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator24 = null;
        xYAreaRenderer22.setLegendItemToolTipGenerator(xYSeriesLabelGenerator24);
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection17, valueAxis20, valueAxis21, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer22);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D28 = new org.jfree.chart.axis.NumberAxis3D();
        xYPlot26.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) numberAxis3D28);
        boolean boolean30 = numberAxis3D28.isTickMarksVisible();
        java.awt.Font font31 = numberAxis3D28.getTickLabelFont();
        java.awt.Color color32 = org.jfree.chart.ChartColor.DARK_GREEN;
        numberAxis3D28.setTickMarkPaint((java.awt.Paint) color32);
        org.jfree.chart.entity.AxisEntity axisEntity36 = new org.jfree.chart.entity.AxisEntity((java.awt.Shape) rectangle2D15, (org.jfree.chart.axis.Axis) numberAxis3D28, "0", "{0}");
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(color32);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint3 = categoryAxis3D2.getLabelPaint();
        categoryAxis3D2.setTickMarkInsideLength((float) 0);
        java.awt.Font font6 = categoryAxis3D2.getLabelFont();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.lang.Class<?> wildcardClass12 = stroke11.getClass();
        boolean boolean13 = verticalAlignment10.equals((java.lang.Object) stroke11);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double16 = rectangleInsets14.calculateTopInset(10.0d);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font6, (java.awt.Paint) color7, rectangleEdge8, horizontalAlignment9, verticalAlignment10, rectangleInsets14);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent18 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle17);
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = textTitle17.getVerticalAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment20 = textTitle17.getHorizontalAlignment();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertNotNull(horizontalAlignment20);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries4.clear();
        timeSeries4.setDescription("series");
        int int8 = timeSeriesCollection0.indexOf(timeSeries4);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection0, (org.jfree.chart.axis.ValueAxis) numberAxis9, polarItemRenderer10);
        java.awt.Paint paint12 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        polarPlot11.setAngleGridlinePaint(paint12);
        polarPlot11.clearCornerTextItems();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(paint12);
    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test220");
//        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900;
//        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 15L + "'", long0 == 15L);
//    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator2 = null;
        xYAreaRenderer0.setLegendItemToolTipGenerator(xYSeriesLabelGenerator2);
        java.awt.Paint paint5 = xYAreaRenderer0.getSeriesPaint(2);
        java.awt.Stroke stroke7 = xYAreaRenderer0.getSeriesOutlineStroke((int) (byte) 1);
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator9 = xYAreaRenderer0.getSeriesURLGenerator((int) '#');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertNull(xYURLGenerator9);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        int int4 = combinedDomainXYPlot3.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot3.rendererChanged(rendererChangeEvent6);
        combinedDomainXYPlot1.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot3);
        combinedDomainXYPlot3.setDomainMinorGridlinesVisible(true);
        boolean boolean11 = combinedDomainXYPlot3.isRangeCrosshairLockedOnData();
        combinedDomainXYPlot3.setRangeCrosshairValue(0.0d);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection15 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries19.clear();
        timeSeries19.setDescription("series");
        int int23 = timeSeriesCollection15.indexOf(timeSeries19);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer25 = null;
        org.jfree.chart.plot.PolarPlot polarPlot26 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection15, (org.jfree.chart.axis.ValueAxis) numberAxis24, polarItemRenderer25);
        org.jfree.chart.plot.PlotOrientation plotOrientation27 = polarPlot26.getOrientation();
        java.awt.Paint paint28 = polarPlot26.getRadiusGridlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer32 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean33 = xYAreaRenderer32.isOutline();
        java.awt.Shape shape34 = xYAreaRenderer32.getBaseShape();
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic36 = new org.jfree.chart.title.LegendGraphic(shape34, (java.awt.Paint) color35);
        legendGraphic36.setWidth((double) 8);
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D43 = legendGraphic36.arrange(graphics2D39, rectangleConstraint42);
        double double44 = legendGraphic36.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = legendGraphic36.getShapeLocation();
        java.awt.geom.Rectangle2D rectangle2D46 = legendGraphic36.getBounds();
        rectangleInsets31.trim(rectangle2D46);
        java.awt.Point point48 = polarPlot26.translateValueThetaRadiusToJava2D((double) (-1.0f), (double) (short) 100, rectangle2D46);
        try {
            combinedDomainXYPlot3.drawBackground(graphics2D14, rectangle2D46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(size2D43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(point48);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator5 = null;
        piePlot3D4.setLabelGenerator(pieSectionLabelGenerator5);
        piePlot3D4.setShadowXOffset(0.0d);
        double double9 = piePlot3D4.getDepthFactor();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot11 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis10);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis12);
        int int14 = combinedDomainXYPlot13.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot13.rendererChanged(rendererChangeEvent16);
        combinedDomainXYPlot11.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot13);
        combinedDomainXYPlot13.setDomainMinorGridlinesVisible(true);
        boolean boolean21 = combinedDomainXYPlot13.isRangeCrosshairLockedOnData();
        java.awt.Paint paint22 = null;
        combinedDomainXYPlot13.setRangeTickBandPaint(paint22);
        java.awt.Paint paint24 = combinedDomainXYPlot13.getRangeCrosshairPaint();
        piePlot3D4.setBackgroundPaint(paint24);
        org.jfree.chart.block.BlockBorder blockBorder26 = new org.jfree.chart.block.BlockBorder((double) 1560495599999L, (double) 9223372036854775807L, (double) 8, (double) 0.0f, paint24);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.12d + "'", double9 == 0.12d);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isRangePannable();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot4 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis3);
        double double5 = combinedRangeXYPlot4.getGap();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis6);
        java.awt.Paint paint8 = combinedDomainXYPlot7.getBackgroundPaint();
        combinedRangeXYPlot4.addChangeListener((org.jfree.chart.event.PlotChangeListener) combinedDomainXYPlot7);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection10 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection10, true);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection10, false);
        int int15 = xYSeriesCollection10.getSeriesCount();
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection10);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D17.centerRange((-1.0d));
        java.awt.Paint paint20 = numberAxis3D17.getTickLabelPaint();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D21 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D21.setUpperMargin((double) (short) 0);
        numberAxis3D21.resizeRange2((double) 10L, (double) 12);
        numberAxis3D21.setAutoTickUnitSelection(false);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer29 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = null;
        xYAreaRenderer29.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition31);
        boolean boolean33 = xYAreaRenderer29.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D34.centerRange((-1.0d));
        java.awt.Paint paint37 = numberAxis3D34.getTickLabelPaint();
        xYAreaRenderer29.setBaseFillPaint(paint37, true);
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection10, (org.jfree.chart.axis.ValueAxis) numberAxis3D17, (org.jfree.chart.axis.ValueAxis) numberAxis3D21, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer29);
        combinedRangeXYPlot4.add(xYPlot40, (int) 'a');
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot45 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis44);
        int int46 = combinedDomainXYPlot45.getBackgroundImageAlignment();
        combinedDomainXYPlot45.setForegroundAlpha((float) (-1));
        org.jfree.chart.axis.AxisLocation axisLocation50 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        combinedDomainXYPlot45.setDomainAxisLocation((int) (short) 1, axisLocation50);
        xYPlot40.setDomainAxisLocation(0, axisLocation50, true);
        categoryPlot0.setDomainAxisLocation(2, axisLocation50);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 5.0d + "'", double5 == 5.0d);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 15 + "'", int46 == 15);
        org.junit.Assert.assertNotNull(axisLocation50);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries4.clear();
        timeSeries4.setDescription("series");
        int int8 = timeSeriesCollection0.indexOf(timeSeries4);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection0, (org.jfree.chart.axis.ValueAxis) numberAxis9, polarItemRenderer10);
        try {
            java.lang.Number number14 = timeSeriesCollection0.getY((int) (short) 1, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        double double2 = logAxis0.calculateLog((double) 6);
        logAxis0.configure();
        logAxis0.pan((double) (short) 100);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = new org.jfree.chart.axis.AxisState();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint10 = categoryAxis3D9.getLabelPaint();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D13 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        piePlot3D13.setSimpleLabelOffset(rectangleInsets14);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection16 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries20.clear();
        timeSeries20.setDescription("series");
        int int24 = timeSeriesCollection16.indexOf(timeSeries20);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer26 = null;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection16, (org.jfree.chart.axis.ValueAxis) numberAxis25, polarItemRenderer26);
        org.jfree.chart.plot.PlotOrientation plotOrientation28 = polarPlot27.getOrientation();
        java.awt.Paint paint29 = polarPlot27.getRadiusGridlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer33 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean34 = xYAreaRenderer33.isOutline();
        java.awt.Shape shape35 = xYAreaRenderer33.getBaseShape();
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic37 = new org.jfree.chart.title.LegendGraphic(shape35, (java.awt.Paint) color36);
        legendGraphic37.setWidth((double) 8);
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint43 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D44 = legendGraphic37.arrange(graphics2D40, rectangleConstraint43);
        double double45 = legendGraphic37.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor46 = legendGraphic37.getShapeLocation();
        java.awt.geom.Rectangle2D rectangle2D47 = legendGraphic37.getBounds();
        rectangleInsets32.trim(rectangle2D47);
        java.awt.Point point49 = polarPlot27.translateValueThetaRadiusToJava2D((double) (-1.0f), (double) (short) 100, rectangle2D47);
        java.awt.geom.Rectangle2D rectangle2D50 = rectangleInsets14.createInsetRectangle(rectangle2D47);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D53 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint54 = categoryAxis3D53.getLabelPaint();
        categoryAxis3D53.setTickMarkInsideLength((float) 0);
        java.awt.Font font57 = categoryAxis3D53.getLabelFont();
        java.awt.Color color58 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment60 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment61 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke62 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.lang.Class<?> wildcardClass63 = stroke62.getClass();
        boolean boolean64 = verticalAlignment61.equals((java.lang.Object) stroke62);
        org.jfree.chart.util.RectangleInsets rectangleInsets65 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double67 = rectangleInsets65.calculateTopInset(10.0d);
        org.jfree.chart.title.TextTitle textTitle68 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font57, (java.awt.Paint) color58, rectangleEdge59, horizontalAlignment60, verticalAlignment61, rectangleInsets65);
        org.jfree.chart.axis.AxisState axisState69 = new org.jfree.chart.axis.AxisState();
        categoryAxis3D9.drawTickMarks(graphics2D11, (double) (byte) 0, rectangle2D50, rectangleEdge59, axisState69);
        org.jfree.chart.axis.ValueAxis valueAxis71 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot72 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis71);
        int int73 = combinedDomainXYPlot72.getBackgroundImageAlignment();
        combinedDomainXYPlot72.setForegroundAlpha((float) (-1));
        int int76 = combinedDomainXYPlot72.getDomainAxisCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge78 = combinedDomainXYPlot72.getRangeAxisEdge(15);
        try {
            java.util.List list79 = logAxis0.refreshTicks(graphics2D6, axisState7, rectangle2D50, rectangleEdge78);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7781512503836435d + "'", double2 == 0.7781512503836435d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation28);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(size2D44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor46);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(point49);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(rectangleEdge59);
        org.junit.Assert.assertNotNull(horizontalAlignment60);
        org.junit.Assert.assertNotNull(verticalAlignment61);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(rectangleInsets65);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 15 + "'", int73 == 15);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1 + "'", int76 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge78);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer3D2.getBaseItemLabelGenerator();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D8 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint9 = categoryAxis3D8.getLabelPaint();
        categoryAxis3D8.setTickMarkInsideLength((float) 0);
        java.awt.Font font12 = categoryAxis3D8.getLabelFont();
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment15 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment16 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.lang.Class<?> wildcardClass18 = stroke17.getClass();
        boolean boolean19 = verticalAlignment16.equals((java.lang.Object) stroke17);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double22 = rectangleInsets20.calculateTopInset(10.0d);
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font12, (java.awt.Paint) color13, rectangleEdge14, horizontalAlignment15, verticalAlignment16, rectangleInsets20);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D26 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint27 = categoryAxis3D26.getLabelPaint();
        categoryAxis3D26.setTickMarkInsideLength((float) 0);
        java.awt.Font font30 = categoryAxis3D26.getLabelFont();
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment33 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment34 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.lang.Class<?> wildcardClass36 = stroke35.getClass();
        boolean boolean37 = verticalAlignment34.equals((java.lang.Object) stroke35);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double40 = rectangleInsets38.calculateTopInset(10.0d);
        org.jfree.chart.title.TextTitle textTitle41 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font30, (java.awt.Paint) color31, rectangleEdge32, horizontalAlignment33, verticalAlignment34, rectangleInsets38);
        textTitle23.setHorizontalAlignment(horizontalAlignment33);
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection44 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries48.clear();
        timeSeries48.setDescription("series");
        int int52 = timeSeriesCollection44.indexOf(timeSeries48);
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer54 = null;
        org.jfree.chart.plot.PolarPlot polarPlot55 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection44, (org.jfree.chart.axis.ValueAxis) numberAxis53, polarItemRenderer54);
        org.jfree.chart.plot.PlotOrientation plotOrientation56 = polarPlot55.getOrientation();
        java.awt.Paint paint57 = polarPlot55.getRadiusGridlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer61 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean62 = xYAreaRenderer61.isOutline();
        java.awt.Shape shape63 = xYAreaRenderer61.getBaseShape();
        java.awt.Color color64 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic65 = new org.jfree.chart.title.LegendGraphic(shape63, (java.awt.Paint) color64);
        legendGraphic65.setWidth((double) 8);
        java.awt.Graphics2D graphics2D68 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint71 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D72 = legendGraphic65.arrange(graphics2D68, rectangleConstraint71);
        double double73 = legendGraphic65.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor74 = legendGraphic65.getShapeLocation();
        java.awt.geom.Rectangle2D rectangle2D75 = legendGraphic65.getBounds();
        rectangleInsets60.trim(rectangle2D75);
        java.awt.Point point77 = polarPlot55.translateValueThetaRadiusToJava2D((double) (-1.0f), (double) (short) 100, rectangle2D75);
        java.lang.Object obj78 = null;
        java.lang.Object obj79 = textTitle23.draw(graphics2D43, rectangle2D75, obj78);
        org.jfree.chart.plot.CategoryPlot categoryPlot80 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer81 = null;
        java.util.Collection collection82 = categoryPlot80.getDomainMarkers(layer81);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray83 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot80.setDomainAxes(categoryAxisArray83);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo86 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState87 = barRenderer3D2.initialise(graphics2D5, rectangle2D75, categoryPlot80, (int) ' ', plotRenderingInfo86);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(horizontalAlignment15);
        org.junit.Assert.assertNotNull(verticalAlignment16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(horizontalAlignment33);
        org.junit.Assert.assertNotNull(verticalAlignment34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation56);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(shape63);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(size2D72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor74);
        org.junit.Assert.assertNotNull(rectangle2D75);
        org.junit.Assert.assertNotNull(point77);
        org.junit.Assert.assertNull(obj79);
        org.junit.Assert.assertNull(collection82);
        org.junit.Assert.assertNotNull(categoryAxisArray83);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("index.html", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        java.util.List list3 = xYSeriesCollection0.getSeries();
        double double5 = xYSeriesCollection0.getDomainUpperBound(false);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        double double9 = xYSeriesCollection0.getDomainLowerBound(true);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        try {
            java.lang.Object obj3 = jFreeChartResources0.getObject("-3,-3,3,3");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key -3,-3,3,3");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint2 = categoryAxis3D1.getLabelPaint();
        categoryAxis3D1.setTickMarkInsideLength((float) 0);
        java.awt.Font font5 = categoryAxis3D1.getLabelFont();
        categoryAxis3D1.setTickLabelsVisible(true);
        categoryAxis3D1.setTickLabelsVisible(true);
        double double10 = categoryAxis3D1.getCategoryMargin();
        categoryAxis3D1.setVisible(true);
        java.lang.Object obj13 = categoryAxis3D1.clone();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.2d + "'", double10 == 0.2d);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.lang.Object obj1 = xYLineAndShapeRenderer0.clone();
        boolean boolean2 = xYLineAndShapeRenderer0.getBaseShapesVisible();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        xYSeriesCollection3.removeAllSeries();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = null;
        xYSeriesCollection3.seriesChanged(seriesChangeEvent5);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState7 = xYSeriesCollection3.getSelectionState();
        java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        xYSeriesCollection3.clearSelection();
        boolean boolean10 = xYLineAndShapeRenderer0.equals((java.lang.Object) xYSeriesCollection3);
        java.lang.Boolean boolean12 = xYLineAndShapeRenderer0.getSeriesVisible(68);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState7);
        org.junit.Assert.assertEquals((double) number8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(boolean12);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        java.awt.Paint paint2 = combinedDomainXYPlot1.getBackgroundPaint();
        combinedDomainXYPlot1.setRangeMinorGridlinesVisible(false);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment(date2);
        java.util.Date date4 = segment3.getDate();
        boolean boolean7 = segment3.contains((long) '#', 86400000L);
        segment3.inc();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(segment3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(28);
        xYStepAreaRenderer1.setOutline(false);
        xYStepAreaRenderer1.setRangeBase((double) 15L);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0.0f);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer2 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean3 = xYAreaRenderer2.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer2.setLegendItemToolTipGenerator(xYSeriesLabelGenerator4);
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYAreaRenderer2.setSeriesStroke(3, stroke7);
        valueMarker1.setStroke(stroke7);
        java.lang.Object obj10 = valueMarker1.clone();
        java.lang.Class class11 = null;
        try {
            java.util.EventListener[] eventListenerArray12 = valueMarker1.getListeners(class11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("35");
        dateAxis1.zoomRange((double) (byte) 1, 3.0d);
        double[] doubleArray11 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray16 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray17 = new double[][] { doubleArray11, doubleArray16 };
        org.jfree.data.category.CategoryDataset categoryDataset18 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray17);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot19 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset18);
        org.jfree.data.category.CategoryDataset categoryDataset20 = multiplePiePlot19.getDataset();
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset20, false);
        dateAxis1.setRange(range22);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(categoryDataset18);
        org.junit.Assert.assertNotNull(categoryDataset20);
        org.junit.Assert.assertNotNull(range22);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 1, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(28);
        xYStepAreaRenderer1.setOutline(false);
        java.lang.Boolean boolean5 = xYStepAreaRenderer1.getSeriesVisible((int) (byte) 100);
        org.junit.Assert.assertNull(boolean5);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint3 = categoryAxis3D2.getLabelPaint();
        categoryAxis3D2.setTickMarkInsideLength((float) 0);
        java.awt.Font font6 = categoryAxis3D2.getLabelFont();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.lang.Class<?> wildcardClass12 = stroke11.getClass();
        boolean boolean13 = verticalAlignment10.equals((java.lang.Object) stroke11);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double16 = rectangleInsets14.calculateTopInset(10.0d);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font6, (java.awt.Paint) color7, rectangleEdge8, horizontalAlignment9, verticalAlignment10, rectangleInsets14);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent18 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle17);
        org.jfree.chart.title.Title title19 = titleChangeEvent18.getTitle();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(title19);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) '4', 10.0d);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer3 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        intervalMarker2.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer3);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray3 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray3);
        categoryPlot0.setWeight(2147483647);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomRangeAxes((double) 100.0f, plotRenderingInfo8, point2D9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        try {
            categoryPlot0.handleClick(100, 96, plotRenderingInfo13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(categoryAxisArray3);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (-1), (float) (-460));
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = null;
        piePlot3D3.setLabelGenerator(pieSectionLabelGenerator4);
        piePlot3D3.setShadowXOffset(0.0d);
        piePlot3D3.setIgnoreZeroValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = piePlot3D3.getSimpleLabelOffset();
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) piePlot3D3, "RangeType.FULL", "35");
        java.lang.String str14 = plotEntity13.toString();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PlotEntity: tooltip = RangeType.FULL" + "'", str14.equals("PlotEntity: tooltip = RangeType.FULL"));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint2 = categoryAxis3D1.getLabelPaint();
        java.text.NumberFormat numberFormat4 = java.text.NumberFormat.getNumberInstance();
        java.lang.String str6 = numberFormat4.format(0.0d);
        java.lang.String str8 = numberFormat4.format((long) '#');
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = new org.jfree.chart.axis.NumberTickUnit((double) 86400000L, numberFormat4, 4);
        org.jfree.chart.plot.PiePlot3D piePlot3D11 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection12 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection12, true);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer17 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean18 = xYAreaRenderer17.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator19 = null;
        xYAreaRenderer17.setLegendItemToolTipGenerator(xYSeriesLabelGenerator19);
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection12, valueAxis15, valueAxis16, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer17);
        boolean boolean22 = xYAreaRenderer17.isOutline();
        java.awt.Font font24 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYAreaRenderer17.setSeriesItemLabelFont(100, font24);
        piePlot3D11.setLabelFont(font24);
        categoryAxis3D1.setTickLabelFont((java.lang.Comparable) 86400000L, font24);
        categoryAxis3D1.clearCategoryLabelToolTips();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "0" + "'", str6.equals("0"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "35" + "'", str8.equals("35"));
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(font24);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot0 = new org.jfree.chart.plot.CombinedRangeXYPlot();
        combinedRangeXYPlot0.configureDomainAxes();
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
        double[] doubleArray10 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray15 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray16 = new double[][] { doubleArray10, doubleArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray16);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity20 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "", "item", categoryDataset17, (java.lang.Comparable) "item", (java.lang.Comparable) "0");
        java.lang.Comparable comparable21 = categoryItemEntity20.getColumnKey();
        java.lang.String str22 = categoryItemEntity20.getURLText();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + "0" + "'", comparable21.equals("0"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "item" + "'", str22.equals("item"));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Image image1 = null;
        projectInfo0.setLogo(image1);
        java.lang.String str3 = projectInfo0.getInfo();
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getPercentInstance();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) (short) 100, numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat1);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        combinedDomainXYPlot1.select(generalPath3, rectangle2D4, renderingSource5);
        java.awt.Paint paint8 = combinedDomainXYPlot1.getQuadrantPaint((int) (short) 0);
        combinedDomainXYPlot1.setBackgroundAlpha(0.0f);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = combinedDomainXYPlot1.getLegendItems();
        combinedDomainXYPlot1.setRangeGridlinesVisible(true);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(legendItemCollection11);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(28);
        xYStepAreaRenderer1.setShapesVisible(true);
        xYStepAreaRenderer1.setShapesFilled(true);
        java.lang.Object obj6 = xYStepAreaRenderer1.clone();
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        combinedDomainXYPlot1.select(generalPath3, rectangle2D4, renderingSource5);
        java.awt.Paint paint8 = combinedDomainXYPlot1.getQuadrantPaint((int) (short) 0);
        combinedDomainXYPlot1.clearAnnotations();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = combinedDomainXYPlot1.getDrawingSupplier();
        combinedDomainXYPlot1.setForegroundAlpha((float) 8);
        double[] doubleArray19 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray24 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray25 = new double[][] { doubleArray19, doubleArray24 };
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray25);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot27 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset26);
        java.lang.Number number28 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset26);
        org.jfree.data.general.PieDataset pieDataset30 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset26, 0);
        org.jfree.chart.plot.RingPlot ringPlot31 = new org.jfree.chart.plot.RingPlot(pieDataset30);
        java.awt.Stroke stroke32 = ringPlot31.getSeparatorStroke();
        combinedDomainXYPlot1.setDomainZeroBaselineStroke(stroke32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 1.0d + "'", number28.equals(1.0d));
        org.junit.Assert.assertNotNull(pieDataset30);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        double double4 = barRenderer3D2.getXOffset();
        barRenderer3D2.setAutoPopulateSeriesFillPaint(false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.099412556013E12d + "'", double4 == 1.099412556013E12d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.renderer.category.GradientBarPainter gradientBarPainter0 = new org.jfree.chart.renderer.category.GradientBarPainter();
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        long long3 = segmentedTimeline0.getTimeFromLong(3600000L);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection4 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor5 = org.jfree.data.time.TimePeriodAnchor.END;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D7 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint8 = categoryAxis3D7.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart9 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent12 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D7, jFreeChart9, (int) (short) 1, (int) (short) 10);
        boolean boolean13 = timePeriodAnchor5.equals((java.lang.Object) (short) 10);
        timeSeriesCollection4.setXPosition(timePeriodAnchor5);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate15 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection4);
        java.util.List list16 = timeSeriesCollection4.getSeries();
        segmentedTimeline0.addExceptions(list16);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3600000L + "'", long3 == 3600000L);
        org.junit.Assert.assertNotNull(timePeriodAnchor5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(list16);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        org.jfree.chart.LegendItem legendItem6 = barRenderer3D2.getLegendItem((int) (byte) 1, 1);
        barRenderer3D2.clearSeriesPaints(true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNull(legendItem6);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint3 = categoryAxis3D2.getLabelPaint();
        categoryAxis3D2.setTickMarkInsideLength((float) 0);
        java.awt.Font font6 = categoryAxis3D2.getLabelFont();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.lang.Class<?> wildcardClass12 = stroke11.getClass();
        boolean boolean13 = verticalAlignment10.equals((java.lang.Object) stroke11);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double16 = rectangleInsets14.calculateTopInset(10.0d);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font6, (java.awt.Paint) color7, rectangleEdge8, horizontalAlignment9, verticalAlignment10, rectangleInsets14);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent18 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle17);
        org.jfree.chart.util.VerticalAlignment verticalAlignment19 = textTitle17.getVerticalAlignment();
        org.jfree.chart.block.BlockFrame blockFrame20 = textTitle17.getFrame();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment19);
        org.junit.Assert.assertNotNull(blockFrame20);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearAnnotations();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot0, jFreeChart4);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = chartChangeEvent5.getType();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(chartChangeEventType6);
    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test260");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        int int1 = segmentedTimeline0.getSegmentsExcluded();
//        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment(date2);
//        java.util.TimeZone timeZone4 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
//        java.util.Locale locale5 = null;
//        try {
//            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month(date2, timeZone4, locale5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(segmentedTimeline0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(segment3);
//        org.junit.Assert.assertNull(timeZone4);
//    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean6 = xYAreaRenderer5.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator7 = null;
        xYAreaRenderer5.setLegendItemToolTipGenerator(xYSeriesLabelGenerator7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis3, valueAxis4, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer5);
        boolean boolean10 = xYAreaRenderer5.isOutline();
        java.awt.Font font12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYAreaRenderer5.setSeriesItemLabelFont(100, font12);
        org.jfree.chart.plot.XYPlot xYPlot14 = xYAreaRenderer5.getPlot();
        java.awt.Image image15 = xYPlot14.getBackgroundImage();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer16 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYAreaRenderer16.setBaseOutlineStroke(stroke17);
        xYPlot14.setDomainZeroBaselineStroke(stroke17);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(xYPlot14);
        org.junit.Assert.assertNull(image15);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray3 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray3);
        boolean boolean6 = categoryPlot0.equals((java.lang.Object) "hi!");
        boolean boolean7 = categoryPlot0.isNotify();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(categoryAxisArray3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor1 = org.jfree.data.time.TimePeriodAnchor.END;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint4 = categoryAxis3D3.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D3, jFreeChart5, (int) (short) 1, (int) (short) 10);
        boolean boolean9 = timePeriodAnchor1.equals((java.lang.Object) (short) 10);
        timeSeriesCollection0.setXPosition(timePeriodAnchor1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate11 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        java.util.List list12 = timeSeriesCollection0.getSeries();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries16.clear();
        timeSeries16.setDescription("series");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection20 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries24.clear();
        timeSeries24.setDescription("series");
        int int28 = timeSeriesCollection20.indexOf(timeSeries24);
        java.lang.String str29 = timeSeries24.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries16.addAndOrUpdate(timeSeries24);
        int int31 = timeSeriesCollection0.indexOf(timeSeries16);
        try {
            timeSeriesCollection0.setSelected(13, (int) '4', true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (13).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodAnchor1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries4.clear();
        timeSeries4.setDescription("series");
        int int8 = timeSeriesCollection0.indexOf(timeSeries4);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection0, (org.jfree.chart.axis.ValueAxis) numberAxis9, polarItemRenderer10);
        java.awt.Paint paint12 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        polarPlot11.setAngleGridlinePaint(paint12);
        java.awt.Paint paint14 = polarPlot11.getAngleLabelPaint();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint14);
    }

//    @Test
//    public void test266() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test266");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        int int1 = segmentedTimeline0.getSegmentsExcluded();
//        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment(date2);
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date2);
//        java.lang.String str6 = serialDate5.toString();
//        try {
//            org.jfree.data.time.SerialDate serialDate8 = serialDate5.getNearestDayOfWeek((-1));
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(segmentedTimeline0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(segment3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 1, (double) 100.0f);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = null;
        piePlot3D6.setLabelGenerator(pieSectionLabelGenerator7);
        piePlot3D6.setShadowXOffset(0.0d);
        piePlot3D6.setIgnoreZeroValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = piePlot3D6.getSimpleLabelOffset();
        blockContainer5.setPadding(rectangleInsets13);
        java.lang.String str15 = blockContainer5.getID();
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNull(str15);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        java.awt.Color color3 = java.awt.Color.getHSBColor(0.0f, (float) 86400000L, (float) 12);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment(date2);
        long long6 = segmentedTimeline0.getExceptionSegmentCount((long) '4', 60000L);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(segment3);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = null;
        piePlot3D1.setLabelGenerator(pieSectionLabelGenerator2);
        piePlot3D1.setShadowXOffset(0.0d);
        piePlot3D1.setCircular(true);
        java.awt.Font font8 = piePlot3D1.getLabelFont();
        piePlot3D1.clearSectionOutlinePaints(true);
        java.awt.Font font11 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        piePlot3D1.setLabelFont(font11);
        java.awt.Color color13 = java.awt.Color.darkGray;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("June 2019", font11, (java.awt.Paint) color13);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(textBlock14);
    }

//    @Test
//    public void test271() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test271");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        int int1 = segmentedTimeline0.getSegmentsExcluded();
//        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment(date2);
//        long long5 = segment3.calculateSegmentNumber((long) (short) 10);
//        segment3.inc();
//        long long7 = segment3.getSegmentNumber();
//        org.junit.Assert.assertNotNull(segmentedTimeline0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(segment3);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 2454364L + "'", long5 == 2454364L);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 4188206L + "'", long7 == 4188206L);
//    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        java.awt.Shape shape2 = xYAreaRenderer0.getBaseShape();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        legendGraphic4.setWidth((double) 8);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D11 = legendGraphic4.arrange(graphics2D7, rectangleConstraint10);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        legendGraphic4.setShapeLocation(rectangleAnchor12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(size2D11);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator3 = new org.jfree.chart.urls.StandardXYURLGenerator("", "hi!", "NO_CHANGE");
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        long long1 = dateRange0.getUpperMillis();
        java.util.Date date2 = dateRange0.getLowerDate();
        org.junit.Assert.assertNotNull(dateRange0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.lang.Object obj1 = xYLineAndShapeRenderer0.clone();
        boolean boolean2 = xYLineAndShapeRenderer0.getBaseShapesVisible();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        xYSeriesCollection3.removeAllSeries();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = null;
        xYSeriesCollection3.seriesChanged(seriesChangeEvent5);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState7 = xYSeriesCollection3.getSelectionState();
        java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        xYSeriesCollection3.clearSelection();
        boolean boolean10 = xYLineAndShapeRenderer0.equals((java.lang.Object) xYSeriesCollection3);
        boolean boolean13 = xYLineAndShapeRenderer0.getItemLineVisible(4, (int) '4');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = xYLineAndShapeRenderer0.getSeriesPositiveItemLabelPosition(12);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState7);
        org.junit.Assert.assertEquals((double) number8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        segmentedTimeline0.setBaseTimeline(segmentedTimeline1);
        int int3 = segmentedTimeline1.getGroupSegmentCount();
        java.util.Date date4 = null;
        try {
            segmentedTimeline1.addException(date4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 96 + "'", int3 == 96);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo1);
        java.lang.String str3 = projectInfo1.getVersion();
        org.junit.Assert.assertNotNull(projectInfo1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "1.2.0-pre" + "'", str3.equals("1.2.0-pre"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        org.jfree.chart.LegendItem legendItem6 = barRenderer3D2.getLegendItem((int) (byte) 1, 1);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        java.lang.String str11 = timeSeries10.getDomainDescription();
        java.lang.Class class12 = timeSeries10.getTimePeriodClass();
        boolean boolean13 = barRenderer3D2.equals((java.lang.Object) class12);
        barRenderer3D2.setBase(8.0d);
        org.jfree.chart.renderer.category.BarPainter barPainter16 = barRenderer3D2.getBarPainter();
        barRenderer3D2.setDrawBarOutline(false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNull(legendItem6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "series" + "'", str11.equals("series"));
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(barPainter16);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("RangeType.FULL");
        java.lang.String str2 = legendItem1.getURLText();
        java.lang.String str3 = legendItem1.getURLText();
        legendItem1.setShapeVisible(false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = legendItem1.getFillPaintTransformer();
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        piePlot3D7.setSimpleLabelOffset(rectangleInsets8);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries14.clear();
        timeSeries14.setDescription("series");
        int int18 = timeSeriesCollection10.indexOf(timeSeries14);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer20 = null;
        org.jfree.chart.plot.PolarPlot polarPlot21 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection10, (org.jfree.chart.axis.ValueAxis) numberAxis19, polarItemRenderer20);
        org.jfree.chart.plot.PlotOrientation plotOrientation22 = polarPlot21.getOrientation();
        java.awt.Paint paint23 = polarPlot21.getRadiusGridlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer27 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean28 = xYAreaRenderer27.isOutline();
        java.awt.Shape shape29 = xYAreaRenderer27.getBaseShape();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic31 = new org.jfree.chart.title.LegendGraphic(shape29, (java.awt.Paint) color30);
        legendGraphic31.setWidth((double) 8);
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint37 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D38 = legendGraphic31.arrange(graphics2D34, rectangleConstraint37);
        double double39 = legendGraphic31.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = legendGraphic31.getShapeLocation();
        java.awt.geom.Rectangle2D rectangle2D41 = legendGraphic31.getBounds();
        rectangleInsets26.trim(rectangle2D41);
        java.awt.Point point43 = polarPlot21.translateValueThetaRadiusToJava2D((double) (-1.0f), (double) (short) 100, rectangle2D41);
        java.awt.geom.Rectangle2D rectangle2D44 = rectangleInsets8.createInsetRectangle(rectangle2D41);
        legendItem1.setLine((java.awt.Shape) rectangle2D44);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(size2D38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor40);
        org.junit.Assert.assertNotNull(rectangle2D41);
        org.junit.Assert.assertNotNull(point43);
        org.junit.Assert.assertNotNull(rectangle2D44);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        xYAreaRenderer0.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition2);
        boolean boolean4 = xYAreaRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYAreaRenderer6.setBaseOutlineStroke(stroke7);
        java.lang.Object obj9 = xYAreaRenderer6.clone();
        java.awt.Shape shape13 = xYAreaRenderer6.getItemShape((int) (byte) 1, (int) (byte) 100, false);
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock18 = new org.jfree.chart.block.LabelBlock("ClassContext", font17);
        java.awt.Paint paint19 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        org.jfree.chart.text.TextFragment textFragment21 = new org.jfree.chart.text.TextFragment("java.awt.Color[r=255,g=128,b=128]", font17, paint19, (float) 43629L);
        xYAreaRenderer6.setLegendTextFont(2, font17);
        try {
            xYAreaRenderer0.setSeriesItemLabelFont((-1), font17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = logAxis0.getTickLabelInsets();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = logAxis0.getTickUnit();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(numberTickUnit2);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("TextBlockAnchor.CENTER");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection2 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection2, true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer7 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean8 = xYAreaRenderer7.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator9 = null;
        xYAreaRenderer7.setLegendItemToolTipGenerator(xYSeriesLabelGenerator9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection2, valueAxis5, valueAxis6, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer7);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D();
        xYPlot11.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) numberAxis3D13);
        boolean boolean15 = numberAxis3D13.isTickMarksVisible();
        java.awt.Font font16 = numberAxis3D13.getTickLabelFont();
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_GREEN;
        numberAxis3D13.setTickMarkPaint((java.awt.Paint) color17);
        standardChartTheme1.setLegendBackgroundPaint((java.awt.Paint) color17);
        java.awt.Paint paint20 = standardChartTheme1.getTitlePaint();
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot22 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis21);
        int int23 = combinedDomainXYPlot22.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        combinedDomainXYPlot22.select(generalPath24, rectangle2D25, renderingSource26);
        java.awt.Paint paint29 = combinedDomainXYPlot22.getQuadrantPaint((int) (short) 0);
        combinedDomainXYPlot22.setBackgroundAlpha(0.0f);
        java.awt.Paint paint32 = combinedDomainXYPlot22.getRangeGridlinePaint();
        standardChartTheme1.setPlotBackgroundPaint(paint32);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = standardChartTheme1.getAxisOffset();
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 15 + "'", int23 == 15);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(rectangleInsets34);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.lang.Object obj1 = xYLineAndShapeRenderer0.clone();
        boolean boolean2 = xYLineAndShapeRenderer0.getBaseShapesVisible();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        xYSeriesCollection3.removeAllSeries();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = null;
        xYSeriesCollection3.seriesChanged(seriesChangeEvent5);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState7 = xYSeriesCollection3.getSelectionState();
        java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        xYSeriesCollection3.clearSelection();
        boolean boolean10 = xYLineAndShapeRenderer0.equals((java.lang.Object) xYSeriesCollection3);
        java.lang.Number number11 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        try {
            int int15 = org.jfree.chart.renderer.RendererUtilities.findLiveItemsLowerBound((org.jfree.data.xy.XYDataset) xYSeriesCollection3, (-1), (double) ' ', (double) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState7);
        org.junit.Assert.assertEquals((double) number8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertEquals((double) number11, Double.NaN, 0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("RangeType.FULL");
        java.lang.String str3 = legendItem2.getURLText();
        java.lang.String str4 = legendItem2.getURLText();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis5);
        double double7 = combinedRangeXYPlot6.getGap();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis8);
        java.awt.Paint paint10 = combinedDomainXYPlot9.getBackgroundPaint();
        combinedRangeXYPlot6.addChangeListener((org.jfree.chart.event.PlotChangeListener) combinedDomainXYPlot9);
        boolean boolean12 = legendItem2.equals((java.lang.Object) combinedRangeXYPlot6);
        legendItemCollection0.add(legendItem2);
        boolean boolean14 = legendItem2.isShapeVisible();
        java.awt.Font font15 = null;
        legendItem2.setLabelFont(font15);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 5.0d + "'", double7 == 5.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries4.clear();
        timeSeries4.setDescription("series");
        int int8 = timeSeriesCollection0.indexOf(timeSeries4);
        long long9 = timeSeries4.getMaximumItemAge();
        try {
            timeSeries4.setMaximumItemCount((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'maximum' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        java.util.List list3 = xYSeriesCollection0.getSeries();
        double double5 = xYSeriesCollection0.getDomainUpperBound(false);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        double double8 = xYSeriesCollection0.getIntervalPositionFactor();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5d + "'", double8 == 0.5d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        double[] doubleArray6 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray11 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray12 = new double[][] { doubleArray6, doubleArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        java.lang.Number number15 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset13);
        org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset13, 0);
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot(pieDataset17);
        java.awt.Stroke stroke19 = ringPlot18.getSeparatorStroke();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D21 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        piePlot3D21.setSimpleLabelOffset(rectangleInsets22);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries28.clear();
        timeSeries28.setDescription("series");
        int int32 = timeSeriesCollection24.indexOf(timeSeries28);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer34 = null;
        org.jfree.chart.plot.PolarPlot polarPlot35 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection24, (org.jfree.chart.axis.ValueAxis) numberAxis33, polarItemRenderer34);
        org.jfree.chart.plot.PlotOrientation plotOrientation36 = polarPlot35.getOrientation();
        java.awt.Paint paint37 = polarPlot35.getRadiusGridlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer41 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean42 = xYAreaRenderer41.isOutline();
        java.awt.Shape shape43 = xYAreaRenderer41.getBaseShape();
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic45 = new org.jfree.chart.title.LegendGraphic(shape43, (java.awt.Paint) color44);
        legendGraphic45.setWidth((double) 8);
        java.awt.Graphics2D graphics2D48 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint51 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D52 = legendGraphic45.arrange(graphics2D48, rectangleConstraint51);
        double double53 = legendGraphic45.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor54 = legendGraphic45.getShapeLocation();
        java.awt.geom.Rectangle2D rectangle2D55 = legendGraphic45.getBounds();
        rectangleInsets40.trim(rectangle2D55);
        java.awt.Point point57 = polarPlot35.translateValueThetaRadiusToJava2D((double) (-1.0f), (double) (short) 100, rectangle2D55);
        java.awt.geom.Rectangle2D rectangle2D58 = rectangleInsets22.createInsetRectangle(rectangle2D55);
        org.jfree.chart.plot.PiePlot3D piePlot3D59 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator60 = null;
        piePlot3D59.setLabelGenerator(pieSectionLabelGenerator60);
        piePlot3D59.setShadowXOffset(0.0d);
        piePlot3D59.setIgnoreZeroValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets66 = piePlot3D59.getSimpleLabelOffset();
        boolean boolean67 = piePlot3D59.getAutoPopulateSectionPaint();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor68 = piePlot3D59.getLabelDistributor();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo70 = null;
        try {
            org.jfree.chart.plot.PiePlotState piePlotState71 = ringPlot18.initialise(graphics2D20, rectangle2D58, (org.jfree.chart.plot.PiePlot) piePlot3D59, (java.lang.Integer) 1, plotRenderingInfo70);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1.0d + "'", number15.equals(1.0d));
        org.junit.Assert.assertNotNull(pieDataset17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(size2D52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor54);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertNotNull(point57);
        org.junit.Assert.assertNotNull(rectangle2D58);
        org.junit.Assert.assertNotNull(rectangleInsets66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertNotNull(abstractPieLabelDistributor68);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setUpperMargin((double) (short) 0);
        numberAxis3D0.resizeRange2((double) 10L, (double) 12);
        numberAxis3D0.setAutoRangeMinimumSize(0.05d, false);
        boolean boolean9 = numberAxis3D0.getAutoRangeIncludesZero();
        numberAxis3D0.setAutoRange(false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker1);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean4 = xYAreaRenderer3.isOutline();
        java.awt.Shape shape5 = xYAreaRenderer3.getBaseShape();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic7 = new org.jfree.chart.title.LegendGraphic(shape5, (java.awt.Paint) color6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint(0.0d, (double) (-1L));
        org.jfree.chart.util.Size2D size2D12 = legendGraphic7.arrange(graphics2D8, rectangleConstraint11);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D14 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint15 = categoryAxis3D14.getLabelPaint();
        categoryAxis3D14.setTickMarkInsideLength((float) 0);
        java.awt.Font font18 = categoryAxis3D14.getLabelFont();
        boolean boolean19 = legendGraphic7.equals((java.lang.Object) categoryAxis3D14);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer20 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = null;
        xYAreaRenderer20.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition22);
        boolean boolean24 = xYAreaRenderer20.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Paint paint26 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYAreaRenderer20.setSeriesItemLabelPaint((int) '#', paint26, false);
        legendGraphic7.setOutlinePaint(paint26);
        valueMarker1.setPaint(paint26);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(paint26);
    }

//    @Test
//    public void test292() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test292");
//        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
//        java.awt.Paint paint2 = xYAreaRenderer1.getBaseLegendTextPaint();
//        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator3 = null;
//        xYAreaRenderer1.setBaseItemLabelGenerator(xYItemLabelGenerator3, true);
//        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis6);
//        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
//        org.jfree.data.Range range9 = combinedDomainXYPlot7.getDataRange(valueAxis8);
//        java.lang.Object obj10 = null;
//        boolean boolean11 = combinedDomainXYPlot7.equals(obj10);
//        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
//        combinedDomainXYPlot7.setRangeGridlineStroke(stroke12);
//        xYAreaRenderer1.setBaseOutlineStroke(stroke12);
//        java.awt.Font font18 = xYAreaRenderer1.getItemLabelFont((int) (short) 100, 12, false);
//        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
//        org.jfree.chart.block.LabelBlock labelBlock20 = new org.jfree.chart.block.LabelBlock("35", font18, (java.awt.Paint) color19);
//        java.lang.String str21 = labelBlock20.getToolTipText();
//        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
//        labelBlock20.setPaint((java.awt.Paint) color22);
//        java.awt.Graphics2D graphics2D24 = null;
//        java.awt.geom.Rectangle2D rectangle2D25 = null;
//        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection26 = new org.jfree.data.time.TimeSeriesCollection();
//        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
//        timeSeries30.clear();
//        timeSeries30.setDescription("series");
//        int int34 = timeSeriesCollection26.indexOf(timeSeries30);
//        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day();
//        timeSeries30.add((org.jfree.data.time.RegularTimePeriod) day35, (java.lang.Number) 12, false);
//        long long39 = day35.getLastMillisecond();
//        int int40 = day35.getDayOfMonth();
//        try {
//            java.lang.Object obj41 = labelBlock20.draw(graphics2D24, rectangle2D25, (java.lang.Object) day35);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(paint2);
//        org.junit.Assert.assertNull(range9);
//        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
//        org.junit.Assert.assertNotNull(stroke12);
//        org.junit.Assert.assertNotNull(font18);
//        org.junit.Assert.assertNotNull(color19);
//        org.junit.Assert.assertNull(str21);
//        org.junit.Assert.assertNotNull(color22);
//        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560495599999L + "'", long39 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 13 + "'", int40 == 13);
//    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("index.html");
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, false);
        int int5 = xYSeriesCollection0.getSeriesCount();
        try {
            java.lang.Number number8 = xYSeriesCollection0.getEndX(1, 28);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangePannable(true);
        combinedDomainXYPlot1.setRangePannable(true);
        org.jfree.chart.plot.PiePlot3D piePlot3D7 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection8 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection8, true);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer13 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean14 = xYAreaRenderer13.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator15 = null;
        xYAreaRenderer13.setLegendItemToolTipGenerator(xYSeriesLabelGenerator15);
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection8, valueAxis11, valueAxis12, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer13);
        boolean boolean18 = xYAreaRenderer13.isOutline();
        java.awt.Font font20 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYAreaRenderer13.setSeriesItemLabelFont(100, font20);
        piePlot3D7.setLabelFont(font20);
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer25 = null;
        org.jfree.chart.text.TextBlock textBlock26 = org.jfree.chart.text.TextUtilities.createTextBlock("", font20, (java.awt.Paint) color23, (float) 100L, textMeasurer25);
        combinedDomainXYPlot1.setBackgroundPaint((java.awt.Paint) color23);
        boolean boolean28 = combinedDomainXYPlot1.isRangeZeroBaselineVisible();
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(textBlock26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        xYAreaRenderer0.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition2);
        boolean boolean4 = xYAreaRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D5.centerRange((-1.0d));
        java.awt.Paint paint8 = numberAxis3D5.getTickLabelPaint();
        xYAreaRenderer0.setBaseFillPaint(paint8, true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor11 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double13 = range12.getLength();
        boolean boolean14 = itemLabelAnchor11.equals((java.lang.Object) double13);
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor11, textAnchor15);
        double double17 = itemLabelPosition16.getAngle();
        xYAreaRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition16, false);
        xYAreaRenderer0.setUseFillPaint(true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(itemLabelAnchor11);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        combinedDomainXYPlot1.setForegroundAlpha((float) (-1));
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        combinedDomainXYPlot1.setDomainAxisLocation((int) (short) 1, axisLocation6);
        combinedDomainXYPlot1.setWeight(1);
        java.awt.Paint paint10 = null;
        try {
            combinedDomainXYPlot1.setRangeZeroBaselinePaint(paint10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNotNull(axisLocation6);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) month0, false);
        xYSeries3.add((double) 10.0f, (java.lang.Number) 0.5d);
        xYSeries3.setMaximumItemCount((int) '#');
        xYSeries3.add((double) 0L, (java.lang.Number) 100);
        org.jfree.data.xy.XYDataItem xYDataItem14 = xYSeries3.addOrUpdate((java.lang.Number) 2.0d, (java.lang.Number) (-1));
        xYSeries3.setNotify(false);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNull(xYDataItem14);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint2 = categoryAxis3D1.getLabelPaint();
        categoryAxis3D1.setTickMarkInsideLength((float) 0);
        java.awt.Font font5 = categoryAxis3D1.getLabelFont();
        categoryAxis3D1.setTickLabelsVisible(true);
        categoryAxis3D1.setTickLabelsVisible(true);
        double double10 = categoryAxis3D1.getCategoryMargin();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions11 = categoryAxis3D1.getCategoryLabelPositions();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.2d + "'", double10 == 0.2d);
        org.junit.Assert.assertNotNull(categoryLabelPositions11);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray3 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray3);
        categoryPlot0.setWeight(2147483647);
        categoryPlot0.configureRangeAxes();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(categoryAxisArray3);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement5 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment1, verticalAlignment2, (double) (byte) 1, (double) 100.0f);
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement5);
        org.jfree.chart.block.BlockFrame blockFrame7 = blockContainer6.getFrame();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer8 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean9 = xYAreaRenderer8.isOutline();
        java.awt.Shape shape10 = xYAreaRenderer8.getBaseShape();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic12 = new org.jfree.chart.title.LegendGraphic(shape10, (java.awt.Paint) color11);
        legendGraphic12.setWidth((double) 8);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D19 = legendGraphic12.arrange(graphics2D15, rectangleConstraint18);
        double double20 = legendGraphic12.getHeight();
        boolean boolean21 = legendGraphic12.isShapeVisible();
        java.lang.Object obj22 = null;
        blockContainer6.add((org.jfree.chart.block.Block) legendGraphic12, obj22);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint24 = org.jfree.chart.block.RectangleConstraint.NONE;
        centerArrangement0.add((org.jfree.chart.block.Block) legendGraphic12, (java.lang.Object) rectangleConstraint24);
        org.junit.Assert.assertNotNull(blockFrame7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(size2D19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(rectangleConstraint24);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("PlotEntity: tooltip = RangeType.FULL", "Pie 3D Plot", "index.html", "-3,-3,3,3");
    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test303");
//        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
//        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection(timeZone0);
//        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection2 = new org.jfree.data.xy.XYSeriesCollection();
//        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection2, true);
//        java.util.List list5 = xYSeriesCollection2.getSeries();
//        org.jfree.data.Range range6 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
//        double double7 = range6.getCentralValue();
//        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection1, list5, range6, false);
//        org.junit.Assert.assertNull(timeZone0);
//        org.junit.Assert.assertNull(range4);
//        org.junit.Assert.assertNotNull(list5);
//        org.junit.Assert.assertNotNull(range6);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5d + "'", double7 == 0.5d);
//        org.junit.Assert.assertNull(range9);
//    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor1 = org.jfree.data.time.TimePeriodAnchor.END;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint4 = categoryAxis3D3.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D3, jFreeChart5, (int) (short) 1, (int) (short) 10);
        boolean boolean9 = timePeriodAnchor1.equals((java.lang.Object) (short) 10);
        timeSeriesCollection0.setXPosition(timePeriodAnchor1);
        try {
            java.lang.Number number13 = timeSeriesCollection0.getY((-460), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodAnchor1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = null;
        xYAreaRenderer0.setBaseItemLabelGenerator(xYItemLabelGenerator2, true);
        java.awt.Shape shape5 = xYAreaRenderer0.getBaseShape();
        java.awt.Paint paint6 = xYAreaRenderer0.getBasePaint();
        java.awt.Stroke stroke8 = xYAreaRenderer0.getSeriesOutlineStroke(10);
        java.awt.Paint paint9 = xYAreaRenderer0.getBaseFillPaint();
        xYAreaRenderer0.setBaseItemLabelsVisible(false, false);
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(stroke8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("RangeType.FULL");
        java.lang.String str2 = legendItem1.getURLText();
        java.lang.String str3 = legendItem1.getURLText();
        legendItem1.setShapeVisible(false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = legendItem1.getFillPaintTransformer();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer7 = null;
        try {
            legendItem1.setFillPaintTransformer(gradientPaintTransformer7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'transformer' attribute.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        int int0 = org.jfree.data.time.SerialDate.FOLLOWING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries4.clear();
        timeSeries4.setDescription("series");
        int int8 = timeSeriesCollection0.indexOf(timeSeries4);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection0, (org.jfree.chart.axis.ValueAxis) numberAxis9, polarItemRenderer10);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = polarPlot11.getOrientation();
        java.awt.Paint paint13 = polarPlot11.getRadiusGridlinePaint();
        boolean boolean14 = polarPlot11.isAngleGridlinesVisible();
        boolean boolean15 = polarPlot11.isAngleGridlinesVisible();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer16 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYAreaRenderer16.setBaseOutlineStroke(stroke17);
        polarPlot11.setRadiusGridlineStroke(stroke17);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        combinedDomainXYPlot1.select(generalPath3, rectangle2D4, renderingSource5);
        java.awt.Paint paint8 = combinedDomainXYPlot1.getQuadrantPaint((int) (short) 0);
        combinedDomainXYPlot1.setBackgroundAlpha(0.0f);
        float float11 = combinedDomainXYPlot1.getBackgroundAlpha();
        combinedDomainXYPlot1.setGap((double) (-460));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor1 = org.jfree.data.time.TimePeriodAnchor.END;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint4 = categoryAxis3D3.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D3, jFreeChart5, (int) (short) 1, (int) (short) 10);
        boolean boolean9 = timePeriodAnchor1.equals((java.lang.Object) (short) 10);
        timeSeriesCollection0.setXPosition(timePeriodAnchor1);
        org.jfree.data.DomainOrder domainOrder11 = timeSeriesCollection0.getDomainOrder();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis12);
        java.util.List list14 = combinedRangeXYPlot13.getSubplots();
        java.util.List list15 = combinedRangeXYPlot13.getSubplots();
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean18 = range16.contains(0.0d);
        org.jfree.data.Range range21 = org.jfree.data.Range.expand(range16, (double) ' ', (double) 2.0f);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month23.next();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = month25.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = month25.next();
        org.jfree.chart.axis.PeriodAxis periodAxis28 = new org.jfree.chart.axis.PeriodAxis("java.awt.Color[r=255,g=128,b=128]", regularTimePeriod24, regularTimePeriod27);
        java.awt.Paint paint29 = periodAxis28.getMinorTickMarkPaint();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D30.centerRange((-1.0d));
        java.awt.Paint paint33 = numberAxis3D30.getTickLabelPaint();
        org.jfree.data.Range range34 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double35 = range34.getLength();
        numberAxis3D30.setRangeWithMargins(range34, false, false);
        periodAxis28.setRange(range34, false, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = new org.jfree.chart.block.RectangleConstraint(range16, range34);
        org.jfree.data.Range range44 = org.jfree.data.general.DatasetUtilities.iterateToFindRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0, list15, range34, false);
        org.junit.Assert.assertNotNull(timePeriodAnchor1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(domainOrder11);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
        org.junit.Assert.assertNull(range44);
    }

//    @Test
//    public void test311() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test311");
//        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
//        timeSeries4.clear();
//        timeSeries4.setDescription("series");
//        int int8 = timeSeriesCollection0.indexOf(timeSeries4);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day9, (java.lang.Number) 12, false);
//        long long13 = day9.getLastMillisecond();
//        int int14 = day9.getDayOfMonth();
//        int int15 = day9.getMonth();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560495599999L + "'", long13 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 13 + "'", int14 == 13);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        java.util.List list2 = combinedRangeXYPlot1.getSubplots();
        java.util.List list3 = combinedRangeXYPlot1.getSubplots();
        combinedRangeXYPlot1.configureRangeAxes();
        int int5 = combinedRangeXYPlot1.getRangeAxisCount();
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBaseLegendTextPaint();
        java.awt.Paint paint2 = xYAreaRenderer0.getBaseLegendTextPaint();
        java.awt.Shape shape3 = xYAreaRenderer0.getLegendArea();
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeMinorGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer(10);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint6 = categoryAxis3D5.getLabelPaint();
        categoryAxis3D5.setTickMarkInsideLength((float) 0);
        categoryAxis3D5.addCategoryLabelToolTip((java.lang.Comparable) 1, "series");
        int int12 = categoryPlot0.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D5);
        double[] doubleArray19 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray24 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray25 = new double[][] { doubleArray19, doubleArray24 };
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray25);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot27 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset26);
        org.jfree.data.category.CategoryDataset categoryDataset28 = multiplePiePlot27.getDataset();
        boolean boolean29 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset28);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = categoryPlot0.getRendererForDataset(categoryDataset28);
        float float31 = categoryPlot0.getBackgroundImageAlpha();
        java.awt.Stroke stroke32 = categoryPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(categoryItemRenderer30);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 0.5f + "'", float31 == 0.5f);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor1 = org.jfree.data.time.TimePeriodAnchor.END;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint4 = categoryAxis3D3.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D3, jFreeChart5, (int) (short) 1, (int) (short) 10);
        boolean boolean9 = timePeriodAnchor1.equals((java.lang.Object) (short) 10);
        timeSeriesCollection0.setXPosition(timePeriodAnchor1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate11 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        double double13 = intervalXYDelegate11.getDomainUpperBound(false);
        double double14 = intervalXYDelegate11.getIntervalWidth();
        org.junit.Assert.assertNotNull(timePeriodAnchor1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertEquals((double) double13, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries4.clear();
        timeSeries4.setDescription("series");
        int int8 = timeSeriesCollection0.indexOf(timeSeries4);
        try {
            int[] intArray11 = timeSeriesCollection0.getSurroundingItems((int) (short) 10, (long) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (10).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator2 = null;
        xYAreaRenderer0.setLegendItemToolTipGenerator(xYSeriesLabelGenerator2);
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYAreaRenderer0.setSeriesStroke(3, stroke5);
        boolean boolean10 = xYAreaRenderer0.isItemLabelVisible((int) (short) 1, (int) (byte) 100, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range12 = xYAreaRenderer0.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        org.jfree.data.xy.XYSeries xYSeries13 = null;
        try {
            xYSeriesCollection11.removeSeries(xYSeries13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(range12);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint2 = categoryAxis3D1.getLabelPaint();
        categoryAxis3D1.setTickMarkInsideLength((float) 0);
        java.awt.Font font5 = categoryAxis3D1.getLabelFont();
        categoryAxis3D1.setTickLabelsVisible(true);
        categoryAxis3D1.setTickLabelsVisible(true);
        categoryAxis3D1.setMaximumCategoryLabelWidthRatio((float) 60000L);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        double double4 = barRenderer3D2.getXOffset();
        int int5 = barRenderer3D2.getColumnCount();
        barRenderer3D2.setIncludeBaseInRange(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        barRenderer3D2.setBaseToolTipGenerator(categoryToolTipGenerator8);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.099412556013E12d + "'", double4 == 1.099412556013E12d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangePannable(true);
        double double4 = combinedDomainXYPlot1.getGap();
        java.lang.Object obj5 = combinedDomainXYPlot1.clone();
        java.lang.Object obj6 = combinedDomainXYPlot1.clone();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5.0d + "'", double4 == 5.0d);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor0 = org.jfree.data.time.TimePeriodAnchor.END;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint3 = categoryAxis3D2.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent7 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D2, jFreeChart4, (int) (short) 1, (int) (short) 10);
        boolean boolean8 = timePeriodAnchor0.equals((java.lang.Object) (short) 10);
        org.jfree.chart.util.ObjectList objectList10 = new org.jfree.chart.util.ObjectList(3);
        java.lang.Object obj11 = objectList10.clone();
        boolean boolean12 = timePeriodAnchor0.equals((java.lang.Object) objectList10);
        org.junit.Assert.assertNotNull(timePeriodAnchor0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangePannable(true);
        org.jfree.chart.axis.AxisSpace axisSpace4 = combinedDomainXYPlot1.getFixedDomainAxisSpace();
        java.awt.Stroke stroke5 = null;
        try {
            combinedDomainXYPlot1.setRangeGridlineStroke(stroke5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace4);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint2 = categoryAxis3D1.getLabelPaint();
        categoryAxis3D1.setTickMarkInsideLength((float) 0);
        java.awt.Font font5 = categoryAxis3D1.getLabelFont();
        categoryAxis3D1.setCategoryMargin((double) 1L);
        java.awt.Paint paint8 = categoryAxis3D1.getLabelPaint();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer9 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYAreaRenderer9.setBaseOutlineStroke(stroke10);
        categoryAxis3D1.setAxisLineStroke(stroke10);
        float float13 = categoryAxis3D1.getMinorTickMarkOutsideLength();
        categoryAxis3D1.setMaximumCategoryLabelWidthRatio(1.0f);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 2.0f + "'", float13 == 2.0f);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int1 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries4.clear();
        timeSeries4.setDescription("series");
        int int8 = timeSeriesCollection0.indexOf(timeSeries4);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day9, (java.lang.Number) 12, false);
        boolean boolean13 = timeSeries4.getNotify();
        java.lang.Class class14 = timeSeries4.getTimePeriodClass();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries4.getDataItem((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(class14);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        long long3 = segmentedTimeline0.getTimeFromLong(3600000L);
        long long4 = segmentedTimeline0.getStartTime();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 3600000L + "'", long3 == 3600000L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-2208927600000L) + "'", long4 == (-2208927600000L));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) ' ');
        pieLabelDistributor1.clear();
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord4 = pieLabelDistributor1.getPieLabelRecord((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean4 = xYAreaRenderer3.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator5 = null;
        xYAreaRenderer3.setLegendItemToolTipGenerator(xYSeriesLabelGenerator5);
        boolean boolean7 = xYAreaRenderer3.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator9 = null;
        xYAreaRenderer3.setSeriesToolTipGenerator((int) (short) 100, xYToolTipGenerator9);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = xYAreaRenderer3.getNegativeItemLabelPosition(100, (int) (byte) -1, false);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor15 = itemLabelPosition14.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor16 = itemLabelPosition14.getTextAnchor();
        barRenderer3D2.setNegativeItemLabelPositionFallback(itemLabelPosition14);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D20 = new org.jfree.chart.renderer.category.BarRenderer3D(8.19260189995275E11d, (double) 60000L);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer21 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        barRenderer3D20.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer21);
        barRenderer3D2.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer21);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(itemLabelAnchor15);
        org.junit.Assert.assertNotNull(textAnchor16);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = combinedDomainXYPlot1.getDataRange(valueAxis2);
        java.lang.Object obj4 = null;
        boolean boolean5 = combinedDomainXYPlot1.equals(obj4);
        combinedDomainXYPlot1.setDomainCrosshairVisible(false);
        java.awt.Paint paint8 = null;
        try {
            combinedDomainXYPlot1.setDomainZeroBaselinePaint(paint8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean6 = xYAreaRenderer5.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator7 = null;
        xYAreaRenderer5.setLegendItemToolTipGenerator(xYSeriesLabelGenerator7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis3, valueAxis4, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer5);
        boolean boolean10 = xYAreaRenderer5.isOutline();
        java.awt.Font font12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYAreaRenderer5.setSeriesItemLabelFont(100, font12);
        org.jfree.chart.plot.XYPlot xYPlot14 = xYAreaRenderer5.getPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot14.getRangeAxisEdge(100);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(xYPlot14);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(serialDate2);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.SerialDate serialDate6 = serialDate2.getEndOfCurrentMonth(serialDate5);
        try {
            org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek((int) (short) 0, serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        double double1 = crosshairState0.getAnchorX();
        crosshairState0.setCrosshairX((double) 1099412556013L);
        int int4 = crosshairState0.getDomainAxisIndex();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        int int4 = combinedDomainXYPlot3.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot3.rendererChanged(rendererChangeEvent6);
        combinedDomainXYPlot1.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot3);
        combinedDomainXYPlot3.setDomainMinorGridlinesVisible(true);
        boolean boolean11 = combinedDomainXYPlot3.isRangeCrosshairLockedOnData();
        java.awt.Paint paint12 = null;
        combinedDomainXYPlot3.setRangeTickBandPaint(paint12);
        java.awt.Paint paint14 = combinedDomainXYPlot3.getRangeCrosshairPaint();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment16 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement20 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment16, verticalAlignment17, (double) (byte) 1, (double) 100.0f);
        org.jfree.chart.block.BlockContainer blockContainer21 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement20);
        org.jfree.chart.block.BlockFrame blockFrame22 = blockContainer21.getFrame();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer23 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean24 = xYAreaRenderer23.isOutline();
        java.awt.Shape shape25 = xYAreaRenderer23.getBaseShape();
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic27 = new org.jfree.chart.title.LegendGraphic(shape25, (java.awt.Paint) color26);
        legendGraphic27.setWidth((double) 8);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint33 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D34 = legendGraphic27.arrange(graphics2D30, rectangleConstraint33);
        double double35 = legendGraphic27.getHeight();
        boolean boolean36 = legendGraphic27.isShapeVisible();
        java.lang.Object obj37 = null;
        blockContainer21.add((org.jfree.chart.block.Block) legendGraphic27, obj37);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D40 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint41 = categoryAxis3D40.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart42 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent45 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D40, jFreeChart42, (int) (short) 1, (int) (short) 10);
        int int46 = chartProgressEvent45.getType();
        boolean boolean47 = blockContainer21.equals((java.lang.Object) chartProgressEvent45);
        java.util.List list48 = blockContainer21.getBlocks();
        try {
            combinedDomainXYPlot3.mapDatasetToRangeAxes(8, list48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Indices must be Integer instances.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(blockFrame22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(size2D34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1 + "'", int46 == 1);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(list48);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer1 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(28);
        xYStepAreaRenderer1.setShapesVisible(true);
        xYStepAreaRenderer1.setShapesFilled(true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer7 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean8 = xYAreaRenderer7.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator9 = null;
        xYAreaRenderer7.setLegendItemToolTipGenerator(xYSeriesLabelGenerator9);
        boolean boolean11 = xYAreaRenderer7.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator13 = null;
        xYAreaRenderer7.setSeriesToolTipGenerator((int) (short) 100, xYToolTipGenerator13);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = xYAreaRenderer7.getNegativeItemLabelPosition(100, (int) (byte) -1, false);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor19 = itemLabelPosition18.getItemLabelAnchor();
        try {
            xYStepAreaRenderer1.setSeriesNegativeItemLabelPosition((-1), itemLabelPosition18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(itemLabelAnchor19);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        combinedDomainXYPlot1.select(generalPath3, rectangle2D4, renderingSource5);
        java.awt.Paint paint8 = combinedDomainXYPlot1.getQuadrantPaint((int) (short) 0);
        combinedDomainXYPlot1.setBackgroundAlpha(0.0f);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = combinedDomainXYPlot1.getLegendItems();
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("RangeType.FULL");
        java.lang.String str14 = legendItem13.getURLText();
        double[] doubleArray21 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray26 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray27 = new double[][] { doubleArray21, doubleArray26 };
        org.jfree.data.category.CategoryDataset categoryDataset28 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray27);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot29 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset28);
        org.jfree.data.category.CategoryDataset categoryDataset30 = multiplePiePlot29.getDataset();
        java.lang.Number number31 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset30);
        legendItem13.setDataset((org.jfree.data.general.Dataset) categoryDataset30);
        legendItemCollection11.add(legendItem13);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertNotNull(categoryDataset30);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 0.0d + "'", number31.equals(0.0d));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor1 = org.jfree.data.time.TimePeriodAnchor.END;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint4 = categoryAxis3D3.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D3, jFreeChart5, (int) (short) 1, (int) (short) 10);
        boolean boolean9 = timePeriodAnchor1.equals((java.lang.Object) (short) 10);
        timeSeriesCollection0.setXPosition(timePeriodAnchor1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate11 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        java.util.List list12 = timeSeriesCollection0.getSeries();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries16.clear();
        timeSeries16.setDescription("series");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection20 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries24.clear();
        timeSeries24.setDescription("series");
        int int28 = timeSeriesCollection20.indexOf(timeSeries24);
        java.lang.String str29 = timeSeries24.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries16.addAndOrUpdate(timeSeries24);
        int int31 = timeSeriesCollection0.indexOf(timeSeries16);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = timeSeries16.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodAnchor1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries4.clear();
        timeSeries4.setDescription("series");
        int int8 = timeSeriesCollection0.indexOf(timeSeries4);
        java.lang.String str9 = timeSeries4.getRangeDescription();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = timeSeries4.addOrUpdate(regularTimePeriod10, (java.lang.Number) (-1L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setUpperMargin((double) (short) 0);
        numberAxis3D0.resizeRange2((double) 10L, (double) 12);
        numberAxis3D0.setAutoTickUnitSelection(false);
        numberAxis3D0.centerRange(5.0d);
        org.jfree.chart.event.AxisChangeListener axisChangeListener10 = null;
        numberAxis3D0.addChangeListener(axisChangeListener10);
        numberAxis3D0.resizeRange2(0.0d, 0.0d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        org.jfree.chart.LegendItem legendItem6 = barRenderer3D2.getLegendItem((int) (byte) 1, 1);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        java.lang.String str11 = timeSeries10.getDomainDescription();
        java.lang.Class class12 = timeSeries10.getTimePeriodClass();
        boolean boolean13 = barRenderer3D2.equals((java.lang.Object) class12);
        barRenderer3D2.setBase(8.0d);
        org.jfree.chart.renderer.category.BarPainter barPainter16 = barRenderer3D2.getBarPainter();
        org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(barPainter16);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNull(legendItem6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "series" + "'", str11.equals("series"));
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(barPainter16);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeMinorGridlineStroke();
        int int2 = categoryPlot0.getDomainAxisCount();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D5 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = barRenderer3D5.getLegendItemLabelGenerator();
        org.jfree.chart.LegendItem legendItem9 = barRenderer3D5.getLegendItem((int) (byte) 1, 1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = barRenderer3D5.getURLGenerator((int) (byte) 1, (int) (byte) 1, true);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer3D5);
        barRenderer3D5.setAutoPopulateSeriesFillPaint(false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator6);
        org.junit.Assert.assertNull(legendItem9);
        org.junit.Assert.assertNull(categoryURLGenerator13);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        org.jfree.chart.text.TextFragment textFragment1 = textLine0.getLastTextFragment();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.NumberTick numberTick10 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (short) 10, "series", textAnchor7, textAnchor8, (double) (short) 10);
        textLine0.draw(graphics2D2, (float) (-9999), 0.0f, textAnchor7, (float) 68, (float) '4', 4.0d);
        org.junit.Assert.assertNull(textFragment1);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        java.awt.Image image0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeImage(image0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean6 = xYAreaRenderer5.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator7 = null;
        xYAreaRenderer5.setLegendItemToolTipGenerator(xYSeriesLabelGenerator7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis3, valueAxis4, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer5);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        xYPlot9.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) numberAxis3D11);
        try {
            numberAxis3D11.setRange((double) 172800000L, (double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.728E8) <= upper (10.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries4.clear();
        timeSeries4.setDescription("series");
        int int8 = timeSeriesCollection0.indexOf(timeSeries4);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection0, (org.jfree.chart.axis.ValueAxis) numberAxis9, polarItemRenderer10);
        int int12 = polarPlot11.getSeriesCount();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean6 = xYAreaRenderer5.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator7 = null;
        xYAreaRenderer5.setLegendItemToolTipGenerator(xYSeriesLabelGenerator7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis3, valueAxis4, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer5);
        float float10 = xYPlot9.getBackgroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double13 = rectangleInsets11.trimWidth((double) 1560495599999L);
        xYPlot9.setAxisOffset(rectangleInsets11);
        double double15 = rectangleInsets11.getLeft();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.560495599991E12d + "'", double13 == 1.560495599991E12d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.0d + "'", double15 == 4.0d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        double double2 = combinedRangeXYPlot1.getGap();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis3);
        java.awt.Paint paint5 = combinedDomainXYPlot4.getBackgroundPaint();
        combinedRangeXYPlot1.addChangeListener((org.jfree.chart.event.PlotChangeListener) combinedDomainXYPlot4);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.data.Range range8 = combinedDomainXYPlot4.getDataRange(valueAxis7);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.0d + "'", double2 == 5.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(range8);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearAnnotations();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getRangeAxisLocation();
        categoryPlot0.setRangeZeroBaselineVisible(true);
        java.awt.Stroke stroke7 = categoryPlot0.getRangeGridlineStroke();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        org.jfree.chart.LegendItem legendItem6 = barRenderer3D2.getLegendItem((int) (byte) 1, 1);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        java.lang.String str11 = timeSeries10.getDomainDescription();
        java.lang.Class class12 = timeSeries10.getTimePeriodClass();
        boolean boolean13 = barRenderer3D2.equals((java.lang.Object) class12);
        barRenderer3D2.setBase(8.0d);
        org.jfree.chart.renderer.category.BarPainter barPainter16 = barRenderer3D2.getBarPainter();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer17 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYAreaRenderer17.setBaseOutlineStroke(stroke18);
        java.lang.Object obj20 = xYAreaRenderer17.clone();
        java.awt.Shape shape24 = xYAreaRenderer17.getItemShape((int) (byte) 1, (int) (byte) 100, false);
        java.awt.Font font28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock29 = new org.jfree.chart.block.LabelBlock("ClassContext", font28);
        java.awt.Paint paint30 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        org.jfree.chart.text.TextFragment textFragment32 = new org.jfree.chart.text.TextFragment("java.awt.Color[r=255,g=128,b=128]", font28, paint30, (float) 43629L);
        xYAreaRenderer17.setLegendTextFont(2, font28);
        java.awt.Paint paint35 = xYAreaRenderer17.lookupSeriesFillPaint((int) '#');
        barRenderer3D2.setBasePaint(paint35, true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNull(legendItem6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "series" + "'", str11.equals("series"));
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(barPainter16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setUpperMargin((double) (short) 0);
        numberAxis3D0.resizeRange2((double) 10L, (double) 12);
        numberAxis3D0.setAutoTickUnitSelection(false);
        numberAxis3D0.centerRange(5.0d);
        org.jfree.chart.event.AxisChangeListener axisChangeListener10 = null;
        numberAxis3D0.addChangeListener(axisChangeListener10);
        org.jfree.chart.plot.PiePlot3D piePlot3D12 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection13 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection13, true);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer18 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean19 = xYAreaRenderer18.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator20 = null;
        xYAreaRenderer18.setLegendItemToolTipGenerator(xYSeriesLabelGenerator20);
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection13, valueAxis16, valueAxis17, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer18);
        boolean boolean23 = xYAreaRenderer18.isOutline();
        java.awt.Font font25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYAreaRenderer18.setSeriesItemLabelFont(100, font25);
        piePlot3D12.setLabelFont(font25);
        numberAxis3D0.setLabelFont(font25);
        java.awt.Shape shape29 = numberAxis3D0.getRightArrow();
        numberAxis3D0.setPositiveArrowVisible(false);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(shape29);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean6 = xYAreaRenderer5.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator7 = null;
        xYAreaRenderer5.setLegendItemToolTipGenerator(xYSeriesLabelGenerator7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis3, valueAxis4, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer5);
        boolean boolean10 = xYAreaRenderer5.isOutline();
        java.awt.Font font12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYAreaRenderer5.setSeriesItemLabelFont(100, font12);
        org.jfree.chart.plot.XYPlot xYPlot14 = xYAreaRenderer5.getPlot();
        java.awt.Shape shape15 = xYAreaRenderer5.getLegendArea();
        boolean boolean16 = xYAreaRenderer5.getPlotShapes();
        xYAreaRenderer5.setAutoPopulateSeriesPaint(false);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(xYPlot14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        double double2 = logAxis0.calculateLog((double) 6);
        logAxis0.configure();
        logAxis0.pan((double) (short) 100);
        logAxis0.pan((double) 1900);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7781512503836435d + "'", double2 == 0.7781512503836435d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor1 = org.jfree.data.time.TimePeriodAnchor.END;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint4 = categoryAxis3D3.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D3, jFreeChart5, (int) (short) 1, (int) (short) 10);
        boolean boolean9 = timePeriodAnchor1.equals((java.lang.Object) (short) 10);
        timeSeriesCollection0.setXPosition(timePeriodAnchor1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate11 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        java.util.List list12 = timeSeriesCollection0.getSeries();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries16.clear();
        timeSeries16.setDescription("series");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection20 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries24.clear();
        timeSeries24.setDescription("series");
        int int28 = timeSeriesCollection20.indexOf(timeSeries24);
        java.lang.String str29 = timeSeries24.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries16.addAndOrUpdate(timeSeries24);
        int int31 = timeSeriesCollection0.indexOf(timeSeries16);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline32 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int33 = segmentedTimeline32.getSegmentsExcluded();
        java.util.Date date34 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment35 = segmentedTimeline32.getSegment(date34);
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month(date34);
        timeSeries16.add((org.jfree.data.time.RegularTimePeriod) month36, 0.025d);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year39.previous();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries16.addOrUpdate(regularTimePeriod40, (double) 1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodAnchor1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(segmentedTimeline32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 68 + "'", int33 == 68);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(segment35);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) month0, false);
        xYSeries3.add((double) 10.0f, (java.lang.Number) 0.5d);
        xYSeries3.setMaximumItemCount((int) '#');
        double double9 = xYSeries3.getMaxX();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        org.jfree.data.time.Year year2 = month0.getYear();
        int int3 = year2.getYear();
        java.util.Calendar calendar4 = null;
        try {
            year2.peg(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeMinorGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer(10);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint6 = categoryAxis3D5.getLabelPaint();
        categoryAxis3D5.setTickMarkInsideLength((float) 0);
        categoryAxis3D5.addCategoryLabelToolTip((java.lang.Comparable) 1, "series");
        int int12 = categoryPlot0.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D5);
        double[] doubleArray19 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray24 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray25 = new double[][] { doubleArray19, doubleArray24 };
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray25);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot27 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset26);
        org.jfree.data.category.CategoryDataset categoryDataset28 = multiplePiePlot27.getDataset();
        boolean boolean29 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset28);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = categoryPlot0.getRendererForDataset(categoryDataset28);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray31 = null;
        try {
            categoryPlot0.setRangeAxes(valueAxisArray31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(categoryItemRenderer30);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray3 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray3);
        boolean boolean6 = categoryPlot0.equals((java.lang.Object) "hi!");
        java.lang.Object obj7 = categoryPlot0.clone();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(categoryAxisArray3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint3 = categoryAxis3D2.getLabelPaint();
        categoryAxis3D2.setTickMarkInsideLength((float) 0);
        java.awt.Font font6 = categoryAxis3D2.getLabelFont();
        org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("-3,-3,3,3", font6);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot3D0.setLabelGenerator(pieSectionLabelGenerator1);
        piePlot3D0.setShadowXOffset(0.0d);
        double double5 = piePlot3D0.getDepthFactor();
        java.awt.Paint paint6 = piePlot3D0.getLabelOutlinePaint();
        java.lang.Object obj7 = piePlot3D0.clone();
        org.jfree.chart.labels.PieToolTipGenerator pieToolTipGenerator8 = piePlot3D0.getToolTipGenerator();
        double double9 = piePlot3D0.getDepthFactor();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.12d + "'", double5 == 0.12d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(pieToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.12d + "'", double9 == 0.12d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        float[] floatArray1 = new float[] {};
        try {
            float[] floatArray2 = color0.getComponents(floatArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray1);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        double[] doubleArray6 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray11 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray12 = new double[][] { doubleArray6, doubleArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        java.lang.Number number15 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset13);
        org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset13, 0);
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot(pieDataset17);
        ringPlot18.setShadowYOffset(0.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1.0d + "'", number15.equals(1.0d));
        org.junit.Assert.assertNotNull(pieDataset17);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getCurrencyInstance();
        numberFormat0.setMaximumIntegerDigits((int) (short) 10);
        int int3 = numberFormat0.getMaximumIntegerDigits();
        java.math.RoundingMode roundingMode4 = numberFormat0.getRoundingMode();
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + java.math.RoundingMode.HALF_EVEN + "'", roundingMode4.equals(java.math.RoundingMode.HALF_EVEN));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        java.awt.Paint paint4 = combinedDomainXYPlot3.getBackgroundPaint();
        xYAreaRenderer0.setSeriesPaint(2, paint4);
        xYAreaRenderer0.setAutoPopulateSeriesPaint(false);
        xYAreaRenderer0.setUseFillPaint(true);
        boolean boolean13 = xYAreaRenderer0.getItemCreateEntity((int) (short) 0, 255, true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.centerRange((-1.0d));
        java.awt.Paint paint3 = numberAxis3D0.getTickLabelPaint();
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double5 = range4.getLength();
        numberAxis3D0.setRangeWithMargins(range4, false, false);
        org.jfree.data.RangeType rangeType9 = numberAxis3D0.getRangeType();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint12 = categoryAxis3D11.getLabelPaint();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D15 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        piePlot3D15.setSimpleLabelOffset(rectangleInsets16);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection18 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries22.clear();
        timeSeries22.setDescription("series");
        int int26 = timeSeriesCollection18.indexOf(timeSeries22);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer28 = null;
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection18, (org.jfree.chart.axis.ValueAxis) numberAxis27, polarItemRenderer28);
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = polarPlot29.getOrientation();
        java.awt.Paint paint31 = polarPlot29.getRadiusGridlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer35 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean36 = xYAreaRenderer35.isOutline();
        java.awt.Shape shape37 = xYAreaRenderer35.getBaseShape();
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic39 = new org.jfree.chart.title.LegendGraphic(shape37, (java.awt.Paint) color38);
        legendGraphic39.setWidth((double) 8);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint45 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D46 = legendGraphic39.arrange(graphics2D42, rectangleConstraint45);
        double double47 = legendGraphic39.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor48 = legendGraphic39.getShapeLocation();
        java.awt.geom.Rectangle2D rectangle2D49 = legendGraphic39.getBounds();
        rectangleInsets34.trim(rectangle2D49);
        java.awt.Point point51 = polarPlot29.translateValueThetaRadiusToJava2D((double) (-1.0f), (double) (short) 100, rectangle2D49);
        java.awt.geom.Rectangle2D rectangle2D52 = rectangleInsets16.createInsetRectangle(rectangle2D49);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D55 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint56 = categoryAxis3D55.getLabelPaint();
        categoryAxis3D55.setTickMarkInsideLength((float) 0);
        java.awt.Font font59 = categoryAxis3D55.getLabelFont();
        java.awt.Color color60 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment62 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment63 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke64 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.lang.Class<?> wildcardClass65 = stroke64.getClass();
        boolean boolean66 = verticalAlignment63.equals((java.lang.Object) stroke64);
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double69 = rectangleInsets67.calculateTopInset(10.0d);
        org.jfree.chart.title.TextTitle textTitle70 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font59, (java.awt.Paint) color60, rectangleEdge61, horizontalAlignment62, verticalAlignment63, rectangleInsets67);
        org.jfree.chart.axis.AxisState axisState71 = new org.jfree.chart.axis.AxisState();
        categoryAxis3D11.drawTickMarks(graphics2D13, (double) (byte) 0, rectangle2D52, rectangleEdge61, axisState71);
        boolean boolean73 = rangeType9.equals((java.lang.Object) rectangleEdge61);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(rangeType9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(size2D46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor48);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(point51);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(font59);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(rectangleEdge61);
        org.junit.Assert.assertNotNull(horizontalAlignment62);
        org.junit.Assert.assertNotNull(verticalAlignment63);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("35");
        dateAxis1.zoomRange((double) (byte) 1, 3.0d);
        dateAxis1.setRange(5.0d, (double) 1900);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        java.awt.Paint paint4 = combinedDomainXYPlot3.getBackgroundPaint();
        xYAreaRenderer0.setSeriesPaint(2, paint4);
        org.jfree.chart.LegendItem legendItem8 = xYAreaRenderer0.getLegendItem(1, (int) (short) 100);
        boolean boolean10 = xYAreaRenderer0.isSeriesVisibleInLegend(0);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(legendItem8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        xYSeriesCollection0.removeAllSeries();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = null;
        xYSeriesCollection0.seriesChanged(seriesChangeEvent2);
        int int5 = xYSeriesCollection0.indexOf((java.lang.Comparable) 1);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.DAY;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.data.Range range5 = xYSeriesCollection0.getRangeBounds(true);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertEquals((double) number3, Double.NaN, 0);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, false);
        int int5 = xYSeriesCollection0.getSeriesCount();
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D7.centerRange((-1.0d));
        java.awt.Paint paint10 = numberAxis3D7.getTickLabelPaint();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D11.setUpperMargin((double) (short) 0);
        numberAxis3D11.resizeRange2((double) 10L, (double) 12);
        numberAxis3D11.setAutoTickUnitSelection(false);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer19 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = null;
        xYAreaRenderer19.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition21);
        boolean boolean23 = xYAreaRenderer19.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D24.centerRange((-1.0d));
        java.awt.Paint paint27 = numberAxis3D24.getTickLabelPaint();
        xYAreaRenderer19.setBaseFillPaint(paint27, true);
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) numberAxis3D7, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer19);
        java.lang.Boolean boolean32 = xYAreaRenderer19.getSeriesItemLabelsVisible(3);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNull(boolean32);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        java.util.List list2 = combinedRangeXYPlot1.getSubplots();
        java.util.List list3 = combinedRangeXYPlot1.getSubplots();
        combinedRangeXYPlot1.configureRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis5);
        int int7 = combinedDomainXYPlot6.getBackgroundImageAlignment();
        combinedDomainXYPlot6.setForegroundAlpha((float) (-1));
        int int10 = combinedDomainXYPlot6.getDomainAxisCount();
        float float11 = combinedDomainXYPlot6.getBackgroundImageAlpha();
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) 0.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent14 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker13);
        org.jfree.chart.plot.Marker marker15 = markerChangeEvent14.getMarker();
        org.jfree.chart.util.Layer layer16 = null;
        boolean boolean17 = combinedDomainXYPlot6.removeRangeMarker(marker15, layer16);
        combinedRangeXYPlot1.addChangeListener((org.jfree.chart.event.PlotChangeListener) combinedDomainXYPlot6);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = combinedRangeXYPlot1.getRangeAxisEdge(255);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.5f + "'", float11 == 0.5f);
        org.junit.Assert.assertNotNull(marker15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.TOP_RIGHT" + "'", str1.equals("RectangleAnchor.TOP_RIGHT"));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection1, true);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean7 = xYAreaRenderer6.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator8 = null;
        xYAreaRenderer6.setLegendItemToolTipGenerator(xYSeriesLabelGenerator8);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection1, valueAxis4, valueAxis5, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer6);
        boolean boolean11 = xYAreaRenderer6.isOutline();
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYAreaRenderer6.setSeriesItemLabelFont(100, font13);
        piePlot3D0.setLabelFont(font13);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer16 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean17 = xYAreaRenderer16.isOutline();
        java.awt.Shape shape18 = xYAreaRenderer16.getBaseShape();
        piePlot3D0.setLegendItemShape(shape18);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(shape18);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        double[] doubleArray6 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray11 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray12 = new double[][] { doubleArray6, doubleArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        java.lang.Number number15 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset13);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset13, false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1.0d + "'", number15.equals(1.0d));
        org.junit.Assert.assertNotNull(range17);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setUpperMargin((double) (short) 0);
        numberAxis3D0.resizeRange2((double) 10L, (double) 12);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand6 = numberAxis3D0.getMarkerBand();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis9);
        int int11 = combinedDomainXYPlot10.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot10.rendererChanged(rendererChangeEvent13);
        combinedDomainXYPlot8.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot10);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = combinedDomainXYPlot10.getDomainAxisEdge((int) (byte) 1);
        numberAxis3D0.setPlot((org.jfree.chart.plot.Plot) combinedDomainXYPlot10);
        java.awt.Font font19 = combinedDomainXYPlot10.getNoDataMessageFont();
        boolean boolean20 = combinedDomainXYPlot10.isDomainPannable();
        org.junit.Assert.assertNull(markerAxisBand6);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries4.clear();
        timeSeries4.setDescription("series");
        int int8 = timeSeriesCollection0.indexOf(timeSeries4);
        long long9 = timeSeries4.getMaximumItemAge();
        java.lang.Object obj10 = timeSeries4.clone();
        java.lang.String str11 = timeSeries4.getDescription();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9223372036854775807L + "'", long9 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "series" + "'", str11.equals("series"));
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("TextBlockAnchor.CENTER");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection2 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection2, true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer7 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean8 = xYAreaRenderer7.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator9 = null;
        xYAreaRenderer7.setLegendItemToolTipGenerator(xYSeriesLabelGenerator9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection2, valueAxis5, valueAxis6, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer7);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D();
        xYPlot11.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) numberAxis3D13);
        boolean boolean15 = numberAxis3D13.isTickMarksVisible();
        java.awt.Font font16 = numberAxis3D13.getTickLabelFont();
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_GREEN;
        numberAxis3D13.setTickMarkPaint((java.awt.Paint) color17);
        standardChartTheme1.setLegendBackgroundPaint((java.awt.Paint) color17);
        java.awt.Paint paint20 = standardChartTheme1.getTitlePaint();
        org.jfree.chart.renderer.category.BarPainter barPainter21 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
        standardChartTheme1.setBarPainter(barPainter21);
        java.awt.Paint paint23 = standardChartTheme1.getItemLabelPaint();
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(barPainter21);
        org.junit.Assert.assertNotNull(paint23);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries4.clear();
        timeSeries4.setDescription("series");
        int int8 = timeSeriesCollection0.indexOf(timeSeries4);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection0, (org.jfree.chart.axis.ValueAxis) numberAxis9, polarItemRenderer10);
        java.lang.Object obj12 = polarPlot11.clone();
        org.jfree.chart.axis.ValueAxis valueAxis13 = polarPlot11.getAxis();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertNotNull(valueAxis13);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        java.text.DateFormat dateFormat1 = null;
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getNumberInstance();
        java.lang.String str4 = numberFormat2.format(0.0d);
        java.math.RoundingMode roundingMode5 = numberFormat2.getRoundingMode();
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator6 = new org.jfree.chart.labels.StandardXYToolTipGenerator("ClassContext", dateFormat1, numberFormat2);
        java.lang.Object obj7 = standardXYToolTipGenerator6.clone();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor9 = org.jfree.data.time.TimePeriodAnchor.END;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint12 = categoryAxis3D11.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent16 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D11, jFreeChart13, (int) (short) 1, (int) (short) 10);
        boolean boolean17 = timePeriodAnchor9.equals((java.lang.Object) (short) 10);
        timeSeriesCollection8.setXPosition(timePeriodAnchor9);
        org.jfree.data.DomainOrder domainOrder19 = timeSeriesCollection8.getDomainOrder();
        try {
            java.lang.String str22 = standardXYToolTipGenerator6.generateLabelString((org.jfree.data.xy.XYDataset) timeSeriesCollection8, 68, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (68).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + java.math.RoundingMode.HALF_EVEN + "'", roundingMode5.equals(java.math.RoundingMode.HALF_EVEN));
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(timePeriodAnchor9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(domainOrder19);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray3 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot0.setRenderer(categoryItemRenderer5, false);
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(categoryAxisArray3);
        org.junit.Assert.assertNull(axisSpace8);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.plot.XYCrosshairState xYCrosshairState0 = new org.jfree.chart.plot.XYCrosshairState();
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.HOUR;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot3D0.setLabelGenerator(pieSectionLabelGenerator1);
        piePlot3D0.setShadowXOffset(0.0d);
        piePlot3D0.setCircular(true);
        java.awt.Font font7 = piePlot3D0.getLabelFont();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator8 = piePlot3D0.getLegendLabelGenerator();
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(pieSectionLabelGenerator8);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) 8, 100.0d);
        java.lang.Number number3 = xYDataItem2.getY();
        java.lang.Number number4 = xYDataItem2.getY();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 100.0d + "'", number3.equals(100.0d));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100.0d + "'", number4.equals(100.0d));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeMinorGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer(10);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint6 = categoryAxis3D5.getLabelPaint();
        categoryAxis3D5.setTickMarkInsideLength((float) 0);
        categoryAxis3D5.addCategoryLabelToolTip((java.lang.Comparable) 1, "series");
        int int12 = categoryPlot0.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D5);
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot0.getRangeAxisLocation();
        categoryPlot0.setRangeCrosshairVisible(false);
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) 0.0f);
        java.lang.Object obj19 = valueMarker18.clone();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType20 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        valueMarker18.setLabelOffsetType(lengthAdjustmentType20);
        org.jfree.chart.util.Layer layer22 = null;
        boolean boolean23 = categoryPlot0.removeRangeMarker(4, (org.jfree.chart.plot.Marker) valueMarker18, layer22);
        double[] doubleArray30 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray35 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray36 = new double[][] { doubleArray30, doubleArray35 };
        org.jfree.data.category.CategoryDataset categoryDataset37 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray36);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot38 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset37);
        org.jfree.data.category.CategoryDataset categoryDataset39 = multiplePiePlot38.getDataset();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = categoryPlot0.getRendererForDataset(categoryDataset39);
        org.jfree.data.Range range42 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset39, (double) 1546329600000L);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(lengthAdjustmentType20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(categoryDataset37);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNull(categoryItemRenderer40);
        org.junit.Assert.assertNotNull(range42);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean3 = range1.contains(0.0d);
        org.jfree.data.Range range6 = org.jfree.data.Range.expand(range1, (double) ' ', (double) 2.0f);
        org.jfree.data.Range range8 = org.jfree.data.Range.shift(range1, (double) (short) 0);
        org.jfree.data.Range range11 = org.jfree.data.Range.expand(range1, (double) 1099412556013L, 3.0d);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D12.centerRange((-1.0d));
        java.awt.Paint paint15 = numberAxis3D12.getTickLabelPaint();
        float float16 = numberAxis3D12.getTickMarkInsideLength();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D17.centerRange((-1.0d));
        java.awt.Paint paint20 = numberAxis3D17.getTickLabelPaint();
        org.jfree.data.Range range21 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double22 = range21.getLength();
        numberAxis3D17.setRangeWithMargins(range21, false, false);
        double double27 = range21.constrain(0.0d);
        numberAxis3D12.setRangeWithMargins(range21, true, false);
        org.jfree.data.Range range32 = org.jfree.data.Range.shift(range21, 5.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint33 = new org.jfree.chart.block.RectangleConstraint(range11, range21);
        boolean boolean34 = blockBorder0.equals((java.lang.Object) range21);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint36 = new org.jfree.chart.block.RectangleConstraint(range21, 0.0d);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.0f + "'", float16 == 0.0f);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 1, (double) 100.0f);
        flowArrangement4.clear();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(28);
        boolean boolean8 = flowArrangement4.equals((java.lang.Object) xYStepAreaRenderer7);
        xYStepAreaRenderer7.setSeriesVisible(68, (java.lang.Boolean) false);
        java.awt.Font font13 = xYStepAreaRenderer7.getSeriesItemLabelFont((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(font13);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getNumberInstance();
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getNumberInstance();
        java.lang.String str4 = numberFormat2.format((long) 1);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator5 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("RectangleAnchor.TOP_RIGHT", numberFormat1, numberFormat2);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "1" + "'", str4.equals("1"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0.0f);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer2 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean3 = xYAreaRenderer2.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer2.setLegendItemToolTipGenerator(xYSeriesLabelGenerator4);
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYAreaRenderer2.setSeriesStroke(3, stroke7);
        valueMarker1.setStroke(stroke7);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = valueMarker1.getLabelOffset();
        double double12 = rectangleInsets10.calculateTopOutset(0.0d);
        double double14 = rectangleInsets10.calculateTopInset((double) 43629L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.0d + "'", double12 == 3.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.0d + "'", double14 == 3.0d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        double double4 = barRenderer3D2.getXOffset();
        barRenderer3D2.setBase((double) (short) 10);
        java.awt.Stroke stroke10 = barRenderer3D2.getItemOutlineStroke(2147483647, (-460), true);
        barRenderer3D2.setShadowYOffset(10.0d);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.099412556013E12d + "'", double4 == 1.099412556013E12d);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer3D2.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean6 = xYAreaRenderer5.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator7 = null;
        xYAreaRenderer5.setLegendItemToolTipGenerator(xYSeriesLabelGenerator7);
        boolean boolean9 = xYAreaRenderer5.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        xYAreaRenderer5.setSeriesToolTipGenerator((int) (short) 100, xYToolTipGenerator11);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = xYAreaRenderer5.getNegativeItemLabelPosition(100, (int) (byte) -1, false);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor17 = itemLabelPosition16.getItemLabelAnchor();
        barRenderer3D2.setBasePositiveItemLabelPosition(itemLabelPosition16);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = barRenderer3D2.getPlot();
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(itemLabelAnchor17);
        org.junit.Assert.assertNull(categoryPlot19);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        java.lang.Comparable[] comparableArray0 = new java.lang.Comparable[] {};
        org.jfree.data.xy.XYDataItem xYDataItem3 = new org.jfree.data.xy.XYDataItem((double) 8, 100.0d);
        double double4 = xYDataItem3.getYValue();
        double double5 = xYDataItem3.getXValue();
        java.lang.Comparable[] comparableArray6 = new java.lang.Comparable[] { double5 };
        double[][] doubleArray7 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset8 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray0, comparableArray6, doubleArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(comparableArray0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 100.0d + "'", double4 == 100.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 8.0d + "'", double5 == 8.0d);
        org.junit.Assert.assertNotNull(comparableArray6);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("TextBlockAnchor.CENTER");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo6 = new org.jfree.chart.ui.BasicProjectInfo("", "series", "series", "hi!");
        boolean boolean7 = standardChartTheme1.equals((java.lang.Object) "");
        java.awt.Font font8 = standardChartTheme1.getSmallFont();
        java.awt.Paint paint9 = standardChartTheme1.getPlotOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("TextBlockAnchor.CENTER");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo6 = new org.jfree.chart.ui.BasicProjectInfo("", "series", "series", "hi!");
        boolean boolean7 = standardChartTheme1.equals((java.lang.Object) "");
        java.awt.Font font8 = standardChartTheme1.getSmallFont();
        org.jfree.chart.plot.PiePlot3D piePlot3D9 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator10 = null;
        piePlot3D9.setLabelGenerator(pieSectionLabelGenerator10);
        piePlot3D9.setShadowXOffset(0.0d);
        piePlot3D9.setCircular(true);
        java.awt.Font font16 = piePlot3D9.getLabelFont();
        piePlot3D9.clearSectionOutlinePaints(true);
        java.awt.Font font19 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        piePlot3D9.setLabelFont(font19);
        boolean boolean21 = standardChartTheme1.equals((java.lang.Object) piePlot3D9);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0.0f);
        java.lang.Object obj2 = valueMarker1.clone();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        valueMarker1.setLabelOffsetType(lengthAdjustmentType3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.data.Range range8 = combinedDomainXYPlot6.getDataRange(valueAxis7);
        valueMarker1.addChangeListener((org.jfree.chart.event.MarkerChangeListener) combinedDomainXYPlot6);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection14 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries18.clear();
        timeSeries18.setDescription("series");
        int int22 = timeSeriesCollection14.indexOf(timeSeries18);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer24 = null;
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection14, (org.jfree.chart.axis.ValueAxis) numberAxis23, polarItemRenderer24);
        org.jfree.chart.plot.PlotOrientation plotOrientation26 = polarPlot25.getOrientation();
        java.awt.Paint paint27 = polarPlot25.getRadiusGridlinePaint();
        org.jfree.chart.block.BlockBorder blockBorder28 = new org.jfree.chart.block.BlockBorder(0.5d, (double) 0, (double) 172800000L, (double) 2.0f, paint27);
        valueMarker1.setLabelPaint(paint27);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(lengthAdjustmentType3);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation26);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.centerRange((-1.0d));
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.next();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month6.next();
        org.jfree.chart.axis.PeriodAxis periodAxis9 = new org.jfree.chart.axis.PeriodAxis("java.awt.Color[r=255,g=128,b=128]", regularTimePeriod5, regularTimePeriod8);
        java.awt.Paint paint10 = periodAxis9.getMinorTickMarkPaint();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D11.centerRange((-1.0d));
        java.awt.Paint paint14 = numberAxis3D11.getTickLabelPaint();
        org.jfree.data.Range range15 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double16 = range15.getLength();
        numberAxis3D11.setRangeWithMargins(range15, false, false);
        periodAxis9.setRange(range15, false, false);
        numberAxis3D0.setRange(range15);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("1");
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 1, (double) 100.0f);
        flowArrangement4.clear();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(28);
        boolean boolean8 = flowArrangement4.equals((java.lang.Object) xYStepAreaRenderer7);
        java.lang.Object obj9 = xYStepAreaRenderer7.clone();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        org.jfree.chart.LegendItem legendItem6 = barRenderer3D2.getLegendItem((int) (byte) 1, 1);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        java.lang.String str11 = timeSeries10.getDomainDescription();
        java.lang.Class class12 = timeSeries10.getTimePeriodClass();
        boolean boolean13 = barRenderer3D2.equals((java.lang.Object) class12);
        int int14 = barRenderer3D2.getPassCount();
        double double15 = barRenderer3D2.getYOffset();
        barRenderer3D2.setSeriesVisible(4, (java.lang.Boolean) false, true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNull(legendItem6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "series" + "'", str11.equals("series"));
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, 1900);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint3 = categoryAxis3D2.getLabelPaint();
        categoryAxis3D2.setTickMarkInsideLength((float) 0);
        java.awt.Font font6 = categoryAxis3D2.getLabelFont();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.lang.Class<?> wildcardClass12 = stroke11.getClass();
        boolean boolean13 = verticalAlignment10.equals((java.lang.Object) stroke11);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double16 = rectangleInsets14.calculateTopInset(10.0d);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font6, (java.awt.Paint) color7, rectangleEdge8, horizontalAlignment9, verticalAlignment10, rectangleInsets14);
        boolean boolean18 = textTitle17.visible;
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = null;
        piePlot3D1.setLabelGenerator(pieSectionLabelGenerator2);
        piePlot3D1.setShadowXOffset(0.0d);
        double double6 = piePlot3D1.getDepthFactor();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis9);
        int int11 = combinedDomainXYPlot10.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot10.rendererChanged(rendererChangeEvent13);
        combinedDomainXYPlot8.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot10);
        combinedDomainXYPlot10.setDomainMinorGridlinesVisible(true);
        boolean boolean18 = combinedDomainXYPlot10.isRangeCrosshairLockedOnData();
        java.awt.Paint paint19 = null;
        combinedDomainXYPlot10.setRangeTickBandPaint(paint19);
        java.awt.Paint paint21 = combinedDomainXYPlot10.getRangeCrosshairPaint();
        piePlot3D1.setBackgroundPaint(paint21);
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("35", paint21);
        java.awt.Stroke stroke24 = legendItem23.getOutlineStroke();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.12d + "'", double6 == 0.12d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator2 = null;
        xYAreaRenderer0.setLegendItemToolTipGenerator(xYSeriesLabelGenerator2);
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYAreaRenderer0.setSeriesStroke(3, stroke5);
        boolean boolean10 = xYAreaRenderer0.isItemLabelVisible((int) (short) 1, (int) (byte) 100, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range12 = xYAreaRenderer0.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        xYAreaRenderer0.setBaseItemLabelsVisible(true);
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator16 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("series");
        xYAreaRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.XYSeriesLabelGenerator) standardXYSeriesLabelGenerator16);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection18 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range20 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection18, true);
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection18, false);
        xYSeriesCollection18.clearSelection();
        try {
            java.lang.String str25 = standardXYSeriesLabelGenerator16.generateLabel((org.jfree.data.xy.XYDataset) xYSeriesCollection18, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertNull(range22);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        java.util.List list2 = combinedRangeXYPlot1.getSubplots();
        combinedRangeXYPlot1.setGap(1.0d);
        combinedRangeXYPlot1.setGap((double) 900000L);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D8 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection9 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection9, true);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer14 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean15 = xYAreaRenderer14.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator16 = null;
        xYAreaRenderer14.setLegendItemToolTipGenerator(xYSeriesLabelGenerator16);
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection9, valueAxis12, valueAxis13, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer14);
        boolean boolean19 = xYAreaRenderer14.isOutline();
        java.awt.Font font21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYAreaRenderer14.setSeriesItemLabelFont(100, font21);
        piePlot3D8.setLabelFont(font21);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = piePlot3D8.getSimpleLabelOffset();
        org.jfree.chart.plot.PiePlot3D piePlot3D25 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        piePlot3D25.setSimpleLabelOffset(rectangleInsets26);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection28 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries32.clear();
        timeSeries32.setDescription("series");
        int int36 = timeSeriesCollection28.indexOf(timeSeries32);
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer38 = null;
        org.jfree.chart.plot.PolarPlot polarPlot39 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection28, (org.jfree.chart.axis.ValueAxis) numberAxis37, polarItemRenderer38);
        org.jfree.chart.plot.PlotOrientation plotOrientation40 = polarPlot39.getOrientation();
        java.awt.Paint paint41 = polarPlot39.getRadiusGridlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer45 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean46 = xYAreaRenderer45.isOutline();
        java.awt.Shape shape47 = xYAreaRenderer45.getBaseShape();
        java.awt.Color color48 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic49 = new org.jfree.chart.title.LegendGraphic(shape47, (java.awt.Paint) color48);
        legendGraphic49.setWidth((double) 8);
        java.awt.Graphics2D graphics2D52 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint55 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D56 = legendGraphic49.arrange(graphics2D52, rectangleConstraint55);
        double double57 = legendGraphic49.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor58 = legendGraphic49.getShapeLocation();
        java.awt.geom.Rectangle2D rectangle2D59 = legendGraphic49.getBounds();
        rectangleInsets44.trim(rectangle2D59);
        java.awt.Point point61 = polarPlot39.translateValueThetaRadiusToJava2D((double) (-1.0f), (double) (short) 100, rectangle2D59);
        java.awt.geom.Rectangle2D rectangle2D62 = rectangleInsets26.createInsetRectangle(rectangle2D59);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType63 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType64 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str65 = lengthAdjustmentType64.toString();
        java.awt.geom.Rectangle2D rectangle2D66 = rectangleInsets24.createAdjustedRectangle(rectangle2D62, lengthAdjustmentType63, lengthAdjustmentType64);
        try {
            combinedRangeXYPlot1.drawBackground(graphics2D7, rectangle2D62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation40);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(size2D56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor58);
        org.junit.Assert.assertNotNull(rectangle2D59);
        org.junit.Assert.assertNotNull(point61);
        org.junit.Assert.assertNotNull(rectangle2D62);
        org.junit.Assert.assertNotNull(lengthAdjustmentType63);
        org.junit.Assert.assertNotNull(lengthAdjustmentType64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "NO_CHANGE" + "'", str65.equals("NO_CHANGE"));
        org.junit.Assert.assertNotNull(rectangle2D66);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        combinedDomainXYPlot1.select(generalPath3, rectangle2D4, renderingSource5);
        java.awt.Paint paint8 = combinedDomainXYPlot1.getQuadrantPaint((int) (short) 0);
        combinedDomainXYPlot1.clearAnnotations();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = combinedDomainXYPlot1.getDrawingSupplier();
        java.awt.geom.GeneralPath generalPath11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.RenderingSource renderingSource13 = null;
        combinedDomainXYPlot1.select(generalPath11, rectangle2D12, renderingSource13);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot17 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis16);
        int int18 = combinedDomainXYPlot17.getBackgroundImageAlignment();
        combinedDomainXYPlot17.setForegroundAlpha((float) (-1));
        org.jfree.chart.axis.AxisLocation axisLocation22 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        combinedDomainXYPlot17.setDomainAxisLocation((int) (short) 1, axisLocation22);
        combinedDomainXYPlot1.setRangeAxisLocation((int) (byte) 0, axisLocation22);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
        org.junit.Assert.assertNotNull(axisLocation22);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        int int4 = combinedDomainXYPlot3.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot3.rendererChanged(rendererChangeEvent6);
        combinedDomainXYPlot1.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot3);
        combinedDomainXYPlot3.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot12 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis11);
        int int13 = combinedDomainXYPlot12.getBackgroundImageAlignment();
        combinedDomainXYPlot12.setForegroundAlpha((float) (-1));
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        combinedDomainXYPlot12.setDomainAxisLocation((int) (short) 1, axisLocation17);
        org.jfree.chart.axis.AxisLocation axisLocation19 = axisLocation17.getOpposite();
        combinedDomainXYPlot3.setDomainAxisLocation(axisLocation19, false);
        org.jfree.chart.axis.AxisLocation axisLocation22 = axisLocation19.getOpposite();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(axisLocation22);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot3D0.setLabelGenerator(pieSectionLabelGenerator1);
        piePlot3D0.setShadowXOffset(0.0d);
        piePlot3D0.setCircular(true);
        java.awt.Font font7 = piePlot3D0.getLabelFont();
        piePlot3D0.clearSectionOutlinePaints(true);
        boolean boolean10 = piePlot3D0.getAutoPopulateSectionOutlineStroke();
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        boolean boolean6 = barRenderer3D2.isItemLabelVisible(0, 1900, false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment(date2);
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segment3.copy();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(segment3);
        org.junit.Assert.assertNotNull(segment4);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        combinedDomainXYPlot1.select(generalPath3, rectangle2D4, renderingSource5);
        java.awt.Paint paint8 = combinedDomainXYPlot1.getQuadrantPaint((int) (short) 0);
        combinedDomainXYPlot1.setBackgroundAlpha(0.0f);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = combinedDomainXYPlot1.getLegendItems();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D12.centerRange((-1.0d));
        java.awt.Paint paint15 = numberAxis3D12.getTickLabelPaint();
        float float16 = numberAxis3D12.getTickMarkInsideLength();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D17.centerRange((-1.0d));
        java.awt.Paint paint20 = numberAxis3D17.getTickLabelPaint();
        org.jfree.data.Range range21 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double22 = range21.getLength();
        numberAxis3D17.setRangeWithMargins(range21, false, false);
        double double27 = range21.constrain(0.0d);
        numberAxis3D12.setRangeWithMargins(range21, true, false);
        numberAxis3D12.setAutoTickUnitSelection(true, false);
        numberAxis3D12.setLowerBound((double) 1.0f);
        float float36 = numberAxis3D12.getMinorTickMarkOutsideLength();
        combinedDomainXYPlot1.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D12);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.0f + "'", float16 == 0.0f);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 2.0f + "'", float36 == 2.0f);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo1);
        org.jfree.chart.ui.ProjectInfo projectInfo3 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Image image4 = null;
        projectInfo3.setLogo(image4);
        projectInfo1.addLibrary((org.jfree.chart.ui.Library) projectInfo3);
        projectInfo1.addOptionalLibrary("java.awt.Color[r=255,g=128,b=128]");
        org.junit.Assert.assertNotNull(projectInfo1);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
        double[] doubleArray10 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray15 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray16 = new double[][] { doubleArray10, doubleArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray16);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity20 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "", "item", categoryDataset17, (java.lang.Comparable) "item", (java.lang.Comparable) "0");
        java.lang.Comparable comparable21 = categoryItemEntity20.getColumnKey();
        org.jfree.data.category.CategoryDataset categoryDataset22 = categoryItemEntity20.getDataset();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertTrue("'" + comparable21 + "' != '" + "0" + "'", comparable21.equals("0"));
        org.junit.Assert.assertNotNull(categoryDataset22);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        double double4 = barRenderer3D2.getXOffset();
        barRenderer3D2.setBase((double) (short) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke8 = categoryPlot7.getRangeMinorGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot7.getRenderer(10);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D12 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint13 = categoryAxis3D12.getLabelPaint();
        categoryAxis3D12.setTickMarkInsideLength((float) 0);
        categoryAxis3D12.addCategoryLabelToolTip((java.lang.Comparable) 1, "series");
        int int19 = categoryPlot7.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D12);
        double[] doubleArray26 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray31 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray32 = new double[][] { doubleArray26, doubleArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray32);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot34 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset33);
        org.jfree.data.category.CategoryDataset categoryDataset35 = multiplePiePlot34.getDataset();
        boolean boolean36 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset35);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = categoryPlot7.getRendererForDataset(categoryDataset35);
        barRenderer3D2.setPlot(categoryPlot7);
        boolean boolean39 = barRenderer3D2.getIncludeBaseInRange();
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.099412556013E12d + "'", double4 == 1.099412556013E12d);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(categoryItemRenderer37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getBaseShapesVisible();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        boolean boolean6 = xYLineAndShapeRenderer0.getUseFillPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        double double0 = org.jfree.chart.plot.PolarPlot.DEFAULT_ANGLE_TICK_UNIT_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 45.0d + "'", double0 == 45.0d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("Combined_Domain_XYPlot");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearAnnotations();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot0, jFreeChart4);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month9.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        org.jfree.chart.axis.PeriodAxis periodAxis12 = new org.jfree.chart.axis.PeriodAxis("java.awt.Color[r=255,g=128,b=128]", regularTimePeriod8, regularTimePeriod11);
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) "java.awt.Color[r=255,g=128,b=128]", true);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (-1), (float) (-460));
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = null;
        piePlot3D3.setLabelGenerator(pieSectionLabelGenerator4);
        piePlot3D3.setShadowXOffset(0.0d);
        piePlot3D3.setIgnoreZeroValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = piePlot3D3.getSimpleLabelOffset();
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) piePlot3D3, "RangeType.FULL", "35");
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity(shape2);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean6 = xYAreaRenderer5.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator7 = null;
        xYAreaRenderer5.setLegendItemToolTipGenerator(xYSeriesLabelGenerator7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis3, valueAxis4, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer5);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        xYPlot9.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) numberAxis3D11);
        java.awt.Paint paint14 = xYPlot9.getQuadrantPaint(0);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(paint14);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean6 = xYAreaRenderer5.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator7 = null;
        xYAreaRenderer5.setLegendItemToolTipGenerator(xYSeriesLabelGenerator7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis3, valueAxis4, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer5);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator10 = null;
        xYAreaRenderer5.setBaseToolTipGenerator(xYToolTipGenerator10);
        java.lang.Boolean boolean13 = xYAreaRenderer5.getSeriesVisible(1);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(boolean13);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        java.awt.Shape shape2 = xYAreaRenderer0.getBaseShape();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(0.0d, (double) (-1L));
        org.jfree.chart.util.Size2D size2D9 = legendGraphic4.arrange(graphics2D5, rectangleConstraint8);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint8.toFixedWidth((double) 100.0f);
        org.jfree.data.Range range12 = rectangleConstraint11.getHeightRange();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNull(range12);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = logAxis0.getTickUnit();
        double double3 = logAxis0.calculateValue((double) 60000L);
        double double4 = logAxis0.getSmallestValue();
        org.junit.Assert.assertNotNull(numberTickUnit1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.POSITIVE_INFINITY + "'", double3 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-100d + "'", double4 == 1.0E-100d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        org.jfree.data.xy.XYDataItem xYDataItem5 = new org.jfree.data.xy.XYDataItem((double) 8, 100.0d);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 100.0d, true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation8, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection2);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.chart.labels.StandardXYToolTipGenerator standardXYToolTipGenerator0 = new org.jfree.chart.labels.StandardXYToolTipGenerator();
        java.text.NumberFormat numberFormat1 = standardXYToolTipGenerator0.getXFormat();
        org.junit.Assert.assertNotNull(numberFormat1);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (byte) 0, year1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("TextBlockAnchor.CENTER");
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        standardChartTheme1.setLegendItemPaint((java.awt.Paint) color2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        standardChartTheme1.setCrosshairPaint((java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("RangeType.FULL");
        legendItem1.setDescription("");
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        org.jfree.chart.LegendItem legendItem6 = barRenderer3D2.getLegendItem((int) (byte) 1, 1);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = barRenderer3D2.getLegendItems();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement12 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment8, verticalAlignment9, (double) (byte) 1, (double) 100.0f);
        flowArrangement12.clear();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer15 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(28);
        boolean boolean16 = flowArrangement12.equals((java.lang.Object) xYStepAreaRenderer15);
        xYStepAreaRenderer15.setSeriesVisible(68, (java.lang.Boolean) false);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot22 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis21);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot24 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis23);
        int int25 = combinedDomainXYPlot24.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot24.rendererChanged(rendererChangeEvent27);
        combinedDomainXYPlot22.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot24);
        combinedDomainXYPlot24.setDomainMinorGridlinesVisible(true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D33 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D33.setUpperMargin((double) (short) 0);
        numberAxis3D33.resizeRange2((double) 10L, (double) 12);
        combinedDomainXYPlot24.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis3D33, false);
        org.jfree.data.xy.XYDataset xYDataset42 = combinedDomainXYPlot24.getDataset(4);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D43 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D43.setUpperMargin((double) (short) 0);
        numberAxis3D43.resizeRange2((double) 10L, (double) 12);
        numberAxis3D43.resizeRange((double) 15);
        org.jfree.chart.plot.Marker marker51 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection52 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries56 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries56.clear();
        timeSeries56.setDescription("series");
        int int60 = timeSeriesCollection52.indexOf(timeSeries56);
        org.jfree.chart.axis.NumberAxis numberAxis61 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer62 = null;
        org.jfree.chart.plot.PolarPlot polarPlot63 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection52, (org.jfree.chart.axis.ValueAxis) numberAxis61, polarItemRenderer62);
        org.jfree.chart.plot.PlotOrientation plotOrientation64 = polarPlot63.getOrientation();
        java.awt.Paint paint65 = polarPlot63.getRadiusGridlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets68 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer69 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean70 = xYAreaRenderer69.isOutline();
        java.awt.Shape shape71 = xYAreaRenderer69.getBaseShape();
        java.awt.Color color72 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic73 = new org.jfree.chart.title.LegendGraphic(shape71, (java.awt.Paint) color72);
        legendGraphic73.setWidth((double) 8);
        java.awt.Graphics2D graphics2D76 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint79 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D80 = legendGraphic73.arrange(graphics2D76, rectangleConstraint79);
        double double81 = legendGraphic73.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor82 = legendGraphic73.getShapeLocation();
        java.awt.geom.Rectangle2D rectangle2D83 = legendGraphic73.getBounds();
        rectangleInsets68.trim(rectangle2D83);
        java.awt.Point point85 = polarPlot63.translateValueThetaRadiusToJava2D((double) (-1.0f), (double) (short) 100, rectangle2D83);
        xYStepAreaRenderer15.drawDomainMarker(graphics2D20, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot24, (org.jfree.chart.axis.ValueAxis) numberAxis3D43, marker51, rectangle2D83);
        barRenderer3D2.setBaseLegendShape((java.awt.Shape) rectangle2D83);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNull(legendItem6);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 15 + "'", int25 == 15);
        org.junit.Assert.assertNull(xYDataset42);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation64);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(rectangleInsets68);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(shape71);
        org.junit.Assert.assertNotNull(color72);
        org.junit.Assert.assertNotNull(size2D80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor82);
        org.junit.Assert.assertNotNull(rectangle2D83);
        org.junit.Assert.assertNotNull(point85);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean2 = xYAreaRenderer1.isOutline();
        java.awt.Shape shape3 = xYAreaRenderer1.getBaseShape();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape3, (java.awt.Paint) color4);
        legendGraphic5.setWidth((double) 8);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D12 = legendGraphic5.arrange(graphics2D8, rectangleConstraint11);
        double double13 = legendGraphic5.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = legendGraphic5.getShapeLocation();
        java.awt.geom.Rectangle2D rectangle2D15 = legendGraphic5.getBounds();
        rectangleInsets0.trim(rectangle2D15);
        double[] doubleArray23 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray28 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray29 = new double[][] { doubleArray23, doubleArray28 };
        org.jfree.data.category.CategoryDataset categoryDataset30 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray29);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot31 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset30);
        java.lang.Number number32 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset30);
        org.jfree.data.general.PieDataset pieDataset34 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset30, 0);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset35 = new org.jfree.data.general.DefaultPieDataset((org.jfree.data.KeyedValues) pieDataset34);
        java.text.NumberFormat numberFormat39 = java.text.NumberFormat.getNumberInstance();
        java.lang.String str41 = numberFormat39.format(0.0d);
        boolean boolean42 = numberFormat39.isParseIntegerOnly();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit44 = new org.jfree.chart.axis.NumberTickUnit(3.0d, numberFormat39, 1900);
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity47 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D15, (org.jfree.data.general.PieDataset) defaultPieDataset35, (int) (short) -1, (int) '#', (java.lang.Comparable) 3.0d, "index.html", "0");
        org.jfree.data.general.PieDataset pieDataset48 = pieSectionEntity47.getDataset();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(categoryDataset30);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 1.0d + "'", number32.equals(1.0d));
        org.junit.Assert.assertNotNull(pieDataset34);
        org.junit.Assert.assertNotNull(numberFormat39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "0" + "'", str41.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(pieDataset48);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        java.lang.String str4 = timeSeries3.getDomainDescription();
        java.util.Collection collection5 = timeSeries3.getTimePeriods();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "series" + "'", str4.equals("series"));
        org.junit.Assert.assertNotNull(collection5);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorUp((double) 25200000L);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint3 = categoryAxis3D2.getLabelPaint();
        categoryAxis3D2.setTickMarkInsideLength((float) 0);
        java.awt.Font font6 = categoryAxis3D2.getLabelFont();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.lang.Class<?> wildcardClass12 = stroke11.getClass();
        boolean boolean13 = verticalAlignment10.equals((java.lang.Object) stroke11);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double16 = rectangleInsets14.calculateTopInset(10.0d);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font6, (java.awt.Paint) color7, rectangleEdge8, horizontalAlignment9, verticalAlignment10, rectangleInsets14);
        textTitle17.setToolTipText("TextBlockAnchor.CENTER");
        textTitle17.setToolTipText("Polar Plot");
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        combinedDomainXYPlot1.select(generalPath3, rectangle2D4, renderingSource5);
        java.awt.Paint paint8 = combinedDomainXYPlot1.getQuadrantPaint((int) (short) 0);
        combinedDomainXYPlot1.clearAnnotations();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = combinedDomainXYPlot1.getDrawingSupplier();
        java.awt.geom.GeneralPath generalPath11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.RenderingSource renderingSource13 = null;
        combinedDomainXYPlot1.select(generalPath11, rectangle2D12, renderingSource13);
        double double15 = combinedDomainXYPlot1.getRangeCrosshairValue();
        boolean boolean16 = combinedDomainXYPlot1.canSelectByRegion();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

//    @Test
//    public void test445() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test445");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        int int1 = segmentedTimeline0.getSegmentsExcluded();
//        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment(date2);
//        java.util.Date date4 = segment3.getDate();
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        int int6 = segmentedTimeline5.getSegmentsExcluded();
//        long long7 = segmentedTimeline5.getStartTime();
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline9 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        int int10 = segmentedTimeline9.getSegmentsExcluded();
//        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.chart.axis.SegmentedTimeline.Segment segment12 = segmentedTimeline9.getSegment(date11);
//        java.util.Date date13 = segment12.getDate();
//        long long14 = segmentedTimeline8.toTimelineValue(date13);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13);
//        org.jfree.chart.axis.SegmentedTimeline.Segment segment16 = segmentedTimeline5.getSegment(date13);
//        boolean boolean17 = segment3.before(segment16);
//        org.junit.Assert.assertNotNull(segmentedTimeline0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(segment3);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertNotNull(segmentedTimeline5);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 68 + "'", int6 == 68);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + (-2208927600000L) + "'", long7 == (-2208927600000L));
//        org.junit.Assert.assertNotNull(segmentedTimeline8);
//        org.junit.Assert.assertNotNull(segmentedTimeline9);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 68 + "'", int10 == 68);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(segment12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1099412556013L + "'", long14 == 1099412556013L);
//        org.junit.Assert.assertNotNull(segment16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot1.rendererChanged(rendererChangeEvent4);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = null;
        combinedDomainXYPlot1.setDrawingSupplier(drawingSupplier6, false);
        combinedDomainXYPlot1.setDomainZeroBaselineVisible(true);
        boolean boolean11 = combinedDomainXYPlot1.isDomainCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        xYSeriesCollection0.removeAllSeries();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = null;
        xYSeriesCollection0.seriesChanged(seriesChangeEvent2);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState4 = xYSeriesCollection0.getSelectionState();
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState5 = xYSeriesCollection0.getSelectionState();
        org.junit.Assert.assertNotNull(xYDatasetSelectionState4);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState5);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = logAxis0.getTickLabelInsets();
        logAxis0.configure();
        org.junit.Assert.assertNotNull(rectangleInsets1);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.08d + "'", double0 == 0.08d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker1);
        org.jfree.chart.plot.Marker marker3 = markerChangeEvent2.getMarker();
        org.jfree.chart.plot.Marker marker4 = markerChangeEvent2.getMarker();
        org.jfree.chart.text.TextAnchor textAnchor5 = marker4.getLabelTextAnchor();
        org.junit.Assert.assertNotNull(marker3);
        org.junit.Assert.assertNotNull(marker4);
        org.junit.Assert.assertNotNull(textAnchor5);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) projectInfo0);
        org.junit.Assert.assertNotNull(projectInfo0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getBaseShapesVisible();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        boolean boolean6 = xYLineAndShapeRenderer0.getBaseShapesFilled();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        double[] doubleArray6 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray11 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray12 = new double[][] { doubleArray6, doubleArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        java.lang.Number number15 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset13);
        org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset13, 0);
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot(pieDataset17);
        java.awt.Stroke stroke19 = ringPlot18.getSeparatorStroke();
        ringPlot18.setSectionDepth((double) 0.5f);
        double double22 = ringPlot18.getOuterSeparatorExtension();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1.0d + "'", number15.equals(1.0d));
        org.junit.Assert.assertNotNull(pieDataset17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.2d + "'", double22 == 0.2d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.lang.String str1 = color0.toString();
        java.awt.image.ColorModel colorModel2 = null;
        java.awt.Rectangle rectangle3 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D4 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection5 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection5, true);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer10 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean11 = xYAreaRenderer10.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator12 = null;
        xYAreaRenderer10.setLegendItemToolTipGenerator(xYSeriesLabelGenerator12);
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection5, valueAxis8, valueAxis9, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer10);
        boolean boolean15 = xYAreaRenderer10.isOutline();
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYAreaRenderer10.setSeriesItemLabelFont(100, font17);
        piePlot3D4.setLabelFont(font17);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = piePlot3D4.getSimpleLabelOffset();
        org.jfree.chart.plot.PiePlot3D piePlot3D21 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        piePlot3D21.setSimpleLabelOffset(rectangleInsets22);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection24 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries28.clear();
        timeSeries28.setDescription("series");
        int int32 = timeSeriesCollection24.indexOf(timeSeries28);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer34 = null;
        org.jfree.chart.plot.PolarPlot polarPlot35 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection24, (org.jfree.chart.axis.ValueAxis) numberAxis33, polarItemRenderer34);
        org.jfree.chart.plot.PlotOrientation plotOrientation36 = polarPlot35.getOrientation();
        java.awt.Paint paint37 = polarPlot35.getRadiusGridlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer41 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean42 = xYAreaRenderer41.isOutline();
        java.awt.Shape shape43 = xYAreaRenderer41.getBaseShape();
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic45 = new org.jfree.chart.title.LegendGraphic(shape43, (java.awt.Paint) color44);
        legendGraphic45.setWidth((double) 8);
        java.awt.Graphics2D graphics2D48 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint51 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D52 = legendGraphic45.arrange(graphics2D48, rectangleConstraint51);
        double double53 = legendGraphic45.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor54 = legendGraphic45.getShapeLocation();
        java.awt.geom.Rectangle2D rectangle2D55 = legendGraphic45.getBounds();
        rectangleInsets40.trim(rectangle2D55);
        java.awt.Point point57 = polarPlot35.translateValueThetaRadiusToJava2D((double) (-1.0f), (double) (short) 100, rectangle2D55);
        java.awt.geom.Rectangle2D rectangle2D58 = rectangleInsets22.createInsetRectangle(rectangle2D55);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType59 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType60 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str61 = lengthAdjustmentType60.toString();
        java.awt.geom.Rectangle2D rectangle2D62 = rectangleInsets20.createAdjustedRectangle(rectangle2D58, lengthAdjustmentType59, lengthAdjustmentType60);
        java.awt.geom.AffineTransform affineTransform63 = null;
        java.awt.RenderingHints renderingHints64 = null;
        java.awt.PaintContext paintContext65 = color0.createContext(colorModel2, rectangle3, rectangle2D58, affineTransform63, renderingHints64);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=0,g=192,b=192]" + "'", str1.equals("java.awt.Color[r=0,g=192,b=192]"));
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(size2D52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor54);
        org.junit.Assert.assertNotNull(rectangle2D55);
        org.junit.Assert.assertNotNull(point57);
        org.junit.Assert.assertNotNull(rectangle2D58);
        org.junit.Assert.assertNotNull(lengthAdjustmentType59);
        org.junit.Assert.assertNotNull(lengthAdjustmentType60);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "NO_CHANGE" + "'", str61.equals("NO_CHANGE"));
        org.junit.Assert.assertNotNull(rectangle2D62);
        org.junit.Assert.assertNotNull(paintContext65);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.NumberTick numberTick11 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (short) 10, "series", textAnchor8, textAnchor9, (double) (short) 10);
        org.jfree.chart.text.TextAnchor textAnchor12 = numberTick11.getRotationAnchor();
        try {
            java.awt.Shape shape13 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("java.awt.Color[r=0,g=192,b=192]", graphics2D1, (float) 8, (float) (-2208927600000L), textAnchor4, (double) 86400000L, textAnchor12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertNotNull(textAnchor12);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement0.clear();
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean6 = xYAreaRenderer5.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator7 = null;
        xYAreaRenderer5.setLegendItemToolTipGenerator(xYSeriesLabelGenerator7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis3, valueAxis4, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer5);
        boolean boolean10 = xYAreaRenderer5.isOutline();
        java.awt.Font font12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYAreaRenderer5.setSeriesItemLabelFont(100, font12);
        boolean boolean15 = xYAreaRenderer5.isSeriesItemLabelsVisible((int) (short) 10);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot17 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis16);
        int int18 = combinedDomainXYPlot17.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.RenderingSource renderingSource21 = null;
        combinedDomainXYPlot17.select(generalPath19, rectangle2D20, renderingSource21);
        java.awt.Paint paint24 = combinedDomainXYPlot17.getQuadrantPaint((int) (short) 0);
        combinedDomainXYPlot17.setBackgroundAlpha(0.0f);
        java.awt.Paint paint27 = combinedDomainXYPlot17.getRangeGridlinePaint();
        xYAreaRenderer5.setBaseFillPaint(paint27);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 15 + "'", int18 == 15);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        double double2 = combinedRangeXYPlot1.getGap();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis3);
        java.awt.Paint paint5 = combinedDomainXYPlot4.getBackgroundPaint();
        combinedRangeXYPlot1.addChangeListener((org.jfree.chart.event.PlotChangeListener) combinedDomainXYPlot4);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = combinedRangeXYPlot1.getRangeMarkers(layer7);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer9 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean10 = xYAreaRenderer9.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator11 = null;
        xYAreaRenderer9.setLegendItemToolTipGenerator(xYSeriesLabelGenerator11);
        boolean boolean13 = xYAreaRenderer9.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator15 = null;
        xYAreaRenderer9.setSeriesToolTipGenerator((int) (short) 100, xYToolTipGenerator15);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator17 = xYAreaRenderer9.getBaseToolTipGenerator();
        combinedRangeXYPlot1.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer9);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.0d + "'", double2 == 5.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(xYToolTipGenerator17);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor1 = org.jfree.data.time.TimePeriodAnchor.END;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint4 = categoryAxis3D3.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D3, jFreeChart5, (int) (short) 1, (int) (short) 10);
        boolean boolean9 = timePeriodAnchor1.equals((java.lang.Object) (short) 10);
        timeSeriesCollection0.setXPosition(timePeriodAnchor1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate11 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        java.util.List list12 = timeSeriesCollection0.getSeries();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries16.clear();
        timeSeries16.setDescription("series");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection20 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries24.clear();
        timeSeries24.setDescription("series");
        int int28 = timeSeriesCollection20.indexOf(timeSeries24);
        java.lang.String str29 = timeSeries24.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries16.addAndOrUpdate(timeSeries24);
        int int31 = timeSeriesCollection0.indexOf(timeSeries16);
        org.jfree.data.Range range32 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        try {
            int[] intArray35 = timeSeriesCollection0.getSurroundingItems(4, (-2208927600000L));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (4).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodAnchor1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNull(range32);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.lang.Object obj1 = xYLineAndShapeRenderer0.clone();
        try {
            xYLineAndShapeRenderer0.setSeriesVisibleInLegend(2147483647, (java.lang.Boolean) true);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        java.awt.Shape shape2 = xYAreaRenderer0.getBaseShape();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        legendGraphic4.setWidth((double) 8);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D11 = legendGraphic4.arrange(graphics2D7, rectangleConstraint10);
        double double12 = legendGraphic4.getHeight();
        boolean boolean13 = legendGraphic4.isShapeVisible();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator15 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator16 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer17 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a', xYToolTipGenerator15, xYURLGenerator16);
        java.awt.Stroke stroke18 = xYAreaRenderer17.getBaseOutlineStroke();
        legendGraphic4.setLineStroke(stroke18);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(size2D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        java.awt.Shape shape2 = xYAreaRenderer0.getBaseShape();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        legendGraphic4.setWidth((double) 8);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D11 = legendGraphic4.arrange(graphics2D7, rectangleConstraint10);
        double double12 = legendGraphic4.getHeight();
        boolean boolean13 = legendGraphic4.isShapeVisible();
        java.awt.Shape shape14 = legendGraphic4.getLine();
        java.lang.Object obj15 = legendGraphic4.clone();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(size2D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(shape14);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator1 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("hi!");
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearAnnotations();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = null;
        categoryPlot0.axisChanged(axisChangeEvent4);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNull(axisSpace3);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        double double4 = barRenderer3D2.getXOffset();
        barRenderer3D2.setBase((double) (short) 10);
        java.awt.Stroke stroke10 = barRenderer3D2.getItemOutlineStroke(2147483647, (-460), true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer12 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint13 = xYAreaRenderer12.getBaseLegendTextPaint();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator14 = null;
        xYAreaRenderer12.setBaseItemLabelGenerator(xYItemLabelGenerator14, true);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot18 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis17);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.data.Range range20 = combinedDomainXYPlot18.getDataRange(valueAxis19);
        java.lang.Object obj21 = null;
        boolean boolean22 = combinedDomainXYPlot18.equals(obj21);
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        combinedDomainXYPlot18.setRangeGridlineStroke(stroke23);
        xYAreaRenderer12.setBaseOutlineStroke(stroke23);
        java.awt.Font font29 = xYAreaRenderer12.getItemLabelFont((int) (short) 100, 12, false);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.block.LabelBlock labelBlock31 = new org.jfree.chart.block.LabelBlock("35", font29, (java.awt.Paint) color30);
        barRenderer3D2.setBaseItemLabelFont(font29, false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.099412556013E12d + "'", double4 == 1.099412556013E12d);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNull(range20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(color30);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        combinedDomainXYPlot1.setForegroundAlpha((float) (-1));
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        combinedDomainXYPlot1.setDomainAxisLocation((int) (short) 1, axisLocation6);
        combinedDomainXYPlot1.setWeight(1);
        java.lang.Class<?> wildcardClass10 = combinedDomainXYPlot1.getClass();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor1 = org.jfree.data.time.TimePeriodAnchor.END;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint4 = categoryAxis3D3.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D3, jFreeChart5, (int) (short) 1, (int) (short) 10);
        boolean boolean9 = timePeriodAnchor1.equals((java.lang.Object) (short) 10);
        timeSeriesCollection0.setXPosition(timePeriodAnchor1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate11 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        java.util.List list12 = timeSeriesCollection0.getSeries();
        try {
            int int14 = timeSeriesCollection0.getItemCount(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (3).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodAnchor1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection1, true);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean7 = xYAreaRenderer6.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator8 = null;
        xYAreaRenderer6.setLegendItemToolTipGenerator(xYSeriesLabelGenerator8);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection1, valueAxis4, valueAxis5, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer6);
        boolean boolean11 = xYAreaRenderer6.isOutline();
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYAreaRenderer6.setSeriesItemLabelFont(100, font13);
        piePlot3D0.setLabelFont(font13);
        double double16 = piePlot3D0.getMaximumExplodePercent();
        piePlot3D0.setLabelLinksVisible(true);
        boolean boolean19 = piePlot3D0.isCircular();
        piePlot3D0.setLabelLinkMargin(0.0d);
        piePlot3D0.setPieIndex(15);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot3D0.setLabelGenerator(pieSectionLabelGenerator1);
        piePlot3D0.setShadowXOffset(0.0d);
        piePlot3D0.setCircular(true);
        java.awt.Font font7 = piePlot3D0.getLabelFont();
        piePlot3D0.clearSectionOutlinePaints(true);
        double double10 = piePlot3D0.getLabelLinkMargin();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator11 = null;
        piePlot3D0.setURLGenerator(pieURLGenerator11);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.025d + "'", double10 == 0.025d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        java.util.List list2 = combinedRangeXYPlot1.getSubplots();
        java.util.List list3 = combinedRangeXYPlot1.getSubplots();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace5 = categoryPlot4.getFixedDomainAxisSpace();
        categoryPlot4.clearAnnotations();
        org.jfree.chart.axis.AxisSpace axisSpace7 = categoryPlot4.getFixedRangeAxisSpace();
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot4.getRangeAxisLocation();
        combinedRangeXYPlot1.setRangeAxisLocation(axisLocation8);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNull(axisSpace5);
        org.junit.Assert.assertNull(axisSpace7);
        org.junit.Assert.assertNotNull(axisLocation8);
    }

//    @Test
//    public void test473() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test473");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        int int2 = segmentedTimeline1.getSegmentsExcluded();
//        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segmentedTimeline1.getSegment(date3);
//        java.util.Date date5 = segment4.getDate();
//        long long6 = segmentedTimeline0.toTimelineValue(date5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date5);
//        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis("35");
//        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = null;
//        dateAxis9.setTickUnit(dateTickUnit10, false, false);
//        org.jfree.chart.axis.Timeline timeline14 = dateAxis9.getTimeline();
//        java.util.TimeZone timeZone15 = dateAxis9.getTimeZone();
//        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone15;
//        java.util.Locale locale17 = null;
//        try {
//            org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date5, timeZone15, locale17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(segmentedTimeline0);
//        org.junit.Assert.assertNotNull(segmentedTimeline1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68 + "'", int2 == 68);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(segment4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1099412556013L + "'", long6 == 1099412556013L);
//        org.junit.Assert.assertNotNull(timeline14);
//        org.junit.Assert.assertNotNull(timeZone15);
//    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D4.setUpperMargin((double) (short) 0);
        numberAxis3D4.resizeRange2((double) 10L, (double) 12);
        combinedDomainXYPlot1.setRangeAxis(8, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, true);
        java.lang.Object obj12 = numberAxis3D4.clone();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        int int4 = combinedDomainXYPlot3.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot3.rendererChanged(rendererChangeEvent6);
        combinedDomainXYPlot1.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot3);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = combinedDomainXYPlot3.getDomainAxisEdge((int) (byte) 1);
        java.awt.Stroke stroke11 = combinedDomainXYPlot3.getRangeGridlineStroke();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis12);
        int int14 = combinedDomainXYPlot13.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot13.rendererChanged(rendererChangeEvent16);
        combinedDomainXYPlot3.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedDomainXYPlot13);
        java.awt.Paint paint19 = null;
        try {
            combinedDomainXYPlot13.setDomainCrosshairPaint(paint19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        java.util.List list2 = combinedRangeXYPlot1.getSubplots();
        java.lang.String str3 = combinedRangeXYPlot1.getPlotType();
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        combinedRangeXYPlot1.setOrientation(plotOrientation4);
        java.awt.Stroke stroke6 = null;
        try {
            combinedRangeXYPlot1.setRangeMinorGridlineStroke(stroke6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "Combined Range XYPlot" + "'", str3.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNotNull(plotOrientation4);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        org.jfree.data.time.Year year2 = month0.getYear();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3, true);
        org.jfree.data.Range range7 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3, false);
        int int8 = xYSeriesCollection3.getSeriesCount();
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D10.centerRange((-1.0d));
        java.awt.Paint paint13 = numberAxis3D10.getTickLabelPaint();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D14.setUpperMargin((double) (short) 0);
        numberAxis3D14.resizeRange2((double) 10L, (double) 12);
        numberAxis3D14.setAutoTickUnitSelection(false);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer22 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = null;
        xYAreaRenderer22.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition24);
        boolean boolean26 = xYAreaRenderer22.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D27 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D27.centerRange((-1.0d));
        java.awt.Paint paint30 = numberAxis3D27.getTickLabelPaint();
        xYAreaRenderer22.setBaseFillPaint(paint30, true);
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection3, (org.jfree.chart.axis.ValueAxis) numberAxis3D10, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer22);
        int int34 = year2.compareTo((java.lang.Object) numberAxis3D10);
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator2 = null;
        xYAreaRenderer0.setLegendItemToolTipGenerator(xYSeriesLabelGenerator2);
        boolean boolean4 = xYAreaRenderer0.getAutoPopulateSeriesStroke();
        xYAreaRenderer0.setBaseSeriesVisibleInLegend(true, true);
        xYAreaRenderer0.setSeriesItemLabelsVisible(8, (java.lang.Boolean) false);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer11 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean12 = xYAreaRenderer11.isOutline();
        java.awt.Shape shape13 = xYAreaRenderer11.getBaseShape();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic15 = new org.jfree.chart.title.LegendGraphic(shape13, (java.awt.Paint) color14);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint(0.0d, (double) (-1L));
        org.jfree.chart.util.Size2D size2D20 = legendGraphic15.arrange(graphics2D16, rectangleConstraint19);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D22 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint23 = categoryAxis3D22.getLabelPaint();
        categoryAxis3D22.setTickMarkInsideLength((float) 0);
        java.awt.Font font26 = categoryAxis3D22.getLabelFont();
        boolean boolean27 = legendGraphic15.equals((java.lang.Object) categoryAxis3D22);
        java.awt.Color color29 = java.awt.Color.ORANGE;
        categoryAxis3D22.setTickLabelPaint((java.lang.Comparable) 1560495599999L, (java.awt.Paint) color29);
        xYAreaRenderer0.setBaseItemLabelPaint((java.awt.Paint) color29);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(size2D20);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(color29);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot3D0.setLabelGenerator(pieSectionLabelGenerator1);
        piePlot3D0.setShadowXOffset(0.0d);
        piePlot3D0.setCircular(true);
        java.awt.Font font7 = piePlot3D0.getLabelFont();
        piePlot3D0.clearSectionOutlinePaints(true);
        java.awt.Font font10 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        piePlot3D0.setLabelFont(font10);
        piePlot3D0.setShadowXOffset(0.0d);
        java.text.NumberFormat numberFormat15 = java.text.NumberFormat.getNumberInstance();
        java.lang.String str17 = numberFormat15.format(0.0d);
        java.text.NumberFormat numberFormat18 = java.text.NumberFormat.getNumberInstance();
        java.lang.String str20 = numberFormat18.format((long) 1);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator21 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Combined Range XYPlot", numberFormat15, numberFormat18);
        piePlot3D0.setLegendLabelGenerator((org.jfree.chart.labels.PieSectionLabelGenerator) standardPieSectionLabelGenerator21);
        java.text.AttributedString attributedString24 = null;
        standardPieSectionLabelGenerator21.setAttributedLabel(1, attributedString24);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(numberFormat15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
        org.junit.Assert.assertNotNull(numberFormat18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "1" + "'", str20.equals("1"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

//    @Test
//    public void test482() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test482");
//        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
//        timeSeries4.clear();
//        timeSeries4.setDescription("series");
//        int int8 = timeSeriesCollection0.indexOf(timeSeries4);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day9, (java.lang.Number) 12, false);
//        long long13 = day9.getLastMillisecond();
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
//        numberAxis3D14.setUpperMargin((double) (short) 0);
//        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_RED;
//        numberAxis3D14.setTickLabelPaint((java.awt.Paint) color17);
//        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis19);
//        int int21 = combinedDomainXYPlot20.getBackgroundImageAlignment();
//        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
//        combinedDomainXYPlot20.rendererChanged(rendererChangeEvent23);
//        org.jfree.chart.plot.DrawingSupplier drawingSupplier25 = null;
//        combinedDomainXYPlot20.setDrawingSupplier(drawingSupplier25, false);
//        numberAxis3D14.removeChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot20);
//        java.awt.Shape shape29 = numberAxis3D14.getDownArrow();
//        boolean boolean30 = numberAxis3D14.getAutoRangeIncludesZero();
//        int int31 = day9.compareTo((java.lang.Object) numberAxis3D14);
//        int int32 = day9.getDayOfMonth();
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560495599999L + "'", long13 == 1560495599999L);
//        org.junit.Assert.assertNotNull(color17);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 15 + "'", int21 == 15);
//        org.junit.Assert.assertNotNull(shape29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 13 + "'", int32 == 13);
//    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        double double2 = combinedRangeXYPlot1.getGap();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis3);
        java.awt.Paint paint5 = combinedDomainXYPlot4.getBackgroundPaint();
        combinedRangeXYPlot1.addChangeListener((org.jfree.chart.event.PlotChangeListener) combinedDomainXYPlot4);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection7 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection7, true);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection7, false);
        int int12 = xYSeriesCollection7.getSeriesCount();
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection7);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D14.centerRange((-1.0d));
        java.awt.Paint paint17 = numberAxis3D14.getTickLabelPaint();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D18.setUpperMargin((double) (short) 0);
        numberAxis3D18.resizeRange2((double) 10L, (double) 12);
        numberAxis3D18.setAutoTickUnitSelection(false);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer26 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = null;
        xYAreaRenderer26.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition28);
        boolean boolean30 = xYAreaRenderer26.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D31.centerRange((-1.0d));
        java.awt.Paint paint34 = numberAxis3D31.getTickLabelPaint();
        xYAreaRenderer26.setBaseFillPaint(paint34, true);
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection7, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, (org.jfree.chart.axis.ValueAxis) numberAxis3D18, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer26);
        combinedRangeXYPlot1.add(xYPlot37, (int) 'a');
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot42 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis41);
        int int43 = combinedDomainXYPlot42.getBackgroundImageAlignment();
        combinedDomainXYPlot42.setForegroundAlpha((float) (-1));
        org.jfree.chart.axis.AxisLocation axisLocation47 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        combinedDomainXYPlot42.setDomainAxisLocation((int) (short) 1, axisLocation47);
        xYPlot37.setDomainAxisLocation(0, axisLocation47, true);
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.RenderingSource renderingSource54 = null;
        xYPlot37.select((double) 172800000L, 5.0d, rectangle2D53, renderingSource54);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.0d + "'", double2 == 5.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 15 + "'", int43 == 15);
        org.junit.Assert.assertNotNull(axisLocation47);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.jfree.chart.ChartTheme chartTheme0 = org.jfree.chart.StandardChartTheme.createDarknessTheme();
        org.junit.Assert.assertNotNull(chartTheme0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int2 = segmentedTimeline1.getSegmentsExcluded();
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segmentedTimeline1.getSegment(date3);
        segmentedTimeline0.addBaseTimelineException(date3);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68 + "'", int2 == 68);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(segment4);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 1, (double) 100.0f);
        flowArrangement4.clear();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(28);
        boolean boolean8 = flowArrangement4.equals((java.lang.Object) xYStepAreaRenderer7);
        java.awt.Paint paint9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        boolean boolean10 = flowArrangement4.equals((java.lang.Object) paint9);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        java.util.List list2 = combinedRangeXYPlot1.getSubplots();
        java.util.List list3 = combinedRangeXYPlot1.getSubplots();
        combinedRangeXYPlot1.configureRangeAxes();
        combinedRangeXYPlot1.setRangeCrosshairValue((double) 1, true);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot9 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis8);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) combinedRangeXYPlot9);
        combinedRangeXYPlot1.plotChanged(plotChangeEvent10);
        java.awt.Stroke stroke12 = combinedRangeXYPlot1.getDomainZeroBaselineStroke();
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint2 = categoryAxis3D1.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent6 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D1, jFreeChart3, (int) (short) 1, (int) (short) 10);
        org.jfree.chart.JFreeChart jFreeChart7 = null;
        chartProgressEvent6.setChart(jFreeChart7);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        xYAreaRenderer0.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition2);
        boolean boolean4 = xYAreaRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D5.centerRange((-1.0d));
        java.awt.Paint paint8 = numberAxis3D5.getTickLabelPaint();
        xYAreaRenderer0.setBaseFillPaint(paint8, true);
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator11 = xYAreaRenderer0.getLegendItemURLGenerator();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(xYSeriesLabelGenerator11);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        double double4 = barRenderer3D2.getXOffset();
        int int5 = barRenderer3D2.getColumnCount();
        double double6 = barRenderer3D2.getBase();
        java.awt.Stroke stroke7 = barRenderer3D2.getBaseOutlineStroke();
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.099412556013E12d + "'", double4 == 1.099412556013E12d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        org.jfree.data.xy.XYDataItem xYDataItem5 = new org.jfree.data.xy.XYDataItem((double) 8, 100.0d);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 100.0d, true);
        java.awt.Stroke stroke8 = categoryPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        int int4 = combinedDomainXYPlot3.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot3.rendererChanged(rendererChangeEvent6);
        combinedDomainXYPlot1.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot3);
        org.jfree.chart.axis.AxisLocation axisLocation9 = combinedDomainXYPlot1.getRangeAxisLocation();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot13 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis12);
        java.util.List list14 = combinedRangeXYPlot13.getSubplots();
        java.util.List list15 = combinedRangeXYPlot13.getSubplots();
        combinedRangeXYPlot13.clearRangeAxes();
        int int17 = combinedRangeXYPlot13.getRangeAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection21 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries25.clear();
        timeSeries25.setDescription("series");
        int int29 = timeSeriesCollection21.indexOf(timeSeries25);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer31 = null;
        org.jfree.chart.plot.PolarPlot polarPlot32 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection21, (org.jfree.chart.axis.ValueAxis) numberAxis30, polarItemRenderer31);
        org.jfree.chart.plot.PlotOrientation plotOrientation33 = polarPlot32.getOrientation();
        java.awt.Paint paint34 = polarPlot32.getRadiusGridlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer38 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean39 = xYAreaRenderer38.isOutline();
        java.awt.Shape shape40 = xYAreaRenderer38.getBaseShape();
        java.awt.Color color41 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic42 = new org.jfree.chart.title.LegendGraphic(shape40, (java.awt.Paint) color41);
        legendGraphic42.setWidth((double) 8);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint48 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D49 = legendGraphic42.arrange(graphics2D45, rectangleConstraint48);
        double double50 = legendGraphic42.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor51 = legendGraphic42.getShapeLocation();
        java.awt.geom.Rectangle2D rectangle2D52 = legendGraphic42.getBounds();
        rectangleInsets37.trim(rectangle2D52);
        java.awt.Point point54 = polarPlot32.translateValueThetaRadiusToJava2D((double) (-1.0f), (double) (short) 100, rectangle2D52);
        combinedRangeXYPlot13.zoomRangeAxes(0.0d, (double) 1.0f, plotRenderingInfo20, (java.awt.geom.Point2D) point54);
        try {
            combinedDomainXYPlot1.zoomRangeAxes(0.18d, plotRenderingInfo11, (java.awt.geom.Point2D) point54, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertNotNull(list15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(size2D49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor51);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertNotNull(point54);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment(date2);
        java.util.Date date4 = segment3.getDate();
        boolean boolean7 = segment3.contains((long) '#', 86400000L);
        boolean boolean10 = segment3.contained(1L, (long) 0);
        boolean boolean13 = segment3.contained(61200000L, (long) (byte) 10);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(segment3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 1, (double) 100.0f);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = null;
        piePlot3D6.setLabelGenerator(pieSectionLabelGenerator7);
        piePlot3D6.setShadowXOffset(0.0d);
        piePlot3D6.setIgnoreZeroValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = piePlot3D6.getSimpleLabelOffset();
        blockContainer5.setPadding(rectangleInsets13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint(0.0d, (double) (-1L));
        org.jfree.chart.util.Size2D size2D19 = blockContainer5.arrange(graphics2D15, rectangleConstraint18);
        blockContainer5.clear();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer21 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean22 = xYAreaRenderer21.isOutline();
        java.awt.Shape shape23 = xYAreaRenderer21.getBaseShape();
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic25 = new org.jfree.chart.title.LegendGraphic(shape23, (java.awt.Paint) color24);
        legendGraphic25.setWidth((double) 8);
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D32 = legendGraphic25.arrange(graphics2D28, rectangleConstraint31);
        double double33 = legendGraphic25.getHeight();
        java.lang.Object obj34 = legendGraphic25.clone();
        blockContainer5.add((org.jfree.chart.block.Block) legendGraphic25);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(size2D19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(size2D32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(obj34);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getBaseShapesVisible();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(true);
        xYLineAndShapeRenderer0.setDrawOutlines(false);
        java.awt.Font font7 = xYLineAndShapeRenderer0.getLegendTextFont(10);
        boolean boolean9 = xYLineAndShapeRenderer0.isSeriesItemLabelsVisible((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNull(font7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.setDomainCrosshairVisible(false);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(axisSpace3);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator2 = null;
        xYAreaRenderer0.setLegendItemToolTipGenerator(xYSeriesLabelGenerator2);
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYAreaRenderer0.setSeriesStroke(3, stroke5);
        boolean boolean10 = xYAreaRenderer0.isItemLabelVisible((int) (short) 1, (int) (byte) 100, false);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range12 = xYAreaRenderer0.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNull(range13);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        java.awt.Paint paint3 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = categoryPlot0.getOrientation();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(plotOrientation4);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 1, (double) 100.0f);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = null;
        piePlot3D6.setLabelGenerator(pieSectionLabelGenerator7);
        piePlot3D6.setShadowXOffset(0.0d);
        piePlot3D6.setIgnoreZeroValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = piePlot3D6.getSimpleLabelOffset();
        blockContainer5.setPadding(rectangleInsets13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint(0.0d, (double) (-1L));
        org.jfree.chart.util.Size2D size2D19 = blockContainer5.arrange(graphics2D15, rectangleConstraint18);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer20 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean21 = xYAreaRenderer20.isOutline();
        java.awt.Shape shape22 = xYAreaRenderer20.getBaseShape();
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic24 = new org.jfree.chart.title.LegendGraphic(shape22, (java.awt.Paint) color23);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = new org.jfree.chart.block.RectangleConstraint(0.0d, (double) (-1L));
        org.jfree.chart.util.Size2D size2D29 = legendGraphic24.arrange(graphics2D25, rectangleConstraint28);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D31 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint32 = categoryAxis3D31.getLabelPaint();
        categoryAxis3D31.setTickMarkInsideLength((float) 0);
        java.awt.Font font35 = categoryAxis3D31.getLabelFont();
        boolean boolean36 = legendGraphic24.equals((java.lang.Object) categoryAxis3D31);
        java.awt.Stroke stroke37 = legendGraphic24.getOutlineStroke();
        org.jfree.chart.block.BlockBorder blockBorder42 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) '4', (double) 10L, (double) 100L);
        java.awt.Paint paint43 = blockBorder42.getPaint();
        legendGraphic24.setFrame((org.jfree.chart.block.BlockFrame) blockBorder42);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection45 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries49.clear();
        timeSeries49.setDescription("series");
        int int53 = timeSeriesCollection45.indexOf(timeSeries49);
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer55 = null;
        org.jfree.chart.plot.PolarPlot polarPlot56 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection45, (org.jfree.chart.axis.ValueAxis) numberAxis54, polarItemRenderer55);
        org.jfree.chart.plot.PlotOrientation plotOrientation57 = polarPlot56.getOrientation();
        java.awt.Paint paint58 = polarPlot56.getRadiusGridlinePaint();
        blockContainer5.add((org.jfree.chart.block.Block) legendGraphic24, (java.lang.Object) polarPlot56);
        org.jfree.chart.LegendItemCollection legendItemCollection60 = polarPlot56.getLegendItems();
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(size2D19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(size2D29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(stroke37);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation57);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(legendItemCollection60);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        org.jfree.chart.util.LineUtilities lineUtilities0 = new org.jfree.chart.util.LineUtilities();
    }
}

