import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        java.awt.Paint paint4 = combinedDomainXYPlot3.getBackgroundPaint();
        xYAreaRenderer0.setSeriesPaint(2, paint4);
        xYAreaRenderer0.setAutoPopulateSeriesPaint(false);
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        combinedDomainXYPlot1.setForegroundAlpha((float) (-1));
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis5);
        int int7 = combinedDomainXYPlot6.getBackgroundImageAlignment();
        combinedDomainXYPlot6.setForegroundAlpha((float) (-1));
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        combinedDomainXYPlot6.setDomainAxisLocation((int) (short) 1, axisLocation11);
        combinedDomainXYPlot1.setDomainAxisLocation(axisLocation11);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = combinedDomainXYPlot1.getRangeAxisEdge((int) (short) 100);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection16 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries20.clear();
        timeSeries20.setDescription("series");
        int int24 = timeSeriesCollection16.indexOf(timeSeries20);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer26 = null;
        org.jfree.chart.plot.PolarPlot polarPlot27 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection16, (org.jfree.chart.axis.ValueAxis) numberAxis25, polarItemRenderer26);
        boolean boolean28 = numberAxis25.isTickMarksVisible();
        combinedDomainXYPlot1.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis25);
        boolean boolean30 = combinedDomainXYPlot1.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 15 + "'", int7 == 15);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit(0.0d);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        boolean boolean3 = numberTickUnit1.equals((java.lang.Object) textBlockAnchor2);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getCurrencyInstance();
        numberFormat0.setMaximumIntegerDigits((int) (short) 10);
        int int3 = numberFormat0.getMaximumIntegerDigits();
        java.util.Currency currency4 = null;
        try {
            numberFormat0.setCurrency(currency4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test007");
//        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
//        timeSeries4.clear();
//        timeSeries4.setDescription("series");
//        int int8 = timeSeriesCollection0.indexOf(timeSeries4);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day9, (java.lang.Number) 12, false);
//        long long13 = day9.getLastMillisecond();
//        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
//        numberAxis3D14.setUpperMargin((double) (short) 0);
//        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_RED;
//        numberAxis3D14.setTickLabelPaint((java.awt.Paint) color17);
//        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
//        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis19);
//        int int21 = combinedDomainXYPlot20.getBackgroundImageAlignment();
//        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
//        combinedDomainXYPlot20.rendererChanged(rendererChangeEvent23);
//        org.jfree.chart.plot.DrawingSupplier drawingSupplier25 = null;
//        combinedDomainXYPlot20.setDrawingSupplier(drawingSupplier25, false);
//        numberAxis3D14.removeChangeListener((org.jfree.chart.event.AxisChangeListener) combinedDomainXYPlot20);
//        java.awt.Shape shape29 = numberAxis3D14.getDownArrow();
//        boolean boolean30 = numberAxis3D14.getAutoRangeIncludesZero();
//        int int31 = day9.compareTo((java.lang.Object) numberAxis3D14);
//        numberAxis3D14.setAutoRangeMinimumSize((double) (short) 100);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1560495599999L + "'", long13 == 1560495599999L);
//        org.junit.Assert.assertNotNull(color17);
//        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 15 + "'", int21 == 15);
//        org.junit.Assert.assertNotNull(shape29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
//    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) 8, 100.0d);
        double double3 = xYDataItem2.getYValue();
        java.lang.Number number4 = xYDataItem2.getX();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 8.0d + "'", number4.equals(8.0d));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer2 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean3 = xYAreaRenderer2.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer2.setLegendItemToolTipGenerator(xYSeriesLabelGenerator4);
        java.awt.Paint paint7 = xYAreaRenderer2.getSeriesPaint(2);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator9 = xYAreaRenderer2.getSeriesItemLabelGenerator(10);
        xYAreaRenderer2.setBaseCreateEntities(true, false);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment15 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement18 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment14, verticalAlignment15, (double) (byte) 1, (double) 100.0f);
        flowArrangement18.clear();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer21 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(28);
        boolean boolean22 = flowArrangement18.equals((java.lang.Object) xYStepAreaRenderer21);
        xYStepAreaRenderer21.setSeriesVisible(68, (java.lang.Boolean) false);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot28 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis27);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot30 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis29);
        int int31 = combinedDomainXYPlot30.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent33 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot30.rendererChanged(rendererChangeEvent33);
        combinedDomainXYPlot28.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot30);
        combinedDomainXYPlot30.setDomainMinorGridlinesVisible(true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D39 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D39.setUpperMargin((double) (short) 0);
        numberAxis3D39.resizeRange2((double) 10L, (double) 12);
        combinedDomainXYPlot30.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis3D39, false);
        org.jfree.data.xy.XYDataset xYDataset48 = combinedDomainXYPlot30.getDataset(4);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D49 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D49.setUpperMargin((double) (short) 0);
        numberAxis3D49.resizeRange2((double) 10L, (double) 12);
        numberAxis3D49.resizeRange((double) 15);
        org.jfree.chart.plot.Marker marker57 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection58 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries62 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries62.clear();
        timeSeries62.setDescription("series");
        int int66 = timeSeriesCollection58.indexOf(timeSeries62);
        org.jfree.chart.axis.NumberAxis numberAxis67 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer68 = null;
        org.jfree.chart.plot.PolarPlot polarPlot69 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection58, (org.jfree.chart.axis.ValueAxis) numberAxis67, polarItemRenderer68);
        org.jfree.chart.plot.PlotOrientation plotOrientation70 = polarPlot69.getOrientation();
        java.awt.Paint paint71 = polarPlot69.getRadiusGridlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets74 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer75 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean76 = xYAreaRenderer75.isOutline();
        java.awt.Shape shape77 = xYAreaRenderer75.getBaseShape();
        java.awt.Color color78 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic79 = new org.jfree.chart.title.LegendGraphic(shape77, (java.awt.Paint) color78);
        legendGraphic79.setWidth((double) 8);
        java.awt.Graphics2D graphics2D82 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint85 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D86 = legendGraphic79.arrange(graphics2D82, rectangleConstraint85);
        double double87 = legendGraphic79.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor88 = legendGraphic79.getShapeLocation();
        java.awt.geom.Rectangle2D rectangle2D89 = legendGraphic79.getBounds();
        rectangleInsets74.trim(rectangle2D89);
        java.awt.Point point91 = polarPlot69.translateValueThetaRadiusToJava2D((double) (-1.0f), (double) (short) 100, rectangle2D89);
        xYStepAreaRenderer21.drawDomainMarker(graphics2D26, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot30, (org.jfree.chart.axis.ValueAxis) numberAxis3D49, marker57, rectangle2D89);
        xYAreaRenderer2.setSeriesShape((int) '4', (java.awt.Shape) rectangle2D89, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo96 = null;
        org.jfree.chart.plot.CategoryCrosshairState categoryCrosshairState97 = null;
        boolean boolean98 = categoryPlot0.render(graphics2D1, rectangle2D89, 0, plotRenderingInfo96, categoryCrosshairState97);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNull(xYItemLabelGenerator9);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 15 + "'", int31 == 15);
        org.junit.Assert.assertNull(xYDataset48);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1) + "'", int66 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation70);
        org.junit.Assert.assertNotNull(paint71);
        org.junit.Assert.assertNotNull(rectangleInsets74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(shape77);
        org.junit.Assert.assertNotNull(color78);
        org.junit.Assert.assertNotNull(size2D86);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor88);
        org.junit.Assert.assertNotNull(rectangle2D89);
        org.junit.Assert.assertNotNull(point91);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, false);
        xYSeriesCollection0.clearSelection();
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        logAxis0.setBase((double) 100L);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D6 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint7 = categoryAxis3D6.getLabelPaint();
        categoryAxis3D6.setTickMarkInsideLength((float) 0);
        java.awt.Font font10 = categoryAxis3D6.getLabelFont();
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment14 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.lang.Class<?> wildcardClass16 = stroke15.getClass();
        boolean boolean17 = verticalAlignment14.equals((java.lang.Object) stroke15);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double20 = rectangleInsets18.calculateTopInset(10.0d);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font10, (java.awt.Paint) color11, rectangleEdge12, horizontalAlignment13, verticalAlignment14, rectangleInsets18);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent22 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle21);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D24 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        piePlot3D24.setSimpleLabelOffset(rectangleInsets25);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection27 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries31.clear();
        timeSeries31.setDescription("series");
        int int35 = timeSeriesCollection27.indexOf(timeSeries31);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer37 = null;
        org.jfree.chart.plot.PolarPlot polarPlot38 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection27, (org.jfree.chart.axis.ValueAxis) numberAxis36, polarItemRenderer37);
        org.jfree.chart.plot.PlotOrientation plotOrientation39 = polarPlot38.getOrientation();
        java.awt.Paint paint40 = polarPlot38.getRadiusGridlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets43 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer44 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean45 = xYAreaRenderer44.isOutline();
        java.awt.Shape shape46 = xYAreaRenderer44.getBaseShape();
        java.awt.Color color47 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic48 = new org.jfree.chart.title.LegendGraphic(shape46, (java.awt.Paint) color47);
        legendGraphic48.setWidth((double) 8);
        java.awt.Graphics2D graphics2D51 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint54 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D55 = legendGraphic48.arrange(graphics2D51, rectangleConstraint54);
        double double56 = legendGraphic48.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor57 = legendGraphic48.getShapeLocation();
        java.awt.geom.Rectangle2D rectangle2D58 = legendGraphic48.getBounds();
        rectangleInsets43.trim(rectangle2D58);
        java.awt.Point point60 = polarPlot38.translateValueThetaRadiusToJava2D((double) (-1.0f), (double) (short) 100, rectangle2D58);
        java.awt.geom.Rectangle2D rectangle2D61 = rectangleInsets25.createInsetRectangle(rectangle2D58);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D64 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator65 = barRenderer3D64.getLegendItemLabelGenerator();
        double double66 = barRenderer3D64.getXOffset();
        int int67 = barRenderer3D64.getColumnCount();
        java.lang.Object obj68 = textTitle21.draw(graphics2D23, rectangle2D58, (java.lang.Object) barRenderer3D64);
        org.jfree.chart.util.RectangleEdge rectangleEdge69 = org.jfree.chart.util.RectangleEdge.RIGHT;
        double double70 = logAxis0.exponentLengthToJava2D(0.18d, rectangle2D58, rectangleEdge69);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
        org.junit.Assert.assertNotNull(verticalAlignment14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation39);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(rectangleInsets43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(size2D55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor57);
        org.junit.Assert.assertNotNull(rectangle2D58);
        org.junit.Assert.assertNotNull(point60);
        org.junit.Assert.assertNotNull(rectangle2D61);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 1.099412556013E12d + "'", double66 == 1.099412556013E12d);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertNull(obj68);
        org.junit.Assert.assertNotNull(rectangleEdge69);
        org.junit.Assert.assertEquals((double) double70, Double.NaN, 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0.0f);
        java.lang.Object obj2 = valueMarker1.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double5 = rectangleInsets3.calculateTopInset(10.0d);
        double double7 = rectangleInsets3.calculateTopInset((double) (-1.0f));
        valueMarker1.setLabelOffset(rectangleInsets3);
        double double10 = rectangleInsets3.trimHeight(0.0d);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        int int4 = combinedDomainXYPlot3.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot3.rendererChanged(rendererChangeEvent6);
        combinedDomainXYPlot1.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot3);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = combinedDomainXYPlot3.getLegendItems();
        combinedDomainXYPlot3.setGap((double) '#');
        java.awt.Color color13 = java.awt.Color.BLACK;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer14 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint15 = xYAreaRenderer14.getBaseLegendTextPaint();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator16 = null;
        xYAreaRenderer14.setBaseItemLabelGenerator(xYItemLabelGenerator16, true);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis19);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.data.Range range22 = combinedDomainXYPlot20.getDataRange(valueAxis21);
        java.lang.Object obj23 = null;
        boolean boolean24 = combinedDomainXYPlot20.equals(obj23);
        java.awt.Stroke stroke25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        combinedDomainXYPlot20.setRangeGridlineStroke(stroke25);
        xYAreaRenderer14.setBaseOutlineStroke(stroke25);
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color13, stroke25);
        combinedDomainXYPlot3.setBackgroundPaint((java.awt.Paint) color13);
        float[] floatArray32 = new float[] { (-9999), (short) 100 };
        try {
            float[] floatArray33 = color13.getRGBColorComponents(floatArray32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(floatArray32);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangePannable(true);
        double double4 = combinedDomainXYPlot1.getGap();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean6 = xYAreaRenderer5.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator7 = null;
        xYAreaRenderer5.setLegendItemToolTipGenerator(xYSeriesLabelGenerator7);
        java.awt.Paint paint10 = xYAreaRenderer5.getSeriesPaint(2);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator12 = xYAreaRenderer5.getSeriesItemLabelGenerator(10);
        boolean boolean13 = xYAreaRenderer5.getBaseItemLabelsVisible();
        combinedDomainXYPlot1.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer5);
        double double15 = combinedDomainXYPlot1.getDomainCrosshairValue();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5.0d + "'", double4 == 5.0d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNull(xYItemLabelGenerator12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = combinedDomainXYPlot1.getRenderer();
        boolean boolean4 = combinedDomainXYPlot1.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNull(xYItemRenderer3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        double double4 = barRenderer3D2.getXOffset();
        barRenderer3D2.setBase((double) (short) 10);
        boolean boolean7 = barRenderer3D2.getShadowsVisible();
        barRenderer3D2.setMaximumBarWidth((double) 1L);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.099412556013E12d + "'", double4 == 1.099412556013E12d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        double double4 = barRenderer3D2.getXOffset();
        barRenderer3D2.setBase((double) (short) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke8 = categoryPlot7.getRangeMinorGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot7.getRenderer(10);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D12 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint13 = categoryAxis3D12.getLabelPaint();
        categoryAxis3D12.setTickMarkInsideLength((float) 0);
        categoryAxis3D12.addCategoryLabelToolTip((java.lang.Comparable) 1, "series");
        int int19 = categoryPlot7.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D12);
        double[] doubleArray26 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray31 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray32 = new double[][] { doubleArray26, doubleArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray32);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot34 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset33);
        org.jfree.data.category.CategoryDataset categoryDataset35 = multiplePiePlot34.getDataset();
        boolean boolean36 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset35);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = categoryPlot7.getRendererForDataset(categoryDataset35);
        barRenderer3D2.setPlot(categoryPlot7);
        java.lang.Class<?> wildcardClass39 = categoryPlot7.getClass();
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.099412556013E12d + "'", double4 == 1.099412556013E12d);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(categoryItemRenderer37);
        org.junit.Assert.assertNotNull(wildcardClass39);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setUpperMargin((double) (short) 0);
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        numberAxis3D0.setTickLabelPaint((java.awt.Paint) color3);
        java.text.NumberFormat numberFormat5 = java.text.NumberFormat.getNumberInstance();
        java.lang.String str7 = numberFormat5.format((long) 1);
        numberAxis3D0.setNumberFormatOverride(numberFormat5);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D11 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        piePlot3D11.setSimpleLabelOffset(rectangleInsets12);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection14 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries18.clear();
        timeSeries18.setDescription("series");
        int int22 = timeSeriesCollection14.indexOf(timeSeries18);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer24 = null;
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection14, (org.jfree.chart.axis.ValueAxis) numberAxis23, polarItemRenderer24);
        org.jfree.chart.plot.PlotOrientation plotOrientation26 = polarPlot25.getOrientation();
        java.awt.Paint paint27 = polarPlot25.getRadiusGridlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer31 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean32 = xYAreaRenderer31.isOutline();
        java.awt.Shape shape33 = xYAreaRenderer31.getBaseShape();
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic35 = new org.jfree.chart.title.LegendGraphic(shape33, (java.awt.Paint) color34);
        legendGraphic35.setWidth((double) 8);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint41 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D42 = legendGraphic35.arrange(graphics2D38, rectangleConstraint41);
        double double43 = legendGraphic35.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = legendGraphic35.getShapeLocation();
        java.awt.geom.Rectangle2D rectangle2D45 = legendGraphic35.getBounds();
        rectangleInsets30.trim(rectangle2D45);
        java.awt.Point point47 = polarPlot25.translateValueThetaRadiusToJava2D((double) (-1.0f), (double) (short) 100, rectangle2D45);
        java.awt.geom.Rectangle2D rectangle2D48 = rectangleInsets12.createInsetRectangle(rectangle2D45);
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot51 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis50);
        int int52 = combinedDomainXYPlot51.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath53 = null;
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.chart.RenderingSource renderingSource55 = null;
        combinedDomainXYPlot51.select(generalPath53, rectangle2D54, renderingSource55);
        java.awt.Paint paint58 = combinedDomainXYPlot51.getQuadrantPaint((int) (short) 0);
        combinedDomainXYPlot51.setBackgroundAlpha(0.0f);
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = combinedDomainXYPlot51.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo62 = null;
        try {
            org.jfree.chart.axis.AxisState axisState63 = numberAxis3D0.draw(graphics2D9, (double) 1, rectangle2D45, rectangle2D49, rectangleEdge61, plotRenderingInfo62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(numberFormat5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1" + "'", str7.equals("1"));
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(size2D42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(point47);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 15 + "'", int52 == 15);
        org.junit.Assert.assertNull(paint58);
        org.junit.Assert.assertNotNull(rectangleEdge61);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor1 = org.jfree.data.time.TimePeriodAnchor.END;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint4 = categoryAxis3D3.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D3, jFreeChart5, (int) (short) 1, (int) (short) 10);
        boolean boolean9 = timePeriodAnchor1.equals((java.lang.Object) (short) 10);
        timeSeriesCollection0.setXPosition(timePeriodAnchor1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate11 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        try {
            timeSeriesCollection0.setSelected((int) (short) 10, 255, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (10).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodAnchor1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        combinedDomainXYPlot1.setForegroundAlpha((float) (-1));
        int int5 = combinedDomainXYPlot1.getDomainAxisCount();
        float float6 = combinedDomainXYPlot1.getBackgroundImageAlpha();
        java.awt.Stroke stroke7 = combinedDomainXYPlot1.getDomainZeroBaselineStroke();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.5f + "'", float6 == 0.5f);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) '4', (double) 10L, (double) 100L);
        java.awt.Paint paint5 = blockBorder4.getPaint();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement11 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment7, verticalAlignment8, (double) (byte) 1, (double) 100.0f);
        flowArrangement11.clear();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer14 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(28);
        boolean boolean15 = flowArrangement11.equals((java.lang.Object) xYStepAreaRenderer14);
        xYStepAreaRenderer14.setSeriesVisible(68, (java.lang.Boolean) false);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot21 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis20);
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot23 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis22);
        int int24 = combinedDomainXYPlot23.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent26 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot23.rendererChanged(rendererChangeEvent26);
        combinedDomainXYPlot21.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot23);
        combinedDomainXYPlot23.setDomainMinorGridlinesVisible(true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D32.setUpperMargin((double) (short) 0);
        numberAxis3D32.resizeRange2((double) 10L, (double) 12);
        combinedDomainXYPlot23.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis3D32, false);
        org.jfree.data.xy.XYDataset xYDataset41 = combinedDomainXYPlot23.getDataset(4);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D42 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D42.setUpperMargin((double) (short) 0);
        numberAxis3D42.resizeRange2((double) 10L, (double) 12);
        numberAxis3D42.resizeRange((double) 15);
        org.jfree.chart.plot.Marker marker50 = null;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection51 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries55.clear();
        timeSeries55.setDescription("series");
        int int59 = timeSeriesCollection51.indexOf(timeSeries55);
        org.jfree.chart.axis.NumberAxis numberAxis60 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer61 = null;
        org.jfree.chart.plot.PolarPlot polarPlot62 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection51, (org.jfree.chart.axis.ValueAxis) numberAxis60, polarItemRenderer61);
        org.jfree.chart.plot.PlotOrientation plotOrientation63 = polarPlot62.getOrientation();
        java.awt.Paint paint64 = polarPlot62.getRadiusGridlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer68 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean69 = xYAreaRenderer68.isOutline();
        java.awt.Shape shape70 = xYAreaRenderer68.getBaseShape();
        java.awt.Color color71 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic72 = new org.jfree.chart.title.LegendGraphic(shape70, (java.awt.Paint) color71);
        legendGraphic72.setWidth((double) 8);
        java.awt.Graphics2D graphics2D75 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint78 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D79 = legendGraphic72.arrange(graphics2D75, rectangleConstraint78);
        double double80 = legendGraphic72.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor81 = legendGraphic72.getShapeLocation();
        java.awt.geom.Rectangle2D rectangle2D82 = legendGraphic72.getBounds();
        rectangleInsets67.trim(rectangle2D82);
        java.awt.Point point84 = polarPlot62.translateValueThetaRadiusToJava2D((double) (-1.0f), (double) (short) 100, rectangle2D82);
        xYStepAreaRenderer14.drawDomainMarker(graphics2D19, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot23, (org.jfree.chart.axis.ValueAxis) numberAxis3D42, marker50, rectangle2D82);
        try {
            blockBorder4.draw(graphics2D6, rectangle2D82);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 15 + "'", int24 == 15);
        org.junit.Assert.assertNull(xYDataset41);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation63);
        org.junit.Assert.assertNotNull(paint64);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(shape70);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertNotNull(size2D79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor81);
        org.junit.Assert.assertNotNull(rectangle2D82);
        org.junit.Assert.assertNotNull(point84);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        java.awt.Paint paint3 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        xYAreaRenderer4.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition6);
        boolean boolean8 = xYAreaRenderer4.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D9.centerRange((-1.0d));
        java.awt.Paint paint12 = numberAxis3D9.getTickLabelPaint();
        xYAreaRenderer4.setBaseFillPaint(paint12, true);
        categoryPlot0.setDomainCrosshairPaint(paint12);
        org.jfree.chart.LegendItemCollection legendItemCollection16 = categoryPlot0.getFixedLegendItems();
        boolean boolean17 = categoryPlot0.isDomainPannable();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(legendItemCollection16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        int int4 = combinedDomainXYPlot3.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot3.rendererChanged(rendererChangeEvent6);
        combinedDomainXYPlot1.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot3);
        org.jfree.chart.axis.AxisLocation axisLocation9 = combinedDomainXYPlot1.getRangeAxisLocation();
        combinedDomainXYPlot1.setWeight(4);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test024");
//        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
//        timeSeries6.clear();
//        timeSeries6.setDescription("series");
//        int int10 = timeSeriesCollection2.indexOf(timeSeries6);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day11, (java.lang.Number) 12, false);
//        long long15 = day11.getLastMillisecond();
//        int int16 = day11.getDayOfMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) month1, (org.jfree.data.time.RegularTimePeriod) day11);
//        java.awt.Stroke stroke18 = periodAxis17.getMinorTickMarkStroke();
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline19 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline20 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        segmentedTimeline19.setBaseTimeline(segmentedTimeline20);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline22 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        int int23 = segmentedTimeline22.getSegmentsExcluded();
//        java.util.Date date24 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.chart.axis.SegmentedTimeline.Segment segment25 = segmentedTimeline22.getSegment(date24);
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date24);
//        long long27 = segmentedTimeline19.toTimelineValue(date24);
//        long long28 = segmentedTimeline19.getSegmentsIncludedSize();
//        boolean boolean29 = periodAxis17.equals((java.lang.Object) long28);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 13 + "'", int16 == 13);
//        org.junit.Assert.assertNotNull(stroke18);
//        org.junit.Assert.assertNotNull(segmentedTimeline19);
//        org.junit.Assert.assertNotNull(segmentedTimeline20);
//        org.junit.Assert.assertNotNull(segmentedTimeline22);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 68 + "'", int23 == 68);
//        org.junit.Assert.assertNotNull(date24);
//        org.junit.Assert.assertNotNull(segment25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1099412556013L + "'", long27 == 1099412556013L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 25200000L + "'", long28 == 25200000L);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        double double4 = barRenderer3D2.getXOffset();
        barRenderer3D2.setBase((double) (short) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke8 = categoryPlot7.getRangeMinorGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot7.getRenderer(10);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D12 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint13 = categoryAxis3D12.getLabelPaint();
        categoryAxis3D12.setTickMarkInsideLength((float) 0);
        categoryAxis3D12.addCategoryLabelToolTip((java.lang.Comparable) 1, "series");
        int int19 = categoryPlot7.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D12);
        double[] doubleArray26 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray31 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray32 = new double[][] { doubleArray26, doubleArray31 };
        org.jfree.data.category.CategoryDataset categoryDataset33 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray32);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot34 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset33);
        org.jfree.data.category.CategoryDataset categoryDataset35 = multiplePiePlot34.getDataset();
        boolean boolean36 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset35);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = categoryPlot7.getRendererForDataset(categoryDataset35);
        barRenderer3D2.setPlot(categoryPlot7);
        double double39 = barRenderer3D2.getLowerClip();
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.099412556013E12d + "'", double4 == 1.099412556013E12d);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(categoryDataset33);
        org.junit.Assert.assertNotNull(categoryDataset35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(categoryItemRenderer37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean6 = xYAreaRenderer5.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator7 = null;
        xYAreaRenderer5.setLegendItemToolTipGenerator(xYSeriesLabelGenerator7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis3, valueAxis4, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer5);
        float float10 = xYPlot9.getBackgroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double13 = rectangleInsets11.trimWidth((double) 1560495599999L);
        xYPlot9.setAxisOffset(rectangleInsets11);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot17 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot19 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis18);
        int int20 = combinedDomainXYPlot19.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent22 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot19.rendererChanged(rendererChangeEvent22);
        combinedDomainXYPlot17.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot19);
        org.jfree.chart.axis.AxisLocation axisLocation25 = combinedDomainXYPlot17.getRangeAxisLocation();
        try {
            xYPlot9.setRangeAxisLocation((-1), axisLocation25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.560495599991E12d + "'", double13 == 1.560495599991E12d);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 15 + "'", int20 == 15);
        org.junit.Assert.assertNotNull(axisLocation25);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint3 = categoryAxis3D2.getLabelPaint();
        categoryAxis3D2.setTickMarkInsideLength((float) 0);
        java.awt.Font font6 = categoryAxis3D2.getLabelFont();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.lang.Class<?> wildcardClass12 = stroke11.getClass();
        boolean boolean13 = verticalAlignment10.equals((java.lang.Object) stroke11);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double16 = rectangleInsets14.calculateTopInset(10.0d);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font6, (java.awt.Paint) color7, rectangleEdge8, horizontalAlignment9, verticalAlignment10, rectangleInsets14);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        textTitle17.setPaint((java.awt.Paint) color18);
        double double20 = textTitle17.getContentXOffset();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.lang.Object obj1 = xYLineAndShapeRenderer0.clone();
        boolean boolean2 = xYLineAndShapeRenderer0.getBaseShapesVisible();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection3 = new org.jfree.data.xy.XYSeriesCollection();
        xYSeriesCollection3.removeAllSeries();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent5 = null;
        xYSeriesCollection3.seriesChanged(seriesChangeEvent5);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState7 = xYSeriesCollection3.getSelectionState();
        java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue((org.jfree.data.xy.XYDataset) xYSeriesCollection3);
        xYSeriesCollection3.clearSelection();
        boolean boolean10 = xYLineAndShapeRenderer0.equals((java.lang.Object) xYSeriesCollection3);
        xYLineAndShapeRenderer0.setSeriesLinesVisible(12, (java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(xYDatasetSelectionState7);
        org.junit.Assert.assertEquals((double) number8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getNumberInstance();
        java.lang.String str3 = numberFormat1.format(0.0d);
        java.text.NumberFormat numberFormat4 = java.text.NumberFormat.getNumberInstance();
        java.lang.String str6 = numberFormat4.format((long) 1);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator7 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Combined Range XYPlot", numberFormat1, numberFormat4);
        int int8 = numberFormat1.getMaximumFractionDigits();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1" + "'", str6.equals("1"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.jfree.chart.util.LogFormat logFormat0 = new org.jfree.chart.util.LogFormat();
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getCurrencyInstance();
        logFormat0.setExponentFormat(numberFormat1);
        org.junit.Assert.assertNotNull(numberFormat1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) 0.5d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(true);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeMinorGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer(10);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint6 = categoryAxis3D5.getLabelPaint();
        categoryAxis3D5.setTickMarkInsideLength((float) 0);
        categoryAxis3D5.addCategoryLabelToolTip((java.lang.Comparable) 1, "series");
        int int12 = categoryPlot0.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D5);
        double[] doubleArray19 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray24 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray25 = new double[][] { doubleArray19, doubleArray24 };
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray25);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot27 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset26);
        org.jfree.data.category.CategoryDataset categoryDataset28 = multiplePiePlot27.getDataset();
        boolean boolean29 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset28);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = categoryPlot0.getRendererForDataset(categoryDataset28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint32 = categoryPlot0.getRangeCrosshairPaint();
        java.awt.Paint paint33 = categoryPlot0.getDomainCrosshairPaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(categoryItemRenderer30);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(paint33);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot3D0.setLabelGenerator(pieSectionLabelGenerator1);
        piePlot3D0.setShadowXOffset(0.0d);
        piePlot3D0.setIgnoreZeroValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot3D0.getSimpleLabelOffset();
        boolean boolean8 = piePlot3D0.getIgnoreZeroValues();
        boolean boolean9 = piePlot3D0.getDarkerSides();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getIntegerInstance();
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("35");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2, false, false);
        org.jfree.chart.axis.Timeline timeline6 = dateAxis1.getTimeline();
        java.util.TimeZone timeZone7 = dateAxis1.getTimeZone();
        dateAxis1.setVisible(false);
        org.junit.Assert.assertNotNull(timeline6);
        org.junit.Assert.assertNotNull(timeZone7);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekInMonthToString(255);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str1.equals("SerialDate.weekInMonthToString(): invalid code."));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.TickType tickType4 = org.jfree.chart.axis.TickType.MAJOR;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.NumberTick numberTick15 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (short) 10, "series", textAnchor12, textAnchor13, (double) (short) 10);
        org.jfree.chart.text.TextAnchor textAnchor16 = numberTick15.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.NumberTick numberTick19 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0.2d, "NO_CHANGE", textAnchor16, textAnchor17, (double) '4');
        org.jfree.chart.axis.NumberTick numberTick21 = new org.jfree.chart.axis.NumberTick(tickType4, (double) (short) -1, "TextAnchor.BASELINE_CENTER", textAnchor7, textAnchor17, (double) 25200000L);
        org.jfree.chart.axis.TickType tickType23 = org.jfree.chart.axis.TickType.MAJOR;
        org.jfree.chart.text.TextAnchor textAnchor26 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor31 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor32 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.NumberTick numberTick34 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (short) 10, "series", textAnchor31, textAnchor32, (double) (short) 10);
        org.jfree.chart.text.TextAnchor textAnchor35 = numberTick34.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor36 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.NumberTick numberTick38 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0.2d, "NO_CHANGE", textAnchor35, textAnchor36, (double) '4');
        org.jfree.chart.axis.NumberTick numberTick40 = new org.jfree.chart.axis.NumberTick(tickType23, (double) (short) -1, "TextAnchor.BASELINE_CENTER", textAnchor26, textAnchor36, (double) 25200000L);
        try {
            java.awt.Shape shape41 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("Combined_Domain_XYPlot", graphics2D1, (float) 4188206L, (float) 13, textAnchor17, (double) (-9999), textAnchor36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(tickType4);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertNotNull(tickType23);
        org.junit.Assert.assertNotNull(textAnchor26);
        org.junit.Assert.assertNotNull(textAnchor31);
        org.junit.Assert.assertNotNull(textAnchor32);
        org.junit.Assert.assertNotNull(textAnchor35);
        org.junit.Assert.assertNotNull(textAnchor36);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int2 = segmentedTimeline1.getSegmentsExcluded();
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segmentedTimeline1.getSegment(date3);
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(date3);
        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis("35");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = null;
        dateAxis7.setTickUnit(dateTickUnit8, false, false);
        org.jfree.chart.axis.Timeline timeline12 = dateAxis7.getTimeline();
        java.util.TimeZone timeZone13 = dateAxis7.getTimeZone();
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone13;
        java.util.Date date15 = dateTickUnit0.rollDate(date3, timeZone13);
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertNotNull(segmentedTimeline1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68 + "'", int2 == 68);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(segment4);
        org.junit.Assert.assertNotNull(timeline12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNotNull(date15);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        double[] doubleArray6 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray11 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray12 = new double[][] { doubleArray6, doubleArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        org.jfree.data.category.CategoryDataset categoryDataset15 = multiplePiePlot14.getDataset();
        boolean boolean16 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset15);
        org.jfree.data.Range range18 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(categoryDataset15, false);
        org.jfree.data.Range range19 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset15);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertNotNull(range19);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.jfree.chart.StandardChartTheme standardChartTheme1 = new org.jfree.chart.StandardChartTheme("TextBlockAnchor.CENTER");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection2 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection2, true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer7 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean8 = xYAreaRenderer7.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator9 = null;
        xYAreaRenderer7.setLegendItemToolTipGenerator(xYSeriesLabelGenerator9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection2, valueAxis5, valueAxis6, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer7);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D();
        xYPlot11.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) numberAxis3D13);
        boolean boolean15 = numberAxis3D13.isTickMarksVisible();
        java.awt.Font font16 = numberAxis3D13.getTickLabelFont();
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_GREEN;
        numberAxis3D13.setTickMarkPaint((java.awt.Paint) color17);
        standardChartTheme1.setLegendBackgroundPaint((java.awt.Paint) color17);
        java.awt.Paint paint20 = standardChartTheme1.getTitlePaint();
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot22 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis21);
        int int23 = combinedDomainXYPlot22.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        combinedDomainXYPlot22.select(generalPath24, rectangle2D25, renderingSource26);
        java.awt.Paint paint29 = combinedDomainXYPlot22.getQuadrantPaint((int) (short) 0);
        combinedDomainXYPlot22.setBackgroundAlpha(0.0f);
        java.awt.Paint paint32 = combinedDomainXYPlot22.getRangeGridlinePaint();
        standardChartTheme1.setPlotBackgroundPaint(paint32);
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        standardChartTheme1.setLabelLinkPaint((java.awt.Paint) color34);
        java.awt.Paint paint36 = standardChartTheme1.getItemLabelPaint();
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 15 + "'", int23 == 15);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor1 = org.jfree.data.time.TimePeriodAnchor.END;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint4 = categoryAxis3D3.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D3, jFreeChart5, (int) (short) 1, (int) (short) 10);
        boolean boolean9 = timePeriodAnchor1.equals((java.lang.Object) (short) 10);
        timeSeriesCollection0.setXPosition(timePeriodAnchor1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate11 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        boolean boolean12 = intervalXYDelegate11.isAutoWidth();
        intervalXYDelegate11.setIntervalPositionFactor((double) 0L);
        double double15 = intervalXYDelegate11.getIntervalWidth();
        double double17 = intervalXYDelegate11.getDomainUpperBound(false);
        org.junit.Assert.assertNotNull(timePeriodAnchor1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertEquals((double) double17, Double.NaN, 0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("java.awt.Color[r=255,g=128,b=128]", regularTimePeriod2, regularTimePeriod5);
        float float7 = periodAxis6.getMinorTickMarkInsideLength();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year9 = month8.getYear();
        periodAxis6.setLast((org.jfree.data.time.RegularTimePeriod) year9);
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.lang.Class<?> wildcardClass14 = stroke13.getClass();
        java.io.InputStream inputStream15 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("java.awt.Color[r=0,g=192,b=192]", (java.lang.Class) wildcardClass14);
        java.net.URL uRL16 = org.jfree.chart.util.ObjectUtilities.getResource("{0}", (java.lang.Class) wildcardClass14);
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        periodAxis6.setAutoRangeTimePeriodClass((java.lang.Class) wildcardClass14);
        java.lang.Class class19 = periodAxis6.getAutoRangeTimePeriodClass();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month21.next();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = month23.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = month23.next();
        org.jfree.chart.axis.PeriodAxis periodAxis26 = new org.jfree.chart.axis.PeriodAxis("java.awt.Color[r=255,g=128,b=128]", regularTimePeriod22, regularTimePeriod25);
        java.awt.Paint paint27 = periodAxis26.getMinorTickMarkPaint();
        java.lang.Class class28 = periodAxis26.getAutoRangeTimePeriodClass();
        periodAxis6.setMinorTickTimePeriodClass(class28);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(year9);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNull(inputStream15);
        org.junit.Assert.assertNull(uRL16);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertNotNull(class19);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(class28);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString((-9999));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        java.awt.Paint paint3 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder4 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder4);
        java.lang.Comparable comparable6 = null;
        categoryPlot0.setDomainCrosshairRowKey(comparable6, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = null;
        org.jfree.chart.util.Layer layer11 = null;
        try {
            categoryPlot0.addDomainMarker(1900, categoryMarker10, layer11, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(datasetRenderingOrder4);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        double double4 = barRenderer3D2.getXOffset();
        barRenderer3D2.setBase((double) (short) 10);
        boolean boolean7 = barRenderer3D2.getShadowsVisible();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer3D2.setSeriesURLGenerator(100, categoryURLGenerator9, false);
        int int12 = barRenderer3D2.getColumnCount();
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.099412556013E12d + "'", double4 == 1.099412556013E12d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Stroke stroke1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYAreaRenderer0.setBaseOutlineStroke(stroke1);
        xYAreaRenderer0.setBaseCreateEntities(true, true);
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("");
        org.jfree.data.general.SeriesException seriesException3 = new org.jfree.data.general.SeriesException("");
        java.lang.Throwable[] throwableArray4 = seriesException3.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException3);
        java.lang.String str6 = seriesException1.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.jfree.data.general.SeriesException: " + "'", str6.equals("org.jfree.data.general.SeriesException: "));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = year0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        org.jfree.chart.LegendItem legendItem6 = barRenderer3D2.getLegendItem((int) (byte) 1, 1);
        barRenderer3D2.setAutoPopulateSeriesStroke(false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNull(legendItem6);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection1, true);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean7 = xYAreaRenderer6.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator8 = null;
        xYAreaRenderer6.setLegendItemToolTipGenerator(xYSeriesLabelGenerator8);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection1, valueAxis4, valueAxis5, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer6);
        boolean boolean11 = xYAreaRenderer6.isOutline();
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYAreaRenderer6.setSeriesItemLabelFont(100, font13);
        piePlot3D0.setLabelFont(font13);
        double double16 = piePlot3D0.getMaximumExplodePercent();
        piePlot3D0.setLabelLinksVisible(true);
        double double19 = piePlot3D0.getMaximumExplodePercent();
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) 0.0f);
        java.lang.Object obj22 = valueMarker21.clone();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType23 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        valueMarker21.setLabelOffsetType(lengthAdjustmentType23);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot26 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis25);
        int int27 = combinedDomainXYPlot26.getBackgroundImageAlignment();
        combinedDomainXYPlot26.setForegroundAlpha((float) (-1));
        java.awt.Stroke stroke30 = combinedDomainXYPlot26.getDomainMinorGridlineStroke();
        valueMarker21.setStroke(stroke30);
        piePlot3D0.setBaseSectionOutlineStroke(stroke30);
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor34 = new org.jfree.chart.plot.PieLabelDistributor((int) ' ');
        pieLabelDistributor34.clear();
        piePlot3D0.setLabelDistributor((org.jfree.chart.plot.AbstractPieLabelDistributor) pieLabelDistributor34);
        try {
            org.jfree.chart.plot.PieLabelRecord pieLabelRecord38 = pieLabelDistributor34.getPieLabelRecord(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(lengthAdjustmentType23);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 15 + "'", int27 == 15);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 1, (double) 100.0f);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = null;
        piePlot3D6.setLabelGenerator(pieSectionLabelGenerator7);
        piePlot3D6.setShadowXOffset(0.0d);
        piePlot3D6.setIgnoreZeroValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = piePlot3D6.getSimpleLabelOffset();
        blockContainer5.setPadding(rectangleInsets13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint(0.0d, (double) (-1L));
        org.jfree.chart.util.Size2D size2D19 = blockContainer5.arrange(graphics2D15, rectangleConstraint18);
        blockContainer5.setWidth((double) '4');
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(size2D19);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean2 = xYAreaRenderer1.isOutline();
        java.awt.Shape shape3 = xYAreaRenderer1.getBaseShape();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape3, (java.awt.Paint) color4);
        legendGraphic5.setWidth((double) 8);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D12 = legendGraphic5.arrange(graphics2D8, rectangleConstraint11);
        double double13 = legendGraphic5.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = legendGraphic5.getShapeLocation();
        java.awt.geom.Rectangle2D rectangle2D15 = legendGraphic5.getBounds();
        rectangleInsets0.trim(rectangle2D15);
        double[] doubleArray23 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray28 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray29 = new double[][] { doubleArray23, doubleArray28 };
        org.jfree.data.category.CategoryDataset categoryDataset30 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray29);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot31 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset30);
        java.lang.Number number32 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset30);
        org.jfree.data.general.PieDataset pieDataset34 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset30, 0);
        org.jfree.data.general.DefaultPieDataset defaultPieDataset35 = new org.jfree.data.general.DefaultPieDataset((org.jfree.data.KeyedValues) pieDataset34);
        java.text.NumberFormat numberFormat39 = java.text.NumberFormat.getNumberInstance();
        java.lang.String str41 = numberFormat39.format(0.0d);
        boolean boolean42 = numberFormat39.isParseIntegerOnly();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit44 = new org.jfree.chart.axis.NumberTickUnit(3.0d, numberFormat39, 1900);
        org.jfree.chart.entity.PieSectionEntity pieSectionEntity47 = new org.jfree.chart.entity.PieSectionEntity((java.awt.Shape) rectangle2D15, (org.jfree.data.general.PieDataset) defaultPieDataset35, (int) (short) -1, (int) '#', (java.lang.Comparable) 3.0d, "index.html", "0");
        boolean boolean48 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.general.PieDataset) defaultPieDataset35);
        org.jfree.data.general.PieDataset pieDataset52 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset((org.jfree.data.general.PieDataset) defaultPieDataset35, (java.lang.Comparable) Double.POSITIVE_INFINITY, (double) 2, 2);
        org.jfree.chart.plot.RingPlot ringPlot53 = new org.jfree.chart.plot.RingPlot(pieDataset52);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(rectangle2D15);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(categoryDataset30);
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 1.0d + "'", number32.equals(1.0d));
        org.junit.Assert.assertNotNull(pieDataset34);
        org.junit.Assert.assertNotNull(numberFormat39);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "0" + "'", str41.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(pieDataset52);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        int int4 = combinedDomainXYPlot3.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot3.rendererChanged(rendererChangeEvent6);
        combinedDomainXYPlot1.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot3);
        combinedDomainXYPlot3.setRangeGridlinesVisible(false);
        combinedDomainXYPlot3.mapDatasetToRangeAxis(100, 0);
        combinedDomainXYPlot3.clearAnnotations();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
        double[] doubleArray10 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray15 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray16 = new double[][] { doubleArray10, doubleArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray16);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity20 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "", "item", categoryDataset17, (java.lang.Comparable) "item", (java.lang.Comparable) "0");
        java.lang.Object obj21 = categoryItemEntity20.clone();
        java.awt.Shape shape23 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
        double[] doubleArray32 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray37 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray38 = new double[][] { doubleArray32, doubleArray37 };
        org.jfree.data.category.CategoryDataset categoryDataset39 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray38);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity42 = new org.jfree.chart.entity.CategoryItemEntity(shape23, "", "item", categoryDataset39, (java.lang.Comparable) "item", (java.lang.Comparable) "0");
        categoryItemEntity20.setDataset(categoryDataset39);
        org.jfree.data.Range range44 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset39);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(categoryDataset39);
        org.junit.Assert.assertNotNull(range44);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator0 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator();
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (short) 10, "series", textAnchor2, textAnchor3, (double) (short) 10);
        org.jfree.chart.text.TextAnchor textAnchor6 = numberTick5.getRotationAnchor();
        java.lang.Object obj7 = numberTick5.clone();
        org.jfree.chart.text.TextAnchor textAnchor8 = numberTick5.getRotationAnchor();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        boolean boolean3 = jFreeChartResources0.containsKey("TextAnchor.BASELINE_CENTER");
        java.lang.Object[][] objArray4 = jFreeChartResources0.getContents();
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean6 = xYAreaRenderer5.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator7 = null;
        xYAreaRenderer5.setLegendItemToolTipGenerator(xYSeriesLabelGenerator7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis3, valueAxis4, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer5);
        boolean boolean10 = xYAreaRenderer5.isOutline();
        java.awt.Font font12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYAreaRenderer5.setSeriesItemLabelFont(100, font12);
        org.jfree.chart.plot.XYPlot xYPlot14 = xYAreaRenderer5.getPlot();
        java.awt.Shape shape15 = xYAreaRenderer5.getLegendArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke17 = categoryPlot16.getRangeMinorGridlineStroke();
        int int18 = categoryPlot16.getDomainAxisCount();
        org.jfree.chart.entity.PlotEntity plotEntity20 = new org.jfree.chart.entity.PlotEntity(shape15, (org.jfree.chart.plot.Plot) categoryPlot16, "RectangleAnchor.CENTER");
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(xYPlot14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) "1.2.0-pre", true, false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint2 = categoryAxis3D1.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent6 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D1, jFreeChart3, (int) (short) 1, (int) (short) 10);
        int int7 = chartProgressEvent6.getPercent();
        chartProgressEvent6.setPercent((int) (short) -1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot3D0.setLabelGenerator(pieSectionLabelGenerator1);
        piePlot3D0.setShadowXOffset(0.0d);
        piePlot3D0.setIgnoreZeroValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot3D0.getSimpleLabelOffset();
        boolean boolean8 = piePlot3D0.getIgnoreZeroValues();
        java.lang.Object obj9 = piePlot3D0.clone();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator10 = piePlot3D0.getLegendLabelURLGenerator();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(pieURLGenerator10);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection2 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection2, true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer7 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean8 = xYAreaRenderer7.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator9 = null;
        xYAreaRenderer7.setLegendItemToolTipGenerator(xYSeriesLabelGenerator9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection2, valueAxis5, valueAxis6, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer7);
        boolean boolean12 = xYAreaRenderer7.isOutline();
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYAreaRenderer7.setSeriesItemLabelFont(100, font14);
        piePlot3D1.setLabelFont(font14);
        java.awt.Color color17 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer19 = null;
        org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("", font14, (java.awt.Paint) color17, (float) 100L, textMeasurer19);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor24 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        java.awt.Shape shape28 = textBlock20.calculateBounds(graphics2D21, (float) 2147483647, (float) (-460), textBlockAnchor24, (float) 10L, (float) 9223372036854775807L, 1.0d);
        java.awt.Graphics2D graphics2D29 = null;
        org.jfree.chart.util.Size2D size2D30 = textBlock20.calculateDimensions(graphics2D29);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment31 = textBlock20.getLineAlignment();
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(textBlock20);
        org.junit.Assert.assertNotNull(textBlockAnchor24);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(size2D30);
        org.junit.Assert.assertNotNull(horizontalAlignment31);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        java.lang.String str2 = rectangleEdge0.toString();
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "RectangleEdge.RIGHT" + "'", str2.equals("RectangleEdge.RIGHT"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        java.awt.Shape shape2 = xYAreaRenderer0.getBaseShape();
        org.jfree.chart.plot.Plot plot3 = null;
        try {
            org.jfree.chart.entity.PlotEntity plotEntity4 = new org.jfree.chart.entity.PlotEntity(shape2, plot3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        double double1 = crosshairState0.getAnchorX();
        crosshairState0.setCrosshairX((double) (-1));
        double double4 = crosshairState0.getCrosshairX();
        crosshairState0.updateCrosshairX((double) (byte) 0, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection8 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries12.clear();
        timeSeries12.setDescription("series");
        int int16 = timeSeriesCollection8.indexOf(timeSeries12);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer18 = null;
        org.jfree.chart.plot.PolarPlot polarPlot19 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection8, (org.jfree.chart.axis.ValueAxis) numberAxis17, polarItemRenderer18);
        org.jfree.chart.plot.PlotOrientation plotOrientation20 = polarPlot19.getOrientation();
        java.awt.Paint paint21 = polarPlot19.getRadiusGridlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean26 = xYAreaRenderer25.isOutline();
        java.awt.Shape shape27 = xYAreaRenderer25.getBaseShape();
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic29 = new org.jfree.chart.title.LegendGraphic(shape27, (java.awt.Paint) color28);
        legendGraphic29.setWidth((double) 8);
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint35 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D36 = legendGraphic29.arrange(graphics2D32, rectangleConstraint35);
        double double37 = legendGraphic29.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor38 = legendGraphic29.getShapeLocation();
        java.awt.geom.Rectangle2D rectangle2D39 = legendGraphic29.getBounds();
        rectangleInsets24.trim(rectangle2D39);
        java.awt.Point point41 = polarPlot19.translateValueThetaRadiusToJava2D((double) (-1.0f), (double) (short) 100, rectangle2D39);
        crosshairState0.setAnchor((java.awt.geom.Point2D) point41);
        int int43 = crosshairState0.getDomainAxisIndex();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation20);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(size2D36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor38);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(point41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
    }

//    @Test
//    public void test073() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test073");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        int int1 = segmentedTimeline0.getSegmentsExcluded();
//        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment(date2);
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
//        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date2);
//        java.lang.String str6 = serialDate5.toString();
//        org.jfree.data.time.SerialDate serialDate8 = serialDate5.getNearestDayOfWeek((int) (byte) 1);
//        org.junit.Assert.assertNotNull(segmentedTimeline0);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(segment3);
//        org.junit.Assert.assertNotNull(serialDate5);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "13-June-2019" + "'", str6.equals("13-June-2019"));
//        org.junit.Assert.assertNotNull(serialDate8);
//    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        java.awt.Paint paint4 = combinedDomainXYPlot3.getBackgroundPaint();
        xYAreaRenderer0.setSeriesPaint(2, paint4);
        java.awt.Stroke stroke7 = null;
        xYAreaRenderer0.setSeriesStroke((int) '#', stroke7, true);
        java.awt.Paint paint13 = xYAreaRenderer0.getItemFillPaint((int) (byte) -1, (int) '#', true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        java.awt.Color color1 = java.awt.Color.BLACK;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer2 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint3 = xYAreaRenderer2.getBaseLegendTextPaint();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator4 = null;
        xYAreaRenderer2.setBaseItemLabelGenerator(xYItemLabelGenerator4, true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.data.Range range10 = combinedDomainXYPlot8.getDataRange(valueAxis9);
        java.lang.Object obj11 = null;
        boolean boolean12 = combinedDomainXYPlot8.equals(obj11);
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        combinedDomainXYPlot8.setRangeGridlineStroke(stroke13);
        xYAreaRenderer2.setBaseOutlineStroke(stroke13);
        org.jfree.chart.plot.ValueMarker valueMarker16 = new org.jfree.chart.plot.ValueMarker((double) 1.0f, (java.awt.Paint) color1, stroke13);
        org.jfree.chart.plot.PiePlot3D piePlot3D17 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator18 = null;
        piePlot3D17.setLabelGenerator(pieSectionLabelGenerator18);
        piePlot3D17.setShadowXOffset(0.0d);
        double double23 = piePlot3D17.getExplodePercent((java.lang.Comparable) 100L);
        java.awt.Stroke stroke24 = piePlot3D17.getLabelOutlineStroke();
        valueMarker16.setStroke(stroke24);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod1, (double) 3);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.jfree.data.xy.XYSeries xYSeries1 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) 3);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeMinorGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer(10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.CrosshairState crosshairState7 = new org.jfree.chart.plot.CrosshairState();
        double double8 = crosshairState7.getAnchorX();
        crosshairState7.setCrosshairX((double) (-1));
        double double11 = crosshairState7.getCrosshairX();
        crosshairState7.updateCrosshairX((double) (byte) 0, (int) (byte) 100);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection15 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries19.clear();
        timeSeries19.setDescription("series");
        int int23 = timeSeriesCollection15.indexOf(timeSeries19);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer25 = null;
        org.jfree.chart.plot.PolarPlot polarPlot26 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection15, (org.jfree.chart.axis.ValueAxis) numberAxis24, polarItemRenderer25);
        org.jfree.chart.plot.PlotOrientation plotOrientation27 = polarPlot26.getOrientation();
        java.awt.Paint paint28 = polarPlot26.getRadiusGridlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer32 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean33 = xYAreaRenderer32.isOutline();
        java.awt.Shape shape34 = xYAreaRenderer32.getBaseShape();
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic36 = new org.jfree.chart.title.LegendGraphic(shape34, (java.awt.Paint) color35);
        legendGraphic36.setWidth((double) 8);
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D43 = legendGraphic36.arrange(graphics2D39, rectangleConstraint42);
        double double44 = legendGraphic36.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor45 = legendGraphic36.getShapeLocation();
        java.awt.geom.Rectangle2D rectangle2D46 = legendGraphic36.getBounds();
        rectangleInsets31.trim(rectangle2D46);
        java.awt.Point point48 = polarPlot26.translateValueThetaRadiusToJava2D((double) (-1.0f), (double) (short) 100, rectangle2D46);
        crosshairState7.setAnchor((java.awt.geom.Point2D) point48);
        categoryPlot0.zoomDomainAxes((double) (-1L), Double.NaN, plotRenderingInfo6, (java.awt.geom.Point2D) point48);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11 == (-1.0d));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(size2D43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor45);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(point48);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries3.clear();
        timeSeries3.setDescription("series");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries11.clear();
        timeSeries11.setDescription("series");
        int int15 = timeSeriesCollection7.indexOf(timeSeries11);
        java.lang.String str16 = timeSeries11.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.addAndOrUpdate(timeSeries11);
        timeSeries11.setRangeDescription("-3,-3,3,3");
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
        org.junit.Assert.assertNotNull(timeSeries17);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.jfree.chart.plot.WaferMapPlot waferMapPlot0 = new org.jfree.chart.plot.WaferMapPlot();
        org.jfree.data.general.WaferMapDataset waferMapDataset1 = waferMapPlot0.getDataset();
        org.junit.Assert.assertNull(waferMapDataset1);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        org.jfree.data.xy.XYDataItem xYDataItem5 = new org.jfree.data.xy.XYDataItem((double) 8, 100.0d);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 100.0d, true);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint10 = categoryAxis3D9.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent14 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D9, jFreeChart11, (int) (short) 1, (int) (short) 10);
        categoryAxis3D9.setMaximumCategoryLabelWidthRatio((float) ' ');
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer17 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint18 = xYAreaRenderer17.getBaseLegendTextPaint();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator19 = null;
        xYAreaRenderer17.setBaseItemLabelGenerator(xYItemLabelGenerator19, true);
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot23 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis22);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.data.Range range25 = combinedDomainXYPlot23.getDataRange(valueAxis24);
        java.lang.Object obj26 = null;
        boolean boolean27 = combinedDomainXYPlot23.equals(obj26);
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        combinedDomainXYPlot23.setRangeGridlineStroke(stroke28);
        xYAreaRenderer17.setBaseOutlineStroke(stroke28);
        boolean boolean31 = categoryAxis3D9.equals((java.lang.Object) xYAreaRenderer17);
        categoryPlot0.setDomainAxis((org.jfree.chart.axis.CategoryAxis) categoryAxis3D9);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(paint18);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("RangeType.FULL");
        java.lang.String str2 = legendItem1.getURLText();
        java.lang.String str3 = legendItem1.getURLText();
        legendItem1.setShapeVisible(false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = legendItem1.getFillPaintTransformer();
        java.awt.Stroke stroke7 = legendItem1.getOutlineStroke();
        legendItem1.setToolTipText("");
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot3D0.setLabelGenerator(pieSectionLabelGenerator1);
        piePlot3D0.setShadowXOffset(0.0d);
        piePlot3D0.setIgnoreZeroValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot3D0.getSimpleLabelOffset();
        boolean boolean8 = piePlot3D0.getIgnoreZeroValues();
        java.lang.Object obj9 = piePlot3D0.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = piePlot3D0.getSimpleLabelOffset();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean2 = range0.contains(0.0d);
        org.jfree.data.Range range5 = org.jfree.data.Range.expand(range0, (double) ' ', (double) 2.0f);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = month7.next();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = month9.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = month9.next();
        org.jfree.chart.axis.PeriodAxis periodAxis12 = new org.jfree.chart.axis.PeriodAxis("java.awt.Color[r=255,g=128,b=128]", regularTimePeriod8, regularTimePeriod11);
        java.awt.Paint paint13 = periodAxis12.getMinorTickMarkPaint();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D14.centerRange((-1.0d));
        java.awt.Paint paint17 = numberAxis3D14.getTickLabelPaint();
        org.jfree.data.Range range18 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double19 = range18.getLength();
        numberAxis3D14.setRangeWithMargins(range18, false, false);
        periodAxis12.setRange(range18, false, false);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint(range0, range18);
        java.lang.String str27 = rectangleConstraint26.toString();
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(range18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str27.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        double double2 = combinedRangeXYPlot1.getGap();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis3);
        java.awt.Paint paint5 = combinedDomainXYPlot4.getBackgroundPaint();
        combinedRangeXYPlot1.addChangeListener((org.jfree.chart.event.PlotChangeListener) combinedDomainXYPlot4);
        org.jfree.chart.util.Layer layer7 = null;
        java.util.Collection collection8 = combinedRangeXYPlot1.getRangeMarkers(layer7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D11 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        piePlot3D11.setSimpleLabelOffset(rectangleInsets12);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection14 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries18.clear();
        timeSeries18.setDescription("series");
        int int22 = timeSeriesCollection14.indexOf(timeSeries18);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer24 = null;
        org.jfree.chart.plot.PolarPlot polarPlot25 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection14, (org.jfree.chart.axis.ValueAxis) numberAxis23, polarItemRenderer24);
        org.jfree.chart.plot.PlotOrientation plotOrientation26 = polarPlot25.getOrientation();
        java.awt.Paint paint27 = polarPlot25.getRadiusGridlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer31 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean32 = xYAreaRenderer31.isOutline();
        java.awt.Shape shape33 = xYAreaRenderer31.getBaseShape();
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic35 = new org.jfree.chart.title.LegendGraphic(shape33, (java.awt.Paint) color34);
        legendGraphic35.setWidth((double) 8);
        java.awt.Graphics2D graphics2D38 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint41 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D42 = legendGraphic35.arrange(graphics2D38, rectangleConstraint41);
        double double43 = legendGraphic35.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = legendGraphic35.getShapeLocation();
        java.awt.geom.Rectangle2D rectangle2D45 = legendGraphic35.getBounds();
        rectangleInsets30.trim(rectangle2D45);
        java.awt.Point point47 = polarPlot25.translateValueThetaRadiusToJava2D((double) (-1.0f), (double) (short) 100, rectangle2D45);
        java.awt.geom.Rectangle2D rectangle2D48 = rectangleInsets12.createInsetRectangle(rectangle2D45);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor49 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        java.awt.geom.Point2D point2D50 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D45, rectangleAnchor49);
        try {
            combinedRangeXYPlot1.zoomDomainAxes((-98.0d), plotRenderingInfo10, point2D50, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.0d + "'", double2 == 5.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(collection8);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(size2D42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor44);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(point47);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(rectangleAnchor49);
        org.junit.Assert.assertNotNull(point2D50);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer3D2.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean6 = xYAreaRenderer5.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator7 = null;
        xYAreaRenderer5.setLegendItemToolTipGenerator(xYSeriesLabelGenerator7);
        boolean boolean9 = xYAreaRenderer5.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        xYAreaRenderer5.setSeriesToolTipGenerator((int) (short) 100, xYToolTipGenerator11);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = xYAreaRenderer5.getNegativeItemLabelPosition(100, (int) (byte) -1, false);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor17 = itemLabelPosition16.getItemLabelAnchor();
        barRenderer3D2.setBasePositiveItemLabelPosition(itemLabelPosition16);
        double double19 = itemLabelPosition16.getAngle();
        org.jfree.chart.text.TextAnchor textAnchor20 = itemLabelPosition16.getTextAnchor();
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(itemLabelAnchor17);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(textAnchor20);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        java.util.List list3 = xYSeriesCollection0.getSeries();
        xYSeriesCollection0.validateObject();
        java.lang.Object obj5 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) xYSeriesCollection0);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        java.awt.Shape shape2 = xYAreaRenderer0.getBaseShape();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.clone(shape2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        combinedDomainXYPlot1.select(generalPath3, rectangle2D4, renderingSource5);
        java.awt.Paint paint8 = combinedDomainXYPlot1.getQuadrantPaint((int) (short) 0);
        combinedDomainXYPlot1.clearAnnotations();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = combinedDomainXYPlot1.getDrawingSupplier();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot12 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis11);
        int int13 = combinedDomainXYPlot12.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.RenderingSource renderingSource16 = null;
        combinedDomainXYPlot12.select(generalPath14, rectangle2D15, renderingSource16);
        java.awt.Paint paint19 = combinedDomainXYPlot12.getQuadrantPaint((int) (short) 0);
        combinedDomainXYPlot12.setBackgroundAlpha(0.0f);
        org.jfree.chart.plot.Marker marker23 = null;
        org.jfree.chart.util.Layer layer24 = null;
        boolean boolean26 = combinedDomainXYPlot12.removeDomainMarker((-1), marker23, layer24, true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer28 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot31 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis30);
        java.awt.Paint paint32 = combinedDomainXYPlot31.getBackgroundPaint();
        xYAreaRenderer28.setSeriesPaint(2, paint32);
        xYAreaRenderer28.setAutoPopulateSeriesPaint(false);
        combinedDomainXYPlot12.setRenderer(0, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer28, true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator39 = xYAreaRenderer28.getSeriesItemLabelGenerator((int) (short) 10);
        combinedDomainXYPlot1.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer28);
        xYAreaRenderer28.clearSeriesStrokes(false);
        java.awt.Shape shape44 = xYAreaRenderer28.getLegendShape(28);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator47 = null;
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator51 = new org.jfree.chart.urls.StandardXYURLGenerator("Pie 3D Plot", "poly", "35");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer52 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-460), xYToolTipGenerator47, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator51);
        xYAreaRenderer28.setSeriesURLGenerator((int) '4', (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator51);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNull(xYItemLabelGenerator39);
        org.junit.Assert.assertNull(shape44);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean2 = xYAreaRenderer1.isOutline();
        java.awt.Shape shape3 = xYAreaRenderer1.getBaseShape();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic5 = new org.jfree.chart.title.LegendGraphic(shape3, (java.awt.Paint) color4);
        legendGraphic5.setWidth((double) 8);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot8.getDomainMarkers(layer9);
        java.awt.Paint paint11 = categoryPlot8.getDomainCrosshairPaint();
        org.jfree.chart.StandardChartTheme standardChartTheme13 = new org.jfree.chart.StandardChartTheme("TextBlockAnchor.CENTER");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection14 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection14, true);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer19 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean20 = xYAreaRenderer19.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator21 = null;
        xYAreaRenderer19.setLegendItemToolTipGenerator(xYSeriesLabelGenerator21);
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection14, valueAxis17, valueAxis18, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer19);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D25 = new org.jfree.chart.axis.NumberAxis3D();
        xYPlot23.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) numberAxis3D25);
        boolean boolean27 = numberAxis3D25.isTickMarksVisible();
        java.awt.Font font28 = numberAxis3D25.getTickLabelFont();
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_GREEN;
        numberAxis3D25.setTickMarkPaint((java.awt.Paint) color29);
        standardChartTheme13.setLegendBackgroundPaint((java.awt.Paint) color29);
        java.awt.Paint paint32 = standardChartTheme13.getTitlePaint();
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot34 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis33);
        int int35 = combinedDomainXYPlot34.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.RenderingSource renderingSource38 = null;
        combinedDomainXYPlot34.select(generalPath36, rectangle2D37, renderingSource38);
        java.awt.Paint paint41 = combinedDomainXYPlot34.getQuadrantPaint((int) (short) 0);
        combinedDomainXYPlot34.setBackgroundAlpha(0.0f);
        java.awt.Paint paint44 = combinedDomainXYPlot34.getRangeGridlinePaint();
        standardChartTheme13.setPlotBackgroundPaint(paint44);
        categoryPlot8.setDomainGridlinePaint(paint44);
        java.awt.Paint paint47 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        categoryPlot8.setDomainGridlinePaint(paint47);
        org.jfree.data.category.CategoryDataset categoryDataset50 = categoryPlot8.getDataset(13);
        boolean boolean51 = legendGraphic5.equals((java.lang.Object) categoryPlot8);
        boolean boolean52 = color0.equals((java.lang.Object) legendGraphic5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 15 + "'", int35 == 15);
        org.junit.Assert.assertNull(paint41);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNull(categoryDataset50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("35");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2, false, false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = dateAxis1.getTickUnit();
        java.util.Date date7 = dateAxis1.getMinimumDate();
        dateAxis1.setAutoTickUnitSelection(true);
        org.junit.Assert.assertNull(dateTickUnit6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        xYSeriesCollection0.removeAllSeries();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent2 = null;
        xYSeriesCollection0.seriesChanged(seriesChangeEvent2);
        org.jfree.data.xy.XYDatasetSelectionState xYDatasetSelectionState4 = xYSeriesCollection0.getSelectionState();
        xYSeriesCollection0.removeAllSeries();
        try {
            xYSeriesCollection0.removeSeries((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(xYDatasetSelectionState4);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        double double4 = barRenderer3D2.getXOffset();
        barRenderer3D2.setBase((double) (short) 10);
        java.awt.Stroke stroke10 = barRenderer3D2.getItemOutlineStroke(2147483647, (-460), true);
        java.awt.Paint paint12 = barRenderer3D2.lookupSeriesPaint(0);
        barRenderer3D2.setMaximumBarWidth((double) 1546329600000L);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.099412556013E12d + "'", double4 == 1.099412556013E12d);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor1 = org.jfree.data.time.TimePeriodAnchor.END;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint4 = categoryAxis3D3.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D3, jFreeChart5, (int) (short) 1, (int) (short) 10);
        boolean boolean9 = timePeriodAnchor1.equals((java.lang.Object) (short) 10);
        timeSeriesCollection0.setXPosition(timePeriodAnchor1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate11 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        java.util.List list12 = timeSeriesCollection0.getSeries();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries16.clear();
        timeSeries16.setDescription("series");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection20 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries24.clear();
        timeSeries24.setDescription("series");
        int int28 = timeSeriesCollection20.indexOf(timeSeries24);
        java.lang.String str29 = timeSeries24.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries16.addAndOrUpdate(timeSeries24);
        int int31 = timeSeriesCollection0.indexOf(timeSeries16);
        org.jfree.data.DomainOrder domainOrder32 = timeSeriesCollection0.getDomainOrder();
        org.junit.Assert.assertNotNull(timePeriodAnchor1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "0" + "'", str29.equals("0"));
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNotNull(domainOrder32);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        borderArrangement0.clear();
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = null;
        piePlot3D1.setLabelGenerator(pieSectionLabelGenerator2);
        piePlot3D1.setShadowXOffset(0.0d);
        piePlot3D1.setCircular(true);
        java.awt.Font font8 = piePlot3D1.getLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis9);
        java.awt.Paint paint11 = combinedDomainXYPlot10.getBackgroundPaint();
        org.jfree.chart.text.TextLine textLine12 = new org.jfree.chart.text.TextLine("NO_CHANGE", font8, paint11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        try {
            textLine12.draw(graphics2D13, (float) 25200000L, (float) 1099412556013L, textAnchor16, (float) 13, (float) 15, 8.19260189995275E11d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(textAnchor16);
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test097");
//        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
//        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
//        timeSeries5.clear();
//        timeSeries5.setDescription("series");
//        int int9 = timeSeriesCollection1.indexOf(timeSeries5);
//        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day();
//        timeSeries5.add((org.jfree.data.time.RegularTimePeriod) day10, (java.lang.Number) 12, false);
//        long long14 = day10.getLastMillisecond();
//        int int15 = day10.getMonth();
//        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day();
//        java.util.TimeZone timeZone17 = org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE;
//        java.util.Locale locale18 = null;
//        try {
//            org.jfree.chart.axis.PeriodAxis periodAxis19 = new org.jfree.chart.axis.PeriodAxis("series", (org.jfree.data.time.RegularTimePeriod) day10, (org.jfree.data.time.RegularTimePeriod) day16, timeZone17, locale18);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'locale' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1560495599999L + "'", long14 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
//        org.junit.Assert.assertNotNull(timeZone17);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer2 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint3 = xYAreaRenderer2.getBaseLegendTextPaint();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator4 = null;
        xYAreaRenderer2.setBaseItemLabelGenerator(xYItemLabelGenerator4, true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.data.Range range10 = combinedDomainXYPlot8.getDataRange(valueAxis9);
        java.lang.Object obj11 = null;
        boolean boolean12 = combinedDomainXYPlot8.equals(obj11);
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        combinedDomainXYPlot8.setRangeGridlineStroke(stroke13);
        xYAreaRenderer2.setBaseOutlineStroke(stroke13);
        java.awt.Font font19 = xYAreaRenderer2.getItemLabelFont((int) (short) 100, 12, false);
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.block.LabelBlock labelBlock21 = new org.jfree.chart.block.LabelBlock("35", font19, (java.awt.Paint) color20);
        java.lang.String str22 = labelBlock21.getToolTipText();
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        labelBlock21.setPaint((java.awt.Paint) color23);
        java.awt.Color color25 = color23.darker();
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("RangeType.FULL");
        java.lang.String str28 = legendItem27.getURLText();
        java.lang.String str29 = legendItem27.getURLText();
        legendItem27.setShapeVisible(false);
        java.awt.Shape shape32 = legendItem27.getShape();
        java.awt.Stroke stroke33 = legendItem27.getOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker34 = new org.jfree.chart.plot.ValueMarker((double) 2147483647, (java.awt.Paint) color23, stroke33);
        java.lang.Object obj35 = null;
        boolean boolean36 = valueMarker34.equals(obj35);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(range10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("TextAnchor.BASELINE_CENTER");
        java.awt.Shape shape2 = numberAxis3D1.getUpArrow();
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (short) 10, "series", textAnchor2, textAnchor3, (double) (short) 10);
        org.jfree.chart.text.TextAnchor textAnchor6 = numberTick5.getRotationAnchor();
        java.lang.String str7 = numberTick5.getText();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "series" + "'", str7.equals("series"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator3 = new org.jfree.chart.urls.StandardXYURLGenerator("", "Combined Range XYPlot", "35");
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean6 = xYAreaRenderer5.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator7 = null;
        xYAreaRenderer5.setLegendItemToolTipGenerator(xYSeriesLabelGenerator7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis3, valueAxis4, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer5);
        boolean boolean10 = xYAreaRenderer5.isOutline();
        java.awt.Font font12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYAreaRenderer5.setSeriesItemLabelFont(100, font12);
        xYAreaRenderer5.setBaseCreateEntities(false);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0, "0", "1");
        double double4 = timeSeries3.getMinY();
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(10);
        java.lang.Object obj2 = null;
        int int3 = objectList1.indexOf(obj2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D4 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D4.setUpperMargin((double) (short) 0);
        numberAxis3D4.resizeRange2((double) 10L, (double) 12);
        combinedDomainXYPlot1.setRangeAxis(8, (org.jfree.chart.axis.ValueAxis) numberAxis3D4, true);
        float float12 = numberAxis3D4.getTickMarkOutsideLength();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 2.0f + "'", float12 == 2.0f);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator1 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("series");
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        int int4 = combinedDomainXYPlot3.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.RenderingSource renderingSource7 = null;
        combinedDomainXYPlot3.select(generalPath5, rectangle2D6, renderingSource7);
        java.awt.Paint paint10 = combinedDomainXYPlot3.getQuadrantPaint((int) (short) 0);
        combinedDomainXYPlot3.setBackgroundAlpha(0.0f);
        org.jfree.chart.plot.Marker marker14 = null;
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean17 = combinedDomainXYPlot3.removeDomainMarker((-1), marker14, layer15, true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer19 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot22 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis21);
        java.awt.Paint paint23 = combinedDomainXYPlot22.getBackgroundPaint();
        xYAreaRenderer19.setSeriesPaint(2, paint23);
        xYAreaRenderer19.setAutoPopulateSeriesPaint(false);
        combinedDomainXYPlot3.setRenderer(0, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer19, true);
        java.awt.Color color29 = java.awt.Color.CYAN;
        combinedDomainXYPlot3.setRangeMinorGridlinePaint((java.awt.Paint) color29);
        boolean boolean31 = standardXYSeriesLabelGenerator1.equals((java.lang.Object) combinedDomainXYPlot3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor(10);
        java.lang.String str2 = pieLabelDistributor1.toString();
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord3 = null;
        try {
            pieLabelDistributor1.addPieLabelRecord(pieLabelRecord3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "" + "'", str2.equals(""));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("RangeType.FULL");
        java.lang.String str3 = legendItem2.getURLText();
        java.lang.String str4 = legendItem2.getURLText();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis5);
        double double7 = combinedRangeXYPlot6.getGap();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis8);
        java.awt.Paint paint10 = combinedDomainXYPlot9.getBackgroundPaint();
        combinedRangeXYPlot6.addChangeListener((org.jfree.chart.event.PlotChangeListener) combinedDomainXYPlot9);
        boolean boolean12 = legendItem2.equals((java.lang.Object) combinedRangeXYPlot6);
        legendItemCollection0.add(legendItem2);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline14 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int15 = segmentedTimeline14.getSegmentsExcluded();
        java.util.Date date16 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment17 = segmentedTimeline14.getSegment(date16);
        long long19 = segment17.calculateSegmentNumber((long) (short) 10);
        segment17.inc();
        legendItem2.setSeriesKey((java.lang.Comparable) segment17);
        boolean boolean22 = legendItem2.isLineVisible();
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 5.0d + "'", double7 == 5.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(segmentedTimeline14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 68 + "'", int15 == 68);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(segment17);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 2454364L + "'", long19 == 2454364L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries4.clear();
        timeSeries4.setDescription("series");
        int int8 = timeSeriesCollection0.indexOf(timeSeries4);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day9, (java.lang.Number) 12, false);
        boolean boolean13 = timeSeries4.getNotify();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year15 = month14.getYear();
        org.jfree.data.time.Year year16 = month14.getYear();
        try {
            timeSeries4.add((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) 100.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(year15);
        org.junit.Assert.assertNotNull(year16);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedDomainAxisSpace();
        categoryPlot0.clearAnnotations();
        org.jfree.chart.axis.AxisSpace axisSpace3 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.JFreeChart jFreeChart4 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent5 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot0, jFreeChart4);
        categoryPlot0.setRangeCrosshairValue((double) 4);
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.chart.util.Layer layer10 = null;
        boolean boolean12 = categoryPlot0.removeDomainMarker(28, marker9, layer10, false);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNull(axisSpace3);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint2 = categoryAxis3D1.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent6 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D1, jFreeChart3, (int) (short) 1, (int) (short) 10);
        categoryAxis3D1.setMaximumCategoryLabelWidthRatio((float) ' ');
        boolean boolean9 = categoryAxis3D1.isTickMarksVisible();
        categoryAxis3D1.setUpperMargin((double) (short) -1);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor12 = null;
        org.jfree.chart.plot.PiePlot3D piePlot3D15 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        piePlot3D15.setSimpleLabelOffset(rectangleInsets16);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection18 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries22.clear();
        timeSeries22.setDescription("series");
        int int26 = timeSeriesCollection18.indexOf(timeSeries22);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer28 = null;
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection18, (org.jfree.chart.axis.ValueAxis) numberAxis27, polarItemRenderer28);
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = polarPlot29.getOrientation();
        java.awt.Paint paint31 = polarPlot29.getRadiusGridlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer35 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean36 = xYAreaRenderer35.isOutline();
        java.awt.Shape shape37 = xYAreaRenderer35.getBaseShape();
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic39 = new org.jfree.chart.title.LegendGraphic(shape37, (java.awt.Paint) color38);
        legendGraphic39.setWidth((double) 8);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint45 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D46 = legendGraphic39.arrange(graphics2D42, rectangleConstraint45);
        double double47 = legendGraphic39.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor48 = legendGraphic39.getShapeLocation();
        java.awt.geom.Rectangle2D rectangle2D49 = legendGraphic39.getBounds();
        rectangleInsets34.trim(rectangle2D49);
        java.awt.Point point51 = polarPlot29.translateValueThetaRadiusToJava2D((double) (-1.0f), (double) (short) 100, rectangle2D49);
        java.awt.geom.Rectangle2D rectangle2D52 = rectangleInsets16.createInsetRectangle(rectangle2D49);
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = org.jfree.chart.util.RectangleEdge.RIGHT;
        try {
            double double54 = categoryAxis3D1.getCategoryJava2DCoordinate(categoryAnchor12, 255, 2147483647, rectangle2D49, rectangleEdge53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(size2D46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor48);
        org.junit.Assert.assertNotNull(rectangle2D49);
        org.junit.Assert.assertNotNull(point51);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertNotNull(rectangleEdge53);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("RectangleEdge.RIGHT");
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean6 = xYAreaRenderer5.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator7 = null;
        xYAreaRenderer5.setLegendItemToolTipGenerator(xYSeriesLabelGenerator7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis3, valueAxis4, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer5);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        xYPlot9.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) numberAxis3D11);
        java.awt.Paint paint13 = xYPlot9.getDomainTickBandPaint();
        boolean boolean14 = xYPlot9.isRangeZeroBaselineVisible();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        org.jfree.chart.LegendItem legendItem6 = barRenderer3D2.getLegendItem((int) (byte) 1, 1);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        barRenderer3D2.setSeriesToolTipGenerator((int) (byte) 10, categoryToolTipGenerator8, false);
        double double11 = barRenderer3D2.getShadowXOffset();
        double double12 = barRenderer3D2.getMaximumBarWidth();
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNull(legendItem6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.0d + "'", double11 == 4.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint3 = categoryAxis3D2.getLabelPaint();
        categoryAxis3D2.setTickMarkInsideLength((float) 0);
        java.awt.Font font6 = categoryAxis3D2.getLabelFont();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.lang.Class<?> wildcardClass12 = stroke11.getClass();
        boolean boolean13 = verticalAlignment10.equals((java.lang.Object) stroke11);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double16 = rectangleInsets14.calculateTopInset(10.0d);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font6, (java.awt.Paint) color7, rectangleEdge8, horizontalAlignment9, verticalAlignment10, rectangleInsets14);
        java.lang.Object obj18 = textTitle17.clone();
        int int19 = textTitle17.getMaximumLinesToDisplay();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2147483647 + "'", int19 == 2147483647);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeMinorGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer(10);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint6 = categoryAxis3D5.getLabelPaint();
        categoryAxis3D5.setTickMarkInsideLength((float) 0);
        categoryAxis3D5.addCategoryLabelToolTip((java.lang.Comparable) 1, "series");
        int int12 = categoryPlot0.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D5);
        double[] doubleArray19 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray24 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray25 = new double[][] { doubleArray19, doubleArray24 };
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray25);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot27 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset26);
        org.jfree.data.category.CategoryDataset categoryDataset28 = multiplePiePlot27.getDataset();
        boolean boolean29 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset28);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = categoryPlot0.getRendererForDataset(categoryDataset28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline32 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int33 = segmentedTimeline32.getSegmentsExcluded();
        java.util.Date date34 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment35 = segmentedTimeline32.getSegment(date34);
        java.util.Date date36 = segment35.getDate();
        segment35.dec();
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) segment35, false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(categoryItemRenderer30);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(segmentedTimeline32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 68 + "'", int33 == 68);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(segment35);
        org.junit.Assert.assertNotNull(date36);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries3.clear();
        timeSeries3.setDescription("series");
        timeSeries3.removeAgedItems(false);
        int int9 = timeSeries3.getMaximumItemCount();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection(timeSeries3);
        try {
            java.lang.Number number13 = timeSeriesCollection10.getStartY((int) (short) 100, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2147483647 + "'", int9 == 2147483647);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator1 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("series");
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.data.Range range5 = combinedDomainXYPlot3.getDataRange(valueAxis4);
        java.lang.Object obj6 = null;
        boolean boolean7 = combinedDomainXYPlot3.equals(obj6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        combinedDomainXYPlot3.setFixedRangeAxisSpace(axisSpace8);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection10 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries14.clear();
        timeSeries14.setDescription("series");
        int int18 = timeSeriesCollection10.indexOf(timeSeries14);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer20 = null;
        org.jfree.chart.plot.PolarPlot polarPlot21 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection10, (org.jfree.chart.axis.ValueAxis) numberAxis19, polarItemRenderer20);
        double double22 = numberAxis19.getAutoRangeMinimumSize();
        int int23 = combinedDomainXYPlot3.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis19);
        boolean boolean24 = standardXYSeriesLabelGenerator1.equals((java.lang.Object) int23);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0E-8d + "'", double22 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer3D2.getBaseItemLabelGenerator();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean6 = xYAreaRenderer5.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator7 = null;
        xYAreaRenderer5.setLegendItemToolTipGenerator(xYSeriesLabelGenerator7);
        boolean boolean9 = xYAreaRenderer5.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator11 = null;
        xYAreaRenderer5.setSeriesToolTipGenerator((int) (short) 100, xYToolTipGenerator11);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = xYAreaRenderer5.getNegativeItemLabelPosition(100, (int) (byte) -1, false);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor17 = itemLabelPosition16.getItemLabelAnchor();
        barRenderer3D2.setBasePositiveItemLabelPosition(itemLabelPosition16);
        org.jfree.chart.StandardChartTheme standardChartTheme20 = new org.jfree.chart.StandardChartTheme("TextBlockAnchor.CENTER");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo25 = new org.jfree.chart.ui.BasicProjectInfo("", "series", "series", "hi!");
        boolean boolean26 = standardChartTheme20.equals((java.lang.Object) "");
        java.awt.Font font27 = standardChartTheme20.getSmallFont();
        barRenderer3D2.setBaseItemLabelFont(font27, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator30 = barRenderer3D2.getBaseToolTipGenerator();
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(itemLabelAnchor17);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNull(categoryToolTipGenerator30);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) month0, false);
        xYSeries3.add((double) 10.0f, (java.lang.Number) 0.5d);
        xYSeries3.setMaximumItemCount((int) '#');
        xYSeries3.add((double) 0L, (java.lang.Number) 100);
        org.jfree.data.xy.XYDataItem xYDataItem14 = xYSeries3.addOrUpdate((java.lang.Number) 2.0d, (java.lang.Number) (-1));
        xYSeries3.add((double) 'a', (double) 0.5f, false);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNull(xYDataItem14);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        java.awt.Color color0 = java.awt.Color.white;
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D3 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = barRenderer3D3.getLegendItemLabelGenerator();
        double double5 = barRenderer3D3.getXOffset();
        barRenderer3D3.setBase((double) (short) 10);
        java.awt.Stroke stroke11 = barRenderer3D3.getItemOutlineStroke(2147483647, (-460), true);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.block.LineBorder lineBorder13 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke11, rectangleInsets12);
        java.awt.Stroke stroke14 = lineBorder13.getStroke();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.099412556013E12d + "'", double5 == 1.099412556013E12d);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint2 = categoryAxis3D1.getLabelPaint();
        categoryAxis3D1.setTickMarkInsideLength((float) 0);
        java.awt.Font font5 = categoryAxis3D1.getLabelFont();
        categoryAxis3D1.setCategoryMargin((double) 1L);
        java.awt.Paint paint8 = categoryAxis3D1.getLabelPaint();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer9 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean10 = xYAreaRenderer9.isOutline();
        java.awt.Shape shape11 = xYAreaRenderer9.getBaseShape();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic13 = new org.jfree.chart.title.LegendGraphic(shape11, (java.awt.Paint) color12);
        legendGraphic13.setWidth((double) 8);
        java.lang.Object obj16 = legendGraphic13.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = legendGraphic13.getShapeLocation();
        boolean boolean18 = categoryAxis3D1.equals((java.lang.Object) rectangleAnchor17);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        org.jfree.data.xy.XYDataItem xYDataItem5 = new org.jfree.data.xy.XYDataItem((double) 8, 100.0d);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 100.0d, true);
        double[] doubleArray14 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray19 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray20 = new double[][] { doubleArray14, doubleArray19 };
        org.jfree.data.category.CategoryDataset categoryDataset21 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray20);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot22 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset21);
        org.jfree.data.category.CategoryDataset categoryDataset23 = multiplePiePlot22.getDataset();
        boolean boolean24 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset23);
        categoryPlot0.setDataset(categoryDataset23);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(categoryDataset21);
        org.junit.Assert.assertNotNull(categoryDataset23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0.0f);
        java.lang.Object obj2 = valueMarker1.clone();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        valueMarker1.setLabelOffsetType(lengthAdjustmentType3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.data.Range range8 = combinedDomainXYPlot6.getDataRange(valueAxis7);
        valueMarker1.addChangeListener((org.jfree.chart.event.MarkerChangeListener) combinedDomainXYPlot6);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection10 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection10, true);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer15 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean16 = xYAreaRenderer15.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator17 = null;
        xYAreaRenderer15.setLegendItemToolTipGenerator(xYSeriesLabelGenerator17);
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection10, valueAxis13, valueAxis14, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer15);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = month20.next();
        org.jfree.data.xy.XYSeries xYSeries23 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) month20, false);
        xYSeries23.add((double) 10.0f, (java.lang.Number) 0.5d);
        xYSeries23.setMaximumItemCount((int) '#');
        xYSeriesCollection10.addSeries(xYSeries23);
        int int30 = combinedDomainXYPlot6.indexOf((org.jfree.data.xy.XYDataset) xYSeriesCollection10);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(lengthAdjustmentType3);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.centerRange((-1.0d));
        java.awt.Paint paint3 = numberAxis3D0.getTickLabelPaint();
        float float4 = numberAxis3D0.getTickMarkInsideLength();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D5.centerRange((-1.0d));
        java.awt.Paint paint8 = numberAxis3D5.getTickLabelPaint();
        org.jfree.data.Range range9 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double10 = range9.getLength();
        numberAxis3D5.setRangeWithMargins(range9, false, false);
        double double15 = range9.constrain(0.0d);
        numberAxis3D0.setRangeWithMargins(range9, true, false);
        numberAxis3D0.setAutoTickUnitSelection(true, false);
        double double22 = numberAxis3D0.getUpperBound();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.05d + "'", double22 == 1.05d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot3D0.setLabelGenerator(pieSectionLabelGenerator1);
        piePlot3D0.setShadowXOffset(0.0d);
        piePlot3D0.setIgnoreZeroValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot3D0.getSimpleLabelOffset();
        boolean boolean8 = piePlot3D0.getIgnoreZeroValues();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis9);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.data.Range range12 = combinedDomainXYPlot10.getDataRange(valueAxis11);
        java.lang.Object obj13 = null;
        boolean boolean14 = combinedDomainXYPlot10.equals(obj13);
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        combinedDomainXYPlot10.setRangeGridlineStroke(stroke15);
        piePlot3D0.setBaseSectionOutlineStroke(stroke15);
        org.jfree.chart.util.Rotation rotation18 = null;
        try {
            piePlot3D0.setDirection(rotation18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'direction' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        long long2 = segmentedTimeline0.getStartTime();
        long long3 = segmentedTimeline0.getSegmentsGroupSize();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2208927600000L) + "'", long2 == (-2208927600000L));
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 86400000L + "'", long3 == 86400000L);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        java.awt.Shape shape2 = xYAreaRenderer0.getBaseShape();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        legendGraphic4.setWidth((double) 8);
        java.lang.Object obj7 = legendGraphic4.clone();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = legendGraphic4.getShapeLocation();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D13 = legendGraphic4.arrange(graphics2D9, rectangleConstraint12);
        org.jfree.data.time.DateRange dateRange14 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        long long15 = dateRange14.getUpperMillis();
        java.util.Date date16 = dateRange14.getUpperDate();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = rectangleConstraint12.toRangeWidth((org.jfree.data.Range) dateRange14);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertNotNull(size2D13);
        org.junit.Assert.assertNotNull(dateRange14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1L + "'", long15 == 1L);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(rectangleConstraint17);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(date2);
        serialDate5.setDescription("[8.0, 100.0]");
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(segment3);
        org.junit.Assert.assertNotNull(serialDate5);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        org.jfree.chart.LegendItem legendItem6 = barRenderer3D2.getLegendItem((int) (byte) 1, 1);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        java.lang.String str11 = timeSeries10.getDomainDescription();
        java.lang.Class class12 = timeSeries10.getTimePeriodClass();
        boolean boolean13 = barRenderer3D2.equals((java.lang.Object) class12);
        int int14 = barRenderer3D2.getPassCount();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator16 = null;
        try {
            barRenderer3D2.setSeriesItemLabelGenerator((-9999), categoryItemLabelGenerator16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNull(legendItem6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "series" + "'", str11.equals("series"));
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        double double4 = barRenderer3D2.getXOffset();
        int int5 = barRenderer3D2.getColumnCount();
        double double6 = barRenderer3D2.getBase();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer3D2.setSeriesURLGenerator(3, categoryURLGenerator8);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.099412556013E12d + "'", double4 == 1.099412556013E12d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("java.awt.Color[r=255,g=128,b=128]", regularTimePeriod2, regularTimePeriod5);
        java.awt.Paint paint7 = periodAxis6.getMinorTickMarkPaint();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D8 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D8.centerRange((-1.0d));
        java.awt.Paint paint11 = numberAxis3D8.getTickLabelPaint();
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double13 = range12.getLength();
        numberAxis3D8.setRangeWithMargins(range12, false, false);
        periodAxis6.setRange(range12, false, false);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection20 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries24.clear();
        timeSeries24.setDescription("series");
        int int28 = timeSeriesCollection20.indexOf(timeSeries24);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day();
        timeSeries24.add((org.jfree.data.time.RegularTimePeriod) day29, (java.lang.Number) 12, false);
        boolean boolean33 = timeSeries24.getNotify();
        java.lang.Class class34 = timeSeries24.getTimePeriodClass();
        periodAxis6.setMinorTickTimePeriodClass(class34);
        periodAxis6.setMinorTickMarkInsideLength((-1.0f));
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(class34);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        combinedDomainXYPlot1.select(generalPath3, rectangle2D4, renderingSource5);
        java.awt.Paint paint8 = combinedDomainXYPlot1.getQuadrantPaint((int) (short) 0);
        combinedDomainXYPlot1.setBackgroundAlpha(0.0f);
        java.awt.Paint paint11 = combinedDomainXYPlot1.getRangeGridlinePaint();
        boolean boolean12 = combinedDomainXYPlot1.isNotify();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        java.awt.Shape shape2 = xYAreaRenderer0.getBaseShape();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        legendGraphic4.setWidth((double) 8);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D11 = legendGraphic4.arrange(graphics2D7, rectangleConstraint10);
        double double12 = legendGraphic4.getHeight();
        boolean boolean13 = legendGraphic4.isShapeVisible();
        boolean boolean14 = legendGraphic4.isShapeOutlineVisible();
        java.awt.Paint paint15 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        legendGraphic4.setLinePaint(paint15);
        legendGraphic4.setLineVisible(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(size2D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot3D0.setLabelGenerator(pieSectionLabelGenerator1);
        piePlot3D0.setShadowXOffset(0.0d);
        piePlot3D0.setIgnoreZeroValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot3D0.getSimpleLabelOffset();
        boolean boolean8 = piePlot3D0.getAutoPopulateSectionPaint();
        java.awt.Paint paint9 = piePlot3D0.getLabelLinkPaint();
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        combinedDomainXYPlot1.setForegroundAlpha((float) (-1));
        int int5 = combinedDomainXYPlot1.getDomainAxisCount();
        double double6 = combinedDomainXYPlot1.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("ClassContext");
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        org.jfree.chart.LegendItem legendItem6 = barRenderer3D2.getLegendItem((int) (byte) 1, 1);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = barRenderer3D2.getLegendItemLabelGenerator();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer3D2.setBaseURLGenerator(categoryURLGenerator8, false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNull(legendItem6);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator7);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.panRangeAxes((double) (byte) 100, plotRenderingInfo4, point2D5);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = categoryPlot7.getDomainMarkers(layer8);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray10 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot7.setDomainAxes(categoryAxisArray10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot7.setRenderer(categoryItemRenderer12, false);
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot7.setDomainAxisLocation(1900, axisLocation16, false);
        categoryPlot0.setRangeAxisLocation(axisLocation16);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNotNull(categoryAxisArray10);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        java.awt.Paint paint3 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.StandardChartTheme standardChartTheme5 = new org.jfree.chart.StandardChartTheme("TextBlockAnchor.CENTER");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection6 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection6, true);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer11 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean12 = xYAreaRenderer11.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator13 = null;
        xYAreaRenderer11.setLegendItemToolTipGenerator(xYSeriesLabelGenerator13);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection6, valueAxis9, valueAxis10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer11);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        xYPlot15.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) numberAxis3D17);
        boolean boolean19 = numberAxis3D17.isTickMarksVisible();
        java.awt.Font font20 = numberAxis3D17.getTickLabelFont();
        java.awt.Color color21 = org.jfree.chart.ChartColor.DARK_GREEN;
        numberAxis3D17.setTickMarkPaint((java.awt.Paint) color21);
        standardChartTheme5.setLegendBackgroundPaint((java.awt.Paint) color21);
        java.awt.Paint paint24 = standardChartTheme5.getTitlePaint();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot26 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis25);
        int int27 = combinedDomainXYPlot26.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.RenderingSource renderingSource30 = null;
        combinedDomainXYPlot26.select(generalPath28, rectangle2D29, renderingSource30);
        java.awt.Paint paint33 = combinedDomainXYPlot26.getQuadrantPaint((int) (short) 0);
        combinedDomainXYPlot26.setBackgroundAlpha(0.0f);
        java.awt.Paint paint36 = combinedDomainXYPlot26.getRangeGridlinePaint();
        standardChartTheme5.setPlotBackgroundPaint(paint36);
        categoryPlot0.setDomainGridlinePaint(paint36);
        double[] doubleArray45 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray50 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray51 = new double[][] { doubleArray45, doubleArray50 };
        org.jfree.data.category.CategoryDataset categoryDataset52 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray51);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot53 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset52);
        org.jfree.data.category.CategoryDataset categoryDataset54 = multiplePiePlot53.getDataset();
        org.jfree.data.Range range56 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds(categoryDataset54, false);
        categoryPlot0.setDataset(categoryDataset54);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor58 = categoryPlot0.getDomainGridlinePosition();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 15 + "'", int27 == 15);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(categoryDataset52);
        org.junit.Assert.assertNotNull(categoryDataset54);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertNotNull(categoryAnchor58);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer3D2.getBaseItemLabelGenerator();
        boolean boolean5 = barRenderer3D2.getBaseSeriesVisible();
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.ProjectInfo projectInfo1 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) projectInfo1);
        org.jfree.chart.ui.ProjectInfo projectInfo3 = new org.jfree.chart.ui.ProjectInfo();
        java.awt.Image image4 = null;
        projectInfo3.setLogo(image4);
        projectInfo1.addLibrary((org.jfree.chart.ui.Library) projectInfo3);
        java.awt.Image image7 = null;
        projectInfo1.setLogo(image7);
        org.junit.Assert.assertNotNull(projectInfo1);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray3 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray3);
        categoryPlot0.setWeight(2147483647);
        org.jfree.chart.ChartColor chartColor13 = new org.jfree.chart.ChartColor(1, 3, (int) (short) 100);
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (double) 68, (java.awt.Paint) chartColor13);
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean17 = categoryPlot0.removeDomainMarker(28, (org.jfree.chart.plot.Marker) intervalMarker14, layer15, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = categoryPlot0.getDrawingSupplier();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(categoryAxisArray3);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(drawingSupplier18);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year1 = month0.getYear();
        org.jfree.data.time.Year year2 = month0.getYear();
        long long3 = month0.getMiddleMillisecond();
        org.junit.Assert.assertNotNull(year1);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560668399999L + "'", long3 == 1560668399999L);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot3D0.setLabelGenerator(pieSectionLabelGenerator1);
        piePlot3D0.setShadowXOffset(0.0d);
        double double5 = piePlot3D0.getDepthFactor();
        java.awt.Paint paint6 = piePlot3D0.getLabelOutlinePaint();
        piePlot3D0.setMinimumArcAngleToDraw(0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.12d + "'", double5 == 0.12d);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.SECOND;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateRightOutset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        double[] doubleArray6 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray11 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray12 = new double[][] { doubleArray6, doubleArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        java.lang.Number number15 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset13);
        org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset13, 0);
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot(pieDataset17);
        ringPlot18.setSeparatorsVisible(false);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator21 = null;
        ringPlot18.setLegendLabelURLGenerator(pieURLGenerator21);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1.0d + "'", number15.equals(1.0d));
        org.junit.Assert.assertNotNull(pieDataset17);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        java.awt.Paint paint3 = categoryPlot0.getDomainCrosshairPaint();
        double[] doubleArray10 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray15 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray16 = new double[][] { doubleArray10, doubleArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray16);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot18 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset17);
        org.jfree.chart.JFreeChart jFreeChart19 = multiplePiePlot18.getPieChart();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D22 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint23 = categoryAxis3D22.getLabelPaint();
        categoryAxis3D22.setTickMarkInsideLength((float) 0);
        java.awt.Font font26 = categoryAxis3D22.getLabelFont();
        java.awt.Color color27 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment29 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment30 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.lang.Class<?> wildcardClass32 = stroke31.getClass();
        boolean boolean33 = verticalAlignment30.equals((java.lang.Object) stroke31);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double36 = rectangleInsets34.calculateTopInset(10.0d);
        org.jfree.chart.title.TextTitle textTitle37 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font26, (java.awt.Paint) color27, rectangleEdge28, horizontalAlignment29, verticalAlignment30, rectangleInsets34);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent38 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle37);
        jFreeChart19.titleChanged(titleChangeEvent38);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent40 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot0, jFreeChart19);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(jFreeChart19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNotNull(horizontalAlignment29);
        org.junit.Assert.assertNotNull(verticalAlignment30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection2 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection2, true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer7 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean8 = xYAreaRenderer7.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator9 = null;
        xYAreaRenderer7.setLegendItemToolTipGenerator(xYSeriesLabelGenerator9);
        org.jfree.chart.plot.XYPlot xYPlot11 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection2, valueAxis5, valueAxis6, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer7);
        boolean boolean12 = xYAreaRenderer7.isOutline();
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYAreaRenderer7.setSeriesItemLabelFont(100, font14);
        piePlot3D1.setLabelFont(font14);
        double double17 = piePlot3D1.getMaximumExplodePercent();
        piePlot3D1.setLabelLinksVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = piePlot3D1.getLabelPadding();
        java.lang.String str21 = piePlot3D1.getPlotType();
        boolean boolean22 = tickUnits0.equals((java.lang.Object) str21);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Pie 3D Plot" + "'", str21.equals("Pie 3D Plot"));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D2 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint3 = categoryAxis3D2.getLabelPaint();
        categoryAxis3D2.setTickMarkInsideLength((float) 0);
        java.awt.Font font6 = categoryAxis3D2.getLabelFont();
        java.awt.Color color7 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.lang.Class<?> wildcardClass12 = stroke11.getClass();
        boolean boolean13 = verticalAlignment10.equals((java.lang.Object) stroke11);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double16 = rectangleInsets14.calculateTopInset(10.0d);
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font6, (java.awt.Paint) color7, rectangleEdge8, horizontalAlignment9, verticalAlignment10, rectangleInsets14);
        java.lang.Object obj18 = textTitle17.clone();
        textTitle17.setHeight((-98.0d));
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        double[] doubleArray6 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray11 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray12 = new double[][] { doubleArray6, doubleArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        org.jfree.chart.JFreeChart jFreeChart15 = multiplePiePlot14.getPieChart();
        jFreeChart15.setTextAntiAlias(false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(jFreeChart15);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        double[] doubleArray6 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray11 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray12 = new double[][] { doubleArray6, doubleArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        org.jfree.chart.JFreeChart jFreeChart15 = multiplePiePlot14.getPieChart();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D18 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint19 = categoryAxis3D18.getLabelPaint();
        categoryAxis3D18.setTickMarkInsideLength((float) 0);
        java.awt.Font font22 = categoryAxis3D18.getLabelFont();
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment25 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        org.jfree.chart.util.VerticalAlignment verticalAlignment26 = org.jfree.chart.util.VerticalAlignment.TOP;
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.lang.Class<?> wildcardClass28 = stroke27.getClass();
        boolean boolean29 = verticalAlignment26.equals((java.lang.Object) stroke27);
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double32 = rectangleInsets30.calculateTopInset(10.0d);
        org.jfree.chart.title.TextTitle textTitle33 = new org.jfree.chart.title.TextTitle("TextBlockAnchor.CENTER", font22, (java.awt.Paint) color23, rectangleEdge24, horizontalAlignment25, verticalAlignment26, rectangleInsets30);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent34 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle33);
        jFreeChart15.titleChanged(titleChangeEvent34);
        jFreeChart15.setBackgroundImageAlpha(0.0f);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(jFreeChart15);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(horizontalAlignment25);
        org.junit.Assert.assertNotNull(verticalAlignment26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getNumberInstance();
        java.lang.String str3 = numberFormat1.format(0.0d);
        java.text.NumberFormat numberFormat4 = java.text.NumberFormat.getNumberInstance();
        java.lang.String str6 = numberFormat4.format((long) 1);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator7 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Combined Range XYPlot", numberFormat1, numberFormat4);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        java.lang.String str10 = standardPieSectionLabelGenerator7.generateSectionLabel(pieDataset8, (java.lang.Comparable) 900000L);
        org.jfree.data.Range range11 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double12 = range11.getLength();
        boolean boolean13 = standardPieSectionLabelGenerator7.equals((java.lang.Object) range11);
        java.lang.String str14 = range11.toString();
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1" + "'", str6.equals("1"));
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Range[0.0,1.0]" + "'", str14.equals("Range[0.0,1.0]"));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        double[] doubleArray6 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray11 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray12 = new double[][] { doubleArray6, doubleArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        org.jfree.chart.JFreeChart jFreeChart15 = multiplePiePlot14.getPieChart();
        jFreeChart15.setBorderVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot19 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis18);
        java.awt.Paint paint20 = combinedDomainXYPlot19.getBackgroundPaint();
        jFreeChart15.setBorderPaint(paint20);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(jFreeChart15);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        boolean boolean3 = categoryPlot0.isDomainPannable();
        java.lang.Comparable comparable4 = null;
        categoryPlot0.setDomainCrosshairRowKey(comparable4, false);
        java.awt.Paint paint7 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_WALL_PAINT;
        categoryPlot0.setRangeZeroBaselinePaint(paint7);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 1, (double) 100.0f);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.plot.PiePlot3D piePlot3D6 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = null;
        piePlot3D6.setLabelGenerator(pieSectionLabelGenerator7);
        piePlot3D6.setShadowXOffset(0.0d);
        piePlot3D6.setIgnoreZeroValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = piePlot3D6.getSimpleLabelOffset();
        blockContainer5.setPadding(rectangleInsets13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint(0.0d, (double) (-1L));
        org.jfree.chart.util.Size2D size2D19 = blockContainer5.arrange(graphics2D15, rectangleConstraint18);
        blockContainer5.clear();
        org.jfree.chart.block.FlowArrangement flowArrangement21 = new org.jfree.chart.block.FlowArrangement();
        blockContainer5.setArrangement((org.jfree.chart.block.Arrangement) flowArrangement21);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(size2D19);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeMinorGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = categoryPlot0.getRenderer(10);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D5 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint6 = categoryAxis3D5.getLabelPaint();
        categoryAxis3D5.setTickMarkInsideLength((float) 0);
        categoryAxis3D5.addCategoryLabelToolTip((java.lang.Comparable) 1, "series");
        int int12 = categoryPlot0.getDomainAxisIndex((org.jfree.chart.axis.CategoryAxis) categoryAxis3D5);
        double[] doubleArray19 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray24 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray25 = new double[][] { doubleArray19, doubleArray24 };
        org.jfree.data.category.CategoryDataset categoryDataset26 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray25);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot27 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset26);
        org.jfree.data.category.CategoryDataset categoryDataset28 = multiplePiePlot27.getDataset();
        boolean boolean29 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset28);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = categoryPlot0.getRendererForDataset(categoryDataset28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint32 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        try {
            categoryPlot0.handleClick(7, (int) (byte) 0, plotRenderingInfo35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categoryItemRenderer3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(categoryDataset26);
        org.junit.Assert.assertNotNull(categoryDataset28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(categoryItemRenderer30);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        double double4 = barRenderer3D2.getXOffset();
        barRenderer3D2.setBase((double) (short) 10);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = null;
        barRenderer3D2.setSeriesItemLabelGenerator(10, categoryItemLabelGenerator8);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation10 = null;
        org.jfree.chart.util.Layer layer11 = null;
        try {
            barRenderer3D2.addAnnotation(categoryAnnotation10, layer11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.099412556013E12d + "'", double4 == 1.099412556013E12d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries3.clear();
        timeSeries3.setDescription("series");
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance((int) '4');
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate8);
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day9);
        org.junit.Assert.assertNotNull(serialDate8);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long3 = segmentedTimeline0.getExceptionSegmentCount((long) (short) 10, (long) 100);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline4 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int5 = segmentedTimeline4.getSegmentsExcluded();
        java.util.Date date7 = segmentedTimeline4.getDate((long) 11);
        long long8 = segmentedTimeline0.getTime(date7);
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertNotNull(segmentedTimeline4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 68 + "'", int5 == 68);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 11L + "'", long8 == 11L);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        org.jfree.chart.LegendItem legendItem6 = barRenderer3D2.getLegendItem((int) (byte) 1, 1);
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        java.lang.String str11 = timeSeries10.getDomainDescription();
        java.lang.Class class12 = timeSeries10.getTimePeriodClass();
        boolean boolean13 = barRenderer3D2.equals((java.lang.Object) class12);
        int int14 = barRenderer3D2.getPassCount();
        double double15 = barRenderer3D2.getYOffset();
        barRenderer3D2.setBaseCreateEntities(false, true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNull(legendItem6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "series" + "'", str11.equals("series"));
        org.junit.Assert.assertNull(class12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("java.awt.Color[r=255,g=128,b=128]", regularTimePeriod2, regularTimePeriod5);
        java.awt.Paint paint7 = periodAxis6.getMinorTickMarkPaint();
        java.lang.Class class8 = periodAxis6.getAutoRangeTimePeriodClass();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer10 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = null;
        xYAreaRenderer10.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition12);
        boolean boolean14 = xYAreaRenderer10.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Paint paint16 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYAreaRenderer10.setSeriesItemLabelPaint((int) '#', paint16, false);
        org.jfree.chart.plot.PiePlot3D piePlot3D19 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection20 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range22 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection20, true);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer25 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean26 = xYAreaRenderer25.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator27 = null;
        xYAreaRenderer25.setLegendItemToolTipGenerator(xYSeriesLabelGenerator27);
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection20, valueAxis23, valueAxis24, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer25);
        boolean boolean30 = xYAreaRenderer25.isOutline();
        java.awt.Font font32 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYAreaRenderer25.setSeriesItemLabelFont(100, font32);
        piePlot3D19.setLabelFont(font32);
        double double35 = piePlot3D19.getMaximumExplodePercent();
        piePlot3D19.setLabelLinksVisible(true);
        double double38 = piePlot3D19.getMaximumExplodePercent();
        org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker((double) 0.0f);
        java.lang.Object obj41 = valueMarker40.clone();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType42 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        valueMarker40.setLabelOffsetType(lengthAdjustmentType42);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot45 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis44);
        int int46 = combinedDomainXYPlot45.getBackgroundImageAlignment();
        combinedDomainXYPlot45.setForegroundAlpha((float) (-1));
        java.awt.Stroke stroke49 = combinedDomainXYPlot45.getDomainMinorGridlineStroke();
        valueMarker40.setStroke(stroke49);
        piePlot3D19.setBaseSectionOutlineStroke(stroke49);
        org.jfree.chart.plot.ValueMarker valueMarker52 = new org.jfree.chart.plot.ValueMarker((double) (short) 1, paint16, stroke49);
        periodAxis6.setMinorTickMarkPaint(paint16);
        boolean boolean55 = periodAxis6.equals((java.lang.Object) 'a');
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(class8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(range22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertNotNull(lengthAdjustmentType42);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 15 + "'", int46 == 15);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getBaseShapesVisible();
        java.awt.Shape shape2 = xYLineAndShapeRenderer0.getLegendLine();
        java.lang.Boolean boolean4 = xYLineAndShapeRenderer0.getSeriesShapesVisible(4);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = null;
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator10 = new org.jfree.chart.urls.StandardXYURLGenerator("Pie 3D Plot", "poly", "35");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer11 = new org.jfree.chart.renderer.xy.XYAreaRenderer((-460), xYToolTipGenerator6, (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator10);
        xYLineAndShapeRenderer0.setBaseURLGenerator((org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(boolean4);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection1, true);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean7 = xYAreaRenderer6.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator8 = null;
        xYAreaRenderer6.setLegendItemToolTipGenerator(xYSeriesLabelGenerator8);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection1, valueAxis4, valueAxis5, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer6);
        boolean boolean11 = xYAreaRenderer6.isOutline();
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYAreaRenderer6.setSeriesItemLabelFont(100, font13);
        piePlot3D0.setLabelFont(font13);
        double double16 = piePlot3D0.getMaximumExplodePercent();
        piePlot3D0.setLabelLinksVisible(true);
        boolean boolean19 = piePlot3D0.isCircular();
        piePlot3D0.setIgnoreZeroValues(true);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        double[] doubleArray6 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray11 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray12 = new double[][] { doubleArray6, doubleArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        java.lang.Number number15 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset13);
        org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset13, 0);
        org.jfree.chart.plot.RingPlot ringPlot18 = new org.jfree.chart.plot.RingPlot(pieDataset17);
        java.awt.Stroke stroke19 = ringPlot18.getSeparatorStroke();
        java.awt.Stroke stroke20 = ringPlot18.getSeparatorStroke();
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker((double) 0.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent24 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker23);
        org.jfree.chart.plot.Marker marker25 = markerChangeEvent24.getMarker();
        java.awt.Stroke stroke26 = marker25.getStroke();
        ringPlot18.setSectionOutlineStroke((java.lang.Comparable) "hi!", stroke26);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1.0d + "'", number15.equals(1.0d));
        org.junit.Assert.assertNotNull(pieDataset17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(marker25);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        java.awt.Paint paint3 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.StandardChartTheme standardChartTheme5 = new org.jfree.chart.StandardChartTheme("TextBlockAnchor.CENTER");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection6 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range8 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection6, true);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer11 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean12 = xYAreaRenderer11.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator13 = null;
        xYAreaRenderer11.setLegendItemToolTipGenerator(xYSeriesLabelGenerator13);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection6, valueAxis9, valueAxis10, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer11);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D17 = new org.jfree.chart.axis.NumberAxis3D();
        xYPlot15.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) numberAxis3D17);
        boolean boolean19 = numberAxis3D17.isTickMarksVisible();
        java.awt.Font font20 = numberAxis3D17.getTickLabelFont();
        java.awt.Color color21 = org.jfree.chart.ChartColor.DARK_GREEN;
        numberAxis3D17.setTickMarkPaint((java.awt.Paint) color21);
        standardChartTheme5.setLegendBackgroundPaint((java.awt.Paint) color21);
        java.awt.Paint paint24 = standardChartTheme5.getTitlePaint();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot26 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis25);
        int int27 = combinedDomainXYPlot26.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.RenderingSource renderingSource30 = null;
        combinedDomainXYPlot26.select(generalPath28, rectangle2D29, renderingSource30);
        java.awt.Paint paint33 = combinedDomainXYPlot26.getQuadrantPaint((int) (short) 0);
        combinedDomainXYPlot26.setBackgroundAlpha(0.0f);
        java.awt.Paint paint36 = combinedDomainXYPlot26.getRangeGridlinePaint();
        standardChartTheme5.setPlotBackgroundPaint(paint36);
        categoryPlot0.setDomainGridlinePaint(paint36);
        java.awt.Paint paint39 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        categoryPlot0.setDomainGridlinePaint(paint39);
        org.jfree.data.category.CategoryDataset categoryDataset42 = categoryPlot0.getDataset(13);
        java.awt.Paint paint43 = categoryPlot0.getBackgroundPaint();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 15 + "'", int27 == 15);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNull(categoryDataset42);
        org.junit.Assert.assertNotNull(paint43);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 1, (double) 100.0f);
        flowArrangement4.clear();
        org.jfree.chart.renderer.xy.XYStepAreaRenderer xYStepAreaRenderer7 = new org.jfree.chart.renderer.xy.XYStepAreaRenderer(28);
        boolean boolean8 = flowArrangement4.equals((java.lang.Object) xYStepAreaRenderer7);
        xYStepAreaRenderer7.setSeriesVisible(68, (java.lang.Boolean) false);
        boolean boolean12 = xYStepAreaRenderer7.isOutline();
        xYStepAreaRenderer7.setOutline(false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.trimWidth((double) 1560495599999L);
        double double4 = rectangleInsets0.calculateTopOutset((double) (-460));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.560495599991E12d + "'", double2 == 1.560495599991E12d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0d + "'", double4 == 2.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries4.clear();
        timeSeries4.setDescription("series");
        int int8 = timeSeriesCollection0.indexOf(timeSeries4);
        java.lang.String str9 = timeSeries4.getRangeDescription();
        timeSeries4.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "0" + "'", str9.equals("0"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean6 = xYAreaRenderer5.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator7 = null;
        xYAreaRenderer5.setLegendItemToolTipGenerator(xYSeriesLabelGenerator7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis3, valueAxis4, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer5);
        float float10 = xYPlot9.getBackgroundAlpha();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double13 = rectangleInsets11.trimWidth((double) 1560495599999L);
        xYPlot9.setAxisOffset(rectangleInsets11);
        double double15 = rectangleInsets11.getBottom();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.560495599991E12d + "'", double13 == 1.560495599991E12d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.0d + "'", double15 == 2.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.panRangeAxes((double) (byte) 100, plotRenderingInfo4, point2D5);
        java.awt.Stroke stroke7 = categoryPlot0.getRangeMinorGridlineStroke();
        int int8 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot0.getDomainAxisEdge((int) (byte) 1);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge10);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = categoryPlot3.getDomainMarkers(layer4);
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot3.getFixedDomainAxisSpace();
        barRenderer3D2.setPlot(categoryPlot3);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer3D2.setBaseURLGenerator(categoryURLGenerator8);
        org.junit.Assert.assertNull(collection5);
        org.junit.Assert.assertNull(axisSpace6);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor1 = org.jfree.data.time.TimePeriodAnchor.END;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint4 = categoryAxis3D3.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D3, jFreeChart5, (int) (short) 1, (int) (short) 10);
        boolean boolean9 = timePeriodAnchor1.equals((java.lang.Object) (short) 10);
        timeSeriesCollection0.setXPosition(timePeriodAnchor1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate11 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0, true);
        org.junit.Assert.assertNotNull(timePeriodAnchor1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(range13);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries4.clear();
        timeSeries4.setDescription("series");
        int int8 = timeSeriesCollection0.indexOf(timeSeries4);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
        timeSeries4.add((org.jfree.data.time.RegularTimePeriod) day9, (java.lang.Number) 12, false);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot14 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis13);
        int int15 = combinedDomainXYPlot14.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.RenderingSource renderingSource18 = null;
        combinedDomainXYPlot14.select(generalPath16, rectangle2D17, renderingSource18);
        java.awt.Paint paint21 = combinedDomainXYPlot14.getQuadrantPaint((int) (short) 0);
        combinedDomainXYPlot14.clearAnnotations();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier23 = combinedDomainXYPlot14.getDrawingSupplier();
        java.awt.geom.GeneralPath generalPath24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.RenderingSource renderingSource26 = null;
        combinedDomainXYPlot14.select(generalPath24, rectangle2D25, renderingSource26);
        java.awt.Paint paint28 = combinedDomainXYPlot14.getDomainTickBandPaint();
        boolean boolean29 = day9.equals((java.lang.Object) paint28);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNotNull(drawingSupplier23);
        org.junit.Assert.assertNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        java.awt.Paint paint3 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        xYAreaRenderer4.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition6);
        boolean boolean8 = xYAreaRenderer4.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D9.centerRange((-1.0d));
        java.awt.Paint paint12 = numberAxis3D9.getTickLabelPaint();
        xYAreaRenderer4.setBaseFillPaint(paint12, true);
        categoryPlot0.setDomainCrosshairPaint(paint12);
        int int16 = categoryPlot0.getRangeAxisCount();
        java.awt.Stroke stroke17 = categoryPlot0.getRangeCrosshairStroke();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 1, (double) 100.0f);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.block.BlockContainer blockContainer6 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.lang.Object obj1 = xYLineAndShapeRenderer0.clone();
        boolean boolean2 = xYLineAndShapeRenderer0.getBaseShapesVisible();
        boolean boolean3 = xYLineAndShapeRenderer0.getDrawOutlines();
        java.awt.Font font4 = xYLineAndShapeRenderer0.getBaseLegendTextFont();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(font4);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        org.jfree.data.xy.XYDataItem xYDataItem5 = new org.jfree.data.xy.XYDataItem((double) 8, 100.0d);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 100.0d, true);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis8);
        int int10 = combinedDomainXYPlot9.getBackgroundImageAlignment();
        combinedDomainXYPlot9.setForegroundAlpha((float) (-1));
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot14 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis13);
        int int15 = combinedDomainXYPlot14.getBackgroundImageAlignment();
        combinedDomainXYPlot14.setForegroundAlpha((float) (-1));
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        combinedDomainXYPlot14.setDomainAxisLocation((int) (short) 1, axisLocation19);
        combinedDomainXYPlot9.setDomainAxisLocation(axisLocation19);
        categoryPlot0.setRangeAxisLocation(axisLocation19, false);
        org.jfree.chart.axis.AxisLocation axisLocation25 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot0.setRangeAxisLocation((int) (short) 0, axisLocation25);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation27 = null;
        try {
            boolean boolean29 = categoryPlot0.removeAnnotation(categoryAnnotation27, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(axisLocation25);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        int int1 = tickUnits0.size();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot3D0.setLabelGenerator(pieSectionLabelGenerator1);
        piePlot3D0.setShadowXOffset(0.0d);
        piePlot3D0.setIgnoreZeroValues(false);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator7 = piePlot3D0.getLegendLabelToolTipGenerator();
        org.junit.Assert.assertNull(pieSectionLabelGenerator7);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test192");
//        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection2 = new org.jfree.data.time.TimeSeriesCollection();
//        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
//        timeSeries6.clear();
//        timeSeries6.setDescription("series");
//        int int10 = timeSeriesCollection2.indexOf(timeSeries6);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        timeSeries6.add((org.jfree.data.time.RegularTimePeriod) day11, (java.lang.Number) 12, false);
//        long long15 = day11.getLastMillisecond();
//        int int16 = day11.getDayOfMonth();
//        org.jfree.chart.axis.PeriodAxis periodAxis17 = new org.jfree.chart.axis.PeriodAxis("", (org.jfree.data.time.RegularTimePeriod) month1, (org.jfree.data.time.RegularTimePeriod) day11);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day11.next();
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560495599999L + "'", long15 == 1560495599999L);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 13 + "'", int16 == 13);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        java.awt.Paint paint4 = combinedDomainXYPlot3.getBackgroundPaint();
        xYAreaRenderer0.setSeriesPaint(2, paint4);
        java.awt.Shape shape6 = xYAreaRenderer0.getBaseShape();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator7 = xYAreaRenderer0.getBaseItemLabelGenerator();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(xYItemLabelGenerator7);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangePannable(true);
        org.jfree.chart.axis.AxisSpace axisSpace4 = combinedDomainXYPlot1.getFixedDomainAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = combinedDomainXYPlot1.getDomainAxisEdge((int) (short) -1);
        boolean boolean7 = combinedDomainXYPlot1.isDomainCrosshairLockedOnData();
        org.junit.Assert.assertNull(axisSpace4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }
}

