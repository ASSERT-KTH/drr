import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        org.junit.Assert.assertNull(rectangleEdge1);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.SHAPES_AND_LINES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        java.util.TimeZone timeZone0 = null;
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource2 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0, locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.awt.Shape shape0 = null;
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.clone(shape0);
        org.junit.Assert.assertNull(shape1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.awt.Shape shape0 = null;
        java.awt.Paint paint1 = null;
        try {
            org.jfree.chart.title.LegendGraphic legendGraphic2 = new org.jfree.chart.title.LegendGraphic(shape0, paint1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = null;
        org.jfree.chart.text.TextAnchor textAnchor1 = null;
        org.jfree.chart.text.TextAnchor textAnchor2 = null;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1, textAnchor2, (double) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'itemLabelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.lang.Class class1 = null;
        java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("hi!", class1);
        org.junit.Assert.assertNull(inputStream2);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        java.awt.Paint paint5 = null;
        java.awt.Stroke stroke6 = null;
        java.awt.Paint paint7 = null;
        try {
            org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem(attributedString0, "", "", "hi!", shape4, paint5, stroke6, paint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_SECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("hi!", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_FIRST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        int int4 = combinedDomainXYPlot3.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot3.rendererChanged(rendererChangeEvent6);
        combinedDomainXYPlot1.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot3);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = null;
        try {
            combinedDomainXYPlot1.setOrientation(plotOrientation9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.jfree.data.time.SerialDate.MONDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            boolean boolean3 = org.jfree.chart.util.ShapeUtilities.isPointInRect((double) (byte) -1, (double) 10.0f, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        try {
            xYSeriesCollection0.setSelected((int) (byte) 100, 3, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        combinedDomainXYPlot1.setForegroundAlpha((float) (-1));
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder5 = null;
        try {
            combinedDomainXYPlot1.setSeriesRenderingOrder(seriesRenderingOrder5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultShadowsVisible(false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        boolean boolean1 = org.jfree.data.time.SerialDate.isLeapYear((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.Range.shift(range0, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        try {
            xYSeriesCollection0.setIntervalPositionFactor((double) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Argument 'd' outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        double double1 = crosshairState0.getCrosshairX();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.jfree.data.time.SerialDate.LAST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Paint paint2 = null;
        try {
            org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("hi!", font1, paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        crosshairState0.setAnchorY((double) 1.0f);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        int int4 = combinedDomainXYPlot3.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot3.rendererChanged(rendererChangeEvent6);
        combinedDomainXYPlot1.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot3);
        try {
            combinedDomainXYPlot1.setBackgroundImageAlpha((float) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MONTH;
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 3, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        java.awt.Paint paint2 = combinedDomainXYPlot1.getBackgroundPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        try {
            combinedDomainXYPlot1.zoomRangeAxes((double) 0.0f, (double) (byte) 10, plotRenderingInfo5, point2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Month month1 = new org.jfree.data.time.Month(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, (double) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        java.awt.Paint paint4 = combinedDomainXYPlot3.getBackgroundPaint();
        xYAreaRenderer0.setSeriesPaint(2, paint4);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis9);
        int int11 = combinedDomainXYPlot10.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot10.rendererChanged(rendererChangeEvent13);
        combinedDomainXYPlot8.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot10);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer19 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot22 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis21);
        java.awt.Paint paint23 = combinedDomainXYPlot22.getBackgroundPaint();
        xYAreaRenderer19.setSeriesPaint(2, paint23);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        try {
            xYAreaRenderer0.drawRangeLine(graphics2D6, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot8, valueAxis16, rectangle2D17, (double) 100, paint23, stroke25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.awt.Color color1 = java.awt.Color.getColor("hi!");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 10L, (double) 8, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray2 = new float[] {};
        try {
            float[] floatArray3 = color0.getColorComponents(colorSpace1, floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        boolean boolean2 = xYAreaRenderer0.getAutoPopulateSeriesOutlinePaint();
        boolean boolean3 = xYAreaRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            rectangleInsets0.trim(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int int0 = org.jfree.chart.renderer.xy.XYAreaRenderer.LINES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        java.awt.Paint paint4 = combinedDomainXYPlot3.getBackgroundPaint();
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("hi!", font1, paint4, 1.0f, textMeasurer6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.util.Locale locale1 = null;
        try {
            org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator2 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        double double1 = rectangleConstraint0.getHeight();
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.lang.String str0 = org.jfree.chart.urls.StandardXYURLGenerator.DEFAULT_SERIES_PARAMETER;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "series" + "'", str0.equals("series"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        combinedDomainXYPlot1.select(generalPath3, rectangle2D4, renderingSource5);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = null;
        try {
            combinedDomainXYPlot1.setDatasetRenderingOrder(datasetRenderingOrder7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        int int4 = combinedDomainXYPlot3.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot3.rendererChanged(rendererChangeEvent6);
        combinedDomainXYPlot1.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot3);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = combinedDomainXYPlot3.getLegendItems();
        try {
            org.jfree.chart.LegendItem legendItem11 = legendItemCollection9.get((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(legendItemCollection9);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        try {
            org.jfree.chart.axis.TickUnit tickUnit2 = tickUnits0.get(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("hi!", graphics2D1, (float) (byte) 10, (float) (short) -1, (double) (-1L), (float) 12, (float) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        try {
            combinedRangeXYPlot1.handleClick(2, 0, plotRenderingInfo4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setUpperMargin((double) (short) 0);
        try {
            numberAxis3D0.setAutoRangeMinimumSize((double) 0L, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-460) + "'", int1 == (-460));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("series");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name series, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.plot.PlotOrientation plotOrientation2 = null;
        try {
            combinedDomainXYPlot1.setOrientation(plotOrientation2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer2 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean3 = xYAreaRenderer2.isOutline();
        java.awt.Shape shape4 = xYAreaRenderer2.getBaseShape();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic6 = new org.jfree.chart.title.LegendGraphic(shape4, (java.awt.Paint) color5);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = null;
        try {
            org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("0", font1, (java.awt.Paint) color5, rectangleEdge7, horizontalAlignment8, verticalAlignment9, rectangleInsets10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'horizontalAlignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("series", graphics2D1, (float) (-1L), (float) 12, (double) '4', (float) (byte) 0, (float) 1L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createAdjustedRectangle(rectangle2D1, lengthAdjustmentType2, lengthAdjustmentType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(lengthAdjustmentType2);
        org.junit.Assert.assertNotNull(lengthAdjustmentType3);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("", "series", "series", "hi!");
        java.lang.String str5 = basicProjectInfo4.getName();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.awt.Paint paint2 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.lang.Class<?> wildcardClass4 = stroke3.getClass();
        java.awt.Paint paint5 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis8);
        int int10 = combinedDomainXYPlot9.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot9.rendererChanged(rendererChangeEvent12);
        combinedDomainXYPlot7.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot9);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = combinedDomainXYPlot9.getDomainAxisEdge((int) (byte) 1);
        java.awt.Stroke stroke17 = combinedDomainXYPlot9.getRangeGridlineStroke();
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker((double) (-1.0f), (double) 2.0f, paint2, stroke3, paint5, stroke17, (float) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("hi!", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean6 = xYAreaRenderer5.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator7 = null;
        xYAreaRenderer5.setLegendItemToolTipGenerator(xYSeriesLabelGenerator7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis3, valueAxis4, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer5);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator10 = xYAreaRenderer5.getBaseItemLabelGenerator();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D13 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 0.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent16 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker15);
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        try {
            xYAreaRenderer5.drawRangeMarker(graphics2D11, xYPlot12, (org.jfree.chart.axis.ValueAxis) numberAxis3D13, (org.jfree.chart.plot.Marker) valueMarker15, rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(xYItemLabelGenerator10);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.plot.CrosshairState crosshairState1 = new org.jfree.chart.plot.CrosshairState(false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        java.awt.Shape shape2 = xYAreaRenderer0.getBaseShape();
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
        boolean boolean5 = org.jfree.chart.util.ShapeUtilities.equal(shape2, shape4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance(100, 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangePannable(true);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = combinedDomainXYPlot1.getDomainMarkers(layer4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.Point2D point2D8 = null;
        org.jfree.chart.plot.PlotState plotState9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        try {
            combinedDomainXYPlot1.draw(graphics2D6, rectangle2D7, point2D8, plotState9, plotRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection5);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean6 = xYAreaRenderer5.isOutline();
        java.awt.Shape shape7 = xYAreaRenderer5.getBaseShape();
        java.awt.Paint paint9 = null;
        java.awt.Color color11 = java.awt.Color.CYAN;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer12 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean13 = xYAreaRenderer12.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator14 = null;
        xYAreaRenderer12.setLegendItemToolTipGenerator(xYSeriesLabelGenerator14);
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYAreaRenderer12.setSeriesStroke(3, stroke17);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer20 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean21 = xYAreaRenderer20.isOutline();
        java.awt.Shape shape22 = xYAreaRenderer20.getBaseShape();
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        try {
            org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("0", "", "ClassContext", "0", true, shape7, false, paint9, true, (java.awt.Paint) color11, stroke17, false, shape22, stroke23, (java.awt.Paint) color24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color24);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Paint paint1 = org.jfree.chart.util.SerialUtilities.readPaint(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.lang.String str0 = org.jfree.chart.labels.StandardXYSeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint2 = categoryAxis3D1.getLabelPaint();
        categoryAxis3D1.setTickMarkInsideLength((float) 0);
        java.awt.Font font5 = categoryAxis3D1.getLabelFont();
        categoryAxis3D1.setCategoryMargin((double) 1L);
        java.awt.Paint paint8 = categoryAxis3D1.getLabelPaint();
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.util.RectangleEdge.RIGHT;
        try {
            double double13 = categoryAxis3D1.getCategoryStart(10, (int) (short) 0, rectangle2D11, rectangleEdge12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        try {
            boolean boolean3 = xYSeriesCollection0.isSelected((int) '#', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.awt.Paint paint0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        combinedDomainXYPlot1.select(generalPath3, rectangle2D4, renderingSource5);
        java.awt.Paint paint8 = combinedDomainXYPlot1.getQuadrantPaint((int) (short) 0);
        double double9 = combinedDomainXYPlot1.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.net.URL uRL0 = null;
        java.net.URLClassLoader uRLClassLoader1 = null;
        try {
            org.jfree.chart.util.ResourceBundleWrapper.removeCodeBase(uRL0, uRLClassLoader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        java.awt.Paint paint4 = combinedDomainXYPlot3.getBackgroundPaint();
        xYAreaRenderer0.setSeriesPaint(2, paint4);
        java.awt.Shape shape6 = xYAreaRenderer0.getBaseShape();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator8 = null;
        xYAreaRenderer0.setSeriesItemLabelGenerator(1900, xYItemLabelGenerator8);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        combinedDomainXYPlot1.setForegroundAlpha((float) (-1));
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        combinedDomainXYPlot1.setDomainAxisLocation((int) (short) 1, axisLocation6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        try {
            combinedDomainXYPlot1.zoomRangeAxes((double) (short) 0, (double) (short) 0, plotRenderingInfo10, point2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNotNull(axisLocation6);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        combinedDomainXYPlot1.setForegroundAlpha((float) (-1));
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        combinedDomainXYPlot1.setDomainAxisLocation((int) (short) 1, axisLocation6);
        int int8 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries3.clear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = null;
        try {
            timeSeries3.add(timeSeriesDataItem5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        int int0 = org.jfree.data.time.SerialDate.INCLUDE_BOTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 1L, (double) 1L, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        int int0 = org.jfree.chart.renderer.xy.XYStepAreaRenderer.AREA_AND_SHAPES;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter0 = null;
        try {
            org.jfree.chart.renderer.xy.XYBarRenderer.setDefaultBarPainter(xYBarPainter0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'painter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        boolean boolean0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultShadowsVisible();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setUpperMargin((double) (short) 0);
        numberAxis3D0.resizeRange2((double) 10L, (double) 12);
        numberAxis3D0.setAutoTickUnitSelection(false);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean11 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge10);
        try {
            double double12 = numberAxis3D0.lengthToJava2D((double) (short) 10, rectangle2D9, rectangleEdge10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        org.jfree.chart.axis.AxisSpace axisSpace3 = null;
        combinedDomainXYPlot1.setFixedDomainAxisSpace(axisSpace3);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray5 = null;
        try {
            combinedDomainXYPlot1.setDomainAxes(valueAxisArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint2 = categoryAxis3D1.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent6 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D1, jFreeChart3, (int) (short) 1, (int) (short) 10);
        java.lang.Comparable comparable7 = null;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D9 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint10 = categoryAxis3D9.getLabelPaint();
        categoryAxis3D9.setTickMarkInsideLength((float) 0);
        java.awt.Font font13 = categoryAxis3D9.getLabelFont();
        try {
            categoryAxis3D1.setTickLabelFont(comparable7, font13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.awt.Font font0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone0;
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint2 = categoryAxis3D1.getLabelPaint();
        categoryAxis3D1.setTickMarkInsideLength((float) 0);
        java.awt.Font font5 = categoryAxis3D1.getLabelFont();
        categoryAxis3D1.setTickLabelsVisible(true);
        categoryAxis3D1.setTickLabelsVisible(true);
        double double10 = categoryAxis3D1.getCategoryMargin();
        java.lang.String str11 = categoryAxis3D1.getLabelToolTip();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.2d + "'", double10 == 0.2d);
        org.junit.Assert.assertNull(str11);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(0.0d, (double) (-1L));
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedHeight();
        org.junit.Assert.assertNotNull(rectangleConstraint3);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        java.awt.Shape shape2 = xYAreaRenderer0.getBaseShape();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(0.0d, (double) (-1L));
        org.jfree.chart.util.Size2D size2D9 = legendGraphic4.arrange(graphics2D5, rectangleConstraint8);
        size2D9.setHeight((double) 1.0f);
        size2D9.setHeight(0.0d);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(size2D9);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        combinedDomainXYPlot1.setForegroundAlpha((float) (-1));
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        combinedDomainXYPlot1.setDomainAxisLocation((int) (short) 1, axisLocation6);
        org.jfree.chart.plot.Marker marker8 = null;
        try {
            combinedDomainXYPlot1.addRangeMarker(marker8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNotNull(axisLocation6);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIFTEEN_MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 900000L + "'", long0 == 900000L);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        int int4 = combinedDomainXYPlot3.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot3.rendererChanged(rendererChangeEvent6);
        combinedDomainXYPlot1.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot3);
        combinedDomainXYPlot3.setDomainMinorGridlinesVisible(true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D12.setUpperMargin((double) (short) 0);
        numberAxis3D12.resizeRange2((double) 10L, (double) 12);
        combinedDomainXYPlot3.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis3D12, false);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.plot.Plot plot21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.jfree.chart.axis.AxisSpace axisSpace24 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace25 = numberAxis3D12.reserveSpace(graphics2D20, plot21, rectangle2D22, rectangleEdge23, axisSpace24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        xYAreaRenderer0.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition2);
        boolean boolean4 = xYAreaRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        boolean boolean5 = xYAreaRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot1.rendererChanged(rendererChangeEvent4);
        boolean boolean6 = rendererChangeEvent4.getSeriesVisibilityChanged();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        int int2 = org.jfree.data.time.SerialDate.lastDayOfMonth(0, 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator2 = null;
        xYAreaRenderer0.setLegendItemToolTipGenerator(xYSeriesLabelGenerator2);
        java.awt.Paint paint5 = xYAreaRenderer0.getSeriesPaint(2);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator7 = xYAreaRenderer0.getSeriesItemLabelGenerator(10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        xYAreaRenderer0.setSeriesNegativeItemLabelPosition(12, itemLabelPosition9, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNull(xYItemLabelGenerator7);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.String str2 = jFreeChartResources0.getString("java.awt.Color[r=0,g=192,b=192]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key java.awt.Color[r=0,g=192,b=192]");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getIntegerInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        org.jfree.data.xy.XYSeries xYSeries3 = null;
        try {
            xYSeriesCollection0.addSeries(xYSeries3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = null;
        xYAreaRenderer0.setBaseItemLabelGenerator(xYItemLabelGenerator2, true);
        java.awt.Paint paint5 = xYAreaRenderer0.getBaseFillPaint();
        java.io.ObjectOutputStream objectOutputStream6 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint(paint5, objectOutputStream6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("ClassContext");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean2 = range0.contains(0.0d);
        boolean boolean4 = range0.equals((java.lang.Object) 12);
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 1900, (double) 100.0f, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        boolean boolean2 = xYAreaRenderer0.getAutoPopulateSeriesOutlinePaint();
        xYAreaRenderer0.setAutoPopulateSeriesPaint(true);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation5 = null;
        boolean boolean6 = xYAreaRenderer0.removeAnnotation(xYAnnotation5);
        xYAreaRenderer0.setAutoPopulateSeriesOutlinePaint(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        int int0 = org.jfree.data.time.SerialDate.SECOND_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("NO_CHANGE", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) 2.0f, (double) 10L, 12, (java.lang.Comparable) 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("{0}", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        java.awt.Shape shape2 = xYAreaRenderer0.getBaseShape();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        legendGraphic4.setWidth((double) 8);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D11 = legendGraphic4.arrange(graphics2D7, rectangleConstraint10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline14 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long17 = segmentedTimeline14.getExceptionSegmentCount((long) (short) 10, (long) 100);
        try {
            java.lang.Object obj18 = legendGraphic4.draw(graphics2D12, rectangle2D13, (java.lang.Object) segmentedTimeline14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(size2D11);
        org.junit.Assert.assertNotNull(segmentedTimeline14);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 0L + "'", long17 == 0L);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        java.awt.Shape shape2 = xYAreaRenderer0.getBaseShape();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(0.0d, (double) (-1L));
        org.jfree.chart.util.Size2D size2D9 = legendGraphic4.arrange(graphics2D5, rectangleConstraint8);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint12 = categoryAxis3D11.getLabelPaint();
        categoryAxis3D11.setTickMarkInsideLength((float) 0);
        java.awt.Font font15 = categoryAxis3D11.getLabelFont();
        boolean boolean16 = legendGraphic4.equals((java.lang.Object) categoryAxis3D11);
        java.awt.Color color18 = java.awt.Color.ORANGE;
        categoryAxis3D11.setTickLabelPaint((java.lang.Comparable) 1560495599999L, (java.awt.Paint) color18);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot25 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis24);
        int int26 = combinedDomainXYPlot25.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.RenderingSource renderingSource29 = null;
        combinedDomainXYPlot25.select(generalPath27, rectangle2D28, renderingSource29);
        java.awt.Paint paint32 = combinedDomainXYPlot25.getQuadrantPaint((int) (short) 0);
        combinedDomainXYPlot25.setBackgroundAlpha(0.0f);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = combinedDomainXYPlot25.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        try {
            org.jfree.chart.axis.AxisState axisState37 = categoryAxis3D11.draw(graphics2D20, (double) (byte) 10, rectangle2D22, rectangle2D23, rectangleEdge35, plotRenderingInfo36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 15 + "'", int26 == 15);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNotNull(rectangleEdge35);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createInsetRectangle(rectangle2D1, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean2 = xYAreaRenderer1.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator3 = null;
        xYAreaRenderer1.setLegendItemToolTipGenerator(xYSeriesLabelGenerator3);
        boolean boolean5 = xYAreaRenderer1.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator7 = null;
        xYAreaRenderer1.setSeriesToolTipGenerator((int) (short) 100, xYToolTipGenerator7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = xYAreaRenderer1.getNegativeItemLabelPosition(100, (int) (byte) -1, false);
        boolean boolean13 = lengthConstraintType0.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        int int1 = org.jfree.data.time.SerialDate.stringToMonthCode("{0}");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor1 = org.jfree.data.time.TimePeriodAnchor.END;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint4 = categoryAxis3D3.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D3, jFreeChart5, (int) (short) 1, (int) (short) 10);
        boolean boolean9 = timePeriodAnchor1.equals((java.lang.Object) (short) 10);
        timeSeriesCollection0.setXPosition(timePeriodAnchor1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate11 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        try {
            double double14 = intervalXYDelegate11.getStartXValue((int) (byte) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodAnchor1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.lang.String str0 = org.jfree.chart.urls.StandardXYURLGenerator.DEFAULT_ITEM_PARAMETER;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "item" + "'", str0.equals("item"));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.awt.Color color1 = java.awt.Color.getColor("item");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setUpperMargin((double) (short) 0);
        numberAxis3D0.resizeRange2((double) 10L, (double) 12);
        numberAxis3D0.setAutoTickUnitSelection(false);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = org.jfree.chart.util.RectangleEdge.RIGHT;
        try {
            double double11 = numberAxis3D0.java2DToValue((double) 100.0f, rectangle2D9, rectangleEdge10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        try {
            combinedDomainXYPlot1.zoomRangeAxes((double) (short) 10, 1.0d, plotRenderingInfo5, point2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.title.Title title0 = null;
        try {
            org.jfree.chart.event.TitleChangeEvent titleChangeEvent1 = new org.jfree.chart.event.TitleChangeEvent(title0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection1, true);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean7 = xYAreaRenderer6.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator8 = null;
        xYAreaRenderer6.setLegendItemToolTipGenerator(xYSeriesLabelGenerator8);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection1, valueAxis4, valueAxis5, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer6);
        boolean boolean11 = xYAreaRenderer6.isOutline();
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYAreaRenderer6.setSeriesItemLabelFont(100, font13);
        piePlot3D0.setLabelFont(font13);
        double double16 = piePlot3D0.getMaximumExplodePercent();
        piePlot3D0.setLabelLinksVisible(true);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        try {
            piePlot3D0.drawBackground(graphics2D19, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("{0}");
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint2 = categoryAxis3D1.getLabelPaint();
        categoryAxis3D1.setTickMarkInsideLength((float) 0);
        java.awt.Font font5 = categoryAxis3D1.getLabelFont();
        categoryAxis3D1.setTickLabelsVisible(true);
        categoryAxis3D1.setTickLabelsVisible(true);
        categoryAxis3D1.setLabelToolTip("ClassContext");
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator0 = new org.jfree.chart.labels.StandardPieToolTipGenerator();
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        combinedDomainXYPlot1.select(generalPath3, rectangle2D4, renderingSource5);
        java.awt.Paint paint8 = combinedDomainXYPlot1.getQuadrantPaint((int) (short) 0);
        combinedDomainXYPlot1.clearAnnotations();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = combinedDomainXYPlot1.getDrawingSupplier();
        java.awt.geom.GeneralPath generalPath11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.RenderingSource renderingSource13 = null;
        combinedDomainXYPlot1.select(generalPath11, rectangle2D12, renderingSource13);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        combinedDomainXYPlot1.setDomainAxisLocation(axisLocation15, true);
        java.lang.Object obj18 = combinedDomainXYPlot1.clone();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.NONE;
        org.junit.Assert.assertNotNull(domainOrder0);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor1 = org.jfree.data.time.TimePeriodAnchor.END;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint4 = categoryAxis3D3.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D3, jFreeChart5, (int) (short) 1, (int) (short) 10);
        boolean boolean9 = timePeriodAnchor1.equals((java.lang.Object) (short) 10);
        timeSeriesCollection0.setXPosition(timePeriodAnchor1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate11 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        try {
            timeSeriesCollection0.setSelected(0, (int) (byte) 1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodAnchor1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("35", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint2 = categoryAxis3D1.getLabelPaint();
        categoryAxis3D1.setTickMarkInsideLength((float) 0);
        java.awt.Font font5 = categoryAxis3D1.getLabelFont();
        categoryAxis3D1.setTickLabelsVisible(true);
        java.awt.Font font8 = null;
        try {
            categoryAxis3D1.setLabelFont(font8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        java.awt.Shape shape2 = xYAreaRenderer0.getBaseShape();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        legendGraphic4.setWidth((double) 8);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D11 = legendGraphic4.arrange(graphics2D7, rectangleConstraint10);
        org.jfree.chart.plot.PiePlot3D piePlot3D13 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection14 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection14, true);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer19 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean20 = xYAreaRenderer19.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator21 = null;
        xYAreaRenderer19.setLegendItemToolTipGenerator(xYSeriesLabelGenerator21);
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection14, valueAxis17, valueAxis18, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer19);
        boolean boolean24 = xYAreaRenderer19.isOutline();
        java.awt.Font font26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYAreaRenderer19.setSeriesItemLabelFont(100, font26);
        piePlot3D13.setLabelFont(font26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer31 = null;
        org.jfree.chart.text.TextBlock textBlock32 = org.jfree.chart.text.TextUtilities.createTextBlock("", font26, (java.awt.Paint) color29, (float) 100L, textMeasurer31);
        boolean boolean33 = legendGraphic4.equals((java.lang.Object) textMeasurer31);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(size2D11);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(textBlock32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        int int4 = combinedDomainXYPlot3.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot3.rendererChanged(rendererChangeEvent6);
        combinedDomainXYPlot1.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot3);
        org.jfree.chart.axis.AxisLocation axisLocation9 = combinedDomainXYPlot1.getRangeAxisLocation();
        org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 0.0f);
        org.jfree.chart.util.Layer layer13 = null;
        try {
            combinedDomainXYPlot1.addDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker12, layer13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean6 = xYAreaRenderer5.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator7 = null;
        xYAreaRenderer5.setLegendItemToolTipGenerator(xYSeriesLabelGenerator7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis3, valueAxis4, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer5);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        xYPlot9.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) numberAxis3D11);
        try {
            numberAxis3D11.setAutoRangeMinimumSize(0.0d, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.axis.TickUnit tickUnit1 = null;
        try {
            tickUnits0.add(tickUnit1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'unit' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        centerArrangement0.clear();
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = null;
        xYAreaRenderer0.setBaseItemLabelGenerator(xYItemLabelGenerator2, true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.data.Range range8 = combinedDomainXYPlot6.getDataRange(valueAxis7);
        java.lang.Object obj9 = null;
        boolean boolean10 = combinedDomainXYPlot6.equals(obj9);
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        combinedDomainXYPlot6.setRangeGridlineStroke(stroke11);
        xYAreaRenderer0.setBaseOutlineStroke(stroke11);
        xYAreaRenderer0.setSeriesVisible(1900, (java.lang.Boolean) false, true);
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long3 = segmentedTimeline0.getExceptionSegmentCount((long) (short) 10, (long) 100);
        boolean boolean4 = segmentedTimeline0.getAdjustForDaylightSaving();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        java.awt.Stroke stroke1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.lang.Class<?> wildcardClass2 = stroke1.getClass();
        java.io.InputStream inputStream3 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("item", (java.lang.Class) wildcardClass2);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNull(inputStream3);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        int int0 = java.text.NumberFormat.FRACTION_FIELD;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.centerRange((-1.0d));
        java.awt.Paint paint3 = numberAxis3D0.getTickLabelPaint();
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double5 = range4.getLength();
        numberAxis3D0.setRangeWithMargins(range4, false, false);
        org.jfree.data.RangeType rangeType9 = numberAxis3D0.getRangeType();
        java.lang.String str10 = rangeType9.toString();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(rangeType9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "RangeType.FULL" + "'", str10.equals("RangeType.FULL"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = null;
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType2 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        java.text.DateFormat dateFormat4 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit5 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, 100, dateTickUnitType2, (int) (short) -1, dateFormat4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType2);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot3D0.setLabelGenerator(pieSectionLabelGenerator1);
        piePlot3D0.setShadowXOffset(0.0d);
        piePlot3D0.setIgnoreZeroValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot3D0.getSimpleLabelOffset();
        piePlot3D0.setLabelLinksVisible(true);
        org.junit.Assert.assertNotNull(rectangleInsets7);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean6 = xYAreaRenderer5.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator7 = null;
        xYAreaRenderer5.setLegendItemToolTipGenerator(xYSeriesLabelGenerator7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis3, valueAxis4, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer5);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer10 = null;
        try {
            xYAreaRenderer5.setGradientTransformer(gradientPaintTransformer10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'transformer' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        java.awt.Paint paint2 = combinedDomainXYPlot1.getBackgroundPaint();
        combinedDomainXYPlot1.setDomainZeroBaselineVisible(true);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 1, (double) 100.0f);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement10 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment6, verticalAlignment7, (double) (byte) 1, (double) 100.0f);
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement10);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.data.Range range14 = rectangleConstraint13.getWidthRange();
        org.jfree.chart.util.Size2D size2D15 = flowArrangement4.arrange(blockContainer11, graphics2D12, rectangleConstraint13);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection18 = new org.jfree.data.xy.XYSeriesCollection();
        xYSeriesCollection18.removeAllSeries();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent20 = null;
        xYSeriesCollection18.seriesChanged(seriesChangeEvent20);
        try {
            java.lang.Object obj22 = blockContainer11.draw(graphics2D16, rectangle2D17, (java.lang.Object) seriesChangeEvent20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleConstraint13);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(size2D15);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.renderer.RendererUtilities rendererUtilities0 = new org.jfree.chart.renderer.RendererUtilities();
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.NumberTick numberTick9 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (short) 10, "series", textAnchor6, textAnchor7, (double) (short) 10);
        org.jfree.chart.text.TextAnchor textAnchor11 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("series", graphics2D1, (float) 0, (float) (-460), textAnchor7, (double) 10, textAnchor11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries3.clear();
        timeSeries3.setDescription("series");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        try {
            timeSeries3.update((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) 8);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: There is no existing value for the specified 'period'.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        xYAreaRenderer0.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition2);
        xYAreaRenderer0.setBaseItemLabelsVisible(false, false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getInfo();
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.axis.SegmentedTimeline.FIRST_MONDAY_AFTER_1900 = 15;
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setUpperMargin((double) (short) 0);
        numberAxis3D0.resizeRange2((double) 10L, (double) 12);
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = null;
        try {
            numberAxis3D0.setLabelInsets(rectangleInsets6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) '4', 10.0d);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = intervalMarker2.getGradientPaintTransformer();
        org.junit.Assert.assertNull(gradientPaintTransformer3);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateBottomOutset((double) (byte) 10);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        xYSeriesCollection0.removeAllSeries();
        try {
            java.lang.Comparable comparable3 = xYSeriesCollection0.getSeriesKey(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        xYAreaRenderer0.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition2);
        boolean boolean4 = xYAreaRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator5 = null;
        xYAreaRenderer0.setBaseToolTipGenerator(xYToolTipGenerator5);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        combinedDomainXYPlot1.select(generalPath3, rectangle2D4, renderingSource5);
        java.awt.Paint paint8 = combinedDomainXYPlot1.getQuadrantPaint((int) (short) 0);
        combinedDomainXYPlot1.setBackgroundAlpha(0.0f);
        org.jfree.chart.plot.Marker marker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        boolean boolean15 = combinedDomainXYPlot1.removeDomainMarker((-1), marker12, layer13, true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer17 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis19);
        java.awt.Paint paint21 = combinedDomainXYPlot20.getBackgroundPaint();
        xYAreaRenderer17.setSeriesPaint(2, paint21);
        xYAreaRenderer17.setAutoPopulateSeriesPaint(false);
        combinedDomainXYPlot1.setRenderer(0, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer17, true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor27 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.jfree.data.Range range28 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double29 = range28.getLength();
        boolean boolean30 = itemLabelAnchor27.equals((java.lang.Object) double29);
        org.jfree.chart.text.TextAnchor textAnchor31 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor27, textAnchor31);
        xYAreaRenderer17.setBaseNegativeItemLabelPosition(itemLabelPosition32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(itemLabelAnchor27);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(textAnchor31);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        combinedDomainXYPlot1.select(generalPath3, rectangle2D4, renderingSource5);
        java.awt.Paint paint8 = combinedDomainXYPlot1.getQuadrantPaint((int) (short) 0);
        combinedDomainXYPlot1.setBackgroundAlpha(0.0f);
        org.jfree.chart.plot.Marker marker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        boolean boolean15 = combinedDomainXYPlot1.removeDomainMarker((-1), marker12, layer13, true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer17 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis19);
        java.awt.Paint paint21 = combinedDomainXYPlot20.getBackgroundPaint();
        xYAreaRenderer17.setSeriesPaint(2, paint21);
        xYAreaRenderer17.setAutoPopulateSeriesPaint(false);
        combinedDomainXYPlot1.setRenderer(0, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer17, true);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation27 = null;
        try {
            xYAreaRenderer17.addAnnotation(xYAnnotation27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        int int1 = org.jfree.data.time.SerialDate.stringToWeekdayCode("1");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        combinedDomainXYPlot1.select(generalPath3, rectangle2D4, renderingSource5);
        java.awt.Paint paint8 = combinedDomainXYPlot1.getQuadrantPaint((int) (short) 0);
        combinedDomainXYPlot1.setBackgroundAlpha(0.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        try {
            combinedDomainXYPlot1.zoomRangeAxes((double) 'a', plotRenderingInfo12, point2D13, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) 4, 0.0f);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean6 = xYAreaRenderer5.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator7 = null;
        xYAreaRenderer5.setLegendItemToolTipGenerator(xYSeriesLabelGenerator7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis3, valueAxis4, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer5);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        xYPlot9.setDomainAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) numberAxis3D11);
        boolean boolean13 = numberAxis3D11.isTickMarksVisible();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean19 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        try {
            org.jfree.chart.axis.AxisState axisState21 = numberAxis3D11.draw(graphics2D14, 0.05d, rectangle2D16, rectangle2D17, rectangleEdge18, plotRenderingInfo20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        long long1 = segmentedTimeline0.getSegmentsExcludedSize();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 172800000L + "'", long1 == 172800000L);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        int int4 = combinedDomainXYPlot3.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot3.rendererChanged(rendererChangeEvent6);
        combinedDomainXYPlot1.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot3);
        org.jfree.chart.LegendItemCollection legendItemCollection9 = combinedDomainXYPlot3.getLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        try {
            combinedDomainXYPlot3.handleClick(100, (int) (byte) -1, plotRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(legendItemCollection9);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        int int0 = org.jfree.data.time.SerialDate.TUESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean6 = xYAreaRenderer5.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator7 = null;
        xYAreaRenderer5.setLegendItemToolTipGenerator(xYSeriesLabelGenerator7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis3, valueAxis4, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer5);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator10 = xYAreaRenderer5.getBaseItemLabelGenerator();
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) xYItemLabelGenerator10, jFreeChart11, chartChangeEventType12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(xYItemLabelGenerator10);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot3D0.setLabelGenerator(pieSectionLabelGenerator1);
        piePlot3D0.setShadowXOffset(0.0d);
        double double5 = piePlot3D0.getDepthFactor();
        boolean boolean6 = piePlot3D0.getSimpleLabels();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.12d + "'", double5 == 0.12d);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        java.util.List list2 = combinedRangeXYPlot1.getSubplots();
        java.util.List list3 = combinedRangeXYPlot1.getSubplots();
        combinedRangeXYPlot1.configureRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot7 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis6);
        java.util.List list8 = combinedRangeXYPlot7.getSubplots();
        java.util.List list9 = combinedRangeXYPlot7.getSubplots();
        try {
            combinedRangeXYPlot1.mapDatasetToRangeAxes((int) (short) 0, list9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.text.AttributedString attributedString1 = org.jfree.chart.util.SerialUtilities.readAttributedString(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor1 = org.jfree.data.time.TimePeriodAnchor.END;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint4 = categoryAxis3D3.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D3, jFreeChart5, (int) (short) 1, (int) (short) 10);
        boolean boolean9 = timePeriodAnchor1.equals((java.lang.Object) (short) 10);
        timeSeriesCollection0.setXPosition(timePeriodAnchor1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate11 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        try {
            java.lang.Number number14 = timeSeriesCollection0.getStartX(12, 68);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodAnchor1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        int int4 = combinedDomainXYPlot3.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot3.rendererChanged(rendererChangeEvent6);
        combinedDomainXYPlot1.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot3);
        combinedDomainXYPlot3.setDomainMinorGridlinesVisible(true);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis12 = combinedDomainXYPlot3.getRangeAxisForDataset((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 1 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor1 = org.jfree.data.time.TimePeriodAnchor.END;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint4 = categoryAxis3D3.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D3, jFreeChart5, (int) (short) 1, (int) (short) 10);
        boolean boolean9 = timePeriodAnchor1.equals((java.lang.Object) (short) 10);
        timeSeriesCollection0.setXPosition(timePeriodAnchor1);
        try {
            double double13 = timeSeriesCollection0.getStartXValue((int) (short) 10, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodAnchor1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.YEAR;
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.jfree.data.Range range1 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double2 = range1.getLength();
        boolean boolean3 = itemLabelAnchor0.equals((java.lang.Object) double2);
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor4);
        double double6 = itemLabelPosition5.getAngle();
        double double7 = itemLabelPosition5.getAngle();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(range1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment(date2);
        java.util.TimeZone timeZone4 = null;
        java.util.Locale locale5 = null;
        try {
            org.jfree.data.time.Year year6 = new org.jfree.data.time.Year(date2, timeZone4, locale5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(segment3);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        int int4 = combinedDomainXYPlot3.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot3.rendererChanged(rendererChangeEvent6);
        combinedDomainXYPlot1.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot3);
        int int9 = combinedDomainXYPlot3.getDatasetCount();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot12 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis11);
        java.util.List list13 = combinedRangeXYPlot12.getSubplots();
        try {
            combinedDomainXYPlot3.mapDatasetToDomainAxes((int) '#', list13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(list13);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("35");
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot5 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis4);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis6);
        int int8 = combinedDomainXYPlot7.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot7.rendererChanged(rendererChangeEvent10);
        combinedDomainXYPlot5.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot7);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = combinedDomainXYPlot7.getDomainAxisEdge((int) (byte) 1);
        try {
            double double15 = dateAxis1.java2DToValue(0.2d, rectangle2D3, rectangleEdge14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 15 + "'", int8 == 15);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.util.Size2D size2D2 = new org.jfree.chart.util.Size2D((double) (short) 10, (double) (-1L));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.awt.Color color1 = java.awt.Color.getColor("0");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        double[] doubleArray6 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray11 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray12 = new double[][] { doubleArray6, doubleArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray12);
        try {
            org.jfree.data.general.PieDataset pieDataset15 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset13, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint2 = categoryAxis3D1.getLabelPaint();
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            org.jfree.chart.axis.AxisState axisState9 = categoryAxis3D1.draw(graphics2D3, (double) 10L, rectangle2D5, rectangle2D6, rectangleEdge7, plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleEdge7);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        int int1 = segmentedTimeline0.getSegmentsExcluded();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.chart.axis.SegmentedTimeline.Segment segment3 = segmentedTimeline0.getSegment(date2);
        java.util.TimeZone timeZone4 = null;
        try {
            org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date2, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 68 + "'", int1 == 68);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(segment3);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot3 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis2);
        java.util.List list4 = combinedRangeXYPlot3.getSubplots();
        java.lang.String str5 = combinedRangeXYPlot3.getPlotType();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        combinedRangeXYPlot3.setOrientation(plotOrientation6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            xYAreaRenderer0.fillDomainGridBand(graphics2D1, (org.jfree.chart.plot.XYPlot) combinedRangeXYPlot3, valueAxis8, rectangle2D9, (double) 900000L, 1.560495599991E12d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Combined Range XYPlot" + "'", str5.equals("Combined Range XYPlot"));
        org.junit.Assert.assertNotNull(plotOrientation6);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("35");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2, false, false);
        java.util.Date date6 = null;
        java.util.Date date7 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        try {
            dateAxis1.setRange(date6, date7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setUpperMargin((double) (short) 0);
        numberAxis3D0.resizeRange2((double) 10L, (double) 12);
        numberAxis3D0.resizeRange((double) 15);
        numberAxis3D0.setAutoRangeStickyZero(true);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        java.util.List list3 = xYSeriesCollection0.getSeries();
        double double5 = xYSeriesCollection0.getRangeLowerBound(true);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertEquals((double) double5, Double.NaN, 0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (short) 10, "series", textAnchor2, textAnchor3, (double) (short) 10);
        double double6 = numberTick5.getAngle();
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 10.0d + "'", double6 == 10.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        int int4 = combinedDomainXYPlot3.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot3.rendererChanged(rendererChangeEvent6);
        combinedDomainXYPlot1.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot3);
        combinedDomainXYPlot3.setDomainMinorGridlinesVisible(true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D12.setUpperMargin((double) (short) 0);
        numberAxis3D12.resizeRange2((double) 10L, (double) 12);
        combinedDomainXYPlot3.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis3D12, false);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        try {
            combinedDomainXYPlot3.drawBackground(graphics2D20, rectangle2D21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        crosshairState0.setAnchorY((double) (-460));
        crosshairState0.updateCrosshairX(1.560495599991E12d, 15);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor1 = org.jfree.data.time.TimePeriodAnchor.END;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint4 = categoryAxis3D3.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D3, jFreeChart5, (int) (short) 1, (int) (short) 10);
        boolean boolean9 = timePeriodAnchor1.equals((java.lang.Object) (short) 10);
        timeSeriesCollection0.setXPosition(timePeriodAnchor1);
        org.jfree.data.DomainOrder domainOrder11 = timeSeriesCollection0.getDomainOrder();
        org.jfree.data.general.DatasetGroup datasetGroup12 = null;
        try {
            timeSeriesCollection0.setGroup(datasetGroup12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'group' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodAnchor1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(domainOrder11);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        java.awt.Shape shape2 = xYAreaRenderer0.getBaseShape();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        xYAreaRenderer0.setBaseItemLabelPaint((java.awt.Paint) color3, false);
        boolean boolean7 = xYAreaRenderer0.isSeriesVisible(68);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries4.clear();
        timeSeries4.setDescription("series");
        int int8 = timeSeriesCollection0.indexOf(timeSeries4);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection0, (org.jfree.chart.axis.ValueAxis) numberAxis9, polarItemRenderer10);
        try {
            java.lang.Comparable comparable13 = timeSeriesCollection0.getSeriesKey((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (1).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 172800000L, (double) 1560495599999L, (double) (-1L), (double) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0.0f);
        java.lang.Object obj2 = valueMarker1.clone();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        valueMarker1.setLabelOffsetType(lengthAdjustmentType3);
        valueMarker1.setValue((-1.0d));
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(lengthAdjustmentType3);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        java.awt.Shape shape2 = xYAreaRenderer0.getBaseShape();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        legendGraphic4.setWidth((double) 8);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D11 = legendGraphic4.arrange(graphics2D7, rectangleConstraint10);
        double double12 = legendGraphic4.getHeight();
        boolean boolean13 = legendGraphic4.isShapeVisible();
        java.awt.Paint paint14 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        legendGraphic4.setFillPaint(paint14);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(size2D11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, false);
        int int5 = xYSeriesCollection0.getSeriesCount();
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D7.centerRange((-1.0d));
        java.awt.Paint paint10 = numberAxis3D7.getTickLabelPaint();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D11.setUpperMargin((double) (short) 0);
        numberAxis3D11.resizeRange2((double) 10L, (double) 12);
        numberAxis3D11.setAutoTickUnitSelection(false);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer19 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = null;
        xYAreaRenderer19.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition21);
        boolean boolean23 = xYAreaRenderer19.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D24.centerRange((-1.0d));
        java.awt.Paint paint27 = numberAxis3D24.getTickLabelPaint();
        xYAreaRenderer19.setBaseFillPaint(paint27, true);
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) numberAxis3D7, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer19);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = numberAxis3D7.getLabelInsets();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(rectangleInsets31);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator2 = null;
        xYAreaRenderer0.setLegendItemToolTipGenerator(xYSeriesLabelGenerator2);
        xYAreaRenderer0.setUseFillPaint(false);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator9 = xYAreaRenderer0.getItemLabelGenerator((int) (short) 100, (int) 'a', false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(xYItemLabelGenerator9);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("NO_CHANGE");
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        boolean boolean3 = jFreeChartResources0.containsKey("item");
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test254");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getNumberInstance();
        java.math.RoundingMode roundingMode1 = null;
        try {
            numberFormat0.setRoundingMode(roundingMode1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) range0);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(range0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        java.awt.Shape shape2 = xYAreaRenderer0.getBaseShape();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.lang.String str5 = color3.toString();
        java.awt.color.ColorSpace colorSpace6 = null;
        float[] floatArray7 = new float[] {};
        try {
            float[] floatArray8 = color3.getComponents(colorSpace6, floatArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "java.awt.Color[r=255,g=128,b=128]" + "'", str5.equals("java.awt.Color[r=255,g=128,b=128]"));
        org.junit.Assert.assertNotNull(floatArray7);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("ClassContext");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        int int0 = org.jfree.data.time.SerialDate.WEDNESDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.renderer.xy.XYBarPainter xYBarPainter0 = org.jfree.chart.renderer.xy.XYBarRenderer.getDefaultBarPainter();
        org.junit.Assert.assertNotNull(xYBarPainter0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getCurrencyInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.labels.StandardPieToolTipGenerator standardPieToolTipGenerator1 = new org.jfree.chart.labels.StandardPieToolTipGenerator(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.renderer.PaintScale paintScale0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D1.centerRange((-1.0d));
        java.awt.Paint paint4 = numberAxis3D1.getTickLabelPaint();
        float float5 = numberAxis3D1.getTickMarkInsideLength();
        try {
            org.jfree.chart.title.PaintScaleLegend paintScaleLegend6 = new org.jfree.chart.title.PaintScaleLegend(paintScale0, (org.jfree.chart.axis.ValueAxis) numberAxis3D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection1, true);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean7 = xYAreaRenderer6.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator8 = null;
        xYAreaRenderer6.setLegendItemToolTipGenerator(xYSeriesLabelGenerator8);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection1, valueAxis4, valueAxis5, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer6);
        boolean boolean11 = xYAreaRenderer6.isOutline();
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYAreaRenderer6.setSeriesItemLabelFont(100, font13);
        piePlot3D0.setLabelFont(font13);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = piePlot3D0.getSimpleLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D20 = rectangleInsets16.createInsetRectangle(rectangle2D17, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(rectangleInsets16);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent4 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot1.rendererChanged(rendererChangeEvent4);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier6 = null;
        combinedDomainXYPlot1.setDrawingSupplier(drawingSupplier6, false);
        combinedDomainXYPlot1.clearDomainMarkers();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = combinedDomainXYPlot1.getSeriesRenderingOrder();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D11.setUpperMargin((double) (short) 0);
        numberAxis3D11.resizeRange2((double) 10L, (double) 12);
        numberAxis3D11.setAutoTickUnitSelection(false);
        int int19 = combinedDomainXYPlot1.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, false);
        int int5 = xYSeriesCollection0.getSeriesCount();
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D7.centerRange((-1.0d));
        java.awt.Paint paint10 = numberAxis3D7.getTickLabelPaint();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D11 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D11.setUpperMargin((double) (short) 0);
        numberAxis3D11.resizeRange2((double) 10L, (double) 12);
        numberAxis3D11.setAutoTickUnitSelection(false);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer19 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = null;
        xYAreaRenderer19.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition21);
        boolean boolean23 = xYAreaRenderer19.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D24 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D24.centerRange((-1.0d));
        java.awt.Paint paint27 = numberAxis3D24.getTickLabelPaint();
        xYAreaRenderer19.setBaseFillPaint(paint27, true);
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, (org.jfree.chart.axis.ValueAxis) numberAxis3D7, (org.jfree.chart.axis.ValueAxis) numberAxis3D11, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer19);
        try {
            xYSeriesCollection0.setSelected((int) ' ', 10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        combinedDomainXYPlot1.select(generalPath3, rectangle2D4, renderingSource5);
        java.awt.Paint paint8 = combinedDomainXYPlot1.getQuadrantPaint((int) (short) 0);
        combinedDomainXYPlot1.setBackgroundAlpha(0.0f);
        org.jfree.chart.plot.Marker marker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        boolean boolean15 = combinedDomainXYPlot1.removeDomainMarker((-1), marker12, layer13, true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer17 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis19);
        java.awt.Paint paint21 = combinedDomainXYPlot20.getBackgroundPaint();
        xYAreaRenderer17.setSeriesPaint(2, paint21);
        xYAreaRenderer17.setAutoPopulateSeriesPaint(false);
        combinedDomainXYPlot1.setRenderer(0, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer17, true);
        org.jfree.chart.plot.PiePlot3D piePlot3D27 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator28 = null;
        piePlot3D27.setLabelGenerator(pieSectionLabelGenerator28);
        java.awt.Stroke stroke31 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        piePlot3D27.setSectionOutlineStroke((java.lang.Comparable) 1.560495599991E12d, stroke31);
        combinedDomainXYPlot1.setDomainCrosshairStroke(stroke31);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke31);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        try {
            java.lang.Number number3 = timeSeriesCollection0.getStartX((int) (byte) 1, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        java.lang.Number[] numberArray3 = new java.lang.Number[] { (short) 100 };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { (short) 100 };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { (short) 100 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { (short) 100 };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { (short) 100 };
        java.lang.Number[][] numberArray12 = new java.lang.Number[][] { numberArray3, numberArray5, numberArray7, numberArray9, numberArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("series", "RectangleAnchor.CENTER", numberArray12);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, false);
        int int5 = xYSeriesCollection0.getSeriesCount();
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0);
        try {
            int int8 = xYSeriesCollection0.getItemCount(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean6 = xYAreaRenderer5.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator7 = null;
        xYAreaRenderer5.setLegendItemToolTipGenerator(xYSeriesLabelGenerator7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis3, valueAxis4, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer5);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator10 = xYAreaRenderer5.getBaseItemLabelGenerator();
        org.jfree.chart.plot.PiePlot3D piePlot3D13 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection14 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection14, true);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer19 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean20 = xYAreaRenderer19.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator21 = null;
        xYAreaRenderer19.setLegendItemToolTipGenerator(xYSeriesLabelGenerator21);
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection14, valueAxis17, valueAxis18, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer19);
        boolean boolean24 = xYAreaRenderer19.isOutline();
        java.awt.Font font26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYAreaRenderer19.setSeriesItemLabelFont(100, font26);
        piePlot3D13.setLabelFont(font26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.text.TextMeasurer textMeasurer31 = null;
        org.jfree.chart.text.TextBlock textBlock32 = org.jfree.chart.text.TextUtilities.createTextBlock("", font26, (java.awt.Paint) color29, (float) 100L, textMeasurer31);
        try {
            xYAreaRenderer5.setSeriesOutlinePaint((int) (byte) -1, (java.awt.Paint) color29, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(xYItemLabelGenerator10);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(textBlock32);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D1, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries3.clear();
        timeSeries3.setDescription("series");
        try {
            timeSeries3.delete((int) '#', (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries4.clear();
        timeSeries4.setDescription("series");
        int int8 = timeSeriesCollection0.indexOf(timeSeries4);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection0, (org.jfree.chart.axis.ValueAxis) numberAxis9, polarItemRenderer10);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = polarPlot11.getOrientation();
        java.awt.Paint paint13 = polarPlot11.getRadiusGridlinePaint();
        org.jfree.data.xy.XYDataset xYDataset14 = polarPlot11.getDataset();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(xYDataset14);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.jfree.chart.util.UnitType unitType1 = rectangleInsets0.getUnitType();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(unitType1);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        java.awt.Shape shape2 = xYAreaRenderer0.getBaseShape();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(0.0d, (double) (-1L));
        org.jfree.chart.util.Size2D size2D9 = legendGraphic4.arrange(graphics2D5, rectangleConstraint8);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint12 = categoryAxis3D11.getLabelPaint();
        categoryAxis3D11.setTickMarkInsideLength((float) 0);
        java.awt.Font font15 = categoryAxis3D11.getLabelFont();
        boolean boolean16 = legendGraphic4.equals((java.lang.Object) categoryAxis3D11);
        categoryAxis3D11.setLowerMargin((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        combinedDomainXYPlot1.select(generalPath3, rectangle2D4, renderingSource5);
        java.awt.Paint paint8 = combinedDomainXYPlot1.getQuadrantPaint((int) (short) 0);
        combinedDomainXYPlot1.clearAnnotations();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = combinedDomainXYPlot1.getDrawingSupplier();
        java.awt.geom.GeneralPath generalPath11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.RenderingSource renderingSource13 = null;
        combinedDomainXYPlot1.select(generalPath11, rectangle2D12, renderingSource13);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot16 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis15);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot18 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis17);
        int int19 = combinedDomainXYPlot18.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot18.rendererChanged(rendererChangeEvent21);
        combinedDomainXYPlot16.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot18);
        combinedDomainXYPlot18.setDomainMinorGridlinesVisible(true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D27 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D27.setUpperMargin((double) (short) 0);
        numberAxis3D27.resizeRange2((double) 10L, (double) 12);
        combinedDomainXYPlot18.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis3D27, false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D35 = new org.jfree.chart.axis.NumberAxis3D();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D36 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D36.centerRange((-1.0d));
        java.awt.Paint paint39 = numberAxis3D36.getTickLabelPaint();
        org.jfree.data.Range range40 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double41 = range40.getLength();
        numberAxis3D36.setRangeWithMargins(range40, false, false);
        org.jfree.data.RangeType rangeType45 = numberAxis3D36.getRangeType();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D46 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D46.centerRange((-1.0d));
        org.jfree.chart.axis.NumberAxis3D numberAxis3D49 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D49.setUpperMargin((double) (short) 0);
        numberAxis3D49.resizeRange2((double) 10L, (double) 12);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D55 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D55.setUpperMargin((double) (short) 0);
        numberAxis3D55.resizeRange2((double) 10L, (double) 12);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand61 = numberAxis3D55.getMarkerBand();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray62 = new org.jfree.chart.axis.ValueAxis[] { numberAxis3D27, numberAxis3D35, numberAxis3D36, numberAxis3D46, numberAxis3D49, numberAxis3D55 };
        combinedDomainXYPlot1.setDomainAxes(valueAxisArray62);
        java.awt.Color color64 = java.awt.Color.lightGray;
        combinedDomainXYPlot1.setDomainZeroBaselinePaint((java.awt.Paint) color64);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertNotNull(rangeType45);
        org.junit.Assert.assertNull(markerAxisBand61);
        org.junit.Assert.assertNotNull(valueAxisArray62);
        org.junit.Assert.assertNotNull(color64);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.awt.Font font1 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer2 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot5 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis4);
        java.awt.Paint paint6 = combinedDomainXYPlot5.getBackgroundPaint();
        xYAreaRenderer2.setSeriesPaint(2, paint6);
        try {
            org.jfree.chart.text.TextFragment textFragment9 = new org.jfree.chart.text.TextFragment("[8.0, 100.0]", font1, paint6, 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        int int4 = combinedDomainXYPlot3.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot3.rendererChanged(rendererChangeEvent6);
        combinedDomainXYPlot1.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot3);
        combinedDomainXYPlot3.setDomainMinorGridlinesVisible(true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D12.setUpperMargin((double) (short) 0);
        numberAxis3D12.resizeRange2((double) 10L, (double) 12);
        combinedDomainXYPlot3.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis3D12, false);
        combinedDomainXYPlot3.clearAnnotations();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint2 = categoryAxis3D1.getLabelPaint();
        categoryAxis3D1.setTickMarkInsideLength((float) 0);
        java.awt.Font font5 = categoryAxis3D1.getLabelFont();
        categoryAxis3D1.setUpperMargin((double) (short) 100);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean6 = xYAreaRenderer5.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator7 = null;
        xYAreaRenderer5.setLegendItemToolTipGenerator(xYSeriesLabelGenerator7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis3, valueAxis4, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer5);
        java.awt.Shape shape11 = null;
        xYAreaRenderer5.setLegendShape(2, shape11);
        xYAreaRenderer5.setBaseCreateEntities(true);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor1 = org.jfree.data.time.TimePeriodAnchor.END;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint4 = categoryAxis3D3.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D3, jFreeChart5, (int) (short) 1, (int) (short) 10);
        boolean boolean9 = timePeriodAnchor1.equals((java.lang.Object) (short) 10);
        timeSeriesCollection0.setXPosition(timePeriodAnchor1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate11 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        boolean boolean12 = intervalXYDelegate11.isAutoWidth();
        intervalXYDelegate11.setIntervalPositionFactor((double) 1L);
        org.junit.Assert.assertNotNull(timePeriodAnchor1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        int int0 = org.jfree.chart.renderer.xy.XYStepAreaRenderer.AREA;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        java.awt.Paint paint4 = combinedDomainXYPlot3.getBackgroundPaint();
        xYAreaRenderer0.setSeriesPaint(2, paint4);
        java.awt.Shape shape6 = xYAreaRenderer0.getBaseShape();
        boolean boolean7 = xYAreaRenderer0.getAutoPopulateSeriesShape();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = null;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.NumberTick numberTick6 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (short) 10, "series", textAnchor3, textAnchor4, (double) (short) 10);
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'itemLabelAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint2 = categoryAxis3D1.getLabelPaint();
        categoryAxis3D1.setTickMarkInsideLength((float) 0);
        java.awt.Font font5 = categoryAxis3D1.getLabelFont();
        categoryAxis3D1.setCategoryMargin((double) 1L);
        java.awt.Paint paint8 = categoryAxis3D1.getLabelPaint();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer9 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYAreaRenderer9.setBaseOutlineStroke(stroke10);
        categoryAxis3D1.setAxisLineStroke(stroke10);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions13 = null;
        try {
            categoryAxis3D1.setCategoryLabelPositions(categoryLabelPositions13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
        double[] doubleArray10 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray15 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray16 = new double[][] { doubleArray10, doubleArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray16);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity20 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "", "item", categoryDataset17, (java.lang.Comparable) "item", (java.lang.Comparable) "0");
        org.jfree.chart.title.Title title21 = null;
        try {
            org.jfree.chart.entity.TitleEntity titleEntity22 = new org.jfree.chart.entity.TitleEntity(shape1, title21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'title' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.junit.Assert.assertNull(timeZone0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = combinedDomainXYPlot1.getDataRange(valueAxis2);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        try {
            combinedDomainXYPlot1.handleClick((int) (byte) 100, 0, plotRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, false);
        int int5 = xYSeriesCollection0.getSeriesCount();
        org.jfree.data.Range range7 = xYSeriesCollection0.getDomainBounds(true);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, false);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNull(range9);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getNumberInstance();
        java.lang.String str3 = numberFormat1.format(0.0d);
        java.text.NumberFormat numberFormat4 = java.text.NumberFormat.getNumberInstance();
        java.lang.String str6 = numberFormat4.format((long) 1);
        org.jfree.chart.labels.StandardPieSectionLabelGenerator standardPieSectionLabelGenerator7 = new org.jfree.chart.labels.StandardPieSectionLabelGenerator("Combined Range XYPlot", numberFormat1, numberFormat4);
        org.jfree.data.general.PieDataset pieDataset8 = null;
        java.lang.String str10 = standardPieSectionLabelGenerator7.generateSectionLabel(pieDataset8, (java.lang.Comparable) 900000L);
        org.jfree.chart.plot.PiePlot3D piePlot3D11 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator12 = null;
        piePlot3D11.setLabelGenerator(pieSectionLabelGenerator12);
        piePlot3D11.setShadowXOffset(0.0d);
        piePlot3D11.setIgnoreZeroValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = piePlot3D11.getSimpleLabelOffset();
        boolean boolean19 = standardPieSectionLabelGenerator7.equals((java.lang.Object) piePlot3D11);
        java.text.AttributedString attributedString21 = null;
        standardPieSectionLabelGenerator7.setAttributedLabel((int) (short) 10, attributedString21);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "0" + "'", str3.equals("0"));
        org.junit.Assert.assertNotNull(numberFormat4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1" + "'", str6.equals("1"));
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = null;
        piePlot3D1.setLabelGenerator(pieSectionLabelGenerator2);
        piePlot3D1.setShadowXOffset(0.0d);
        piePlot3D1.setCircular(true);
        java.awt.Font font8 = piePlot3D1.getLabelFont();
        org.jfree.chart.plot.Plot plot9 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("RangeType.FULL", font8, plot9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (short) 0, 0.0f);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        try {
            org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity5 = new org.jfree.chart.entity.JFreeChartEntity(shape2, jFreeChart3, "NO_CHANGE");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'chart' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        int int4 = combinedDomainXYPlot3.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot3.rendererChanged(rendererChangeEvent6);
        combinedDomainXYPlot1.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        combinedDomainXYPlot1.panRangeAxes((double) 1560495599999L, plotRenderingInfo10, point2D11);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.xy.XYSeries xYSeries3 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) month0, false);
        try {
            xYSeries3.delete((-460), 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: fromIndex = -460");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        java.awt.Paint paint2 = combinedDomainXYPlot1.getBackgroundPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        try {
            combinedDomainXYPlot1.zoomRangeAxes((double) 9223372036854775807L, (double) '4', plotRenderingInfo5, point2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = month0.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.next();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor1 = org.jfree.data.time.TimePeriodAnchor.END;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint4 = categoryAxis3D3.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D3, jFreeChart5, (int) (short) 1, (int) (short) 10);
        boolean boolean9 = timePeriodAnchor1.equals((java.lang.Object) (short) 10);
        timeSeriesCollection0.setXPosition(timePeriodAnchor1);
        org.jfree.data.DomainOrder domainOrder11 = timeSeriesCollection0.getDomainOrder();
        try {
            java.lang.Comparable comparable13 = timeSeriesCollection0.getSeriesKey(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (1).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodAnchor1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(domainOrder11);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.renderer.xy.GradientXYBarPainter gradientXYBarPainter0 = new org.jfree.chart.renderer.xy.GradientXYBarPainter();
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint2 = categoryAxis3D1.getLabelPaint();
        categoryAxis3D1.setTickMarkInsideLength((float) 0);
        java.awt.Font font5 = categoryAxis3D1.getLabelFont();
        categoryAxis3D1.setVisible(false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator2 = null;
        xYAreaRenderer0.setLegendItemToolTipGenerator(xYSeriesLabelGenerator2);
        java.awt.Paint paint5 = xYAreaRenderer0.getSeriesPaint(2);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator7 = xYAreaRenderer0.getSeriesItemLabelGenerator(10);
        xYAreaRenderer0.setBaseCreateEntities(true, false);
        xYAreaRenderer0.setDataBoundsIncludesVisibleSeriesOnly(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNull(xYItemLabelGenerator7);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        try {
            java.lang.Object obj3 = jFreeChartResources0.getObject("ClassContext");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ClassContext");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertNull(locale1);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("35");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2, false, false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource6 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        dateAxis1.setStandardTickUnits(tickUnitSource6);
        org.junit.Assert.assertNotNull(tickUnitSource6);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        combinedDomainXYPlot1.select(generalPath3, rectangle2D4, renderingSource5);
        java.awt.Paint paint8 = combinedDomainXYPlot1.getQuadrantPaint((int) (short) 0);
        combinedDomainXYPlot1.setBackgroundAlpha(0.0f);
        org.jfree.chart.plot.Marker marker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        boolean boolean15 = combinedDomainXYPlot1.removeDomainMarker((-1), marker12, layer13, true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer17 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis19);
        java.awt.Paint paint21 = combinedDomainXYPlot20.getBackgroundPaint();
        xYAreaRenderer17.setSeriesPaint(2, paint21);
        xYAreaRenderer17.setAutoPopulateSeriesPaint(false);
        combinedDomainXYPlot1.setRenderer(0, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer17, true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        try {
            combinedDomainXYPlot1.zoomRangeAxes((double) 900000L, 0.0d, plotRenderingInfo29, point2D30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (-1), (float) (-460));
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = null;
        piePlot3D3.setLabelGenerator(pieSectionLabelGenerator4);
        piePlot3D3.setShadowXOffset(0.0d);
        piePlot3D3.setIgnoreZeroValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = piePlot3D3.getSimpleLabelOffset();
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) piePlot3D3, "RangeType.FULL", "35");
        org.jfree.chart.JFreeChart jFreeChart14 = null;
        try {
            org.jfree.chart.entity.JFreeChartEntity jFreeChartEntity16 = new org.jfree.chart.entity.JFreeChartEntity(shape2, jFreeChart14, "0");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'chart' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator2 = null;
        xYAreaRenderer0.setLegendItemToolTipGenerator(xYSeriesLabelGenerator2);
        boolean boolean4 = xYAreaRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation5 = null;
        try {
            xYAreaRenderer0.addAnnotation(xYAnnotation5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        combinedDomainXYPlot1.setForegroundAlpha((float) (-1));
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        combinedDomainXYPlot1.setDomainAxisLocation((int) (short) 1, axisLocation6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.data.Range range11 = combinedDomainXYPlot9.getDataRange(valueAxis10);
        java.lang.Object obj12 = null;
        boolean boolean13 = combinedDomainXYPlot9.equals(obj12);
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        combinedDomainXYPlot9.setRangeGridlineStroke(stroke14);
        combinedDomainXYPlot1.setDomainCrosshairStroke(stroke14);
        org.jfree.chart.axis.AxisSpace axisSpace17 = combinedDomainXYPlot1.getFixedDomainAxisSpace();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(axisSpace17);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.HOUR_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 3600000L + "'", long0 == 3600000L);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        java.lang.String str1 = projectInfo0.getName();
        org.jfree.chart.ui.Library library2 = null;
        try {
            projectInfo0.addOptionalLibrary(library2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Library must be given.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name , locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        xYAreaRenderer0.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition2);
        boolean boolean4 = xYAreaRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot6 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis5);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.data.Range range8 = combinedDomainXYPlot6.getDataRange(valueAxis7);
        java.lang.Object obj9 = null;
        boolean boolean10 = combinedDomainXYPlot6.equals(obj9);
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        combinedDomainXYPlot6.setRangeGridlineStroke(stroke11);
        xYAreaRenderer0.setBaseOutlineStroke(stroke11);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(range8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.data.Range range3 = combinedDomainXYPlot1.getDataRange(valueAxis2);
        java.lang.Object obj4 = null;
        boolean boolean5 = combinedDomainXYPlot1.equals(obj4);
        combinedDomainXYPlot1.setDomainCrosshairVisible(false);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            combinedDomainXYPlot1.drawBackground(graphics2D8, rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        int int4 = combinedDomainXYPlot3.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot3.rendererChanged(rendererChangeEvent6);
        combinedDomainXYPlot1.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot3);
        org.jfree.chart.axis.AxisLocation axisLocation9 = combinedDomainXYPlot1.getRangeAxisLocation();
        java.awt.Paint paint10 = combinedDomainXYPlot1.getDomainMinorGridlinePaint();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        combinedDomainXYPlot1.select(generalPath3, rectangle2D4, renderingSource5);
        java.awt.Paint paint8 = combinedDomainXYPlot1.getQuadrantPaint((int) (short) 0);
        combinedDomainXYPlot1.setBackgroundAlpha(0.0f);
        org.jfree.chart.plot.Marker marker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        boolean boolean15 = combinedDomainXYPlot1.removeDomainMarker((-1), marker12, layer13, true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer17 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis19);
        java.awt.Paint paint21 = combinedDomainXYPlot20.getBackgroundPaint();
        xYAreaRenderer17.setSeriesPaint(2, paint21);
        xYAreaRenderer17.setAutoPopulateSeriesPaint(false);
        combinedDomainXYPlot1.setRenderer(0, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer17, true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator28 = xYAreaRenderer17.getSeriesItemLabelGenerator((int) (short) 10);
        java.awt.Stroke stroke30 = null;
        xYAreaRenderer17.setSeriesStroke(15, stroke30);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer32 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean33 = xYAreaRenderer32.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator34 = null;
        xYAreaRenderer32.setLegendItemToolTipGenerator(xYSeriesLabelGenerator34);
        boolean boolean36 = xYAreaRenderer32.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator38 = null;
        xYAreaRenderer32.setSeriesToolTipGenerator((int) (short) 100, xYToolTipGenerator38);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition43 = xYAreaRenderer32.getNegativeItemLabelPosition(100, (int) (byte) -1, false);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor44 = itemLabelPosition43.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor45 = itemLabelPosition43.getTextAnchor();
        xYAreaRenderer17.setBaseNegativeItemLabelPosition(itemLabelPosition43);
        boolean boolean47 = xYAreaRenderer17.getDataBoundsIncludesVisibleSeriesOnly();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(xYItemLabelGenerator28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition43);
        org.junit.Assert.assertNotNull(itemLabelAnchor44);
        org.junit.Assert.assertNotNull(textAnchor45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor1 = org.jfree.data.time.TimePeriodAnchor.END;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint4 = categoryAxis3D3.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D3, jFreeChart5, (int) (short) 1, (int) (short) 10);
        boolean boolean9 = timePeriodAnchor1.equals((java.lang.Object) (short) 10);
        timeSeriesCollection0.setXPosition(timePeriodAnchor1);
        org.jfree.data.DomainOrder domainOrder11 = timeSeriesCollection0.getDomainOrder();
        try {
            timeSeriesCollection0.setSelected((int) (byte) 100, 0, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (100).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodAnchor1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(domainOrder11);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator2 = null;
        xYAreaRenderer0.setLegendItemToolTipGenerator(xYSeriesLabelGenerator2);
        boolean boolean4 = xYAreaRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = null;
        xYAreaRenderer0.setSeriesToolTipGenerator((int) (short) 100, xYToolTipGenerator6);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = xYAreaRenderer0.getBaseToolTipGenerator();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = xYAreaRenderer0.getSeriesNegativeItemLabelPosition((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(xYToolTipGenerator8);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        crosshairState0.setCrosshairX((double) (byte) 1);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        combinedDomainXYPlot1.select(generalPath3, rectangle2D4, renderingSource5);
        java.awt.Paint paint8 = combinedDomainXYPlot1.getQuadrantPaint((int) (short) 0);
        combinedDomainXYPlot1.setBackgroundAlpha(0.0f);
        org.jfree.chart.plot.Marker marker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        boolean boolean15 = combinedDomainXYPlot1.removeDomainMarker((-1), marker12, layer13, true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer17 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis19);
        java.awt.Paint paint21 = combinedDomainXYPlot20.getBackgroundPaint();
        xYAreaRenderer17.setSeriesPaint(2, paint21);
        xYAreaRenderer17.setAutoPopulateSeriesPaint(false);
        combinedDomainXYPlot1.setRenderer(0, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer17, true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator28 = xYAreaRenderer17.getSeriesItemLabelGenerator((int) (short) 10);
        java.awt.Stroke stroke30 = xYAreaRenderer17.getSeriesOutlineStroke(68);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(xYItemLabelGenerator28);
        org.junit.Assert.assertNull(stroke30);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        combinedDomainXYPlot1.setForegroundAlpha((float) (-1));
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        combinedDomainXYPlot1.setDomainAxisLocation((int) (short) 1, axisLocation6);
        combinedDomainXYPlot1.setWeight(1);
        java.awt.Color color10 = java.awt.Color.darkGray;
        combinedDomainXYPlot1.setDomainCrosshairPaint((java.awt.Paint) color10);
        org.jfree.chart.plot.Marker marker13 = null;
        org.jfree.chart.util.Layer layer14 = null;
        try {
            combinedDomainXYPlot1.addRangeMarker(1, marker13, layer14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getNumberInstance();
        java.lang.String str2 = numberFormat0.format(0.0d);
        boolean boolean3 = numberFormat0.isParseIntegerOnly();
        java.util.Currency currency4 = null;
        try {
            numberFormat0.setCurrency(currency4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a', xYToolTipGenerator1, xYURLGenerator2);
        try {
            xYAreaRenderer3.setSeriesItemLabelsVisible((int) (byte) -1, (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, false);
        int int5 = xYSeriesCollection0.getSeriesCount();
        try {
            xYSeriesCollection0.setSelected(10, 0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries4.clear();
        timeSeries4.setDescription("series");
        int int8 = timeSeriesCollection0.indexOf(timeSeries4);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection0, (org.jfree.chart.axis.ValueAxis) numberAxis9, polarItemRenderer10);
        polarPlot11.removeCornerTextItem("");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.centerRange((-1.0d));
        java.awt.Paint paint3 = numberAxis3D0.getTickLabelPaint();
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double5 = range4.getLength();
        numberAxis3D0.setRangeWithMargins(range4, false, false);
        org.jfree.data.RangeType rangeType9 = numberAxis3D0.getRangeType();
        numberAxis3D0.setAxisLineVisible(true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(rangeType9);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double1 = range0.getLength();
        double double2 = range0.getUpperBound();
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
        long long3 = segmentedTimeline0.getExceptionSegmentCount((long) (short) 10, (long) 100);
        long long4 = segmentedTimeline0.getSegmentsGroupSize();
        long long5 = segmentedTimeline0.getSegmentsGroupSize();
        int int6 = segmentedTimeline0.getSegmentsIncluded();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 86400000L + "'", long4 == 86400000L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 86400000L + "'", long5 == 86400000L);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 28 + "'", int6 == 28);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        combinedDomainXYPlot1.setRangePannable(true);
        org.jfree.chart.util.Layer layer4 = null;
        java.util.Collection collection5 = combinedDomainXYPlot1.getDomainMarkers(layer4);
        org.jfree.chart.plot.XYPlot xYPlot6 = null;
        try {
            combinedDomainXYPlot1.remove(xYPlot6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message:  Null 'subplot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection5);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 0L, (double) (byte) -1, (double) (-1.0f), 4.0d);
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 3.0d, 86400000L };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 3.0d, 86400000L };
        java.lang.Number[] numberArray10 = new java.lang.Number[] { 3.0d, 86400000L };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 3.0d, 86400000L };
        java.lang.Number[][] numberArray14 = new java.lang.Number[][] { numberArray4, numberArray7, numberArray10, numberArray13 };
        org.jfree.data.category.CategoryDataset categoryDataset15 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("hi!", "RectangleAnchor.CENTER", numberArray14);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray14);
        org.junit.Assert.assertNotNull(categoryDataset15);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator2 = null;
        xYAreaRenderer0.setLegendItemToolTipGenerator(xYSeriesLabelGenerator2);
        boolean boolean4 = xYAreaRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = null;
        xYAreaRenderer0.setSeriesToolTipGenerator((int) (short) 100, xYToolTipGenerator6);
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator8 = xYAreaRenderer0.getBaseToolTipGenerator();
        boolean boolean9 = xYAreaRenderer0.getBaseCreateEntities();
        java.awt.Shape shape11 = xYAreaRenderer0.lookupLegendShape(100);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(xYToolTipGenerator8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor1 = org.jfree.data.time.TimePeriodAnchor.END;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint4 = categoryAxis3D3.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D3, jFreeChart5, (int) (short) 1, (int) (short) 10);
        boolean boolean9 = timePeriodAnchor1.equals((java.lang.Object) (short) 10);
        timeSeriesCollection0.setXPosition(timePeriodAnchor1);
        org.jfree.data.DomainOrder domainOrder11 = timeSeriesCollection0.getDomainOrder();
        try {
            java.lang.Number number14 = timeSeriesCollection0.getEndY(4, 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(timePeriodAnchor1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(domainOrder11);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Point2D point2D4 = null;
        org.jfree.chart.plot.PlotState plotState5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        try {
            combinedDomainXYPlot1.draw(graphics2D2, rectangle2D3, point2D4, plotState5, plotRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker1);
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        markerChangeEvent2.setChart(jFreeChart3);
        org.jfree.chart.JFreeChart jFreeChart5 = markerChangeEvent2.getChart();
        org.junit.Assert.assertNull(jFreeChart5);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("ClassContext", font2);
        java.awt.Paint paint4 = org.jfree.chart.axis.SymbolAxis.DEFAULT_GRID_BAND_PAINT;
        org.jfree.chart.text.TextFragment textFragment6 = new org.jfree.chart.text.TextFragment("java.awt.Color[r=255,g=128,b=128]", font2, paint4, (float) 43629L);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.NumberTick numberTick15 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (short) 10, "series", textAnchor12, textAnchor13, (double) (short) 10);
        org.jfree.chart.text.TextAnchor textAnchor16 = numberTick15.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.jfree.chart.axis.NumberTick numberTick19 = new org.jfree.chart.axis.NumberTick((java.lang.Number) 0.2d, "NO_CHANGE", textAnchor16, textAnchor17, (double) '4');
        try {
            float float20 = textFragment6.calculateBaselineOffset(graphics2D7, textAnchor17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(textAnchor12);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertNotNull(textAnchor17);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        int int4 = combinedDomainXYPlot3.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot3.rendererChanged(rendererChangeEvent6);
        combinedDomainXYPlot1.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot3);
        combinedDomainXYPlot3.setDomainMinorGridlinesVisible(true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D12.setUpperMargin((double) (short) 0);
        numberAxis3D12.resizeRange2((double) 10L, (double) 12);
        combinedDomainXYPlot3.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis3D12, false);
        boolean boolean20 = combinedDomainXYPlot3.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.lang.Boolean boolean2 = xYLineAndShapeRenderer0.getSeriesShapesVisible(2147483647);
        org.junit.Assert.assertNull(boolean2);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis1);
        combinedDomainXYPlot2.setRangePannable(true);
        double double5 = combinedDomainXYPlot2.getGap();
        java.lang.Object obj6 = combinedDomainXYPlot2.clone();
        boolean boolean7 = textBlockAnchor0.equals((java.lang.Object) combinedDomainXYPlot2);
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 5.0d + "'", double5 == 5.0d);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        double[] doubleArray6 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray11 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray12 = new double[][] { doubleArray6, doubleArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        org.jfree.data.category.CategoryDataset categoryDataset15 = multiplePiePlot14.getDataset();
        boolean boolean16 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset15);
        boolean boolean17 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset15);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("35");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis1.setTickUnit(dateTickUnit2, false, false);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.axis.AxisState axisState7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        try {
            java.util.List list10 = dateAxis1.refreshTicks(graphics2D6, axisState7, rectangle2D8, rectangleEdge9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        double[] doubleArray6 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray11 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray12 = new double[][] { doubleArray6, doubleArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset13);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(range15);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        combinedDomainXYPlot1.setForegroundAlpha((float) (-1));
        java.awt.Stroke stroke5 = combinedDomainXYPlot1.getDomainMinorGridlineStroke();
        combinedDomainXYPlot1.setDomainMinorGridlinesVisible(false);
        combinedDomainXYPlot1.setNoDataMessage("");
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        double[] doubleArray6 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray11 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray12 = new double[][] { doubleArray6, doubleArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        org.jfree.data.category.CategoryDataset categoryDataset15 = multiplePiePlot14.getDataset();
        boolean boolean16 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(categoryDataset15);
        try {
            org.jfree.data.general.PieDataset pieDataset18 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn(categoryDataset15, (java.lang.Comparable) 0.2d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint2 = xYAreaRenderer1.getBaseLegendTextPaint();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator3 = null;
        xYAreaRenderer1.setBaseItemLabelGenerator(xYItemLabelGenerator3, true);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.data.Range range9 = combinedDomainXYPlot7.getDataRange(valueAxis8);
        java.lang.Object obj10 = null;
        boolean boolean11 = combinedDomainXYPlot7.equals(obj10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        combinedDomainXYPlot7.setRangeGridlineStroke(stroke12);
        xYAreaRenderer1.setBaseOutlineStroke(stroke12);
        java.awt.Font font18 = xYAreaRenderer1.getItemLabelFont((int) (short) 100, 12, false);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.block.LabelBlock labelBlock20 = new org.jfree.chart.block.LabelBlock("35", font18, (java.awt.Paint) color19);
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection21 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries25.clear();
        timeSeries25.setDescription("series");
        int int29 = timeSeriesCollection21.indexOf(timeSeries25);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer31 = null;
        org.jfree.chart.plot.PolarPlot polarPlot32 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection21, (org.jfree.chart.axis.ValueAxis) numberAxis30, polarItemRenderer31);
        org.jfree.chart.plot.PlotOrientation plotOrientation33 = polarPlot32.getOrientation();
        java.awt.Paint paint34 = polarPlot32.getRadiusGridlinePaint();
        labelBlock20.setPaint(paint34);
        labelBlock20.setURLText("RangeType.FULL");
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation33);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("35", graphics2D1, (float) (short) 0, (float) 1, (double) (short) -1, 0.0f, (float) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.renderer.category.BarPainter barPainter3 = null;
        try {
            barRenderer3D2.setBarPainter(barPainter3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'painter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot3D0.setLabelGenerator(pieSectionLabelGenerator1);
        piePlot3D0.setShadowXOffset(0.0d);
        piePlot3D0.setIgnoreZeroValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = piePlot3D0.getSimpleLabelOffset();
        boolean boolean8 = piePlot3D0.getIgnoreZeroValues();
        java.lang.Object obj9 = piePlot3D0.clone();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double12 = rectangleInsets10.calculateBottomInset((double) '4');
        piePlot3D0.setLabelPadding(rectangleInsets10);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.0d + "'", double12 == 3.0d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot0.setRangeAxisLocation(15, axisLocation2);
        org.junit.Assert.assertNotNull(axisLocation2);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.centerRange((-1.0d));
        org.jfree.data.Range range3 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        boolean boolean5 = range3.contains(0.0d);
        org.jfree.data.Range range8 = org.jfree.data.Range.expand(range3, (double) ' ', (double) 2.0f);
        org.jfree.data.Range range10 = org.jfree.data.Range.shift(range3, (double) (short) 0);
        numberAxis3D0.setRange(range10, true, true);
        org.jfree.data.Range range16 = org.jfree.data.Range.shift(range10, (double) (short) 1, true);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(range16);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        xYAreaRenderer0.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition2);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean6 = xYAreaRenderer5.isOutline();
        java.awt.Shape shape7 = xYAreaRenderer5.getBaseShape();
        xYAreaRenderer0.setSeriesShape(15, shape7);
        xYAreaRenderer0.setBaseItemLabelsVisible(true, true);
        java.awt.Paint paint15 = xYAreaRenderer0.getItemOutlinePaint((int) (short) 0, (int) ' ', false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        java.awt.Font font1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        int int4 = combinedDomainXYPlot3.getBackgroundImageAlignment();
        combinedDomainXYPlot3.setForegroundAlpha((float) (-1));
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis7);
        int int9 = combinedDomainXYPlot8.getBackgroundImageAlignment();
        combinedDomainXYPlot8.setForegroundAlpha((float) (-1));
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        combinedDomainXYPlot8.setDomainAxisLocation((int) (short) 1, axisLocation13);
        combinedDomainXYPlot3.setDomainAxisLocation(axisLocation13);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer16 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot19 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis18);
        java.awt.Paint paint20 = combinedDomainXYPlot19.getBackgroundPaint();
        xYAreaRenderer16.setSeriesPaint(2, paint20);
        combinedDomainXYPlot3.setRangeGridlinePaint(paint20);
        try {
            org.jfree.chart.block.LabelBlock labelBlock23 = new org.jfree.chart.block.LabelBlock("0", font1, paint20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = null;
        try {
            barRenderer3D2.setSeriesItemLabelGenerator(2147483647, categoryItemLabelGenerator4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        combinedDomainXYPlot1.select(generalPath3, rectangle2D4, renderingSource5);
        java.awt.Paint paint8 = combinedDomainXYPlot1.getQuadrantPaint((int) (short) 0);
        combinedDomainXYPlot1.clearAnnotations();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = combinedDomainXYPlot1.getDrawingSupplier();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot12 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis11);
        int int13 = combinedDomainXYPlot12.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.RenderingSource renderingSource16 = null;
        combinedDomainXYPlot12.select(generalPath14, rectangle2D15, renderingSource16);
        java.awt.Paint paint19 = combinedDomainXYPlot12.getQuadrantPaint((int) (short) 0);
        combinedDomainXYPlot12.setBackgroundAlpha(0.0f);
        org.jfree.chart.plot.Marker marker23 = null;
        org.jfree.chart.util.Layer layer24 = null;
        boolean boolean26 = combinedDomainXYPlot12.removeDomainMarker((-1), marker23, layer24, true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer28 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot31 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis30);
        java.awt.Paint paint32 = combinedDomainXYPlot31.getBackgroundPaint();
        xYAreaRenderer28.setSeriesPaint(2, paint32);
        xYAreaRenderer28.setAutoPopulateSeriesPaint(false);
        combinedDomainXYPlot12.setRenderer(0, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer28, true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator39 = xYAreaRenderer28.getSeriesItemLabelGenerator((int) (short) 10);
        combinedDomainXYPlot1.setRenderer((org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer28);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent41 = null;
        combinedDomainXYPlot1.datasetChanged(datasetChangeEvent41);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 15 + "'", int13 == 15);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNull(xYItemLabelGenerator39);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator2 = null;
        xYAreaRenderer0.setLegendItemToolTipGenerator(xYSeriesLabelGenerator2);
        java.awt.Paint paint5 = xYAreaRenderer0.getSeriesPaint(2);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator7 = xYAreaRenderer0.getSeriesItemLabelGenerator(10);
        xYAreaRenderer0.setBaseCreateEntities(true, false);
        boolean boolean11 = xYAreaRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot14 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis13);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot16 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis15);
        int int17 = combinedDomainXYPlot16.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent19 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot16.rendererChanged(rendererChangeEvent19);
        combinedDomainXYPlot14.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot16);
        combinedDomainXYPlot16.setDomainMinorGridlinesVisible(true);
        boolean boolean24 = combinedDomainXYPlot16.isRangeCrosshairLockedOnData();
        java.awt.Paint paint25 = null;
        combinedDomainXYPlot16.setRangeTickBandPaint(paint25);
        java.awt.Paint paint27 = combinedDomainXYPlot16.getRangeCrosshairPaint();
        xYAreaRenderer0.setSeriesFillPaint((int) (short) 100, paint27, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNull(xYItemLabelGenerator7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 15 + "'", int17 == 15);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.NumberTick numberTick5 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (short) 10, "series", textAnchor2, textAnchor3, (double) (short) 10);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = month6.next();
        org.jfree.data.xy.XYSeries xYSeries9 = new org.jfree.data.xy.XYSeries((java.lang.Comparable) month6, false);
        xYSeries9.add((double) 10.0f, (java.lang.Number) 0.5d);
        boolean boolean13 = numberTick5.equals((java.lang.Object) 0.5d);
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.LineUtilities.clipLine(line2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        int int4 = combinedDomainXYPlot3.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot3.rendererChanged(rendererChangeEvent6);
        combinedDomainXYPlot1.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot3);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = combinedDomainXYPlot3.getDomainAxisEdge((int) (byte) 1);
        java.awt.Stroke stroke11 = combinedDomainXYPlot3.getRangeGridlineStroke();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis12);
        int int14 = combinedDomainXYPlot13.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot13.rendererChanged(rendererChangeEvent16);
        combinedDomainXYPlot3.removeChangeListener((org.jfree.chart.event.PlotChangeListener) combinedDomainXYPlot13);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        try {
            combinedDomainXYPlot13.drawOutline(graphics2D19, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries4.clear();
        timeSeries4.setDescription("series");
        int int8 = timeSeriesCollection0.indexOf(timeSeries4);
        try {
            java.lang.Number number11 = timeSeriesCollection0.getY(1900, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1900, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint2 = categoryAxis3D1.getLabelPaint();
        categoryAxis3D1.setTickMarkInsideLength((float) 0);
        java.awt.Font font5 = categoryAxis3D1.getLabelFont();
        categoryAxis3D1.setCategoryMargin((double) 1L);
        java.awt.Paint paint8 = categoryAxis3D1.getLabelPaint();
        int int9 = categoryAxis3D1.getMaximumCategoryLabelLines();
        categoryAxis3D1.setMaximumCategoryLabelLines((int) (byte) 1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("NO_CHANGE", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection1, true);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean7 = xYAreaRenderer6.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator8 = null;
        xYAreaRenderer6.setLegendItemToolTipGenerator(xYSeriesLabelGenerator8);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection1, valueAxis4, valueAxis5, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer6);
        boolean boolean11 = xYAreaRenderer6.isOutline();
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYAreaRenderer6.setSeriesItemLabelFont(100, font13);
        piePlot3D0.setLabelFont(font13);
        double double16 = piePlot3D0.getMaximumExplodePercent();
        boolean boolean17 = piePlot3D0.getAutoPopulateSectionOutlinePaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = null;
        try {
            piePlot3D0.setSimpleLabelOffset(rectangleInsets18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'offset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        int int0 = org.jfree.data.time.SerialDate.FIRST_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.axis.DateTickUnitType dateTickUnitType0 = org.jfree.chart.axis.DateTickUnitType.MINUTE;
        java.text.DateFormat dateFormat2 = null;
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit3 = new org.jfree.chart.axis.DateTickUnit(dateTickUnitType0, (int) (short) 0, dateFormat2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnitType0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = null;
        xYAreaRenderer0.setBaseItemLabelGenerator(xYItemLabelGenerator2, true);
        java.awt.Shape shape5 = xYAreaRenderer0.getBaseShape();
        java.awt.Paint paint6 = xYAreaRenderer0.getBasePaint();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis8);
        int int10 = combinedDomainXYPlot9.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.RenderingSource renderingSource13 = null;
        combinedDomainXYPlot9.select(generalPath11, rectangle2D12, renderingSource13);
        java.awt.Paint paint16 = combinedDomainXYPlot9.getQuadrantPaint((int) (short) 0);
        boolean boolean17 = combinedDomainXYPlot9.canSelectByRegion();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection18 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries22.clear();
        timeSeries22.setDescription("series");
        int int26 = timeSeriesCollection18.indexOf(timeSeries22);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer28 = null;
        org.jfree.chart.plot.PolarPlot polarPlot29 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection18, (org.jfree.chart.axis.ValueAxis) numberAxis27, polarItemRenderer28);
        boolean boolean30 = numberAxis27.isTickMarksVisible();
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        try {
            xYAreaRenderer0.fillRangeGridBand(graphics2D7, (org.jfree.chart.plot.XYPlot) combinedDomainXYPlot9, (org.jfree.chart.axis.ValueAxis) numberAxis27, rectangle2D31, (double) (short) 10, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = java.text.NumberFormat.getPercentInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test383() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test383");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        int int2 = segmentedTimeline1.getSegmentsExcluded();
//        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.chart.axis.SegmentedTimeline.Segment segment4 = segmentedTimeline1.getSegment(date3);
//        java.util.Date date5 = segment4.getDate();
//        long long6 = segmentedTimeline0.toTimelineValue(date5);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date5);
//        java.util.Calendar calendar8 = null;
//        try {
//            day7.peg(calendar8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(segmentedTimeline0);
//        org.junit.Assert.assertNotNull(segmentedTimeline1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 68 + "'", int2 == 68);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(segment4);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1099412556013L + "'", long6 == 1099412556013L);
//    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot3D0.setLabelGenerator(pieSectionLabelGenerator1);
        piePlot3D0.setShadowXOffset(0.0d);
        double double5 = piePlot3D0.getDepthFactor();
        java.awt.Paint paint6 = piePlot3D0.getLabelOutlinePaint();
        java.awt.Stroke stroke7 = piePlot3D0.getLabelLinkStroke();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.12d + "'", double5 == 0.12d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MAJOR;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis3);
        int int5 = combinedDomainXYPlot4.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot4.rendererChanged(rendererChangeEvent7);
        combinedDomainXYPlot2.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4);
        combinedDomainXYPlot4.setDomainMinorGridlinesVisible(true);
        int int12 = combinedDomainXYPlot4.getBackgroundImageAlignment();
        boolean boolean13 = tickType0.equals((java.lang.Object) int12);
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 15 + "'", int12 == 15);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.geom.Point2D point2D1 = org.jfree.chart.util.SerialUtilities.readPoint2D(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.NumberTick numberTick10 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (short) 10, "series", textAnchor7, textAnchor8, (double) (short) 10);
        org.jfree.chart.text.TextAnchor textAnchor11 = numberTick10.getRotationAnchor();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor4, textAnchor11);
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor17 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.NumberTick numberTick19 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (short) 10, "series", textAnchor16, textAnchor17, (double) (short) 10);
        org.jfree.chart.text.TextAnchor textAnchor20 = numberTick19.getRotationAnchor();
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("RectangleAnchor.CENTER", graphics2D1, (float) 3, (-1.0f), textAnchor11, (double) (-460), textAnchor20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertNotNull(textAnchor17);
        org.junit.Assert.assertNotNull(textAnchor20);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("35");
        dateAxis1.zoomRange((double) (byte) 1, 3.0d);
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = null;
        try {
            java.util.Date date6 = dateAxis1.calculateLowestVisibleTickValue(dateTickUnit5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDiagonalCross((float) (-1), (float) (-460));
        org.jfree.chart.plot.PiePlot3D piePlot3D3 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator4 = null;
        piePlot3D3.setLabelGenerator(pieSectionLabelGenerator4);
        piePlot3D3.setShadowXOffset(0.0d);
        piePlot3D3.setIgnoreZeroValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = piePlot3D3.getSimpleLabelOffset();
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) piePlot3D3, "RangeType.FULL", "35");
        java.lang.String str14 = plotEntity13.getToolTipText();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "RangeType.FULL" + "'", str14.equals("RangeType.FULL"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries4.clear();
        timeSeries4.setDescription("series");
        int int8 = timeSeriesCollection0.indexOf(timeSeries4);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection0, (org.jfree.chart.axis.ValueAxis) numberAxis9, polarItemRenderer10);
        java.lang.Object obj12 = polarPlot11.clone();
        java.lang.String str13 = polarPlot11.getPlotType();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Polar Plot" + "'", str13.equals("Polar Plot"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        java.text.NumberFormat numberFormat2 = java.text.NumberFormat.getNumberInstance();
        java.lang.String str4 = numberFormat2.format(0.0d);
        java.lang.String str6 = numberFormat2.format((long) '#');
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = new org.jfree.chart.axis.NumberTickUnit((double) 86400000L, numberFormat2, 4);
        try {
            org.jfree.chart.axis.TickUnit tickUnit9 = tickUnits0.getLargerTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "0" + "'", str4.equals("0"));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "35" + "'", str6.equals("35"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean6 = xYAreaRenderer5.isOutline();
        java.awt.Shape shape7 = xYAreaRenderer5.getBaseShape();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic9 = new org.jfree.chart.title.LegendGraphic(shape7, (java.awt.Paint) color8);
        legendGraphic9.setWidth((double) 8);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D16 = legendGraphic9.arrange(graphics2D12, rectangleConstraint15);
        double double17 = legendGraphic9.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = legendGraphic9.getShapeLocation();
        java.lang.String str19 = rectangleAnchor18.toString();
        java.awt.Shape shape22 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape4, rectangleAnchor18, (double) (short) -1, 0.05d);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer23 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint24 = xYAreaRenderer23.getBaseLegendTextPaint();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator25 = null;
        xYAreaRenderer23.setBaseItemLabelGenerator(xYItemLabelGenerator25, true);
        java.awt.Paint paint28 = xYAreaRenderer23.getBaseFillPaint();
        try {
            org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem(attributedString0, "NO_CHANGE", "1", "NO_CHANGE", shape4, paint28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(size2D16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "RectangleAnchor.CENTER" + "'", str19.equals("RectangleAnchor.CENTER"));
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        combinedDomainXYPlot1.select(generalPath3, rectangle2D4, renderingSource5);
        java.awt.Paint paint8 = combinedDomainXYPlot1.getQuadrantPaint((int) (short) 0);
        combinedDomainXYPlot1.clearAnnotations();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = combinedDomainXYPlot1.getDrawingSupplier();
        java.awt.geom.GeneralPath generalPath11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.RenderingSource renderingSource13 = null;
        combinedDomainXYPlot1.select(generalPath11, rectangle2D12, renderingSource13);
        java.awt.Paint paint15 = combinedDomainXYPlot1.getDomainTickBandPaint();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot17 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis16);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.data.Range range19 = combinedDomainXYPlot17.getDataRange(valueAxis18);
        java.lang.Object obj20 = null;
        boolean boolean21 = combinedDomainXYPlot17.equals(obj20);
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        combinedDomainXYPlot17.setRangeGridlineStroke(stroke22);
        combinedDomainXYPlot1.setRangeZeroBaselineStroke(stroke22);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        java.awt.geom.Ellipse2D ellipse2D0 = null;
        java.awt.geom.Ellipse2D ellipse2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(ellipse2D0, ellipse2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.lang.String str0 = org.jfree.chart.urls.StandardXYURLGenerator.DEFAULT_PREFIX;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "index.html" + "'", str0.equals("index.html"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getBaseShapesVisible();
        java.awt.Shape shape2 = xYLineAndShapeRenderer0.getLegendLine();
        java.lang.Object obj3 = xYLineAndShapeRenderer0.clone();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.plot.PieLabelDistributor pieLabelDistributor1 = new org.jfree.chart.plot.PieLabelDistributor((int) ' ');
        org.jfree.chart.plot.PieLabelRecord pieLabelRecord2 = null;
        try {
            pieLabelDistributor1.addPieLabelRecord(pieLabelRecord2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'record' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        boolean boolean1 = numberAxis0.isVerticalTickLabels();
        numberAxis0.setNegativeArrowVisible(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) 0.5f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.FIXED;
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection1 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries5.clear();
        timeSeries5.setDescription("series");
        int int9 = timeSeriesCollection1.indexOf(timeSeries5);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer11 = null;
        org.jfree.chart.plot.PolarPlot polarPlot12 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection1, (org.jfree.chart.axis.ValueAxis) numberAxis10, polarItemRenderer11);
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = polarPlot12.getOrientation();
        boolean boolean14 = lengthConstraintType0.equals((java.lang.Object) polarPlot12);
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot3D0.setLabelGenerator(pieSectionLabelGenerator1);
        piePlot3D0.setShadowXOffset(0.0d);
        piePlot3D0.setCircular(true);
        java.awt.Font font7 = piePlot3D0.getLabelFont();
        piePlot3D0.setDepthFactor((double) (byte) 1);
        java.awt.Paint paint10 = piePlot3D0.getBaseSectionOutlinePaint();
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot2 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis1);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis3);
        int int5 = combinedDomainXYPlot4.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot4.rendererChanged(rendererChangeEvent7);
        combinedDomainXYPlot2.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot4);
        combinedDomainXYPlot4.setRangeGridlinesVisible(false);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot13 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis12);
        int int14 = combinedDomainXYPlot13.getBackgroundImageAlignment();
        combinedDomainXYPlot13.setForegroundAlpha((float) (-1));
        org.jfree.chart.axis.AxisLocation axisLocation18 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        combinedDomainXYPlot13.setDomainAxisLocation((int) (short) 1, axisLocation18);
        org.jfree.chart.axis.AxisLocation axisLocation20 = axisLocation18.getOpposite();
        combinedDomainXYPlot4.setDomainAxisLocation(axisLocation20, false);
        boolean boolean23 = horizontalAlignment0.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 15 + "'", int5 == 15);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("NO_CHANGE");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        java.lang.Object obj1 = null;
        boolean boolean2 = textAnchor0.equals(obj1);
        java.lang.String str3 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "TextAnchor.BASELINE_CENTER" + "'", str3.equals("TextAnchor.BASELINE_CENTER"));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 60000L + "'", long0 == 60000L);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        xYAreaRenderer0.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition2);
        java.awt.Font font5 = xYAreaRenderer0.getLegendTextFont(1);
        org.junit.Assert.assertNull(font5);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        java.awt.Shape shape2 = xYAreaRenderer0.getBaseShape();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint(0.0d, (double) (-1L));
        org.jfree.chart.util.Size2D size2D9 = legendGraphic4.arrange(graphics2D5, rectangleConstraint8);
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D11 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint12 = categoryAxis3D11.getLabelPaint();
        categoryAxis3D11.setTickMarkInsideLength((float) 0);
        java.awt.Font font15 = categoryAxis3D11.getLabelFont();
        boolean boolean16 = legendGraphic4.equals((java.lang.Object) categoryAxis3D11);
        java.awt.Color color18 = java.awt.Color.ORANGE;
        categoryAxis3D11.setTickLabelPaint((java.lang.Comparable) 1560495599999L, (java.awt.Paint) color18);
        categoryAxis3D11.setUpperMargin((double) 15);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot3D0.setLabelGenerator(pieSectionLabelGenerator1);
        piePlot3D0.setAutoPopulateSectionOutlineStroke(true);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        java.util.List list2 = combinedRangeXYPlot1.getSubplots();
        java.util.List list3 = combinedRangeXYPlot1.getSubplots();
        combinedRangeXYPlot1.clearRangeAxes();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean7 = xYAreaRenderer6.isOutline();
        java.awt.Shape shape8 = xYAreaRenderer6.getBaseShape();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic10 = new org.jfree.chart.title.LegendGraphic(shape8, (java.awt.Paint) color9);
        legendGraphic10.setWidth((double) 8);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D17 = legendGraphic10.arrange(graphics2D13, rectangleConstraint16);
        double double18 = legendGraphic10.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = legendGraphic10.getShapeLocation();
        java.awt.geom.Rectangle2D rectangle2D20 = legendGraphic10.getBounds();
        java.awt.geom.Point2D point2D21 = null;
        org.jfree.chart.plot.PlotState plotState22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        try {
            combinedRangeXYPlot1.draw(graphics2D5, rectangle2D20, point2D21, plotState22, plotRenderingInfo23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(list3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(size2D17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor19);
        org.junit.Assert.assertNotNull(rectangle2D20);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray3 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot0.setRenderer(categoryItemRenderer5, false);
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = null;
        org.jfree.chart.util.Layer layer10 = null;
        try {
            categoryPlot0.addDomainMarker(4, categoryMarker9, layer10, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(categoryAxisArray3);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.plot.CrosshairState crosshairState0 = new org.jfree.chart.plot.CrosshairState();
        double double1 = crosshairState0.getAnchorY();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries3.clear();
        timeSeries3.setDescription("series");
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        java.awt.Paint paint3 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        xYAreaRenderer4.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition6);
        boolean boolean8 = xYAreaRenderer4.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D9.centerRange((-1.0d));
        java.awt.Paint paint12 = numberAxis3D9.getTickLabelPaint();
        xYAreaRenderer4.setBaseFillPaint(paint12, true);
        categoryPlot0.setDomainCrosshairPaint(paint12);
        categoryPlot0.setAnchorValue((double) 1900);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        xYAreaRenderer0.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition2);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator5 = null;
        try {
            xYAreaRenderer0.setSeriesItemLabelGenerator((-1), xYItemLabelGenerator5, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries4.clear();
        timeSeries4.setDescription("series");
        int int8 = timeSeriesCollection0.indexOf(timeSeries4);
        try {
            timeSeriesCollection0.setSelected(0, 1900, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'series' argument is out of bounds (0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) (-1), (double) '4', (double) 10L, (double) 100L);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer7 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean8 = xYAreaRenderer7.isOutline();
        java.awt.Shape shape9 = xYAreaRenderer7.getBaseShape();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic11 = new org.jfree.chart.title.LegendGraphic(shape9, (java.awt.Paint) color10);
        legendGraphic11.setWidth((double) 8);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D18 = legendGraphic11.arrange(graphics2D14, rectangleConstraint17);
        double double19 = legendGraphic11.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = legendGraphic11.getShapeLocation();
        java.awt.geom.Rectangle2D rectangle2D21 = legendGraphic11.getBounds();
        rectangleInsets6.trim(rectangle2D21);
        try {
            blockBorder4.draw(graphics2D5, rectangle2D21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(size2D18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(rectangle2D21);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator0 = new org.jfree.chart.urls.StandardXYURLGenerator();
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 1099412556013L, 0.0d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer3D2.getLegendItemLabelGenerator();
        org.jfree.chart.LegendItem legendItem6 = barRenderer3D2.getLegendItem((int) (byte) 1, 1);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke9 = categoryPlot8.getRangeMinorGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot8.getRenderer(10);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer12 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean13 = xYAreaRenderer12.isOutline();
        java.awt.Shape shape14 = xYAreaRenderer12.getBaseShape();
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic16 = new org.jfree.chart.title.LegendGraphic(shape14, (java.awt.Paint) color15);
        legendGraphic16.setWidth((double) 8);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D23 = legendGraphic16.arrange(graphics2D19, rectangleConstraint22);
        double double24 = legendGraphic16.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = legendGraphic16.getShapeLocation();
        java.awt.geom.Rectangle2D rectangle2D26 = legendGraphic16.getBounds();
        try {
            barRenderer3D2.drawOutline(graphics2D7, categoryPlot8, rectangle2D26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNull(legendItem6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(size2D23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertNotNull(rectangle2D26);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray3 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot0.getRangeAxisLocation(0);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(categoryAxisArray3);
        org.junit.Assert.assertNotNull(axisLocation6);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double1 = rectangleInsets0.getRight();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("java.awt.Color[r=255,g=128,b=128]", regularTimePeriod2, regularTimePeriod5);
        float float7 = periodAxis6.getMinorTickMarkInsideLength();
        periodAxis6.setMinorTickCount(2147483647);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.NO_DST_TIME_ZONE = timeZone0;
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = null;
        piePlot3D1.setLabelGenerator(pieSectionLabelGenerator2);
        piePlot3D1.setShadowXOffset(0.0d);
        double double6 = piePlot3D1.getDepthFactor();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis9);
        int int11 = combinedDomainXYPlot10.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot10.rendererChanged(rendererChangeEvent13);
        combinedDomainXYPlot8.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot10);
        combinedDomainXYPlot10.setDomainMinorGridlinesVisible(true);
        boolean boolean18 = combinedDomainXYPlot10.isRangeCrosshairLockedOnData();
        java.awt.Paint paint19 = null;
        combinedDomainXYPlot10.setRangeTickBandPaint(paint19);
        java.awt.Paint paint21 = combinedDomainXYPlot10.getRangeCrosshairPaint();
        piePlot3D1.setBackgroundPaint(paint21);
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("35", paint21);
        legendItem23.setLineVisible(true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.12d + "'", double6 == 0.12d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        boolean boolean1 = xYLineAndShapeRenderer0.getBaseShapesVisible();
        xYLineAndShapeRenderer0.setBaseSeriesVisibleInLegend(true);
        xYLineAndShapeRenderer0.setAutoPopulateSeriesPaint(false);
        boolean boolean8 = xYLineAndShapeRenderer0.getItemShapeFilled(100, 0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.labels.StandardXYSeriesLabelGenerator standardXYSeriesLabelGenerator1 = new org.jfree.chart.labels.StandardXYSeriesLabelGenerator("series");
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot5 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis4);
        int int6 = combinedDomainXYPlot5.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot5.rendererChanged(rendererChangeEvent8);
        combinedDomainXYPlot3.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot5);
        boolean boolean11 = standardXYSeriesLabelGenerator1.equals((java.lang.Object) combinedDomainXYPlot5);
        org.jfree.chart.plot.Plot plot12 = combinedDomainXYPlot5.getParent();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 15 + "'", int6 == 15);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(plot12);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("RangeType.FULL");
        java.lang.String str3 = legendItem2.getURLText();
        java.lang.String str4 = legendItem2.getURLText();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis5);
        double double7 = combinedRangeXYPlot6.getGap();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot9 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis8);
        java.awt.Paint paint10 = combinedDomainXYPlot9.getBackgroundPaint();
        combinedRangeXYPlot6.addChangeListener((org.jfree.chart.event.PlotChangeListener) combinedDomainXYPlot9);
        boolean boolean12 = legendItem2.equals((java.lang.Object) combinedRangeXYPlot6);
        legendItemCollection0.add(legendItem2);
        boolean boolean14 = legendItem2.isShapeVisible();
        legendItem2.setDescription("");
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNull(str4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 5.0d + "'", double7 == 5.0d);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, false);
        int int5 = xYSeriesCollection0.getSeriesCount();
        org.jfree.data.Range range7 = xYSeriesCollection0.getDomainBounds(true);
        try {
            double double10 = xYSeriesCollection0.getStartXValue(15, 15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(range7);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.axis.LogAxis logAxis0 = new org.jfree.chart.axis.LogAxis();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean5 = xYAreaRenderer4.isOutline();
        java.awt.Shape shape6 = xYAreaRenderer4.getBaseShape();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape6, (java.awt.Paint) color7);
        legendGraphic8.setWidth((double) 8);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D15 = legendGraphic8.arrange(graphics2D11, rectangleConstraint14);
        double double16 = legendGraphic8.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = legendGraphic8.getShapeLocation();
        java.awt.geom.Rectangle2D rectangle2D18 = legendGraphic8.getBounds();
        rectangleInsets3.trim(rectangle2D18);
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.util.RectangleEdge.RIGHT;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        try {
            org.jfree.chart.axis.AxisState axisState23 = logAxis0.draw(graphics2D1, (double) 1L, rectangle2D18, rectangle2D20, rectangleEdge21, plotRenderingInfo22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(size2D15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor17);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer1 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint2 = xYAreaRenderer1.getBaseLegendTextPaint();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator3 = null;
        xYAreaRenderer1.setBaseItemLabelGenerator(xYItemLabelGenerator3, true);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot7 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.data.Range range9 = combinedDomainXYPlot7.getDataRange(valueAxis8);
        java.lang.Object obj10 = null;
        boolean boolean11 = combinedDomainXYPlot7.equals(obj10);
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        combinedDomainXYPlot7.setRangeGridlineStroke(stroke12);
        xYAreaRenderer1.setBaseOutlineStroke(stroke12);
        java.awt.Font font18 = xYAreaRenderer1.getItemLabelFont((int) (short) 100, 12, false);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.jfree.chart.block.LabelBlock labelBlock20 = new org.jfree.chart.block.LabelBlock("35", font18, (java.awt.Paint) color19);
        java.lang.Object obj21 = labelBlock20.clone();
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        double[] doubleArray6 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray11 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray12 = new double[][] { doubleArray6, doubleArray11 };
        org.jfree.data.category.CategoryDataset categoryDataset13 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray12);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot14 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset13);
        org.jfree.data.category.CategoryDataset categoryDataset15 = multiplePiePlot14.getDataset();
        java.lang.Number number16 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset15);
        java.lang.Number number17 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset15);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(categoryDataset13);
        org.junit.Assert.assertNotNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0.0d + "'", number16.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 0.0d + "'", number17.equals(0.0d));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimePeriodAnchor timePeriodAnchor1 = org.jfree.data.time.TimePeriodAnchor.END;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D3 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint4 = categoryAxis3D3.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent8 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D3, jFreeChart5, (int) (short) 1, (int) (short) 10);
        boolean boolean9 = timePeriodAnchor1.equals((java.lang.Object) (short) 10);
        timeSeriesCollection0.setXPosition(timePeriodAnchor1);
        org.jfree.data.xy.IntervalXYDelegate intervalXYDelegate11 = new org.jfree.data.xy.IntervalXYDelegate((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        boolean boolean12 = intervalXYDelegate11.isAutoWidth();
        intervalXYDelegate11.setIntervalPositionFactor((double) 0L);
        double double15 = intervalXYDelegate11.getIntervalWidth();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType16 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str17 = lengthAdjustmentType16.toString();
        boolean boolean18 = intervalXYDelegate11.equals((java.lang.Object) lengthAdjustmentType16);
        org.junit.Assert.assertNotNull(timePeriodAnchor1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(lengthAdjustmentType16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "NO_CHANGE" + "'", str17.equals("NO_CHANGE"));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries4.clear();
        timeSeries4.setDescription("series");
        int int8 = timeSeriesCollection0.indexOf(timeSeries4);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection0, (org.jfree.chart.axis.ValueAxis) numberAxis9, polarItemRenderer10);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = polarPlot11.getOrientation();
        java.awt.Paint paint13 = polarPlot11.getRadiusGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        polarPlot11.zoomRangeAxes(1.560495599991E12d, (double) (short) 0, plotRenderingInfo16, point2D17);
        double double19 = polarPlot11.getMaxRadius();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 8.19260189995275E11d + "'", double19 == 8.19260189995275E11d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateLeftInset(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator2 = null;
        xYAreaRenderer0.setLegendItemToolTipGenerator(xYSeriesLabelGenerator2);
        java.awt.Paint paint5 = xYAreaRenderer0.getSeriesPaint(2);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator7 = xYAreaRenderer0.getSeriesItemLabelGenerator(10);
        xYAreaRenderer0.setBaseCreateEntities(true, false);
        boolean boolean11 = xYAreaRenderer0.getAutoPopulateSeriesOutlineStroke();
        java.awt.Paint paint13 = xYAreaRenderer0.getLegendTextPaint(10);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNull(xYItemLabelGenerator7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(paint13);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        java.awt.Color color1 = java.awt.Color.getColor("Combined Range XYPlot");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        double double2 = combinedRangeXYPlot1.getGap();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis3);
        java.awt.Paint paint5 = combinedDomainXYPlot4.getBackgroundPaint();
        combinedRangeXYPlot1.addChangeListener((org.jfree.chart.event.PlotChangeListener) combinedDomainXYPlot4);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection7 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection7, true);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection7, false);
        int int12 = xYSeriesCollection7.getSeriesCount();
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection7);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D14.centerRange((-1.0d));
        java.awt.Paint paint17 = numberAxis3D14.getTickLabelPaint();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D18.setUpperMargin((double) (short) 0);
        numberAxis3D18.resizeRange2((double) 10L, (double) 12);
        numberAxis3D18.setAutoTickUnitSelection(false);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer26 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = null;
        xYAreaRenderer26.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition28);
        boolean boolean30 = xYAreaRenderer26.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D31.centerRange((-1.0d));
        java.awt.Paint paint34 = numberAxis3D31.getTickLabelPaint();
        xYAreaRenderer26.setBaseFillPaint(paint34, true);
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection7, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, (org.jfree.chart.axis.ValueAxis) numberAxis3D18, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer26);
        combinedRangeXYPlot1.add(xYPlot37, (int) 'a');
        org.jfree.chart.util.Layer layer41 = null;
        java.util.Collection collection42 = xYPlot37.getDomainMarkers(2, layer41);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.0d + "'", double2 == 5.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNull(collection42);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        java.lang.Object obj1 = xYLineAndShapeRenderer0.clone();
        boolean boolean4 = xYLineAndShapeRenderer0.getItemShapeFilled(1, 15);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = new org.jfree.chart.ui.ProjectInfo();
        org.jfree.chart.ui.Library[] libraryArray1 = projectInfo0.getLibraries();
        org.jfree.chart.ui.Library[] libraryArray2 = projectInfo0.getOptionalLibraries();
        java.awt.Image image3 = null;
        projectInfo0.setLogo(image3);
        org.junit.Assert.assertNotNull(libraryArray1);
        org.junit.Assert.assertNotNull(libraryArray2);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        double double3 = xYSeriesCollection0.getIntervalWidth();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("35");
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        int int4 = combinedDomainXYPlot3.getBackgroundImageAlignment();
        combinedDomainXYPlot3.setForegroundAlpha((float) (-1));
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis7);
        int int9 = combinedDomainXYPlot8.getBackgroundImageAlignment();
        combinedDomainXYPlot8.setForegroundAlpha((float) (-1));
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        combinedDomainXYPlot8.setDomainAxisLocation((int) (short) 1, axisLocation13);
        combinedDomainXYPlot3.setDomainAxisLocation(axisLocation13);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer16 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot19 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis18);
        java.awt.Paint paint20 = combinedDomainXYPlot19.getBackgroundPaint();
        xYAreaRenderer16.setSeriesPaint(2, paint20);
        combinedDomainXYPlot3.setRangeGridlinePaint(paint20);
        java.awt.Stroke stroke23 = combinedDomainXYPlot3.getRangeZeroBaselineStroke();
        boolean boolean24 = dateAxis1.equals((java.lang.Object) stroke23);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 15 + "'", int9 == 15);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.plot.PiePlot3D piePlot3D1 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator2 = null;
        piePlot3D1.setLabelGenerator(pieSectionLabelGenerator2);
        piePlot3D1.setShadowXOffset(0.0d);
        double double6 = piePlot3D1.getDepthFactor();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot8 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis7);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot10 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis9);
        int int11 = combinedDomainXYPlot10.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot10.rendererChanged(rendererChangeEvent13);
        combinedDomainXYPlot8.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot10);
        combinedDomainXYPlot10.setDomainMinorGridlinesVisible(true);
        boolean boolean18 = combinedDomainXYPlot10.isRangeCrosshairLockedOnData();
        java.awt.Paint paint19 = null;
        combinedDomainXYPlot10.setRangeTickBandPaint(paint19);
        java.awt.Paint paint21 = combinedDomainXYPlot10.getRangeCrosshairPaint();
        piePlot3D1.setBackgroundPaint(paint21);
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("35", paint21);
        java.awt.Paint paint24 = null;
        try {
            legendItem23.setFillPaint(paint24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.12d + "'", double6 == 0.12d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 15 + "'", int11 == 15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        combinedDomainXYPlot1.setForegroundAlpha((float) (-1));
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        combinedDomainXYPlot1.setDomainAxisLocation((int) (short) 1, axisLocation6);
        boolean boolean8 = combinedDomainXYPlot1.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        java.awt.Font font1 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_FONT;
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("item", font1);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        double double2 = combinedRangeXYPlot1.getGap();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis3);
        java.awt.Paint paint5 = combinedDomainXYPlot4.getBackgroundPaint();
        combinedRangeXYPlot1.addChangeListener((org.jfree.chart.event.PlotChangeListener) combinedDomainXYPlot4);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection7 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection7, true);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection7, false);
        int int12 = xYSeriesCollection7.getSeriesCount();
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection7);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D14.centerRange((-1.0d));
        java.awt.Paint paint17 = numberAxis3D14.getTickLabelPaint();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D18.setUpperMargin((double) (short) 0);
        numberAxis3D18.resizeRange2((double) 10L, (double) 12);
        numberAxis3D18.setAutoTickUnitSelection(false);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer26 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = null;
        xYAreaRenderer26.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition28);
        boolean boolean30 = xYAreaRenderer26.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D31.centerRange((-1.0d));
        java.awt.Paint paint34 = numberAxis3D31.getTickLabelPaint();
        xYAreaRenderer26.setBaseFillPaint(paint34, true);
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection7, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, (org.jfree.chart.axis.ValueAxis) numberAxis3D18, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer26);
        combinedRangeXYPlot1.add(xYPlot37, (int) 'a');
        combinedRangeXYPlot1.setDomainMinorGridlinesVisible(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.0d + "'", double2 == 5.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray3 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray3);
        categoryPlot0.setWeight(2147483647);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomRangeAxes((double) 100.0f, plotRenderingInfo8, point2D9);
        int int11 = categoryPlot0.getDomainAxisCount();
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection12 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries16.clear();
        timeSeries16.setDescription("series");
        int int20 = timeSeriesCollection12.indexOf(timeSeries16);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer22 = null;
        org.jfree.chart.plot.PolarPlot polarPlot23 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection12, (org.jfree.chart.axis.ValueAxis) numberAxis21, polarItemRenderer22);
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = polarPlot23.getOrientation();
        categoryPlot0.setOrientation(plotOrientation24);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(categoryAxisArray3);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation24);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer5 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean6 = xYAreaRenderer5.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator7 = null;
        xYAreaRenderer5.setLegendItemToolTipGenerator(xYSeriesLabelGenerator7);
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection0, valueAxis3, valueAxis4, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer5);
        xYPlot9.clearAnnotations();
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.xy.XYDataItem xYDataItem2 = new org.jfree.data.xy.XYDataItem((double) 8, 100.0d);
        double double3 = xYDataItem2.getYValue();
        double double4 = xYDataItem2.getXValue();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 8.0d + "'", double4 == 8.0d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = null;
        xYAreaRenderer0.setBaseItemLabelGenerator(xYItemLabelGenerator2, true);
        java.awt.Shape shape5 = xYAreaRenderer0.getBaseShape();
        java.awt.Paint paint6 = xYAreaRenderer0.getBasePaint();
        java.awt.Stroke stroke8 = xYAreaRenderer0.getSeriesOutlineStroke(10);
        xYAreaRenderer0.setBaseItemLabelsVisible(true, true);
        org.junit.Assert.assertNull(paint1);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(stroke8);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray3 = new org.jfree.chart.axis.CategoryAxis[] {};
        categoryPlot0.setDomainAxes(categoryAxisArray3);
        categoryPlot0.setWeight(2147483647);
        org.jfree.chart.ChartColor chartColor13 = new org.jfree.chart.ChartColor(1, 3, (int) (short) 100);
        org.jfree.chart.plot.IntervalMarker intervalMarker14 = new org.jfree.chart.plot.IntervalMarker((double) ' ', (double) 68, (java.awt.Paint) chartColor13);
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean17 = categoryPlot0.removeDomainMarker(28, (org.jfree.chart.plot.Marker) intervalMarker14, layer15, true);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) true);
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(categoryAxisArray3);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setUpperMargin((double) (short) 0);
        numberAxis3D0.resizeRange2((double) 10L, (double) 12);
        numberAxis3D0.setAutoTickUnitSelection(false);
        numberAxis3D0.centerRange(5.0d);
        double double10 = numberAxis3D0.getAutoRangeMinimumSize();
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0E-8d + "'", double10 == 1.0E-8d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        java.awt.Shape shape2 = xYAreaRenderer0.getBaseShape();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic4 = new org.jfree.chart.title.LegendGraphic(shape2, (java.awt.Paint) color3);
        org.jfree.chart.entity.ChartEntity chartEntity5 = new org.jfree.chart.entity.ChartEntity(shape2);
        java.lang.String str6 = chartEntity5.getShapeCoords();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "-3,-3,3,3" + "'", str6.equals("-3,-3,3,3"));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        java.text.NumberFormat numberFormat0 = java.text.NumberFormat.getNumberInstance();
        java.lang.String str2 = numberFormat0.format(0.0d);
        java.math.RoundingMode roundingMode3 = numberFormat0.getRoundingMode();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean5 = xYAreaRenderer4.isOutline();
        java.awt.Shape shape6 = xYAreaRenderer4.getBaseShape();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic8 = new org.jfree.chart.title.LegendGraphic(shape6, (java.awt.Paint) color7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint(0.0d, (double) (-1L));
        org.jfree.chart.util.Size2D size2D13 = legendGraphic8.arrange(graphics2D9, rectangleConstraint12);
        try {
            java.text.AttributedCharacterIterator attributedCharacterIterator14 = numberFormat0.formatToCharacterIterator((java.lang.Object) legendGraphic8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Cannot format given Object as a Number");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "0" + "'", str2.equals("0"));
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + java.math.RoundingMode.HALF_EVEN + "'", roundingMode3.equals(java.math.RoundingMode.HALF_EVEN));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(size2D13);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        java.util.List list2 = combinedRangeXYPlot1.getSubplots();
        java.util.List list3 = combinedRangeXYPlot1.getSubplots();
        try {
            java.util.Collection collection4 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list3);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.util.LogFormat logFormat4 = new org.jfree.chart.util.LogFormat((double) 10.0f, "hi!", "RangeType.FULL", false);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries3.clear();
        timeSeries3.setDescription("series");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection7 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries11.clear();
        timeSeries11.setDescription("series");
        int int15 = timeSeriesCollection7.indexOf(timeSeries11);
        java.lang.String str16 = timeSeries11.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries17 = timeSeries3.addAndOrUpdate(timeSeries11);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = null;
        try {
            timeSeries3.add(timeSeriesDataItem18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "0" + "'", str16.equals("0"));
        org.junit.Assert.assertNotNull(timeSeries17);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        combinedDomainXYPlot1.select(generalPath3, rectangle2D4, renderingSource5);
        java.awt.Paint paint8 = combinedDomainXYPlot1.getQuadrantPaint((int) (short) 0);
        combinedDomainXYPlot1.setBackgroundAlpha(0.0f);
        org.jfree.chart.plot.Marker marker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        boolean boolean15 = combinedDomainXYPlot1.removeDomainMarker((-1), marker12, layer13, true);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer17 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot20 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis19);
        java.awt.Paint paint21 = combinedDomainXYPlot20.getBackgroundPaint();
        xYAreaRenderer17.setSeriesPaint(2, paint21);
        xYAreaRenderer17.setAutoPopulateSeriesPaint(false);
        combinedDomainXYPlot1.setRenderer(0, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer17, true);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator28 = xYAreaRenderer17.getSeriesItemLabelGenerator((int) (short) 10);
        java.awt.Stroke stroke30 = null;
        xYAreaRenderer17.setSeriesStroke(15, stroke30);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer32 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean33 = xYAreaRenderer32.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator34 = null;
        xYAreaRenderer32.setLegendItemToolTipGenerator(xYSeriesLabelGenerator34);
        boolean boolean36 = xYAreaRenderer32.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator38 = null;
        xYAreaRenderer32.setSeriesToolTipGenerator((int) (short) 100, xYToolTipGenerator38);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition43 = xYAreaRenderer32.getNegativeItemLabelPosition(100, (int) (byte) -1, false);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor44 = itemLabelPosition43.getItemLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor45 = itemLabelPosition43.getTextAnchor();
        xYAreaRenderer17.setBaseNegativeItemLabelPosition(itemLabelPosition43);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor47 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.jfree.data.Range range48 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double49 = range48.getLength();
        boolean boolean50 = itemLabelAnchor47.equals((java.lang.Object) double49);
        org.jfree.chart.text.TextAnchor textAnchor51 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition52 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor47, textAnchor51);
        xYAreaRenderer17.setBaseNegativeItemLabelPosition(itemLabelPosition52, false);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(xYItemLabelGenerator28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition43);
        org.junit.Assert.assertNotNull(itemLabelAnchor44);
        org.junit.Assert.assertNotNull(textAnchor45);
        org.junit.Assert.assertNotNull(itemLabelAnchor47);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.0d + "'", double49 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(textAnchor51);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean1 = xYAreaRenderer0.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator2 = null;
        xYAreaRenderer0.setLegendItemToolTipGenerator(xYSeriesLabelGenerator2);
        boolean boolean4 = xYAreaRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator6 = null;
        xYAreaRenderer0.setSeriesToolTipGenerator((int) (short) 100, xYToolTipGenerator6);
        boolean boolean11 = xYAreaRenderer0.getItemCreateEntity(0, 28, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.centerRange((-1.0d));
        java.awt.Paint paint3 = numberAxis3D0.getTickLabelPaint();
        float float4 = numberAxis3D0.getTickMarkInsideLength();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D5.centerRange((-1.0d));
        java.awt.Paint paint8 = numberAxis3D5.getTickLabelPaint();
        org.jfree.data.Range range9 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double10 = range9.getLength();
        numberAxis3D5.setRangeWithMargins(range9, false, false);
        double double15 = range9.constrain(0.0d);
        numberAxis3D0.setRangeWithMargins(range9, true, false);
        java.awt.Shape shape19 = numberAxis3D0.getDownArrow();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        int int2 = combinedDomainXYPlot1.getBackgroundImageAlignment();
        java.awt.geom.GeneralPath generalPath3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        combinedDomainXYPlot1.select(generalPath3, rectangle2D4, renderingSource5);
        java.awt.Paint paint8 = combinedDomainXYPlot1.getQuadrantPaint((int) (short) 0);
        combinedDomainXYPlot1.clearAnnotations();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier10 = combinedDomainXYPlot1.getDrawingSupplier();
        java.awt.geom.GeneralPath generalPath11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.RenderingSource renderingSource13 = null;
        combinedDomainXYPlot1.select(generalPath11, rectangle2D12, renderingSource13);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        combinedDomainXYPlot1.setDomainAxisLocation(axisLocation15, true);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D18.setUpperMargin((double) (short) 0);
        numberAxis3D18.resizeRange2((double) 10L, (double) 12);
        numberAxis3D18.setAutoTickUnitSelection(false);
        numberAxis3D18.centerRange(5.0d);
        org.jfree.chart.event.AxisChangeListener axisChangeListener28 = null;
        numberAxis3D18.addChangeListener(axisChangeListener28);
        org.jfree.data.Range range30 = combinedDomainXYPlot1.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D18);
        numberAxis3D18.setRange(0.2d, (double) 100L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 15 + "'", int2 == 15);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(drawingSupplier10);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNull(range30);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection0 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, true);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, false);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot6 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis5);
        java.util.List list7 = combinedRangeXYPlot6.getSubplots();
        java.util.List list8 = combinedRangeXYPlot6.getSubplots();
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.iterateToFindDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection0, list8, true);
        try {
            java.lang.Number number13 = xYSeriesCollection0.getStartX((int) (short) 0, 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNull(range10);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent2 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker1);
        org.jfree.chart.plot.Marker marker3 = markerChangeEvent2.getMarker();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        xYAreaRenderer4.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition6);
        boolean boolean8 = xYAreaRenderer4.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Paint paint10 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        xYAreaRenderer4.setSeriesItemLabelPaint((int) '#', paint10, false);
        marker3.setPaint(paint10);
        org.junit.Assert.assertNotNull(marker3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries4.clear();
        timeSeries4.setDescription("series");
        int int8 = timeSeriesCollection0.indexOf(timeSeries4);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer10 = null;
        org.jfree.chart.plot.PolarPlot polarPlot11 = new org.jfree.chart.plot.PolarPlot((org.jfree.data.xy.XYDataset) timeSeriesCollection0, (org.jfree.chart.axis.ValueAxis) numberAxis9, polarItemRenderer10);
        int int13 = timeSeriesCollection0.indexOf((java.lang.Comparable) "");
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

//    @Test
//    public void test474() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test474");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline1 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        segmentedTimeline0.setBaseTimeline(segmentedTimeline1);
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = org.jfree.chart.axis.SegmentedTimeline.newFifteenMinuteTimeline();
//        int int4 = segmentedTimeline3.getSegmentsExcluded();
//        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.chart.axis.SegmentedTimeline.Segment segment6 = segmentedTimeline3.getSegment(date5);
//        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date5);
//        long long8 = segmentedTimeline0.toTimelineValue(date5);
//        long long9 = segmentedTimeline0.getSegmentsExcludedSize();
//        org.junit.Assert.assertNotNull(segmentedTimeline0);
//        org.junit.Assert.assertNotNull(segmentedTimeline1);
//        org.junit.Assert.assertNotNull(segmentedTimeline3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 68 + "'", int4 == 68);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(segment6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1099412556013L + "'", long8 == 1099412556013L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 61200000L + "'", long9 == 61200000L);
//    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection1 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection1, true);
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer6 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean7 = xYAreaRenderer6.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator8 = null;
        xYAreaRenderer6.setLegendItemToolTipGenerator(xYSeriesLabelGenerator8);
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection1, valueAxis4, valueAxis5, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer6);
        boolean boolean11 = xYAreaRenderer6.isOutline();
        java.awt.Font font13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        xYAreaRenderer6.setSeriesItemLabelFont(100, font13);
        piePlot3D0.setLabelFont(font13);
        double double16 = piePlot3D0.getMaximumExplodePercent();
        piePlot3D0.setLabelLinksVisible(true);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = piePlot3D0.getLabelPadding();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        org.jfree.data.time.Year year21 = month20.getYear();
        java.awt.Stroke stroke22 = piePlot3D0.getSectionOutlineStroke((java.lang.Comparable) month20);
        java.util.Calendar calendar23 = null;
        try {
            month20.peg(calendar23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(year21);
        org.junit.Assert.assertNull(stroke22);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 0.0f);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer2 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean3 = xYAreaRenderer2.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator4 = null;
        xYAreaRenderer2.setLegendItemToolTipGenerator(xYSeriesLabelGenerator4);
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYAreaRenderer2.setSeriesStroke(3, stroke7);
        valueMarker1.setStroke(stroke7);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = valueMarker1.getLabelOffset();
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.lang.Class<?> wildcardClass14 = stroke13.getClass();
        java.io.InputStream inputStream15 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("java.awt.Color[r=0,g=192,b=192]", (java.lang.Class) wildcardClass14);
        java.net.URL uRL16 = org.jfree.chart.util.ObjectUtilities.getResource("{0}", (java.lang.Class) wildcardClass14);
        java.lang.Class class17 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        try {
            java.util.EventListener[] eventListenerArray18 = valueMarker1.getListeners(class17);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: [Lorg.jfree.data.time.Millisecond; cannot be cast to [Ljava.util.EventListener;");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNull(inputStream15);
        org.junit.Assert.assertNull(uRL16);
        org.junit.Assert.assertNotNull(class17);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Paint paint1 = xYAreaRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator2 = null;
        xYAreaRenderer0.setBaseItemLabelGenerator(xYItemLabelGenerator2, true);
        org.jfree.chart.urls.StandardXYURLGenerator standardXYURLGenerator7 = new org.jfree.chart.urls.StandardXYURLGenerator("0");
        try {
            xYAreaRenderer0.setSeriesURLGenerator((-1), (org.jfree.chart.urls.XYURLGenerator) standardXYURLGenerator7, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint1);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint2 = categoryAxis3D1.getLabelPaint();
        org.jfree.chart.JFreeChart jFreeChart3 = null;
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent6 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) categoryAxis3D1, jFreeChart3, (int) (short) 1, (int) (short) 10);
        java.awt.Paint paint8 = categoryAxis3D1.getTickLabelPaint((java.lang.Comparable) 0.5d);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer12 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean13 = xYAreaRenderer12.isOutline();
        java.awt.Shape shape14 = xYAreaRenderer12.getBaseShape();
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic16 = new org.jfree.chart.title.LegendGraphic(shape14, (java.awt.Paint) color15);
        legendGraphic16.setWidth((double) 8);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint((double) 2, (double) (byte) 1);
        org.jfree.chart.util.Size2D size2D23 = legendGraphic16.arrange(graphics2D19, rectangleConstraint22);
        double double24 = legendGraphic16.getHeight();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = legendGraphic16.getShapeLocation();
        java.awt.geom.Rectangle2D rectangle2D26 = legendGraphic16.getBounds();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean28 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge27);
        try {
            double double29 = categoryAxis3D1.getCategoryJava2DCoordinate(categoryAnchor9, (int) 'a', (int) '#', rectangle2D26, rectangleEdge27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(size2D23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleAnchor25);
        org.junit.Assert.assertNotNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint2 = categoryAxis3D1.getLabelPaint();
        categoryAxis3D1.setTickMarkInsideLength((float) 0);
        java.awt.Font font5 = categoryAxis3D1.getLabelFont();
        categoryAxis3D1.setCategoryMargin((double) 1L);
        java.awt.Paint paint8 = categoryAxis3D1.getLabelPaint();
        int int9 = categoryAxis3D1.getMaximumCategoryLabelLines();
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection11 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11, true);
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11, false);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot17 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis16);
        java.util.List list18 = combinedRangeXYPlot17.getSubplots();
        java.util.List list19 = combinedRangeXYPlot17.getSubplots();
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.iterateToFindDomainBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection11, list19, true);
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.util.RectangleEdge.RIGHT;
        try {
            double double24 = categoryAxis3D1.getCategoryMiddle((java.lang.Comparable) (-460), list19, rectangle2D22, rectangleEdge23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertNotNull(rectangleEdge23);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        int int4 = combinedDomainXYPlot3.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot3.rendererChanged(rendererChangeEvent6);
        combinedDomainXYPlot1.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot3);
        combinedDomainXYPlot3.setRangeGridlinesVisible(false);
        combinedDomainXYPlot3.mapDatasetToRangeAxis(100, 0);
        combinedDomainXYPlot3.setWeight(100);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        java.util.Locale locale2 = jFreeChartResources0.getLocale();
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertNull(locale2);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.data.DomainOrder domainOrder0 = org.jfree.data.DomainOrder.DESCENDING;
        org.junit.Assert.assertNotNull(domainOrder0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.Layer layer1 = null;
        java.util.Collection collection2 = categoryPlot0.getDomainMarkers(layer1);
        java.awt.Paint paint3 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer4 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        xYAreaRenderer4.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition6);
        boolean boolean8 = xYAreaRenderer4.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D9 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D9.centerRange((-1.0d));
        java.awt.Paint paint12 = numberAxis3D9.getTickLabelPaint();
        xYAreaRenderer4.setBaseFillPaint(paint12, true);
        categoryPlot0.setDomainCrosshairPaint(paint12);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot0.getDomainAxisEdge();
        org.junit.Assert.assertNull(collection2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("hi!");
        java.awt.Paint paint2 = categoryAxis3D1.getLabelPaint();
        categoryAxis3D1.setTickMarkInsideLength((float) 0);
        java.awt.Font font5 = categoryAxis3D1.getLabelFont();
        categoryAxis3D1.setCategoryMargin((double) 1L);
        java.awt.Paint paint8 = categoryAxis3D1.getLabelPaint();
        int int9 = categoryAxis3D1.getMaximumCategoryLabelLines();
        categoryAxis3D1.setUpperMargin((double) 100);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
        double[] doubleArray10 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[] doubleArray15 = new double[] { 0L, (byte) 0, (byte) 1, 1.0f };
        double[][] doubleArray16 = new double[][] { doubleArray10, doubleArray15 };
        org.jfree.data.category.CategoryDataset categoryDataset17 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("NO_CHANGE", "0", doubleArray16);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity20 = new org.jfree.chart.entity.CategoryItemEntity(shape1, "", "item", categoryDataset17, (java.lang.Comparable) "item", (java.lang.Comparable) "0");
        java.lang.Object obj21 = categoryItemEntity20.clone();
        java.lang.Comparable comparable22 = categoryItemEntity20.getColumnKey();
        java.lang.String str23 = categoryItemEntity20.getShapeType();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(categoryDataset17);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + "0" + "'", comparable22.equals("0"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "poly" + "'", str23.equals("poly"));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer0 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = null;
        xYAreaRenderer0.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition2);
        boolean boolean4 = xYAreaRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D5.centerRange((-1.0d));
        java.awt.Paint paint8 = numberAxis3D5.getTickLabelPaint();
        xYAreaRenderer0.setBaseFillPaint(paint8, true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor11 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.jfree.data.Range range12 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double13 = range12.getLength();
        boolean boolean14 = itemLabelAnchor11.equals((java.lang.Object) double13);
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor11, textAnchor15);
        double double17 = itemLabelPosition16.getAngle();
        xYAreaRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition16, false);
        java.awt.Paint paint20 = xYAreaRenderer0.getBaseLegendTextPaint();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation21 = null;
        org.jfree.chart.util.Layer layer22 = null;
        try {
            xYAreaRenderer0.addAnnotation(xYAnnotation21, layer22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(itemLabelAnchor11);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNull(paint20);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.plot.PiePlot3D piePlot3D0 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator1 = null;
        piePlot3D0.setLabelGenerator(pieSectionLabelGenerator1);
        piePlot3D0.setShadowXOffset(0.0d);
        piePlot3D0.setCircular(true);
        java.awt.Font font7 = piePlot3D0.getLabelFont();
        java.awt.Shape shape8 = piePlot3D0.getLegendItemShape();
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Stroke stroke1 = categoryPlot0.getRangeMinorGridlineStroke();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer2 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        xYAreaRenderer2.setBaseOutlineStroke(stroke3);
        categoryPlot0.setRangeCrosshairStroke(stroke3);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor7 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.axis.NumberTick numberTick9 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (short) 10, "series", textAnchor6, textAnchor7, (double) (short) 10);
        org.jfree.chart.text.TextAnchor textAnchor10 = numberTick9.getRotationAnchor();
        try {
            java.awt.geom.Rectangle2D rectangle2D11 = org.jfree.chart.text.TextUtilities.drawAlignedString("", graphics2D1, (float) (byte) 0, (float) 3600000L, textAnchor10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(textAnchor7);
        org.junit.Assert.assertNotNull(textAnchor10);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month1.next();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month3.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month3.next();
        org.jfree.chart.axis.PeriodAxis periodAxis6 = new org.jfree.chart.axis.PeriodAxis("java.awt.Color[r=255,g=128,b=128]", regularTimePeriod2, regularTimePeriod5);
        float float7 = periodAxis6.getMinorTickMarkInsideLength();
        int int8 = periodAxis6.getMinorTickCount();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.labels.XYToolTipGenerator xYToolTipGenerator1 = null;
        org.jfree.chart.urls.XYURLGenerator xYURLGenerator2 = null;
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer3 = new org.jfree.chart.renderer.xy.XYAreaRenderer((int) 'a', xYToolTipGenerator1, xYURLGenerator2);
        org.jfree.chart.plot.XYPlot xYPlot4 = xYAreaRenderer3.getPlot();
        org.junit.Assert.assertNull(xYPlot4);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.renderer.xy.XYLineAndShapeRenderer xYLineAndShapeRenderer0 = new org.jfree.chart.renderer.xy.XYLineAndShapeRenderer();
        xYLineAndShapeRenderer0.setUseOutlinePaint(true);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("RangeType.FULL");
        java.lang.String str2 = legendItem1.getURLText();
        java.lang.String str3 = legendItem1.getURLText();
        legendItem1.setShapeVisible(false);
        legendItem1.setDatasetIndex(0);
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries3.clear();
        timeSeries3.setDescription("series");
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = null;
        try {
            timeSeries3.add(timeSeriesDataItem9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedRangeXYPlot combinedRangeXYPlot1 = new org.jfree.chart.plot.CombinedRangeXYPlot(valueAxis0);
        double double2 = combinedRangeXYPlot1.getGap();
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot4 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis3);
        java.awt.Paint paint5 = combinedDomainXYPlot4.getBackgroundPaint();
        combinedRangeXYPlot1.addChangeListener((org.jfree.chart.event.PlotChangeListener) combinedDomainXYPlot4);
        org.jfree.data.xy.XYSeriesCollection xYSeriesCollection7 = new org.jfree.data.xy.XYSeriesCollection();
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection7, true);
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection7, false);
        int int12 = xYSeriesCollection7.getSeriesCount();
        org.jfree.data.Range range13 = org.jfree.data.general.DatasetUtilities.iterateRangeBounds((org.jfree.data.xy.XYDataset) xYSeriesCollection7);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D14.centerRange((-1.0d));
        java.awt.Paint paint17 = numberAxis3D14.getTickLabelPaint();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D18 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D18.setUpperMargin((double) (short) 0);
        numberAxis3D18.resizeRange2((double) 10L, (double) 12);
        numberAxis3D18.setAutoTickUnitSelection(false);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer26 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = null;
        xYAreaRenderer26.setSeriesNegativeItemLabelPosition((int) ' ', itemLabelPosition28);
        boolean boolean30 = xYAreaRenderer26.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D31.centerRange((-1.0d));
        java.awt.Paint paint34 = numberAxis3D31.getTickLabelPaint();
        xYAreaRenderer26.setBaseFillPaint(paint34, true);
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot((org.jfree.data.xy.XYDataset) xYSeriesCollection7, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, (org.jfree.chart.axis.ValueAxis) numberAxis3D18, (org.jfree.chart.renderer.xy.XYItemRenderer) xYAreaRenderer26);
        combinedRangeXYPlot1.add(xYPlot37, (int) 'a');
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = combinedRangeXYPlot1.getDomainAxisEdge(0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.0d + "'", double2 == 5.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNull(range11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(rectangleEdge41);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.time.TimeSeriesCollection timeSeriesCollection0 = new org.jfree.data.time.TimeSeriesCollection();
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (-1.0d), "series", "0");
        timeSeries4.clear();
        timeSeries4.setDescription("series");
        int int8 = timeSeriesCollection0.indexOf(timeSeries4);
        org.jfree.data.Range range9 = org.jfree.data.general.DatasetUtilities.findDomainBounds((org.jfree.data.xy.XYDataset) timeSeriesCollection0);
        java.lang.Object obj10 = timeSeriesCollection0.clone();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(range9);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.centerRange((-1.0d));
        java.awt.Paint paint3 = numberAxis3D0.getTickLabelPaint();
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double5 = range4.getLength();
        numberAxis3D0.setRangeWithMargins(range4, false, false);
        boolean boolean9 = numberAxis3D0.isAxisLineVisible();
        java.lang.Object obj10 = numberAxis3D0.clone();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.axis.ValueAxis valueAxis0 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot1 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis0);
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.plot.CombinedDomainXYPlot combinedDomainXYPlot3 = new org.jfree.chart.plot.CombinedDomainXYPlot(valueAxis2);
        int int4 = combinedDomainXYPlot3.getBackgroundImageAlignment();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) ' ');
        combinedDomainXYPlot3.rendererChanged(rendererChangeEvent6);
        combinedDomainXYPlot1.remove((org.jfree.chart.plot.XYPlot) combinedDomainXYPlot3);
        int int9 = combinedDomainXYPlot3.getDatasetCount();
        org.jfree.chart.axis.NumberAxis3D numberAxis3D10 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D10.centerRange((-1.0d));
        java.awt.Paint paint13 = numberAxis3D10.getTickLabelPaint();
        float float14 = numberAxis3D10.getTickMarkInsideLength();
        int int15 = combinedDomainXYPlot3.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis3D10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 15 + "'", int4 == 15);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement4 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment0, verticalAlignment1, (double) (byte) 1, (double) 100.0f);
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement4);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment6 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment7 = null;
        org.jfree.chart.block.FlowArrangement flowArrangement10 = new org.jfree.chart.block.FlowArrangement(horizontalAlignment6, verticalAlignment7, (double) (byte) 1, (double) 100.0f);
        org.jfree.chart.block.BlockContainer blockContainer11 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) flowArrangement10);
        org.jfree.chart.plot.PiePlot3D piePlot3D12 = new org.jfree.chart.plot.PiePlot3D();
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator13 = null;
        piePlot3D12.setLabelGenerator(pieSectionLabelGenerator13);
        piePlot3D12.setShadowXOffset(0.0d);
        piePlot3D12.setIgnoreZeroValues(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = piePlot3D12.getSimpleLabelOffset();
        blockContainer11.setPadding(rectangleInsets19);
        java.lang.Object obj21 = blockContainer11.clone();
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer22 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean23 = xYAreaRenderer22.isOutline();
        java.awt.Shape shape24 = xYAreaRenderer22.getBaseShape();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.jfree.chart.title.LegendGraphic legendGraphic26 = new org.jfree.chart.title.LegendGraphic(shape24, (java.awt.Paint) color25);
        legendGraphic26.setWidth((double) 8);
        org.jfree.chart.renderer.xy.XYAreaRenderer xYAreaRenderer29 = new org.jfree.chart.renderer.xy.XYAreaRenderer();
        boolean boolean30 = xYAreaRenderer29.isOutline();
        org.jfree.chart.labels.XYSeriesLabelGenerator xYSeriesLabelGenerator31 = null;
        xYAreaRenderer29.setLegendItemToolTipGenerator(xYSeriesLabelGenerator31);
        java.awt.Paint paint34 = xYAreaRenderer29.getSeriesPaint(2);
        org.jfree.chart.labels.XYItemLabelGenerator xYItemLabelGenerator36 = xYAreaRenderer29.getSeriesItemLabelGenerator(10);
        boolean boolean37 = xYAreaRenderer29.getBaseItemLabelsVisible();
        java.awt.Shape shape39 = xYAreaRenderer29.lookupLegendShape(3);
        legendGraphic26.setShape(shape39);
        blockContainer11.add((org.jfree.chart.block.Block) legendGraphic26);
        java.lang.Object obj42 = null;
        flowArrangement4.add((org.jfree.chart.block.Block) blockContainer11, obj42);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(paint34);
        org.junit.Assert.assertNull(xYItemLabelGenerator36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(shape39);
    }
}

