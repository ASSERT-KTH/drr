
import junit.framework.*;

public class RandoopTest0 extends TestCase {

  public static boolean debug = false;

  public void test1() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test1"); }


    double[] var0 = new double[] { };
    double var1 = org.apache.commons.math3.util.MathArrays.safeNorm(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var0);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);

  }

  public void test2() {}
//   public void test2() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test2"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     double[] var1 = null;
//     double[] var2 = null;
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var3 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var0, var1, var2);
// 
//   }

  public void test3() {}
//   public void test3() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test3"); }
// 
// 
//     long[][] var0 = null;
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var0);
// 
//   }

  public void test4() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test4"); }


    double[] var1 = new double[] { 1.0d};
    double[] var2 = new double[] { };
    double var3 = org.apache.commons.math3.util.MathArrays.safeNorm(var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var4 = org.apache.commons.math3.util.MathArrays.ebeAdd(var1, var2);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);

  }

  public void test5() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test5"); }


    double[] var3 = new double[] { 0.0d, (-1.0d), 1.0d};
    double[] var4 = new double[] { };
    double var5 = org.apache.commons.math3.util.MathArrays.safeNorm(var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = org.apache.commons.math3.util.MathArrays.distance(var3, var4);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);

  }

  public void test6() {}
//   public void test6() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test6"); }
// 
// 
//     java.util.List var0 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var1 = new org.apache.commons.math3.distribution.DiscreteDistribution(var0);
// 
//   }

  public void test7() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test7"); }


    double[] var2 = new double[] { (-1.0d), 100.0d};
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    double[] var4 = new double[] { };
    double var5 = org.apache.commons.math3.util.MathArrays.safeNorm(var4);
    double[][] var6 = new double[][] { var4};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.sortInPlace(var2, var3, var6);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test8() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test8"); }


    double[] var0 = new double[] { };
    double var1 = org.apache.commons.math3.util.MathArrays.safeNorm(var0);
    double[] var2 = new double[] { };
    double var3 = org.apache.commons.math3.util.MathArrays.safeNorm(var2);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var4 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var0, var2);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 0.0d);

  }

  public void test9() {}
//   public void test9() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test9"); }
// 
// 
//     int[] var0 = new int[] { };
//     int[] var1 = null;
//     int var2 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var1);
//     int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 1);
// 
//   }

  public void test10() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test10"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var3 = var0.nextPascal(10, 100.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }

  }

  public void test11() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test11"); }


    double[] var0 = new double[] { };
    double var1 = org.apache.commons.math3.util.MathArrays.safeNorm(var0);
    double[] var2 = new double[] { };
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = org.apache.commons.math3.util.MathArrays.linearCombination(var0, var2);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test12() {}
//   public void test12() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test12"); }
// 
// 
//     int[] var0 = new int[] { };
//     int[] var1 = null;
//     int var2 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var1);
//     int[] var5 = new int[] { 1, 100};
//     double var6 = org.apache.commons.math3.util.MathArrays.distance(var1, var5);
// 
//   }

  public void test13() {}
//   public void test13() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test13"); }
// 
// 
//     int[] var0 = new int[] { };
//     int[] var1 = null;
//     int var2 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var1);
//     int[] var4 = org.apache.commons.math3.util.MathArrays.copyOf(var1, 63);
// 
//   }

  public void test14() {}
//   public void test14() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test14"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     var1.clear();
//     double[] var6 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var10 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var11 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var6, var10);
//     double[] var12 = null;
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var13 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var6, var12);
// 
//   }

  public void test15() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test15"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSecureAlgorithm("hi!", "hi!");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);

  }

  public void test16() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test16"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var5 = var2.nextPermutation(10, 63);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test17() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test17"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var8 = var2.nextSecureLong(0L, 0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);

  }

  public void test18() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test18"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var2.nextBeta((-0.6044871530760823d), 100.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
    } catch (org.apache.commons.math3.exception.NoBracketingException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);

  }

  public void test19() {}
//   public void test19() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test19"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     java.lang.Object[] var3 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError(var1, var3);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var5 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var3);
//     org.apache.commons.math3.exception.NullArgumentException var6 = new org.apache.commons.math3.exception.NullArgumentException();
//     var5.addSuppressed((java.lang.Throwable)var6);
//     java.lang.String var8 = var5.toString();
// 
//   }

  public void test20() {}
//   public void test20() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test20"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGaussian(0.0d, 10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextPascal(62, 8.884353152082793d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.6639526855402442d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "b68a0ac99c83e35dd1a1f3afbb7a983d90d798c12902bf34edcb3836942b9adc3c449b7f0892582b3a08398"+ "'", var8.equals("b68a0ac99c83e35dd1a1f3afbb7a983d90d798c12902bf34edcb3836942b9adc3c449b7f0892582b3a08398"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 7.006152518306231d);
// 
//   }

  public void test21() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test21"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var2.nextExponential((-6.755317488693713d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test22() {}
//   public void test22() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test22"); }
// 
// 
//     double[] var0 = null;
//     double[] var1 = org.apache.commons.math3.util.MathArrays.copyOf(var0);
// 
//   }

  public void test23() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test23"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var6 = var2.nextBinomial(37, 7.500930705661022d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }

  }

  public void test24() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test24"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, 5.2935374176612715d, (-1.0d), 100.0d, 0.0d, 7.500930705661022d, 100.0d, 100.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 9900.0d);

  }

  public void test25() {}
//   public void test25() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test25"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(100.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var5 = var0.nextBeta((-1.0d), (-0.6081402879038607d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 77.9367391301058d);
// 
//   }

  public void test26() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test26"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var3 = var0.nextSecureLong(100L, 0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test27() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test27"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var8 = var2.nextZipf(1, (-0.14097693123713528d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);

  }

  public void test28() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test28"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var2.nextWeibull((-0.14097693123713528d), 8.884353152082793d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);

  }

  public void test29() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test29"); }


    double[] var2 = new double[] { 0.0d, 1.0d};
    double[] var3 = new double[] { };
    double var4 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = org.apache.commons.math3.util.MathArrays.distance1(var2, var3);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.0d);

  }

  public void test30() {}
//   public void test30() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test30"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var6 = var0.nextUniform(0.31568577999507896d, 0.1431715674774945d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 81);
// 
//   }

  public void test31() {}
//   public void test31() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test31"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var7, var9, true);
// 
//   }

  public void test32() {}
//   public void test32() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test32"); }
// 
// 
//     int[] var0 = new int[] { };
//     int[] var1 = null;
//     int var2 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var1);
//     int[] var3 = new int[] { };
//     int[] var4 = null;
//     int var5 = org.apache.commons.math3.util.MathArrays.distanceInf(var3, var4);
//     int[] var6 = new int[] { };
//     int[] var7 = null;
//     int var8 = org.apache.commons.math3.util.MathArrays.distanceInf(var6, var7);
//     int var9 = org.apache.commons.math3.util.MathArrays.distanceInf(var3, var7);
//     int var10 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var3);
// 
//   }

  public void test33() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test33"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var2.nextCauchy((-0.9438041885292305d), (-0.32577132027868605d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test34() {}
//   public void test34() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test34"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextBinomial(33, 21.869847397459292d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.3999037564769137d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "ebfcf008f6e0d5ad6e5c72a7e55d2b4735765d8c8ecdc9f275cbf7b904035eece5df062d5186ae0e3144d9a"+ "'", var8.equals("ebfcf008f6e0d5ad6e5c72a7e55d2b4735765d8c8ecdc9f275cbf7b904035eece5df062d5186ae0e3144d9a"));
// 
//   }

  public void test35() {}
//   public void test35() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test35"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGaussian(0.0d, 10.0d);
//     double var13 = var0.nextExponential(0.1431715674774945d);
//     java.util.Collection var14 = null;
//     java.lang.Object[] var16 = var0.nextSample(var14, 18);
// 
//   }

  public void test36() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test36"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var8 = var2.nextBinomial(10, 10.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);

  }

  public void test37() {}
//   public void test37() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test37"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGamma(103.56915419683993d, 0.20851425337288942d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextBinomial(10, (-0.9438041885292305d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.7604112137419752d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "a8f9b3c5d5914799097c267f2ed91f9509f8a0b8091a814cef7e0d5238e33fc84b84720686024e93d4e99ed"+ "'", var8.equals("a8f9b3c5d5914799097c267f2ed91f9509f8a0b8091a814cef7e0d5238e33fc84b84720686024e93d4e99ed"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 18.523683638934422d);
// 
//   }

  public void test38() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test38"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var2.nextChiSquare(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);

  }

  public void test39() {}
//   public void test39() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test39"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var0.nextChiSquare(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.01844268008124672d));
// 
//   }

  public void test40() {}
//   public void test40() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test40"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextCauchy((-0.6044871530760823d), 5.704309058613993d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var0.nextBinomial(18, (-679.7841048171373d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-5.419604433756458d));
// 
//   }

  public void test41() {}
//   public void test41() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test41"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGamma(103.56915419683993d, 0.20851425337288942d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var0.nextT(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.8024580898427272d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "92bbdc1b8e4b67e18b8b0bd41c020cd57319c1bb7862675fd483697e17c08c130ec91a43ac5077247ad68f9"+ "'", var8.equals("92bbdc1b8e4b67e18b8b0bd41c020cd57319c1bb7862675fd483697e17c08c130ec91a43ac5077247ad68f9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 21.306570958008987d);
// 
//   }

  public void test42() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test42"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var6 = var2.nextSecureLong(7L, 0L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test43() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test43"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    boolean var5 = var3.getStrict();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);

  }

  public void test44() {}
//   public void test44() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test44"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.util.Collection var7 = null;
//     java.lang.Object[] var9 = var6.nextSample(var7, 10);
// 
//   }

  public void test45() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test45"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { 0.0d};
    org.apache.commons.math3.exception.NotFiniteNumberException var4 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)1L, var3);
    java.lang.Number var5 = var4.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1L+ "'", var5.equals(1L));

  }

  public void test46() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test46"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    double[] var22 = new double[] { 0.0d};
    org.apache.commons.math3.util.MathArrays.OrderDirection var23 = null;
    boolean var25 = org.apache.commons.math3.util.MathArrays.isMonotonic(var22, var23, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var26 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var20, var22);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);

  }

  public void test47() {}
//   public void test47() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test47"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     java.util.List var1 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var2 = new org.apache.commons.math3.distribution.DiscreteDistribution(var0, var1);
// 
//   }

  public void test48() {}
//   public void test48() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test48"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var6 = var0.nextWeibull(0.0d, 7.500930705661022d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 62);
// 
//   }

  public void test49() {}
//   public void test49() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test49"); }
// 
// 
//     int[] var0 = new int[] { };
//     int[] var1 = null;
//     int var2 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var1);
//     int[] var3 = org.apache.commons.math3.util.MathArrays.copyOf(var1);
// 
//   }

  public void test50() {}
//   public void test50() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test50"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform(5.2935374176612715d, 10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var6 = var0.nextGamma(0.0d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 7.406686212373884d);
// 
//   }

  public void test51() {}
//   public void test51() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test51"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var4 = var0.nextUniform((-1.0d), 10.0d, false);
//     int var7 = var0.nextInt(0, 100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextBinomial(87, 3.367537023715106d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 3.4456662458668434d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 48);
// 
//   }

  public void test52() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test52"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var20);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);

  }

  public void test53() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test53"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    int[] var7 = new int[] { };
    int[] var8 = null;
    int var9 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = org.apache.commons.math3.util.MathArrays.distanceInf(var5, var7);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 0);

  }

  public void test54() {}
//   public void test54() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test54"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var4 = var1.nextInt(10, 100);
//     double var6 = var1.nextExponential(10.0d);
//     org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)"255737ca0aa76cd64c486046c09bb4241de9d17d6a15fad4cb3ac04c20bfb9ce320daaebb6e9d68f18f5234", (java.lang.Object)var1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var9 = var1.nextPoisson((-0.9286380078653282d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 84);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.555965034732264d);
// 
//   }

  public void test55() {}
//   public void test55() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test55"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     long var3 = var0.nextSecureLong(0L, 10L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var0.nextUniform((-0.6851952826289146d), (-0.6851952826289146d), false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9L);
// 
//   }

  public void test56() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test56"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination((-0.32577132027868605d), 0.407741687198951d, (-0.14097693123713528d), (-30.443553573156947d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 4.1590082109255295d);

  }

  public void test57() {}
//   public void test57() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test57"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
//     double[] var13 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var17 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var18 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var13, var17);
//     double[] var19 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var8, var17);
//     double[] var20 = org.apache.commons.math3.util.MathArrays.ebeDivide(var0, var8);
// 
//   }

  public void test58() {}
//   public void test58() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test58"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextBeta(0.0d, 3.367537023715106d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.15907047612299507d);
// 
//   }

  public void test59() {}
//   public void test59() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test59"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     double var6 = var2.nextUniform(0.012774969105543068d, 21.869847397459292d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var2.nextChiSquare((-0.9286380078653282d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 12.026869142034565d);
// 
//   }

  public void test60() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test60"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var2.nextF((-0.9899264537631861d), 0.4301403036978695d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test61() {}
//   public void test61() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test61"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var6 = var0.nextHypergeometric(20, 20, 100);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-28.74058653893555d));
// 
//   }

  public void test62() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test62"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(0, 1);
    org.apache.commons.math3.exception.util.ExceptionContext var3 = var2.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test63() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test63"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(4.847943602659273d, 0.5684335790811075d, 6.813639406926573E-7d, 0.6862627241836179d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 2.755734400837643d);

  }

  public void test64() {}
//   public void test64() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test64"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
//     boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
//     double[] var14 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var18 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var19 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var14, var18);
//     double[] var23 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var27 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var28 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var23, var27);
//     double[] var29 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var18, var27);
//     double var30 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var29);
// 
//   }

  public void test65() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test65"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathIllegalArgumentException var2 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var1);

  }

  public void test66() {}
//   public void test66() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test66"); }
// 
// 
//     int[] var0 = new int[] { };
//     int[] var1 = null;
//     int var2 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var1);
//     int[] var3 = null;
//     double var4 = org.apache.commons.math3.util.MathArrays.distance(var1, var3);
// 
//   }

  public void test67() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test67"); }


    double[] var2 = new double[] { 1.0d, (-1.0d)};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var2);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test68() {}
//   public void test68() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test68"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var0.nextChiSquare((-679.7841048171373d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.03668680474044583d);
// 
//   }

  public void test69() {}
//   public void test69() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test69"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
//     double[] var13 = new double[] { 10.0d, (-1.0d), (-1.0d)};
//     double var14 = org.apache.commons.math3.util.MathArrays.safeNorm(var13);
//     double[][] var15 = new double[][] { var13};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var15);
//     double var17 = org.apache.commons.math3.util.MathArrays.linearCombination(var0, var4);
// 
//   }

  public void test70() {}
//   public void test70() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test70"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     java.lang.Object[] var3 = new java.lang.Object[] { 0.0d};
//     org.apache.commons.math3.exception.NotFiniteNumberException var4 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)1L, var3);
//     org.apache.commons.math3.exception.util.Localizable var5 = null;
//     double[] var9 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var13 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var14 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var9, var13);
//     double[] var18 = new double[] { 10.0d, (-1.0d), (-1.0d)};
//     double var19 = org.apache.commons.math3.util.MathArrays.safeNorm(var18);
//     double[][] var20 = new double[][] { var18};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var9, var20);
//     org.apache.commons.math3.exception.MathIllegalStateException var22 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var4, var5, (java.lang.Object[])var20);
// 
//   }

  public void test71() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test71"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    var2.reSeedSecure(100L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var10 = var2.nextPascal(17, 100.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);

  }

  public void test72() {}
//   public void test72() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test72"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     int var5 = var0.nextSecureInt((-1), 33);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var0.nextUniform(0.012774969105543068d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 4.859066663864139E9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 19);
// 
//   }

  public void test73() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test73"); }


    int[] var2 = new int[] { (-1), 100};
    int[] var3 = new int[] { };
    int[] var4 = null;
    int var5 = org.apache.commons.math3.util.MathArrays.distanceInf(var3, var4);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = org.apache.commons.math3.util.MathArrays.distance(var2, var3);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 0);

  }

  public void test74() {}
//   public void test74() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test74"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextHypergeometric(0, 88, 100);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 91);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.9928822359157303d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.5901610096892388d);
// 
//   }

  public void test75() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test75"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var5 = var2.nextWeibull((-6.755317488693713d), 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test76() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test76"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    var2.reSeedSecure(100L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var2.nextGamma((-3.672203955332186d), 357.60346728709703d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);

  }

  public void test77() {}
//   public void test77() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test77"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var4 = var1.nextInt(10, 100);
//     double var6 = var1.nextExponential(10.0d);
//     org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)"255737ca0aa76cd64c486046c09bb4241de9d17d6a15fad4cb3ac04c20bfb9ce320daaebb6e9d68f18f5234", (java.lang.Object)var1);
//     double var9 = var1.nextT(223.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var1.nextGamma(103.56915419683993d, (-0.6081402879038607d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 7.120450318686301d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1.0283047675189432d);
// 
//   }

  public void test78() {}
//   public void test78() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test78"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 11);
// 
//   }

  public void test79() {}
//   public void test79() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test79"); }
// 
// 
//     double[] var0 = null;
//     org.apache.commons.math3.util.MathArrays.OrderDirection var1 = null;
//     boolean var4 = org.apache.commons.math3.util.MathArrays.checkOrder(var0, var1, false, false);
// 
//   }

  public void test80() {}
//   public void test80() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test80"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextInt(47, 20);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.6547895399373167d);
// 
//   }

  public void test81() {}
//   public void test81() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test81"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var9 = var0.nextLong(100L, 10L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.4067613356605633d);
// 
//   }

  public void test82() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test82"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure(100L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var2.setSecureAlgorithm("org.apache.commons.math3.exception.NonMonotonicSequenceException: points -1 and 0 are not strictly increasing (0 >= -1)", "hi!");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }

  }

  public void test83() {}
//   public void test83() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test83"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var0.nextPascal(62, 103.56915419683993d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.477245204170444d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
// 
//   }

  public void test84() {}
//   public void test84() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test84"); }
// 
// 
//     double[] var0 = null;
//     double[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 29);
// 
//   }

  public void test85() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test85"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure(100L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var8 = var2.nextHypergeometric(33, 61, 20);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test86() {}
//   public void test86() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test86"); }
// 
// 
//     double[] var3 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var7 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var11 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var12 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var7, var11);
//     double var13 = org.apache.commons.math3.util.MathArrays.distance1(var3, var12);
//     double[] var15 = org.apache.commons.math3.util.MathArrays.normalizeArray(var12, 0.0d);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var16 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var15, var16, false);
// 
//   }

  public void test87() {}
//   public void test87() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test87"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var4 = var1.nextInt(10, 100);
//     double var6 = var1.nextExponential(10.0d);
//     org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)"255737ca0aa76cd64c486046c09bb4241de9d17d6a15fad4cb3ac04c20bfb9ce320daaebb6e9d68f18f5234", (java.lang.Object)var1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var1.setSecureAlgorithm("4aef77955efc5b0bc3300497959bc61645d4a4ca8178aab7cec873b660bb4d250eb034dfd6c7255912c7b14", "3329d70073c313b2f0af69933b74885275e6f91de302adec32fc3d338cfd2dcd3c4a43f6485991eb3e9bd92");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4.689401872454838d);
// 
//   }

  public void test88() {}
//   public void test88() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test88"); }
// 
// 
//     double[] var3 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var7 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var11 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var12 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var7, var11);
//     double var13 = org.apache.commons.math3.util.MathArrays.distance1(var3, var12);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var14 = null;
//     boolean var16 = org.apache.commons.math3.util.MathArrays.isMonotonic(var3, var14, true);
// 
//   }

  public void test89() {}
//   public void test89() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test89"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     java.lang.String var6 = var0.nextSecureHexString(88);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var0.nextZipf(52, (-0.32577132027868605d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-2.0524197082274753d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "e2890fb9f97790d25af9d7"+ "'", var4.equals("e2890fb9f97790d25af9d7"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "ab1917613decc6e2083a01f402f636b2b0538049fac3209e54a4b8f944aaf5000405f9f3e174e921fbb77510"+ "'", var6.equals("ab1917613decc6e2083a01f402f636b2b0538049fac3209e54a4b8f944aaf5000405f9f3e174e921fbb77510"));
// 
//   }

  public void test90() {}
//   public void test90() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test90"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var7 = var0.nextLong(10L, (-1L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-42740.062563715546d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "97a07fa4f9a4bd6942fe75"+ "'", var4.equals("97a07fa4f9a4bd6942fe75"));
// 
//   }

  public void test91() {}
//   public void test91() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test91"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
//     boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
//     double var11 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var12 = null;
//     boolean var15 = org.apache.commons.math3.util.MathArrays.checkOrder(var8, var12, true, true);
// 
//   }

  public void test92() {}
//   public void test92() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test92"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     double[] var12 = new double[] { 10.0d, (-1.0d), (-1.0d)};
//     double var13 = org.apache.commons.math3.util.MathArrays.safeNorm(var12);
//     double[][] var14 = new double[][] { var12};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var3, var14);
//     double var16 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
//     double[] var20 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var24 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var28 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var29 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var24, var28);
//     double var30 = org.apache.commons.math3.util.MathArrays.distance1(var20, var29);
//     double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 88);
//     double[] var33 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var3, var29);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var34 = null;
//     boolean var37 = org.apache.commons.math3.util.MathArrays.checkOrder(var3, var34, true, true);
// 
//   }

  public void test93() {}
//   public void test93() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test93"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     int var5 = var0.nextSecureInt((-1), 33);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var0.nextHypergeometric(0, 0, 1);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 126.97383987173268d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 13);
// 
//   }

  public void test94() {}
//   public void test94() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test94"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     double var6 = var2.nextUniform(0.012774969105543068d, 21.869847397459292d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var2.nextBeta(2.755734400837643d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.3192683733742615d);
// 
//   }

  public void test95() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test95"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var2 = null;
    org.apache.commons.math3.exception.NotFiniteNumberException var3 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)1.4387505701387593d, var2);

  }

  public void test96() {}
//   public void test96() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test96"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var12 = var9.nextInt(10, 100);
//     double var15 = var9.nextUniform((-1.0d), 1.0d);
//     var9.reSeedSecure();
//     org.apache.commons.math3.util.Pair var17 = new org.apache.commons.math3.util.Pair((java.lang.Object)var8, (java.lang.Object)var9);
//     double[] var18 = null;
//     double[] var22 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var26 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var27 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var22, var26);
//     boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var18, var26);
//     double var29 = org.apache.commons.math3.util.MathArrays.linearCombination(var8, var18);
// 
//   }

  public void test97() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test97"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var2 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError(var0, var2);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test98() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test98"); }


    java.lang.Object var1 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)(-1), var1);
    java.lang.Object var3 = var2.getSecond();
    java.lang.Object var4 = var2.getKey();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (short)(-1)+ "'", var4.equals((short)(-1)));

  }

  public void test99() {}
//   public void test99() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test99"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextCauchy((-0.6044871530760823d), 5.704309058613993d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var0.nextPascal(0, (-0.32577132027868605d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-2272.7269602768583d));
// 
//   }

  public void test100() {}
//   public void test100() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test100"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var12 = var9.nextInt(10, 100);
//     double var15 = var9.nextUniform((-1.0d), 1.0d);
//     var9.reSeedSecure();
//     org.apache.commons.math3.util.Pair var17 = new org.apache.commons.math3.util.Pair((java.lang.Object)var8, (java.lang.Object)var9);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var20 = var9.nextPermutation(78, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 100);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.7071865381663494d);
// 
//   }

  public void test101() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test101"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var6 = var2.nextPermutation(99, 0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test102() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test102"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var19 = null;
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var16, var19);
    double[] var24 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var28 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var32 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var28, var32);
    double var34 = org.apache.commons.math3.util.MathArrays.distance1(var24, var33);
    boolean var35 = org.apache.commons.math3.util.MathArrays.equals(var16, var24);
    double[] var39 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var43 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var47 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var48 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var43, var47);
    double var49 = org.apache.commons.math3.util.MathArrays.distance1(var39, var48);
    double[] var51 = org.apache.commons.math3.util.MathArrays.copyOf(var48, 88);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var52 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var24, var51);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var35 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);

  }

  public void test103() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test103"); }


    double[] var0 = null;
    double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
    boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var8);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);

  }

  public void test104() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test104"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure(100L);
    var2.reSeedSecure(1L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var9 = var2.nextLong(108L, (-1L));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test105() {}
//   public void test105() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test105"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var6 = var0.nextPermutation(100, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 95);
// 
//   }

  public void test106() {}
//   public void test106() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test106"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     java.util.Collection var2 = null;
//     java.lang.Object[] var4 = var1.nextSample(var2, 53);
// 
//   }

  public void test107() {}
//   public void test107() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test107"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextBeta(2.923657016815099d, (-1.2058173601229263d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 98);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 21.610997188985493d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.38465633197830984d);
// 
//   }

  public void test108() {}
//   public void test108() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test108"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 0);
// 
//   }

  public void test109() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test109"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination((-19533.05988397774d), 0.0d, 10.0d, (-0.6001566413360179d), (-0.6851952826289146d), (-679.7841048171373d), 5.704309058613993d, (-0.8782782965603144d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 454.7733245704089d);

  }

  public void test110() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test110"); }


    double[] var0 = new double[] { };
    double var1 = org.apache.commons.math3.util.MathArrays.safeNorm(var0);
    double[] var3 = new double[] { 0.0d};
    org.apache.commons.math3.util.MathArrays.OrderDirection var4 = null;
    boolean var6 = org.apache.commons.math3.util.MathArrays.isMonotonic(var3, var4, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var3);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var8 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var0, var3);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var1 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == true);

  }

  public void test111() {}
//   public void test111() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test111"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var9 = var0.nextPermutation(61, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.1546712570479456d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.682186322627748E-4d);
// 
//   }

  public void test112() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test112"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    var2.reSeed((-1L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var10 = var2.nextSecureLong(8026008374386375277L, 108L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);

  }

  public void test113() {}
//   public void test113() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test113"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 52, 18);
// 
//   }

  public void test114() {}
//   public void test114() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test114"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 33);
// 
//   }

  public void test115() {}
//   public void test115() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test115"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     var0.reSeed((-1L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var9 = var0.nextPoisson((-19533.05988397774d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.44588712927659024d);
// 
//   }

  public void test116() {}
//   public void test116() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test116"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var8 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var12 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var13 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var8, var12);
//     double var14 = org.apache.commons.math3.util.MathArrays.distance1(var4, var13);
//     double[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var13, 88);
//     double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var0, var13);
// 
//   }

  public void test117() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test117"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(5.2935374176612715d, 1.487086298741032E-9d, (-6.755317488693713d), 1.327000036267693d, 6.813639406926573E-7d, (-19533.05988397774d), 0.0d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-8.977615667280723d));

  }

  public void test118() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test118"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
    java.lang.Object[] var5 = new java.lang.Object[] { true};
    org.apache.commons.math3.exception.MathIllegalStateException var6 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var5);
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var6.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test119() {}
//   public void test119() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test119"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     org.apache.commons.math3.distribution.IntegerDistribution var6 = null;
//     int var7 = var0.nextInversionDeviate(var6);
// 
//   }

  public void test120() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test120"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 61, 20);
    int var4 = var3.getDimension();
    java.lang.Number var5 = var3.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 61+ "'", var5.equals(61));

  }

  public void test121() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test121"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination((-0.9286380078653282d), (-6.755317488693713d), (-0.19811647941323907d), 0.10832690038004085d, 0.0d, 0.026649323194479716d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 6.251783231069299d);

  }

  public void test122() {}
//   public void test122() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test122"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.012774969105543068d, 0.09455763871444445d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var0.nextBinomial(20, (-0.01516979083120098d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 4.177575470302021d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
// 
//   }

  public void test123() {}
//   public void test123() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test123"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     var0.reSeed();
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var0.nextInt(62, 29);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.22610132882977307d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.18233592668342705d);
// 
//   }

  public void test124() {}
//   public void test124() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test124"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
//     double var18 = org.apache.commons.math3.util.MathArrays.distance1(var8, var12);
//     double[] var19 = null;
//     double[] var23 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var27 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var28 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var23, var27);
//     boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var19, var27);
//     double var30 = org.apache.commons.math3.util.MathArrays.safeNorm(var27);
//     double[] var34 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var38 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var39 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var34, var38);
//     double[] var40 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var27, var34);
//     boolean var41 = org.apache.commons.math3.util.MathArrays.equals(var12, var34);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var42 = null;
//     boolean var44 = org.apache.commons.math3.util.MathArrays.isMonotonic(var34, var42, true);
// 
//   }

  public void test125() {}
//   public void test125() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test125"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextBinomial(99, (-0.04382736477013571d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.7224456267861283d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "a2facd9f040b66c6b2fc9376ad49fd693d8407f91e9f13519713b6124fd139057cc709de103ad1ec5cd144d"+ "'", var8.equals("a2facd9f040b66c6b2fc9376ad49fd693d8407f91e9f13519713b6124fd139057cc709de103ad1ec5cd144d"));
// 
//   }

  public void test126() {}
//   public void test126() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test126"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     java.lang.String var5 = var0.nextHexString(87);
//     java.util.Collection var6 = null;
//     java.lang.Object[] var8 = var0.nextSample(var6, 0);
// 
//   }

  public void test127() {}
//   public void test127() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test127"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
//     double[] var13 = new double[] { 10.0d, (-1.0d), (-1.0d)};
//     double var14 = org.apache.commons.math3.util.MathArrays.safeNorm(var13);
//     double[][] var15 = new double[][] { var13};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var15);
//     double var17 = org.apache.commons.math3.util.MathArrays.safeNorm(var4);
//     double[] var21 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var25 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var29 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var30 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var25, var29);
//     double var31 = org.apache.commons.math3.util.MathArrays.distance1(var21, var30);
//     double[] var33 = org.apache.commons.math3.util.MathArrays.copyOf(var30, 88);
//     double[] var34 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var4, var30);
//     double[] var35 = org.apache.commons.math3.util.MathArrays.ebeAdd(var0, var30);
// 
//   }

  public void test128() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test128"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var6 = var2.nextSecureInt(96, 83);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test129() {}
//   public void test129() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test129"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
//     double[] var13 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var17 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var18 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var13, var17);
//     double[] var19 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var8, var17);
//     double[] var20 = org.apache.commons.math3.util.MathArrays.ebeAdd(var0, var8);
// 
//   }

  public void test130() {}
//   public void test130() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test130"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var6.nextBeta(4.1590082109255295d, (-0.8782782965603144d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.4523057448459515d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
// 
//   }

  public void test131() {}
//   public void test131() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test131"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     org.apache.commons.math3.distribution.RealDistribution var6 = null;
//     double var7 = var0.nextInversionDeviate(var6);
// 
//   }

  public void test132() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test132"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var6 = var2.nextF(102.0d, (-0.6001566413360179d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test133() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test133"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(3.367537023715106d, (-1.2058173601229263d), 1.4387505701387593d, 0.14521388384019507d, 2.923657016815099d, (-0.1293240986622624d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-4.229807354382433d));

  }

  public void test134() {}
//   public void test134() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test134"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     var0.reSeed((-1L));
//     java.util.Collection var8 = null;
//     java.lang.Object[] var10 = var0.nextSample(var8, 42);
// 
//   }

  public void test135() {}
//   public void test135() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test135"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var4 = var0.nextUniform((-1.0d), 10.0d, false);
//     var0.reSeed();
//     var0.reSeed(10L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextT((-679.7841048171373d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 1.6195819066863824d);
// 
//   }

  public void test136() {}
//   public void test136() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test136"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     double var11 = var0.nextUniform((-0.4148741153049867d), (-0.19811647941323907d), false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var0.nextBeta((-2.1252493435396733d), (-0.6001566413360179d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 100);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 6.134596089144195d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.830442571230336d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.32813291709187437d));
// 
//   }

  public void test137() {}
//   public void test137() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test137"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var4 = var1.nextInt(10, 100);
//     double var6 = var1.nextExponential(10.0d);
//     org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)"255737ca0aa76cd64c486046c09bb4241de9d17d6a15fad4cb3ac04c20bfb9ce320daaebb6e9d68f18f5234", (java.lang.Object)var1);
//     var1.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var1.nextGamma((-0.32577132027868605d), 87.05882352941177d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 32);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.20272405796967402d);
// 
//   }

  public void test138() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test138"); }


    double[] var0 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var1 = null;
    double[] var5 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var9 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var10 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var5, var9);
    double[] var14 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var15 = org.apache.commons.math3.util.MathArrays.safeNorm(var14);
    double[][] var16 = new double[][] { var14};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var5, var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.sortInPlace(var0, var1, var16);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test139() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test139"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    java.lang.Object[] var4 = new java.lang.Object[] { 0.0d};
    org.apache.commons.math3.exception.NotFiniteNumberException var5 = new org.apache.commons.math3.exception.NotFiniteNumberException(var1, (java.lang.Number)1L, var4);
    org.apache.commons.math3.exception.NullArgumentException var6 = new org.apache.commons.math3.exception.NullArgumentException(var0, var4);
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var6.getContext();
    java.lang.Number var8 = null;
    org.apache.commons.math3.util.MathArrays.OrderDirection var11 = null;
    org.apache.commons.math3.exception.NonMonotonicSequenceException var13 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var8, (java.lang.Number)103.56915419683993d, (-1), var11, true);
    var6.addSuppressed((java.lang.Throwable)var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test140() {}
//   public void test140() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test140"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var0.nextChiSquare((-3.672203955332186d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.9225372297811352d));
// 
//   }

  public void test141() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test141"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathInternalError var2 = new org.apache.commons.math3.exception.MathInternalError(var0, var1);

  }

  public void test142() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test142"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    int[] var7 = new int[] { };
    var1.setSeed(var7);
    org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var9.nextF(0.0d, 0.013022537989140215d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test143() {}
//   public void test143() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test143"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var6 = var0.nextPascal(61, 454.7733245704089d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 73);
// 
//   }

  public void test144() {}
//   public void test144() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test144"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     int var5 = var0.nextSecureInt((-1), 33);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var8 = var0.nextSecureLong(10L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 5568.37511691021d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 24);
// 
//   }

  public void test145() {}
//   public void test145() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test145"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var6 = var0.nextPermutation(0, 62);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 26);
// 
//   }

  public void test146() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test146"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var4 = var1.nextZipf(70, (-2.8440414054821423d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test147() {}
//   public void test147() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test147"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var4 = var0.nextUniform((-1.0d), 10.0d, false);
//     var0.reSeed();
//     var0.reSeed(10L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextBeta((-3.3781187158717527d), 100.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 9.08538869046472d);
// 
//   }

  public void test148() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test148"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    var2.reSeed((-1L));
    long var9 = var2.nextPoisson(100.00999950005d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var12 = var2.nextZipf(0, 357.60346728709703d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 108L);

  }

  public void test149() {}
//   public void test149() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test149"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var6 = var0.nextWeibull((-0.8745685632141509d), 1.934238008197349E-9d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 98);
// 
//   }

  public void test150() {}
//   public void test150() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test150"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     java.util.Collection var4 = null;
//     java.lang.Object[] var6 = var2.nextSample(var4, 88);
// 
//   }

  public void test151() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test151"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var3 = new java.lang.Object[] { 0.0d};
    org.apache.commons.math3.exception.NotFiniteNumberException var4 = new org.apache.commons.math3.exception.NotFiniteNumberException(var0, (java.lang.Number)1L, var3);
    org.apache.commons.math3.exception.util.ExceptionContext var5 = var4.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test152() {}
//   public void test152() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test152"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     double var8 = var2.nextT(11.36369913641775d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var2.nextF(0.018830280094064424d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.782974750774556d);
// 
//   }

  public void test153() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test153"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.util.Localizable var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var5 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
    java.lang.Object[] var6 = new java.lang.Object[] { true};
    org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var6);
    org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var6);
    org.apache.commons.math3.exception.util.ExceptionContext var9 = var8.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test154() {}
//   public void test154() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test154"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var3 = var0.nextUniform(5.2935374176612715d, 10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var6 = var0.nextSecureLong(10L, 7L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 8.47296284071117d);
// 
//   }

  public void test155() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test155"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(5.704309058613993d, 100.00999950005d, 0.10832690038004085d, 0.1431715674774945d, (-6.755317488693713d), (-0.05475404077564316d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 570.8733363614718d);

  }

  public void test156() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test156"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination((-0.6001566413360179d), (-2.8440414054821423d), 12.211458734486403d, 223.0d, (-0.8024838501147071d), (-75.62470873108684d), 11.36369913641775d, (-0.05475404077564316d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 2784.9275671086507d);

  }

  public void test157() {}
//   public void test157() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test157"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     double var9 = var0.nextCauchy(0.08430081831437178d, 0.407741687198951d);
//     double var11 = var0.nextT(149.06382668435472d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var0.nextBeta(0.0d, 100.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.5710544146205296d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.09555252791114864d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.16348078466968305d);
// 
//   }

  public void test158() {}
//   public void test158() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test158"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     long var3 = var0.nextSecureLong(0L, 10L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var6 = var0.nextWeibull(2.1874856059935905d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9L);
// 
//   }

  public void test159() {}
//   public void test159() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test159"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
//     double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
//     double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
//     double[] var24 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var28 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var29 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var24, var28);
//     org.apache.commons.math3.random.RandomDataGenerator var30 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var33 = var30.nextInt(10, 100);
//     double var36 = var30.nextUniform((-1.0d), 1.0d);
//     var30.reSeedSecure();
//     org.apache.commons.math3.util.Pair var38 = new org.apache.commons.math3.util.Pair((java.lang.Object)var29, (java.lang.Object)var30);
//     double[] var42 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var46 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var47 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var42, var46);
//     double[] var51 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var55 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var56 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var51, var55);
//     double[] var57 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var46, var55);
//     double[] var58 = null;
//     boolean var59 = org.apache.commons.math3.util.MathArrays.equals(var55, var58);
//     double[] var63 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var67 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var71 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var72 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var67, var71);
//     double var73 = org.apache.commons.math3.util.MathArrays.distance1(var63, var72);
//     boolean var74 = org.apache.commons.math3.util.MathArrays.equals(var55, var63);
//     double[] var75 = org.apache.commons.math3.util.MathArrays.ebeDivide(var29, var55);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.apache.commons.math3.distribution.DiscreteRealDistribution var76 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var16, var75);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var24);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 64);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var36 == 0.21621348163719034d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var42);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var59 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var73 == 223.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var74 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var75);
// 
//   }

  public void test160() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test160"); }


    double[] var3 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var7 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var11 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var12 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var7, var11);
    double var13 = org.apache.commons.math3.util.MathArrays.distance1(var3, var12);
    double[] var15 = org.apache.commons.math3.util.MathArrays.normalizeArray(var12, 0.0d);
    double[] var17 = new double[] { 0.0d};
    org.apache.commons.math3.util.MathArrays.OrderDirection var18 = null;
    boolean var20 = org.apache.commons.math3.util.MathArrays.isMonotonic(var17, var18, false);
    double[] var21 = null;
    double[] var25 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var29 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var30 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var25, var29);
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var21, var29);
    double var32 = org.apache.commons.math3.util.MathArrays.safeNorm(var29);
    double[] var36 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var40 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var41 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var36, var40);
    double[] var42 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var29, var36);
    double var43 = org.apache.commons.math3.util.MathArrays.distance1(var17, var29);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var44 = org.apache.commons.math3.util.MathArrays.distance(var15, var17);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == 1.0d);

  }

  public void test161() {}
//   public void test161() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test161"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     double var8 = var0.nextUniform((-0.14097693123713528d), 4.1590082109255295d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var0.nextSecureInt(54, (-1));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.8161760112388483d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0070907413320793885d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2.906340746762074d);
// 
//   }

  public void test162() {}
//   public void test162() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test162"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var9 = var2.nextLong(6L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 5);
// 
//   }

  public void test163() {}
//   public void test163() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test163"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     double var8 = var0.nextUniform((-0.14097693123713528d), 4.1590082109255295d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextGamma(0.31568577999507896d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-2753.388595669856d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.07466141392617946d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.014986290618739906d);
// 
//   }

  public void test164() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test164"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var8, var12);
    double[] var22 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var26 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var30 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var31 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var26, var30);
    double var32 = org.apache.commons.math3.util.MathArrays.distance1(var22, var31);
    double[] var34 = org.apache.commons.math3.util.MathArrays.copyOf(var31, 88);
    double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
    double[] var47 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var51 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var52 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var47, var51);
    double[] var53 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var42, var51);
    double[] var54 = null;
    boolean var55 = org.apache.commons.math3.util.MathArrays.equals(var51, var54);
    double[][] var56 = new double[][] { var51};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var31, var56);
    org.apache.commons.math3.util.MathArrays.sortInPlace(var12, var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 102.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var55 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);

  }

  public void test165() {}
//   public void test165() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test165"); }
// 
// 
//     double[] var0 = null;
//     double[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 37);
// 
//   }

  public void test166() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test166"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    var2.reSeed((-1L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var2.nextCauchy((-8.977615667280723d), (-1.2058173601229263d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);

  }

  public void test167() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test167"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var16, 9900.0d);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var24 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var25 = var24.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var26 = var24.getDirection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var20, var26, true);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);

  }

  public void test168() {}
//   public void test168() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test168"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     double var6 = var0.nextChiSquare(0.012774969105543068d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextBeta((-8.977615667280723d), 0.5769815473378194d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-5730.896913772651d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "a3eb01616a41a96be54b9c"+ "'", var4.equals("a3eb01616a41a96be54b9c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0d);
// 
//   }

  public void test169() {}
//   public void test169() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test169"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGaussian(0.0d, 10.0d);
//     int var14 = var0.nextSecureInt(22, 75);
//     java.lang.String var16 = var0.nextHexString(33);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var0.nextPascal(0, 4.1590082109255295d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.6530963560569947d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "d209bbb477c102969271d11bc069c75b8b19ed7705781514facdeb3da53d3e311718b3bfa500849d81d857b"+ "'", var8.equals("d209bbb477c102969271d11bc069c75b8b19ed7705781514facdeb3da53d3e311718b3bfa500849d81d857b"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-12.043782263845042d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var16 + "' != '" + "430dd4e58d4a9c513c79f77391e4e3def"+ "'", var16.equals("430dd4e58d4a9c513c79f77391e4e3def"));
// 
//   }

  public void test170() {}
//   public void test170() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test170"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     int[] var5 = new int[] { 100, 10, (-1)};
//     var1.setSeed(var5);
//     double[] var7 = null;
//     double[] var8 = null;
//     double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
//     boolean var18 = org.apache.commons.math3.util.MathArrays.equals(var8, var16);
//     double var19 = org.apache.commons.math3.util.MathArrays.safeNorm(var16);
//     double[] var23 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var27 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var28 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var23, var27);
//     double[] var29 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var16, var23);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var30 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var7, var16);
// 
//   }

  public void test171() {}
//   public void test171() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test171"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     float var2 = var1.nextFloat();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.985664f);
// 
//   }

  public void test172() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test172"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, var1, (java.lang.Number)6.251783231069299d, false);
    boolean var5 = var4.getBoundIsAllowed();
    boolean var6 = var4.getBoundIsAllowed();
    boolean var7 = var4.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == false);

  }

  public void test173() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test173"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(50, 16);

  }

  public void test174() {}
//   public void test174() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test174"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextLong((-1L), 10L);
//     var2.reSeedSecure(100L);
//     java.lang.String var9 = var2.nextSecureHexString(54);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var2.nextInt(88, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "7247abf0fd87377758ca7cd6a9ab1ef5255291b42e02bf44aec36b"+ "'", var9.equals("7247abf0fd87377758ca7cd6a9ab1ef5255291b42e02bf44aec36b"));
// 
//   }

  public void test175() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test175"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(10L);
    int[] var2 = null;
    org.apache.commons.math3.random.Well19937c var3 = new org.apache.commons.math3.random.Well19937c(var2);
    int[] var7 = new int[] { 100, 10, (-1)};
    var3.setSeed(var7);
    int[] var9 = new int[] { };
    var3.setSeed(var9);
    int[] var11 = null;
    int var12 = org.apache.commons.math3.util.MathArrays.distanceInf(var9, var11);
    int[] var14 = org.apache.commons.math3.util.MathArrays.copyOf(var9, 66);
    int[] var16 = org.apache.commons.math3.util.MathArrays.copyOf(var9, 0);
    var1.setSeed(var16);
    float var18 = var1.nextFloat();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 0.74755037f);

  }

  public void test176() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test176"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotPositiveException var2 = new org.apache.commons.math3.exception.NotPositiveException(var0, (java.lang.Number)7L);

  }

  public void test177() {}
//   public void test177() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test177"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.012774969105543068d, 0.09455763871444445d);
//     int[] var8 = var0.nextPermutation(83, 33);
//     int[] var9 = org.apache.commons.math3.util.MathArrays.copyOf(var8);
//     org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var12 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var11);
//     var12.reSeed();
//     int var16 = var12.nextZipf(18, 0.10832690038004085d);
//     double var18 = var12.nextT(11.36369913641775d);
//     int[] var21 = var12.nextPermutation(33, 31);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var22 = org.apache.commons.math3.util.MathArrays.distanceInf(var9, var21);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 11.593505888123785d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 1);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 0.28196495345567185d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
// 
//   }

  public void test178() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test178"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.1289083935957991d, (java.lang.Number)7, (java.lang.Number)108L);
    java.lang.Number var4 = var3.getLo();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 7+ "'", var4.equals(7));

  }

  public void test179() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test179"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    int[] var7 = new int[] { };
    var1.setSeed(var7);
    int[] var9 = null;
    int var10 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var9);
    int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 66);
    int[] var13 = new int[] { };
    int[] var14 = null;
    int var15 = org.apache.commons.math3.util.MathArrays.distanceInf(var13, var14);
    double var16 = org.apache.commons.math3.util.MathArrays.distance(var7, var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == 0);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 0.0d);

  }

  public void test180() {}
//   public void test180() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test180"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var0.nextBinomial(53, (-0.14097693123713528d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.6289270020478646d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "4a065c42477db5c9642365b87ee806b179f63ff6b773441133c499d36f2c38d9d424067149bd0a1f0ffdd3f"+ "'", var8.equals("4a065c42477db5c9642365b87ee806b179f63ff6b773441133c499d36f2c38d9d424067149bd0a1f0ffdd3f"));
// 
//   }

  public void test181() {}
//   public void test181() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test181"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextHypergeometric(58, 93, 20);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 8.064976072390355d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.03878245582013849d);
// 
//   }

  public void test182() {}
//   public void test182() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test182"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var9 = var0.nextSecureLong(8026008374386375277L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.2473668151722661d);
// 
//   }

  public void test183() {}
//   public void test183() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test183"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     java.lang.String var5 = var0.nextHexString(87);
//     java.lang.String var7 = var0.nextHexString(75);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextCauchy((-0.9286380078653282d), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 71);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "66c9ab380caaf0a0ab820cc25f8588b832d07b3cd32cc1523079bd0fa5ec88cd90399f9c0c5db7fcbc61c0c"+ "'", var5.equals("66c9ab380caaf0a0ab820cc25f8588b832d07b3cd32cc1523079bd0fa5ec88cd90399f9c0c5db7fcbc61c0c"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "530e7b9c1a56c1b3ea60c2a36e87135a67ae7547b4eaee31020bdd8d7d5173f6f3f2ebc3b43"+ "'", var7.equals("530e7b9c1a56c1b3ea60c2a36e87135a67ae7547b4eaee31020bdd8d7d5173f6f3f2ebc3b43"));
// 
//   }

  public void test184() {}
//   public void test184() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test184"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     var0.reSeedSecure();
//     double var10 = var0.nextWeibull(5.2935374176612715d, 6306020.951293601d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var13 = var0.nextPermutation(0, 100);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.8734065481273303d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5675315.868079295d);
// 
//   }

  public void test185() {}
//   public void test185() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test185"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     double var8 = var0.nextUniform((-0.14097693123713528d), 4.1590082109255295d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("2f964d87803fad28e664396c6ffccf22b", "8c0da73981231d95e4506f2554b2de2167df3dde5cd91330915db82c1639bfe700b359bd3bb");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-9.974595017791964E21d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.0013692451243095404d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.8709340549514093d);
// 
//   }

  public void test186() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test186"); }


    double[] var3 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var7 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var11 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var12 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var7, var11);
    double var13 = org.apache.commons.math3.util.MathArrays.distance1(var3, var12);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var20 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var21 = var20.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var22 = var20.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var24 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var22, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var3, var22, true);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);

  }

  public void test187() {}
//   public void test187() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test187"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     java.lang.String var6 = var0.nextSecureHexString(88);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextBeta((-0.01498759451409439d), 7.4087361194955745d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-4.8337860571023053E18d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "13e357a6855dbc298d8341"+ "'", var4.equals("13e357a6855dbc298d8341"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "c5fb97770442d534319416aa9e7f360173c26114e47261782ea09959557b1f4ea21ae6f7ef6e464c9b25a2aa"+ "'", var6.equals("c5fb97770442d534319416aa9e7f360173c26114e47261782ea09959557b1f4ea21ae6f7ef6e464c9b25a2aa"));
// 
//   }

  public void test188() {}
//   public void test188() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test188"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextDouble();
//     long var3 = var1.nextLong();
//     org.apache.commons.math3.random.RandomDataImpl var4 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     org.apache.commons.math3.distribution.RealDistribution var5 = null;
//     double var6 = var4.nextInversionDeviate(var5);
// 
//   }

  public void test189() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test189"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var8, var12);
    double[] var19 = null;
    double[] var23 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var27 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var28 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var23, var27);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var19, var27);
    double var30 = org.apache.commons.math3.util.MathArrays.safeNorm(var27);
    double[] var34 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var38 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var39 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var34, var38);
    double[] var40 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var27, var34);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equals(var12, var34);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var34);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 102.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);

  }

  public void test190() {}
//   public void test190() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test190"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGaussian(0.0d, 10.0d);
//     long var13 = var0.nextPoisson(10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var0.nextHypergeometric(0, 51, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.5047932122955054d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "1c41930cd51622bc9f220033e6003c85c565cd78b805c0934853e4d0cb8ee911106f04f5440b9fd6fd22dfe"+ "'", var8.equals("1c41930cd51622bc9f220033e6003c85c565cd78b805c0934853e4d0cb8ee911106f04f5440b9fd6fd22dfe"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-9.124161176069787d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 11L);
// 
//   }

  public void test191() {}
//   public void test191() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test191"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.012774969105543068d, 0.09455763871444445d);
//     double var7 = var0.nextExponential(0.4301403036978695d);
//     org.apache.commons.math3.distribution.IntegerDistribution var8 = null;
//     int var9 = var0.nextInversionDeviate(var8);
// 
//   }

  public void test192() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test192"); }


    double[] var3 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var4 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
    double[] var6 = new double[] { 0.0d};
    org.apache.commons.math3.util.MathArrays.OrderDirection var7 = null;
    boolean var9 = org.apache.commons.math3.util.MathArrays.isMonotonic(var6, var7, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var6);
    double[][] var11 = new double[][] { var6};
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.sortInPlace(var3, var11);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);

  }

  public void test193() {}
//   public void test193() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test193"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     java.lang.String var5 = var0.nextHexString(87);
//     java.lang.String var7 = var0.nextHexString(75);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextUniform(5.704309058613993d, 0.031186714079133728d, true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "9dd3287215afaf9f0c2746517f44e21f4d025d3e424aa634ebdad6a6391e6ee76e153c7b716879013a9be8e"+ "'", var5.equals("9dd3287215afaf9f0c2746517f44e21f4d025d3e424aa634ebdad6a6391e6ee76e153c7b716879013a9be8e"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "740b330fc113b5fc3d5349f9ddba4df23e4e2a2c935aad2a7854bb74465b7aecb005bf511e6"+ "'", var7.equals("740b330fc113b5fc3d5349f9ddba4df23e4e2a2c935aad2a7854bb74465b7aecb005bf511e6"));
// 
//   }

  public void test194() {}
//   public void test194() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test194"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     java.util.List var2 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var3 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var2);
// 
//   }

  public void test195() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test195"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)52, (java.lang.Number)5.433048171930581d, false);

  }

  public void test196() {}
//   public void test196() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test196"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var4 = var1.nextInt(10, 100);
//     double var6 = var1.nextExponential(10.0d);
//     org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)"255737ca0aa76cd64c486046c09bb4241de9d17d6a15fad4cb3ac04c20bfb9ce320daaebb6e9d68f18f5234", (java.lang.Object)var1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var9 = var1.nextHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.773333199303721d);
// 
//   }

  public void test197() {}
//   public void test197() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test197"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     var0.reSeed();
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextUniform(6.251783231069299d, 0.2080200843690793d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 98);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.4421360174688491d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.34067478331897755d);
// 
//   }

  public void test198() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test198"); }


    org.apache.commons.math3.exception.util.Localizable var2 = null;
    org.apache.commons.math3.exception.util.Localizable var3 = null;
    org.apache.commons.math3.exception.util.Localizable var4 = null;
    java.lang.Object[] var6 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var7 = new org.apache.commons.math3.exception.MathInternalError(var4, var6);
    org.apache.commons.math3.exception.MathIllegalArgumentException var8 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var3, var6);
    org.apache.commons.math3.exception.NullArgumentException var9 = new org.apache.commons.math3.exception.NullArgumentException(var2, var6);
    org.apache.commons.math3.exception.NotFiniteNumberException var10 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)100.0d, var6);
    org.apache.commons.math3.exception.NotFiniteNumberException var11 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)0.74755037f, var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test199() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test199"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)10.0f, (java.lang.Number)(-1.0d), false);
    java.lang.Number var5 = var4.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-1.0d)+ "'", var5.equals((-1.0d)));

  }

  public void test200() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test200"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    var2.reSeed((-1L));
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var10 = var2.nextPermutation(24, 47);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);

  }

  public void test201() {}
//   public void test201() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test201"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("8c0da73981231d95e4506f2554b2de2167df3dde5cd91330915db82c1639bfe700b359bd3bb", "700687440fea7126649656749b57b90aa77c34398855a13ed5f7e0bc55d51dde51eab335dd9945e806ed7d0");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 17.38840794124854d);
// 
//   }

  public void test202() {}
//   public void test202() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test202"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     double var8 = var2.nextT(11.36369913641775d);
//     int[] var11 = var2.nextPermutation(33, 31);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var2.nextHypergeometric(26, 42, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.07519452628396103d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
// 
//   }

  public void test203() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test203"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 33, 54);
    java.lang.Throwable[] var4 = var3.getSuppressed();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test204() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test204"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.20851425337288942d, 0.031186714079133728d, 0.0d, 0.0d, 1.818331372129114d, 3.577208239390972d, 0.7025993166887234d, (-0.4148741153049867d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 6.219562570799601d);

  }

  public void test205() {}
//   public void test205() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test205"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     double var11 = var0.nextUniform((-0.4148741153049867d), (-0.19811647941323907d), false);
//     java.util.Collection var12 = null;
//     java.lang.Object[] var14 = var0.nextSample(var12, 51);
// 
//   }

  public void test206() {}
//   public void test206() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test206"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     int var9 = var2.nextZipf(52, 7.4087361194955745d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var2.nextSecureInt(42, 3);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
// 
//   }

  public void test207() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test207"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var8, var12);
    double[] var22 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var26 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var30 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var31 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var26, var30);
    double var32 = org.apache.commons.math3.util.MathArrays.distance1(var22, var31);
    double[] var34 = org.apache.commons.math3.util.MathArrays.normalizeArray(var31, 0.0d);
    double[] var35 = org.apache.commons.math3.util.MathArrays.copyOf(var31);
    double var36 = org.apache.commons.math3.util.MathArrays.distance1(var8, var31);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var40 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var41 = var40.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var42 = var40.getDirection();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      boolean var45 = org.apache.commons.math3.util.MathArrays.checkOrder(var31, var42, false, true);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 102.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);

  }

  public void test208() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test208"); }


    long[] var3 = new long[] { 10L, 0L, 0L};
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var3);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var3);
    org.apache.commons.math3.util.MathArrays.checkNonNegative(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);

  }

  public void test209() {}
//   public void test209() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test209"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var8 = var0.nextUniform(4.847943602659273d, 0.0d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1534.0770428502617d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "4df54a4e36377c0303e490"+ "'", var4.equals("4df54a4e36377c0303e490"));
// 
//   }

  public void test210() {}
//   public void test210() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test210"); }
// 
// 
//     double[] var0 = null;
//     double[] var1 = null;
//     double[] var5 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var9 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var10 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var5, var9);
//     boolean var11 = org.apache.commons.math3.util.MathArrays.equals(var1, var9);
//     double var12 = org.apache.commons.math3.util.MathArrays.safeNorm(var9);
//     double[] var16 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var20 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var21 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var16, var20);
//     double[] var22 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var9, var16);
//     double[] var23 = null;
//     double[] var27 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var31 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var32 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var27, var31);
//     boolean var33 = org.apache.commons.math3.util.MathArrays.equals(var23, var31);
//     double var34 = org.apache.commons.math3.util.MathArrays.safeNorm(var31);
//     double[] var38 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var42 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var46 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var47 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var42, var46);
//     double var48 = org.apache.commons.math3.util.MathArrays.distance1(var38, var47);
//     double[] var50 = org.apache.commons.math3.util.MathArrays.copyOf(var47, 88);
//     double var51 = org.apache.commons.math3.util.MathArrays.distanceInf(var31, var47);
//     double[] var55 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var59 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var60 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var55, var59);
//     org.apache.commons.math3.random.RandomDataGenerator var61 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var64 = var61.nextInt(10, 100);
//     double var67 = var61.nextUniform((-1.0d), 1.0d);
//     var61.reSeedSecure();
//     org.apache.commons.math3.util.Pair var69 = new org.apache.commons.math3.util.Pair((java.lang.Object)var60, (java.lang.Object)var61);
//     double[] var70 = org.apache.commons.math3.util.MathArrays.ebeAdd(var31, var60);
//     boolean var71 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var22, var60);
//     double[] var72 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var0, var22);
// 
//   }

  public void test211() {}
//   public void test211() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test211"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextCauchy((-0.6044871530760823d), 5.704309058613993d);
//     double var10 = var0.nextUniform(0.407741687198951d, 1.4387505701387593d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var13 = var0.nextSecureLong(14L, (-1L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 117.49519565863507d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.8728888526351157d);
// 
//   }

  public void test212() {}
//   public void test212() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test212"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     var0.reSeed(10L);
//     long var8 = var0.nextPoisson(0.636769707396945d);
//     double var11 = var0.nextGaussian((-0.8258598346981539d), 454.7733245704089d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var0.nextChiSquare((-0.01516979083120098d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-190.16438686640686d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "fd12cef80fe68c09680694"+ "'", var4.equals("fd12cef80fe68c09680694"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 529.9961815694902d);
// 
//   }

  public void test213() {}
//   public void test213() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test213"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     java.lang.String var5 = var0.nextHexString(87);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var8 = var0.nextSecureLong(108L, (-3200518016629555151L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "8d059718539da1e9f33926d790f3f48119dad2d7250388576895a439df60e0908acc41794c12a72492f01a0"+ "'", var5.equals("8d059718539da1e9f33926d790f3f48119dad2d7250388576895a439df60e0908acc41794c12a72492f01a0"));
// 
//   }

  public void test214() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test214"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(1.6128523808130044d, (-679.7841048171373d), 0.10684763416654564d, 0.13710330393787307d, 100.00999950005d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1096.3767627294947d));

  }

  public void test215() {}
//   public void test215() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test215"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     java.lang.Object[] var3 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var4 = new org.apache.commons.math3.exception.MathInternalError(var1, var3);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var5 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var3);
//     org.apache.commons.math3.exception.NullArgumentException var6 = new org.apache.commons.math3.exception.NullArgumentException();
//     var5.addSuppressed((java.lang.Throwable)var6);
//     org.apache.commons.math3.exception.util.Localizable var8 = null;
//     java.lang.Object[] var9 = null;
//     org.apache.commons.math3.exception.MathIllegalStateException var10 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable)var5, var8, var9);
// 
//   }

  public void test216() {}
//   public void test216() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test216"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     java.lang.String var5 = var0.nextHexString(87);
//     java.lang.String var7 = var0.nextHexString(75);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextSecureInt(83, 53);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 28);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "7e21a15717906f06cfa6da94ffb4dfba33153a26a49d9c4351003db2932805a61852336d06c662018be2d62"+ "'", var5.equals("7e21a15717906f06cfa6da94ffb4dfba33153a26a49d9c4351003db2932805a61852336d06c662018be2d62"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var7 + "' != '" + "0c3f00b7124492a29e66c6fa73438ce2cb823b3de127a1664aa1810f5b809073fdbc4d0661d"+ "'", var7.equals("0c3f00b7124492a29e66c6fa73438ce2cb823b3de127a1664aa1810f5b809073fdbc4d0661d"));
// 
//   }

  public void test217() {}
//   public void test217() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test217"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     int var8 = var0.nextInt(0, 100);
//     var0.reSeedSecure(1L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextPascal(4, (-75.62470873108684d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-483.73260305861567d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.009883833124588024d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 41);
// 
//   }

  public void test218() {}
//   public void test218() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test218"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.012774969105543068d, 0.09455763871444445d);
//     double var7 = var0.nextExponential(0.4301403036978695d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextZipf(4, (-0.01498759451409439d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 355574.3765670932d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.3576593749373283E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.02913934730594456d);
// 
//   }

  public void test219() {}
//   public void test219() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test219"); }
// 
// 
//     int[] var0 = null;
//     int[] var1 = org.apache.commons.math3.util.MathArrays.copyOf(var0);
// 
//   }

  public void test220() {}
//   public void test220() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test220"); }
// 
// 
//     double[] var0 = null;
//     double[] var1 = null;
//     double[] var5 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var9 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var10 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var5, var9);
//     boolean var11 = org.apache.commons.math3.util.MathArrays.equals(var1, var9);
//     double[] var15 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var19 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var23 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var24 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var19, var23);
//     double var25 = org.apache.commons.math3.util.MathArrays.distance1(var15, var24);
//     boolean var26 = org.apache.commons.math3.util.MathArrays.equals(var9, var24);
//     double[] var30 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var34 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var35 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var30, var34);
//     org.apache.commons.math3.random.RandomDataGenerator var36 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var39 = var36.nextInt(10, 100);
//     double var42 = var36.nextUniform((-1.0d), 1.0d);
//     var36.reSeedSecure();
//     org.apache.commons.math3.util.Pair var44 = new org.apache.commons.math3.util.Pair((java.lang.Object)var35, (java.lang.Object)var36);
//     double[] var48 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var52 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var53 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var48, var52);
//     double[] var57 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var61 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var62 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var57, var61);
//     double[] var63 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var52, var61);
//     double[] var64 = null;
//     boolean var65 = org.apache.commons.math3.util.MathArrays.equals(var61, var64);
//     double[] var69 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var73 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var77 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var78 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var73, var77);
//     double var79 = org.apache.commons.math3.util.MathArrays.distance1(var69, var78);
//     boolean var80 = org.apache.commons.math3.util.MathArrays.equals(var61, var69);
//     double[] var81 = org.apache.commons.math3.util.MathArrays.ebeDivide(var35, var61);
//     double var82 = org.apache.commons.math3.util.MathArrays.distance(var9, var61);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var83 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var0, var61);
// 
//   }

  public void test221() {}
//   public void test221() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test221"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.012774969105543068d, 0.09455763871444445d);
//     int[] var8 = var0.nextPermutation(83, 33);
//     org.apache.commons.math3.distribution.RealDistribution var9 = null;
//     double var10 = var0.nextInversionDeviate(var9);
// 
//   }

  public void test222() {}
//   public void test222() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test222"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     int var5 = var0.nextSecureInt((-1), 33);
//     long var8 = var0.nextSecureLong(1L, 100L);
//     org.apache.commons.math3.distribution.RealDistribution var9 = null;
//     double var10 = var0.nextInversionDeviate(var9);
// 
//   }

  public void test223() {}
//   public void test223() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test223"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextCauchy((-0.6044871530760823d), 5.704309058613993d);
//     double var10 = var0.nextUniform(0.407741687198951d, 1.4387505701387593d, false);
//     java.lang.String var12 = var0.nextHexString(62);
//     var0.reSeed(0L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var0.nextPascal(66, (-8.977615667280723d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-37.931138367284646d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.9156230799827776d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "47e208a009c656101f5d8ce2dd2a9b0914cdb31378954ac17b0e301595daa1"+ "'", var12.equals("47e208a009c656101f5d8ce2dd2a9b0914cdb31378954ac17b0e301595daa1"));
// 
//   }

  public void test224() {}
//   public void test224() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test224"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
//     boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
//     double var11 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
//     double[] var15 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var19 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var20 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var15, var19);
//     double[] var21 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var8, var15);
//     double[] var22 = null;
//     double[] var26 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var30 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var31 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var26, var30);
//     boolean var32 = org.apache.commons.math3.util.MathArrays.equals(var22, var30);
//     double var33 = org.apache.commons.math3.util.MathArrays.safeNorm(var30);
//     double[] var37 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var41 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var45 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var46 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var41, var45);
//     double var47 = org.apache.commons.math3.util.MathArrays.distance1(var37, var46);
//     double[] var49 = org.apache.commons.math3.util.MathArrays.copyOf(var46, 88);
//     double var50 = org.apache.commons.math3.util.MathArrays.distanceInf(var30, var46);
//     double[] var54 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var58 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var59 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var54, var58);
//     org.apache.commons.math3.random.RandomDataGenerator var60 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var63 = var60.nextInt(10, 100);
//     double var66 = var60.nextUniform((-1.0d), 1.0d);
//     var60.reSeedSecure();
//     org.apache.commons.math3.util.Pair var68 = new org.apache.commons.math3.util.Pair((java.lang.Object)var59, (java.lang.Object)var60);
//     double[] var69 = org.apache.commons.math3.util.MathArrays.ebeAdd(var30, var59);
//     boolean var70 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var21, var59);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       org.apache.commons.math3.util.MathArrays.checkPositive(var21);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 100.00999950005d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var19);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var32 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var33 == 100.00999950005d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var37);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var45);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var46);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var47 == 223.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var50 == 199.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var58);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var63 == 33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var66 == (-0.6850523914042341d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var70 == false);
// 
//   }

  public void test225() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test225"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var8, var12);
    double[] var22 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var26 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var30 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var31 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var26, var30);
    double var32 = org.apache.commons.math3.util.MathArrays.distance1(var22, var31);
    double[] var34 = org.apache.commons.math3.util.MathArrays.normalizeArray(var31, 0.0d);
    double[] var35 = org.apache.commons.math3.util.MathArrays.copyOf(var31);
    double var36 = org.apache.commons.math3.util.MathArrays.distance1(var8, var31);
    double var37 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var8);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 102.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 99.04039579888602d);

  }

  public void test226() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test226"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var2 = new java.lang.Object[] { 25.05052606779598d};
    org.apache.commons.math3.exception.MathIllegalArgumentException var3 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var0, var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);

  }

  public void test227() {}
//   public void test227() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test227"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     int var8 = var0.nextZipf(99, 4.1590082109255295d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextUniform(529.9961815694902d, 1.509158546181673E-9d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2430.9834232789103d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.07655929212779816d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
// 
//   }

  public void test228() {}
//   public void test228() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test228"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     double var9 = var0.nextCauchy(0.08430081831437178d, 0.407741687198951d);
//     double var11 = var0.nextT(149.06382668435472d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var14 = var0.nextLong(6149568864592168549L, 5507950371326924800L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 93);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.9795838476878407d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-3.7921689759589796d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.6268812096121295d));
// 
//   }

  public void test229() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test229"); }


    double[] var0 = null;
    double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
    boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
    double var11 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
    double[] var15 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var19 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var20 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var15, var19);
    double[] var24 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var28 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var29 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var24, var28);
    double[] var30 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var19, var28);
    double[] var31 = null;
    boolean var32 = org.apache.commons.math3.util.MathArrays.equals(var28, var31);
    double[] var36 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var40 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var44 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var45 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var40, var44);
    double var46 = org.apache.commons.math3.util.MathArrays.distance1(var36, var45);
    boolean var47 = org.apache.commons.math3.util.MathArrays.equals(var28, var36);
    double var48 = org.apache.commons.math3.util.MathArrays.distance1(var8, var28);
    double[] var52 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var56 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var57 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var52, var56);
    double[] var61 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var65 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var66 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var61, var65);
    double[] var67 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var56, var65);
    double var68 = org.apache.commons.math3.util.MathArrays.distance(var28, var56);
    org.apache.commons.math3.util.MathArrays.checkPositive(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var46 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var52);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var67);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var68 == 0.0d);

  }

  public void test230() {}
//   public void test230() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test230"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var9 = var2.nextSecureLong((-1L), (-1L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3);
// 
//   }

  public void test231() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test231"); }


    double[] var1 = new double[] { 10.0d};
    double[] var5 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var9 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var10 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var5, var9);
    double[] var14 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var18 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var19 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var14, var18);
    double[] var20 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var9, var18);
    double[] var22 = org.apache.commons.math3.util.MathArrays.normalizeArray(var18, 9900.0d);
    org.apache.commons.math3.exception.util.Localizable var23 = null;
    java.lang.Object[] var25 = new java.lang.Object[] { (byte)100};
    org.apache.commons.math3.exception.MathInternalError var26 = new org.apache.commons.math3.exception.MathInternalError(var23, var25);
    org.apache.commons.math3.util.Pair var27 = new org.apache.commons.math3.util.Pair((java.lang.Object)var22, (java.lang.Object)var23);
    double var28 = org.apache.commons.math3.util.MathArrays.distanceInf(var1, var22);
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    double[] var31 = org.apache.commons.math3.util.MathArrays.normalizeArray(var1, 0.3127635608371082d);
    double[] var35 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var39 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var43 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var44 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var39, var43);
    double var45 = org.apache.commons.math3.util.MathArrays.distance1(var35, var44);
    double[] var47 = org.apache.commons.math3.util.MathArrays.normalizeArray(var44, 0.0d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var48 = org.apache.commons.math3.util.MathArrays.ebeDivide(var1, var44);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var10);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var28 == 87.05882352941177d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var44);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var45 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);

  }

  public void test232() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test232"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(7741999113339246307L);

  }

  public void test233() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test233"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)100, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getSecond();
    java.lang.Object var4 = var2.getKey();
    java.lang.Object var5 = var2.getKey();
    java.lang.Object var6 = var2.getKey();
    java.lang.Object var7 = var2.getFirst();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 10.0d+ "'", var3.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (short)100+ "'", var4.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)100+ "'", var5.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (short)100+ "'", var6.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (short)100+ "'", var7.equals((short)100));

  }

  public void test234() {}
//   public void test234() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test234"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 61, 18);
// 
//   }

  public void test235() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test235"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong(1L, 8026008374386375277L);
    var2.reSeedSecure(7L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var2.nextUniform(0.0d, (-3.738191689496304d));
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5507950371326924800L);

  }

  public void test236() {}
//   public void test236() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test236"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var6.reSeedSecure((-1L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var6.nextBinomial(93, (-0.29240659494060117d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.6265305217663903d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
// 
//   }

  public void test237() {}
//   public void test237() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test237"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var4 = var0.nextUniform((-1.0d), 10.0d, false);
//     var0.reSeed();
//     var0.reSeed(10L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextWeibull((-33988.90347597093d), (-0.19811647941323907d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 8.187758528240918d);
// 
//   }

  public void test238() {}
//   public void test238() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test238"); }
// 
// 
//     double[] var0 = null;
//     double[] var1 = null;
//     double[] var5 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var9 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var10 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var5, var9);
//     boolean var11 = org.apache.commons.math3.util.MathArrays.equals(var1, var9);
//     double var12 = org.apache.commons.math3.util.MathArrays.safeNorm(var9);
//     double var13 = org.apache.commons.math3.util.MathArrays.linearCombination(var0, var9);
// 
//   }

  public void test239() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test239"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)100, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getSecond();
    java.lang.Object var4 = var2.getKey();
    java.lang.Object var5 = var2.getKey();
    java.lang.Object var6 = var2.getFirst();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 10.0d+ "'", var3.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (short)100+ "'", var4.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)100+ "'", var5.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (short)100+ "'", var6.equals((short)100));

  }

  public void test240() {}
//   public void test240() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test240"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     int var9 = var2.nextZipf(52, 7.4087361194955745d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var12 = var2.nextSecureLong(39L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 1);
// 
//   }

  public void test241() {}
//   public void test241() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test241"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var0.nextZipf(54, (-0.5903111221322579d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.9060431720552047d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "45dea7dc09daa9e635a647c87802ca34546e267e126f91611a1f9bce79313fce512391013fe6909dbf4f66b"+ "'", var8.equals("45dea7dc09daa9e635a647c87802ca34546e267e126f91611a1f9bce79313fce512391013fe6909dbf4f66b"));
// 
//   }

  public void test242() {}
//   public void test242() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test242"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextChiSquare(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 44);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.5301196532599812d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.16663334242271674d);
// 
//   }

  public void test243() {}
//   public void test243() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test243"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     double var9 = var0.nextCauchy(0.08430081831437178d, 0.407741687198951d);
//     double var11 = var0.nextT(149.06382668435472d);
//     double var14 = var0.nextF(1.5408118860052713d, 0.6862627241836179d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var0.nextUniform(25.05052606779598d, 0.6639432937569401d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.8725050288057372d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.07736184794829667d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-2.248472957013535d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 3.366645132909437d);
// 
//   }

  public void test244() {}
//   public void test244() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test244"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
//     boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
//     double[] var14 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var18 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var22 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var23 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var18, var22);
//     double var24 = org.apache.commons.math3.util.MathArrays.distance1(var14, var23);
//     boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var8, var23);
//     double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
//     org.apache.commons.math3.random.RandomDataGenerator var35 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var38 = var35.nextInt(10, 100);
//     double var41 = var35.nextUniform((-1.0d), 1.0d);
//     var35.reSeedSecure();
//     org.apache.commons.math3.util.Pair var43 = new org.apache.commons.math3.util.Pair((java.lang.Object)var34, (java.lang.Object)var35);
//     double[] var47 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var51 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var52 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var47, var51);
//     double[] var56 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var60 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var61 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var56, var60);
//     double[] var62 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var51, var60);
//     double[] var63 = null;
//     boolean var64 = org.apache.commons.math3.util.MathArrays.equals(var60, var63);
//     double[] var68 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var72 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var76 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var77 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var72, var76);
//     double var78 = org.apache.commons.math3.util.MathArrays.distance1(var68, var77);
//     boolean var79 = org.apache.commons.math3.util.MathArrays.equals(var60, var68);
//     double[] var80 = org.apache.commons.math3.util.MathArrays.ebeDivide(var34, var60);
//     double var81 = org.apache.commons.math3.util.MathArrays.distance(var8, var60);
//     double[] var82 = new double[] { };
//     double var83 = org.apache.commons.math3.util.MathArrays.safeNorm(var82);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var84 = org.apache.commons.math3.util.MathArrays.linearCombination(var60, var82);
//       fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
//     } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var24 == 223.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var25 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var33);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var38 == 55);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var41 == (-0.8065760538388793d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var47);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var51);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var52);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var56);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var60);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var61);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var62);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var64 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var68);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var72);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var76);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var77);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var78 == 223.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var79 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var81 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var83 == 0.0d);
// 
//   }

  public void test245() {}
//   public void test245() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test245"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.NumberIsTooSmallException var5 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
//     java.lang.Object[] var6 = new java.lang.Object[] { true};
//     org.apache.commons.math3.exception.MathIllegalStateException var7 = new org.apache.commons.math3.exception.MathIllegalStateException(var1, var6);
//     org.apache.commons.math3.exception.MathIllegalStateException var8 = new org.apache.commons.math3.exception.MathIllegalStateException(var0, var6);
//     java.lang.String var9 = var8.toString();
// 
//   }

  public void test246() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test246"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    int[] var7 = new int[] { };
    var1.setSeed(var7);
    org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int[] var12 = var9.nextPermutation(66, 20);
    int[] var16 = new int[] { 0, 0, 0};
    org.apache.commons.math3.random.Well19937c var17 = new org.apache.commons.math3.random.Well19937c(var16);
    org.apache.commons.math3.random.Well19937c var18 = new org.apache.commons.math3.random.Well19937c(var16);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var19 = org.apache.commons.math3.util.MathArrays.distanceInf(var12, var16);
      fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
    } catch (java.lang.ArrayIndexOutOfBoundsException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);

  }

  public void test247() {}
//   public void test247() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test247"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(0L);
//     int[] var2 = new int[] { };
//     int[] var3 = null;
//     int var4 = org.apache.commons.math3.util.MathArrays.distanceInf(var2, var3);
//     var1.setSeed(var2);
//     java.util.List var6 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var7 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var6);
// 
//   }

  public void test248() {}
//   public void test248() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test248"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var12 = var9.nextInt(10, 100);
//     double var15 = var9.nextUniform((-1.0d), 1.0d);
//     var9.reSeedSecure();
//     org.apache.commons.math3.util.Pair var17 = new org.apache.commons.math3.util.Pair((java.lang.Object)var8, (java.lang.Object)var9);
//     int var20 = var9.nextSecureInt(20, 78);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var23 = var9.nextBinomial(12, 2.95900240642029d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 0.066246214043169d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 37);
// 
//   }

  public void test249() {}
//   public void test249() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test249"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     var0.reSeedSecure();
//     double var10 = var0.nextWeibull(5.2935374176612715d, 6306020.951293601d);
//     double var13 = var0.nextBeta(1.4276096462825826E-9d, 0.1431715674774945d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var16 = var0.nextCauchy(1.1054197636303182d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 48);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.18631066731636814d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 4391485.424759003d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.0d);
// 
//   }

  public void test250() {}
//   public void test250() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test250"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     java.lang.String var6 = var0.nextSecureHexString(88);
//     var0.reSeedSecure(8026008374386375277L);
//     double var11 = var0.nextUniform(0.33140457057801864d, 10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var0.nextT(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-114.17440471809306d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "0adfce67580b0f9544bd68"+ "'", var4.equals("0adfce67580b0f9544bd68"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "49f5b12abdc8a6e98362863ba6ad4987c2348c9333205dcc0ef0998b28a3dc25f40d351f23f077bcdffbc1d8"+ "'", var6.equals("49f5b12abdc8a6e98362863ba6ad4987c2348c9333205dcc0ef0998b28a3dc25f40d351f23f077bcdffbc1d8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 3.2687600318980667d);
// 
//   }

  public void test251() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test251"); }


    double[] var3 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var7 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var11 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var12 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var7, var11);
    double var13 = org.apache.commons.math3.util.MathArrays.distance1(var3, var12);
    double[] var15 = org.apache.commons.math3.util.MathArrays.normalizeArray(var12, 0.0d);
    double[] var16 = null;
    double[] var20 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var24 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var25 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var20, var24);
    boolean var26 = org.apache.commons.math3.util.MathArrays.equals(var16, var24);
    double var27 = org.apache.commons.math3.util.MathArrays.safeNorm(var24);
    double[] var31 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var35 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var39 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var40 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var35, var39);
    double var41 = org.apache.commons.math3.util.MathArrays.distance1(var31, var40);
    double[] var43 = org.apache.commons.math3.util.MathArrays.copyOf(var40, 88);
    double var44 = org.apache.commons.math3.util.MathArrays.distanceInf(var24, var40);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var51 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var52 = var51.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var53 = var51.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var55 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var53, true);
    boolean var57 = org.apache.commons.math3.util.MathArrays.isMonotonic(var24, var53, false);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var15, var53, true);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var44 == 199.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var52 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var57 == true);

  }

  public void test252() {}
//   public void test252() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test252"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextCauchy((-0.6044871530760823d), 5.704309058613993d);
//     double var10 = var0.nextUniform(0.407741687198951d, 1.4387505701387593d, false);
//     java.lang.String var12 = var0.nextHexString(62);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextCauchy(10.912004843858076d, (-4.092805944621339d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-7.4259174651064805d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.0297620016193785d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "d6f3c1b6d040acfce87f633a76ca5c5ca88bb69c4b0d1bd7caff225df652c6"+ "'", var12.equals("d6f3c1b6d040acfce87f633a76ca5c5ca88bb69c4b0d1bd7caff225df652c6"));
// 
//   }

  public void test253() {}
//   public void test253() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test253"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(100.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var5 = var0.nextF((-334.56309673916184d), 570.8733363614718d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 112.99909316360825d);
// 
//   }

  public void test254() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test254"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    var2.reSeed((-1L));
    double var9 = var2.nextExponential(100.0d);
    var2.reSeed(39L);
    double var13 = var2.nextChiSquare(4.713414225479933d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 149.06382668435472d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 1.7451931429974368d);

  }

  public void test255() {}
//   public void test255() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test255"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
//     double[] var13 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var17 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var18 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var13, var17);
//     double[] var19 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var8, var17);
//     double[] var21 = org.apache.commons.math3.util.MathArrays.normalizeArray(var17, 9900.0d);
//     double[] var22 = org.apache.commons.math3.util.MathArrays.ebeAdd(var0, var17);
// 
//   }

  public void test256() {}
//   public void test256() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test256"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     int var8 = var0.nextZipf(99, 4.1590082109255295d);
//     double var10 = var0.nextT(0.4573684520296781d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("b963fc8f775b2a5894c5cc44fc70241fcb4799bd2eb8faa3b739b91f99e29e390e965672f6b779253244122e", "a42660b42eda4ba0ef07f638e08e35c9d6b49b33d954b83b035a77218ba02c");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.32395895110696504d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 3.0601467454468624E-4d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-1.2720510827569682d));
// 
//   }

  public void test257() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test257"); }


    float[] var1 = new float[] { 10.0f};
    float[] var4 = new float[] { 0.0f, (-1.0f)};
    float[] var7 = new float[] { 0.0f, 100.0f};
    boolean var8 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var4, var7);
    boolean var9 = org.apache.commons.math3.util.MathArrays.equals(var1, var7);
    float[] var12 = new float[] { (-1.0f), 1.0f};
    boolean var13 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var1, var12);
    float[] var14 = null;
    float[] var16 = new float[] { 10.0f};
    float[] var19 = new float[] { 0.0f, (-1.0f)};
    float[] var22 = new float[] { 0.0f, 100.0f};
    boolean var23 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var19, var22);
    boolean var24 = org.apache.commons.math3.util.MathArrays.equals(var16, var22);
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var14, var16);
    boolean var26 = org.apache.commons.math3.util.MathArrays.equals(var12, var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var23 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);

  }

  public void test258() {}
//   public void test258() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test258"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextCauchy((-0.6044871530760823d), 5.704309058613993d);
//     double var10 = var0.nextUniform(0.407741687198951d, 1.4387505701387593d, false);
//     java.lang.String var12 = var0.nextHexString(62);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var0.nextBinomial(43, 2.755734400837643d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 99);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-2.957741088833521d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.5529953648751098d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "83d1b6fae4152c624a0669144872059a257220cb794f24b29b1b2621dff840"+ "'", var12.equals("83d1b6fae4152c624a0669144872059a257220cb794f24b29b1b2621dff840"));
// 
//   }

  public void test259() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test259"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    var2.reSeed((-1L));
    var2.reSeed(100L);
    double var12 = var2.nextCauchy((-334.56309673916184d), 0.11407385423536498d);
    double var15 = var2.nextGaussian(0.9692669377133449d, 54745.822302454384d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var12 == (-334.73040418701044d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == (-37807.751602013566d));

  }

  public void test260() {}
//   public void test260() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test260"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     java.lang.String var6 = var0.nextSecureHexString(88);
//     var0.reSeedSecure(8026008374386375277L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var11 = var0.nextSecureLong(369960311448764288L, 108L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-8.881087386191819d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7aaa6f2dc1dd16d54b0ee1"+ "'", var4.equals("7aaa6f2dc1dd16d54b0ee1"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "e97e7ff5d3d886135e8fd424dba5c4378792ee18ed13a849b352bc8b1ac81a5de1232b88c53e60222e10ad1f"+ "'", var6.equals("e97e7ff5d3d886135e8fd424dba5c4378792ee18ed13a849b352bc8b1ac81a5de1232b88c53e60222e10ad1f"));
// 
//   }

  public void test261() {}
//   public void test261() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test261"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     double var9 = var0.nextCauchy(0.08430081831437178d, 0.407741687198951d);
//     double var11 = var0.nextT(149.06382668435472d);
//     double var14 = var0.nextF(1.5408118860052713d, 0.6862627241836179d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var0.nextInt(6, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 84);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.09824859833123023d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-2.304437513520285d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.3498247647874155d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 32.15503869794711d);
// 
//   }

  public void test262() {}
//   public void test262() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test262"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       java.lang.String var8 = var0.nextHexString(0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 73);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.15219360812993665d));
// 
//   }

  public void test263() {}
//   public void test263() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test263"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var4 = var1.nextInt(10, 100);
//     double var6 = var1.nextExponential(10.0d);
//     org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)"255737ca0aa76cd64c486046c09bb4241de9d17d6a15fad4cb3ac04c20bfb9ce320daaebb6e9d68f18f5234", (java.lang.Object)var1);
//     var1.reSeedSecure();
//     java.lang.String var10 = var1.nextSecureHexString(47);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var1.nextUniform(5.2935374176612715d, (-5.144340331950409E15d), false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 21.449231310040467d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var10 + "' != '" + "eb8c1d197f7cb9402489bf0b3d576b9b06117e7b9f0eddf"+ "'", var10.equals("eb8c1d197f7cb9402489bf0b3d576b9b06117e7b9f0eddf"));
// 
//   }

  public void test264() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test264"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(2, 87);
    int var3 = var2.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 87);

  }

  public void test265() {}
//   public void test265() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test265"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     double var9 = var0.nextCauchy(0.08430081831437178d, 0.407741687198951d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var0.nextUniform(0.013754611873402173d, 1.0252073473582036E-4d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 18);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.6769927129148723d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 5.905983313877651d);
// 
//   }

  public void test266() {}
//   public void test266() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test266"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var6.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var10 = var6.nextLong(8026008374386375277L, 1L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.5080204994860626d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
// 
//   }

  public void test267() {}
//   public void test267() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test267"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     byte[] var8 = new byte[] { (byte)1};
//     var1.nextBytes(var8);
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var10.nextUniform(54745.822302454384d, 0.3398307785317276d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.7787870769143767d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
// 
//   }

  public void test268() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test268"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    var2.reSeedSecure(100L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var2.nextWeibull(1.1054197636303182d, (-0.4148817263771911d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);

  }

  public void test269() {}
//   public void test269() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test269"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
//     double var18 = org.apache.commons.math3.util.MathArrays.distance1(var8, var12);
//     double[] var19 = null;
//     double[] var23 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var27 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var28 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var23, var27);
//     boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var19, var27);
//     double var30 = org.apache.commons.math3.util.MathArrays.safeNorm(var27);
//     double[] var34 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var38 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var39 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var34, var38);
//     double[] var40 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var27, var34);
//     boolean var41 = org.apache.commons.math3.util.MathArrays.equals(var12, var34);
//     double[] var42 = null;
//     double var43 = org.apache.commons.math3.util.MathArrays.distance(var34, var42);
// 
//   }

  public void test270() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test270"); }


    double[] var0 = null;
    double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
    boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
    double[] var14 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var18 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var22 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var23 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var18, var22);
    double var24 = org.apache.commons.math3.util.MathArrays.distance1(var14, var23);
    boolean var25 = org.apache.commons.math3.util.MathArrays.equals(var8, var23);
    double[] var26 = null;
    double[] var30 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var34 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var35 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var30, var34);
    boolean var36 = org.apache.commons.math3.util.MathArrays.equals(var26, var34);
    double var37 = org.apache.commons.math3.util.MathArrays.safeNorm(var34);
    double[] var41 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var45 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var46 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var41, var45);
    double[] var50 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var54 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var55 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var50, var54);
    double[] var56 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var45, var54);
    double[] var57 = null;
    boolean var58 = org.apache.commons.math3.util.MathArrays.equals(var54, var57);
    double[] var62 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var66 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var70 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var71 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var66, var70);
    double var72 = org.apache.commons.math3.util.MathArrays.distance1(var62, var71);
    boolean var73 = org.apache.commons.math3.util.MathArrays.equals(var54, var62);
    double var74 = org.apache.commons.math3.util.MathArrays.distance1(var34, var54);
    double[] var78 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var82 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var83 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var78, var82);
    double[] var87 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var91 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var92 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var87, var91);
    double[] var93 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var82, var91);
    double var94 = org.apache.commons.math3.util.MathArrays.distance(var54, var82);
    double[] var95 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var8, var54);
    double[] var96 = org.apache.commons.math3.util.MathArrays.copyOf(var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var34);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var36 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var45);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var56);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var58 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var66);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var70);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var71);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var72 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var73 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var74 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var78);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var82);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var83);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var87);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var91);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var92);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var93);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var94 == 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var95);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var96);

  }

  public void test271() {}
//   public void test271() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test271"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     int var5 = var0.nextSecureInt((-1), 33);
//     long var8 = var0.nextSecureLong(1L, 100L);
//     var0.reSeed((-56139359032789495L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextSecureInt(86, 20);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1491.3961102928993d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 69L);
// 
//   }

  public void test272() {}
//   public void test272() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test272"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     double var6 = var1.nextDouble();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.537606467905246d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.7247668141114612d);
// 
//   }

  public void test273() {}
//   public void test273() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test273"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     var0.reSeed();
//     int var12 = var0.nextHypergeometric(75, 0, 3);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var0.nextZipf(32, (-0.5903111221322579d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 5.052935465571613d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.33937051339637025d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0);
// 
//   }

  public void test274() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test274"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(1.5146528018297123d, (-0.05475404077564316d), (-0.8258598346981539d), (-0.14097693123713528d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.03349382385542734d);

  }

  public void test275() {}
//   public void test275() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test275"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextT(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.9836413026924906d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "aeff1660f0f52b208eafa2682aa1c0fe53d0afcc63a4eac7cfc9fd1efb328ed746051ae17182d0ee46eb932"+ "'", var8.equals("aeff1660f0f52b208eafa2682aa1c0fe53d0afcc63a4eac7cfc9fd1efb328ed746051ae17182d0ee46eb932"));
// 
//   }

  public void test276() {}
//   public void test276() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test276"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     int var6 = var0.nextZipf(52, 1.4276096462825826E-9d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextHypergeometric(0, 13, 71);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 30);
// 
//   }

  public void test277() {}
//   public void test277() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test277"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.012774969105543068d, 0.09455763871444445d);
//     double var7 = var0.nextExponential(0.4301403036978695d);
//     double var10 = var0.nextCauchy((-9.743086442592038E10d), 0.10684763416654564d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var13 = var0.nextLong(374001257020227328L, 1L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-256641.88172696382d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.3406274412026122E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.24047771254364336d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-9.743086442603528E10d));
// 
//   }

  public void test278() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test278"); }


    float[] var0 = null;
    float[] var2 = new float[] { 10.0f};
    float[] var5 = new float[] { 0.0f, (-1.0f)};
    float[] var8 = new float[] { 0.0f, 100.0f};
    boolean var9 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var5, var8);
    boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var2, var8);
    boolean var11 = org.apache.commons.math3.util.MathArrays.equals(var0, var2);
    float[] var14 = new float[] { 0.0f, (-1.0f)};
    float[] var17 = new float[] { 0.0f, 100.0f};
    boolean var18 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var14, var17);
    float[] var19 = null;
    boolean var20 = org.apache.commons.math3.util.MathArrays.equals(var17, var19);
    boolean var21 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var2, var19);
    float[] var22 = new float[] { };
    float[] var25 = new float[] { 0.0f, (-1.0f)};
    float[] var28 = new float[] { 0.0f, 100.0f};
    boolean var29 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var25, var28);
    boolean var30 = org.apache.commons.math3.util.MathArrays.equals(var22, var25);
    boolean var31 = org.apache.commons.math3.util.MathArrays.equals(var19, var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var20 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var21 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);

  }

  public void test279() {}
//   public void test279() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test279"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var9 = var6.nextLong(1L, 5804136433509186560L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var11 = var6.nextPoisson(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.9448669510786125d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 3780301342741635072L);
// 
//   }

  public void test280() {}
//   public void test280() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test280"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     double var10 = var0.nextF(102.0d, 9900.0d);
//     double var12 = var0.nextT(223.0d);
//     long var15 = var0.nextLong(14L, 2563274223793255424L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var18 = var0.nextSecureLong(24L, 24L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.029922531943247d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.3897355645231488d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.2566797887795786d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.5069583585089396d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 514411848893168576L);
// 
//   }

  public void test281() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test281"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(24L);
    int var2 = var1.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == (-1612642752));

  }

  public void test282() {}
//   public void test282() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test282"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var4 = var1.nextInt(10, 100);
//     double var6 = var1.nextExponential(10.0d);
//     org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)"255737ca0aa76cd64c486046c09bb4241de9d17d6a15fad4cb3ac04c20bfb9ce320daaebb6e9d68f18f5234", (java.lang.Object)var1);
//     java.lang.Object var8 = var7.getFirst();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3.4785048692046914d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "255737ca0aa76cd64c486046c09bb4241de9d17d6a15fad4cb3ac04c20bfb9ce320daaebb6e9d68f18f5234"+ "'", var8.equals("255737ca0aa76cd64c486046c09bb4241de9d17d6a15fad4cb3ac04c20bfb9ce320daaebb6e9d68f18f5234"));
// 
//   }

  public void test283() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test283"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination((-0.45868556584517606d), 1.172276254234819E-9d, 2.923657016815099d, 0.0339842858777826d, 0.0028269929560076706d, 2.1874856059935905d, 0.026429111303666656d, 0.30767857782779273d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.11367407310899982d);

  }

  public void test284() {}
//   public void test284() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test284"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var10 = var0.nextPermutation(24, 66);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.1069069258138522d));
// 
//   }

  public void test285() {}
//   public void test285() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test285"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var12 = var9.nextInt(10, 100);
//     double var15 = var9.nextUniform((-1.0d), 1.0d);
//     var9.reSeedSecure();
//     org.apache.commons.math3.util.Pair var17 = new org.apache.commons.math3.util.Pair((java.lang.Object)var8, (java.lang.Object)var9);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var20 = var9.nextGaussian(0.3694532899986669d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 27);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.5548497581714384d));
// 
//   }

  public void test286() {}
//   public void test286() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test286"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var3 = var0.nextCauchy(0.0d, 0.4841123961597962d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var6 = var0.nextInt(51, 0);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 2.5250818793484906d);
// 
//   }

  public void test287() {}
//   public void test287() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test287"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     java.lang.String var5 = var0.nextHexString(87);
//     int var8 = var0.nextZipf(70, 0.6245596043465632d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var11 = var0.nextPermutation(0, 11);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 97);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "3924412a793e4e88fcec24c4b93bde7bad9d223087f04fbd3156c7006290937186b4c415412f6e7f6f7d66d"+ "'", var5.equals("3924412a793e4e88fcec24c4b93bde7bad9d223087f04fbd3156c7006290937186b4c415412f6e7f6f7d66d"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
// 
//   }

  public void test288() {}
//   public void test288() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test288"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     org.apache.commons.math3.distribution.RealDistribution var3 = null;
//     double var4 = var2.nextInversionDeviate(var3);
// 
//   }

  public void test289() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test289"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed(5804136433509186560L);
    double var7 = var2.nextCauchy(3.829127667332408d, 0.7578669481310135d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 2.0652764284882417d);

  }

  public void test290() {}
//   public void test290() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test290"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(0.08430081831437178d);
//     double var6 = var1.nextUniform((-0.32577132027868605d), 4.713414225479933d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var9 = var1.nextSecureLong(7741999113339246307L, (-1L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 0.0d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4.200395280339416d);
// 
//   }

  public void test291() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test291"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)1126.0675830210619d, (java.lang.Number)6.219562570799601d, (java.lang.Number)69);

  }

  public void test292() {}
//   public void test292() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test292"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
//     boolean var10 = org.apache.commons.math3.util.MathArrays.equals(var0, var8);
//     double var11 = org.apache.commons.math3.util.MathArrays.safeNorm(var8);
//     double[] var15 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var19 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var23 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var24 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var19, var23);
//     double var25 = org.apache.commons.math3.util.MathArrays.distance1(var15, var24);
//     double[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var24, 88);
//     double var28 = org.apache.commons.math3.util.MathArrays.distanceInf(var8, var24);
//     double[] var32 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var36 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var37 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var32, var36);
//     org.apache.commons.math3.random.RandomDataGenerator var38 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var41 = var38.nextInt(10, 100);
//     double var44 = var38.nextUniform((-1.0d), 1.0d);
//     var38.reSeedSecure();
//     org.apache.commons.math3.util.Pair var46 = new org.apache.commons.math3.util.Pair((java.lang.Object)var37, (java.lang.Object)var38);
//     double[] var47 = org.apache.commons.math3.util.MathArrays.ebeAdd(var8, var37);
//     double[] var51 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var55 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var56 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var51, var55);
//     double[] var60 = new double[] { 10.0d, (-1.0d), (-1.0d)};
//     double var61 = org.apache.commons.math3.util.MathArrays.safeNorm(var60);
//     double[][] var62 = new double[][] { var60};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var51, var62);
//     double var64 = org.apache.commons.math3.util.MathArrays.safeNorm(var51);
//     double[] var68 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var72 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var76 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var77 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var72, var76);
//     double var78 = org.apache.commons.math3.util.MathArrays.distance1(var68, var77);
//     double[] var80 = org.apache.commons.math3.util.MathArrays.copyOf(var77, 88);
//     double[] var81 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var51, var77);
//     double[] var82 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var37, var51);
//     double[] var83 = null;
//     double[] var84 = org.apache.commons.math3.util.MathArrays.ebeDivide(var37, var83);
// 
//   }

  public void test293() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test293"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(1.487086298741032E-9d, 0.9415837925032302d, (-0.292640940848738d), (-370.93054277619296d), (-0.01498759451409439d), (-0.6044871530760823d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 108.55852283729766d);

  }

  public void test294() {}
//   public void test294() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test294"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var6.reSeedSecure((-1L));
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var6.nextGaussian(0.06469997385775762d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.42969692199050896d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
// 
//   }

  public void test295() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test295"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c((-3200518016629555151L));

  }

  public void test296() {}
//   public void test296() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test296"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var4 = var1.nextInt(10, 100);
//     double var6 = var1.nextExponential(10.0d);
//     org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)"255737ca0aa76cd64c486046c09bb4241de9d17d6a15fad4cb3ac04c20bfb9ce320daaebb6e9d68f18f5234", (java.lang.Object)var1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var1.nextGaussian(0.3038706340483591d, (-0.08824970291025913d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 100);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 8.37172525589682d);
// 
//   }

  public void test297() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test297"); }


    float[] var0 = null;
    float[] var1 = null;
    boolean var2 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var0, var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test298() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test298"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Comparable[] var2 = new java.lang.Comparable[] { (short)1};
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var3, false);
    org.apache.commons.math3.util.MathArrays.OrderDirection var6 = null;
    boolean var8 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var6, true);
    org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
    boolean var11 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var9, false);
    org.apache.commons.math3.exception.MathInternalError var12 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == true);

  }

  public void test299() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test299"); }


    double[] var0 = null;
    double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
    double[] var13 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var17 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var13, var17);
    double var19 = org.apache.commons.math3.util.MathArrays.distance1(var9, var13);
    double[] var23 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var27 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var28 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var23, var27);
    double[] var32 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var36 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var37 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var32, var36);
    double var38 = org.apache.commons.math3.util.MathArrays.distance1(var28, var32);
    double[] var39 = null;
    double[] var43 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var47 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var48 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var43, var47);
    boolean var49 = org.apache.commons.math3.util.MathArrays.equals(var39, var47);
    double var50 = org.apache.commons.math3.util.MathArrays.safeNorm(var47);
    double[] var54 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var58 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var59 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var54, var58);
    double[] var60 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var47, var54);
    boolean var61 = org.apache.commons.math3.util.MathArrays.equals(var32, var54);
    double[] var62 = org.apache.commons.math3.util.MathArrays.copyOf(var32);
    double[][] var63 = new double[][] { var32};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var9, var63);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.sortInPlace(var0, var63);
      fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException");
    } catch (org.apache.commons.math3.exception.NullArgumentException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 102.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var38 == 102.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var43);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var54);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var61 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);

  }

  public void test300() {}
//   public void test300() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test300"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextZipf((-1102768644), 1.327000036267693d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 54);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.15085314306760944d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "3d49a5d2a2d1bab903c8a58efd08d014591d6b105f458a8ddc907f976bc1c762a1d3510103e6473bca740ab"+ "'", var8.equals("3d49a5d2a2d1bab903c8a58efd08d014591d6b105f458a8ddc907f976bc1c762a1d3510103e6473bca740ab"));
// 
//   }

  public void test301() {}
//   public void test301() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test301"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextLong((-1L), 10L);
//     var2.reSeed((-1L));
//     double var9 = var2.nextExponential(100.0d);
//     var2.reSeed(39L);
//     double var14 = var2.nextCauchy(1.7451931429974368d, 4979382.8531437665d);
//     org.apache.commons.math3.distribution.IntegerDistribution var15 = null;
//     int var16 = var2.nextInversionDeviate(var15);
// 
//   }

  public void test302() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test302"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    int[] var7 = new int[] { };
    var1.setSeed(var7);
    org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    boolean var10 = var1.nextBoolean();
    int var11 = var1.nextInt();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-848192168));

  }

  public void test303() {}
//   public void test303() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test303"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(25);
//     java.util.Collection var5 = null;
//     java.lang.Object[] var7 = var0.nextSample(var5, 5);
// 
//   }

  public void test304() {}
//   public void test304() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test304"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     org.apache.commons.math3.distribution.IntegerDistribution var4 = null;
//     int var5 = var2.nextInversionDeviate(var4);
// 
//   }

  public void test305() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test305"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(51);
    var1.setSeed(5804136433509186560L);

  }

  public void test306() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test306"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure(100L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var7 = var2.nextPascal(0, 4.713414225479933d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test307() {}
//   public void test307() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test307"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var12 = var0.nextBinomial(92, (-3.672203955332186d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 88);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.6999020850133664d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "4c52205f5cc533426053c8096d0a3b6f8c65337eaf23be7c4fe63eb79df9f278c0458b2293a17f639757ffc"+ "'", var8.equals("4c52205f5cc533426053c8096d0a3b6f8c65337eaf23be7c4fe63eb79df9f278c0458b2293a17f639757ffc"));
// 
//   }

  public void test308() {}
//   public void test308() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test308"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextLong((-1L), 10L);
//     var2.reSeed((-1L));
//     var2.reSeed(100L);
//     double var12 = var2.nextCauchy((-334.56309673916184d), 0.11407385423536498d);
//     org.apache.commons.math3.distribution.IntegerDistribution var13 = null;
//     int var14 = var2.nextInversionDeviate(var13);
// 
//   }

  public void test309() {}
//   public void test309() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test309"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeedSecure(100L);
//     var2.reSeedSecure(1L);
//     java.lang.String var8 = var2.nextSecureHexString(2);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var2.nextGamma(0.0d, 0.013754611873402173d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "74"+ "'", var8.equals("74"));
// 
//   }

  public void test310() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test310"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    var1.clear();
    boolean var3 = var1.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == true);

  }

  public void test311() {}
//   public void test311() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test311"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var12 = var9.nextInt(10, 100);
//     double var15 = var9.nextUniform((-1.0d), 1.0d);
//     var9.reSeedSecure();
//     org.apache.commons.math3.util.Pair var17 = new org.apache.commons.math3.util.Pair((java.lang.Object)var8, (java.lang.Object)var9);
//     int var20 = var9.nextSecureInt(20, 78);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var22 = var9.nextExponential((-1.5189910320170308d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 94);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.5731939808746596d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 75);
// 
//   }

  public void test312() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test312"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)(-2.8440414054821423d), (java.lang.Number)29.538354013273814d, false);

  }

  public void test313() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test313"); }


    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)100, (java.lang.Object)10.0d);
    java.lang.Object var3 = var2.getSecond();
    java.lang.Object var4 = var2.getFirst();
    java.lang.Object var5 = var2.getKey();
    java.lang.Object var6 = var2.getFirst();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 10.0d+ "'", var3.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + (short)100+ "'", var4.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (short)100+ "'", var5.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + (short)100+ "'", var6.equals((short)100));

  }

  public void test314() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test314"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    var2.reSeedSecure(100L);
    java.lang.String var9 = var2.nextHexString(53);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var2.nextUniform(0.0d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + "662ab224c609e5c9ef47e16ab5a751468d6b7db870cac522c8500"+ "'", var9.equals("662ab224c609e5c9ef47e16ab5a751468d6b7db870cac522c8500"));

  }

  public void test315() {}
//   public void test315() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test315"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var0.nextSecureInt(68, (-1612642752));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 18.07429852441478d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.2234058823622435d);
// 
//   }

  public void test316() {}
//   public void test316() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test316"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     double var8 = var2.nextT(11.36369913641775d);
//     int[] var11 = var2.nextPermutation(33, 31);
//     int[] var14 = new int[] { 1, 0};
//     int[] var15 = null;
//     org.apache.commons.math3.random.Well19937c var16 = new org.apache.commons.math3.random.Well19937c(var15);
//     double var17 = var16.nextGaussian();
//     int[] var20 = new int[] { 0, 1};
//     var16.setSeed(var20);
//     double var22 = org.apache.commons.math3.util.MathArrays.distance(var14, var20);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var23 = org.apache.commons.math3.util.MathArrays.distanceInf(var11, var20);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.2663703589705997d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == (-1.149398640489006d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == 1.4142135623730951d);
// 
//   }

  public void test317() {}
//   public void test317() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test317"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var12 = var9.nextInt(10, 100);
//     double var15 = var9.nextUniform((-1.0d), 1.0d);
//     var9.reSeedSecure();
//     org.apache.commons.math3.util.Pair var17 = new org.apache.commons.math3.util.Pair((java.lang.Object)var8, (java.lang.Object)var9);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var21 = var9.nextUniform(0.0d, (-37807.751602013566d), false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 31);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == (-0.761569309756259d));
// 
//   }

  public void test318() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test318"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var7, 21.869847397459292d);
    double[] var24 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var28 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var29 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var24, var28);
    double[] var33 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var37 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var38 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var33, var37);
    double var39 = org.apache.commons.math3.util.MathArrays.distance1(var29, var33);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.distribution.DiscreteRealDistribution var40 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var7, var29);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == 102.0d);

  }

  public void test319() {}
//   public void test319() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test319"); }
// 
// 
//     org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)100, (java.lang.Object)10.0d);
//     java.lang.Object var3 = var2.getSecond();
//     java.lang.Object var4 = var2.getFirst();
//     double[] var8 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var12 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var13 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var8, var12);
//     org.apache.commons.math3.random.RandomDataGenerator var14 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var17 = var14.nextInt(10, 100);
//     double var20 = var14.nextUniform((-1.0d), 1.0d);
//     var14.reSeedSecure();
//     org.apache.commons.math3.util.Pair var22 = new org.apache.commons.math3.util.Pair((java.lang.Object)var13, (java.lang.Object)var14);
//     boolean var23 = var2.equals((java.lang.Object)var14);
//     java.lang.Object var24 = var2.getValue();
//     java.lang.Object var25 = var2.getFirst();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + 10.0d+ "'", var3.equals(10.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + (short)100+ "'", var4.equals((short)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 99);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == (-0.2036590265768301d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == false);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var24 + "' != '" + 10.0d+ "'", var24.equals(10.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var25 + "' != '" + (short)100+ "'", var25.equals((short)100));
// 
//   }

  public void test320() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test320"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Comparable[] var2 = new java.lang.Comparable[] { (short)1};
    org.apache.commons.math3.util.MathArrays.OrderDirection var3 = null;
    boolean var5 = org.apache.commons.math3.util.MathArrays.<java.lang.Comparable>isMonotonic(var2, var3, false);
    org.apache.commons.math3.exception.MathInternalError var6 = new org.apache.commons.math3.exception.MathInternalError(var0, (java.lang.Object[])var2);
    org.apache.commons.math3.exception.util.ExceptionContext var7 = var6.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test321() {}
//   public void test321() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test321"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     double var8 = var2.nextT(11.36369913641775d);
//     int[] var11 = var2.nextPermutation(33, 31);
//     var2.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var2.nextPascal(0, 8.884353152082793d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 14);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0.4186432652070932d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
// 
//   }

  public void test322() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test322"); }


    org.apache.commons.math3.exception.MathArithmeticException var0 = new org.apache.commons.math3.exception.MathArithmeticException();
    java.lang.Throwable[] var1 = var0.getSuppressed();
    org.apache.commons.math3.exception.util.ExceptionContext var2 = var0.getContext();
    org.apache.commons.math3.exception.MathInternalError var3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable)var0);
    org.apache.commons.math3.exception.util.ExceptionContext var4 = var0.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);

  }

  public void test323() {}
//   public void test323() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test323"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     int var7 = var0.nextSecureInt(16, 34);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextExponential((-0.5883540186360512d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 3.4589310689412516d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "574e97431991b8bf0e3fba"+ "'", var4.equals("574e97431991b8bf0e3fba"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 24);
// 
//   }

  public void test324() {}
//   public void test324() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test324"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var6.reSeedSecure();
//     var6.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var11 = var6.nextPermutation((-1612642752), 61);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.0452998002128344d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
// 
//   }

  public void test325() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test325"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong(1L, 8026008374386375277L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var7 = var2.nextT((-988.6092885864007d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5507950371326924800L);

  }

  public void test326() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test326"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(7L);
    var1.setSeed(0L);

  }

  public void test327() {}
//   public void test327() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test327"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed(5804136433509186560L);
//     org.apache.commons.math3.distribution.RealDistribution var5 = null;
//     double var6 = var2.nextInversionDeviate(var5);
// 
//   }

  public void test328() {}
//   public void test328() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test328"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var6.reSeedSecure((-1L));
//     var6.reSeed(14L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var6.nextZipf(70, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.5804954691557591d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
// 
//   }

  public void test329() {}
//   public void test329() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test329"); }
// 
// 
//     double[] var0 = null;
//     double[] var2 = org.apache.commons.math3.util.MathArrays.copyOf(var0, 21);
// 
//   }

  public void test330() {}
//   public void test330() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test330"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     int[] var5 = new int[] { 100, 10, (-1)};
//     var1.setSeed(var5);
//     int[] var7 = new int[] { };
//     var1.setSeed(var7);
//     int[] var9 = null;
//     int var10 = org.apache.commons.math3.util.MathArrays.distanceInf(var7, var9);
//     int[] var12 = org.apache.commons.math3.util.MathArrays.copyOf(var7, 66);
//     int[] var13 = org.apache.commons.math3.util.MathArrays.copyOf(var12);
//     org.apache.commons.math3.random.Well19937c var15 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var16 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var15);
//     var16.reSeed();
//     int var20 = var16.nextZipf(18, 0.10832690038004085d);
//     double var22 = var16.nextT(11.36369913641775d);
//     int[] var25 = var16.nextPermutation(33, 31);
//     int[] var27 = org.apache.commons.math3.util.MathArrays.copyOf(var25, 0);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var28 = org.apache.commons.math3.util.MathArrays.distance(var13, var27);
//       fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException");
//     } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var7);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 17);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var22 == (-1.1213225119307009d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var25);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var27);
// 
//   }

  public void test331() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test331"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var13 = org.apache.commons.math3.util.MathArrays.safeNorm(var12);
    double[][] var14 = new double[][] { var12};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var3, var14);
    double var16 = org.apache.commons.math3.util.MathArrays.safeNorm(var3);
    double[] var20 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var24 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var28 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var29 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var24, var28);
    double var30 = org.apache.commons.math3.util.MathArrays.distance1(var20, var29);
    double[] var32 = org.apache.commons.math3.util.MathArrays.copyOf(var29, 88);
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var3, var29);
    double[] var37 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var41 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var42 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var37, var41);
    double[] var46 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var47 = org.apache.commons.math3.util.MathArrays.safeNorm(var46);
    double[][] var48 = new double[][] { var46};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var37, var48);
    double var50 = org.apache.commons.math3.util.MathArrays.safeNorm(var37);
    double var51 = org.apache.commons.math3.util.MathArrays.distance1(var33, var37);
    double[] var55 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var59 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var60 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var55, var59);
    double[] var61 = org.apache.commons.math3.util.MathArrays.ebeAdd(var37, var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var16 == 1.7320508075688772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var37);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var47 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var48);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var50 == 1.7320508075688772d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var51 == 106.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);

  }

  public void test332() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test332"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.4301403036978695d);
    boolean var2 = var1.getBoundIsAllowed();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var2 == true);

  }

  public void test333() {}
//   public void test333() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test333"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     int var8 = var1.nextInt(18);
//     int var10 = var1.nextInt(54);
//     float var11 = var1.nextFloat();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.048635280582399396d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 26);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.69278264f);
// 
//   }

  public void test334() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test334"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var7.nextGaussian((-0.45868556584517606d), (-0.8211092390774544d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);

  }

  public void test335() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test335"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong(1L, 8026008374386375277L);
    var2.reSeedSecure(7L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var2.nextF(6.309299255664245d, (-0.9438041885292305d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5507950371326924800L);

  }

  public void test336() {}
//   public void test336() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test336"); }
// 
// 
//     double[] var0 = null;
//     org.apache.commons.math3.util.MathArrays.OrderDirection var1 = null;
//     boolean var4 = org.apache.commons.math3.util.MathArrays.checkOrder(var0, var1, true, true);
// 
//   }

  public void test337() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test337"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int[] var5 = var2.nextPermutation(3, 22);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test338() {}
//   public void test338() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test338"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     double var7 = var1.nextGaussian();
//     var1.clear();
//     org.apache.commons.math3.random.RandomDataImpl var9 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var1.nextDouble();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.125285173880562d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 1.327000036267693d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 0.9635745263191828d);
// 
//   }

  public void test339() {}
//   public void test339() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test339"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     java.lang.String var6 = var0.nextSecureHexString(88);
//     var0.reSeedSecure(8026008374386375277L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextWeibull((-0.6851952826289146d), 0.11681967467915401d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1783.2878505993083d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "26e6dbee6dcc3a6b714206"+ "'", var4.equals("26e6dbee6dcc3a6b714206"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "c0e2754db93ca5aa0b0f15cd88594ca71f9df3b29dddcf771ad15940c6950ccce8d8688852acdfdf34f492cc"+ "'", var6.equals("c0e2754db93ca5aa0b0f15cd88594ca71f9df3b29dddcf771ad15940c6950ccce8d8688852acdfdf34f492cc"));
// 
//   }

  public void test340() {}
//   public void test340() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test340"); }
// 
// 
//     double[] var0 = null;
//     java.lang.Number var1 = null;
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var7 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
//     boolean var8 = var7.getStrict();
//     org.apache.commons.math3.util.MathArrays.OrderDirection var9 = var7.getDirection();
//     org.apache.commons.math3.exception.NonMonotonicSequenceException var11 = new org.apache.commons.math3.exception.NonMonotonicSequenceException(var1, (java.lang.Number)0.8055186938534216d, 60, var9, true);
//     boolean var14 = org.apache.commons.math3.util.MathArrays.checkOrder(var0, var9, false, false);
// 
//   }

  public void test341() {}
//   public void test341() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test341"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextLong((-1L), 10L);
//     var2.reSeed((-1L));
//     var2.reSeed(100L);
//     double var12 = var2.nextCauchy((-334.56309673916184d), 0.11407385423536498d);
//     java.util.Collection var13 = null;
//     java.lang.Object[] var15 = var2.nextSample(var13, 29);
// 
//   }

  public void test342() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test342"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)(-75.62470873108684d));

  }

  public void test343() {}
//   public void test343() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test343"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     java.lang.String var6 = var0.nextSecureHexString(88);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var9 = var0.nextLong(0L, (-1952321163872933406L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-5.38718017393532d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7a57e757e94db0b7915845"+ "'", var4.equals("7a57e757e94db0b7915845"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "27c4d80a9a5b9c516b219b17dc8d24be250a7a78408eb8244f990b0066ce5c116fc02a2f7e9e8bd68e28f301"+ "'", var6.equals("27c4d80a9a5b9c516b219b17dc8d24be250a7a78408eb8244f990b0066ce5c116fc02a2f7e9e8bd68e28f301"));
// 
//   }

  public void test344() {}
//   public void test344() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test344"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 2);
// 
//   }

  public void test345() {}
//   public void test345() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test345"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var6.reSeedSecure();
//     var6.reSeedSecure();
//     int var11 = var6.nextSecureInt(20, 71);
//     long var14 = var6.nextLong(0L, 10L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var17 = var6.nextSecureInt(63, 29);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-0.30832386497687575d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 22);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 5L);
// 
//   }

  public void test346() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test346"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(0.22333706539912798d, 0.0d, 0.0d, 28.46111736987342d, 5842551.508144901d, 1.934238008197349E-9d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.01130088519190461d);

  }

  public void test347() {}
//   public void test347() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test347"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     double var6 = var0.nextChiSquare(0.012774969105543068d);
//     int[] var9 = var0.nextPermutation(43, 3);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextUniform(1126.0675830210619d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 9.350559972236074E12d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "098312576c6dd867f6c366"+ "'", var4.equals("098312576c6dd867f6c366"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 1.979876021035755E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
// 
//   }

  public void test348() {}
//   public void test348() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test348"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     double[] var6 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var10 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var11 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var6, var10);
//     double[] var15 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var19 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var20 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var15, var19);
//     double var21 = org.apache.commons.math3.util.MathArrays.distance1(var11, var15);
//     double[] var25 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var29 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var33 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var34 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var29, var33);
//     double var35 = org.apache.commons.math3.util.MathArrays.distance1(var25, var34);
//     double[] var37 = org.apache.commons.math3.util.MathArrays.normalizeArray(var34, 0.0d);
//     double[] var38 = org.apache.commons.math3.util.MathArrays.copyOf(var34);
//     double var39 = org.apache.commons.math3.util.MathArrays.distance1(var11, var34);
//     double var40 = org.apache.commons.math3.util.MathArrays.safeNorm(var11);
//     double[] var42 = org.apache.commons.math3.util.MathArrays.normalizeArray(var11, 0.0d);
//     double[] var43 = null;
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var44 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var42, var43);
// 
//   }

  public void test349() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test349"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    java.lang.Number var4 = var3.getPrevious();
    java.lang.Number var5 = var3.getArgument();
    int var6 = var3.getIndex();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 0.0f+ "'", var4.equals(0.0f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + (-1)+ "'", var5.equals((-1)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0);

  }

  public void test350() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test350"); }


    java.lang.Number var1 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)66, var1, true);
    java.lang.Number var4 = var3.getMin();
    boolean var5 = var3.getBoundIsAllowed();
    org.apache.commons.math3.exception.util.ExceptionContext var6 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);

  }

  public void test351() {}
//   public void test351() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test351"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 61, 20);
//     java.lang.String var4 = var3.toString();
// 
//   }

  public void test352() {}
//   public void test352() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test352"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     byte[] var8 = new byte[] { (byte)1};
//     var1.nextBytes(var8);
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var10.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var10.nextHypergeometric((-1983603608), 61, 27);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.6190351225342927d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
// 
//   }

  public void test353() {}
//   public void test353() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test353"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     double var6 = var0.nextChiSquare(0.012774969105543068d);
//     java.util.Collection var7 = null;
//     java.lang.Object[] var9 = var0.nextSample(var7, 32);
// 
//   }

  public void test354() {}
//   public void test354() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test354"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGaussian(0.0d, 10.0d);
//     int var14 = var0.nextSecureInt(22, 75);
//     java.lang.String var16 = var0.nextHexString(33);
//     int var20 = var0.nextHypergeometric(73, 18, 12);
//     java.util.Collection var21 = null;
//     java.lang.Object[] var23 = var0.nextSample(var21, 30);
// 
//   }

  public void test355() {}
//   public void test355() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test355"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.012774969105543068d, 0.09455763871444445d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var0.nextPascal(15, (-0.4016759303325931d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.308636882618985d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.417736454219135E-4d);
// 
//   }

  public void test356() {}
//   public void test356() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test356"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     java.util.Collection var1 = null;
//     java.lang.Object[] var3 = var0.nextSample(var1, 61);
// 
//   }

  public void test357() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test357"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)31, (java.lang.Number)0.3980143371708322d, (java.lang.Number)0.985664f);
    java.lang.Number var5 = var4.getHi();
    java.lang.Number var6 = var4.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.985664f+ "'", var5.equals(0.985664f));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 31+ "'", var6.equals(31));

  }

  public void test358() {}
//   public void test358() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test358"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("b971894634cad8dd4b254342dabbf284a6d34c1b775dd2abb8af8242fcfe08edc4ce7d5787ef30378e7", "b971894634cad8dd4b254342dabbf284a6d34c1b775dd2abb8af8242fcfe08edc4ce7d5787ef30378e7");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.01617485246280692d);
// 
//   }

  public void test359() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test359"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)0.6989809774046034d);

  }

  public void test360() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test360"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, (-0.32577132027868605d), 0.0d, 0.9999999989253456d, 0.0d, (-5.144340331950409E15d), 0.18726212538835552d, 0.013754611873402173d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.002575717853305201d);

  }

  public void test361() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test361"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong(1L, 8026008374386375277L);
    double var8 = var2.nextGaussian(1.3621815434775926d, 0.9692669377133449d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var2.nextUniform(4.218937231588664d, 0.0d, false);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 5507950371326924800L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.1054197636303182d);

  }

  public void test362() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test362"); }


    org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var3 = var0.nextF(0.0d, (-0.8258598346981539d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test363() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test363"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, 0.0d, 4.124408130986206d, 1.1099343768922654d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 4.577822368915567d);

  }

  public void test364() {}
//   public void test364() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test364"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(51);
//     float var2 = var1.nextFloat();
//     var1.setSeed(71);
//     int var6 = var1.nextInt(3);
//     double[] var10 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var14 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var15 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var10, var14);
//     double[] var19 = new double[] { 10.0d, (-1.0d), (-1.0d)};
//     double var20 = org.apache.commons.math3.util.MathArrays.safeNorm(var19);
//     double[][] var21 = new double[][] { var19};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var10, var21);
//     double[] var23 = null;
//     double[] var27 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var31 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var32 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var27, var31);
//     boolean var33 = org.apache.commons.math3.util.MathArrays.equals(var23, var31);
//     double var34 = org.apache.commons.math3.util.MathArrays.safeNorm(var31);
//     double[] var38 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var42 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var43 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var38, var42);
//     double[] var44 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var31, var38);
//     double var45 = org.apache.commons.math3.util.MathArrays.linearCombination(var10, var44);
//     double[] var46 = null;
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var47 = new org.apache.commons.math3.distribution.DiscreteRealDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var10, var46);
// 
//   }

  public void test365() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test365"); }


    double[] var0 = null;
    double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
    double[] var13 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var17 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var13, var17);
    double var19 = org.apache.commons.math3.util.MathArrays.distance1(var9, var13);
    double[] var20 = null;
    double[] var24 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var28 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var29 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var24, var28);
    boolean var30 = org.apache.commons.math3.util.MathArrays.equals(var20, var28);
    double var31 = org.apache.commons.math3.util.MathArrays.safeNorm(var28);
    double[] var35 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var39 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var40 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var35, var39);
    double[] var41 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var28, var35);
    boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var13, var35);
    double[] var46 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var50 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var51 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var46, var50);
    double[] var55 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var59 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var60 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var55, var59);
    double[] var61 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var50, var59);
    double[] var63 = org.apache.commons.math3.util.MathArrays.normalizeArray(var59, 9900.0d);
    boolean var64 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var13, var63);
    boolean var65 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var0, var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var13);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == 102.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var29);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var39);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var40);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var41);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var50);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var51);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var55);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var60);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var63);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var64 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var65 == false);

  }

  public void test366() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test366"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    var2.reSeed((-1L));
    double var9 = var2.nextExponential(100.0d);
    var2.reSeed(39L);
    double var14 = var2.nextCauchy(1.7451931429974368d, 4979382.8531437665d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var18 = var2.nextUniform(6.226786534303597d, (-3.3781187158717527d), true);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 149.06382668435472d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == (-1.0521385758460062E7d));

  }

  public void test367() {}
//   public void test367() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test367"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     var1.setSeed(17);
//     int var5 = var1.nextInt(53);
//     long var6 = var1.nextLong();
//     java.util.List var7 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var8 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var1, var7);
// 
//   }

  public void test368() {}
//   public void test368() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test368"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     var0.reSeedSecure();
//     double var10 = var0.nextWeibull(5.2935374176612715d, 6306020.951293601d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var13 = var0.nextSecureInt(86, 29);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 75);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.2917975805000981d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 5984851.2301963d);
// 
//   }

  public void test369() {}
//   public void test369() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test369"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.util.Localizable var1 = null;
//     org.apache.commons.math3.exception.util.Localizable var2 = null;
//     java.lang.Object[] var4 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError(var2, var4);
//     org.apache.commons.math3.exception.MathIllegalArgumentException var6 = new org.apache.commons.math3.exception.MathIllegalArgumentException(var1, var4);
//     org.apache.commons.math3.exception.NullArgumentException var7 = new org.apache.commons.math3.exception.NullArgumentException(var0, var4);
//     java.lang.String var8 = var7.toString();
// 
//   }

  public void test370() {}
//   public void test370() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test370"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     double var8 = var0.nextUniform((-0.14097693123713528d), 4.1590082109255295d);
//     var0.reSeed();
//     java.lang.String var11 = var0.nextSecureHexString(83);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var15 = var0.nextBinomial(2, 1.537606467905246d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 9.782744046250901d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 2.1355435697225197E-7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1.0636578171282127d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var11 + "' != '" + "586979da8af6f43a69dcc7450254ce7f87f0aceb869180f4c1bd86a4bdc8bef9336bdca20ebc753022e"+ "'", var11.equals("586979da8af6f43a69dcc7450254ce7f87f0aceb869180f4c1bd86a4bdc8bef9336bdca20ebc753022e"));
// 
//   }

  public void test371() {}
//   public void test371() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test371"); }
// 
// 
//     double[] var0 = null;
//     double var1 = org.apache.commons.math3.util.MathArrays.safeNorm(var0);
// 
//   }

  public void test372() {}
//   public void test372() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test372"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextUniform(0.7454450602699914d, (-0.8555188580886357d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 89);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.7935712344991641d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "2eaf4b38c459403f4d0b4d2f51d0204fcb2bff161d2ced7645783f7cb2332412e8dd15e9f15ea3515fb73e1"+ "'", var8.equals("2eaf4b38c459403f4d0b4d2f51d0204fcb2bff161d2ced7645783f7cb2332412e8dd15e9f15ea3515fb73e1"));
// 
//   }

  public void test373() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test373"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)5507950371326924800L, (java.lang.Number)1.4276096462825826E-9d, (java.lang.Number)12);
    java.lang.Number var5 = var4.getHi();
    java.lang.Number var6 = var4.getArgument();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 12+ "'", var5.equals(12));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var6 + "' != '" + 5507950371326924800L+ "'", var6.equals(5507950371326924800L));

  }

  public void test374() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test374"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
    java.lang.Number var4 = var3.getMin();
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError();
    var3.addSuppressed((java.lang.Throwable)var5);
    java.lang.Number var7 = var3.getArgument();
    java.lang.Number var8 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1.0d+ "'", var4.equals(1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + (-1L)+ "'", var7.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 1.0d+ "'", var8.equals(1.0d));

  }

  public void test375() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test375"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(25, 78);

  }

  public void test376() {}
//   public void test376() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test376"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     double var9 = var0.nextCauchy(0.08430081831437178d, 0.407741687198951d);
//     double var12 = var0.nextGaussian((-36464.24236834751d), 0.1479328506264807d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var15 = var0.nextLong(14L, 8L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 36);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.3029378679903436d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.5134113440231306d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == (-36464.27526788552d));
// 
//   }

  public void test377() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test377"); }


    java.lang.Object var1 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)(-1), var1);
    org.apache.commons.math3.util.Pair var3 = new org.apache.commons.math3.util.Pair(var2);
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)100, (java.lang.Object)10.0d);
    java.lang.Object var7 = var6.getSecond();
    java.lang.Object var8 = var6.getValue();
    boolean var9 = var3.equals((java.lang.Object)var6);
    java.lang.Object var10 = var3.getValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 10.0d+ "'", var7.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 10.0d+ "'", var8.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var10);

  }

  public void test378() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test378"); }


    org.apache.commons.math3.exception.NonMonotonicSequenceException var3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(byte)100, (java.lang.Number)1.090766432355056d, 15);

  }

  public void test379() {}
//   public void test379() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test379"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     var1.clear();
//     var1.setSeed(1L);
//     org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var5.reSeedSecure(2563274223793255424L);
//     org.apache.commons.math3.distribution.IntegerDistribution var8 = null;
//     int var9 = var5.nextInversionDeviate(var8);
// 
//   }

  public void test380() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test380"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6L);
    var1.clear();
    var1.clear();
    boolean var4 = var1.nextBoolean();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);

  }

  public void test381() {}
//   public void test381() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test381"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextWeibull(1.0252073473582036E-4d, 0.14521388384019507d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextWeibull((-0.2036590265768301d), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 57);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.0d);
// 
//   }

  public void test382() {}
//   public void test382() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test382"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextWeibull(1.0252073473582036E-4d, 0.14521388384019507d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("1230d0e833b2cad77278d8f7dc53661e09405289750763963834ec3e9cc5d01e89cb6bb491324941dfcddd2", "3329d70073c313b2f0af69933b74885275e6f91de302adec32fc3d338cfd2dcd3c4a43f6485991eb3e9bd92");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 67);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == Double.POSITIVE_INFINITY);
// 
//   }

  public void test383() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test383"); }


    float[] var2 = new float[] { 0.0f, (-1.0f)};
    float[] var5 = new float[] { 0.0f, 100.0f};
    boolean var6 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var2, var5);
    float[] var7 = null;
    boolean var8 = org.apache.commons.math3.util.MathArrays.equals(var5, var7);
    float[] var11 = new float[] { 0.0f, (-1.0f)};
    float[] var14 = new float[] { 0.0f, 100.0f};
    boolean var15 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var11, var14);
    float[] var16 = null;
    boolean var17 = org.apache.commons.math3.util.MathArrays.equals(var14, var16);
    float[] var19 = new float[] { 10.0f};
    float[] var22 = new float[] { 0.0f, (-1.0f)};
    float[] var25 = new float[] { 0.0f, 100.0f};
    boolean var26 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var22, var25);
    boolean var27 = org.apache.commons.math3.util.MathArrays.equals(var19, var25);
    float[] var30 = new float[] { (-1.0f), 1.0f};
    boolean var31 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var19, var30);
    float[] var32 = new float[] { };
    float[] var35 = new float[] { 0.0f, (-1.0f)};
    float[] var38 = new float[] { 0.0f, 100.0f};
    boolean var39 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var35, var38);
    boolean var40 = org.apache.commons.math3.util.MathArrays.equals(var32, var35);
    boolean var41 = org.apache.commons.math3.util.MathArrays.equals(var19, var35);
    boolean var42 = org.apache.commons.math3.util.MathArrays.equals(var16, var19);
    boolean var43 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var7, var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var2);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var14);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var15 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var17 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var25);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var26 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var27 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var30);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var31 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var38);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var40 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var41 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var42 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var43 == false);

  }

  public void test384() {}
//   public void test384() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test384"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
//     double[] var13 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var17 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var18 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var13, var17);
//     double[] var19 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var8, var17);
//     double[] var21 = org.apache.commons.math3.util.MathArrays.normalizeArray(var17, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var22 = null;
//     java.lang.Object[] var24 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var25 = new org.apache.commons.math3.exception.MathInternalError(var22, var24);
//     org.apache.commons.math3.util.Pair var26 = new org.apache.commons.math3.util.Pair((java.lang.Object)var21, (java.lang.Object)var22);
//     org.apache.commons.math3.distribution.DiscreteRealDistribution var27 = new org.apache.commons.math3.distribution.DiscreteRealDistribution(var0, var21);
// 
//   }

  public void test385() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test385"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed();
    var2.reSeed(1L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var8 = var2.nextBinomial((-1983603608), 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
    } catch (org.apache.commons.math3.exception.NotPositiveException e) {
      // Expected exception.
    }

  }

  public void test386() {}
//   public void test386() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test386"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var8 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var12 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var13 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var8, var12);
//     double var14 = org.apache.commons.math3.util.MathArrays.distance1(var4, var13);
//     double[] var16 = org.apache.commons.math3.util.MathArrays.normalizeArray(var13, 0.0d);
//     double var17 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var16);
// 
//   }

  public void test387() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test387"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)0.6245596043465632d, (java.lang.Number)16, true);
    java.lang.Number var5 = var4.getMax();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 16+ "'", var5.equals(16));

  }

  public void test388() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test388"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double[] var18 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var7, var16);
    double[] var20 = org.apache.commons.math3.util.MathArrays.normalizeArray(var7, 21.869847397459292d);
    double[] var24 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var25 = org.apache.commons.math3.util.MathArrays.safeNorm(var24);
    double[] var26 = org.apache.commons.math3.util.MathArrays.copyOf(var24);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var33 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var34 = var33.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var35 = var33.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var37 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var35, true);
    boolean var39 = org.apache.commons.math3.util.MathArrays.isMonotonic(var24, var35, true);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      org.apache.commons.math3.util.MathArrays.checkOrder(var7, var35, true);
      fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException");
    } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var18);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var24);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var25 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var39 == false);

  }

  public void test389() {}
//   public void test389() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test389"); }
// 
// 
//     double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var9 = null;
//     double[] var14 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var18 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var19 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var14, var18);
//     double[] var23 = new double[] { 10.0d, (-1.0d), (-1.0d)};
//     double var24 = org.apache.commons.math3.util.MathArrays.safeNorm(var23);
//     double[][] var25 = new double[][] { var23};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var14, var25);
//     org.apache.commons.math3.exception.NotFiniteNumberException var27 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number)(-1952321163872933406L), (java.lang.Object[])var25);
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var8, var9, var25);
// 
//   }

  public void test390() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test390"); }


    int[] var0 = null;
    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
    int[] var5 = new int[] { 100, 10, (-1)};
    var1.setSeed(var5);
    int[] var7 = new int[] { };
    var1.setSeed(var7);
    org.apache.commons.math3.random.RandomDataGenerator var9 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var13 = var9.nextHypergeometric(0, 74, (-1983603608));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var5);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test391() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test391"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)(-435.67621893769024d), (java.lang.Number)8.884353152082793d, (java.lang.Number)8.884353152082793d);

  }

  public void test392() {}
//   public void test392() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test392"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGamma(103.56915419683993d, 0.20851425337288942d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var0.nextF((-0.6001566413360179d), 2.5745125753274625d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 65);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.5225243952793521d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "e426acde0f0fbe7691edac1ba65afdebc221e8024289be2b3264231439f1042d568c17d8dd811ab072d70e3"+ "'", var8.equals("e426acde0f0fbe7691edac1ba65afdebc221e8024289be2b3264231439f1042d568c17d8dd811ab072d70e3"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 22.878064275101266d);
// 
//   }

  public void test393() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test393"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination((-0.04382736477013571d), (-0.1972188656806444d), (-0.09070155974923377d), (-0.09070155974923377d), 0.0d, (-1.088619555944748d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 0.016870356106681826d);

  }

  public void test394() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test394"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    java.lang.Object[] var1 = null;
    org.apache.commons.math3.exception.MathArithmeticException var2 = new org.apache.commons.math3.exception.MathArithmeticException(var0, var1);

  }

  public void test395() {}
//   public void test395() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test395"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGaussian(0.0d, 10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var0.nextPascal((-1983603608), 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 78);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.8338387507378862d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "6605078f7ae71837a39714efa6d6e35d2f946e1e73fd04b7b69a35adf0f0f5b114a637669940ba95a1c54d8"+ "'", var8.equals("6605078f7ae71837a39714efa6d6e35d2f946e1e73fd04b7b69a35adf0f0f5b114a637669940ba95a1c54d8"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-10.822566042566692d));
// 
//   }

  public void test396() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test396"); }


    java.lang.Object var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
    java.lang.Number var5 = var4.getMin();
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair(var0, (java.lang.Object)var4);
    java.lang.Object var7 = var6.getSecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 1.0d+ "'", var5.equals(1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);

  }

  public void test397() {}
//   public void test397() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test397"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     java.lang.String var5 = var0.nextHexString(87);
//     int var8 = var0.nextZipf(70, 0.6245596043465632d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var0.nextF((-0.6346046533769326d), (-0.7188757561542878d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 10);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "5a91ec3196c74d24de2037054369186dbd6ec5fa66e4d4425c01e8e0d19837eb7b4311356892201100bbda9"+ "'", var5.equals("5a91ec3196c74d24de2037054369186dbd6ec5fa66e4d4425c01e8e0d19837eb7b4311356892201100bbda9"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 1);
// 
//   }

  public void test398() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test398"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NotStrictlyPositiveException var2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(var0, (java.lang.Number)10.0d);
    java.lang.Number var3 = var2.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var3 + "' != '" + 0+ "'", var3.equals(0));

  }

  public void test399() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test399"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(93, 51);

  }

  public void test400() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test400"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
    java.lang.Number var4 = var3.getMin();
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError();
    var3.addSuppressed((java.lang.Throwable)var5);
    java.lang.Number var7 = var3.getMin();
    java.lang.Number var8 = var3.getArgument();
    org.apache.commons.math3.exception.util.ExceptionContext var9 = var3.getContext();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1.0d+ "'", var4.equals(1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 1.0d+ "'", var7.equals(1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-1L)+ "'", var8.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);

  }

  public void test401() {}
//   public void test401() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test401"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var10 = var2.nextHypergeometric(49, 33, 58);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 15);
// 
//   }

  public void test402() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test402"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)6992985943769857466L, (java.lang.Number)0.6712866034052163d, false);

  }

  public void test403() {}
//   public void test403() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test403"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextCauchy((-0.6044871530760823d), 5.704309058613993d);
//     double var10 = var0.nextUniform(0.407741687198951d, 1.4387505701387593d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("c6e2709dc5af", "7a8c41024aaff71e13dd180ce9a7eda28ca78fc2f22a7287d30e2b22971b3d");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 41);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 32.36828706402778d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.4185074783847134d);
// 
//   }

  public void test404() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test404"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(1.3621815434775926d, (-0.1972188656806444d), (-75.62470873108684d), 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == (-0.2686478988557602d));

  }

  public void test405() {}
//   public void test405() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test405"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 22);
// 
//   }

  public void test406() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test406"); }


    double[] var3 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var7 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var11 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var12 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var7, var11);
    double var13 = org.apache.commons.math3.util.MathArrays.distance1(var3, var12);
    double[] var15 = org.apache.commons.math3.util.MathArrays.normalizeArray(var12, 0.0d);
    double[] var19 = new double[] { 10.0d, 100.0d, 10.0d};
    double[] var23 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var27 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var28 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var23, var27);
    double var29 = org.apache.commons.math3.util.MathArrays.distance1(var19, var28);
    double[] var31 = org.apache.commons.math3.util.MathArrays.normalizeArray(var28, 0.0d);
    double var32 = org.apache.commons.math3.util.MathArrays.distance(var15, var31);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var34 = org.apache.commons.math3.util.MathArrays.normalizeArray(var31, 0.9128503986588568d);
      fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException");
    } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var13 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var19);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == 223.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var32 == 0.0d);

  }

  public void test407() {}
//   public void test407() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test407"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     var0.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var13 = var0.nextUniform(0.7111154558159436d, 0.5951250420414592d, false);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 49);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.8042301142285111d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "bdbab5fffb172be90971b2561b22cfab12cbd35611344f9a3f72cc06cd72264aa7dfad9b2e47d77b945e992"+ "'", var8.equals("bdbab5fffb172be90971b2561b22cfab12cbd35611344f9a3f72cc06cd72264aa7dfad9b2e47d77b945e992"));
// 
//   }

  public void test408() {}
//   public void test408() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test408"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[][] var3 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 53, 62);
// 
//   }

  public void test409() {}
//   public void test409() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test409"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGaussian(0.0d, 10.0d);
//     long var13 = var0.nextPoisson(10.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("7e57c969e672256b6db5649c42762f0240649cce4fe163ae5f1e75ba2ae5d5bd0af05586b4de200a3c2a6022", "org.apache.commons.math3.exception.MathIllegalStateException: illegal state");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 99);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.1423587762179066d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "ca9419ff0092ac28929ae0a958ba27ffd3f0a2d411fff9c5da03cd34c72feba10fcd6716d9678bff6012b03"+ "'", var8.equals("ca9419ff0092ac28929ae0a958ba27ffd3f0a2d411fff9c5da03cd34c72feba10fcd6716d9678bff6012b03"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 7.004132963760195d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 12L);
// 
//   }

  public void test410() {}
//   public void test410() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test410"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextLong((-1L), 10L);
//     var2.reSeedSecure(100L);
//     org.apache.commons.math3.distribution.IntegerDistribution var8 = null;
//     int var9 = var2.nextInversionDeviate(var8);
// 
//   }

  public void test411() {}
//   public void test411() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test411"); }
// 
// 
//     int[] var0 = new int[] { };
//     int[] var1 = null;
//     int var2 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var1);
//     int[] var3 = new int[] { };
//     int[] var4 = null;
//     int var5 = org.apache.commons.math3.util.MathArrays.distanceInf(var3, var4);
//     int var6 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var4);
//     org.apache.commons.math3.random.Well19937c var7 = new org.apache.commons.math3.random.Well19937c(var0);
//     java.util.List var8 = null;
//     org.apache.commons.math3.distribution.DiscreteDistribution var9 = new org.apache.commons.math3.distribution.DiscreteDistribution((org.apache.commons.math3.random.RandomGenerator)var7, var8);
// 
//   }

  public void test412() {}
//   public void test412() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test412"); }
// 
// 
//     double[] var3 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var7 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var11 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var12 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var7, var11);
//     double var13 = org.apache.commons.math3.util.MathArrays.distance1(var3, var12);
//     double[] var15 = org.apache.commons.math3.util.MathArrays.normalizeArray(var12, 0.0d);
//     double[] var16 = null;
//     double[] var20 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var24 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var25 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var20, var24);
//     boolean var26 = org.apache.commons.math3.util.MathArrays.equals(var16, var24);
//     double var27 = org.apache.commons.math3.util.MathArrays.safeNorm(var24);
//     double[] var31 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var35 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var36 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var31, var35);
//     double[] var37 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var24, var31);
//     double[] var38 = null;
//     double[] var42 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var46 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var47 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var42, var46);
//     boolean var48 = org.apache.commons.math3.util.MathArrays.equals(var38, var46);
//     double var49 = org.apache.commons.math3.util.MathArrays.safeNorm(var46);
//     double[] var53 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var57 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var61 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var62 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var57, var61);
//     double var63 = org.apache.commons.math3.util.MathArrays.distance1(var53, var62);
//     double[] var65 = org.apache.commons.math3.util.MathArrays.copyOf(var62, 88);
//     double var66 = org.apache.commons.math3.util.MathArrays.distanceInf(var46, var62);
//     double[] var70 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var74 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var75 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var70, var74);
//     org.apache.commons.math3.random.RandomDataGenerator var76 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var79 = var76.nextInt(10, 100);
//     double var82 = var76.nextUniform((-1.0d), 1.0d);
//     var76.reSeedSecure();
//     org.apache.commons.math3.util.Pair var84 = new org.apache.commons.math3.util.Pair((java.lang.Object)var75, (java.lang.Object)var76);
//     double[] var85 = org.apache.commons.math3.util.MathArrays.ebeAdd(var46, var75);
//     boolean var86 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var37, var75);
//     double var87 = org.apache.commons.math3.util.MathArrays.distance1(var15, var75);
//     org.apache.commons.math3.util.MathArrays.OrderDirection var88 = null;
//     boolean var90 = org.apache.commons.math3.util.MathArrays.isMonotonic(var15, var88, true);
// 
//   }

  public void test413() {}
//   public void test413() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test413"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextCauchy((-0.6044871530760823d), 5.704309058613993d);
//     double var10 = var0.nextUniform(0.407741687198951d, 1.4387505701387593d, false);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("c516c1803b366d192bed94", "f985eba2acb24941a7b39c2da6094f070e5e8b63ffabfbd8fb7b41763427994dc57458d3358a99c7f57a352");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 38);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-1.592816908462507d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.3168688364586094d);
// 
//   }

  public void test414() {}
//   public void test414() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test414"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var7.reSeedSecure(5804136433509186560L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var7.nextChiSquare((-1.2058173601229263d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.6690209359085747d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
// 
//   }

  public void test415() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test415"); }


    org.apache.commons.math3.exception.NumberIsTooSmallException var3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number)(-1L), (java.lang.Number)1.0d, true);
    java.lang.Number var4 = var3.getMin();
    org.apache.commons.math3.exception.MathInternalError var5 = new org.apache.commons.math3.exception.MathInternalError();
    var3.addSuppressed((java.lang.Throwable)var5);
    java.lang.Number var7 = var3.getMin();
    java.lang.Number var8 = var3.getArgument();
    java.lang.Number var9 = var3.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var4 + "' != '" + 1.0d+ "'", var4.equals(1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 1.0d+ "'", var7.equals(1.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + (-1L)+ "'", var8.equals((-1L)));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var9 + "' != '" + 1.0d+ "'", var9.equals(1.0d));

  }

  public void test416() {}
//   public void test416() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test416"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var5 = var0.nextExponential((-1.2058173601229263d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 13);
// 
//   }

  public void test417() {}
//   public void test417() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test417"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGamma(103.56915419683993d, 0.20851425337288942d);
//     int var14 = var0.nextInt(0, 14);
//     var0.reSeed(5507950371326924800L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var18 = var0.nextExponential((-0.9438041885292305d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 83);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.27609986511014206d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "2908525b1bec0dded33d216419ec29ca98adaf37e37b80ecd51e0779ed507f7de35b8967da6c4eacf65c7d2"+ "'", var8.equals("2908525b1bec0dded33d216419ec29ca98adaf37e37b80ecd51e0779ed507f7de35b8967da6c4eacf65c7d2"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 19.118702120188303d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 8);
// 
//   }

  public void test418() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test418"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination((-14.359298331536461d), 0.0026224007688764057d, 0.0d, (-0.05475404077564316d), 223.0d, 5842551.508144901d, 0.5172867215048762d, 0.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 1.3028889862786572E9d);

  }

  public void test419() {}
//   public void test419() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test419"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     java.lang.String var6 = var0.nextSecureHexString(88);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextBeta(0.19723959692993903d, (-0.4016759303325931d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 2.017832995910669d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "899652f3f581be427577dd"+ "'", var4.equals("899652f3f581be427577dd"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "9a976db03b50bcf4d8ef574ae19e040d1e6162bc634c5eecfdff9d08f5c94dd38365690ff02c3bbb8b72245a"+ "'", var6.equals("9a976db03b50bcf4d8ef574ae19e040d1e6162bc634c5eecfdff9d08f5c94dd38365690ff02c3bbb8b72245a"));
// 
//   }

  public void test420() {}
//   public void test420() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test420"); }
// 
// 
//     double[] var0 = null;
//     double[] var2 = new double[] { 10.0d};
//     double[] var6 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var10 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var11 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var6, var10);
//     double[] var15 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var19 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var20 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var15, var19);
//     double[] var21 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var10, var19);
//     double[] var23 = org.apache.commons.math3.util.MathArrays.normalizeArray(var19, 9900.0d);
//     org.apache.commons.math3.exception.util.Localizable var24 = null;
//     java.lang.Object[] var26 = new java.lang.Object[] { (byte)100};
//     org.apache.commons.math3.exception.MathInternalError var27 = new org.apache.commons.math3.exception.MathInternalError(var24, var26);
//     org.apache.commons.math3.util.Pair var28 = new org.apache.commons.math3.util.Pair((java.lang.Object)var23, (java.lang.Object)var24);
//     double var29 = org.apache.commons.math3.util.MathArrays.distanceInf(var2, var23);
//     double[] var30 = org.apache.commons.math3.util.MathArrays.ebeAdd(var0, var2);
// 
//   }

  public void test421() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test421"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination((-1.0525166427107446d), (-0.8211092390774544d), (-0.7188757561542878d), 3.829127667332408d, 0.0d, 4.8065019061902365d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == (-1.8884359076523125d));

  }

  public void test422() {}
//   public void test422() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test422"); }
// 
// 
//     org.apache.commons.math3.exception.util.Localizable var0 = null;
//     org.apache.commons.math3.exception.OutOfRangeException var4 = new org.apache.commons.math3.exception.OutOfRangeException(var0, (java.lang.Number)0.4573684520296781d, (java.lang.Number)(-0.05475404077564316d), (java.lang.Number)96);
//     java.lang.String var5 = var4.toString();
// 
//   }

  public void test423() {}
//   public void test423() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test423"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("", "c516c1803b366d192bed94");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 30);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.26529657463347434d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "06e724ed2460fedc8f36a9677f64b40c5f8ba30ce1870018b6f30f3dde4893528083e0076a6334231360a2b"+ "'", var8.equals("06e724ed2460fedc8f36a9677f64b40c5f8ba30ce1870018b6f30f3dde4893528083e0076a6334231360a2b"));
// 
//   }

  public void test424() {}
//   public void test424() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test424"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
//     double[] var13 = new double[] { 10.0d, (-1.0d), (-1.0d)};
//     double var14 = org.apache.commons.math3.util.MathArrays.safeNorm(var13);
//     double[][] var15 = new double[][] { var13};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var15);
//     boolean var17 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(var0, var4);
//     double[] var18 = null;
//     double[] var22 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var26 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var27 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var22, var26);
//     boolean var28 = org.apache.commons.math3.util.MathArrays.equals(var18, var26);
//     double var29 = org.apache.commons.math3.util.MathArrays.safeNorm(var26);
//     double[] var33 = new double[] { 10.0d, 100.0d, 10.0d};
//     double[] var37 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var41 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var42 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var37, var41);
//     double var43 = org.apache.commons.math3.util.MathArrays.distance1(var33, var42);
//     double[] var45 = org.apache.commons.math3.util.MathArrays.copyOf(var42, 88);
//     double var46 = org.apache.commons.math3.util.MathArrays.distanceInf(var26, var42);
//     double[] var50 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var54 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var55 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var50, var54);
//     org.apache.commons.math3.random.RandomDataGenerator var56 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var59 = var56.nextInt(10, 100);
//     double var62 = var56.nextUniform((-1.0d), 1.0d);
//     var56.reSeedSecure();
//     org.apache.commons.math3.util.Pair var64 = new org.apache.commons.math3.util.Pair((java.lang.Object)var55, (java.lang.Object)var56);
//     double[] var65 = org.apache.commons.math3.util.MathArrays.ebeAdd(var26, var55);
//     double var66 = org.apache.commons.math3.util.MathArrays.distanceInf(var0, var65);
// 
//   }

  public void test425() {}
//   public void test425() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test425"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextLong((-1L), 10L);
//     var2.reSeed((-1L));
//     double var9 = var2.nextExponential(100.0d);
//     var2.reSeed(39L);
//     double var14 = var2.nextCauchy(1.7451931429974368d, 4979382.8531437665d);
//     org.apache.commons.math3.distribution.RealDistribution var15 = null;
//     double var16 = var2.nextInversionDeviate(var15);
// 
//   }

  public void test426() {}
//   public void test426() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test426"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     long var5 = var2.nextLong((-1L), 10L);
//     long var8 = var2.nextSecureLong(0L, 14L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var2.nextF(0.7578669481310135d, (-0.9899264537631861d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 7L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 7L);
// 
//   }

  public void test427() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test427"); }


    org.apache.commons.math3.exception.NotStrictlyPositiveException var1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number)59);

  }

  public void test428() {}
//   public void test428() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test428"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.1431715674774945d, 7.500930705661022d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var8 = var0.nextLong(1L, (-3200518016629555151L));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-140.46698996258007d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.022621490888327947d);
// 
//   }

  public void test429() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test429"); }


    java.lang.Object var1 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)(-1), var1);
    org.apache.commons.math3.util.Pair var3 = new org.apache.commons.math3.util.Pair(var2);
    boolean var5 = var3.equals((java.lang.Object)(short)(-1));
    java.lang.Object var6 = var3.getSecond();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNull(var6);

  }

  public void test430() {}
//   public void test430() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test430"); }
// 
// 
//     org.apache.commons.math3.Field var0 = null;
//     java.lang.Object[] var2 = org.apache.commons.math3.util.MathArrays.buildArray(var0, 61);
// 
//   }

  public void test431() {}
//   public void test431() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test431"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     int var5 = var0.nextSecureInt((-1), 33);
//     var0.reSeedSecure();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-4.211867240318616d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 17);
// 
//   }

  public void test432() {}
//   public void test432() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test432"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var9 = var0.nextF((-7.547349470080946d), (-75.62470873108684d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 95);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.32029964336677264d));
// 
//   }

  public void test433() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test433"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(23.255333405607846d, (-2.651556632561712d), 0.07277703352123166d, 0.34254335670903924d, 23.255333405607846d, 0.1479328506264807d, (-0.6237038350722588d), 4.645762949836714d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == (-61.09525665040872d));

  }

  public void test434() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test434"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    var1.clear();
    var1.setSeed(1L);
    org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var8 = var5.nextPascal(49, 0.10832690038004085d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      var5.setSecureAlgorithm("", "36c1637e897f0a5dbd2b0ebb46aea03064c712897fd97d9661c61184bcbff1616fa24e72623759c351b9c8d");
      fail("Expected exception of type java.security.NoSuchProviderException");
    } catch (java.security.NoSuchProviderException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 318);

  }

  public void test435() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test435"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    var1.clear();
    var1.setSeed(1L);
    org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    int var7 = var1.nextInt(88);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var7 == 25);

  }

  public void test436() {}
//   public void test436() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test436"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     double var9 = var0.nextCauchy(0.08430081831437178d, 0.407741687198951d);
//     double var11 = var0.nextT(149.06382668435472d);
//     double var13 = var0.nextExponential(103.56915419683993d);
//     java.util.Collection var14 = null;
//     java.lang.Object[] var16 = var0.nextSample(var14, 2);
// 
//   }

  public void test437() {}
//   public void test437() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test437"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     byte[] var8 = new byte[] { (byte)1};
//     var1.nextBytes(var8);
//     org.apache.commons.math3.random.RandomDataImpl var10 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var10.reSeedSecure();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var10.nextWeibull((-0.048635280582399396d), (-5.891344771123487d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 1.1364549594147197d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
// 
//   }

  public void test438() {}
//   public void test438() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test438"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     int[] var5 = new int[] { 0, 1};
//     var1.setSeed(var5);
//     org.apache.commons.math3.random.RandomDataGenerator var7 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     double var10 = var7.nextGaussian(0.19193457678938466d, 67399.51573302031d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var14 = var7.nextUniform((-988.6092885864007d), (-934295.5483625216d), true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1.2608255671755473d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var5);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 89439.3517567197d);
// 
//   }

  public void test439() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test439"); }


    org.apache.commons.math3.exception.DimensionMismatchException var2 = new org.apache.commons.math3.exception.DimensionMismatchException(42, 93);
    int var3 = var2.getDimension();
    int var4 = var2.getDimension();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var3 == 93);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 93);

  }

  public void test440() {}
//   public void test440() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test440"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGamma(103.56915419683993d, 0.20851425337288942d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var15 = var0.nextLong(7741999113339246307L, 0L);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 23);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.7088764047041147d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "985a662beed7fcc7e0a0f4f02f356d6a5cad368ad03535f6b30ae4221fb10210a7a30e03a1df5d9c59c9a82"+ "'", var8.equals("985a662beed7fcc7e0a0f4f02f356d6a5cad368ad03535f6b30ae4221fb10210a7a30e03a1df5d9c59c9a82"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 23.211462730522385d);
// 
//   }

  public void test441() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test441"); }


    org.apache.commons.math3.random.RandomGenerator var0 = null;
    org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
    var1.reSeedSecure();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      long var5 = var1.nextLong(10L, 1L);
      fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
    } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
      // Expected exception.
    }

  }

  public void test442() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test442"); }


    org.apache.commons.math3.exception.OutOfRangeException var3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number)0.003280181574840446d, (java.lang.Number)301405723, (java.lang.Number)0.002060832934925295d);

  }

  public void test443() {}
//   public void test443() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test443"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     long var3 = var0.nextSecureLong(0L, 10L);
//     var0.reSeedSecure(27192867108684266L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("3f9f5e201d1469e5ec21121dd7c7a05a3543bc17f1308d8f6dbe61dc8611f443c47be59d25f90ef04e252a5", "b6927bfd66e40630e4681c80bfa00086d90d2391ae53089602e9c148bfffb7bcf3211f3abec87ef56399d51");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 9L);
// 
//   }

  public void test444() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test444"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    var1.clear();
    var1.setSeed(1L);
    org.apache.commons.math3.random.RandomDataImpl var5 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var5.reSeedSecure(2563274223793255424L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var10 = var5.nextCauchy((-1.088619555944748d), (-1096.3767627294947d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test445() {}
//   public void test445() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test445"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     var0.reSeed((-1L));
//     int var10 = var0.nextZipf(62, 0.11681967467915401d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var0.nextChiSquare((-0.2686478988557602d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 47.98103741091796d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 13);
// 
//   }

  public void test446() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test446"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    double var8 = var2.nextGaussian(0.2408323783466006d, 0.5410607118838238d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      java.lang.String var10 = var2.nextHexString(0);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 0.09750373895602457d);

  }

  public void test447() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test447"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, 0.026429111303666656d, (-0.08515379833665031d), (-934295.5483625216d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 79558.81471209228d);

  }

  public void test448() {}
//   public void test448() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test448"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     var0.reSeed(10L);
//     long var8 = var0.nextPoisson(0.636769707396945d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextT((-0.01516979083120098d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.6911632701558278d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "7a1ff34090ed654379bd81"+ "'", var4.equals("7a1ff34090ed654379bd81"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 0L);
// 
//   }

  public void test449() {}
//   public void test449() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test449"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     double var8 = var2.nextT(11.36369913641775d);
//     int[] var11 = var2.nextPermutation(33, 31);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var14 = var2.nextBinomial(25, 712.9249743109224d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 16);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-2.178052958012575d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
// 
//   }

  public void test450() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test450"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    var2.reSeed((-1L));
    var2.reSeed();
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      int var11 = var2.nextPascal(37, (-0.01516979083120098d));
      fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
    } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);

  }

  public void test451() {}
//   public void test451() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test451"); }
// 
// 
//     long[] var0 = null;
//     org.apache.commons.math3.util.MathArrays.checkNonNegative(var0);
// 
//   }

  public void test452() {}
//   public void test452() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test452"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var4 = var1.nextInt(10, 100);
//     double var6 = var1.nextExponential(10.0d);
//     org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)"255737ca0aa76cd64c486046c09bb4241de9d17d6a15fad4cb3ac04c20bfb9ce320daaebb6e9d68f18f5234", (java.lang.Object)var1);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var11 = var1.nextUniform(2.1874856059935905d, (-0.9451161353496818d), true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 69);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 8.483903544561231d);
// 
//   }

  public void test453() {}
//   public void test453() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test453"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGaussian(0.0d, 10.0d);
//     double var13 = var0.nextExponential(0.1431715674774945d);
//     var0.reSeed();
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var17 = var0.nextBeta(0.7247668141114612d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NoBracketingException");
//     } catch (org.apache.commons.math3.exception.NoBracketingException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 63);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.3495766692570381d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "f40b35c998d868093b88dabb1d4830a9e2605aa5d28bb42b3e4d2db1d8b00156a2f007f29c42f9e24e6bfd0"+ "'", var8.equals("f40b35c998d868093b88dabb1d4830a9e2605aa5d28bb42b3e4d2db1d8b00156a2f007f29c42f9e24e6bfd0"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 4.070543786304324d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 0.12003703417383371d);
// 
//   }

  public void test454() {}
//   public void test454() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test454"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextCauchy((-0.6044871530760823d), 5.704309058613993d);
//     double var10 = var0.nextUniform(0.407741687198951d, 1.4387505701387593d, false);
//     java.lang.String var12 = var0.nextHexString(62);
//     int var15 = var0.nextInt(31, 64);
//     int var18 = var0.nextZipf(36, 0.002575717853305201d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int[] var21 = var0.nextPermutation(53, 58);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 99);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 6.798919369886589d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.1210573644524d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var12 + "' != '" + "15ae5e4257a1792e1a6320bfdbf7477839500d938a0aaaddac698d0105a91a"+ "'", var12.equals("15ae5e4257a1792e1a6320bfdbf7477839500d938a0aaaddac698d0105a91a"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 35);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == 5);
// 
//   }

  public void test455() {}
//   public void test455() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test455"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(25);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var6 = var0.nextPoisson((-36464.35619377387d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 112.54745434145745d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "08a8990ba3a013a223d93d310"+ "'", var4.equals("08a8990ba3a013a223d93d310"));
// 
//   }

  public void test456() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test456"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)28.46111736987342d, (java.lang.Number)1.1891493406396207d, false);

  }

  public void test457() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test457"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed(5804136433509186560L);
    double var6 = var2.nextExponential(1.5408118860052713d);
    int var10 = var2.nextHypergeometric(87, 55, 86);
    var2.reSeedSecure(7L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.1874856059935905d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 54);

  }

  public void test458() {}
//   public void test458() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test458"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     java.lang.String var8 = var2.nextHexString(95);
//     double var11 = var2.nextGaussian((-0.09070155974923377d), 0.4429300278176235d);
//     org.apache.commons.math3.distribution.RealDistribution var12 = null;
//     double var13 = var2.nextInversionDeviate(var12);
// 
//   }

  public void test459() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test459"); }


    org.apache.commons.math3.exception.NotPositiveException var1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number)0.03603256163404128d);

  }

  public void test460() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test460"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)31, (java.lang.Number)0.7643965057948721d, false);

  }

  public void test461() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test461"); }


    double var4 = org.apache.commons.math3.util.MathArrays.linearCombination(0.14649214762772098d, 6.251783231069299d, 0.0d, 7.500930705661022d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == 0.9158371520223142d);

  }

  public void test462() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test462"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeedSecure(100L);
    var2.reSeedSecure(1L);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var8 = var2.nextT(0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }

  }

  public void test463() {}
//   public void test463() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test463"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     java.lang.String var5 = var0.nextHexString(87);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var7 = var0.nextT(0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 82);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var5 + "' != '" + "a1a172ded020e69af8be5b4180a6148af9ecba4a52d80c3483eb94bc85b55c59246e8d72eb0a371fa6adc99"+ "'", var5.equals("a1a172ded020e69af8be5b4180a6148af9ecba4a52d80c3483eb94bc85b55c59246e8d72eb0a371fa6adc99"));
// 
//   }

  public void test464() {}
//   public void test464() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test464"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     double var6 = var2.nextUniform(0.012774969105543068d, 21.869847397459292d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var2.nextSecureInt(69, (-1983603608));
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 20.17993774880086d);
// 
//   }

  public void test465() {}
//   public void test465() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test465"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     double var10 = var0.nextF(102.0d, 9900.0d);
//     double var12 = var0.nextT(223.0d);
//     long var15 = var0.nextLong(14L, 2563274223793255424L);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var19 = var0.nextHypergeometric(63, 40, 80);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 80);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 26.83934053141388d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.0272604962398155d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.1529669952609447d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 0.8847587266246011d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var15 == 89240956088381280L);
// 
//   }

  public void test466() {}
//   public void test466() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test466"); }
// 
// 
//     org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)100, (java.lang.Object)10.0d);
//     java.lang.Object var3 = var2.getSecond();
//     java.lang.Object var4 = var2.getFirst();
//     double[] var8 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var12 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var13 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var8, var12);
//     org.apache.commons.math3.random.RandomDataGenerator var14 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var17 = var14.nextInt(10, 100);
//     double var20 = var14.nextUniform((-1.0d), 1.0d);
//     var14.reSeedSecure();
//     org.apache.commons.math3.util.Pair var22 = new org.apache.commons.math3.util.Pair((java.lang.Object)var13, (java.lang.Object)var14);
//     boolean var23 = var2.equals((java.lang.Object)var14);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var27 = var14.nextHypergeometric(53, 99, 8);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var3 + "' != '" + 10.0d+ "'", var3.equals(10.0d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + (short)100+ "'", var4.equals((short)100));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 43);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var20 == 0.6680311118511639d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == false);
// 
//   }

  public void test467() {}
//   public void test467() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test467"); }
// 
// 
//     int[] var0 = null;
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(var0);
//     double var2 = var1.nextGaussian();
//     byte[] var4 = new byte[] { (byte)10};
//     var1.nextBytes(var4);
//     org.apache.commons.math3.random.RandomDataGenerator var6 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     var6.reSeedSecure();
//     var6.reSeedSecure();
//     int var11 = var6.nextSecureInt(20, 71);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var13 = var6.nextPoisson((-0.049845049744689576d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 0.2125679836352467d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var4);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 35);
// 
//   }

  public void test468() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test468"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(6L);
    var1.setSeed(6992985943769857466L);

  }

  public void test469() {}
//   public void test469() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test469"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var1 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var4 = var1.nextInt(10, 100);
//     double var6 = var1.nextExponential(10.0d);
//     org.apache.commons.math3.util.Pair var7 = new org.apache.commons.math3.util.Pair((java.lang.Object)"255737ca0aa76cd64c486046c09bb4241de9d17d6a15fad4cb3ac04c20bfb9ce320daaebb6e9d68f18f5234", (java.lang.Object)var1);
//     java.lang.String var9 = var1.nextHexString(99);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var12 = var1.nextWeibull(0.0d, (-0.4148741153049867d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var4 == 15);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 11.001668710935428d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var9 + "' != '" + "64b328a6541efe6ca5414ddbb2fe5bb2c0affbc634f3c9a0c81b86c364c83f79d92148aa0be3433940fcece333bf0f42d42"+ "'", var9.equals("64b328a6541efe6ca5414ddbb2fe5bb2c0affbc634f3c9a0c81b86c364c83f79d92148aa0be3433940fcece333bf0f42d42"));
// 
//   }

  public void test470() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test470"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    long var5 = var2.nextLong((-1L), 10L);
    var2.reSeed((-1L));
    double var9 = var2.nextExponential(100.0d);
    double var11 = var2.nextT(23.562469870696063d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var14 = var2.nextWeibull(0.0d, (-0.292640940848738d));
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 7L);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 149.06382668435472d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var11 == (-0.08515379833665031d));

  }

  public void test471() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test471"); }


    double[] var1 = new double[] { 0.0d};
    org.apache.commons.math3.util.MathArrays.OrderDirection var2 = null;
    boolean var4 = org.apache.commons.math3.util.MathArrays.isMonotonic(var1, var2, false);
    org.apache.commons.math3.util.MathArrays.checkOrder(var1);
    double[] var9 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var10 = org.apache.commons.math3.util.MathArrays.safeNorm(var9);
    double[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var9);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var18 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var19 = var18.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var20 = var18.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var22 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var20, true);
    boolean var24 = org.apache.commons.math3.util.MathArrays.isMonotonic(var9, var20, true);
    double[] var28 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var32 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var33 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var28, var32);
    boolean var34 = org.apache.commons.math3.util.MathArrays.equals(var9, var33);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double[] var35 = org.apache.commons.math3.util.MathArrays.ebeAdd(var1, var33);
      fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException");
    } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var1);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var4 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var9);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var10 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var11);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var20);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var24 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var32);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var33);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var34 == false);

  }

  public void test472() {}
//   public void test472() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test472"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     double var11 = var0.nextGaussian(0.0d, 10.0d);
//     int var14 = var0.nextSecureInt(22, 75);
//     java.lang.String var16 = var0.nextHexString(33);
//     int var20 = var0.nextHypergeometric(73, 18, 12);
//     java.util.Collection var21 = null;
//     java.lang.Object[] var23 = var0.nextSample(var21, 15);
// 
//   }

  public void test473() {}
//   public void test473() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test473"); }
// 
// 
//     double[] var0 = null;
//     double[] var4 = new double[] { (-1.0d), (-1.0d), 1.0d};
//     double[] var8 = new double[] { 1.0d, 1.0d, 100.0d};
//     double[] var9 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var4, var8);
//     double[] var13 = new double[] { 10.0d, (-1.0d), (-1.0d)};
//     double var14 = org.apache.commons.math3.util.MathArrays.safeNorm(var13);
//     double[][] var15 = new double[][] { var13};
//     org.apache.commons.math3.util.MathArrays.sortInPlace(var4, var15);
//     double[] var17 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var0, var4);
// 
//   }

  public void test474() {}
//   public void test474() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test474"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     int var5 = var0.nextSecureInt((-1), 33);
//     long var8 = var0.nextSecureLong(1L, 100L);
//     var0.reSeed((-56139359032789495L));
//     double var13 = var0.nextGamma(2.264115422511676d, 1.4387505701387593d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 15.835990056313115d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 13);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == 61L);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == 4.5628215651163915d);
// 
//   }

  public void test475() {}
//   public void test475() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test475"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100L);
//     org.apache.commons.math3.random.RandomDataGenerator var2 = new org.apache.commons.math3.random.RandomDataGenerator((org.apache.commons.math3.random.RandomGenerator)var1);
//     java.lang.String var4 = var2.nextSecureHexString(52);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var8 = var2.nextHypergeometric(499, 62, (-848192168));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException");
//     } catch (org.apache.commons.math3.exception.NotPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "98712be146f86089cb41f3d299e220672c18d4f2888387df82e3"+ "'", var4.equals("98712be146f86089cb41f3d299e220672c18d4f2888387df82e3"));
// 
//   }

  public void test476() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test476"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.DimensionMismatchException var3 = new org.apache.commons.math3.exception.DimensionMismatchException(var0, 22, 0);

  }

  public void test477() {}
//   public void test477() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test477"); }
// 
// 
//     int[] var2 = new int[] { 1, 0};
//     int[] var3 = null;
//     org.apache.commons.math3.random.Well19937c var4 = new org.apache.commons.math3.random.Well19937c(var3);
//     double var5 = var4.nextGaussian();
//     int[] var8 = new int[] { 0, 1};
//     var4.setSeed(var8);
//     double var10 = org.apache.commons.math3.util.MathArrays.distance(var2, var8);
//     int[] var11 = org.apache.commons.math3.util.MathArrays.copyOf(var8);
//     org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var2);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 1.5603122607175668d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var8);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == 1.4142135623730951d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
// 
//   }

  public void test478() {}
//   public void test478() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test478"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     double var6 = var0.nextChiSquare(0.012774969105543068d);
//     int[] var9 = var0.nextPermutation(43, 3);
//     org.apache.commons.math3.random.Well19937c var11 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var12 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var11);
//     var12.reSeed();
//     int var16 = var12.nextZipf(18, 0.10832690038004085d);
//     double var18 = var12.nextT(11.36369913641775d);
//     int[] var21 = var12.nextPermutation(33, 31);
//     org.apache.commons.math3.random.Well19937c var22 = new org.apache.commons.math3.random.Well19937c(var21);
//     int var23 = org.apache.commons.math3.util.MathArrays.distanceInf(var9, var21);
//     org.apache.commons.math3.random.Well19937c var24 = new org.apache.commons.math3.random.Well19937c(var9);
//     org.apache.commons.math3.random.RandomDataImpl var25 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var27 = var25.nextT(0.1431715674774945d);
//     java.lang.String var29 = var25.nextHexString(22);
//     double var31 = var25.nextChiSquare(0.012774969105543068d);
//     int[] var34 = var25.nextPermutation(43, 3);
//     int var35 = org.apache.commons.math3.util.MathArrays.distanceInf(var9, var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 26369.68703442797d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "4baecf8ac5b27e384280db"+ "'", var4.equals("4baecf8ac5b27e384280db"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 4.307681584078219E-5d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 9);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var18 == (-1.915642490695788d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var21);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var23 == 20);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var27 == 25.798688668862965d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var29 + "' != '" + "006211b9c2545be1968857"+ "'", var29.equals("006211b9c2545be1968857"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var31 == 1.0188444560689377E-9d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var34);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var35 == 9);
// 
//   }

  public void test479() {}
//   public void test479() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test479"); }
// 
// 
//     org.apache.commons.math3.random.RandomGenerator var0 = null;
//     org.apache.commons.math3.random.RandomDataImpl var1 = new org.apache.commons.math3.random.RandomDataImpl(var0);
//     double var3 = var1.nextChiSquare(0.08430081831437178d);
//     double var6 = var1.nextUniform((-0.32577132027868605d), 4.713414225479933d);
//     org.apache.commons.math3.distribution.RealDistribution var7 = null;
//     double var8 = var1.nextInversionDeviate(var7);
// 
//   }

  public void test480() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test480"); }


    org.apache.commons.math3.exception.NumberIsTooLargeException var3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number)508515618537942016L, (java.lang.Number)5.587647994475429E8d, true);

  }

  public void test481() {}
//   public void test481() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test481"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     double var9 = var0.nextCauchy(0.08430081831437178d, 0.407741687198951d);
//     double var11 = var0.nextT(149.06382668435472d);
//     double var14 = var0.nextF(1.5408118860052713d, 0.6862627241836179d);
//     int var17 = var0.nextSecureInt(54, 95);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 29);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.5117876358710434d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == (-0.10659341427742133d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == (-0.9866057353036886d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 6.540316540242818d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var17 == 77);
// 
//   }

  public void test482() {}
//   public void test482() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test482"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     java.lang.String var4 = var0.nextHexString(22);
//     java.lang.String var6 = var0.nextSecureHexString(88);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var9 = var0.nextPascal(47, 5.587647994475429E8d);
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-1776436.0708371804d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var4 + "' != '" + "57ecb76f98e410b6d43e57"+ "'", var4.equals("57ecb76f98e410b6d43e57"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var6 + "' != '" + "2f754ca8daf8d2566e62ca61d829e502ea9743bd73008aa274b771f96cfe4fe4581a7ffa94013fc2befa0409"+ "'", var6.equals("2f754ca8daf8d2566e62ca61d829e502ea9743bd73008aa274b771f96cfe4fe4581a7ffa94013fc2befa0409"));
// 
//   }

  public void test483() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test483"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooSmallException var4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(var0, (java.lang.Number)(-1.892067858120859d), (java.lang.Number)0.7643965057948721d, false);
    java.lang.Number var5 = var4.getMin();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var5 + "' != '" + 0.7643965057948721d+ "'", var5.equals(0.7643965057948721d));

  }

  public void test484() {}
//   public void test484() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test484"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextCauchy((-0.6044871530760823d), 5.704309058613993d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var10 = var0.nextUniform(0.13950886311666869d, (-334.56309673916184d), true);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 12);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 10.705734010221242d);
// 
//   }

  public void test485() {}
//   public void test485() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test485"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.012774969105543068d, 0.09455763871444445d);
//     double var7 = var0.nextExponential(0.4301403036978695d);
//     double var10 = var0.nextCauchy((-9.743086442592038E10d), 0.10684763416654564d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       long var12 = var0.nextPoisson((-61.09525665040872d));
//       fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
//     } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == (-27.216199631488912d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 4.880623742696184E-7d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var7 == 0.0825473674490472d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var10 == (-9.743086442572958E10d));
// 
//   }

  public void test486() {}
//   public void test486() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test486"); }
// 
// 
//     double[] var0 = null;
//     org.apache.commons.math3.util.MathArrays.checkOrder(var0);
// 
//   }

  public void test487() {}
//   public void test487() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test487"); }
// 
// 
//     org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
//     org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
//     var2.reSeed();
//     int var6 = var2.nextZipf(18, 0.10832690038004085d);
//     double var8 = var2.nextT(11.36369913641775d);
//     int[] var11 = var2.nextPermutation(33, 31);
//     org.apache.commons.math3.random.Well19937c var12 = new org.apache.commons.math3.random.Well19937c(var11);
//     int var13 = var12.nextInt();
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 3);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var8 == (-0.05536521097801786d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertNotNull(var11);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var13 == (-1123394720));
// 
//   }

  public void test488() {}
//   public void test488() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test488"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     double var9 = var0.nextCauchy(0.08430081831437178d, 0.407741687198951d);
//     double var11 = var0.nextT(149.06382668435472d);
//     double var14 = var0.nextF(1.5408118860052713d, 0.6862627241836179d);
//     double var16 = var0.nextExponential(0.6591014616866876d);
//     double var19 = var0.nextGamma(0.50527176291182d, 0.5951250420414592d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var22 = var0.nextPascal(4, (-30.443553573156947d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 93);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.7469478391291307d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var9 == 0.5174466558238997d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var11 == 0.04577453402801662d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var14 == 0.26028182338089906d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var16 == 0.18679716149835343d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var19 == 0.001062630522492464d);
// 
//   }

  public void test489() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test489"); }


    double var8 = org.apache.commons.math3.util.MathArrays.linearCombination(0.0d, 0.8196062242347161d, 1.1259987554121422d, 0.6862627241836179d, 3.829127667332408d, 3.2269378137240654d, (-0.05077457481457559d), 3.4785048692046914d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var8 == 12.952468230884172d);

  }

  public void test490() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test490"); }


    double[] var0 = null;
    double[] var4 = new double[] { 10.0d, (-1.0d), (-1.0d)};
    double var5 = org.apache.commons.math3.util.MathArrays.safeNorm(var4);
    double[] var6 = org.apache.commons.math3.util.MathArrays.copyOf(var4);
    org.apache.commons.math3.exception.NonMonotonicSequenceException var13 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)(-1), (java.lang.Number)0.0f, 0);
    boolean var14 = var13.getStrict();
    org.apache.commons.math3.util.MathArrays.OrderDirection var15 = var13.getDirection();
    org.apache.commons.math3.exception.NonMonotonicSequenceException var17 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number)0.5684335790811075d, (java.lang.Number)84, 54, var15, true);
    boolean var19 = org.apache.commons.math3.util.MathArrays.isMonotonic(var4, var15, true);
    double[] var23 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var27 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var28 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var23, var27);
    boolean var29 = org.apache.commons.math3.util.MathArrays.equals(var4, var28);
    boolean var30 = org.apache.commons.math3.util.MathArrays.equals(var0, var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var4);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var5 == 10.099504938362077d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var6);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var14 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var15);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var19 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var23);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var28);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var29 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var30 == false);

  }

  public void test491() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test491"); }


    org.apache.commons.math3.exception.util.Localizable var0 = null;
    org.apache.commons.math3.exception.NumberIsTooLargeException var4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(var0, (java.lang.Number)67399.51573302031d, (java.lang.Number)(-0.8782782965603144d), false);

  }

  public void test492() {}
//   public void test492() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test492"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     var0.reSeed();
//     int var12 = var0.nextBinomial(58, 0.09455763871444445d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       double var15 = var0.nextUniform(426.15711861793085d, 0.0d);
//       fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException");
//     } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 88);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == (-0.8145172029002898d));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "66bfa0657ee5a084f963db5210c17803819c46b4ee16f166ab66e628670141104213c9534f43840ef643089"+ "'", var8.equals("66bfa0657ee5a084f963db5210c17803819c46b4ee16f166ab66e628670141104213c9534f43840ef643089"));
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var12 == 3);
// 
//   }

  public void test493() {}
//   public void test493() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test493"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var6 = var0.nextUniform((-1.0d), 1.0d);
//     java.lang.String var8 = var0.nextSecureHexString(87);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       int var11 = var0.nextPascal(74, (-435.67621893769024d));
//       fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException");
//     } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var3 == 59);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var6 == 0.8083722774364306d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue("'" + var8 + "' != '" + "1258fd92fd6baecebf76305600dcd4ba4c59896978788df2c6714ff14b2e01be1bc348ba75a6ee3104f760b"+ "'", var8.equals("1258fd92fd6baecebf76305600dcd4ba4c59896978788df2c6714ff14b2e01be1bc348ba75a6ee3104f760b"));
// 
//   }

  public void test494() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test494"); }


    double[] var3 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var7 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var8 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var3, var7);
    double[] var12 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var16 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var17 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var12, var16);
    double var18 = org.apache.commons.math3.util.MathArrays.distance1(var8, var12);
    double[] var22 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var26 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var27 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var22, var26);
    double[] var31 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var35 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var36 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var31, var35);
    double var37 = org.apache.commons.math3.util.MathArrays.distance1(var27, var31);
    double[] var38 = null;
    double[] var42 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var46 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var47 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var42, var46);
    boolean var48 = org.apache.commons.math3.util.MathArrays.equals(var38, var46);
    double var49 = org.apache.commons.math3.util.MathArrays.safeNorm(var46);
    double[] var53 = new double[] { (-1.0d), (-1.0d), 1.0d};
    double[] var57 = new double[] { 1.0d, 1.0d, 100.0d};
    double[] var58 = org.apache.commons.math3.util.MathArrays.ebeSubtract(var53, var57);
    double[] var59 = org.apache.commons.math3.util.MathArrays.ebeMultiply(var46, var53);
    boolean var60 = org.apache.commons.math3.util.MathArrays.equals(var31, var53);
    double[] var61 = org.apache.commons.math3.util.MathArrays.copyOf(var31);
    double[][] var62 = new double[][] { var31};
    org.apache.commons.math3.util.MathArrays.sortInPlace(var8, var62);
    double[] var65 = org.apache.commons.math3.util.MathArrays.normalizeArray(var8, (-0.9451161353496818d));
    double var66 = org.apache.commons.math3.util.MathArrays.safeNorm(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var3);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var7);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var8);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var12);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var16);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var17);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var18 == 102.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var22);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var26);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var27);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var31);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var35);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var36);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var37 == 102.0d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var42);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var46);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var47);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var48 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var49 == 100.00999950005d);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var53);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var57);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var58);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var59);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var60 == true);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var61);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var62);
    
    // Regression assertion (captures the current behavior of the code)
    assertNotNull(var65);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var66 == 0.9087832633101555d);

  }

  public void test495() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test495"); }


    double var6 = org.apache.commons.math3.util.MathArrays.linearCombination(0.2099020107765877d, 1.3028889862786572E9d, 0.1431715674774945d, (-0.4628858931836466d), 89439.3517567197d, 2.0652764284882417d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.736637349572505E8d);

  }

  public void test496() {}
//   public void test496() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test496"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     double var2 = var0.nextChiSquare(100.0d);
//     int var5 = var0.nextBinomial(0, 0.6040101945254669d);
//     java.util.Collection var6 = null;
//     java.lang.Object[] var8 = var0.nextSample(var6, 30);
// 
//   }

  public void test497() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test497"); }


    org.apache.commons.math3.random.Well19937c var1 = new org.apache.commons.math3.random.Well19937c(100);
    org.apache.commons.math3.random.RandomDataImpl var2 = new org.apache.commons.math3.random.RandomDataImpl((org.apache.commons.math3.random.RandomGenerator)var1);
    var2.reSeed(5804136433509186560L);
    double var6 = var2.nextExponential(1.5408118860052713d);
    double var9 = var2.nextGaussian(4.218937231588664d, 0.9692669377133449d);
    // The following exception was thrown during execution.
    // This behavior will recorded for regression testing.
    try {
      double var12 = var2.nextWeibull(0.5410607118838238d, 0.0d);
      fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException");
    } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
      // Expected exception.
    }
    
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var6 == 2.1874856059935905d);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == 2.641195788033711d);

  }

  public void test498() {}
//   public void test498() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test498"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataGenerator var0 = new org.apache.commons.math3.random.RandomDataGenerator();
//     int var3 = var0.nextInt(10, 100);
//     double var5 = var0.nextExponential(10.0d);
//     double var7 = var0.nextExponential(0.407741687198951d);
//     java.util.Collection var8 = null;
//     java.lang.Object[] var10 = var0.nextSample(var8, 39);
// 
//   }

  public void test499() {}
//   public void test499() throws Throwable {
// 
//     if (debug) { System.out.println(); System.out.print("RandoopTest0.test499"); }
// 
// 
//     org.apache.commons.math3.random.RandomDataImpl var0 = new org.apache.commons.math3.random.RandomDataImpl();
//     double var2 = var0.nextT(0.1431715674774945d);
//     double var5 = var0.nextBeta(0.012774969105543068d, 0.09455763871444445d);
//     // The following exception was thrown during execution.
//     // This behavior will recorded for regression testing.
//     try {
//       var0.setSecureAlgorithm("642aacd9bd9508023be393", "00");
//       fail("Expected exception of type java.security.NoSuchProviderException");
//     } catch (java.security.NoSuchProviderException e) {
//       // Expected exception.
//     }
//     
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var2 == 13.464495536636703d);
//     
//     // Regression assertion (captures the current behavior of the code)
//     assertTrue(var5 == 0.002632108654497921d);
// 
//   }

  public void test500() throws Throwable {

    if (debug) { System.out.println(); System.out.print("RandoopTest0.test500"); }


    java.lang.Object var1 = null;
    org.apache.commons.math3.util.Pair var2 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)(-1), var1);
    org.apache.commons.math3.util.Pair var3 = new org.apache.commons.math3.util.Pair(var2);
    org.apache.commons.math3.util.Pair var6 = new org.apache.commons.math3.util.Pair((java.lang.Object)(short)100, (java.lang.Object)10.0d);
    java.lang.Object var7 = var6.getSecond();
    java.lang.Object var8 = var6.getValue();
    boolean var9 = var3.equals((java.lang.Object)var6);
    java.lang.Object var10 = var6.getFirst();
    java.lang.Object var11 = var6.getKey();
    java.lang.Object var12 = var6.getValue();
    java.lang.Object var13 = var6.getValue();
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var7 + "' != '" + 10.0d+ "'", var7.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var8 + "' != '" + 10.0d+ "'", var8.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue(var9 == false);
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var10 + "' != '" + (short)100+ "'", var10.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var11 + "' != '" + (short)100+ "'", var11.equals((short)100));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var12 + "' != '" + 10.0d+ "'", var12.equals(10.0d));
    
    // Regression assertion (captures the current behavior of the code)
    assertTrue("'" + var13 + "' != '" + 10.0d+ "'", var13.equals(10.0d));

  }

}
